mod zones;

pub use zones::zone_label;

use std::fmt;
use std::fs;
use std::io::{BufRead, BufReader};
use std::env;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {}", zone)
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {}g exceeds zone limit {}g", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Represents a single band in the rate card.
#[derive(Debug)]
struct Band {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

#[derive(Debug)]
struct RateCard {
    bands: Vec<Band>,
}

impl RateCard {
    fn from_path(path: &str) -> Result<Self, QuoteError> {
        let file = fs::File::open(path).map_err(|_| QuoteError::RateCardUnavailable)?;
        let reader = BufReader::new(file);
        let mut bands = Vec::new();

        for (idx, line_result) in reader.lines().enumerate() {
            let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
            let line_num = idx + 1;

            let trimmed = line.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }

            let parts: Vec<&str> = trimmed.split('\t').collect();
            if parts.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: line_num });
            }

            let zone = parts[0].trim().to_string();
            let band_max_grams: u32 = parts[1]
                .trim()
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
            let cents: u64 = parts[2]
                .trim()
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

            bands.push(Band {
                zone,
                band_max_grams,
                cents,
            });
        }

        Ok(RateCard { bands })
    }

    fn get_zone_bands(&self, zone: &str) -> Vec<&Band> {
        self.bands
            .iter()
            .filter(|b| b.zone == zone)
            .collect()
    }
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let rate_card = RateCard::from_path(&path)?;

    let zone_bands = rate_card.get_zone_bands(&parcel.zone);
    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let sorted_bands: Vec<&Band> = {
        let mut bands: Vec<&Band> = zone_bands;
        bands.sort_by_key(|b| b.band_max_grams);
        bands
    };

    let max_band = sorted_bands.last().unwrap();
    if parcel.weight_grams > max_band.band_max_grams {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: max_band.band_max_grams,
        });
    }

    let matching_band = sorted_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .unwrap();

    let base_cents = matching_band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        surcharge_cents += round_half_up_20_percent(base_cents);
    }

    let total_cents = base_cents + surcharge_cents;

    tracing::info!(
        zone = &parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: matching_band.band_max_grams,
    })
}

fn round_half_up_20_percent(amount: u64) -> u64 {
    (amount as f64 * 0.20 + 0.5) as u64
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    fn create_test_rate_card(dir: &tempfile::TempDir, contents: &str) -> std::path::PathBuf {
        let file_path = dir.path().join("rate_card.tsv");
        let mut file = fs::File::create(&file_path).unwrap();
        file.write_all(contents.as_bytes()).unwrap();
        file_path
    }

    #[test]
    fn test_domestic_small_parcel() {
        let dir = tempfile::TempDir::new().unwrap();
        let rate_card_path = create_test_rate_card(&dir, "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
");
        std::env::set_var("RATECARD_PATH", rate_card_path.to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let quote_result = quote(&parcel);
        assert!(quote_result.is_ok());
        let quote = quote_result.unwrap();

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_medium_parcel() {
        let dir = tempfile::TempDir::new().unwrap();
        let rate_card_path = create_test_rate_card(&dir, "\
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
");
        std::env::set_var("RATECARD_PATH", rate_card_path.to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 1000,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_international_weight_above_10kg() {
        let dir = tempfile::TempDir::new().unwrap();
        let rate_card_path = create_test_rate_card(&dir, "\
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
");
        std::env::set_var("RATECARD_PATH", rate_card_path.to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 4999);
        let expected_surcharge = 500 + round_half_up_20_percent(4999);
        assert_eq!(quote.surcharge_cents, expected_surcharge);
        assert_eq!(quote.total_cents, 4999 + expected_surcharge);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_unknown_zone() {
        let dir = tempfile::TempDir::new().unwrap();
        let rate_card_path = create_test_rate_card(&dir, "domestic\t500\t599\n");
        std::env::set_var("RATECARD_PATH", rate_card_path.to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "europe".to_string(),
        };

        let result = quote(&parcel);
        assert!(result.is_err());
        match result.unwrap_err() {
            QuoteError::UnknownZone(z) => assert_eq!(z, "europe"),
            other => panic!("Expected UnknownZone, got {:?}", other),
        }
    }

    #[test]
    fn test_overweight() {
        let dir = tempfile::TempDir::new().unwrap();
        let rate_card_path = create_test_rate_card(&dir, "domestic\t500\t599\n");
        std::env::set_var("RATECARD_PATH", rate_card_path.to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 600,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(result.is_err());
        match result.unwrap_err() {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 600);
                assert_eq!(limit, 500);
            }
            other => panic!("Expected Overweight, got {:?}", other),
        }
    }

    #[test]
    fn test_missing_env_var() {
        std::env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
         };

        let result = quote(&parcel);
        assert!(result.is_err());
        match result.unwrap_err() {
            QuoteError::RateCardUnavailable => {}
            other => panic!("Expected RateCardUnavailable, got {:?}", other),
        }
    }

    #[test]
    fn test_malformed_rate_card() {
        let dir = tempfile::TempDir::new().unwrap();
        let rate_card_path = create_test_rate_card(
            &dir,
            "# header\ttest
domestic\t500\t599
bad line
",
        );
        std::env::set_var("RATECARD_PATH", rate_card_path.to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(result.is_err());
        match result.unwrap_err() {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 3),
            other => panic!("Expected MalformedRateCard, got {:?}", other),
        }
    }

    #[test]
    fn test_quote_error_display_rate_card_unavailable() {
        let err = QuoteError::RateCardUnavailable;
        assert_eq!(format!("{}", err), "rate card unavailable");
    }

    #[test]
    fn test_quote_error_display_malformed() {
        let err = QuoteError::MalformedRateCard { line: 5 };
        assert_eq!(format!("{}", err), "malformed rate card at line 5");
    }

    #[test]
    fn test_quote_error_display_unknown_zone() {
        let err = QuoteError::UnknownZone("asia".to_string());
        assert_eq!(format!("{}", err), "unknown zone: asia");
    }

    #[test]
    fn test_quote_error_display_overweight() {
        let err = QuoteError::Overweight { grams: 2500, limit: 2000 };
        assert_eq!(format!("{}", err), "parcel 2500g exceeds zone limit 2000g");
    }

    #[test]
    fn test_round_half_up_20_percent() {
        assert_eq!(round_half_up_20_percent(100), 20);
        assert_eq!(round_half_up_20_percent(101), 20);
        assert_eq!(round_half_up_20_percent(0), 0);
        assert_eq!(round_half_up_20_percent(999), 200);
        assert_eq!(round_half_up_20_percent(1499), 300);
    }

    #[test]
    fn test_international_small_parcel() {
        let dir = tempfile::TempDir::new().unwrap();
        let rate_card_path = create_test_rate_card(&dir, "\
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
");
        std::env::set_var("RATECARD_PATH", rate_card_path.to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(
            quote.surcharge_cents,
            round_half_up_20_percent(1499),
        );
        assert_eq!(quote.total_cents, 1499 + round_half_up_20_percent(1499));
        assert_eq!(quote.band_max_grams, 500);
    }
}
