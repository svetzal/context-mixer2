use std::fmt;
use std::fs;
use std::io::{BufRead, BufReader};

pub mod zones;

// -- Public types -----------------------------------------------------------

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {:.0}g exceeds zone limit of {:.0}g", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

// -- Internal types ---------------------------------------------------------

struct Band {
    band_max_grams: u32,
    cents: u64,
}

type RateCard = Vec<Band>;
use std::collections::HashMap;
type ZoneMap = HashMap<String, RateCard>;

// -- Core (pure) logic ------------------------------------------------------

fn lookup_zone<'a>(card: &'a ZoneMap, zone: &str) -> Result<&'a RateCard, QuoteError> {
    card.get(zone).ok_or_else(|| QuoteError::UnknownZone(zone.to_string()))
}

fn find_band(bands: &[Band], weight: u32) -> Result<&Band, QuoteError> {
    // Bands sorted ascending by band_max_grams; find first with band_max >= weight
    for band in bands {
        if band.band_max_grams >= weight {
            return Ok(band);
        }
    }
    let limit = bands.last()
        .map(|b| b.band_max_grams)
        .unwrap_or(0);
    Err(QuoteError::Overweight { grams: weight, limit })
}

// -- Parsing ----------------------------------------------------------------

fn parse_rate_card(path: &str) -> Result<ZoneMap, QuoteError> {
    let file = fs::File::open(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);
    let mut map: ZoneMap = HashMap::new();

    for (idx, line_result) in reader.lines().enumerate() {
        let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
        let line_number = idx + 1;

        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = trimmed.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = fields[0].trim().to_string();
        let max_grams: u32 = fields[1].trim().parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2].trim().parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        map.entry(zone).or_insert_with(Vec::new).push(Band {
            band_max_grams: max_grams,
            cents,
        });
    }

    Ok(map)
}

// -- Surcharges (replaces inline version) -----------------------------------

fn calc_weight_surcharge(weight: u32) -> u64 {
    if weight > 10_000 { 500 } else { 0 }
}

fn calc_zone_surcharge(base: u64, zone: &str) -> u64 {
    if zone == "international" {
        let numerator = (base as u128) * 20 + 50;
        (numerator / 100) as u64
    } else {
        0
    }
}

// -- Public API -------------------------------------------------------------

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = parse_rate_card(&path)?;

    let bands = lookup_zone(&card, &parcel.zone)?;
    let band = find_band(bands, parcel.weight_grams)?;

    let base = band.cents;
    let weight_surcharge = calc_weight_surcharge(parcel.weight_grams);
    let zone_surcharge = calc_zone_surcharge(base, &parcel.zone);
    let surcharge = weight_surcharge + zone_surcharge;
    let total = base + surcharge;

    tracing::info!(
        zone = &parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total,
        "quote computed"
    );

    Ok(Quote {
        base_cents: base,
        surcharge_cents: surcharge,
        total_cents: total,
        band_max_grams: band.band_max_grams,
    })
}

// -- Tests ------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn write_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().expect("create temp ratecard");
        write!(file, "{}", content).expect("write ratecard");
        file
    }

    #[test]
    fn basic_domestic_quote() {
        let rc = write_ratecard("# zone\tband_max_grams\tcents\n\ndomestic\t500\t599\ndomestic\t2000\t899\n");
        std::env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel { weight_grams: 300, zone: "domestic".to_string() };
        let q = quote(&parcel).expect("should quote");

        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_heavy_surcharge() {
        let rc = write_ratecard("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n");
        std::env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel { weight_grams: 15000, zone: "domestic".to_string() };
        let q = quote(&parcel).expect("should quote");

        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn international_zone_surcharge() {
        let rc = write_ratecard("international\t500\t1499\ninternational\t20000\t4999\n");
        std::env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel { weight_grams: 400, zone: "international".to_string() };
        let q = quote(&parcel).expect("should quote");

        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300); // 20% of 1499 = 299.8 -> 300
        assert_eq!(q.total_cents, 1799);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn international_heavy_both_surcharges() {
        let rc = write_ratecard("international\t500\t1499\ninternational\t20000\t4999\n");
        std::env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel { weight_grams: 12000, zone: "international".to_string() };
        let q = quote(&parcel).expect("should quote");

        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 500 + 1000); // weight + 20% of 4999 = 999.8+0.5=1000
        assert_eq!(q.total_cents, 6499);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn unknown_zone() {
        let rc = write_ratecard("domestic\t500\t599\n");
        std::env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel { weight_grams: 100, zone: "express".to_string() };
        let result = quote(&parcel);

        assert!(matches!(result, Err(QuoteError::UnknownZone(z)) if z == "express"));
    }

    #[test]
    fn overweight() {
        let rc = write_ratecard("domestic\t500\t599\ndomestic\t2000\t899\n");
        std::env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel { weight_grams: 5000, zone: "domestic".to_string() };
        let Err(QuoteError::Overweight { grams, limit }) = quote(&parcel) else {
            panic!("expected Overweight error");
        };
        assert_eq!(grams, 5000);
        assert_eq!(limit, 2000);
    }

    #[test]
    fn ratecard_missing() {
        std::env::remove_var("RATECARD_PATH");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn ratecard_file_missing() {
        std::env::set_var("RATECARD_PATH", "/nonexistent/path/to/ratecard");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn malformed_ratecard_wrong_fields() {
        let rc = write_ratecard("domestic\t500\n");
        std::env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let Err(QuoteError::MalformedRateCard { line }) = quote(&parcel) else {
            panic!("expected MalformedRateCard");
        };
        assert_eq!(line, 1);
    }

    #[test]
    fn malformed_ratecard_bad_number() {
        let rc = write_ratecard("domestic\tabc\t599\n");
        std::env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let Err(QuoteError::MalformedRateCard { line }) = quote(&parcel) else {
            panic!("expected MalformedRateCard");
        };
        assert_eq!(line, 1);
    }

    #[test]
    fn line_number_counts_all_lines() {
        // Line 1: comment, line 2: blank, line 3: valid, line 4: malformed
        let rc = write_ratecard("# header\n\ndomestic\t500\t599\ndomestic\tbad\n");
        std::env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let Err(QuoteError::MalformedRateCard { line }) = quote(&parcel) else {
            panic!("expected MalformedRateCard");
        };
        assert_eq!(line, 4);
    }

    #[test]
    fn exactly_at_band_boundary() {
        let rc = write_ratecard("domestic\t500\t599\ndomestic\t2000\t899\n");
        std::env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel { weight_grams: 500, zone: "domestic".to_string() };
        let q = quote(&parcel).expect("should quote");
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn display_error_ratecard_unavailable() {
        let err = QuoteError::RateCardUnavailable;
        assert!(!format!("{}", err).is_empty());
    }

    #[test]
    fn display_error_malformed() {
        let err = QuoteError::MalformedRateCard { line: 3 };
        assert!(format!("{}", err).contains("3"));
    }

    #[test]
    fn display_error_unknown_zone() {
        let err = QuoteError::UnknownZone("arctic".to_string());
        assert!(format!("{}", err).contains("arctic"));
    }

    #[test]
    fn display_error_overweight() {
        let err = QuoteError::Overweight { grams: 9999, limit: 5000 };
        let msg = format!("{}", err);
        assert!(msg.contains("9999"));
        assert!(msg.contains("5000"));
    }

    #[test]
    fn error_implements_std_error() {
        let err = Box::<dyn std::error::Error>::from(QuoteError::RateCardUnavailable);
        drop(err);
    }

    #[test]
    fn rounding_half_up_20_percent() {
        // 20% of 1499 = 299.8, round half-up = 300
        let rc = write_ratecard("international\t500\t1499\n");
        std::env::set_var("RATECARD_PATH", rc.path());
        let parcel = Parcel { weight_grams: 100, zone: "international".to_string() };
        let q = quote(&parcel).expect("should quote");
        assert_eq!(q.surcharge_cents, 300);
    }
}
