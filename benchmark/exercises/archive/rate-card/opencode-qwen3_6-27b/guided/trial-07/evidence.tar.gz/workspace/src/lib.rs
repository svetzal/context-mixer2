use std::collections::BTreeMap;
use std::env;
use std::fmt;
use std::fs;
use std::io::{BufRead, BufReader};

pub mod zones;

// -- public types --

#[derive(Clone, Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Clone, Debug, PartialEq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {} grams exceeds limit of {} grams", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

// -- internal rate-card model --

#[derive(Clone, Debug)]
struct Band {
    band_max_grams: u32,
    cents: u64,
}

type RateCard = BTreeMap<String, Vec<Band>>;

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let file = fs::File::open(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);

    let mut card = BTreeMap::new();

    for (idx, line_result) in reader.lines().enumerate() {
        let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
        let line_num = idx + 1;

        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = trimmed.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].trim().to_string();
        let max_grams: u32 = parts[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        card.entry(zone).or_insert_with(Vec::new).push(Band {
            band_max_grams: max_grams,
            cents,
        });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|b| b.band_max_grams);
    }

    Ok(card)
}

// -- public API --

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = load_rate_card()?;

    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    if bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let matching = bands.iter().find(|b| b.band_max_grams >= parcel.weight_grams);

    let (band_max, base) = match matching {
        Some(b) => (b.band_max_grams, b.cents),
        None => {
            let limit = bands.last().unwrap().band_max_grams;
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let mut surcharge: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge += 500;
    }

    if parcel.zone == "international" {
        surcharge += round_half_up(base * 200);
    }

    let total = base + surcharge;

    tracing::info!(
        zone = &parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total,
        "quote_calculated"
    );

    Ok(Quote {
        base_cents: base,
        surcharge_cents: surcharge,
        total_cents: total,
        band_max_grams: band_max,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    fn write_ratecard(tmp: &tempfile::NamedTempFile, content: &str) {
        let mut f = fs::File::create(tmp.path()).unwrap();
        write!(f, "{}", content).unwrap();
    }

    #[test]
    fn missing_ratecard_path() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        assert_eq!(
            quote(&parcel),
            Err(QuoteError::RateCardUnavailable)
        );
    }

    #[test]
    fn unknown_zone() {
        let tmp = tempfile::NamedTempFile::new().unwrap();
        write_ratecard(&tmp, "domestic\t500\t599\n");
        env::set_var("RATECARD_PATH", tmp.path());
        let parcel = Parcel {
            weight_grams: 100,
            zone: "arctic".to_string(),
        };
        assert_eq!(quote(&parcel), Err(QuoteError::UnknownZone("arctic".into())));
    }

    #[test]
    fn basic_domestic_quote() {
        let tmp = tempfile::NamedTempFile::new().unwrap();
        write_ratecard(
            &tmp,
            "domestic\t500\t599\ndomestic\t2000\t899\n",
        );
        env::set_var("RATECARD_PATH", tmp.path());
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_heavy_surcharge() {
        let tmp = tempfile::NamedTempFile::new().unwrap();
        write_ratecard(
            &tmp,
            "domestic\t500\t599\ndomestic\t20000\t1799\n",
        );
        env::set_var("RATECARD_PATH", tmp.path());
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn international_surcharge() {
        let tmp = tempfile::NamedTempFile::new().unwrap();
        write_ratecard(
            &tmp,
            "international\t500\t1499\ninternational\t20000\t4999\n",
        );
        env::set_var("RATECARD_PATH", tmp.path());
        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };
        let q = quote(&parcel).unwrap();
        let ico = round_half_up(1499 * 200);
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, ico);
        assert_eq!(q.total_cents, 1499 + ico);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn overweight_error() {
        let tmp = tempfile::NamedTempFile::new().unwrap();
        write_ratecard(&tmp, "domestic\t500\t599\n");
        env::set_var("RATECARD_PATH", tmp.path());
        let parcel = Parcel {
            weight_grams: 600,
            zone: "domestic".to_string(),
        };
        assert_eq!(
            quote(&parcel),
            Err(QuoteError::Overweight {
                grams: 600,
                limit: 500
            })
        );
    }

    #[test]
    fn malformed_ratecard() {
        let tmp = tempfile::NamedTempFile::new().unwrap();
        write_ratecard(&tmp, "domestic\t500\n");
        env::set_var("RATECARD_PATH", tmp.path());
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        assert_eq!(
            quote(&parcel),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn malformed_bad_number() {
        let tmp = tempfile::NamedTempFile::new().unwrap();
        write_ratecard(&tmp, "# comment\n\ndomestic\tabc\t599\n");
        env::set_var("RATECARD_PATH", tmp.path());
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        assert_eq!(
            quote(&parcel),
            Err(QuoteError::MalformedRateCard { line: 3 })
        );
    }

    #[test]
    fn comments_and_blanks_skipped() {
        let tmp = tempfile::NamedTempFile::new().unwrap();
        write_ratecard(
            &tmp,
            "# header\n\ndomestic\t500\t599\n\n# trailing\n",
        );
        env::set_var("RATECARD_PATH", tmp.path());
        let parcel = Parcel {
            weight_grams: 400,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn exact_band_match() {
        let tmp = tempfile::NamedTempFile::new().unwrap();
        write_ratecard(
            &tmp,
            "domestic\t500\t599\ndomestic\t2000\t899\n",
        );
        env::set_var("RATECARD_PATH", tmp.path());
        let parcel = Parcel {
            weight_grams: 2000,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn both_surcharges_international_heavy() {
        let tmp = tempfile::NamedTempFile::new().unwrap();
        write_ratecard(
            &tmp,
            "international\t500\t1499\ninternational\t20000\t4999\n",
        );
        env::set_var("RATECARD_PATH", tmp.path());
        let parcel = Parcel {
            weight_grams: 12000,
            zone: "international".to_string(),
        };
        let q = quote(&parcel).unwrap();
        let ico = round_half_up(4999 * 200);
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 500 + ico);
        assert_eq!(q.total_cents, 4999 + 500 + ico);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn display_and_error_trait() {
        let e = QuoteError::UnknownZone("sea".into());
        assert!(!format!("{}", e).is_empty());
        let _: &dyn std::error::Error = &e;
    }

    #[test]
    fn rounding_half_up_edge() {
        // 20% of 1499 = 299.8 -> 300
        assert_eq!(round_half_up(1499 * 200), 300);
        // 20% of 1000 = 200.0 -> 200
        assert_eq!(round_half_up(1000 * 200), 200);
    }

    #[test]
    fn unreadable_path() {
        env::set_var("RATECARD_PATH", "/no/such/path/file.tsv");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        assert_eq!(
            quote(&parcel),
            Err(QuoteError::RateCardUnavailable)
        );
    }
}
