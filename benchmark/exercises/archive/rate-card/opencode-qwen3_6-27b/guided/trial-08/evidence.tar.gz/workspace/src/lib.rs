mod rate_card;

use std::fmt;

pub use rate_card::quote;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {}", zone)
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {}g exceeds zone limit of {}g", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}
