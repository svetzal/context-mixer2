use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::io::{BufRead, BufReader};
use tracing::info;
use crate::{Parcel, Quote, QuoteError};
#[derive(Debug, Clone)]
pub(crate) struct Band {
    pub(crate) max_grams: u32,
    pub(crate) cents: u64,
}
pub(crate) type RateCard = BTreeMap<String, Vec<Band>>;
pub trait RateCardGateway {
    fn load(&self) -> Result<RateCard, QuoteError>;
}
pub struct FileGateway;
impl RateCardGateway for FileGateway {
    fn load(&self) -> Result<RateCard, QuoteError> {
        let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
        let file = fs::File::open(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
        let reader = BufReader::new(file);
        let mut map: RateCard = BTreeMap::new();
        for (idx, line_result) in reader.lines().enumerate() {
            let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
            let line_num = idx + 1;
            let trimmed = line.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }
            let parts: Vec<&str> = trimmed.split('\t').collect();
            if parts.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: line_num });
            }
            let zone = parts[0].trim().to_string();
            let max_grams: u32 = parts[1].trim().parse().map_err(|_| {
                QuoteError::MalformedRateCard { line: line_num }
            })?;
            let cents: u64 = parts[2].trim().parse().map_err(|_| {
                QuoteError::MalformedRateCard { line: line_num }
            })?;
            map.entry(zone).or_insert_with(Vec::new).push(Band {
                max_grams,
                cents,
            });
        }
        for bands in map.values_mut() {
            bands.sort_by_key(|b| b.max_grams);
        }
        Ok(map)
    }
}
fn find_band(bands: &[Band], weight: u32) -> Option<&Band> {
    bands.iter().find(|b| b.max_grams >= weight)
}
pub(crate) fn compute_quote(
    card: &RateCard,
    parcel: &Parcel,
) -> Result<Quote, QuoteError> {
    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band = find_band(bands, parcel.weight_grams)
        .ok_or_else(|| {
            let limit = bands.last().map(|b| b.max_grams).unwrap_or(0);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;
    let base = band.cents;
    let mut surcharge: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge += 500;
    }
    if parcel.zone == "international" {
        surcharge += round_half_up(base, 20, 100);
    }
    let total = base + surcharge;
    info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total,
        "quote computed"
    );
    Ok(Quote {
        base_cents: base,
        surcharge_cents: surcharge,
        total_cents: total,
        band_max_grams: band.max_grams,
    })
}
fn round_half_up(value: u64, numerator: u64, denominator: u64) -> u64 {
    (value * numerator * 2 + denominator) / (denominator * 2)
}
pub fn quote_gateway<G: RateCardGateway>(gateway: &G, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = gateway.load()?;
    compute_quote(&card, parcel)
}
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_gateway(&FileGateway, parcel)
}
#[cfg(test)]
mod tests {
    use super::*;
    struct InMemoryGateway {
        card: RateCard,
    }
    impl InMemoryGateway {
        fn new(card: RateCard) -> Self {
            Self { card }
        }
    }
    impl RateCardGateway for InMemoryGateway {
        fn load(&self) -> Result<RateCard, QuoteError> {
            Ok(self.card.clone())
        }
    }
    fn make_card() -> RateCard {
        let mut map: RateCard = BTreeMap::new();
        map.insert(
            "domestic".to_string(),
            vec![
                Band { max_grams: 500, cents: 599 },
                Band { max_grams: 2000, cents: 899 },
                Band { max_grams: 20000, cents: 1799 },
            ],
        );
        map.insert(
            "international".to_string(),
            vec![
                Band { max_grams: 500, cents: 1499 },
                Band { max_grams: 20000, cents: 4999 },
            ],
        );
        map
    }
    #[test]
    fn domestic_light_no_surcharge() {
        let card = make_card();
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let quote = quote_gateway(&InMemoryGateway::new(card), &parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }
    #[test]
    fn domestic_heavy_weight_surcharge() {
        let card = make_card();
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let quote = quote_gateway(&InMemoryGateway::new(card), &parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }
    #[test]
    fn international_with_percent_surcharge() {
        let card = make_card();
        let parcel = Parcel {
            weight_grams: 400,
            zone: "international".to_string(),
        };
        let quote = quote_gateway(&InMemoryGateway::new(card), &parcel).unwrap();
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
        assert_eq!(quote.band_max_grams, 500);
    }
    #[test]
    fn international_heavy_both_surcharges() {
        let card = make_card();
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let quote = quote_gateway(&InMemoryGateway::new(card), &parcel).unwrap();
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 500 + 1000);
        assert_eq!(quote.total_cents, 4999 + 500 + 1000);
        assert_eq!(quote.band_max_grams, 20000);
    }
    #[test]
    fn unknown_zone_error() {
        let card = make_card();
        let parcel = Parcel {
            weight_grams: 100,
            zone: "express".to_string(),
        };
        let result = quote_gateway(&InMemoryGateway::new(card), &parcel);
        assert!(matches!(&result, Err(QuoteError::UnknownZone(z)) if z == "express"));
    }
    #[test]
    fn overweight_error() {
        let card = make_card();
        let parcel = Parcel {
            weight_grams: 50000,
            zone: "domestic".to_string(),
        };
        let result = quote_gateway(&InMemoryGateway::new(card), &parcel);
         assert!(matches!(&result, Err(QuoteError::Overweight { grams: 50000, limit: 20000 })));
    }
    #[test]
    fn round_half_up_exact() {
        assert_eq!(round_half_up(1000, 20, 100), 200);
    }
    #[test]
    fn round_half_up_rounds_up() {
         assert_eq!(round_half_up(1499, 20, 100), 300);
    }
}
