use std::collections::HashMap;
use std::env;
use std::fmt;
use std::fs;

/// A parcel to be shipped.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A shipping quote calculated from a rate card.
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Errors that can occur when computing a quote.
#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card file is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {}g exceeds zone limit {}g", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

fn parse_rate_card(text: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut map: HashMap<String, Vec<Band>> = HashMap::new();

    for (idx, raw_line) in text.lines().enumerate() {
        let line_num = idx + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = trimmed.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].trim().to_string();
        let max_grams: u32 = parts[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        map.entry(zone).or_insert_with(Vec::new).push(Band { max_grams, cents });
    }

    for bands in map.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(map)
}

fn calc_quote(parcel: &Parcel, rc: &HashMap<String, Vec<Band>>) -> Result<Quote, QuoteError> {
    let bands = rc.get(&parcel.zone).ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    if bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let matching = bands.iter().find(|b| b.max_grams >= parcel.weight_grams);

    let (base_cents, band_max_grams) = match matching {
        Some(b) => (b.cents, b.max_grams),
        None => {
            let limit = bands.last().map(|b| b.max_grams).unwrap();
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        surcharge_cents += twenty_percent_half_up(base_cents);
    }

    let total_cents = base_cents + surcharge_cents;

    tracing::info!(
        zone = &parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

/// Calculate 20% of a value, rounded half-up to the nearest cent.
///
/// Uses integer arithmetic: `(value * 2 + 5) / 10` which implements
/// half-up rounding for 20% of any non-negative integer.
fn twenty_percent_half_up(value: u64) -> u64 {
    (value * 2 + 5) / 10
}

/// Calculate a shipping quote for the given parcel.
///
/// Reads the rate card from the file path specified by the `RATECARD_PATH`
/// environment variable.
///
/// # Example
///
/// ```no_run
/// use ratecard::{quote, Parcel};
///
/// std::env::set_var("RATECARD_PATH", "ratecard.tsv");
/// let parcel = Parcel { weight_grams: 300, zone: "domestic".to_string() };
/// let result = quote(&parcel);
/// ```
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let rc = parse_rate_card(&contents)?;
    calc_quote(parcel, &rc)
}

#[cfg(test)]
mod tests {
    use super::*;

    const DEFAULT_CARD: &str = "# zone\tband_max_grams\tcents\n\
                                  domestic\t500\t599\n\
                                  domestic\t2000\t899\n\
                                  domestic\t20000\t1799\n\
                                  international\t500\t1499\n\
                                  international\t20000\t4999\n";

    fn default_rc() -> HashMap<String, Vec<Band>> {
        parse_rate_card(DEFAULT_CARD).unwrap()
    }

    #[test]
    fn basic_domestic_uses_first_matching_band() {
        let rc = default_rc();
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".into(),
        };
        let q = calc_quote(&parcel, &rc).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_over_10kg_gets_weight_surcharge() {
        let rc = default_rc();
        let parcel = Parcel {
            weight_grams: 15_000,
            zone: "domestic".into(),
        };
        let q = calc_quote(&parcel, &rc).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn domestic_exactly_10kg_no_surcharge() {
        let rc = default_rc();
        let parcel = Parcel {
            weight_grams: 10_000,
            zone: "domestic".into(),
        };
        let q = calc_quote(&parcel, &rc).unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn domestic_exactly_10kg_plus_1_gets_surcharge() {
        let rc = default_rc();
        let parcel = Parcel {
            weight_grams: 10_001,
            zone: "domestic".into(),
        };
        let q = calc_quote(&parcel, &rc).unwrap();
        assert_eq!(q.surcharge_cents, 500);
    }

    #[test]
    fn international_light_gets_20_percent_surcharge() {
        let rc = default_rc();
        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".into(),
        };
        let q = calc_quote(&parcel, &rc).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, twenty_percent_half_up(1499));
        assert_eq!(q.total_cents, 1499 + q.surcharge_cents);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn international_heavy_gets_both_surcharges() {
        let rc = default_rc();
        let parcel = Parcel {
            weight_grams: 15_000,
            zone: "international".into(),
        };
        let q = calc_quote(&parcel, &rc).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 500 + twenty_percent_half_up(4999));
        assert_eq!(q.total_cents, 4999 + q.surcharge_cents);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn unknown_zone_returns_error_with_zone_name() {
        let rc = default_rc();
        let parcel = Parcel {
            weight_grams: 100,
            zone: "europe".into(),
        };
        let result = calc_quote(&parcel, &rc);
        assert!(matches!(result, Err(QuoteError::UnknownZone(z)) if z == "europe"));
    }

    #[test]
    fn overweight_returns_error_with_limit() {
        let rc = default_rc();
        let parcel = Parcel {
            weight_grams: 50_000,
            zone: "international".into(),
        };
        let result = calc_quote(&parcel, &rc);
        assert!(matches!(result, Err(QuoteError::Overweight { grams: 50_000, limit: 20_000 })));
    }

    #[test]
    fn weight_between_bands_uses_next_band() {
        let rc = default_rc();
        let parcel = Parcel {
            weight_grams: 750,
            zone: "domestic".into(),
        };
        let q = calc_quote(&parcel, &rc).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn weight_at_exact_boundary_uses_that_band() {
        let rc = default_rc();
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".into(),
        };
        let q = calc_quote(&parcel, &rc).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn twenty_percent_half_up_values() {
        assert_eq!(twenty_percent_half_up(0), 0);
        assert_eq!(twenty_percent_half_up(1), 0);
        assert_eq!(twenty_percent_half_up(3), 1);
        assert_eq!(twenty_percent_half_up(5), 1);
        assert_eq!(twenty_percent_half_up(10), 2);
        assert_eq!(twenty_percent_half_up(100), 20);
        assert_eq!(twenty_percent_half_up(1499), 300);
        assert_eq!(twenty_percent_half_up(4999), 1000);
    }

    #[test]
    fn parse_skips_comments_and_blanks() {
        let text = "# header\n\n# note\ndomestic\t500\t599\n\n";
        let rc = parse_rate_card(text).unwrap();
        assert!(rc.contains_key("domestic"));
        assert_eq!(rc["domestic"].len(), 1);
    }

    #[test]
    fn parse_malformed_two_fields_returns_line_number() {
        let text = "domestic\t500\n";
        let result = parse_rate_card(text);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 1 })));
    }

    #[test]
    fn parse_malformed_non_numeric_returns_line_number() {
        let text = "domestic\tabc\t599\n";
        let result = parse_rate_card(text);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 1 })));
    }

    #[test]
    fn parse_malformed_line_counts_all_lines() {
        let text = "# comment\n\nbad line here\n";
        let result = parse_rate_card(text);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 3 })));
    }

    #[test]
    fn display_format_ratecard_unavailable() {
        let err = QuoteError::RateCardUnavailable;
        assert!(!format!("{}", err).is_empty());
    }

    #[test]
    fn display_format_unknown_zone() {
        let err = QuoteError::UnknownZone("eu-west".into());
        assert!(format!("{}", err).contains("eu-west"));
    }

    #[test]
    fn display_format_overweight() {
        let err = QuoteError::Overweight { grams: 5000, limit: 2000 };
        let msg = format!("{}", err);
        assert!(msg.contains("5000"));
        assert!(msg.contains("2000"));
    }

    #[test]
    fn display_format_malformed() {
        let err = QuoteError::MalformedRateCard { line: 7 };
        assert!(format!("{}", err).contains("7"));
    }

    #[test]
    fn error_implements_std_error() {
        let err: Box<dyn std::error::Error> = Box::new(QuoteError::RateCardUnavailable);
        drop(err);
    }
}

#[cfg(test)]
mod wiring_tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn temp_ratecard(content: &str) -> (tempfile::TempDir, std::path::PathBuf) {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("rc.tsv");
        let mut f = std::fs::File::create(&path).unwrap();
        f.write_all(content.as_bytes()).unwrap();
        env::set_var("RATECARD_PATH", path.to_str().unwrap());
        (dir, path)
      }

      #[test]
    fn quote_missing_env_returns_unavailable() {
        let _lock = ENV_LOCK.lock().unwrap();
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".into() };
        assert!(matches!(quote(&parcel), Err(QuoteError::RateCardUnavailable)));
      }

      #[test]
    fn quote_nonexistent_path_returns_unavailable() {
        let _lock = ENV_LOCK.lock().unwrap();
        env::set_var("RATECARD_PATH", "/no/such/file/rc.tsv");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".into() };
        assert!(matches!(quote(&parcel), Err(QuoteError::RateCardUnavailable)));
      }

      #[test]
    fn quote_end_to_end_success() {
        let _lock = ENV_LOCK.lock().unwrap();
        let (_dir, _path) = temp_ratecard("domestic\t500\t599\n");
        let parcel = Parcel { weight_grams: 300, zone: "domestic".into() };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
      }

      #[test]
    fn quote_end_to_end_malformed() {
        let _lock = ENV_LOCK.lock().unwrap();
        let (_dir, _path) = temp_ratecard("bad\n");
        let parcel = Parcel { weight_grams: 300, zone: "domestic".into() };
        assert!(matches!(quote(&parcel), Err(QuoteError::MalformedRateCard { line: 1 })));
      }
}
