use std::fmt;
use std::fs;
use std::io::{BufRead, BufReader};
use std::env;

pub mod zones;

#[derive(Clone, Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Clone, Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {}g exceeds zone limit of {}g", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct RateBand {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<Vec<RateBand>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let file = fs::File::open(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);

    let mut bands = Vec::new();
    for (idx, line_result) in reader.lines().enumerate() {
        let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
        let line_num = idx + 1;

        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = trimmed.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].trim().to_string();
        let band_max_grams: u32 = parts[1].trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2].trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        bands.push(RateBand {
            zone,
            band_max_grams,
            cents,
        });
    }

    Ok(bands)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let all_bands = load_rate_card()?;

    let zone_bands: Vec<&RateBand> = all_bands
        .iter()
        .filter(|b| b.zone == parcel.zone)
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let mut sorted_bands = zone_bands.clone();
    sorted_bands.sort_by_key(|b| b.band_max_grams);

    let largest_limit = sorted_bands.last().unwrap().band_max_grams;

    if parcel.weight_grams > largest_limit {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest_limit,
        });
    }

    let matched_band = sorted_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .unwrap();

    let base_cents = matched_band.cents;

    let mut surcharge = 0_u64;

    if parcel.weight_grams > 10000 {
        surcharge += 500;
    }

    if parcel.zone == "international" {
        surcharge += (base_cents * 20 + 50) / 100;
      }

    let total_cents = base_cents + surcharge;

    let result = Quote {
        base_cents,
        surcharge_cents: surcharge,
        total_cents,
        band_max_grams: matched_band.band_max_grams,
    };

    tracing::info!(
        zone = &parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total_cents,
        "quote calculated"
    );

    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    fn write_ratecard(path: &std::path::Path, content: &str) {
        let mut file = fs::File::create(path).expect("failed to create ratecard");
        file.write_all(content.as_bytes()).expect("failed to write ratecard");
    }

    #[test]
    fn test_basic_domestic_quote() {
        let dir = tempfile::tempdir().expect("tempdir");
        let path = dir.path().join("rc.tsv");
        write_ratecard(
            &path,
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n",
        );

        env::set_var("RATECARD_PATH", path.to_str().unwrap());
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(result.is_ok(), "expected Ok, got {:?}", result);
        let q = result.unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_heavy_surcharge() {
        let dir = tempfile::tempdir().expect("tempdir");
        let path = dir.path().join("rc.tsv");
        write_ratecard(
            &path,
            "domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n",
        );

        env::set_var("RATECARD_PATH", path.to_str().unwrap());
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(result.is_ok());
        let q = result.unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn test_international_surcharge() {
        let dir = tempfile::tempdir().expect("tempdir");
        let path = dir.path().join("rc.tsv");
        write_ratecard(
            &path,
            "international\t500\t1499\n\
             international\t20000\t4999\n",
        );

        env::set_var("RATECARD_PATH", path.to_str().unwrap());
        let parcel = Parcel {
            weight_grams: 200,
            zone: "international".to_string(),
        };
        let result = quote(&parcel);
        assert!(result.is_ok());
        let q = result.unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn test_unknown_zone() {
        let dir = tempfile::tempdir().expect("tempdir");
        let path = dir.path().join("rc.tsv");
        write_ratecard(&path, "domestic\t500\t599\n");

        env::set_var("RATECARD_PATH", path.to_str().unwrap());
        let parcel = Parcel {
            weight_grams: 100,
            zone: "arctic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::UnknownZone(z)) if z == "arctic"));
    }

    #[test]
    fn test_overweight() {
        let dir = tempfile::tempdir().expect("tempdir");
        let path = dir.path().join("rc.tsv");
        write_ratecard(&path, "domestic\t500\t599\n");

        env::set_var("RATECARD_PATH", path.to_str().unwrap());
        let parcel = Parcel {
            weight_grams: 600,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        match result {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 600);
                assert_eq!(limit, 500);
            }
            _ => panic!("expected Overweight"),
        }
    }

    #[test]
    fn test_missing_ratecard_path() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_malformed_ratecard() {
        let dir = tempfile::tempdir().expect("tempdir");
        let path = dir.path().join("rc.tsv");
        write_ratecard(&path, "domestic\t500\n");

        env::set_var("RATECARD_PATH", path.to_str().unwrap());
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        match result {
            Err(QuoteError::MalformedRateCard { line }) => {
                assert_eq!(line, 1);
            }
            _ => panic!("expected MalformedRateCard"),
        }
    }

    #[test]
    fn test_display_error_rate_card_unavailable() {
        let e = QuoteError::RateCardUnavailable;
        assert_eq!(format!("{}", e), "rate card is unavailable");
    }

    #[test]
    fn test_display_error_malformed() {
        let e = QuoteError::MalformedRateCard { line: 3 };
        assert_eq!(format!("{}", e), "malformed rate card at line 3");
    }

    #[test]
    fn test_display_error_unknown_zone() {
        let e = QuoteError::UnknownZone("oceanic".to_string());
        assert_eq!(format!("{}", e), "unknown zone: oceanic");
    }

    #[test]
    fn test_display_error_overweight() {
        let e = QuoteError::Overweight {
            grams: 5000,
            limit: 2000,
        };
        assert_eq!(
            format!("{}", e),
            "parcel 5000g exceeds zone limit of 2000g"
        );
    }

    #[test]
    fn test_international_heavy_both_surcharges() {
        let dir = tempfile::tempdir().expect("tempdir");
        let path = dir.path().join("rc.tsv");
        write_ratecard(
            &path,
            "international\t500\t1499\n\
             international\t20000\t4999\n",
        );

        env::set_var("RATECARD_PATH", path.to_str().unwrap());
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let result = quote(&parcel);
        assert!(result.is_ok());
        let q = result.unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn test_comments_and_blanks_ignored() {
        let dir = tempfile::tempdir().expect("tempdir");
        let path = dir.path().join("rc.tsv");
        write_ratecard(
            &path,
            "# This is a comment\n\
             \n\
             domestic\t500\t599\n\
             # Another comment\n",
        );

        env::set_var("RATECARD_PATH", path.to_str().unwrap());
        let parcel = Parcel {
            weight_grams: 400,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(result.is_ok());
        let q = result.unwrap();
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn test_weight_exactly_at_limit() {
        let dir = tempfile::tempdir().expect("tempdir");
        let path = dir.path().join("rc.tsv");
        write_ratecard(&path, "domestic\t500\t599\n");

        env::set_var("RATECARD_PATH", path.to_str().unwrap());
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(result.is_ok());
    }

    #[test]
    fn test_rounding_half_up_20_percent() {
        let dir = tempfile::tempdir().expect("tempdir");
        let path = dir.path().join("rc.tsv");
        write_ratecard(&path, "international\t500\t1499\n");

        env::set_var("RATECARD_PATH", path.to_str().unwrap());
        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.surcharge_cents, 300);
    }

    #[test]
    fn test_malformed_non_numeric_value() {
        let dir = tempfile::tempdir().expect("tempdir");
        let path = dir.path().join("rc.tsv");
        write_ratecard(&path, "domestic\tfive\t599\n");

        env::set_var("RATECARD_PATH", path.to_str().unwrap());
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        match result {
            Err(QuoteError::MalformedRateCard { line }) => {
                assert_eq!(line, 1);
            }
            _ => panic!("expected MalformedRateCard"),
        }
    }
}
