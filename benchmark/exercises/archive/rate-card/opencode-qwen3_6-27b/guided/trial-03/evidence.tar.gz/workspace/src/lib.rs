use std::collections::HashMap;
use std::env;
use std::fmt;
use std::fs;

pub mod zones;

// ---------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card is unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "rate card malformed at line {}", line)
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {}", zone)
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {}g exceeds zone limit {}", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

// ---------------------------------------------------------------------------
// Internal rate-card model
// ---------------------------------------------------------------------------

#[derive(Debug, Copy, Clone)]
struct Band {
    max_grams: u32,
    cents: u64,
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/// Calculate a shipping quote from a parcel description.
///
/// Reads the rate card from the path given by the `RATECARD_PATH`
/// environment variable.
///
/// # Example
///
/// ```ignore
/// use ratecard::{Parcel, quote};
///
/// std::env::set_var("RATECARD_PATH", "tests/ratecard.tsv");
/// let parcel = Parcel {
///     weight_grams: 300,
///     zone: "domestic".to_string(),
/// };
/// let q = quote(&parcel).unwrap();
/// assert_eq!(q.base_cents, 599);
/// ```
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = parse_rate_card()?;
    let result = compute_quote(parcel, &rate_card);

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = result.as_ref().map(|q| q.total_cents).unwrap_or(0),
        "quote calculated"
    );

    result
}

// ---------------------------------------------------------------------------
// Rate card I/O  (thin shell)
// ---------------------------------------------------------------------------

fn parse_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents =
        fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut map: HashMap<String, Vec<Band>> = HashMap::new();

    for (idx, raw_line) in contents.lines().enumerate() {
        let line_no = idx + 1;
        let line = raw_line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let zone = fields
            .next()
            .ok_or_else(|| QuoteError::MalformedRateCard { line: line_no })?;
        let max_grams_str = fields
            .next()
            .ok_or_else(|| QuoteError::MalformedRateCard { line: line_no })?;
        let cents_str = fields
            .next()
            .ok_or_else(|| QuoteError::MalformedRateCard { line: line_no })?;

        // Ensure no extra fields (exactly 3 columns)
        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }

        let max_grams = parse_u32(max_grams_str, line_no)?;
        let cents = parse_u64(cents_str, line_no)?;

        let band = Band {
            max_grams,
            cents: cents as u64,
        };

        map.entry(zone.to_string()).or_default().push(band);
    }

    // Sort each zone's bands ascending by max_grams
    for bands in map.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(map)
}

fn parse_u32(s: &str, line: usize) -> Result<u32, QuoteError> {
    s.parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line })
}

fn parse_u64(s: &str, line: usize) -> Result<u64, QuoteError> {
    s.parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line })
}

// ---------------------------------------------------------------------------
// Pure business logic
// ---------------------------------------------------------------------------

fn compute_quote(
    parcel: &Parcel,
    rate_card: &HashMap<String, Vec<Band>>,
) -> Result<Quote, QuoteError> {
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    if bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    // The largest band defines the zone's weight limit.
    let max_band = *bands.last().unwrap();

    if parcel.weight_grams > max_band.max_grams {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: max_band.max_grams,
        });
    }

    // Find the first band whose max_grams >= parcel weight
    let matching = bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .expect("logic: weight already checked against max band");

    let base_cents = matching.cents;
    let band_max = matching.max_grams;

    // Calculate surcharges
    let weight_surcharge = if parcel.weight_grams > 10_000 {
        500u64
    } else {
        0u64
    };

    let zone_surcharge = if parcel.zone == "international" {
        round_half_up(base_cents, 20)
    } else {
        0u64
    };

    let surcharge_cents = weight_surcharge + zone_surcharge;
    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band_max,
    })
}

/// Compute `base * pct / 100` rounded half-up to the nearest cent.
fn round_half_up(base: u64, pct: u64) -> u64 {
    // value = base * pct, divisor = 100
    // (numerator + divisor/2) / divisor  → half-up
    (base * pct + 50) / 100
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn write_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        file
    }

    fn setup_env(content: &str) -> NamedTempFile {
        let file = write_ratecard(content);
        env::set_var("RATECARD_PATH", file.path());
        file
    }

    // -- basic matching --

    #[test]
    fn domestic_small_parcel() {
        let _f = setup_env(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n\
             international\t500\t1499\n\
             international\t20000\t4999\n",
        );

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".into(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_medium_parcel() {
        let _f = setup_env(
            "domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n",
        );

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".into(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn domestic_heavy_parcel() {
        let _f = setup_env(
            "domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n",
        );

        let parcel = Parcel {
            weight_grams: 15_000,
            zone: "domestic".into(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 1799);
        // > 10000 g → weight surcharge 500
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20_000);
    }

    // -- international surcharge --

    #[test]
    fn international_small_parcel() {
        let _f = setup_env(
            "international\t500\t1499\n\
             international\t20000\t4999\n",
        );

        let parcel = Parcel {
            weight_grams: 400,
            zone: "international".into(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 1499);
        // 20% of 1499 = 299.8 → rounds half-up to 300
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn international_heavy_parcel() {
        let _f = setup_env(
            "international\t500\t1499\n\
             international\t20000\t4999\n",
        );

        let parcel = Parcel {
            weight_grams: 15_000,
            zone: "international".into(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 4999);
        // 20% of 4999 = 999.8 → 1000, + 500 weight = 1500
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
        assert_eq!(q.band_max_grams, 20_000);
    }

    // -- error cases --

    #[test]
    fn missing_ratecard_path() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        assert_eq!(quote(&parcel), Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn nonexistent_file() {
        env::set_var("RATECARD_PATH", "/tmp/does-not-exist-ratecard.tsv");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        assert_eq!(quote(&parcel), Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn unknown_zone() {
        let _f = setup_env("domestic\t500\t599\n");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "regional".into(),
        };
        assert_eq!(
            quote(&parcel),
            Err(QuoteError::UnknownZone("regional".into()))
        );
    }

    #[test]
    fn overweight() {
        let _f = setup_env("domestic\t500\t599\ndomestic\t2000\t899\n");
        let parcel = Parcel {
            weight_grams: 5000,
            zone: "domestic".into(),
        };
        assert_eq!(
            quote(&parcel),
            Err(QuoteError::Overweight {
                grams: 5000,
                limit: 2000
            })
        );
    }

    #[test]
    fn malformed_ratecard_missing_fields() {
        let _f = setup_env("domestic\t500\n");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        assert_eq!(
            quote(&parcel),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn malformed_ratecard_bad_number() {
        let _f = setup_env("domestic\tabc\t599\n");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        assert_eq!(
            quote(&parcel),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn malformed_ratecard_extra_fields() {
        let _f = setup_env("domestic\t500\t599\textra\n");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        assert_eq!(
            quote(&parcel),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn malformed_ratecard_line_counting() {
        // Lines 1-2 are comment/blank, line 3 is malformed.
        let _f = setup_env(
            "# header\n\
             \n\
             bad_line\n",
        );
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        assert_eq!(
            quote(&parcel),
            Err(QuoteError::MalformedRateCard { line: 3 })
        );
    }

    // -- boundary weight == exactly the band max --

    #[test]
    fn weight_exactly_at_band_max() {
        let _f = setup_env("domestic\t500\t599\ndomestic\t2000\t899\n");
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".into(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    // -- rounding half-up edge cases --

    #[test]
    fn round_half_up_exactly_half() {
        // 20% of 1001 = 200.2 → 200
        let _f = setup_env("international\t500\t1001\n");
        let parcel = Parcel {
            weight_grams: 400,
            zone: "international".into(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.surcharge_cents, 200);
    }

    #[test]
    fn round_half_up_rounds_up() {
        // 20% of 1005 = 201.0 → 201
        let _f = setup_env("international\t500\t1005\n");
        let parcel = Parcel {
            weight_grams: 400,
            zone: "international".into(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.surcharge_cents, 201);
    }

    #[test]
    fn display_errors() {
        assert_eq!(
            format!("{}", QuoteError::RateCardUnavailable),
            "rate card is unavailable"
        );
        assert_eq!(
            format!(
                "{}",
                QuoteError::MalformedRateCard { line: 5 }
            ),
            "rate card malformed at line 5"
        );
        assert_eq!(
            format!("{}", QuoteError::UnknownZone("foo".into())),
            "unknown zone: foo"
        );
        assert_eq!(
            format!(
                "{}",
                QuoteError::Overweight {
                    grams: 3000,
                    limit: 2000
                }
            ),
            "parcel weight 3000g exceeds zone limit 2000"
        );
    }

    #[test]
    fn is_std_error() {
        let e: Box<dyn std::error::Error> = Box::new(QuoteError::RateCardUnavailable);
        assert!(!e.to_string().is_empty());
    }

    // -- weight exactly 10001 triggers surcharge, 10000 does not --

    #[test]
    fn weight_10000_no_surcharge() {
        let _f = setup_env("domestic\t20000\t1799\n");
        let parcel = Parcel {
            weight_grams: 10_000,
            zone: "domestic".into(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn weight_10001_triggers_surcharge() {
        let _f = setup_env("domestic\t20000\t1799\n");
        let parcel = Parcel {
            weight_grams: 10_001,
            zone: "domestic".into(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.surcharge_cents, 500);
    }
}
