use std::collections::HashMap;
use std::fmt;
use std::fs;
use std::io::{BufRead, BufReader};
use std::env;

pub mod zones;

#[derive(Clone, Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card is unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "rate card is malformed at line {line}")
              }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
              }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel is overweight: {grams}g exceeds {limit}g limit")
              }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

struct RateCard {
    zones: HashMap<String, Vec<Band>>,
}

impl RateCard {
    fn from_file(path: &str) -> Result<Self, QuoteError> {
        let file = fs::File::open(path).map_err(|_| QuoteError::RateCardUnavailable)?;
        let reader = BufReader::new(file);
        let mut zones = HashMap::new();

        for (idx, line_result) in reader.lines().enumerate() {
            let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
            let line_num = idx + 1;

            let trimmed = line.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }

            let parts: Vec<&str> = trimmed.split('\t').collect();
            if parts.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: line_num });
            }

            let zone = parts[0].to_string();
            let max_grams: u32 = parts[1].trim().parse().map_err(|_| {
                QuoteError::MalformedRateCard { line: line_num }
            })?;
            let cents: u64 = parts[2].trim().parse().map_err(|_| {
                QuoteError::MalformedRateCard { line: line_num }
            })?;

            let band = Band {
                max_grams,
                cents,
            };

            zones.entry(zone).or_insert_with(Vec::new).push(band);
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|b| b.max_grams);
        }

        Ok(RateCard { zones })
    }

    fn find_band(&self, zone: &str, weight: u32) -> Result<Quote, QuoteError> {
        let bands = self.zones.get(zone).ok_or_else(|| QuoteError::UnknownZone(zone.to_string()))?;

        let max_band = bands.last()
            .expect("at least one band per zone");

        if weight > max_band.max_grams {
            return Err(QuoteError::Overweight {
                grams: weight,
                limit: max_band.max_grams,
            });
        }

        let matching = bands.iter().find(|b| b.max_grams >= weight)
            .expect("a band must exist because weight <= max");

        let base_cents = matching.cents;
        let band_max_grams = matching.max_grams;

        let mut surcharge_cents: u64 = 0;

        if weight > 10000 {
            surcharge_cents += 500;
        }

        if zone == "international" {
            surcharge_cents += calc_international_surcharge(base_cents);
          }

        let total_cents = base_cents + surcharge_cents;

        Ok(Quote {
            base_cents,
            surcharge_cents,
            total_cents,
            band_max_grams,
        })
    }
}

fn round_half_up(val: f64) -> f64 {
     (val * 10.0).round() / 10.0
 }

#[allow(clippy::cast_possible_truncation, clippy::cast_sign_loss, clippy::cast_precision_loss)]
fn calc_international_surcharge(base_cents: u64) -> u64 {
    round_half_up(base_cents as f64 * 0.2) as u64
}

/// Calculate a shipping quote for a parcel.
///
/// Reads the rate card from the path specified by the `RATECARD_PATH`
/// environment variable, matches the parcel's zone and weight against the
/// applicable band, and applies any surcharges.
///
/// # Errors
///
/// * [`QuoteError::RateCardUnavailable`] if the environment variable is not set
///   or the file cannot be read.
/// * [`QuoteError::MalformedRateCard`] if a data line has the wrong number of
///   fields or contains unparseable numbers.
/// * [`QuoteError::UnknownZone`] if the parcel's zone has no entries in the
///   rate card.
/// * [`QuoteError::Overweight`] if the parcel exceeds the largest band for its
///   zone.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let rate_card = RateCard::from_file(&path)?;
    let result = rate_card.find_band(&parcel.zone, parcel.weight_grams);

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = result.as_ref().map_or(0, |q| q.total_cents),
        "quote calculated"
    );

    result
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    fn write_ratecard(tmp: &tempfile::TempDir, content: &str) {
        let path = tmp.path().join("ratecard.tsv");
        let mut file = fs::File::create(&path).unwrap();
        file.write_all(content.as_bytes()).unwrap();
        env::set_var("RATECARD_PATH", path.to_str().unwrap());
     }

     #[serial_test::serial]
     #[test]
    fn basic_domestic_quote() {
        let tmp = tempfile::TempDir::with_prefix("ratecard-test").unwrap();
        write_ratecard(&tmp, "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\n");
        let parcel = Parcel {
            weight_grams: 400,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

      #[serial_test::serial]
      #[test]
    fn domestic_heavy_no_surcharge() {
        let tmp = tempfile::TempDir::with_prefix("ratecard-test").unwrap();
        write_ratecard(&tmp, "domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n");
        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

       #[serial_test::serial]
       #[test]
    fn heavy_over_10kg_surcharge() {
        let tmp = tempfile::TempDir::with_prefix("ratecard-test").unwrap();
        write_ratecard(&tmp, "domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n");
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

       #[serial_test::serial]
       #[test]
    fn international_zone_surcharge() {
        let tmp = tempfile::TempDir::with_prefix("ratecard-test").unwrap();
        write_ratecard(&tmp, "international\t500\t1499\ninternational\t20000\t4999\n");
        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 299);
        assert_eq!(quote.total_cents, 1798);
        assert_eq!(quote.band_max_grams, 500);
    }

       #[serial_test::serial]
       #[test]
    fn international_heavy_both_surcharges() {
        let tmp = tempfile::TempDir::with_prefix("ratecard-test").unwrap();
        write_ratecard(&tmp, "international\t500\t1499\ninternational\t20000\t4999\n");
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 4999);
        let pct = round_half_up(4999.0 * 0.2) as u64;
        let expected_surcharge = 500 + pct;
        assert_eq!(quote.surcharge_cents, expected_surcharge);
        assert_eq!(quote.total_cents, 4999 + expected_surcharge);
        assert_eq!(quote.band_max_grams, 20000);
    }

      #[serial_test::serial]
      #[test]
    fn unknown_zone_error() {
        let tmp = tempfile::TempDir::with_prefix("ratecard-test").unwrap();
        write_ratecard(&tmp, "domestic\t500\t599\n");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "europe".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert!(matches!(err, QuoteError::UnknownZone(ref z) if z == "europe"));
    }

      #[serial_test::serial]
      #[test]
    fn overweight_error() {
        let tmp = tempfile::TempDir::with_prefix("ratecard-test").unwrap();
        write_ratecard(&tmp, "domestic\t500\t599\ndomestic\t2000\t899\n");
        let parcel = Parcel {
            weight_grams: 5000,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert!(matches!(err, QuoteError::Overweight { grams: 5000, limit: 2000 }));
    }

      #[serial_test::serial]
      #[test]
    fn missing_ratecard_path() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

      #[serial_test::serial]
      #[test]
    fn malformed_line_wrong_fields() {
        let tmp = tempfile::TempDir::with_prefix("ratecard-test").unwrap();
        write_ratecard(&tmp, "domestic\t500\ndomestic\t500\t599\n");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

      #[serial_test::serial]
      #[test]
    fn malformed_line_bad_number() {
        let tmp = tempfile::TempDir::with_prefix("ratecard-test").unwrap();
        write_ratecard(&tmp, "# zone\tband_max_grams\tcents\ndomestic\tfive\t599\n");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 2 }));
    }

      #[serial_test::serial]
      #[test]
    fn exact_weight_matches_band() {
        let tmp = tempfile::TempDir::with_prefix("ratecard-test").unwrap();
        write_ratecard(&tmp, "domestic\t500\t599\ndomestic\t2000\t899\n");
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

      #[serial_test::serial]
      #[test]
    fn international_20_percent_rounding_half_up() {
        let tmp = tempfile::TempDir::with_prefix("ratecard-test").unwrap();
        write_ratecard(&tmp, "international\t500\t10001\n");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 10001);
        let pct = round_half_up(10001.0 * 0.2) as u64;
        assert_eq!(quote.surcharge_cents, pct);
    }

    #[test]
    fn display_error_ratecard_unavailable() {
        let err = QuoteError::RateCardUnavailable;
        assert!(!format!("{}", err).is_empty());
    }

    #[test]
    fn display_error_unknown_zone() {
        let err = QuoteError::UnknownZone("europe".to_string());
        assert!(format!("{}", err).contains("europe"));
    }

    #[test]
    fn display_error_overweight() {
        let err = QuoteError::Overweight { grams: 5000, limit: 2000 };
        let msg = format!("{}", err);
        assert!(msg.contains("5000"));
        assert!(msg.contains("2000"));
    }

    #[test]
    fn error_implements_std_error() {
        let err: Box<dyn std::error::Error> = Box::new(QuoteError::RateCardUnavailable);
        assert!(err.to_string().len() > 0);
    }

      #[serial_test::serial]
      #[test]
    fn comments_and_blank_lines_skipped() {
        let tmp = tempfile::TempDir::with_prefix("ratecard-test").unwrap();
        write_ratecard(&tmp, "# header\n\ndomestic\t500\t599\n\n# trailing\n");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
    }

      #[serial_test::serial]
      #[test]
    fn nonexistent_file_path() {
        env::set_var("RATECARD_PATH", "/does/not/exist.tsv");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }
}
