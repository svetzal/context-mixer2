pub mod zones;

use std::collections::BTreeMap;
use std::env;
use std::fmt;
use std::fs;

/// A parcel to be shipped.
#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A calculated shipping quote.
#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Errors that can occur when calculating a quote.
#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card on line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {}g exceeds zone limit of {}g", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Clone)]
struct RateBand {
    band_max_grams: u32,
    cents: u64,
}

/// Load and parse the rate card file.
fn load_rate_card() -> Result<BTreeMap<String, Vec<RateBand>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut map: BTreeMap<String, Vec<RateBand>> = BTreeMap::new();

    for (idx, raw_line) in contents.lines().enumerate() {
        let line_num = idx + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = trimmed.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].trim().to_string();
        let band_max_grams: u32 = parts[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        map.entry(zone)
            .or_insert_with(Vec::new)
            .push(RateBand { band_max_grams, cents });
    }

    Ok(map)
}

/// Calculate a shipping quote for a parcel.
///
/// # Example
///
/// ```
/// use ratecard::{Parcel, quote};
/// // Given a rate card file on disk referenced by RATECARD_PATH:
/// let parcel = Parcel { weight_grams: 300, zone: "domestic".to_string() };
/// let result = quote(&parcel);
/// ```
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;

    let zones = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let mut sorted = zones.clone();
    sorted.sort_by_key(|b| b.band_max_grams);

    let matched = sorted
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams);

    if matched.is_none() {
        let max_limit = sorted.last().map(|b| b.band_max_grams).unwrap_or(0);
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: max_limit,
        });
    }

    let band = matched.unwrap();
    let base_cents = band.cents;
    let band_max_grams = band.band_max_grams;

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let surcharge_20pct = (base_cents as f64) * 0.2;
        surcharge_cents += (surcharge_20pct + 0.5) as u64;
    }

    let total_cents = base_cents + surcharge_cents;

    tracing::info!(
        zone = &parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn write_rate_card(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().expect("create temp file");
        file.write_all(content.as_bytes()).expect("write rate card");
        file
    }

    fn set_ratecard_path<P: AsRef<std::path::Path>>(file: &P) {
        env::set_var("RATECARD_PATH", file.as_ref().to_string_lossy().to_string());
    }

    #[test]
    fn domestic_basic_quote() {
        let file = write_rate_card(
            "# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799",
        );
        set_ratecard_path(&file);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let quote_result = quote(&parcel).expect("quote should succeed");

        assert_eq!(quote_result.base_cents, 599);
        assert_eq!(quote_result.surcharge_cents, 0);
        assert_eq!(quote_result.total_cents, 599);
        assert_eq!(quote_result.band_max_grams, 500);
    }

    #[test]
    fn domestic_heavier_parcel() {
        let file = write_rate_card(
            "domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799",
        );
        set_ratecard_path(&file);

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };
        let quote_result = quote(&parcel).expect("quote should succeed");

        assert_eq!(quote_result.base_cents, 899);
        assert_eq!(quote_result.surcharge_cents, 0);
        assert_eq!(quote_result.total_cents, 899);
        assert_eq!(quote_result.band_max_grams, 2000);
    }

    #[test]
    fn international_quote_with_surcharge() {
        let file = write_rate_card(
            "international\t500\t1499
international\t20000\t4999",
        );
        set_ratecard_path(&file);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };
        let quote_result = quote(&parcel).expect("quote should succeed");

        assert_eq!(quote_result.base_cents, 1499);
        assert_eq!(quote_result.surcharge_cents, 300);
        assert_eq!(quote_result.total_cents, 1799);
        assert_eq!(quote_result.band_max_grams, 500);
    }

    #[test]
    fn weight_surcharge_above_10kg() {
        let file = write_rate_card(
            "domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799",
        );
        set_ratecard_path(&file);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let quote_result = quote(&parcel).expect("quote should succeed");

        assert_eq!(quote_result.base_cents, 1799);
        assert_eq!(quote_result.surcharge_cents, 500);
        assert_eq!(quote_result.total_cents, 2299);
        assert_eq!(quote_result.band_max_grams, 20000);
    }

    #[test]
    fn both_surcharges_international_heavy() {
        let file = write_rate_card(
            "international\t500\t1499
international\t20000\t4999",
        );
        set_ratecard_path(&file);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let quote_result = quote(&parcel).expect("quote should succeed");

        assert_eq!(quote_result.base_cents, 4999);
        let expected_intl_surcharge = ((4999.0_f64) * 0.2 + 0.5) as u64;
        assert_eq!(quote_result.surcharge_cents, expected_intl_surcharge + 500);
        assert_eq!(
            quote_result.total_cents,
            quote_result.base_cents + quote_result.surcharge_cents
        );
        assert_eq!(quote_result.band_max_grams, 20000);
    }

    #[test]
    fn unknown_zone() {
        let file = write_rate_card("domestic\t500\t599");
        set_ratecard_path(&file);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "express".to_string(),
        };
        let err = quote(&parcel).expect_err("should be unknown zone error");

        match err {
            QuoteError::UnknownZone(z) => assert_eq!(z, "express"),
            other => panic!("expected UnknownZone, got {:?}", other),
        }
    }

    #[test]
    fn overweight() {
        let file = write_rate_card("domestic\t500\t599\ndomestic\t2000\t899");
        set_ratecard_path(&file);

        let parcel = Parcel {
            weight_grams: 5000,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).expect_err("should be overweight error");

        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 5000);
                assert_eq!(limit, 2000);
            }
            other => panic!("expected Overweight, got {:?}", other),
        }
    }

    #[test]
    fn missing_ratecard_path() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).expect_err("should fail when path is unset");

        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn malformed_ratecard_wrong_fields() {
        let file = write_rate_card(
            "# zone\tband_max_grams\tcents
domestic\t599
domestic\t500\t599",
        );
        set_ratecard_path(&file);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).expect_err("malformed line should error");

        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 2),
            other => panic!("expected MalformedRateCard, got {:?}", other),
        }
    }

    #[test]
    fn malformed_ratecard_bad_number() {
        let file = write_rate_card(
            "domestic\tabc\t599",
        );
        set_ratecard_path(&file);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).expect_err("bad number should error");

        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            other => panic!("expected MalformedRateCard, got {:?}", other),
        }
    }

    #[test]
    fn display_error_messages() {
        assert_eq!(
            format!("{}", QuoteError::RateCardUnavailable),
            "rate card is unavailable"
        );
        assert_eq!(
            format!("{}", QuoteError::MalformedRateCard { line: 3 }),
            "malformed rate card on line 3"
        );
        assert_eq!(
            format!("{}", QuoteError::UnknownZone("express".to_string())),
            "unknown zone: express"
        );
        assert_eq!(
            format!(
                "{}",
                QuoteError::Overweight {
                    grams: 5000,
                    limit: 2000
                }
            ),
            "parcel 5000g exceeds zone limit of 2000g"
        );
    }

    #[test]
    fn rounding_half_up() {
        let file = write_rate_card("international\t500\t1001");
        set_ratecard_path(&file);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        };
        let quote_result = quote(&parcel).expect("quote should succeed");

        assert_eq!(quote_result.base_cents, 1001);
        assert_eq!(quote_result.surcharge_cents, 200);
        assert_eq!(quote_result.total_cents, 1201);
    }

    #[test]
    fn exact_weight_on_band_boundary() {
        let file = write_rate_card("domestic\t500\t599\ndomestic\t2000\t899");
        set_ratecard_path(&file);

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let quote_result = quote(&parcel).expect("quote should succeed");

        assert_eq!(quote_result.base_cents, 599);
        assert_eq!(quote_result.band_max_grams, 500);
    }

    #[test]
    fn error_is_std_error() {
        let err: Box<dyn std::error::Error> =
            Box::new(QuoteError::RateCardUnavailable);
        assert!(!err.to_string().is_empty());
    }

    #[test]
    fn comments_and_blank_lines_skipped() {
        let file = write_rate_card(
            "# This is a comment

domestic\t500\t599

# Another comment
domestic\t2000\t899
",
        );
        set_ratecard_path(&file);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let quote_result = quote(&parcel).expect("quote should succeed");

        assert_eq!(quote_result.base_cents, 599);
    }

    #[test]
    fn file_not_found_returns_unavailable() {
        env::set_var("RATECARD_PATH", "/nonexistent/path/to/ratecard.tsv");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).expect_err("should fail when file is missing");

        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }
}
