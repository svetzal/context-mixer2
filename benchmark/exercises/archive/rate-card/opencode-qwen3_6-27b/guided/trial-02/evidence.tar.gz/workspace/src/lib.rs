use std::collections::HashMap;
use std::env;
use std::fmt;
use std::fs;

pub mod zones;

/// A shipping parcel with weight and destination zone.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A computed shipping quote broken down by components.
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Errors that can occur during quote calculation.
#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {}g exceeds zone limit of {}g", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

fn load_ratecard() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut map: HashMap<String, Vec<Band>> = HashMap::new();

    for (idx, raw_line) in contents.lines().enumerate() {
        let line_num = idx + 1;
        let line = raw_line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].trim().to_string();
        let max_grams: u32 = parts[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        map.entry(zone)
            .or_insert_with(Vec::new)
            .push(Band { max_grams, cents });
    }

    for bands in map.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(map)
}

/// Calculate a shipping quote for the given parcel.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let ratecard = load_ratecard()?;

    let bands = ratecard
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let matching_band = bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams);

    let (base_cents, band_max_grams) = match matching_band {
        Some(b) => (b.cents, b.max_grams),
        None => {
            let limit = bands.last().unwrap().max_grams;
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let surcharge = (base_cents as f64 * 0.2).round() as u64;
        surcharge_cents += surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn make_ratecard_content() -> &'static str {
        "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
"
    }

    fn setup_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        file
    }

    #[test]
    fn test_domestic_small_parcel() {
        let file = setup_ratecard(make_ratecard_content());
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_medium_parcel() {
        let file = setup_ratecard(make_ratecard_content());
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_domestic_heavy_with_weight_surcharge() {
        let file = setup_ratecard(make_ratecard_content());
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_international_small_parcel() {
        let file = setup_ratecard(make_ratecard_content());
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_international_heavy_with_both_surcharges() {
        let file = setup_ratecard(make_ratecard_content());
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 500 + 1000);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_unknown_zone() {
        let file = setup_ratecard(make_ratecard_content());
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "europe".to_string(),
        };
        let result = quote(&parcel);

        assert!(matches!(result, Err(QuoteError::UnknownZone(ref z)) if z == "europe"));
    }

    #[test]
    fn test_overweight() {
        let file = setup_ratecard(make_ratecard_content());
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 30000,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);

        assert!(matches!(result, Err(QuoteError::Overweight { grams: 30000, limit: 20000 })));
    }

    #[test]
    fn test_ratecard_unavailable_no_env() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_ratecard_unavailable_missing_file() {
        env::set_var("RATECARD_PATH", "/nonexistent/path");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_malformed_ratecard_bad_fields() {
        let file = setup_ratecard("zone\tmax\ncol1\tcol2");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);

        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 1 })));
    }

    #[test]
    fn test_malformed_ratecard_bad_number() {
        let file = setup_ratecard("zone\t500\nabc");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);

        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 2 })));
    }

    #[test]
    fn test_error_display() {
        assert_eq!(
            format!("{}", QuoteError::RateCardUnavailable),
            "rate card unavailable"
        );
        assert_eq!(
            format!("{}", QuoteError::MalformedRateCard { line: 5 }),
            "malformed rate card at line 5"
        );
        assert_eq!(
            format!("{}", QuoteError::UnknownZone("europe".to_string())),
            "unknown zone: europe"
        );
        assert_eq!(
            format!(
                "{}",
                QuoteError::Overweight {
                    grams: 30000,
                    limit: 20000
                }
            ),
            "parcel 30000g exceeds zone limit of 20000g"
        );
    }

    #[test]
    fn test_exact_boundary_weight_matches_band() {
        let file = setup_ratecard(make_ratecard_content());
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_weight_exactly_10000_no_surcharge() {
        let file = setup_ratecard(make_ratecard_content());
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 10000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn test_weight_10001_gets_surcharge() {
        let file = setup_ratecard(make_ratecard_content());
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 10001,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.surcharge_cents, 500);
    }

    #[test]
    fn test_international_surcharge_rounding() {
        let file = setup_ratecard("domestic\t500\t599\ninternational\t500\t1499");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.surcharge_cents, 300);
    }

    #[test]
    fn test_comments_and_blanks_ignored() {
        let content = "# header comment

# another comment
domestic\t500\t599

domestic\t2000\t899
";
        let file = setup_ratecard(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 599);
    }

    #[test]
    fn test_error_implements_error_trait() {
        let err: Box<dyn std::error::Error> = Box::new(QuoteError::RateCardUnavailable);
        drop(err);
    }
}
