pub mod zones;

use std::collections::BTreeMap;
use std::env;
use std::fmt;
use std::fs;

#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {}", zone)
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {}g exceeds {}g limit", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

fn parse_rate_card() -> Result<BTreeMap<String, Vec<Band>>, QuoteError> {
    let path =
        env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents =
        fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut map: BTreeMap<String, Vec<Band>> = BTreeMap::new();

    for (idx, raw_line) in contents.lines().enumerate() {
        let line_num = idx + 1;
        let line = raw_line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let zone = parts[0].trim().to_string();
        let max_grams: u32 = parts[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        map.entry(zone).or_insert_with(Vec::new).push(Band {
            max_grams,
            cents,
        });
    }

    for bands in map.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(map)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = parse_rate_card()?;

    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    if bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let limit = bands.last().unwrap().max_grams;
    if parcel.weight_grams > limit {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        });
    }

    let matching_band = bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .unwrap();

    let base_cents = matching_band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let twofold = base_cents * 2;
        surcharge_cents += twofold / 10;
        if (twofold % 10) >= 5 {
            surcharge_cents += 1;
         }
     }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "DIAG: zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: matching_band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    fn guard() -> std::sync::MutexGuard<'static, ()> {
        static MX: Mutex<()> = Mutex::new(());
        MX.lock().unwrap()
    }

    fn create_temp_rate_card(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        file
    }

    #[test]
    fn test_basic_domestic_quote() {
        let _g = guard();
        let file = create_temp_rate_card(
            "# zone\tband_max_grams\tcents\n\
            domestic\t500\t599\n\
            domestic\t2000\t899\n\
            domestic\t20000\t1799",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel).unwrap();

        assert_eq!(result.base_cents, 599);
        assert_eq!(result.surcharge_cents, 0);
        assert_eq!(result.total_cents, 599);
        assert_eq!(result.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_no_surcharge_under_limits() {
        let _g = guard();
        let file = create_temp_rate_card(
            "domestic\t500\t599\n\
            domestic\t2000\t899\n\
            domestic\t20000\t1799",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel).unwrap();

        assert_eq!(result.base_cents, 899);
        assert_eq!(result.surcharge_cents, 0);
        assert_eq!(result.total_cents, 899);
        assert_eq!(result.band_max_grams, 2000);
    }

    #[test]
    fn test_weight_surcharge_above_10kg() {
        let _g = guard();
        let file = create_temp_rate_card(
            "domestic\t20000\t1799",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel).unwrap();

        assert_eq!(result.base_cents, 1799);
        assert_eq!(result.surcharge_cents, 500);
        assert_eq!(result.total_cents, 2299);
        assert_eq!(result.band_max_grams, 20000);
    }

    #[test]
    fn test_international_surcharge_20_percent() {
        let _g = guard();
        let file = create_temp_rate_card(
            "international\t500\t1499\n\
            international\t20000\t4999",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };
        let result = quote(&parcel).unwrap();

        assert_eq!(result.base_cents, 1499);
        assert_eq!(result.surcharge_cents, 300);
        assert_eq!(result.total_cents, 1799);
        assert_eq!(result.band_max_grams, 500);
    }

    #[test]
    fn test_international_with_weight_surcharge() {
        let _g = guard();
        let file = create_temp_rate_card(
            "international\t20000\t4999",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let result = quote(&parcel).unwrap();

        assert_eq!(result.base_cents, 4999);
        assert_eq!(result.surcharge_cents, 500 + 1000);
        assert_eq!(result.total_cents, 6499);
    }

    #[test]
    fn test_unknown_zone() {
        let _g = guard();
        let file = create_temp_rate_card(
            "domestic\t500\t599",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "express".to_string(),
        };
        let result = quote(&parcel);

        match result {
            Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "express"),
            _ => panic!("expected UnknownZone"),
        }
    }

    #[test]
    fn test_overweight() {
        let _g = guard();
        let file = create_temp_rate_card(
            "domestic\t500\t599",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 600,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);

        match result {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 600);
                assert_eq!(limit, 500);
            }
            _ => panic!("expected Overweight"),
        }
    }

    #[test]
    fn test_rate_card_unavailable_no_env() {
        let _g = guard();
        env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => {}
            _ => panic!("expected RateCardUnavailable"),
        }
    }

    #[test]
    fn test_rate_card_unavailable_missing_file() {
        let _g = guard();
        env::set_var("RATECARD_PATH", "/nonexistent/path/to/ratecard.txt");

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => {}
            _ => panic!("expected RateCardUnavailable"),
        }
    }

    #[test]
    fn test_malformed_rate_card_bad_fields() {
        let _g = guard();
        let file = create_temp_rate_card(
            "domestic\t500\n\
            domestic\t2000\t899",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            _ => panic!("expected MalformedRateCard"),
        }
    }

    #[test]
    fn test_malformed_rate_card_bad_number() {
        let _g = guard();
        let file = create_temp_rate_card(
            "domestic\t500\tabc",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            _ => panic!("expected MalformedRateCard"),
        }
    }

    #[test]
    fn test_empty_lines_and_comments_ignored() {
        let _g = guard();
        let file = create_temp_rate_card(
            "\n\
            # this is a comment\n\
            \n\
            domestic\t500\t599\n\
            \n",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 599);
    }

    #[test]
    fn test_display_quotes_error() {
        let err = QuoteError::UnknownZone("test_zone".to_string());
        assert!(format!("{}", err).contains("test_zone"));

        let err = QuoteError::Overweight { grams: 600, limit: 500 };
        assert!(format!("{}", err).contains("overweight"));
    }

    #[test]
    fn test_international_20_percent_rounding() {
        let _g = guard();
        let file = create_temp_rate_card(
            "international\t500\t1001",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };
        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 1001);
        assert_eq!(result.surcharge_cents, 200);
        assert_eq!(result.total_cents, 1201);
    }

    #[test]
    fn test_exactly_10kg_no_weight_surcharge() {
        let _g = guard();
        let file = create_temp_rate_card(
            "domestic\t10000\t1500",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 10000,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel).unwrap();
        assert_eq!(result.surcharge_cents, 0);
    }

    #[test]
    fn test_10kg_plus_1_has_weight_surcharge() {
        let _g = guard();
        let file = create_temp_rate_card(
            "domestic\t10001\t1500",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 10001,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel).unwrap();
        assert_eq!(result.surcharge_cents, 500);
    }

    #[test]
    fn test_malformed_line_number_includes_comments() {
        let _g = guard();
        let file = create_temp_rate_card(
            "# comment\n\
            \n\
            domestic\t500\tabc",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
            other => panic!("expected MalformedRateCard line 3, got {:?}", other),
        }
    }
}
