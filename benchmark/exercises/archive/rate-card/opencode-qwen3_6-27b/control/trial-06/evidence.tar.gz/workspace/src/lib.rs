pub mod zones;

use std::collections::BTreeMap;
use std::env;
use std::fmt;
use std::fs;
use std::error::Error;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => write!(f, "overweight: {} grams exceeds limit of {} grams", grams, limit),
        }
    }
}

impl fmt::Debug for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self, f)
    }
}

impl Error for QuoteError {}

struct RateCard {
    bands: BTreeMap<String, Vec<Band>>,
}

struct Band {
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands: BTreeMap<String, Vec<Band>> = BTreeMap::new();

    for (idx, raw_line) in content.lines().enumerate() {
        let line_num = idx + 1;
        let line = raw_line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let zone = parts[0].trim().to_string();
        let band_max_grams: u32 = parts[1].trim().parse().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2].trim().parse().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        bands.entry(zone).or_insert_with(Vec::new).push(Band {
            band_max_grams,
            cents,
        });
    }

    for band_list in bands.values_mut() {
        band_list.sort_by_key(|b| b.band_max_grams);
    }

    Ok(RateCard { bands })
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rc = load_rate_card()?;

    let band_list = rc.bands.get(&parcel.zone).ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let matching = band_list.iter().find(|b| b.band_max_grams >= parcel.weight_grams);

    let (base_cents, band_max_grams) = match matching {
        Some(b) => (b.cents, b.band_max_grams),
        None => {
            let limit = band_list.last().unwrap().band_max_grams;
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let percent_20 = base_cents as f64 * 0.2;
        surcharge_cents += (percent_20 + 0.5) as u64;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!("DIAGNOSTIC: zone={} weight_grams={} total_cents={}", parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    fn setup_ratecard(content: &str) -> tempfile::NamedTempFile {
        let mut file = tempfile::NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        file
    }

    #[test]
    fn test_basic_domestic_quote() {
        let rc = setup_ratecard("# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n");
        env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_weight_above_10kg() {
        let rc = setup_ratecard("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n");
        env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_international_surcharge() {
        let rc = setup_ratecard("international\t500\t1499\ninternational\t20000\t4999\n");
        env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_international_with_both_surcharges() {
        let rc = setup_ratecard("international\t500\t1499\ninternational\t20000\t4999\n");
        env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel {
            weight_grams: 12000,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 4999);
        let expected_surcharge = 500 + ((4999.0 * 0.2 + 0.5) as u64);
        assert_eq!(quote.surcharge_cents, expected_surcharge);
        assert_eq!(quote.total_cents, 4999 + expected_surcharge);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_unknown_zone() {
        let rc = setup_ratecard("domestic\t500\t599\n");
        env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "express".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::UnknownZone(z)) if z == "express"));
    }

    #[test]
    fn test_overweight() {
        let rc = setup_ratecard("domestic\t500\t599\ndomestic\t2000\t899\n");
        env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel {
            weight_grams: 5000,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::Overweight { limit, .. }) if limit == 2000));
    }

    #[test]
    fn test_missing_ratecard_path() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_nonexistent_file() {
        env::set_var("RATECARD_PATH", "/nonexistent/path/ratecard.txt");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_malformed_line() {
        let rc = setup_ratecard("domestic\t500\t599\nbad_line_no_tabs\n");
        env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line }) if line == 2));
    }

    #[test]
    fn test_malformed_non_numeric() {
        let rc = setup_ratecard("domestic\t500\tnot_a_number\n");
        env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line }) if line == 1));
    }

    #[test]
    fn test_exact_weight_boundary() {
        let rc = setup_ratecard("domestic\t500\t599\ndomestic\t2000\t899\n");
        env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_rounding_half_up() {
        let rc = setup_ratecard("international\t500\t1005\n");
        env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel {
            weight_grams: 200,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1005);
        assert_eq!(quote.surcharge_cents, 201);
    }

    #[test]
    fn test_comments_and_blanks_ignored() {
        let rc = setup_ratecard("# header\n\ndomestic\t500\t599\n# another comment\n\ninternational\t500\t1499\n");
        env::set_var("RATECARD_PATH", rc.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
    }

    #[test]
    fn test_error_display() {
        assert_eq!(format!("{}", QuoteError::RateCardUnavailable), "rate card unavailable");
        assert_eq!(format!("{}", QuoteError::MalformedRateCard { line: 5 }), "malformed rate card at line 5");
        assert_eq!(format!("{}", QuoteError::UnknownZone("express".to_string())), "unknown zone: express");
        assert_eq!(format!("{}", QuoteError::Overweight { grams: 5000, limit: 2000 }), "overweight: 5000 grams exceeds limit of 2000 grams");
    }
}
