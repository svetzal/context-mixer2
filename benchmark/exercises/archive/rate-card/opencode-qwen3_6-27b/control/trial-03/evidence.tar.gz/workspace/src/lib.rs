use std::collections::HashMap;
use std::env;
use std::fmt;
use std::fs;

pub mod zones;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {}g exceeds limit {}g", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

fn load_ratecard() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path =
        env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content =
        fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut map: HashMap<String, Vec<Band>> = HashMap::new();

    let mut line_num: usize = 0;
    for raw_line in content.lines() {
        line_num += 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = raw_line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].trim().to_string();
        let max_grams: u32 = parts[1].trim().parse().map_err(|_| {
            QuoteError::MalformedRateCard { line: line_num }
        })?;
        let cents: u64 = parts[2].trim().parse().map_err(|_| {
            QuoteError::MalformedRateCard { line: line_num }
        })?;

        map
            .entry(zone)
            .or_insert_with(Vec::new)
            .push(Band { max_grams, cents });
    }

    for bands in map.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(map)
}

fn round_half_up(value: f64) -> u64 {
    (value + 0.5) as u64
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let ratecard = load_ratecard()?;

    let bands = ratecard
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    if bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let weight = parcel.weight_grams;

    let matching_band = bands.iter().find(|b| b.max_grams >= weight);

    let (base_cents, band_max_grams) = match matching_band {
        Some(b) => (b.cents, b.max_grams),
        None => {
            let limit = bands.last().unwrap().max_grams;
            return Err(QuoteError::Overweight {
                grams: weight,
                limit,
            });
        }
    };

    let mut surcharge_cents: u64 = 0;

    if weight > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        surcharge_cents += round_half_up(base_cents as f64 * 0.2);
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "DIAGNOSTIC: zone={} weight_grams={} total_cents={}",
        parcel.zone, weight, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    fn write_temp_ratecard(content: &str) -> tempfile::NamedTempFile {
        let mut file = tempfile::NamedTempFile::new().unwrap();
        writeln!(file, "{}", content).unwrap();
        file.flush().unwrap();
        file
    }

    fn set_ratecard(path: &str) {
        env::set_var("RATECARD_PATH", path);
    }

    fn default_ratecard() -> tempfile::NamedTempFile {
        write_temp_ratecard(
            "# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999",
        )
    }

    #[test]
    fn test_domestic_light() {
        let file = default_ratecard();
        set_ratecard(file.path().to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_heavy() {
        let file = default_ratecard();
        set_ratecard(file.path().to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_domestic_mid_weight() {
        let file = default_ratecard();
        set_ratecard(file.path().to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_international_surcharge() {
        let file = default_ratecard();
        set_ratecard(file.path().to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 400,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_international_heavy() {
        let file = default_ratecard();
        set_ratecard(file.path().to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 500 + 1000);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_unknown_zone() {
        let file = default_ratecard();
        set_ratecard(file.path().to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "orbital".to_string(),
        };
        let result = quote(&parcel);

        match result {
            Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "orbital"),
            _ => panic!("expected UnknownZone"),
        }
    }

    #[test]
    fn test_overweight() {
        let file = default_ratecard();
        set_ratecard(file.path().to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 50000,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);

        assert!(matches!(
            result,
            Err(QuoteError::Overweight {
                grams: 50000,
                limit: 20000
            })
        ));
    }

    #[test]
    fn test_missing_ratecard_path() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_unreadable_ratecard_path() {
        set_ratecard("/nonexistent/path/file.txt");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_malformed_line() {
        let file = write_temp_ratecard(
            "domestic\t500\t599
bad line with no tabs
domestic\t2000\t899",
        );
        set_ratecard(file.path().to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(
            result,
            Err(QuoteError::MalformedRateCard { line: 2 })
        ));
    }

    #[test]
    fn test_malformed_bad_number() {
        let file = write_temp_ratecard(
            "domestic\t500\tnot_a_number",
        );
        set_ratecard(file.path().to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(
            result,
            Err(QuoteError::MalformedRateCard { line: 1 })
        ));
    }

    #[test]
    fn test_weight_exactly_on_boundary() {
        let file = default_ratecard();
        set_ratecard(file.path().to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_weight_exactly_10000_no_surcharge() {
        let file = default_ratecard();
        set_ratecard(file.path().to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 10000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn test_weight_10001_has_surcharge() {
        let file = default_ratecard();
        set_ratecard(file.path().to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 10001,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.surcharge_cents, 500);
    }

    #[test]
    fn test_rounding_half_up() {
        let file = write_temp_ratecard(
            "testzone\t1000\t1999",
        );
        set_ratecard(file.path().to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 500,
            zone: "international".to_string(),
        };
        let result = quote(&parcel);
        assert!(result.is_err());

        let parcel = Parcel {
            weight_grams: 500,
            zone: "testzone".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1999);
        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn test_display_errors() {
        let e = QuoteError::RateCardUnavailable;
        assert_eq!(format!("{}", e), "rate card unavailable");

        let e = QuoteError::MalformedRateCard { line: 5 };
        assert_eq!(format!("{}", e), "malformed rate card at line 5");

        let e = QuoteError::UnknownZone("mars".to_string());
        assert_eq!(format!("{}", e), "unknown zone: mars");

        let e = QuoteError::Overweight {
            grams: 300,
            limit: 200,
        };
        assert_eq!(format!("{}", e), "overweight: 300g exceeds limit 200g");
    }

    #[test]
    fn test_comments_and_blanks_ignored() {
        let file = write_temp_ratecard(
            "# This is a comment

domestic\t500\t599
# Another comment

domestic\t2000\t899",
        );
        set_ratecard(file.path().to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
    }

    #[test]
    fn test_malformed_counts_all_lines() {
        let file = write_temp_ratecard(
            "# header comment

# second comment
domestic\t500\t599
bad",
        );
        set_ratecard(file.path().to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(
            result,
            Err(QuoteError::MalformedRateCard { line: 5 })
        ));
    }
}
