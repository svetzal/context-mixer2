pub mod zones;

use std::collections::BTreeMap;
use std::env;
use std::fmt;
use std::fs;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {}g exceeds limit of {}g", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Clone)]
struct RateBand {
    max_grams: u32,
    cents: u64,
}

fn parse_rate_card() -> Result<BTreeMap<String, Vec<RateBand>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut map: BTreeMap<String, Vec<RateBand>> = BTreeMap::new();
    for (idx, raw) in content.lines().enumerate() {
        let line_num = idx + 1;
        let trimmed = raw.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = raw.split('\t').collect();
        if parts.len() < 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let zone = parts[0].trim().to_string();
        let max_grams: u32 = parts[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        map
            .entry(zone)
            .or_default()
            .push(RateBand { max_grams, cents });
    }
    Ok(map)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = parse_rate_card()?;

    let zone_bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let mut sorted = zone_bands.clone();
    sorted.sort_by_key(|b| b.max_grams);

    let matching = sorted.iter().find(|b| b.max_grams >= parcel.weight_grams);

    let max_limit = sorted.last().map(|b| b.max_grams).unwrap_or(0);

    let band = match matching {
        Some(b) => b,
        None => {
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: max_limit,
            })
        }
    };

    let base_cents = band.cents;
    let band_max = band.max_grams;

    let mut surcharge: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge += 500;
    }

    if parcel.zone == "international" {
        surcharge += (base_cents * 20 + 50) / 100;
    }

    let total = base_cents + surcharge;

    eprintln!(
        "{{\"zone\":\"{}\",\"weight_grams\":{},\"total_cents\":{}}}",
        parcel.zone, parcel.weight_grams, total
    );

    Ok(Quote {
        base_cents,
        surcharge_cents: surcharge,
        total_cents: total,
        band_max_grams: band_max,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    fn setup_rate_card(content: &str) -> tempfile::NamedTempFile {
        let mut file = tempfile::NamedTempFile::new().unwrap();
        writeln!(file, "{}", content).unwrap();
        file.flush().unwrap();
        file
    }

    #[test]
    fn test_basic_domestic_quote() {
        let file = setup_rate_card(
            "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_next_band() {
        let file = setup_rate_card(
            "domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_weight_surcharge() {
        let file = setup_rate_card(
            "domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_international_surcharge() {
        let file = setup_rate_card(
            "international\t500\t1499\ninternational\t20000\t4999",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1499);
        // 20% of 1499 = 299.8 -> 300 (half-up)
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn test_international_with_weight_surcharge() {
        let file = setup_rate_card(
            "international\t500\t1499\ninternational\t20000\t4999",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 4999);
        // 20% of 4999 = 999.8 -> 1000 (half-up) + 500 weight surcharge = 1500
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn test_unknown_zone() {
        let file = setup_rate_card("domestic\t500\t599");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "express".to_string(),
        };
        let result = quote(&parcel);
        assert!(
            matches!(result, Err(QuoteError::UnknownZone(z)) if z == "express")
        );
    }

    #[test]
    fn test_overweight() {
        let file = setup_rate_card("domestic\t500\t599");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 600,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(
            matches!(result, Err(QuoteError::Overweight { grams: 600, limit: 500 }))
        );
    }

    #[test]
    fn test_missing_ratecard_path() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_malformed_rate_card() {
        let file = setup_rate_card("domestic\t500\t599\nbad line without tabs");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 2 })));
    }

    #[test]
    fn test_exactly_at_boundary() {
        let file = setup_rate_card("domestic\t500\t599\ndomestic\t2000\t899");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_exactly_10000_no_weight_surcharge() {
        let file = setup_rate_card(
            "domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 10000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn test_international_rounding_half_up() {
        let file = setup_rate_card("international\t500\t1000");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1000);
        // 20% of 1000 = 200 exactly
        assert_eq!(quote.surcharge_cents, 200);
    }

    #[test]
    fn test_comments_and_blanks_ignored() {
        let file = setup_rate_card(
            "# header\ndomestic\t500\t599\n\n# another comment\ndomestic\t2000\t899",
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
    }

    #[test]
    fn test_error_display() {
        let e = QuoteError::UnknownZone("test".to_string());
        assert!(!format!("{}", e).is_empty());

        let e = QuoteError::Overweight { grams: 600, limit: 500 };
        assert!(!format!("{}", e).is_empty());

        let e = QuoteError::MalformedRateCard { line: 5 };
        assert!(!format!("{}", e).is_empty());

        let e = QuoteError::RateCardUnavailable;
        assert!(!format!("{}", e).is_empty());
    }
}
