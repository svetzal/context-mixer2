use std::collections::BTreeMap;
use std::env;
use std::fmt;
use std::fs;

pub mod zones;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {} grams exceeds limit of {} grams", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Clone)]
struct Band {
    max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands_by_zone: BTreeMap<String, Vec<Band>> = BTreeMap::new();

    for (idx, raw_line) in content.lines().enumerate() {
        let line_num = idx + 1;
        let line = raw_line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let zone = parts[0].trim().to_string();
        let max_grams: u32 = parts[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        bands_by_zone
            .entry(zone)
            .or_insert_with(Vec::new)
            .push(Band {
                max_grams,
                cents,
            });
    }

    let zone_bands = bands_by_zone
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let sorted = {
        let mut b: Vec<Band> = zone_bands.clone();
        b.sort_by_key(|x| x.max_grams);
        b
     };

    let matching = sorted
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams);

    let (base_cents, band_max_grams) = match matching {
        Some(b) => (b.cents, b.max_grams),
        None => {
            let limit = sorted.last().unwrap().max_grams;
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let surcharge = ((base_cents as f64) * 0.20 + 0.5) as u64;
        surcharge_cents += surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "DIAGNOSTIC zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn create_ratecard_template() -> &'static str {
        "\
# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999"
    }

    fn setup_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        file
    }

    #[test]
    fn test_domestic_basic() {
        let file = setup_ratecard(create_ratecard_template());
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_heavier() {
        let file = setup_ratecard(create_ratecard_template());
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_domestic_over_10kg_surcharge() {
        let file = setup_ratecard(create_ratecard_template());
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_international_base_and_surcharge() {
        let file = setup_ratecard(create_ratecard_template());
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 400,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_international_over_10kg() {
        let file = setup_ratecard(create_ratecard_template());
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_unknown_zone() {
        let file = setup_ratecard(create_ratecard_template());
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "europe".to_string(),
        };
        let result = quote(&parcel);

        assert!(matches!(result, Err(QuoteError::UnknownZone(ref z)) if z == "europe"));
    }

    #[test]
    fn test_overweight() {
        let file = setup_ratecard(create_ratecard_template());
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 30000,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);

        assert!(
            matches!(result, Err(QuoteError::Overweight { grams: 30000, limit: 20000 }))
        );
    }

    #[test]
    fn test_missing_ratecard_path() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);

        assert!(matches!(
            result,
            Err(QuoteError::RateCardUnavailable)
        ));
    }

    #[test]
    fn test_malformed_ratecard() {
        let file = setup_ratecard("domestic\t500");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);

        assert!(matches!(
            result,
            Err(QuoteError::MalformedRateCard { line: 1 })
        ));
    }

    #[test]
    fn test_boundary_exact_10kg_no_surcharge() {
        let file = setup_ratecard(create_ratecard_template());
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 10000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn test_boundary_just_over_10kg_has_surcharge() {
        let file = setup_ratecard(create_ratecard_template());
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 10001,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.surcharge_cents, 500);
    }

    #[test]
    fn test_rounding_half_up() {
        let content = "international\t500\t1005";
        let file = setup_ratecard(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 1005);
        assert_eq!(quote.surcharge_cents, 201);
        assert_eq!(quote.total_cents, 1206);
    }

    #[test]
    fn test_display_errors() {
        let e1 = QuoteError::RateCardUnavailable;
        assert_eq!(format!("{}", e1), "rate card unavailable");

        let e2 = QuoteError::MalformedRateCard { line: 5 };
        assert_eq!(format!("{}", e2), "malformed rate card at line 5");

        let e3 = QuoteError::UnknownZone("asia".to_string());
        assert_eq!(format!("{}", e3), "unknown zone: asia");

        let e4 = QuoteError::Overweight {
            grams: 5000,
            limit: 2000,
        };
        assert_eq!(
            format!("{}", e4),
            "overweight: 5000 grams exceeds limit of 2000 grams"
        );
    }

     #[test]
    fn test_comments_and_blank_lines_skipped() {
        let content = "\
# header\n\
# zone\tmax\tprice\n\
\n\
skip\t100\t500\n\
# another comment\n\
domestic\t500\t599";
        let file = setup_ratecard(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 400,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
     }
}
