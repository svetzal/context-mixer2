use std::fmt;
use std::fs;
use std::io::{BufRead, BufReader};
use std::sync::Mutex;
use std::env;

pub mod zones;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {}", zone)
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel overweight: {}g exceeds limit of {}g", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

static QUOTE_LOCK: Mutex<()> = Mutex::new(());

struct RateBand {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<Vec<RateBand>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let file = fs::File::open(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);

    let mut bands = Vec::new();
    for (idx, line_result) in reader.lines().enumerate() {
        let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
        let line_num = idx + 1;

        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = trimmed.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].trim().to_string();
        let band_max_grams: u32 = parts[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        bands.push(RateBand {
            zone,
            band_max_grams,
            cents,
        });
    }

    Ok(bands)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let _guard = QUOTE_LOCK.lock().unwrap();
    quote_internal(parcel)
}

pub(crate) fn quote_internal(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_rate_card()?;

    let zone_bands: Vec<&RateBand> = bands
        .iter()
        .filter(|b| b.zone == parcel.zone)
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let mut sorted_bands = zone_bands;
    sorted_bands.sort_by_key(|b| b.band_max_grams);

    let max_limit = sorted_bands.last().unwrap().band_max_grams;

    let matched = sorted_bands.iter().find(|b| b.band_max_grams >= parcel.weight_grams);

    let band = match matched {
        Some(b) => b,
        None => {
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: max_limit,
            });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let surcharge = (base_cents * 20 + 50) / 100;
        surcharge_cents += surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "DIAG: zone={} weight={}g total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    fn setup_rate_card(content: &str) -> tempfile::NamedTempFile {
        let mut file = tempfile::NamedTempFile::new().unwrap();
        write!(file, "{}", content).unwrap();
        file
    }

    fn with_ratecard(content: &str, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let file = setup_rate_card(content);
        let _guard = crate::QUOTE_LOCK.lock().unwrap();
        env::set_var("RATECARD_PATH", file.path().to_str().unwrap());
        crate::quote_internal(parcel)
    }

    #[test]
    fn test_basic_domestic_quote() {
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let quote = with_ratecard(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799",
            &parcel,
        )
        .unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_second_band() {
        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };

        let quote = with_ratecard(
            "domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799",
            &parcel,
        )
        .unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_weight_surcharge_above_10kg() {
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };

        let quote = with_ratecard(
            "domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799",
            &parcel,
        )
        .unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn test_international_surcharge_20_percent() {
        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };

        let quote = with_ratecard(
            "international\t500\t1499\n\
             international\t20000\t4999",
            &parcel,
        )
        .unwrap();
        assert_eq!(quote.base_cents, 1499);
         assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_international_with_weight_surcharge() {
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };

        let quote = with_ratecard(
            "international\t500\t1499\n\
             international\t20000\t4999",
            &parcel,
        )
        .unwrap();
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn test_unknown_zone() {
        let parcel = Parcel {
            weight_grams: 100,
            zone: "express".to_string(),
        };

        let result = with_ratecard(
            "domestic\t500\t599\n\
             domestic\t2000\t899",
            &parcel,
        );
        assert!(matches!(result, Err(QuoteError::UnknownZone(ref z)) if z == "express"));
    }

    #[test]
    fn test_overweight() {
        let parcel = Parcel {
            weight_grams: 5000,
            zone: "domestic".to_string(),
        };

        match with_ratecard(
            "domestic\t500\t599\n\
             domestic\t2000\t899",
            &parcel,
        ) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 5000);
                assert_eq!(limit, 2000);
            }
            _ => panic!("expected Overweight error"),
        }
    }

    #[test]
    fn test_rate_card_unavailable_no_env() {
        let _guard = crate::QUOTE_LOCK.lock().unwrap();
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = crate::quote_internal(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_rate_card_unavailable_bad_path() {
        let _guard = crate::QUOTE_LOCK.lock().unwrap();
        env::set_var("RATECARD_PATH", "/nonexistent/path/to/ratecard");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = crate::quote_internal(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_malformed_rate_card_wrong_fields() {
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match with_ratecard("domestic\t500", &parcel) {
            Err(QuoteError::MalformedRateCard { line }) => {
                assert_eq!(line, 1);
            }
            _ => panic!("expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_bad_number() {
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match with_ratecard("domestic\t500\tnot_a_number", &parcel) {
            Err(QuoteError::MalformedRateCard { line }) => {
                assert_eq!(line, 1);
            }
            _ => panic!("expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_comments_and_blanks_ignored() {
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let quote = with_ratecard(
            "# zone\tband_max_grams\tcents\n\n\
             domestic\t500\t599\n\
             # another comment\n\
             domestic\t2000\t899",
            &parcel,
        )
        .unwrap();
        assert_eq!(quote.base_cents, 599);
    }

    #[test]
    fn test_malformed_line_number_counts_all_lines() {
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match with_ratecard(
            "# header\n\n\
             domestic\t500\n",
            &parcel,
        ) {
            Err(QuoteError::MalformedRateCard { line }) => {
                assert_eq!(line, 3);
            }
            _ => panic!("expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_exact_weight_matches_band() {
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };

        let quote = with_ratecard(
            "domestic\t500\t599\n\
             domestic\t2000\t899",
            &parcel,
        )
        .unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_rounding_half_up() {
        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };

        let quote = with_ratecard(
            "international\t500\t1005\n\
             international\t20000\t4999",
            &parcel,
        )
        .unwrap();
        assert_eq!(quote.surcharge_cents, 201);
    }

    #[test]
    fn test_weight_exactly_10000_no_surcharge() {
        let parcel = Parcel {
            weight_grams: 10000,
            zone: "domestic".to_string(),
        };

        let quote = with_ratecard(
            "domestic\t500\t599\n\
             domestic\t20000\t1799",
            &parcel,
        )
        .unwrap();
        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn test_weight_10001_gets_surcharge() {
        let parcel = Parcel {
            weight_grams: 10001,
            zone: "domestic".to_string(),
        };

        let quote = with_ratecard(
            "domestic\t500\t599\n\
             domestic\t20000\t1799",
            &parcel,
        )
        .unwrap();
        assert_eq!(quote.surcharge_cents, 500);
    }

    #[test]
    fn test_display_quote_error() {
        let err = QuoteError::UnknownZone("express".to_string());
        assert!(!format!("{}", err).is_empty());

        let err = QuoteError::Overweight { grams: 5000, limit: 2000 };
        assert!(format!("{}", err).contains("5000"));

        let err = QuoteError::MalformedRateCard { line: 3 };
        assert!(format!("{}", err).contains("3"));

        let err = QuoteError::RateCardUnavailable;
        assert!(!format!("{}", err).is_empty());
    }
}
