use std::collections::HashMap;
use std::env;
use std::fmt;
use std::fs;

pub mod zones;

#[derive(Clone, Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Clone, Debug, PartialEq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => write!(f, "Overweight: {} grams, limit is {} grams", grams, limit),
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

fn parse_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut map: HashMap<String, Vec<Band>> = HashMap::new();

    for (idx, raw) in content.lines().enumerate() {
        let line_num = idx + 1;
        let line = raw.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let zone = parts[0].trim().to_string();
        let max_grams: u32 = parts[1].trim().parse().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2].trim().parse().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        map.entry(zone).or_insert_with(Vec::new).push(Band { max_grams, cents });
    }

    for bands in map.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(map)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = parse_rate_card()?;

    let bands = rate_card.get(&parcel.zone).ok_or(QuoteError::UnknownZone(parcel.zone.clone()))?;

    if bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let max_band = bands.last().unwrap();
    if parcel.weight_grams > max_band.max_grams {
        return Err(QuoteError::Overweight { grams: parcel.weight_grams, limit: max_band.max_grams });
    }

    let matching = bands.iter().find(|b| b.max_grams >= parcel.weight_grams).unwrap();
    let base_cents = matching.cents;
    let band_max_grams = matching.max_grams;

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        surcharge_cents += (base_cents + 2) / 5;
     }

    let total_cents = base_cents + surcharge_cents;

    eprintln!("DIAGNOSTIC: zone={}, weight_grams={}, total_cents={}", parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;

    static ENV_GUARD: Mutex<()> = Mutex::new(());

    struct RateCardGuard {
        _dir: tempfile::TempDir,
        _lock: std::sync::MutexGuard<'static, ()>,
    }

    fn with_rate_card(content: &str) -> RateCardGuard {
        let lock = ENV_GUARD.lock().unwrap();
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("ratecard.tsv");
        let mut file = fs::File::create(&path).unwrap();
        file.write_all(content.as_bytes()).unwrap();
        env::set_var("RATECARD_PATH", path.to_str().unwrap());
        RateCardGuard {
            _dir: dir,
            _lock: lock,
        }
     }

    #[test]
    fn basic_domestic_quote() {
        let _d = with_rate_card("# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\ninternational\t500\t1499\ninternational\t20000\t4999\n");
        let parcel = Parcel { weight_grams: 300, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn domestic_just_above_500() {
        let _d = with_rate_card("# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\ninternational\t500\t1499\ninternational\t20000\t4999\n");
        let parcel = Parcel { weight_grams: 500, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn domestic_501_goes_to_next_band() {
        let _d = with_rate_card("# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\ninternational\t500\t1499\ninternational\t20000\t4999\n");
        let parcel = Parcel { weight_grams: 501, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn overweight_surcharge() {
        let _d = with_rate_card("# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\ninternational\t500\t1499\ninternational\t20000\t4999\n");
        let parcel = Parcel { weight_grams: 10001, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn exactly_10000_no_surcharge() {
        let _d = with_rate_card("# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\ninternational\t500\t1499\ninternational\t20000\t4999\n");
        let parcel = Parcel { weight_grams: 10000, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn international_surcharge_20_percent() {
        let _d = with_rate_card("# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\ninternational\t500\t1499\ninternational\t20000\t4999\n");
        let parcel = Parcel { weight_grams: 300, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1499);
        let expected = (1499 + 2) / 5;
        assert_eq!(quote.surcharge_cents, expected);
        assert_eq!(quote.total_cents, 1499 + expected);
    }

    #[test]
    fn international_and_overweight_combined() {
        let _d = with_rate_card("# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\ninternational\t500\t1499\ninternational\t20000\t4999\n");
        let parcel = Parcel { weight_grams: 15000, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 4999);
        let intl_surcharge = (4999 + 2) / 5;
        assert_eq!(quote.surcharge_cents, 500 + intl_surcharge);
        assert_eq!(quote.total_cents, 4999 + 500 + intl_surcharge);
    }

    #[test]
    fn unknown_zone() {
        let _d = with_rate_card("# zone\tband_max_grams\tcents\ndomestic\t500\t599\n");
        let parcel = Parcel { weight_grams: 100, zone: "eu".to_string() };
        assert_eq!(quote(&parcel), Err(QuoteError::UnknownZone("eu".to_string())));
    }

    #[test]
    fn overweight_error() {
        let _d = with_rate_card("# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\n");
        let parcel = Parcel { weight_grams: 5000, zone: "domestic".to_string() };
        assert_eq!(quote(&parcel), Err(QuoteError::Overweight { grams: 5000, limit: 2000 }));
    }

    #[test]
    fn missing_env_var() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        assert_eq!(quote(&parcel), Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn malformed_line() {
        let _d = with_rate_card("# zone\tband_max_grams\tcents\ndomestic\t500\n");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 2),
            other => panic!("expected MalformedRateCard, got {:?}", other),
        };
     }

     #[test]
    fn unparseable_number() {
        let _d = with_rate_card("# zone\tband_max_grams\tcents\ndomestic\t500\tnot_a_number\n");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 2),
            other => panic!("expected MalformedRateCard, got {:?}", other),
        };
    }

    #[test]
    fn quote_error_display() {
        assert_eq!(format!("{}", QuoteError::RateCardUnavailable), "Rate card is unavailable");
        assert_eq!(format!("{}", QuoteError::UnknownZone("eu".to_string())), "Unknown zone: eu");
        assert_eq!(format!("{}", QuoteError::Overweight { grams: 3000, limit: 2000 }), "Overweight: 3000 grams, limit is 2000 grams");
        assert_eq!(format!("{}", QuoteError::MalformedRateCard { line: 5 }), "Malformed rate card at line 5");
    }
}
