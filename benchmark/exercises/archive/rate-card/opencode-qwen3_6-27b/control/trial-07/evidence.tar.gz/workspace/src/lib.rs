use std::collections::BTreeMap;
use std::env;
use std::fmt;
use std::fs;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => write!(f, "overweight: {} g exceeds limit of {} g", grams, limit),
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Clone)]
struct Band {
    max_grams: u32,
    cents: u64,
}

type RateCard = BTreeMap<String, Vec<Band>>;

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut card = BTreeMap::new();

    for (idx, raw_line) in contents.lines().enumerate() {
        let line = raw_line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: idx + 1 });
        }

        let zone = parts[0].trim().to_string();
        let max_grams: u32 = parts[1].trim().parse().map_err(|_| QuoteError::MalformedRateCard { line: idx + 1 })?;
        let cents: u64 = parts[2].trim().parse().map_err(|_| QuoteError::MalformedRateCard { line: idx + 1 })?;

        card.entry(zone).or_insert_with(Vec::new).push(Band {
            max_grams,
            cents,
        });
    }

    Ok(card)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = load_rate_card()?;

    let bands = card.get(&parcel.zone).ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let sorted_bands = {
        let mut b = bands.clone();
        b.sort_by_key(|x| x.max_grams);
        b
    };

    let matched = sorted_bands.iter().find(|b| b.max_grams >= parcel.weight_grams);

    let matched = matched.ok_or_else(|| {
        let limit = sorted_bands.last().unwrap().max_grams;
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        }
    })?;

    let base_cents = matched.cents;
    let band_max_grams = matched.max_grams;

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let pct = base_cents as f64 * 0.20;
        let rounded = pct.round() as u64;
        surcharge_cents += rounded;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!("DIAG zone={} weight_grams={} total_cents={}", parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    fn setup_rate_card(content: &str) -> tempfile::NamedTempFile {
        let mut file = tempfile::NamedTempFile::new().unwrap();
        writeln!(file, "{}", content).unwrap();
        file.flush().unwrap();
        file
     }

     #[serial_test::serial]
    #[test]
    fn test_basic_domestic_quote() {
        let file = setup_rate_card(
             "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n\
             international\t500\t1499\n\
             international\t20000\t4999",
         );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
         };

        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
     }

     #[serial_test::serial]
    #[test]
    fn test_domestic_2000_band() {
        let file = setup_rate_card(
             "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n\
             international\t500\t1499\n\
             international\t20000\t4999",
         );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
         };

        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
     }

     #[serial_test::serial]
    #[test]
    fn test_domestic_over_10kg_surcharge() {
        let file = setup_rate_card(
             "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n\
             international\t500\t1499\n\
             international\t20000\t4999",
         );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
         };

        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
     }

     #[serial_test::serial]
    #[test]
    fn test_international_surcharge() {
        let file = setup_rate_card(
             "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n\
             international\t500\t1499\n\
             international\t20000\t4999",
         );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
         };

        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
        assert_eq!(q.band_max_grams, 500);
     }

     #[serial_test::serial]
    #[test]
    fn test_international_heavy_both_surcharges() {
        let file = setup_rate_card(
             "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n\
             international\t500\t1499\n\
             international\t20000\t4999",
         );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
         };

        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 4999);
        let intl_surcharge = (4999f64 * 0.20).round() as u64;
        assert_eq!(q.surcharge_cents, 500 + intl_surcharge);
        assert_eq!(q.total_cents, 4999 + 500 + intl_surcharge);
        assert_eq!(q.band_max_grams, 20000);
     }

     #[serial_test::serial]
    #[test]
    fn test_unknown_zone() {
        let file = setup_rate_card(
             "domestic\t500\t599",
         );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "eu".to_string(),
         };

        match quote(&parcel) {
            Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "eu"),
            other => panic!("expected UnknownZone, got {:?}", other),
         }
     }

     #[serial_test::serial]
    #[test]
    fn test_overweight() {
        let file = setup_rate_card(
             "domestic\t500\t599",
         );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 999,
            zone: "domestic".to_string(),
         };

        match quote(&parcel) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 999);
                assert_eq!(limit, 500);
             }
            other => panic!("expected Overweight, got {:?}", other),
         }
     }

     #[serial_test::serial]
    #[test]
    fn test_rate_card_unavailable_unset() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
         };
        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected RateCardUnavailable, got {:?}", other),
         }
     }

     #[serial_test::serial]
    #[test]
    fn test_rate_card_unavailable_missing_file() {
        env::set_var("RATECARD_PATH", "/nonexistent/path/ratecard.txt");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
         };
        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected RateCardUnavailable, got {:?}", other),
         }
     }

     #[serial_test::serial]
    #[test]
    fn test_malformed_line_wrong_field_count() {
        let file = setup_rate_card(
             "domestic\t500\n\
             domestic\t500\t599",
         );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
         };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            other => panic!("expected MalformedRateCard, got {:?}", other),
         }
     }

     #[serial_test::serial]
    #[test]
    fn test_malformed_line_bad_number() {
        let file = setup_rate_card(
             "domestic\t500\tnot_a_number",
         );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
         };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            other => panic!("expected MalformedRateCard, got {:?}", other),
         }
     }

     #[serial_test::serial]
    #[test]
    fn test_comments_and_blanks_ignored() {
        let file = setup_rate_card(
             "# header\n\
              \n\
             domestic\t500\t599\n\
              # another comment\n\
             domestic\t2000\t899",
         );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
         };

        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
     }

     #[serial_test::serial]
    #[test]
    fn test_malformed_line_number_counts_all_lines() {
        let file = setup_rate_card(
             "# line 1\n\
              \n\
             bad_line\n\
             domestic\t500\t599",
         );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
         };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
            other => panic!("expected MalformedRateCard at line 3, got {:?}", other),
         }
     }

     #[serial_test::serial]
    #[test]
    fn test_weight_exact_boundary() {
        let file = setup_rate_card(
             "domestic\t500\t599\n\
             domestic\t2000\t899",
         );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
         };

        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
     }

     #[serial_test::serial]
    #[test]
    fn test_weight_10001_triggers_surcharge() {
        let file = setup_rate_card(
             "domestic\t20000\t1799",
         );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 10001,
            zone: "domestic".to_string(),
         };

        let q = quote(&parcel).unwrap();
        assert_eq!(q.surcharge_cents, 500);
     }

     #[serial_test::serial]
    #[test]
    fn test_weight_10000_no_surcharge() {
        let file = setup_rate_card(
             "domestic\t20000\t1799",
         );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 10000,
            zone: "domestic".to_string(),
         };

        let q = quote(&parcel).unwrap();
        assert_eq!(q.surcharge_cents, 0);
     }

     #[test]
    fn test_display_errors() {
        assert_eq!(format!("{}", QuoteError::RateCardUnavailable), "rate card unavailable");
        assert_eq!(
            format!("{}", QuoteError::MalformedRateCard { line: 5 }),
             "malformed rate card at line 5"
         );
        assert_eq!(
            format!("{}", QuoteError::UnknownZone("eu".to_string())),
             "unknown zone: eu"
         );
        assert_eq!(
            format!("{}", QuoteError::Overweight { grams: 999, limit: 500 }),
             "overweight: 999 g exceeds limit of 500 g"
         );
     }

     #[test]
    fn test_error_implements_std_error() {
        let err: Box<dyn std::error::Error> = Box::new(QuoteError::RateCardUnavailable);
        assert!(err.to_string().contains("rate card unavailable"));
     }

     #[serial_test::serial]
    #[test]
    fn test_international_20_percent_rounding() {
        let file = setup_rate_card(
             "international\t500\t1001",
         );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
         };

        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 1001);
        assert_eq!(q.surcharge_cents, 200);
        assert_eq!(q.total_cents, 1201);
        assert_eq!(q.band_max_grams, 500);
     }
}
