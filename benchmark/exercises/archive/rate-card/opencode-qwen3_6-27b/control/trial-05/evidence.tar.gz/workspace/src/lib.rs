use std::collections::BTreeMap;
use std::env;
use std::fmt;
use std::fs;
use std::error::Error;

mod zones;

#[derive(Clone, Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Clone, Debug, PartialEq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card file is unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => write!(f, "Parcel {}g exceeds zone limit of {}g", grams, limit),
        }
    }
}

impl Error for QuoteError {}

struct RateBand {
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<BTreeMap<String, Vec<RateBand>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut rate_card: BTreeMap<String, Vec<RateBand>> = BTreeMap::new();

    for (idx, raw_line) in content.lines().enumerate() {
        let line_num = idx + 1;
        let line = raw_line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let zone = parts[0].trim().to_string();
        let band_max_grams = parts[1].trim().parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = parts[2].trim().parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        rate_card.entry(zone).or_insert_with(Vec::new).push(RateBand {
            band_max_grams,
            cents,
        });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|b| b.band_max_grams);
    }

    Ok(rate_card)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;

    let bands = rate_card.get(&parcel.zone).ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    if bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let max_limit = bands.last().unwrap().band_max_grams;
    if parcel.weight_grams > max_limit {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: max_limit,
        });
    }

    let matching_band = bands.iter().find(|b| b.band_max_grams >= parcel.weight_grams)
        .unwrap();

    let base_cents = matching_band.cents;
    let band_max_grams = matching_band.band_max_grams;

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let pct = base_cents * 20 / 100;
        let remainder = base_cents * 20 % 100;
        let surcharge = if remainder >= 50 { pct + 1 } else { pct };
        surcharge_cents += surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "DIAG zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn create_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        file
    }

    #[test]
    fn test_basic_domestic_quote() {
        let file = create_ratecard(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799"
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let quote_result = quote(&parcel);
        assert!(quote_result.is_ok());
        let q = quote_result.unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_next_band() {
        let file = create_ratecard(
            "domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799"
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn test_weight_surcharge_above_10kg() {
        let file = create_ratecard(
            "domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799"
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn test_international_surcharge() {
        let file = create_ratecard(
            "international\t500\t1499\n\
             international\t20000\t4999"
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 1499);
        let expected_surcharge = 1499 * 20 / 100;
        let remainder = 1499 * 20 % 100;
        let surcharge = if remainder >= 50 { expected_surcharge + 1 } else { expected_surcharge };
        assert_eq!(q.surcharge_cents, surcharge);
        assert_eq!(q.total_cents, 1499 + surcharge);
    }

     #[test]
    fn test_international_with_weight_surcharge() {
        let file = create_ratecard(
             "international\t500\t1499\ninternational\t20000\t4999"
         );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
         };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 500 + 1000);
        assert_eq!(q.total_cents, 4999 + 500 + 1000);
     }

    #[test]
    fn test_unknown_zone() {
        let file = create_ratecard(
            "domestic\t500\t599"
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "express".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::UnknownZone(z)) if z == "express"));
    }

    #[test]
    fn test_overweight() {
        let file = create_ratecard(
            "domestic\t500\t599\n\
             domestic\t2000\t899"
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 5000,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::Overweight { grams: 5000, limit: 2000 })));
    }

    #[test]
    fn test_missing_ratecard_path() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_nonexistent_file() {
        env::set_var("RATECARD_PATH", "/nonexistent/path/ratecard.txt");
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_malformed_line() {
        let file = create_ratecard(
            "domestic\t500\n\
             domestic\t2000\t899"
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 1 })));
    }

    #[test]
    fn test_malformed_number() {
        let file = create_ratecard(
            "domestic\tnot_a_number\t599"
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 1 })));
    }

    #[test]
    fn test_ignores_comments_and_blanks() {
        let file = create_ratecard(
            "# This is a comment\n\n\
             domestic\t500\t599\n\
             # Another comment\n\
             domestic\t2000\t899"
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
    }

     #[test]
    fn test_rounding_half_up() {
        let file = create_ratecard(
             "international\t500\t999"
         );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
         };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 999);
        assert_eq!(q.surcharge_cents, 200);
        assert_eq!(q.total_cents, 1199);
     }

    #[test]
    fn test_exactly_at_boundary() {
        let file = create_ratecard(
            "domestic\t500\t599\n\
             domestic\t2000\t899"
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

     #[test]
    fn test_exactly_at_weight_surcharge_boundary() {
        let file = create_ratecard(
             "domestic\t500\t599\ndomestic\t20000\t1799"
         );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 10000,
            zone: "domestic".to_string(),
         };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.surcharge_cents, 0);

        let parcel = Parcel {
            weight_grams: 10001,
            zone: "domestic".to_string(),
         };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.surcharge_cents, 500);
     }

    #[test]
    fn test_error_display() {
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "Rate card file is unavailable"
        );
        assert_eq!(
            QuoteError::MalformedRateCard { line: 5 }.to_string(),
            "Malformed rate card at line 5"
        );
        assert_eq!(
            QuoteError::UnknownZone("express".to_string()).to_string(),
            "Unknown zone: express"
        );
        assert_eq!(
            QuoteError::Overweight { grams: 5000, limit: 2000 }.to_string(),
            "Parcel 5000g exceeds zone limit of 2000g"
        );
    }

    #[test]
    fn test_malformed_line_number_counts_all_lines() {
        let file = create_ratecard(
            "# comment\n\n\
             bad line here\n\
             domestic\t500\t599"
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 3 })));
    }
}
