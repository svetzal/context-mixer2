pub mod zones;

use std::fmt;
use std::fs;
use std::io::Read;
use std::env;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {}", zone)
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {}g exceeds zone limit of {}g", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

struct RateCard {
    bands: std::collections::HashMap<String, Vec<Band>>,
}

fn parse_rate_card(path: &str) -> Result<RateCard, QuoteError> {
    let mut content = String::new();
    let mut file = fs::File::open(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    file.read_to_string(&mut content).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands: std::collections::HashMap<String, Vec<Band>> =
        std::collections::HashMap::new();

    for (idx, raw_line) in content.lines().enumerate() {
        let line_num = idx + 1;
        let line = raw_line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let zone = parts[0].trim();
        let max_grams: u32 = parts[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        bands
            .entry(zone.to_string())
            .or_insert_with(Vec::new)
            .push(Band {
                max_grams,
                cents,
            });
    }

    for band_list in bands.values_mut() {
        band_list.sort_by_key(|b| b.max_grams);
    }

    Ok(RateCard { bands })
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let rate_card = parse_rate_card(&path)?;

    let band_list = rate_card
        .bands
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let matching_band = band_list
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams);

    if matching_band.is_none() {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: band_list.last().unwrap().max_grams,
        });
    }

    let band = matching_band.unwrap();
    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let international_surcharge = (base_cents * 20 + 50) / 100;
        surcharge_cents += international_surcharge;
     }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "DIAGNOSTIC: zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    fn write_ratecard(dir: &tempfile::TempDir, content: &str) -> String {
        let path = dir.path().join("ratecard.tsv");
        let mut f = fs::File::create(&path).unwrap();
        write!(f, "{}", content).unwrap();
        path.to_str().unwrap().to_string()
    }

    #[serial_test::serial]
    #[test]
    fn test_basic_domestic_quote() {
        let dir = tempfile::TempDir::new().unwrap();
        let rc_path = write_ratecard(&dir, "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\n");
        env::set_var("RATECARD_PATH", &rc_path);
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[serial_test::serial]
    #[test]
    fn test_domestic_heavier() {
        let dir = tempfile::TempDir::new().unwrap();
        let rc_path = write_ratecard(&dir, "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\n");
        env::set_var("RATECARD_PATH", &rc_path);
        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[serial_test::serial]
    #[test]
    fn test_weight_surcharge_above_10kg() {
        let dir = tempfile::TempDir::new().unwrap();
        let rc_path = write_ratecard(&dir, "domestic\t20000\t1799\n");
        env::set_var("RATECARD_PATH", &rc_path);
        let parcel = Parcel {
            weight_grams: 12000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[serial_test::serial]
    #[test]
    fn test_no_weight_surcharge_at_exactly_10kg() {
        let dir = tempfile::TempDir::new().unwrap();
        let rc_path = write_ratecard(&dir, "domestic\t10000\t1200\n");
        env::set_var("RATECARD_PATH", &rc_path);
        let parcel = Parcel {
            weight_grams: 10000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.surcharge_cents, 0);
    }

    #[serial_test::serial]
    #[test]
    fn test_international_surcharge_twenty_percent() {
        let dir = tempfile::TempDir::new().unwrap();
        let rc_path = write_ratecard(&dir, "international\t500\t1499\n");
        env::set_var("RATECARD_PATH", &rc_path);
        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 1499);
        // 20% of 1499 = 299.8 -> rounded half up = 300
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[serial_test::serial]
    #[test]
    fn test_international_with_weight_surcharge() {
        let dir = tempfile::TempDir::new().unwrap();
        let rc_path = write_ratecard(&dir, "international\t20000\t4999\n");
        env::set_var("RATECARD_PATH", &rc_path);
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 4999);
        // 20% of 4999 = 999.8 -> rounded half up = 1000
        assert_eq!(q.surcharge_cents, 1000 + 500);
        assert_eq!(q.total_cents, 4999 + 1500);
    }

    #[serial_test::serial]
    #[test]
    fn test_unknown_zone() {
        let dir = tempfile::TempDir::new().unwrap();
        let rc_path = write_ratecard(&dir, "domestic\t500\t599\n");
        env::set_var("RATECARD_PATH", &rc_path);
        let parcel = Parcel {
            weight_grams: 300,
            zone: "express".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "express"),
            other => panic!("expected UnknownZone, got {:?}", other),
        }
    }

    #[serial_test::serial]
    #[test]
    fn test_overweight() {
        let dir = tempfile::TempDir::new().unwrap();
        let rc_path = write_ratecard(&dir, "domestic\t500\t599\ndomestic\t2000\t899\n");
        env::set_var("RATECARD_PATH", &rc_path);
        let parcel = Parcel {
            weight_grams: 5000,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 5000);
                assert_eq!(limit, 2000);
            }
            other => panic!("expected Overweight, got {:?}", other),
        }
    }

    #[serial_test::serial]
    #[test]
    fn test_missing_ratecard_path() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected RateCardUnavailable, got {:?}", other),
        }
    }

    #[serial_test::serial]
    #[test]
    fn test_malformed_ratecard() {
        let dir = tempfile::TempDir::new().unwrap();
        let rc_path = write_ratecard(&dir, "domestic\t500\nbad line\n");
        env::set_var("RATECARD_PATH", &rc_path);
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            other => panic!("expected MalformedRateCard, got {:?}", other),
         }
    }

    #[serial_test::serial]
    #[test]
    fn test_comments_and_blanks_ignored() {
        let dir = tempfile::TempDir::new().unwrap();
        let rc_path = write_ratecard(
            &dir,
            "# header\n\ndomestic\t500\t599\n# another comment\n",
        );
        env::set_var("RATECARD_PATH", &rc_path);
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
    }

    #[serial_test::serial]
    #[test]
    fn test_exact_boundary_matches_band() {
        let dir = tempfile::TempDir::new().unwrap();
        let rc_path = write_ratecard(&dir, "domestic\t500\t599\ndomestic\t2000\t899\n");
        env::set_var("RATECARD_PATH", &rc_path);
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[serial_test::serial]
    #[test]
    fn test_rounding_half_up() {
        let dir = tempfile::TempDir::new().unwrap();
        let rc_path = write_ratecard(&dir, "international\t500\t1005\n");
        env::set_var("RATECARD_PATH", &rc_path);
        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };
        let q = quote(&parcel).unwrap();
        // 20% of 1005 = 201.0, exact
        assert_eq!(q.surcharge_cents, 201);
    }

    #[serial_test::serial]
    #[test]
    fn test_display_error_ratecard_unavailable() {
        let e = QuoteError::RateCardUnavailable;
        assert!(!format!("{}", e).is_empty());
    }

    #[serial_test::serial]
    #[test]
    fn test_display_error_unknown_zone() {
        let e = QuoteError::UnknownZone("foo".to_string());
        let s = format!("{}", e);
        assert!(s.contains("foo"));
    }
}
