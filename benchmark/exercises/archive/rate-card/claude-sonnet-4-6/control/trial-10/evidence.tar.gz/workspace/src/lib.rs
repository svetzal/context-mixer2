use std::env;
use std::fmt;
use std::fs;

pub mod zones;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<Vec<(String, Band)>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands = Vec::new();
    for (index, line) in contents.lines().enumerate() {
        let line_num = index + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        bands.push((zone, Band { band_max_grams, cents }));
    }

    Ok(bands)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;

    let mut zone_bands: Vec<&Band> = rate_card
        .iter()
        .filter(|(zone, _)| zone == &parcel.zone)
        .map(|(_, band)| band)
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.band_max_grams);

    let limit = zone_bands.last().unwrap().band_max_grams;

    if parcel.weight_grams > limit {
        return Err(QuoteError::Overweight { grams: parcel.weight_grams, limit });
    }

    let matching_band = zone_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .unwrap();

    let base_cents = matching_band.cents;
    let band_max_grams = matching_band.band_max_grams;

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote { base_cents, surcharge_cents, total_cents, band_max_grams })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write as IoWrite;
    use std::sync::{Mutex, OnceLock};
    use tempfile::NamedTempFile;

    static ENV_LOCK: OnceLock<Mutex<()>> = OnceLock::new();

    fn env_mutex() -> &'static Mutex<()> {
        ENV_LOCK.get_or_init(|| Mutex::new(()))
    }

    const SAMPLE_CARD: &str = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\ninternational\t500\t1499\ninternational\t20000\t4999\n";

    fn with_rate_card<F: FnOnce()>(content: &str, f: F) {
        let _guard = env_mutex().lock().unwrap();
        let mut file = NamedTempFile::new().unwrap();
        write!(file, "{}", content).unwrap();
        unsafe { env::set_var("RATECARD_PATH", file.path()) };
        f();
    }

    fn with_no_rate_card<F: FnOnce()>(f: F) {
        let _guard = env_mutex().lock().unwrap();
        unsafe { env::remove_var("RATECARD_PATH") };
        f();
    }

    #[test]
    fn domestic_light_parcel() {
        with_rate_card(SAMPLE_CARD, || {
            let q = quote(&Parcel { weight_grams: 300, zone: "domestic".into() }).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_mid_parcel() {
        with_rate_card(SAMPLE_CARD, || {
            let q = quote(&Parcel { weight_grams: 1000, zone: "domestic".into() }).unwrap();
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
        });
    }

    #[test]
    fn domestic_heavy_adds_surcharge() {
        with_rate_card(SAMPLE_CARD, || {
            let q = quote(&Parcel { weight_grams: 15000, zone: "domestic".into() }).unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
            assert_eq!(q.band_max_grams, 20000);
        });
    }

    #[test]
    fn international_adds_twenty_percent() {
        with_rate_card(SAMPLE_CARD, || {
            let q = quote(&Parcel { weight_grams: 200, zone: "international".into() }).unwrap();
            assert_eq!(q.base_cents, 1499);
            // 20% of 1499 = 299.8, rounded half-up = 300
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_heavy_both_surcharges() {
        with_rate_card(SAMPLE_CARD, || {
            let q = quote(&Parcel { weight_grams: 15000, zone: "international".into() }).unwrap();
            assert_eq!(q.base_cents, 4999);
            // 20% of 4999 = 999.8, rounded half-up = 1000; plus 500 for >10000g
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
        });
    }

    #[test]
    fn exact_band_boundary_matches() {
        with_rate_card(SAMPLE_CARD, || {
            let q = quote(&Parcel { weight_grams: 500, zone: "domestic".into() }).unwrap();
            assert_eq!(q.band_max_grams, 500);
            assert_eq!(q.base_cents, 599);
        });
    }

    #[test]
    fn unknown_zone_error() {
        with_rate_card(SAMPLE_CARD, || {
            let err = quote(&Parcel { weight_grams: 100, zone: "express".into() }).unwrap_err();
            assert!(matches!(err, QuoteError::UnknownZone(z) if z == "express"));
        });
    }

    #[test]
    fn overweight_error() {
        with_rate_card(SAMPLE_CARD, || {
            let err =
                quote(&Parcel { weight_grams: 25000, zone: "domestic".into() }).unwrap_err();
            assert!(matches!(err, QuoteError::Overweight { grams: 25000, limit: 20000 }));
        });
    }

    #[test]
    fn rate_card_unavailable_when_env_unset() {
        with_no_rate_card(|| {
            let err =
                quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
            assert!(matches!(err, QuoteError::RateCardUnavailable));
        });
    }

    #[test]
    fn malformed_too_few_fields() {
        with_rate_card("domestic\t500\n", || {
            let err =
                quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
            assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
        });
    }

    #[test]
    fn malformed_bad_number() {
        with_rate_card("domestic\tfoo\t599\n", || {
            let err =
                quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
            assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
        });
    }

    #[test]
    fn malformed_line_number_counts_all_lines() {
        // comment = line 1, blank = line 2, bad = line 3
        with_rate_card("# comment\n\ndomestic\tfoo\t599\n", || {
            let err =
                quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
            assert!(matches!(err, QuoteError::MalformedRateCard { line: 3 }));
        });
    }

    #[test]
    fn display_impl_is_human_readable() {
        let e = QuoteError::UnknownZone("express".into());
        assert!(e.to_string().contains("express"));

        let e = QuoteError::MalformedRateCard { line: 7 };
        assert!(e.to_string().contains('7'));

        let e = QuoteError::Overweight { grams: 30000, limit: 20000 };
        assert!(e.to_string().contains("30000"));

        let e = QuoteError::RateCardUnavailable;
        assert!(!e.to_string().is_empty());
    }
}
