pub mod zones;

use std::fmt;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weighs {} g, exceeds zone limit of {} g", grams, limit)
            }
        }
    }
}

impl fmt::Debug for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self, f)
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<Vec<(String, Band)>, QuoteError> {
    let path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let content = std::fs::read_to_string(&path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands = Vec::new();

    for (idx, raw_line) in content.lines().enumerate() {
        let line_num = idx + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = trimmed.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let zone = fields[0].to_string();
        let band_max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        bands.push((zone, Band { band_max_grams, cents }));
    }

    Ok(bands)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_rate_card()?;

    // Collect bands for the requested zone, sorted by band_max_grams ascending
    let mut zone_bands: Vec<&Band> = bands
        .iter()
        .filter(|(z, _)| z == &parcel.zone)
        .map(|(_, b)| b)
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.band_max_grams);

    // Find matching band
    let matched = zone_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams);

    let band = match matched {
        Some(b) => b,
        None => {
            let limit = zone_bands.last().unwrap().band_max_grams;
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up
        surcharge_cents += (base_cents * 20 + 99) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write as IoWrite;

    fn write_rate_card(content: &str) -> tempfile::NamedTempFile {
        let mut f = tempfile::NamedTempFile::new().unwrap();
        f.write_all(content.as_bytes()).unwrap();
        f
    }

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    fn with_card(content: &str, f: impl FnOnce()) {
        let tmp = write_rate_card(content);
        std::env::set_var("RATECARD_PATH", tmp.path());
        f();
        // tmp dropped here, file removed
    }

    #[test]
    fn domestic_first_band() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel { weight_grams: 400, zone: "domestic".into() }).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_boundary_exact() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel { weight_grams: 500, zone: "domestic".into() }).unwrap();
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_second_band() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel { weight_grams: 501, zone: "domestic".into() }).unwrap();
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
        });
    }

    #[test]
    fn domestic_heavy_surcharge() {
        with_card(SAMPLE, || {
            // 15000g domestic, above 10000 → +500
            let q = quote(&Parcel { weight_grams: 15000, zone: "domestic".into() }).unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
        });
    }

    #[test]
    fn international_surcharge() {
        with_card(SAMPLE, || {
            // 400g international: base=1499, +20% = 299.8 rounded half-up = 300
            let q = quote(&Parcel { weight_grams: 400, zone: "international".into() }).unwrap();
            assert_eq!(q.base_cents, 1499);
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_heavy_surcharge() {
        with_card(SAMPLE, || {
            // 15000g international: base=4999, +500 heavy, +20% of 4999=999.8→1000
            let q = quote(&Parcel { weight_grams: 15000, zone: "international".into() }).unwrap();
            assert_eq!(q.base_cents, 4999);
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
        });
    }

    #[test]
    fn overweight() {
        with_card(SAMPLE, || {
            let err = quote(&Parcel { weight_grams: 25000, zone: "domestic".into() }).unwrap_err();
            match err {
                QuoteError::Overweight { grams, limit } => {
                    assert_eq!(grams, 25000);
                    assert_eq!(limit, 20000);
                }
                _ => panic!("expected Overweight"),
            }
        });
    }

    #[test]
    fn unknown_zone() {
        with_card(SAMPLE, || {
            let err = quote(&Parcel { weight_grams: 100, zone: "mars".into() }).unwrap_err();
            match err {
                QuoteError::UnknownZone(z) => assert_eq!(z, "mars"),
                _ => panic!("expected UnknownZone"),
            }
        });
    }

    #[test]
    fn rate_card_unavailable_missing_env() {
        std::env::remove_var("RATECARD_PATH");
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn malformed_wrong_field_count() {
        with_card("domestic\t500\n", || {
            let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
            match err {
                QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
                _ => panic!("expected MalformedRateCard"),
            }
        });
    }

    #[test]
    fn malformed_bad_number() {
        with_card("domestic\tabc\t599\n", || {
            let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
            assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
        });
    }

    #[test]
    fn malformed_line_counting_includes_blanks_and_comments() {
        // Line 1: comment, line 2: blank, line 3: bad
        let content = "# header\n\nbad_line\n";
        with_card(content, || {
            let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
            assert!(matches!(err, QuoteError::MalformedRateCard { line: 3 }));
        });
    }

    #[test]
    fn display_errors() {
        assert!(!format!("{}", QuoteError::RateCardUnavailable).is_empty());
        assert!(!format!("{}", QuoteError::MalformedRateCard { line: 5 }).is_empty());
        assert!(!format!("{}", QuoteError::UnknownZone("x".into())).is_empty());
        assert!(!format!("{}", QuoteError::Overweight { grams: 1, limit: 2 }).is_empty());
    }
}
