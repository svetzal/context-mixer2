use std::env;
use std::fmt;
use std::fs;

pub mod zones;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {}g exceeds zone limit of {}g", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<Vec<Band>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands = Vec::new();
    for (idx, line) in content.lines().enumerate() {
        let line_num = idx + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let band_max_grams = parts[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = parts[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        bands.push(Band {
            zone: parts[0].to_string(),
            band_max_grams,
            cents,
        });
    }
    Ok(bands)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_rate_card()?;

    let mut zone_bands: Vec<&Band> = bands.iter().filter(|b| b.zone == parcel.zone).collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.band_max_grams);

    let matching = zone_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams);

    let band = match matching {
        Some(b) => b,
        None => {
            let limit = zone_bands.last().unwrap().band_max_grams;
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn with_card(content: &str) -> NamedTempFile {
        let mut f = NamedTempFile::new().unwrap();
        f.write_all(content.as_bytes()).unwrap();
        f
    }

    fn set_card(path: &str) {
        env::set_var("RATECARD_PATH", path);
    }

    #[test]
    fn domestic_first_band() {
        let f = with_card(SAMPLE_CARD);
        set_card(f.path().to_str().unwrap());
        let q = quote(&Parcel { weight_grams: 400, zone: "domestic".into() }).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_exact_band_boundary() {
        let f = with_card(SAMPLE_CARD);
        set_card(f.path().to_str().unwrap());
        let q = quote(&Parcel { weight_grams: 500, zone: "domestic".into() }).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_second_band() {
        let f = with_card(SAMPLE_CARD);
        set_card(f.path().to_str().unwrap());
        let q = quote(&Parcel { weight_grams: 501, zone: "domestic".into() }).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn domestic_heavy_surcharge() {
        let f = with_card(SAMPLE_CARD);
        set_card(f.path().to_str().unwrap());
        let q = quote(&Parcel { weight_grams: 15000, zone: "domestic".into() }).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn domestic_exactly_10000_no_surcharge() {
        let f = with_card(SAMPLE_CARD);
        set_card(f.path().to_str().unwrap());
        let q = quote(&Parcel { weight_grams: 10000, zone: "domestic".into() }).unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn international_zone_surcharge() {
        let f = with_card(SAMPLE_CARD);
        set_card(f.path().to_str().unwrap());
        // base 1499, 20% = 299.8 -> rounds half-up to 300
        let q = quote(&Parcel { weight_grams: 300, zone: "international".into() }).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_heavy_both_surcharges() {
        let f = with_card(SAMPLE_CARD);
        set_card(f.path().to_str().unwrap());
        // base 4999, 20% = 999.8 -> 1000, plus 500 heavy
        let q = quote(&Parcel { weight_grams: 15000, zone: "international".into() }).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1000 + 500);
        assert_eq!(q.total_cents, 4999 + 1500);
    }

    #[test]
    fn unknown_zone_error() {
        let f = with_card(SAMPLE_CARD);
        set_card(f.path().to_str().unwrap());
        let err = quote(&Parcel { weight_grams: 100, zone: "galactic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::UnknownZone(z) if z == "galactic"));
    }

    #[test]
    fn overweight_error() {
        let f = with_card(SAMPLE_CARD);
        set_card(f.path().to_str().unwrap());
        let err = quote(&Parcel { weight_grams: 25000, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::Overweight { grams: 25000, limit: 20000 }));
    }

    #[test]
    fn missing_ratecard_path_env() {
        env::remove_var("RATECARD_PATH");
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn unreadable_path() {
        set_card("/nonexistent/path/ratecard.tsv");
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn malformed_wrong_field_count() {
        let f = with_card("domestic\t500\n");
        set_card(f.path().to_str().unwrap());
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn malformed_bad_number() {
        let f = with_card("domestic\tabc\t599\n");
        set_card(f.path().to_str().unwrap());
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn malformed_line_number_counts_comments_and_blanks() {
        let content = "# comment\n\ndomestic\tbad\t599\n";
        let f = with_card(content);
        set_card(f.path().to_str().unwrap());
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn display_errors() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert!(QuoteError::MalformedRateCard { line: 5 }.to_string().contains("5"));
        assert!(QuoteError::UnknownZone("foo".into()).to_string().contains("foo"));
        assert!(QuoteError::Overweight { grams: 999, limit: 500 }.to_string().contains("999"));
    }
}
