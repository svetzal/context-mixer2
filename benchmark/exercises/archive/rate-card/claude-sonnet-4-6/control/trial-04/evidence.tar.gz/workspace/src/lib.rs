pub mod zones;

use std::env;
use std::fmt;
use std::fs;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {}g exceeds zone limit {}g", grams, limit)
            }
        }
    }
}

impl fmt::Debug for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self, f)
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<Vec<Band>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands = Vec::new();
    for (idx, raw_line) in content.lines().enumerate() {
        let line_num = idx + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = raw_line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let band_max_grams = parts[1]
            .trim()
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = parts[2]
            .trim()
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        bands.push(Band {
            zone: parts[0].trim().to_string(),
            band_max_grams,
            cents,
        });
    }
    Ok(bands)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_rate_card()?;

    let zone_bands: Vec<&Band> = {
        let mut zb: Vec<&Band> = bands.iter().filter(|b| b.zone == parcel.zone).collect();
        if zb.is_empty() {
            return Err(QuoteError::UnknownZone(parcel.zone.clone()));
        }
        zb.sort_by_key(|b| b.band_max_grams);
        zb
    };

    let max_band = zone_bands.last().unwrap();
    if parcel.weight_grams > max_band.band_max_grams {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: max_band.band_max_grams,
        });
    }

    let matching_band = zone_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .unwrap();

    let base_cents = matching_band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: matching_band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write as IoWrite;
    use tempfile::NamedTempFile;

    fn write_rate_card(content: &str) -> NamedTempFile {
        let mut f = NamedTempFile::new().unwrap();
        f.write_all(content.as_bytes()).unwrap();
        f
    }

    fn set_card(f: &NamedTempFile) {
        env::set_var("RATECARD_PATH", f.path());
    }

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\ninternational\t500\t1499\ninternational\t20000\t4999\n";

    #[test]
    fn domestic_light_parcel() {
        let f = write_rate_card(SAMPLE);
        set_card(&f);
        let q = quote(&Parcel { weight_grams: 300, zone: "domestic".into() }).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_mid_band() {
        let f = write_rate_card(SAMPLE);
        set_card(&f);
        let q = quote(&Parcel { weight_grams: 1000, zone: "domestic".into() }).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn domestic_heavy_surcharge() {
        let f = write_rate_card(SAMPLE);
        set_card(&f);
        // 15000g > 10000g threshold
        let q = quote(&Parcel { weight_grams: 15000, zone: "domestic".into() }).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn international_surcharge_20_percent() {
        let f = write_rate_card(SAMPLE);
        set_card(&f);
        let q = quote(&Parcel { weight_grams: 400, zone: "international".into() }).unwrap();
        assert_eq!(q.base_cents, 1499);
        // 20% of 1499 = 299.8, rounded half-up = 300
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_heavy_both_surcharges() {
        let f = write_rate_card(SAMPLE);
        set_card(&f);
        // 15000g, international
        let q = quote(&Parcel { weight_grams: 15000, zone: "international".into() }).unwrap();
        assert_eq!(q.base_cents, 4999);
        // 20% of 4999 = 999.8, rounded half-up = 1000, plus 500 weight surcharge
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_error() {
        let f = write_rate_card(SAMPLE);
        set_card(&f);
        let err = quote(&Parcel { weight_grams: 100, zone: "express".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::UnknownZone(z) if z == "express"));
    }

    #[test]
    fn overweight_error() {
        let f = write_rate_card(SAMPLE);
        set_card(&f);
        let err = quote(&Parcel { weight_grams: 25000, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::Overweight { grams: 25000, limit: 20000 }));
    }

    #[test]
    fn rate_card_unavailable_no_env() {
        env::remove_var("RATECARD_PATH");
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn malformed_rate_card_bad_columns() {
        let f = write_rate_card("domestic\t500\n");
        set_card(&f);
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn malformed_rate_card_bad_number() {
        let f = write_rate_card("domestic\tabc\t599\n");
        set_card(&f);
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn comment_and_blank_lines_skipped() {
        let content = "# comment\n\ndomestic\t500\t599\n";
        let f = write_rate_card(content);
        set_card(&f);
        let q = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap();
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn malformed_line_number_counts_all_lines() {
        // blank line is line 1, bad data is line 2
        let content = "\nbad\tdata\n";
        let f = write_rate_card(content);
        set_card(&f);
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 2 }));
    }

    #[test]
    fn display_error_messages() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 5 }.to_string(),
            "malformed rate card at line 5"
        );
        assert_eq!(QuoteError::UnknownZone("foo".into()).to_string(), "unknown zone: foo");
        assert_eq!(
            QuoteError::Overweight { grams: 25000, limit: 20000 }.to_string(),
            "parcel 25000g exceeds zone limit 20000g"
        );
    }

    #[test]
    fn exact_band_boundary_matches() {
        let f = write_rate_card(SAMPLE);
        set_card(&f);
        // exactly at 500g boundary
        let q = quote(&Parcel { weight_grams: 500, zone: "domestic".into() }).unwrap();
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.base_cents, 599);
    }
}
