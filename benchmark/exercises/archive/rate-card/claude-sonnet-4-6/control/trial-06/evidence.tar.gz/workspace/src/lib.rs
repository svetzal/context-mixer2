pub mod zones;

use std::fmt;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {grams}g exceeds zone limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<Vec<(String, Band)>, QuoteError> {
    let path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let content = std::fs::read_to_string(&path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands: Vec<(String, Band)> = Vec::new();

    for (idx, raw_line) in content.lines().enumerate() {
        let line_num = idx + 1;
        let trimmed = raw_line.trim_end_matches('\r');

        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = trimmed.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        bands.push((zone, Band { band_max_grams, cents }));
    }

    Ok(bands)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let all_bands = load_rate_card()?;

    // Collect bands for the requested zone in the order they appear (assumed ascending).
    let zone_bands: Vec<&Band> = all_bands
        .iter()
        .filter(|(z, _)| z == &parcel.zone)
        .map(|(_, b)| b)
        .collect();

    if zone_bands.is_empty() {
        // Check if zone exists at all vs zone being completely absent
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    // Find first band whose band_max_grams >= parcel weight
    let matching = zone_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams);

    let matched_band = match matching {
        Some(b) => b,
        None => {
            let limit = zone_bands.last().unwrap().band_max_grams;
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = matched_band.cents;
    let band_max_grams = matched_band.band_max_grams;

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        // 20% of base_cents rounded half-up
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    fn write_rate_card(content: &str) -> tempfile::NamedTempFile {
        let mut f = tempfile::NamedTempFile::new().unwrap();
        f.write_all(content.as_bytes()).unwrap();
        f
    }

    fn with_card(content: &str, f: impl FnOnce()) {
        let tmp = write_rate_card(content);
        std::env::set_var("RATECARD_PATH", tmp.path());
        f();
        // tmp drops here, removing file
    }

    const BASIC_CARD: &str = "\
# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    #[test]
    fn domestic_light_parcel() {
        with_card(BASIC_CARD, || {
            let p = Parcel { weight_grams: 300, zone: "domestic".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_exact_band_boundary() {
        with_card(BASIC_CARD, || {
            let p = Parcel { weight_grams: 500, zone: "domestic".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_second_band() {
        with_card(BASIC_CARD, || {
            let p = Parcel { weight_grams: 501, zone: "domestic".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
        });
    }

    #[test]
    fn domestic_heavy_surcharge() {
        with_card(BASIC_CARD, || {
            let p = Parcel { weight_grams: 15000, zone: "domestic".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
        });
    }

    #[test]
    fn international_surcharge() {
        with_card(BASIC_CARD, || {
            let p = Parcel { weight_grams: 300, zone: "international".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 1499);
            // 20% of 1499 = 299.8, rounded half-up = 300
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_heavy_and_surcharge() {
        with_card(BASIC_CARD, || {
            let p = Parcel { weight_grams: 15000, zone: "international".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 4999);
            // heavy surcharge 500 + 20% of 4999 = 999.8 -> 1000
            assert_eq!(q.surcharge_cents, 500 + 1000);
            assert_eq!(q.total_cents, 4999 + 1500);
        });
    }

    #[test]
    fn unknown_zone_error() {
        with_card(BASIC_CARD, || {
            let p = Parcel { weight_grams: 100, zone: "express".into() };
            match quote(&p) {
                Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "express"),
                other => panic!("expected UnknownZone, got {other:?}"),
            }
        });
    }

    #[test]
    fn overweight_error() {
        with_card(BASIC_CARD, || {
            let p = Parcel { weight_grams: 25000, zone: "domestic".into() };
            match quote(&p) {
                Err(QuoteError::Overweight { grams, limit }) => {
                    assert_eq!(grams, 25000);
                    assert_eq!(limit, 20000);
                }
                other => panic!("expected Overweight, got {other:?}"),
            }
        });
    }

    #[test]
    fn rate_card_unavailable_when_env_unset() {
        std::env::remove_var("RATECARD_PATH");
        let p = Parcel { weight_grams: 100, zone: "domestic".into() };
        assert!(matches!(quote(&p), Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn malformed_rate_card_wrong_columns() {
        with_card("domestic\t500\n", || {
            let p = Parcel { weight_grams: 100, zone: "domestic".into() };
            match quote(&p) {
                Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
                other => panic!("expected MalformedRateCard, got {other:?}"),
            }
        });
    }

    #[test]
    fn malformed_rate_card_bad_number() {
        with_card("domestic\tabc\t599\n", || {
            let p = Parcel { weight_grams: 100, zone: "domestic".into() };
            match quote(&p) {
                Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
                other => panic!("expected MalformedRateCard, got {other:?}"),
            }
        });
    }

    #[test]
    fn malformed_line_number_counts_comments_and_blanks() {
        let card = "# header\n\ndomestic\tbad\t599\n";
        with_card(card, || {
            let p = Parcel { weight_grams: 100, zone: "domestic".into() };
            match quote(&p) {
                Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
                other => panic!("expected MalformedRateCard line 3, got {other:?}"),
            }
        });
    }

    #[test]
    fn display_errors() {
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "rate card unavailable"
        );
        assert_eq!(
            QuoteError::MalformedRateCard { line: 5 }.to_string(),
            "malformed rate card at line 5"
        );
        assert_eq!(
            QuoteError::UnknownZone("express".into()).to_string(),
            "unknown zone: express"
        );
        assert_eq!(
            QuoteError::Overweight { grams: 25000, limit: 20000 }.to_string(),
            "parcel 25000g exceeds zone limit of 20000g"
        );
    }
}
