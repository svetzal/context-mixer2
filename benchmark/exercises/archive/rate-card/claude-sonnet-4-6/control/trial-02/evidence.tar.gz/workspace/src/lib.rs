pub mod zones;

use std::env;
use std::fmt;
use std::fs;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl fmt::Debug for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self, f)
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<Vec<(String, Band)>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands: Vec<(String, Band)> = Vec::new();

    for (idx, raw_line) in content.lines().enumerate() {
        let line_num = idx + 1;
        let trimmed = raw_line.trim_end_matches('\r');
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = trimmed.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        bands.push((zone, Band { band_max_grams, cents }));
    }

    Ok(bands)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let all_bands = load_rate_card()?;

    // Collect bands for the requested zone in order
    let mut zone_bands: Vec<&Band> = all_bands
        .iter()
        .filter(|(z, _)| z == &parcel.zone)
        .map(|(_, b)| b)
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    // Sort ascending by band_max_grams
    zone_bands.sort_by_key(|b| b.band_max_grams);

    // Find first band where band_max_grams >= weight_grams
    let band = zone_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams);

    let band = match band {
        Some(b) => b,
        None => {
            let limit = zone_bands.last().unwrap().band_max_grams;
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn write_card(content: &str) -> NamedTempFile {
        let mut f = NamedTempFile::new().unwrap();
        f.write_all(content.as_bytes()).unwrap();
        f
    }

    fn with_card<F: FnOnce()>(content: &str, f: F) {
        let file = write_card(content);
        env::set_var("RATECARD_PATH", file.path());
        f();
        env::remove_var("RATECARD_PATH");
    }

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    #[test]
    fn domestic_first_band() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_exact_band_boundary() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&Parcel { weight_grams: 500, zone: "domestic".into() }).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_second_band() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&Parcel { weight_grams: 501, zone: "domestic".into() }).unwrap();
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
        });
    }

    #[test]
    fn domestic_heavy_surcharge() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&Parcel { weight_grams: 15000, zone: "domestic".into() }).unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
        });
    }

    #[test]
    fn international_zone_surcharge() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&Parcel { weight_grams: 200, zone: "international".into() }).unwrap();
            assert_eq!(q.base_cents, 1499);
            // 20% of 1499 = 299.8 → rounds half-up to 300
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_heavy_both_surcharges() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&Parcel { weight_grams: 15000, zone: "international".into() }).unwrap();
            assert_eq!(q.base_cents, 4999);
            // 20% of 4999 = 999.8 → rounds half-up to 1000
            assert_eq!(q.surcharge_cents, 500 + 1000);
            assert_eq!(q.total_cents, 4999 + 1500);
        });
    }

    #[test]
    fn unknown_zone() {
        with_card(SAMPLE_CARD, || {
            let err = quote(&Parcel { weight_grams: 100, zone: "lunar".into() }).unwrap_err();
            assert!(matches!(err, QuoteError::UnknownZone(z) if z == "lunar"));
        });
    }

    #[test]
    fn overweight() {
        with_card(SAMPLE_CARD, || {
            let err = quote(&Parcel { weight_grams: 25000, zone: "domestic".into() }).unwrap_err();
            assert!(matches!(err, QuoteError::Overweight { grams: 25000, limit: 20000 }));
        });
    }

    #[test]
    fn no_env_var() {
        env::remove_var("RATECARD_PATH");
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn malformed_line() {
        let card = "domestic\t500\n"; // only two fields
        with_card(card, || {
            let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
            assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
        });
    }

    #[test]
    fn malformed_line_skips_comments() {
        let card = "# comment\ndomestic\tbad\t599\n";
        with_card(card, || {
            let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
            // line 2 is the bad data line
            assert!(matches!(err, QuoteError::MalformedRateCard { line: 2 }));
        });
    }

    #[test]
    fn display_errors() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert_eq!(QuoteError::MalformedRateCard { line: 3 }.to_string(), "malformed rate card at line 3");
        assert_eq!(QuoteError::UnknownZone("foo".into()).to_string(), "unknown zone: foo");
        assert_eq!(
            QuoteError::Overweight { grams: 100, limit: 50 }.to_string(),
            "parcel 100g exceeds zone limit 50g"
        );
    }
}
