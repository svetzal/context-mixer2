pub mod zones;

use std::env;
use std::fmt;
use std::fs;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {grams}g exceeds zone limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<Vec<Band>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands = Vec::new();
    for (idx, raw_line) in contents.lines().enumerate() {
        let lineno = idx + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = raw_line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: lineno });
        }
        let band_max_grams = parts[1]
            .trim()
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: lineno })?;
        let cents = parts[2]
            .trim()
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: lineno })?;
        bands.push(Band {
            zone: parts[0].trim().to_string(),
            band_max_grams,
            cents,
        });
    }
    Ok(bands)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_rate_card()?;

    // Collect bands for the requested zone, in file order (assumed ascending by band_max_grams)
    let zone_bands: Vec<&Band> = bands.iter().filter(|b| b.zone == parcel.zone).collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    // Find first band whose band_max_grams >= weight
    let matched = zone_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams);

    let band = match matched {
        Some(b) => b,
        None => {
            let limit = zone_bands.last().unwrap().band_max_grams;
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn write_card(content: &str) -> NamedTempFile {
        let mut f = NamedTempFile::new().unwrap();
        write!(f, "{}", content).unwrap();
        f
    }

    fn set_card(f: &NamedTempFile) {
        env::set_var("RATECARD_PATH", f.path());
    }

    #[test]
    fn domestic_first_band() {
        let f = write_card("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n");
        set_card(&f);
        let q = quote(&Parcel { weight_grams: 300, zone: "domestic".into() }).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_second_band() {
        let f = write_card("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n");
        set_card(&f);
        let q = quote(&Parcel { weight_grams: 1000, zone: "domestic".into() }).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn domestic_exact_band_boundary() {
        let f = write_card("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n");
        set_card(&f);
        let q = quote(&Parcel { weight_grams: 500, zone: "domestic".into() }).unwrap();
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn heavy_surcharge_over_10kg() {
        let f = write_card("domestic\t20000\t1799\n");
        set_card(&f);
        let q = quote(&Parcel { weight_grams: 10001, zone: "domestic".into() }).unwrap();
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn no_heavy_surcharge_at_exactly_10kg() {
        let f = write_card("domestic\t20000\t1799\n");
        set_card(&f);
        let q = quote(&Parcel { weight_grams: 10000, zone: "domestic".into() }).unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn international_surcharge() {
        let f = write_card("international\t500\t1499\ninternational\t20000\t4999\n");
        set_card(&f);
        let q = quote(&Parcel { weight_grams: 300, zone: "international".into() }).unwrap();
        // 20% of 1499 = 299.8 -> rounded half-up = 300
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_and_heavy_surcharges() {
        let f = write_card("international\t20000\t4999\n");
        set_card(&f);
        let q = quote(&Parcel { weight_grams: 15000, zone: "international".into() }).unwrap();
        // 20% of 4999 = 999.8 -> 1000; plus 500 heavy = 1500
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone() {
        let f = write_card("domestic\t500\t599\n");
        set_card(&f);
        let err = quote(&Parcel { weight_grams: 100, zone: "mars".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::UnknownZone(z) if z == "mars"));
    }

    #[test]
    fn overweight() {
        let f = write_card("domestic\t500\t599\ndomestic\t2000\t899\n");
        set_card(&f);
        let err = quote(&Parcel { weight_grams: 5000, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::Overweight { grams: 5000, limit: 2000 }));
    }

    #[test]
    fn rate_card_unavailable_no_env() {
        env::remove_var("RATECARD_PATH");
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn rate_card_unavailable_bad_path() {
        env::set_var("RATECARD_PATH", "/nonexistent/path/ratecard.tsv");
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn malformed_too_few_fields() {
        let f = write_card("domestic\t500\n");
        set_card(&f);
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn malformed_bad_number() {
        let f = write_card("domestic\tabc\t599\n");
        set_card(&f);
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn malformed_line_counted_with_blanks_and_comments() {
        let f = write_card("# header\n\ndomestic\tbad\t599\n");
        set_card(&f);
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn comments_and_blank_lines_ignored() {
        let f = write_card("# zone\tmax\tcents\n\ndomestic\t500\t599\n");
        set_card(&f);
        let q = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap();
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn display_errors() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 5 }.to_string(),
            "malformed rate card at line 5"
        );
        assert_eq!(
            QuoteError::UnknownZone("mars".into()).to_string(),
            "unknown zone: mars"
        );
        assert_eq!(
            QuoteError::Overweight { grams: 5000, limit: 2000 }.to_string(),
            "parcel 5000g exceeds zone limit of 2000g"
        );
    }
}
