//! Shipping rate quote generation from a zone rate card.

/// Zone label helpers.
pub mod zones;
mod rate_card;

use std::fmt;

/// A parcel to be priced.
#[derive(Debug)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Shipping zone name (e.g. `"domestic"`, `"international"`).
    pub zone: String,
}

/// A shipping quote for a parcel.
#[derive(Debug)]
pub struct Quote {
    /// Base rate for the matched weight band in cents.
    pub base_cents: u64,
    /// Sum of all applicable surcharges in cents.
    pub surcharge_cents: u64,
    /// Total cost (`base_cents + surcharge_cents`).
    pub total_cents: u64,
    /// Upper weight limit of the matched band in grams.
    pub band_max_grams: u32,
}

/// Errors that can occur when generating a quote.
#[derive(Debug)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, or the file cannot be read.
    RateCardUnavailable,
    /// A line in the rate card is not three tab-separated fields or has non-numeric values.
    MalformedRateCard {
        /// 1-based line number of the offending line.
        line: usize,
    },
    /// The requested zone does not appear in the rate card.
    UnknownZone(String),
    /// The parcel weight exceeds the zone's heaviest band.
    Overweight {
        /// Parcel weight in grams.
        grams: u32,
        /// Zone's maximum weight in grams.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => write!(f, "malformed rate card at line {line}"),
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Calculate a shipping quote for the given parcel.
///
/// Reads the rate card from the path in `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = std::fs::read_to_string(&path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let bands = rate_card::parse(&content)?;
    let q = calculate(&bands, parcel)?;

    tracing::debug!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = q.total_cents,
        "shipping quote generated"
    );

    Ok(q)
}

fn calculate(bands: &[rate_card::Band], parcel: &Parcel) -> Result<Quote, QuoteError> {
    let zone_bands: Vec<&rate_card::Band> = bands
        .iter()
        .filter(|b| b.zone == parcel.zone)
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let matching = zone_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams);

    let band = match matching {
        Some(b) => b,
        None => {
            let limit = zone_bands
                .last()
                .map(|b| b.band_max_grams)
                .unwrap_or(0);
            return Err(QuoteError::Overweight { grams: parcel.weight_grams, limit });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use rate_card::Band;

    fn domestic_bands() -> Vec<Band> {
        vec![
            Band { zone: "domestic".into(), band_max_grams: 500, cents: 599 },
            Band { zone: "domestic".into(), band_max_grams: 2000, cents: 899 },
            Band { zone: "domestic".into(), band_max_grams: 20000, cents: 1799 },
        ]
    }

    fn international_bands() -> Vec<Band> {
        vec![
            Band { zone: "international".into(), band_max_grams: 500, cents: 1499 },
            Band { zone: "international".into(), band_max_grams: 20000, cents: 4999 },
        ]
    }

    fn all_bands() -> Vec<Band> {
        let mut b = domestic_bands();
        b.extend(international_bands());
        b
    }

    #[test]
    fn domestic_light_parcel() {
        let parcel = Parcel { weight_grams: 100, zone: "domestic".into() };
        let q = calculate(&domestic_bands(), &parcel).expect("should quote");
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_exactly_at_band_boundary() {
        let parcel = Parcel { weight_grams: 500, zone: "domestic".into() };
        let q = calculate(&domestic_bands(), &parcel).expect("should quote");
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_just_over_first_band() {
        let parcel = Parcel { weight_grams: 501, zone: "domestic".into() };
        let q = calculate(&domestic_bands(), &parcel).expect("should quote");
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn domestic_heavy_surcharge() {
        let parcel = Parcel { weight_grams: 15000, zone: "domestic".into() };
        let q = calculate(&domestic_bands(), &parcel).expect("should quote");
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn international_adds_20_percent() {
        let parcel = Parcel { weight_grams: 100, zone: "international".into() };
        let q = calculate(&international_bands(), &parcel).expect("should quote");
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300); // 20% of 1499 = 299.8, rounds to 300
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_heavy_combines_both_surcharges() {
        let parcel = Parcel { weight_grams: 15000, zone: "international".into() };
        let q = calculate(&international_bands(), &parcel).expect("should quote");
        assert_eq!(q.base_cents, 4999);
        // 20% of 4999 = 999.8, rounds to 1000; plus 500 weight surcharge
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_error() {
        let parcel = Parcel { weight_grams: 100, zone: "mars".into() };
        let err = calculate(&all_bands(), &parcel).expect_err("should error");
        assert!(matches!(err, QuoteError::UnknownZone(z) if z == "mars"));
    }

    #[test]
    fn overweight_error() {
        let parcel = Parcel { weight_grams: 25000, zone: "domestic".into() };
        let err = calculate(&domestic_bands(), &parcel).expect_err("should error");
        assert!(matches!(err, QuoteError::Overweight { grams: 25000, limit: 20000 }));
    }

    #[test]
    fn quote_error_display() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert_eq!(QuoteError::MalformedRateCard { line: 5 }.to_string(), "malformed rate card at line 5");
        assert_eq!(QuoteError::UnknownZone("mars".into()).to_string(), "unknown zone: mars");
        assert_eq!(
            QuoteError::Overweight { grams: 25000, limit: 20000 }.to_string(),
            "parcel 25000g exceeds zone limit 20000g"
        );
    }

    #[test]
    fn quote_error_is_error() {
        let e: &dyn std::error::Error = &QuoteError::RateCardUnavailable;
        assert_eq!(e.to_string(), "rate card unavailable");
    }
}
