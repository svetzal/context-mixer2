use crate::QuoteError;

#[derive(Debug)]
pub struct Band {
    pub zone: String,
    pub band_max_grams: u32,
    pub cents: u64,
}

pub fn parse(content: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();

    for (idx, raw_line) in content.lines().enumerate() {
        let line_number = idx + 1;
        let trimmed = raw_line.trim();

        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = trimmed.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = parts[0].to_string();
        let band_max_grams = parts[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = parts[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        bands.push(Band { zone, band_max_grams, cents });
    }

    Ok(bands)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_valid_card() {
        let content = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\n";
        let bands = parse(content).expect("should parse");
        assert_eq!(bands.len(), 1);
        assert_eq!(bands[0].zone, "domestic");
        assert_eq!(bands[0].band_max_grams, 500);
        assert_eq!(bands[0].cents, 599);
    }

    #[test]
    fn parse_skips_blanks_and_comments() {
        let content = "\n# comment\ndomestic\t500\t599\n";
        let bands = parse(content).expect("should parse");
        assert_eq!(bands.len(), 1);
    }

    #[test]
    fn parse_wrong_column_count() {
        let err = parse("domestic\t500\n").expect_err("should fail");
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn parse_non_numeric_grams() {
        let err = parse("domestic\tabc\t599\n").expect_err("should fail");
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn parse_line_numbers_count_blanks_and_comments() {
        let content = "# comment\n\ndomestic\tbad\t599\n";
        let err = parse(content).expect_err("should fail");
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 3 }));
    }
}
