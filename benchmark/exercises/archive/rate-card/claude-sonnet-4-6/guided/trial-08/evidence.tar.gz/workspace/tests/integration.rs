//! Integration tests for the `quote` public API.
use ratecard::{Parcel, QuoteError, quote};
use std::io::Write;
use std::sync::Mutex;
use tempfile::NamedTempFile;

// Env vars are process-global; serialize all tests that touch RATECARD_PATH.
static ENV_LOCK: Mutex<()> = Mutex::new(());

const RATE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn with_rate_card(content: &str, f: impl FnOnce()) {
    let _guard = ENV_LOCK.lock().expect("lock");
    let mut file = NamedTempFile::new().expect("temp file");
    file.write_all(content.as_bytes()).expect("write");
    let path = file.path().to_str().expect("path").to_string();
    std::env::set_var("RATECARD_PATH", &path);
    f();
    std::env::remove_var("RATECARD_PATH");
}

#[test]
fn domestic_light() {
    with_rate_card(RATE_CARD, || {
        let q = quote(&Parcel { weight_grams: 200, zone: "domestic".into() })
            .expect("should quote");
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    });
}

#[test]
fn domestic_mid_band() {
    with_rate_card(RATE_CARD, || {
        let q = quote(&Parcel { weight_grams: 1000, zone: "domestic".into() })
            .expect("should quote");
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    });
}

#[test]
fn domestic_overweight() {
    with_rate_card(RATE_CARD, || {
        let err = quote(&Parcel { weight_grams: 25000, zone: "domestic".into() })
            .expect_err("should fail");
        assert!(matches!(err, QuoteError::Overweight { grams: 25000, limit: 20000 }));
    });
}

#[test]
fn international_surcharge() {
    with_rate_card(RATE_CARD, || {
        let q = quote(&Parcel { weight_grams: 100, zone: "international".into() })
            .expect("should quote");
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    });
}

#[test]
fn unknown_zone() {
    with_rate_card(RATE_CARD, || {
        let err = quote(&Parcel { weight_grams: 100, zone: "express".into() })
            .expect_err("should fail");
        assert!(matches!(err, QuoteError::UnknownZone(z) if z == "express"));
    });
}

#[test]
fn missing_env_var() {
    let _guard = ENV_LOCK.lock().expect("lock");
    std::env::remove_var("RATECARD_PATH");
    let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() })
        .expect_err("should fail");
    assert!(matches!(err, QuoteError::RateCardUnavailable));
}

#[test]
fn unreadable_path() {
    let _guard = ENV_LOCK.lock().expect("lock");
    std::env::set_var("RATECARD_PATH", "/no/such/file/exists.tsv");
    let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() })
        .expect_err("should fail");
    std::env::remove_var("RATECARD_PATH");
    assert!(matches!(err, QuoteError::RateCardUnavailable));
}

#[test]
fn malformed_rate_card() {
    with_rate_card("# comment\ndomestic\t500\n", || {
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() })
            .expect_err("should fail");
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 2 }));
    });
}
