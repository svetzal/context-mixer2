use std::io::Write;
use std::sync::Mutex;

use ratecard::{quote, Parcel, QuoteError};
use tempfile::NamedTempFile;

// Serialize all tests that mutate RATECARD_PATH to avoid env-var races.
static ENV_LOCK: Mutex<()> = Mutex::new(());

const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

fn write_rate_card(content: &str) -> NamedTempFile {
    let mut f = NamedTempFile::new().unwrap();
    f.write_all(content.as_bytes()).unwrap();
    f
}

fn parcel(zone: &str, weight_grams: u32) -> Parcel {
    Parcel { weight_grams, zone: zone.to_string() }
}

#[test]
fn unavailable_when_env_unset() {
    let _g = ENV_LOCK.lock().unwrap();
    unsafe { std::env::remove_var("RATECARD_PATH") };
    let err = quote(&parcel("domestic", 100)).unwrap_err();
    assert!(matches!(err, QuoteError::RateCardUnavailable));
}

#[test]
fn unavailable_when_file_missing() {
    let _g = ENV_LOCK.lock().unwrap();
    unsafe { std::env::set_var("RATECARD_PATH", "/no/such/file.tsv") };
    let err = quote(&parcel("domestic", 100)).unwrap_err();
    assert!(matches!(err, QuoteError::RateCardUnavailable));
}

#[test]
fn domestic_quote_via_env() {
    let _g = ENV_LOCK.lock().unwrap();
    let f = write_rate_card(SAMPLE);
    unsafe { std::env::set_var("RATECARD_PATH", f.path()) };
    let q = quote(&parcel("domestic", 100)).unwrap();
    assert_eq!(q.base_cents, 599);
    assert_eq!(q.surcharge_cents, 0);
    assert_eq!(q.total_cents, 599);
    assert_eq!(q.band_max_grams, 500);
}

#[test]
fn international_quote_via_env() {
    let _g = ENV_LOCK.lock().unwrap();
    let f = write_rate_card(SAMPLE);
    unsafe { std::env::set_var("RATECARD_PATH", f.path()) };
    let q = quote(&parcel("international", 300)).unwrap();
    assert_eq!(q.base_cents, 1499);
    assert_eq!(q.surcharge_cents, 300);
    assert_eq!(q.total_cents, 1799);
}

#[test]
fn unknown_zone_via_env() {
    let _g = ENV_LOCK.lock().unwrap();
    let f = write_rate_card(SAMPLE);
    unsafe { std::env::set_var("RATECARD_PATH", f.path()) };
    let err = quote(&parcel("express", 100)).unwrap_err();
    assert!(matches!(err, QuoteError::UnknownZone(z) if z == "express"));
}

#[test]
fn overweight_via_env() {
    let _g = ENV_LOCK.lock().unwrap();
    let f = write_rate_card(SAMPLE);
    unsafe { std::env::set_var("RATECARD_PATH", f.path()) };
    let err = quote(&parcel("domestic", 99999)).unwrap_err();
    assert!(matches!(err, QuoteError::Overweight { grams: 99999, limit: 20000 }));
}

#[test]
fn malformed_rate_card_via_env() {
    let _g = ENV_LOCK.lock().unwrap();
    let f = write_rate_card("# comment\nbad line\n");
    unsafe { std::env::set_var("RATECARD_PATH", f.path()) };
    let err = quote(&parcel("domestic", 100)).unwrap_err();
    assert!(matches!(err, QuoteError::MalformedRateCard { line: 2 }));
}
