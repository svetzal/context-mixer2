use std::collections::HashMap;
use std::env;
use std::fs;

pub mod zones;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {grams}g exceeds zone limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug)]
struct Band {
    band_max_grams: u32,
    cents: u64,
}

fn parse_rate_card(content: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut card: HashMap<String, Vec<Band>> = HashMap::new();

    for (idx, line) in content.lines().enumerate() {
        let line_num = idx + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        card.entry(zone).or_default().push(Band { band_max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|b| b.band_max_grams);
    }

    Ok(card)
}

fn calculate_quote(
    parcel: &Parcel,
    card: &HashMap<String, Vec<Band>>,
) -> Result<Quote, QuoteError> {
    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = bands.last().map(|b| b.band_max_grams).unwrap_or(0);
            QuoteError::Overweight { grams: parcel.weight_grams, limit }
        })?;

    let base_cents = band.cents;
    let band_max_grams = band.band_max_grams;

    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    tracing::debug!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total_cents,
        "shipping quote"
    );

    Ok(Quote { base_cents, surcharge_cents, total_cents, band_max_grams })
}

/// Returns a shipping quote for `parcel` using the rate card at `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = parse_rate_card(&content)?;
    calculate_quote(parcel, &card)
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    fn card() -> HashMap<String, Vec<Band>> {
        parse_rate_card(SAMPLE).unwrap()
    }

    fn parcel(zone: &str, weight_grams: u32) -> Parcel {
        Parcel { weight_grams, zone: zone.to_string() }
    }

    #[test]
    fn domestic_first_band() {
        let q = calculate_quote(&parcel("domestic", 100), &card()).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_exact_band_boundary() {
        let q = calculate_quote(&parcel("domestic", 500), &card()).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_second_band() {
        let q = calculate_quote(&parcel("domestic", 501), &card()).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn domestic_heavy_adds_surcharge() {
        let q = calculate_quote(&parcel("domestic", 15000), &card()).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn domestic_overweight() {
        let err = calculate_quote(&parcel("domestic", 25000), &card()).unwrap_err();
        assert!(matches!(err, QuoteError::Overweight { grams: 25000, limit: 20000 }));
    }

    #[test]
    fn international_adds_twenty_percent() {
        let q = calculate_quote(&parcel("international", 100), &card()).unwrap();
        assert_eq!(q.base_cents, 1499);
        // 20% of 1499 = 299.8, rounded half-up = 300
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_heavy_both_surcharges() {
        let q = calculate_quote(&parcel("international", 15000), &card()).unwrap();
        assert_eq!(q.base_cents, 4999);
        // 20% of 4999 = 999.8, rounded half-up = 1000; plus 500 for >10000g
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone() {
        let err = calculate_quote(&parcel("express", 100), &card()).unwrap_err();
        assert!(matches!(err, QuoteError::UnknownZone(z) if z == "express"));
    }

    #[test]
    fn parse_skips_comments_and_blanks() {
        let content = "# comment\n\ndomestic\t500\t599\n";
        let c = parse_rate_card(content).unwrap();
        assert!(c.contains_key("domestic"));
    }

    #[test]
    fn parse_wrong_field_count_reports_line() {
        let content = "# header\n\ndomestic 500 599\n";
        let err = parse_rate_card(content).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn parse_non_numeric_reports_line() {
        let content = "domestic\tabc\t599\n";
        let err = parse_rate_card(content).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn quote_error_display() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 5 }.to_string(),
            "malformed rate card at line 5"
        );
        assert_eq!(
            QuoteError::UnknownZone("express".to_string()).to_string(),
            "unknown zone: express"
        );
        assert_eq!(
            QuoteError::Overweight { grams: 25000, limit: 20000 }.to_string(),
            "parcel 25000g exceeds zone limit of 20000g"
        );
    }
}
