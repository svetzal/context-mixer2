pub mod zones;

use std::fs;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug)]
struct Band {
    band_max_grams: u32,
    cents: u64,
}

fn parse_rate_card(content: &str) -> Result<Vec<(String, Band)>, QuoteError> {
    let mut bands = Vec::new();
    for (idx, raw_line) in content.lines().enumerate() {
        let line_num = idx + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = raw_line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .trim_end()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        bands.push((zone, Band { band_max_grams, cents }));
    }
    Ok(bands)
}

fn find_quote(parcel: &Parcel, bands: &[(String, Band)]) -> Result<Quote, QuoteError> {
    let mut zone_bands: Vec<&Band> = bands
        .iter()
        .filter(|(z, _)| z == &parcel.zone)
        .map(|(_, b)| b)
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.band_max_grams);

    let matching = zone_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams);

    let band = match matching {
        Some(b) => b,
        None => {
            let limit = zone_bands.last().expect("non-empty").band_max_grams;
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

/// Calculate a shipping quote for the given parcel.
///
/// Reads the rate card from the path in `RATECARD_PATH`.
///
/// # Errors
///
/// Returns [`QuoteError::RateCardUnavailable`] if the env var is unset or the file cannot be read.
/// Returns [`QuoteError::MalformedRateCard`] if any data line is not three tab-separated fields
/// with valid numbers. Returns [`QuoteError::UnknownZone`] if the zone is not in the rate card.
/// Returns [`QuoteError::Overweight`] if the parcel exceeds the zone's heaviest band.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = parse_rate_card(&content)?;
    let result = find_quote(parcel, &bands)?;
    tracing::debug!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = result.total_cents,
        "shipping quote generated"
    );
    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn bands() -> Vec<(String, Band)> {
        parse_rate_card(SAMPLE).expect("valid sample")
    }

    #[test]
    fn domestic_first_band() {
        let parcel = Parcel { weight_grams: 400, zone: "domestic".into() };
        let q = find_quote(&parcel, &bands()).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_exact_band_boundary() {
        let parcel = Parcel { weight_grams: 500, zone: "domestic".into() };
        let q = find_quote(&parcel, &bands()).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_second_band() {
        let parcel = Parcel { weight_grams: 501, zone: "domestic".into() };
        let q = find_quote(&parcel, &bands()).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn domestic_heavy_surcharge() {
        let parcel = Parcel { weight_grams: 15_000, zone: "domestic".into() };
        let q = find_quote(&parcel, &bands()).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn international_surcharge_and_no_weight_surcharge() {
        let parcel = Parcel { weight_grams: 400, zone: "international".into() };
        let q = find_quote(&parcel, &bands()).unwrap();
        assert_eq!(q.base_cents, 1499);
        // 20% of 1499 = 299.8, rounded half-up = 300
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_heavy_both_surcharges() {
        let parcel = Parcel { weight_grams: 15_000, zone: "international".into() };
        let q = find_quote(&parcel, &bands()).unwrap();
        assert_eq!(q.base_cents, 4999);
        // 20% of 4999 = 999.8, rounded half-up = 1000; plus 500 for weight
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_error() {
        let parcel = Parcel { weight_grams: 100, zone: "galactic".into() };
        match find_quote(&parcel, &bands()) {
            Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "galactic"),
            other => panic!("expected UnknownZone, got {other:?}"),
        }
    }

    #[test]
    fn overweight_error() {
        let parcel = Parcel { weight_grams: 25_000, zone: "domestic".into() };
        match find_quote(&parcel, &bands()) {
            Err(QuoteError::Overweight { grams: 25_000, limit: 20_000 }) => {}
            other => panic!("expected Overweight, got {other:?}"),
        }
    }

    #[test]
    fn malformed_wrong_field_count() {
        let bad = "domestic\t500\n";
        match parse_rate_card(bad) {
            Err(QuoteError::MalformedRateCard { line: 1 }) => {}
            other => panic!("expected MalformedRateCard line 1, got {other:?}"),
        }
    }

    #[test]
    fn malformed_bad_number() {
        let bad = "domestic\tabc\t599\n";
        match parse_rate_card(bad) {
            Err(QuoteError::MalformedRateCard { line: 1 }) => {}
            other => panic!("expected MalformedRateCard line 1, got {other:?}"),
        }
    }

    #[test]
    fn comment_and_blank_lines_counted_for_line_numbers() {
        let content = "# header\n\ndomestic\tbad\t599\n";
        match parse_rate_card(content) {
            Err(QuoteError::MalformedRateCard { line: 3 }) => {}
            other => panic!("expected MalformedRateCard line 3, got {other:?}"),
        }
    }

    #[test]
    fn display_errors() {
        assert!(QuoteError::RateCardUnavailable.to_string().contains("unavailable"));
        assert!(QuoteError::MalformedRateCard { line: 5 }.to_string().contains('5'));
        assert!(QuoteError::UnknownZone("x".into()).to_string().contains('x'));
        assert!(QuoteError::Overweight { grams: 100, limit: 50 }
            .to_string()
            .contains("100"));
    }

    #[test]
    fn weight_exactly_10000_no_surcharge() {
        let parcel = Parcel { weight_grams: 10_000, zone: "domestic".into() };
        let q = find_quote(&parcel, &bands()).unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn weight_10001_triggers_surcharge() {
        let parcel = Parcel { weight_grams: 10_001, zone: "domestic".into() };
        let q = find_quote(&parcel, &bands()).unwrap();
        assert_eq!(q.surcharge_cents, 500);
    }
}
