use ratecard::{Parcel, QuoteError, quote};
use std::io::Write as _;
use tempfile::NamedTempFile;

fn write_card(content: &str) -> NamedTempFile {
    let mut f = NamedTempFile::new().unwrap();
    f.write_all(content.as_bytes()).unwrap();
    f
}

const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

#[test]
fn quote_domestic_reads_file() {
    let f = write_card(CARD);
    std::env::set_var("RATECARD_PATH", f.path());
    let q = quote(&Parcel { weight_grams: 300, zone: "domestic".into() }).unwrap();
    assert_eq!(q.base_cents, 599);
    assert_eq!(q.total_cents, 599);
}

#[test]
fn quote_missing_env_var_returns_unavailable() {
    std::env::remove_var("RATECARD_PATH");
    match quote(&Parcel { weight_grams: 100, zone: "domestic".into() }) {
        Err(QuoteError::RateCardUnavailable) => {}
        other => panic!("expected RateCardUnavailable, got {other:?}"),
    }
}

#[test]
fn quote_bad_path_returns_unavailable() {
    std::env::set_var("RATECARD_PATH", "/no/such/file/ever.tsv");
    match quote(&Parcel { weight_grams: 100, zone: "domestic".into() }) {
        Err(QuoteError::RateCardUnavailable) => {}
        other => panic!("expected RateCardUnavailable, got {other:?}"),
    }
}

#[test]
fn quote_malformed_card_returns_error() {
    let f = write_card("domestic\tbadnum\t599\n");
    std::env::set_var("RATECARD_PATH", f.path());
    match quote(&Parcel { weight_grams: 100, zone: "domestic".into() }) {
        Err(QuoteError::MalformedRateCard { line: 1 }) => {}
        other => panic!("expected MalformedRateCard, got {other:?}"),
    }
}

#[test]
fn quote_error_implements_std_error() {
    fn needs_error(_: &dyn std::error::Error) {}
    let e = QuoteError::RateCardUnavailable;
    needs_error(&e);
}
