use ratecard::{Parcel, QuoteError, quote};
use std::io::Write as _;
use std::sync::Mutex;
use tempfile::NamedTempFile;

// Serialise tests that touch RATECARD_PATH to avoid data races.
static ENV_LOCK: Mutex<()> = Mutex::new(());

const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn write_card(content: &str) -> NamedTempFile {
    let mut f = NamedTempFile::new().expect("tempfile");
    f.write_all(content.as_bytes()).expect("write");
    f
}

#[test]
fn domestic_quote_end_to_end() {
    let _guard = ENV_LOCK.lock().unwrap();
    let f = write_card(SAMPLE_CARD);
    std::env::set_var("RATECARD_PATH", f.path());

    let p = Parcel { weight_grams: 400, zone: "domestic".into() };
    let q = quote(&p).unwrap();
    assert_eq!(q.base_cents, 599);
    assert_eq!(q.total_cents, 599);
}

#[test]
fn international_quote_end_to_end() {
    let _guard = ENV_LOCK.lock().unwrap();
    let f = write_card(SAMPLE_CARD);
    std::env::set_var("RATECARD_PATH", f.path());

    let p = Parcel { weight_grams: 300, zone: "international".into() };
    let q = quote(&p).unwrap();
    assert_eq!(q.base_cents, 1499);
    assert_eq!(q.surcharge_cents, 300);
    assert_eq!(q.total_cents, 1799);
}

#[test]
fn missing_env_var_is_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap();
    std::env::remove_var("RATECARD_PATH");

    let p = Parcel { weight_grams: 100, zone: "domestic".into() };
    assert!(matches!(quote(&p), Err(QuoteError::RateCardUnavailable)));
}

#[test]
fn nonexistent_path_is_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap();
    std::env::set_var("RATECARD_PATH", "/tmp/ratecard_does_not_exist_xyz123.tsv");

    let p = Parcel { weight_grams: 100, zone: "domestic".into() };
    assert!(matches!(quote(&p), Err(QuoteError::RateCardUnavailable)));
}

#[test]
fn malformed_card_reports_line() {
    let _guard = ENV_LOCK.lock().unwrap();
    let f = write_card("# comment\nbad line\n");
    std::env::set_var("RATECARD_PATH", f.path());

    let p = Parcel { weight_grams: 100, zone: "domestic".into() };
    assert!(matches!(
        quote(&p),
        Err(QuoteError::MalformedRateCard { line: 2 })
    ));
}
