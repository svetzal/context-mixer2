pub mod zones;

use std::env;
use std::fs;

/// A parcel to be quoted for shipping.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A shipping quote produced from a rate card.
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Errors that can occur when producing a shipping quote.
#[derive(Debug)]
pub enum QuoteError {
    /// The rate card file is missing, unreadable, or `RATECARD_PATH` is not set.
    RateCardUnavailable,
    /// A line in the rate card file could not be parsed; carries the 1-based line number.
    MalformedRateCard { line: usize },
    /// The requested zone is not present in the rate card.
    UnknownZone(String),
    /// The parcel weight exceeds the heaviest band for its zone.
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel too heavy: {grams} g exceeds limit of {limit} g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

fn parse_rate_card(content: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();
    for (idx, raw_line) in content.lines().enumerate() {
        let line_num = idx + 1;
        if raw_line.is_empty() || raw_line.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = raw_line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let band_max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        bands.push(Band {
            zone: fields[0].to_string(),
            band_max_grams,
            cents,
        });
    }
    Ok(bands)
}

fn calculate(parcel: &Parcel, bands: &[Band]) -> Result<Quote, QuoteError> {
    let mut zone_bands: Vec<&Band> = bands.iter().filter(|b| b.zone == parcel.zone).collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.band_max_grams);

    let matched = zone_bands.iter().find(|b| b.band_max_grams >= parcel.weight_grams);

    let band = match matched {
        Some(b) => b,
        None => {
            let limit = zone_bands.last().map_or(0, |b| b.band_max_grams);
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let band_max_grams = band.band_max_grams;

    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        // 20% of base_cents rounded half-up
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

/// Produce a shipping quote for `parcel` using the rate card at `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = parse_rate_card(&contents)?;
    let q = calculate(parcel, &bands)?;

    tracing::debug!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = q.total_cents,
        "shipping quote"
    );

    Ok(q)
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn bands() -> Vec<Band> {
        parse_rate_card(SAMPLE).unwrap()
    }

    #[test]
    fn domestic_small_matches_first_band() {
        let p = Parcel { weight_grams: 400, zone: "domestic".into() };
        let q = calculate(&p, &bands()).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_exact_boundary_matches_that_band() {
        let p = Parcel { weight_grams: 500, zone: "domestic".into() };
        let q = calculate(&p, &bands()).unwrap();
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_heavy_adds_weight_surcharge() {
        let p = Parcel { weight_grams: 15_000, zone: "domestic".into() };
        let q = calculate(&p, &bands()).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn international_adds_percentage_surcharge() {
        let p = Parcel { weight_grams: 400, zone: "international".into() };
        let q = calculate(&p, &bands()).unwrap();
        // base 1499, 20% = 299.8 → rounded half-up = 300
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_heavy_combines_surcharges() {
        let p = Parcel { weight_grams: 15_000, zone: "international".into() };
        let q = calculate(&p, &bands()).unwrap();
        // base 4999, 20% = 999.8 → rounded half-up = 1000, plus 500 heavy
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_returns_error() {
        let p = Parcel { weight_grams: 100, zone: "lunar".into() };
        assert!(matches!(calculate(&p, &bands()), Err(QuoteError::UnknownZone(z)) if z == "lunar"));
    }

    #[test]
    fn overweight_returns_limit() {
        let p = Parcel { weight_grams: 25_000, zone: "domestic".into() };
        assert!(
            matches!(calculate(&p, &bands()), Err(QuoteError::Overweight { grams: 25_000, limit: 20_000 }))
        );
    }

    #[test]
    fn malformed_too_few_fields() {
        let content = "domestic\t500\n";
        assert!(matches!(
            parse_rate_card(content),
            Err(QuoteError::MalformedRateCard { line: 1 })
        ));
    }

    #[test]
    fn malformed_too_many_fields() {
        let content = "domestic\t500\t599\textra\n";
        assert!(matches!(
            parse_rate_card(content),
            Err(QuoteError::MalformedRateCard { line: 1 })
        ));
    }

    #[test]
    fn malformed_bad_number_reports_correct_line() {
        let content = "# comment\ndomestic\tXXX\t599\n";
        assert!(matches!(
            parse_rate_card(content),
            Err(QuoteError::MalformedRateCard { line: 2 })
        ));
    }

    #[test]
    fn error_display_coverage() {
        assert!(!QuoteError::RateCardUnavailable.to_string().is_empty());
        assert!(!QuoteError::MalformedRateCard { line: 3 }.to_string().is_empty());
        assert!(!QuoteError::UnknownZone("x".into()).to_string().is_empty());
        assert!(!QuoteError::Overweight { grams: 1, limit: 0 }.to_string().is_empty());
    }
}
