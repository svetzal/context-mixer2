pub mod zones;

use std::fmt;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {grams}g exceeds zone limit of {limit}g")
            }
        }
    }
}

impl fmt::Debug for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self, f)
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<Vec<(String, Band)>, QuoteError> {
    let path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = std::fs::read_to_string(&path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands: Vec<(String, Band)> = Vec::new();

    for (idx, raw_line) in content.lines().enumerate() {
        let line_num = idx + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = raw_line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        bands.push((zone, Band { band_max_grams, cents }));
    }

    Ok(bands)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let all_bands = load_rate_card()?;

    let zone_bands: Vec<&Band> = all_bands
        .iter()
        .filter(|(z, _)| z == &parcel.zone)
        .map(|(_, b)| b)
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let matching_band = zone_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams);

    let band = match matching_band {
        Some(b) => b,
        None => {
            let limit = zone_bands.iter().map(|b| b.band_max_grams).max().unwrap();
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        // round half-up: (base * 20 + 50) / 100
        let intl_surcharge = (base_cents * 20 + 50) / 100;
        surcharge_cents += intl_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    tracing::debug!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write as IoWrite;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn write_card(content: &str) -> NamedTempFile {
        let mut f = NamedTempFile::new().unwrap();
        f.write_all(content.as_bytes()).unwrap();
        f
    }

    fn with_card<F: FnOnce()>(content: &str, f: F) {
        let _guard = ENV_LOCK.lock().unwrap();
        let file = write_card(content);
        std::env::set_var("RATECARD_PATH", file.path());
        f();
        std::env::remove_var("RATECARD_PATH");
    }

    const CARD: &str = "domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\ninternational\t500\t1499\ninternational\t20000\t4999\n";

    #[test]
    fn domestic_light_parcel() {
        with_card(CARD, || {
            let p = Parcel { weight_grams: 300, zone: "domestic".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_exactly_at_band_boundary() {
        with_card(CARD, || {
            let p = Parcel { weight_grams: 500, zone: "domestic".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_medium_band() {
        with_card(CARD, || {
            let p = Parcel { weight_grams: 501, zone: "domestic".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
        });
    }

    #[test]
    fn domestic_overweight_surcharge() {
        with_card(CARD, || {
            let p = Parcel { weight_grams: 15000, zone: "domestic".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
        });
    }

    #[test]
    fn international_surcharge() {
        with_card(CARD, || {
            let p = Parcel { weight_grams: 400, zone: "international".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 1499);
            // 20% of 1499 rounded half-up = 299.8 -> 300
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_heavy_combined_surcharges() {
        with_card(CARD, || {
            let p = Parcel { weight_grams: 15000, zone: "international".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 4999);
            // 500 heavy + 20% of 4999 rounded half-up: (4999*20+50)/100 = (99980+50)/100 = 100030/100 = 1000
            assert_eq!(q.surcharge_cents, 500 + 1000);
            assert_eq!(q.total_cents, 4999 + 1500);
        });
    }

    #[test]
    fn unknown_zone() {
        with_card(CARD, || {
            let p = Parcel { weight_grams: 100, zone: "mars".into() };
            match quote(&p) {
                Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "mars"),
                other => panic!("expected UnknownZone, got: {other:?}"),
            }
        });
    }

    #[test]
    fn overweight() {
        with_card(CARD, || {
            let p = Parcel { weight_grams: 25000, zone: "domestic".into() };
            match quote(&p) {
                Err(QuoteError::Overweight { grams, limit }) => {
                    assert_eq!(grams, 25000);
                    assert_eq!(limit, 20000);
                }
                other => panic!("expected Overweight, got: {other:?}"),
            }
        });
    }

    #[test]
    fn missing_env_var() {
        let _guard = ENV_LOCK.lock().unwrap();
        std::env::remove_var("RATECARD_PATH");
        let p = Parcel { weight_grams: 100, zone: "domestic".into() };
        assert!(matches!(quote(&p), Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn unreadable_path() {
        let _guard = ENV_LOCK.lock().unwrap();
        std::env::set_var("RATECARD_PATH", "/nonexistent/path/ratecard.tsv");
        let p = Parcel { weight_grams: 100, zone: "domestic".into() };
        let result = quote(&p);
        std::env::remove_var("RATECARD_PATH");
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn malformed_wrong_field_count() {
        with_card("domestic\t500\n", || {
            let p = Parcel { weight_grams: 100, zone: "domestic".into() };
            match quote(&p) {
                Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
                other => panic!("expected MalformedRateCard, got: {other:?}"),
            }
        });
    }

    #[test]
    fn malformed_bad_number() {
        with_card("domestic\tabc\t599\n", || {
            let p = Parcel { weight_grams: 100, zone: "domestic".into() };
            match quote(&p) {
                Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
                other => panic!("expected MalformedRateCard, got: {other:?}"),
            }
        });
    }

    #[test]
    fn comments_and_blanks_skipped_but_counted() {
        let card = "# zone\tband_max_grams\tcents\n\ndomestic\t500\t599\n";
        with_card(card, || {
            let p = Parcel { weight_grams: 100, zone: "domestic".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 599);
        });
    }

    #[test]
    fn malformed_line_number_after_comments() {
        let card = "# header\n\nbad line here\n";
        with_card(card, || {
            let p = Parcel { weight_grams: 100, zone: "domestic".into() };
            match quote(&p) {
                Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
                other => panic!("expected MalformedRateCard, got: {other:?}"),
            }
        });
    }

    #[test]
    fn display_errors() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert_eq!(QuoteError::MalformedRateCard { line: 5 }.to_string(), "malformed rate card at line 5");
        assert_eq!(QuoteError::UnknownZone("mars".into()).to_string(), "unknown zone: mars");
        assert_eq!(
            QuoteError::Overweight { grams: 25000, limit: 20000 }.to_string(),
            "parcel 25000g exceeds zone limit of 20000g"
        );
    }
}
