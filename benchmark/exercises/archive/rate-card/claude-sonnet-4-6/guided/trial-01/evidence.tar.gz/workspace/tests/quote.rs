use ratecard::{Parcel, QuoteError, quote};
use std::io::Write;
use std::sync::Mutex;
use tempfile::NamedTempFile;

static ENV_LOCK: Mutex<()> = Mutex::new(());

fn write_card(content: &str) -> NamedTempFile {
    let mut f = NamedTempFile::new().unwrap();
    f.write_all(content.as_bytes()).unwrap();
    f
}

const STANDARD_CARD: &str = "\
# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n\
";

fn with_card<F: FnOnce() -> R, R>(content: &str, f: F) -> R {
    let file = write_card(content);
    let _lock = ENV_LOCK.lock().unwrap();
    std::env::set_var("RATECARD_PATH", file.path());
    let result = f();
    std::env::remove_var("RATECARD_PATH");
    result
}

#[test]
fn domestic_first_band() {
    with_card(STANDARD_CARD, || {
        let q = quote(&Parcel { weight_grams: 500, zone: "domestic".into() }).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    });
}

#[test]
fn domestic_second_band() {
    with_card(STANDARD_CARD, || {
        let q = quote(&Parcel { weight_grams: 501, zone: "domestic".into() }).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    });
}

#[test]
fn domestic_heavy_surcharge() {
    with_card(STANDARD_CARD, || {
        let q = quote(&Parcel { weight_grams: 10001, zone: "domestic".into() }).unwrap();
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, q.base_cents + 500);
    });
}

#[test]
fn domestic_at_10000_no_surcharge() {
    with_card(STANDARD_CARD, || {
        let q = quote(&Parcel { weight_grams: 10000, zone: "domestic".into() }).unwrap();
        assert_eq!(q.surcharge_cents, 0);
    });
}

#[test]
fn international_adds_twenty_percent() {
    with_card(STANDARD_CARD, || {
        let q = quote(&Parcel { weight_grams: 500, zone: "international".into() }).unwrap();
        assert_eq!(q.base_cents, 1499);
        // 20% of 1499 = 299.8 → rounds half-up to 300
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    });
}

#[test]
fn international_heavy_both_surcharges() {
    with_card(STANDARD_CARD, || {
        let q = quote(&Parcel { weight_grams: 15000, zone: "international".into() }).unwrap();
        assert_eq!(q.base_cents, 4999);
        // 20% of 4999 = 999.8 → rounds to 1000
        let intl_surcharge = (4999u64 * 20 + 50) / 100;
        assert_eq!(q.surcharge_cents, 500 + intl_surcharge);
        assert_eq!(q.total_cents, 4999 + 500 + intl_surcharge);
    });
}

#[test]
fn unknown_zone() {
    with_card(STANDARD_CARD, || {
        let err = quote(&Parcel { weight_grams: 100, zone: "express".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::UnknownZone(z) if z == "express"));
    });
}

#[test]
fn overweight() {
    with_card(STANDARD_CARD, || {
        let err = quote(&Parcel { weight_grams: 20001, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::Overweight { grams: 20001, limit: 20000 }));
    });
}

#[test]
fn rate_card_unavailable_when_env_unset() {
    let _lock = ENV_LOCK.lock().unwrap();
    std::env::remove_var("RATECARD_PATH");
    let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
    assert!(matches!(err, QuoteError::RateCardUnavailable));
}

#[test]
fn rate_card_unavailable_when_file_missing() {
    let _lock = ENV_LOCK.lock().unwrap();
    std::env::set_var("RATECARD_PATH", "/nonexistent/path/to/ratecard.tsv");
    let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
    assert!(matches!(err, QuoteError::RateCardUnavailable));
    std::env::remove_var("RATECARD_PATH");
}

#[test]
fn malformed_wrong_columns() {
    with_card("domestic\t500\n", || {
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    });
}

#[test]
fn malformed_bad_number_counts_all_lines() {
    let card = "# comment\n\ndomestic\t500\tnot_a_number\n";
    with_card(card, || {
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        // line 3 is the malformed data line (comment is line 1, blank is line 2)
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 3 }));
    });
}

#[test]
fn display_errors() {
    assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
    assert_eq!(
        QuoteError::MalformedRateCard { line: 5 }.to_string(),
        "malformed rate card at line 5"
    );
    assert_eq!(
        QuoteError::UnknownZone("express".into()).to_string(),
        "unknown zone: express"
    );
    assert_eq!(
        QuoteError::Overweight { grams: 25000, limit: 20000 }.to_string(),
        "parcel 25000g exceeds zone limit 20000g"
    );
}

#[test]
fn error_is_std_error() {
    fn takes_error(_: &dyn std::error::Error) {}
    takes_error(&QuoteError::RateCardUnavailable);
}
