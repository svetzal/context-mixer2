use std::env;
use std::fmt;
use std::fs;

pub mod zones;

/// A parcel to be quoted.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A shipping quote result.
#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Errors that can occur during quote calculation.
#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => write!(f, "malformed rate card at line {line}"),
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams} g exceeds zone limit {limit} g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug)]
struct Band {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

fn parse_rate_card(content: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();
    for (idx, line) in content.lines().enumerate() {
        let line_num = idx + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let band_max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        bands.push(Band {
            zone: fields[0].to_string(),
            band_max_grams,
            cents,
        });
    }
    Ok(bands)
}

fn calculate_quote(parcel: &Parcel, bands: &[Band]) -> Result<Quote, QuoteError> {
    let mut zone_bands: Vec<&Band> = bands.iter().filter(|b| b.zone == parcel.zone).collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.band_max_grams);

    let mut last_limit = 0u32;
    let mut found: Option<&Band> = None;
    for b in &zone_bands {
        last_limit = b.band_max_grams;
        if b.band_max_grams >= parcel.weight_grams {
            found = Some(b);
            break;
        }
    }

    let band = match found {
        Some(b) => b,
        None => {
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: last_limit,
            })
        }
    };

    let base_cents = band.cents;
    let band_max_grams = band.band_max_grams;

    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up: (n * 20 + 50) / 100
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

/// Calculate a shipping quote for the given parcel.
///
/// Reads the rate card from the path in the `RATECARD_PATH` environment variable.
///
/// # Errors
///
/// Returns [`QuoteError::RateCardUnavailable`] when `RATECARD_PATH` is unset or the file
/// cannot be read, [`QuoteError::MalformedRateCard`] for unparseable lines,
/// [`QuoteError::UnknownZone`] when the zone has no bands, and [`QuoteError::Overweight`]
/// when the parcel exceeds the zone's heaviest band.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = parse_rate_card(&content)?;
    let result = calculate_quote(parcel, &bands);

    match &result {
        Ok(q) => tracing::debug!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            total_cents = q.total_cents,
            "quote calculated"
        ),
        Err(e) => tracing::debug!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            error = %e,
            "quote failed"
        ),
    }

    result
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn sample_bands() -> Vec<Band> {
        parse_rate_card(SAMPLE_CARD).unwrap()
    }

    #[test]
    fn parse_valid_card() {
        let bands = sample_bands();
        assert_eq!(bands.len(), 5);
        assert_eq!(bands[0].zone, "domestic");
        assert_eq!(bands[0].band_max_grams, 500);
        assert_eq!(bands[0].cents, 599);
    }

    #[test]
    fn parse_skips_comments_and_blanks() {
        let content = "\n# comment\ndomestic\t500\t599\n";
        let bands = parse_rate_card(content).unwrap();
        assert_eq!(bands.len(), 1);
    }

    #[test]
    fn parse_malformed_wrong_field_count() {
        let content = "domestic\t500\n";
        let err = parse_rate_card(content).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn parse_malformed_bad_number() {
        let content = "domestic\tabc\t599\n";
        let err = parse_rate_card(content).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn parse_malformed_line_number_counts_all_lines() {
        // comments and blanks count toward line numbers
        let content = "# comment\n\ndomestic\tbad\t599\n";
        let err = parse_rate_card(content).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn domestic_light_parcel() {
        let bands = sample_bands();
        let parcel = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let q = calculate_quote(&parcel, &bands).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_exact_band_boundary() {
        let bands = sample_bands();
        let parcel = Parcel { weight_grams: 500, zone: "domestic".to_string() };
        let q = calculate_quote(&parcel, &bands).unwrap();
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn domestic_heavy_surcharge() {
        let bands = sample_bands();
        let parcel = Parcel { weight_grams: 15_000, zone: "domestic".to_string() };
        let q = calculate_quote(&parcel, &bands).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn international_base_surcharge() {
        let bands = sample_bands();
        // 20% of 1499 = 299.8, rounded half-up = 300
        let parcel = Parcel { weight_grams: 400, zone: "international".to_string() };
        let q = calculate_quote(&parcel, &bands).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_heavy_all_surcharges() {
        let bands = sample_bands();
        // base=4999, heavy=+500, international=20% of 4999=999.8→1000
        let parcel = Parcel { weight_grams: 15_000, zone: "international".to_string() };
        let q = calculate_quote(&parcel, &bands).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_error() {
        let bands = sample_bands();
        let parcel = Parcel { weight_grams: 100, zone: "express".to_string() };
        let err = calculate_quote(&parcel, &bands).unwrap_err();
        assert!(matches!(err, QuoteError::UnknownZone(z) if z == "express"));
    }

    #[test]
    fn overweight_error() {
        let bands = sample_bands();
        let parcel = Parcel { weight_grams: 25_000, zone: "domestic".to_string() };
        let err = calculate_quote(&parcel, &bands).unwrap_err();
        assert!(matches!(err, QuoteError::Overweight { grams: 25_000, limit: 20_000 }));
    }

    #[test]
    fn error_display_rate_card_unavailable() {
        assert!(!QuoteError::RateCardUnavailable.to_string().is_empty());
    }

    #[test]
    fn error_display_malformed_contains_line() {
        let s = QuoteError::MalformedRateCard { line: 5 }.to_string();
        assert!(s.contains('5'));
    }

    #[test]
    fn error_display_unknown_zone_contains_name() {
        let s = QuoteError::UnknownZone("express".to_string()).to_string();
        assert!(s.contains("express"));
    }

    #[test]
    fn error_display_overweight_contains_weight() {
        let s = QuoteError::Overweight { grams: 25_000, limit: 20_000 }.to_string();
        assert!(s.contains("25000"));
    }

    #[test]
    fn quote_error_implements_error_trait() {
        fn accepts_error(_: &dyn std::error::Error) {}
        accepts_error(&QuoteError::RateCardUnavailable);
    }
}
