use std::io::Write;
use std::sync::Mutex;

use ratecard::{quote, Parcel, QuoteError};
use tempfile::NamedTempFile;

// Serialize env-var-touching tests to avoid race conditions between threads.
static ENV_LOCK: Mutex<()> = Mutex::new(());

const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn write_rate_card(content: &str) -> NamedTempFile {
    let mut f = NamedTempFile::new().unwrap();
    f.write_all(content.as_bytes()).unwrap();
    f
}

#[test]
fn quote_domestic_light() {
    let _guard = ENV_LOCK.lock().unwrap();
    let f = write_rate_card(SAMPLE_CARD);
    std::env::set_var("RATECARD_PATH", f.path());
    let q = quote(&Parcel { weight_grams: 400, zone: "domestic".to_string() }).unwrap();
    assert_eq!(q.total_cents, 599);
    assert_eq!(q.surcharge_cents, 0);
}

#[test]
fn quote_international_applies_surcharge() {
    let _guard = ENV_LOCK.lock().unwrap();
    let f = write_rate_card(SAMPLE_CARD);
    std::env::set_var("RATECARD_PATH", f.path());
    let q = quote(&Parcel { weight_grams: 400, zone: "international".to_string() }).unwrap();
    assert_eq!(q.base_cents, 1499);
    assert_eq!(q.surcharge_cents, 300);
    assert_eq!(q.total_cents, 1799);
}

#[test]
fn quote_no_env_var_returns_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap();
    std::env::remove_var("RATECARD_PATH");
    let err = quote(&Parcel { weight_grams: 100, zone: "domestic".to_string() }).unwrap_err();
    assert!(matches!(err, QuoteError::RateCardUnavailable));
}

#[test]
fn quote_bad_path_returns_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap();
    std::env::set_var("RATECARD_PATH", "/nonexistent/ratecard.tsv");
    let err = quote(&Parcel { weight_grams: 100, zone: "domestic".to_string() }).unwrap_err();
    assert!(matches!(err, QuoteError::RateCardUnavailable));
}

#[test]
fn quote_malformed_card_returns_error() {
    let _guard = ENV_LOCK.lock().unwrap();
    let f = write_rate_card("domestic\t500\n");
    std::env::set_var("RATECARD_PATH", f.path());
    let err = quote(&Parcel { weight_grams: 100, zone: "domestic".to_string() }).unwrap_err();
    assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
}

#[test]
fn quote_unknown_zone() {
    let _guard = ENV_LOCK.lock().unwrap();
    let f = write_rate_card(SAMPLE_CARD);
    std::env::set_var("RATECARD_PATH", f.path());
    let err = quote(&Parcel { weight_grams: 100, zone: "express".to_string() }).unwrap_err();
    assert!(matches!(err, QuoteError::UnknownZone(z) if z == "express"));
}

#[test]
fn quote_overweight() {
    let _guard = ENV_LOCK.lock().unwrap();
    let f = write_rate_card(SAMPLE_CARD);
    std::env::set_var("RATECARD_PATH", f.path());
    let err =
        quote(&Parcel { weight_grams: 25_000, zone: "domestic".to_string() }).unwrap_err();
    assert!(matches!(err, QuoteError::Overweight { grams: 25_000, limit: 20_000 }));
}
