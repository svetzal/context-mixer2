pub mod zones;

use std::env;
use std::fmt;
use std::fs;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weighs {grams}g, exceeds zone limit of {limit}g")
            }
        }
    }
}

impl fmt::Debug for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self, f)
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<Vec<Band>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&content)
}

fn parse_rate_card(content: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();
    for (i, line) in content.lines().enumerate() {
        let line_num = i + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = trimmed.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let zone = parts[0].to_string();
        let band_max_grams = parts[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = parts[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        bands.push(Band { zone, band_max_grams, cents });
    }
    Ok(bands)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_rate_card()?;

    let mut zone_bands: Vec<&Band> = bands.iter().filter(|b| b.zone == parcel.zone).collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.band_max_grams);

    let matching = zone_bands.iter().find(|b| b.band_max_grams >= parcel.weight_grams);

    let band = match matching {
        Some(b) => b,
        None => {
            let limit = zone_bands.last().unwrap().band_max_grams;
            return Err(QuoteError::Overweight { grams: parcel.weight_grams, limit });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    tracing::debug!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write as IoWrite;
    use tempfile::NamedTempFile;

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn with_card(content: &str, f: impl FnOnce()) {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        let path = file.path().to_str().unwrap().to_string();
        env::set_var("RATECARD_PATH", &path);
        f();
        env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn parse_rejects_missing_tab_fields() {
        let result = parse_rate_card("domestic 500 599\n");
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 1 })));
    }

    #[test]
    fn parse_rejects_non_numeric_weight() {
        let result = parse_rate_card("domestic\txxx\t599\n");
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 1 })));
    }

    #[test]
    fn parse_rejects_non_numeric_cents() {
        let result = parse_rate_card("domestic\t500\txxx\n");
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 1 })));
    }

    #[test]
    fn parse_skips_comments_and_blanks() {
        let result = parse_rate_card(SAMPLE_CARD).unwrap();
        assert_eq!(result.len(), 5);
    }

    #[test]
    fn malformed_line_number_counts_all_lines() {
        // comment is line 1, blank is line 2, bad line is line 3
        let card = "# comment\n\nbad line\n";
        let result = parse_rate_card(card);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 3 })));
    }

    #[test]
    fn domestic_first_band() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel { weight_grams: 500, zone: "domestic".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_second_band() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel { weight_grams: 501, zone: "domestic".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
        });
    }

    #[test]
    fn domestic_heavy_surcharge() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel { weight_grams: 10_001, zone: "domestic".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
        });
    }

    #[test]
    fn international_adds_twenty_percent() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel { weight_grams: 500, zone: "international".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 1499);
            // 1499 * 20% = 299.8, rounded half-up = 300
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_heavy_both_surcharges() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel { weight_grams: 15_000, zone: "international".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 4999);
            // 4999 * 20% = 999.8, rounded half-up = 1000; plus 500 for heavy
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
        });
    }

    #[test]
    fn unknown_zone_error() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel { weight_grams: 100, zone: "galactic".into() };
            assert!(matches!(quote(&p), Err(QuoteError::UnknownZone(z)) if z == "galactic"));
        });
    }

    #[test]
    fn overweight_error() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel { weight_grams: 20_001, zone: "domestic".into() };
            assert!(matches!(
                quote(&p),
                Err(QuoteError::Overweight { grams: 20_001, limit: 20_000 })
            ));
        });
    }

    #[test]
    fn missing_env_var_is_unavailable() {
        env::remove_var("RATECARD_PATH");
        let p = Parcel { weight_grams: 100, zone: "domestic".into() };
        assert!(matches!(quote(&p), Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn unreadable_path_is_unavailable() {
        env::set_var("RATECARD_PATH", "/nonexistent/path/to/ratecard.tsv");
        let p = Parcel { weight_grams: 100, zone: "domestic".into() };
        assert!(matches!(quote(&p), Err(QuoteError::RateCardUnavailable)));
        env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn error_display_messages() {
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "rate card is unavailable"
        );
        assert_eq!(
            QuoteError::MalformedRateCard { line: 5 }.to_string(),
            "malformed rate card at line 5"
        );
        assert_eq!(
            QuoteError::UnknownZone("express".into()).to_string(),
            "unknown zone: express"
        );
        assert_eq!(
            QuoteError::Overweight { grams: 25_000, limit: 20_000 }.to_string(),
            "parcel weighs 25000g, exceeds zone limit of 20000g"
        );
    }

    #[test]
    fn exactly_at_band_boundary_matches_that_band() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel { weight_grams: 2000, zone: "domestic".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.band_max_grams, 2000);
            assert_eq!(q.base_cents, 899);
        });
    }

    #[test]
    fn weight_exactly_10000_no_heavy_surcharge() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel { weight_grams: 10_000, zone: "domestic".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.surcharge_cents, 0);
        });
    }
}
