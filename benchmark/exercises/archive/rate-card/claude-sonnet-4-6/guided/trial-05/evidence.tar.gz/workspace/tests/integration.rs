use ratecard::{Parcel, QuoteError, quote};
use std::io::Write;
use tempfile::NamedTempFile;

fn write_card(content: &str) -> NamedTempFile {
    let mut f = NamedTempFile::new().unwrap();
    f.write_all(content.as_bytes()).unwrap();
    f
}

const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

#[test]
fn quote_domestic_small() {
    let f = write_card(CARD);
    std::env::set_var("RATECARD_PATH", f.path());
    let q = quote(&Parcel { weight_grams: 300, zone: "domestic".into() }).unwrap();
    assert_eq!(q.total_cents, 599);
}

#[test]
fn quote_missing_env_var() {
    std::env::remove_var("RATECARD_PATH");
    let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
    assert!(matches!(err, QuoteError::RateCardUnavailable));
}

#[test]
fn quote_missing_file() {
    std::env::set_var("RATECARD_PATH", "/nonexistent/path/ratecard.tsv");
    let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
    assert!(matches!(err, QuoteError::RateCardUnavailable));
}
