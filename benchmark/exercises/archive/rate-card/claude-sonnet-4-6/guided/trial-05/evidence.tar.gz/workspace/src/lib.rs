pub mod zones;

use std::env;
use std::fmt;
use std::fs;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug)]
struct Band {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

fn parse_rate_card(content: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();
    for (idx, line) in content.lines().enumerate() {
        let line_num = idx + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let band_max_grams = parts[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = parts[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        bands.push(Band {
            zone: parts[0].to_string(),
            band_max_grams,
            cents,
        });
    }
    Ok(bands)
}

fn compute_quote(parcel: &Parcel, bands: &[Band]) -> Result<Quote, QuoteError> {
    let mut zone_bands: Vec<&Band> = bands.iter().filter(|b| b.zone == parcel.zone).collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.band_max_grams);

    let matching = zone_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams);

    let band = match matching {
        Some(b) => b,
        None => {
            let limit = zone_bands
                .last()
                .map(|b| b.band_max_grams)
                .unwrap_or(0);
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

/// Calculate a shipping quote for `parcel` using the rate card at `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = parse_rate_card(&content)?;
    let result = compute_quote(parcel, &bands)?;

    tracing::debug!(
        zone = parcel.zone.as_str(),
        weight_grams = parcel.weight_grams,
        total_cents = result.total_cents,
        "quote computed"
    );

    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn bands() -> Vec<Band> {
        parse_rate_card(SAMPLE).unwrap()
    }

    fn parcel(zone: &str, weight_grams: u32) -> Parcel {
        Parcel {
            zone: zone.to_string(),
            weight_grams,
        }
    }

    #[test]
    fn domestic_first_band() {
        let q = compute_quote(&parcel("domestic", 499), &bands()).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_exact_band_boundary() {
        let q = compute_quote(&parcel("domestic", 500), &bands()).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_second_band() {
        let q = compute_quote(&parcel("domestic", 501), &bands()).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn domestic_heavy_surcharge() {
        let q = compute_quote(&parcel("domestic", 15_000), &bands()).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn international_surcharge_roundup() {
        // base = 1499, 20% = 299.8 → rounded half-up = 300
        let q = compute_quote(&parcel("international", 400), &bands()).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_heavy_both_surcharges() {
        // base = 4999, 20% = 999.8 → 1000; plus weight surcharge 500
        let q = compute_quote(&parcel("international", 15_000), &bands()).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn overweight_returns_limit() {
        let err = compute_quote(&parcel("domestic", 25_000), &bands()).unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 25_000);
                assert_eq!(limit, 20_000);
            }
            _ => panic!("expected Overweight"),
        }
    }

    #[test]
    fn unknown_zone() {
        let err = compute_quote(&parcel("express", 100), &bands()).unwrap_err();
        match err {
            QuoteError::UnknownZone(z) => assert_eq!(z, "express"),
            _ => panic!("expected UnknownZone"),
        }
    }

    #[test]
    fn malformed_wrong_field_count() {
        let content = "domestic\t500\n";
        let err = parse_rate_card(content).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            _ => panic!("expected MalformedRateCard"),
        }
    }

    #[test]
    fn malformed_bad_number() {
        let content = "domestic\tabc\t599\n";
        let err = parse_rate_card(content).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            _ => panic!("expected MalformedRateCard"),
        }
    }

    #[test]
    fn malformed_line_number_counts_comments() {
        let content = "# comment\ndomestic\tbad\t599\n";
        let err = parse_rate_card(content).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 2),
            _ => panic!("expected MalformedRateCard"),
        }
    }

    #[test]
    fn display_errors() {
        assert!(!QuoteError::RateCardUnavailable.to_string().is_empty());
        assert!(!QuoteError::MalformedRateCard { line: 3 }.to_string().is_empty());
        assert!(!QuoteError::UnknownZone("x".into()).to_string().is_empty());
        assert!(!QuoteError::Overweight { grams: 1, limit: 2 }.to_string().is_empty());
    }

    #[test]
    fn error_is_std_error() {
        let e: &dyn std::error::Error = &QuoteError::RateCardUnavailable;
        let _ = e.to_string();
    }
}
