//! Shipping rate quotes from a zone-based rate card.

pub mod rate_card;
/// Zone label utilities.
pub mod zones;

use std::fmt;
use tracing::debug;

/// A parcel to be quoted.
pub struct Parcel {
    /// Weight of the parcel in grams.
    pub weight_grams: u32,
    /// Destination zone name (e.g. `"domestic"`, `"international"`).
    pub zone: String,
}

/// A shipping quote for a parcel.
#[derive(Debug)]
pub struct Quote {
    /// Base rate from the matched band, in cents.
    pub base_cents: u64,
    /// Total surcharges applied, in cents.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// Upper weight threshold of the matched band, in grams.
    pub band_max_grams: u32,
}

/// Errors that can occur when generating a quote.
#[derive(Debug)]
pub enum QuoteError {
    /// The rate card file could not be found or read.
    RateCardUnavailable,
    /// A line in the rate card could not be parsed.
    MalformedRateCard {
        /// 1-based line number of the offending line.
        line: usize,
    },
    /// The requested zone does not appear in the rate card.
    UnknownZone(String),
    /// The parcel weight exceeds all bands for the zone.
    Overweight {
        /// Actual parcel weight in grams.
        grams: u32,
        /// Largest band threshold for the zone, in grams.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Calculate a shipping quote for the given parcel.
///
/// Reads the rate card from the path in the `RATECARD_PATH` environment variable.
///
/// # Errors
///
/// Returns [`QuoteError`] when the rate card is unavailable or malformed, the
/// zone is not found, or the parcel is too heavy for any band.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = std::fs::read_to_string(&path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = rate_card::parse(&content)?;
    let result = quote_with_bands(parcel, &bands);

    if let Ok(ref q) = result {
        debug!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            total_cents = q.total_cents,
            "quote calculated"
        );
    }

    result
}

/// Pure quote calculation given a pre-parsed set of bands.
pub fn quote_with_bands(
    parcel: &Parcel,
    bands: &[rate_card::Band],
) -> Result<Quote, QuoteError> {
    let zone_bands: Vec<&rate_card::Band> = bands
        .iter()
        .filter(|b| b.zone == parcel.zone)
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let matching = zone_bands.iter().find(|b| b.band_max_grams >= parcel.weight_grams);

    let band = match matching {
        Some(b) => *b,
        None => {
            let limit = zone_bands
                .iter()
                .map(|b| b.band_max_grams)
                .max()
                .unwrap_or(0);
            return Err(QuoteError::Overweight { grams: parcel.weight_grams, limit });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use rate_card::{parse, Band};

    fn sample_bands() -> Vec<Band> {
        parse(
            "domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n\
             international\t500\t1499\ninternational\t20000\t4999\n",
        )
        .unwrap()
    }

    #[test]
    fn domestic_light_parcel_matches_first_band() {
        let parcel = Parcel { weight_grams: 300, zone: "domestic".into() };
        let q = quote_with_bands(&parcel, &sample_bands()).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_exactly_at_band_boundary() {
        let parcel = Parcel { weight_grams: 500, zone: "domestic".into() };
        let q = quote_with_bands(&parcel, &sample_bands()).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_heavy_parcel_gets_overweight_surcharge() {
        let parcel = Parcel { weight_grams: 15_000, zone: "domestic".into() };
        let q = quote_with_bands(&parcel, &sample_bands()).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn international_adds_twenty_percent() {
        let parcel = Parcel { weight_grams: 400, zone: "international".into() };
        let q = quote_with_bands(&parcel, &sample_bands()).unwrap();
        assert_eq!(q.base_cents, 1499);
        // 20% of 1499 = 299.8, rounded half-up = 300
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_heavy_gets_both_surcharges() {
        let parcel = Parcel { weight_grams: 15_000, zone: "international".into() };
        let q = quote_with_bands(&parcel, &sample_bands()).unwrap();
        // base = 4999, overweight = 500, intl = 20% of 4999 = 999.8 → 1000
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_error() {
        let parcel = Parcel { weight_grams: 100, zone: "nowhere".into() };
        let err = quote_with_bands(&parcel, &sample_bands()).unwrap_err();
        assert!(matches!(err, QuoteError::UnknownZone(z) if z == "nowhere"));
    }

    #[test]
    fn overweight_carries_limit() {
        let parcel = Parcel { weight_grams: 25_000, zone: "domestic".into() };
        let err = quote_with_bands(&parcel, &sample_bands()).unwrap_err();
        assert!(matches!(err, QuoteError::Overweight { grams: 25_000, limit: 20_000 }));
    }

    #[test]
    fn exactly_at_weight_boundary_is_not_overweight() {
        let parcel = Parcel { weight_grams: 20_000, zone: "domestic".into() };
        let q = quote_with_bands(&parcel, &sample_bands()).unwrap();
        assert_eq!(q.band_max_grams, 20_000);
    }

    #[test]
    fn exactly_10000g_does_not_trigger_overweight_surcharge() {
        let parcel = Parcel { weight_grams: 10_000, zone: "domestic".into() };
        let q = quote_with_bands(&parcel, &sample_bands()).unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn one_gram_above_10000_triggers_overweight_surcharge() {
        let parcel = Parcel { weight_grams: 10_001, zone: "domestic".into() };
        let q = quote_with_bands(&parcel, &sample_bands()).unwrap();
        assert_eq!(q.surcharge_cents, 500);
    }

    #[test]
    fn quote_error_display_unknown_zone() {
        let e = QuoteError::UnknownZone("express".into());
        assert!(e.to_string().contains("express"));
    }

    #[test]
    fn quote_error_display_overweight() {
        let e = QuoteError::Overweight { grams: 30_000, limit: 20_000 };
        let s = e.to_string();
        assert!(s.contains("30000") && s.contains("20000"));
    }

    #[test]
    fn quote_error_display_malformed() {
        let e = QuoteError::MalformedRateCard { line: 7 };
        assert!(e.to_string().contains("7"));
    }

    #[test]
    fn quote_error_display_unavailable() {
        assert!(!QuoteError::RateCardUnavailable.to_string().is_empty());
    }
}
