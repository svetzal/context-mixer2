//! Human-readable zone label helpers.

/// Returns a display label for a known zone, or the zone name itself.
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}
