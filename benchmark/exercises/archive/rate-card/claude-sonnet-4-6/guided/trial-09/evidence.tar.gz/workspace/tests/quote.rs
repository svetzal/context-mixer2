//! Integration tests for the quote() public API (exercises I/O boundary).

use ratecard::{Parcel, QuoteError, quote};
use std::io::Write as _;
use tempfile::NamedTempFile;

const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn with_rate_card(content: &str, f: impl FnOnce()) {
    let mut tmp = NamedTempFile::new().unwrap();
    tmp.write_all(content.as_bytes()).unwrap();
    let path = tmp.path().to_str().unwrap().to_string();
    // RATECARD_PATH is process-global; tests that set it must not run in parallel.
    std::env::set_var("RATECARD_PATH", &path);
    f();
    std::env::remove_var("RATECARD_PATH");
}

#[test]
fn quote_domestic_light() {
    with_rate_card(SAMPLE_CARD, || {
        let parcel = Parcel { weight_grams: 200, zone: "domestic".into() };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    });
}

#[test]
fn quote_international_light() {
    with_rate_card(SAMPLE_CARD, || {
        let parcel = Parcel { weight_grams: 400, zone: "international".into() };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300); // 20% of 1499 = 299.8 → 300
        assert_eq!(q.total_cents, 1799);
    });
}

#[test]
fn quote_missing_env_var_is_unavailable() {
    std::env::remove_var("RATECARD_PATH");
    let parcel = Parcel { weight_grams: 100, zone: "domestic".into() };
    let err = quote(&parcel).unwrap_err();
    assert!(matches!(err, QuoteError::RateCardUnavailable));
}

#[test]
fn quote_bad_path_is_unavailable() {
    std::env::set_var("RATECARD_PATH", "/no/such/file.tsv");
    let parcel = Parcel { weight_grams: 100, zone: "domestic".into() };
    let err = quote(&parcel).unwrap_err();
    std::env::remove_var("RATECARD_PATH");
    assert!(matches!(err, QuoteError::RateCardUnavailable));
}

#[test]
fn quote_malformed_card_reports_line() {
    with_rate_card("# comment\n\ndomestic\tbad_num\t599\n", || {
        let parcel = Parcel { weight_grams: 100, zone: "domestic".into() };
        let err = quote(&parcel).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 3 }));
    });
}

#[test]
fn quote_unknown_zone() {
    with_rate_card(SAMPLE_CARD, || {
        let parcel = Parcel { weight_grams: 100, zone: "express".into() };
        let err = quote(&parcel).unwrap_err();
        assert!(matches!(err, QuoteError::UnknownZone(z) if z == "express"));
    });
}

#[test]
fn quote_overweight() {
    with_rate_card(SAMPLE_CARD, || {
        let parcel = Parcel { weight_grams: 30_000, zone: "domestic".into() };
        let err = quote(&parcel).unwrap_err();
        assert!(matches!(err, QuoteError::Overweight { grams: 30_000, limit: 20_000 }));
    });
}
