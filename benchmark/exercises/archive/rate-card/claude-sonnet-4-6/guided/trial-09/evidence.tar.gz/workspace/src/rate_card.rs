//! Rate card parsing — pure, no I/O.

use crate::QuoteError;

/// A single pricing band from the rate card.
#[derive(Debug)]
pub struct Band {
    /// Zone name (e.g. `"domestic"`).
    pub zone: String,
    /// Upper weight threshold for this band, in grams.
    pub band_max_grams: u32,
    /// Price for this band, in cents.
    pub cents: u64,
}

/// Parse rate card content into bands.
///
/// Lines that are empty or begin with `#` are skipped. Content lines must be
/// three tab-separated fields: zone, band_max_grams, cents.
///
/// ```
/// use ratecard::rate_card::parse;
/// let bands = parse("domestic\t500\t599\n").unwrap();
/// assert_eq!(bands[0].cents, 599);
/// ```
pub fn parse(content: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();

    for (idx, line) in content.lines().enumerate() {
        let line_num = idx + 1;

        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = fields[0].to_string();
        let band_max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        bands.push(Band { zone, band_max_grams, cents });
    }

    Ok(bands)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn skips_comments_and_blanks() {
        let content = "# header\n\ndomestic\t500\t599\n";
        let bands = parse(content).unwrap();
        assert_eq!(bands.len(), 1);
        assert_eq!(bands[0].zone, "domestic");
    }

    #[test]
    fn wrong_field_count_is_malformed() {
        let content = "domestic\t500\n";
        let err = parse(content).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn non_numeric_grams_is_malformed() {
        let content = "domestic\txxx\t599\n";
        let err = parse(content).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn line_number_counts_all_lines() {
        let content = "# comment\n\ndomestic\tbad\t599\n";
        let err = parse(content).unwrap_err();
        // "domestic\tbad\t599" is line 3
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 3 }));
    }
}
