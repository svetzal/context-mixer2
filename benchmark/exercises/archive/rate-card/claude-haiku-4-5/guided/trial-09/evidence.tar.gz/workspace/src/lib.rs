use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

/// A parcel to be shipped.
#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Errors that can occur during quote calculation.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "Malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "Overweight: {} grams exceeds limit of {}", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

struct RateCardBand {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

struct RateCard {
    bands: Vec<RateCardBand>,
}

impl RateCard {
    fn load() -> Result<Self, QuoteError> {
        let path = std::env::var("RATECARD_PATH")
            .map_err(|_| QuoteError::RateCardUnavailable)?;

        let content = fs::read_to_string(path)
            .map_err(|_| QuoteError::RateCardUnavailable)?;

        let mut bands = Vec::new();

        for (line_idx, line) in content.lines().enumerate() {
            let line_num = line_idx + 1;

            let trimmed = line.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }

            let parts: Vec<&str> = line.split('\t').collect();
            if parts.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: line_num });
            }

            let zone = parts[0].to_string();
            let band_max_grams: u32 = parts[1]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
            let cents: u64 = parts[2]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

            bands.push(RateCardBand {
                zone,
                band_max_grams,
                cents,
            });
        }

        Ok(RateCard { bands })
    }

    fn find_band(&self, zone: &str, weight: u32) -> Result<&RateCardBand, QuoteError> {
        let mut zone_bands: Vec<_> = self
            .bands
            .iter()
            .filter(|b| b.zone == zone)
            .collect();

        if zone_bands.is_empty() {
            return Err(QuoteError::UnknownZone(zone.to_string()));
        }

        zone_bands.sort_by_key(|b| b.band_max_grams);

        zone_bands
            .iter()
            .find(|b| b.band_max_grams >= weight)
            .copied()
            .ok_or_else(|| {
                let limit = zone_bands.last().unwrap().band_max_grams;
                QuoteError::Overweight {
                    grams: weight,
                    limit,
                }
            })
    }
}

/// Calculate a shipping quote for the given parcel.
///
/// Reads the rate card from the `RATECARD_PATH` environment variable and
/// calculates the appropriate quote based on the parcel's weight and zone.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = RateCard::load()?;
    let band = rate_card.find_band(&parcel.zone, parcel.weight_grams)?;

    let base_cents = band.cents;

    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let intl_surcharge = (base_cents * 20 + 50) / 100;
        surcharge_cents += intl_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total_cents,
        "Quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn create_test_rate_card() -> (NamedTempFile, String) {
        let mut file = NamedTempFile::new().unwrap();
        let content = "# zone\tband_max_grams\tcents\n\
                      domestic\t500\t599\n\
                      domestic\t2000\t899\n\
                      domestic\t20000\t1799\n\
                      international\t500\t1499\n\
                      international\t20000\t4999\n";
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();

        let path = file.path().to_string_lossy().to_string();
        (file, path)
    }

    #[test]
    fn test_domestic_light_parcel() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_medium_parcel() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 1000,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_domestic_heavy_parcel() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_international_light_parcel() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1499);
        let intl_surcharge = (1499 * 20 + 50) / 100;
        assert_eq!(quote.surcharge_cents, intl_surcharge);
        assert_eq!(quote.total_cents, 1499 + intl_surcharge);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_international_heavy_parcel() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 4999);
        let intl_surcharge = (4999 * 20 + 50) / 100;
        let weight_surcharge = 500;
        assert_eq!(quote.surcharge_cents, intl_surcharge + weight_surcharge);
        assert_eq!(quote.total_cents, 4999 + intl_surcharge + weight_surcharge);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_unknown_zone() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "unknown".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(
            result,
            Err(QuoteError::UnknownZone(ref z)) if z == "unknown"
        ));
    }

    #[test]
    fn test_overweight() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 25000,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(
            result,
            Err(QuoteError::Overweight {
                grams: 25000,
                limit: 20000
            })
        ));
    }

    #[test]
    fn test_malformed_rate_card_non_numeric_weight() {
        let mut file = NamedTempFile::new().unwrap();
        let content = "domestic\tabc\t599\n";
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();

        let path = file.path().to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 1 })));
    }

    #[test]
    fn test_malformed_rate_card_non_numeric_cents() {
        let mut file = NamedTempFile::new().unwrap();
        let content = "domestic\t500\txyz\n";
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();

        let path = file.path().to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 1 })));
    }

    #[test]
    fn test_malformed_rate_card_wrong_field_count() {
        let mut file = NamedTempFile::new().unwrap();
        let content = "domestic\t500\n";
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();

        let path = file.path().to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 1 })));
    }

    #[test]
    fn test_malformed_rate_card_line_numbers() {
        let mut file = NamedTempFile::new().unwrap();
        let content = "# comment\n\ndomestic\tabc\t599\n";
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();

        let path = file.path().to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 3 })));
    }

    #[test]
    fn test_rate_card_unavailable() {
        std::env::set_var("RATECARD_PATH", "/nonexistent/path/to/file");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert_eq!(result, Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn test_rate_card_path_unset() {
        std::env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert_eq!(result, Err(QuoteError::RateCardUnavailable));
    }
}
