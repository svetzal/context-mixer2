pub mod zones;

use std::collections::BTreeMap;
use std::error::Error;
use std::fmt;
use std::fs;
use std::path::PathBuf;
use tracing::info;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "weight {} grams exceeds limit {}", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

struct RateBand {
    band_max_grams: u32,
    cents: u64,
}

struct RateCard {
    zones: BTreeMap<String, Vec<RateBand>>,
}

impl RateCard {
    fn load() -> Result<RateCard, QuoteError> {
        let path = std::env::var("RATECARD_PATH")
            .map_err(|_| QuoteError::RateCardUnavailable)?;
        let path = PathBuf::from(path);

        let content = fs::read_to_string(&path)
            .map_err(|_| QuoteError::RateCardUnavailable)?;

        let mut zones: BTreeMap<String, Vec<RateBand>> = BTreeMap::new();
        let mut line_num = 0;

        for line in content.lines() {
            line_num += 1;

            let trimmed = line.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }

            let parts: Vec<&str> = line.split('\t').collect();
            if parts.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: line_num });
            }

            let zone = parts[0].to_string();
            let band_max_grams: u32 = parts[1]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
            let cents: u64 = parts[2]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

            zones
                .entry(zone)
                .or_insert_with(Vec::new)
                .push(RateBand {
                    band_max_grams,
                    cents,
                });
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|b| b.band_max_grams);
        }

        Ok(RateCard { zones })
    }

    fn find_band(&self, zone: &str, weight_grams: u32) -> Result<&RateBand, QuoteError> {
        let bands = self
            .zones
            .get(zone)
            .ok_or_else(|| QuoteError::UnknownZone(zone.to_string()))?;

        let band = bands
            .iter()
            .find(|b| b.band_max_grams >= weight_grams)
            .ok_or_else(|| {
                let limit = bands.last().map(|b| b.band_max_grams).unwrap_or(0);
                QuoteError::Overweight {
                    grams: weight_grams,
                    limit,
                }
            })?;

        Ok(band)
    }
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = RateCard::load()?;
    let band = rate_card.find_band(&parcel.zone, parcel.weight_grams)?;

    let base_cents = band.cents;
    let band_max_grams = band.band_max_grams;

    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let international_surcharge = (base_cents * 20 + 50) / 100;
        surcharge_cents += international_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn create_test_rate_card() -> (NamedTempFile, String) {
        let mut file = NamedTempFile::new().unwrap();
        let content = "# zone\tband_max_grams\tcents\n\
                       domestic\t500\t599\n\
                       domestic\t2000\t899\n\
                       domestic\t20000\t1799\n\
                       international\t500\t1499\n\
                       international\t20000\t4999\n";
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();

        let path = file.path().to_string_lossy().to_string();
        (file, path)
    }

    #[test]
    fn test_domestic_small_parcel() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_medium_parcel() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_domestic_heavy_parcel() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_international_small_parcel() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1499);
        let expected_surcharge = (1499 * 20 + 50) / 100;
        assert_eq!(quote.surcharge_cents, expected_surcharge);
        assert_eq!(quote.total_cents, 1499 + expected_surcharge);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_international_heavy_parcel() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 4999);
        let weight_surcharge = 500u64;
        let intl_surcharge = (4999 * 20 + 50) / 100;
        let expected_surcharge = weight_surcharge + intl_surcharge;
        assert_eq!(quote.surcharge_cents, expected_surcharge);
        assert_eq!(quote.total_cents, 4999 + expected_surcharge);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_unknown_zone() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "unknown".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::UnknownZone(zone)) => {
                assert_eq!(zone, "unknown");
            }
            _ => panic!("Expected UnknownZone error"),
        }
    }

    #[test]
    fn test_overweight() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 25000,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 25000);
                assert_eq!(limit, 20000);
            }
            _ => panic!("Expected Overweight error"),
        }
    }

    #[test]
    fn test_missing_rate_card() {
        std::env::set_var("RATECARD_PATH", "/nonexistent/path/to/rate/card");

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => {}
            _ => panic!("Expected RateCardUnavailable error"),
        }
    }

    #[test]
    fn test_unset_rate_card_path() {
        std::env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => {}
            _ => panic!("Expected RateCardUnavailable error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_too_few_fields() {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(b"domestic\t500\n").unwrap();
        file.flush().unwrap();
        let path = file.path().to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => {
                assert_eq!(line, 1);
            }
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_invalid_number() {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(b"domestic\tabc\t599\n").unwrap();
        file.flush().unwrap();
        let path = file.path().to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => {
                assert_eq!(line, 1);
            }
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_line_counting() {
        let mut file = NamedTempFile::new().unwrap();
        let content = "# comment\n\ndomestic\tabc\t599\n";
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();
        let path = file.path().to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => {
                assert_eq!(line, 3);
            }
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_surcharge_rounding_half_up() {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(b"international\t500\t1001\n").unwrap();
        file.flush().unwrap();
        let path = file.path().to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        let expected_surcharge = (1001 * 20 + 50) / 100;
        assert_eq!(quote.surcharge_cents, expected_surcharge);
        assert_eq!(expected_surcharge, 200);
    }

    #[test]
    fn test_exact_band_boundary() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_just_under_band_boundary() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 499,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }
}
