pub mod zones;

use std::collections::BTreeMap;
use std::error::Error;
use std::fmt;
use std::fs;
use std::path::PathBuf;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {} grams exceeds limit {}", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

struct RateBand {
    band_max_grams: u32,
    cents: u64,
}

type RateCard = BTreeMap<String, Vec<RateBand>>;

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = std::env::var("RATECARD_PATH")
        .ok()
        .and_then(|p| {
            if p.is_empty() {
                None
            } else {
                Some(p)
            }
        })
        .map(PathBuf::from);

    let path = match path {
        Some(p) => p,
        None => return Err(QuoteError::RateCardUnavailable),
    };

    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut card: RateCard = BTreeMap::new();

    for (line_idx, line) in content.lines().enumerate() {
        let line_num = line_idx + 1;

        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        card.entry(zone)
            .or_default()
            .push(RateBand {
                band_max_grams,
                cents,
            });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|b| b.band_max_grams);
    }

    Ok(card)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = load_rate_card()?;

    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: bands.last().unwrap().band_max_grams,
        })?;

    let base_cents = band.cents;

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let international_surcharge = (base_cents * 20 + 50) / 100;
        surcharge_cents += international_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total_cents,
        "quote issued"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    #[test]
    fn test_basic_domestic_quote() {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(b"domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n")
            .unwrap();
        file.flush().unwrap();
        let path = file.path().to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 599);
        assert_eq!(result.surcharge_cents, 0);
        assert_eq!(result.total_cents, 599);
        assert_eq!(result.band_max_grams, 500);
    }

    #[test]
    fn test_band_selection() {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(b"domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n")
            .unwrap();
        let path = file.path().to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 899);
        assert_eq!(result.band_max_grams, 2000);
    }

    #[test]
    fn test_heavy_surcharge() {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(b"domestic\t20000\t1799\n").unwrap();
        let path = file.path().to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 1799);
        assert_eq!(result.surcharge_cents, 500);
        assert_eq!(result.total_cents, 2299);
    }

    #[test]
    fn test_international_surcharge() {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(b"international\t500\t1000\n").unwrap();
        let path = file.path().to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 250,
            zone: "international".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 1000);
        assert_eq!(result.surcharge_cents, 200);
        assert_eq!(result.total_cents, 1200);
    }

    #[test]
    fn test_international_and_heavy_surcharge() {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(b"international\t20000\t5000\n").unwrap();
        let path = file.path().to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 5000);
        assert_eq!(result.surcharge_cents, 1500);
        assert_eq!(result.total_cents, 6500);
    }

    #[test]
    fn test_unknown_zone() {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(b"domestic\t500\t599\n").unwrap();
        let path = file.path().to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 250,
            zone: "unknown".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::UnknownZone(zone)) => assert_eq!(zone, "unknown"),
            _ => panic!("expected UnknownZone error"),
        }
    }

    #[test]
    fn test_overweight() {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(b"domestic\t500\t599\n").unwrap();
        let path = file.path().to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 1000,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 1000);
                assert_eq!(limit, 500);
            }
            _ => panic!("expected Overweight error"),
        }
    }

    #[test]
    fn test_missing_ratecard() {
        std::env::set_var("RATECARD_PATH", "/nonexistent/path");

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => (),
            _ => panic!("expected RateCardUnavailable error"),
        }
    }

    #[test]
    fn test_unset_ratecard_path() {
        std::env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => (),
            _ => panic!("expected RateCardUnavailable error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_wrong_field_count() {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(b"domestic\t500\n").unwrap();
        let path = file.path().to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            _ => panic!("expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_invalid_number() {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(b"domestic\tabc\t599\n").unwrap();
        let path = file.path().to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            _ => panic!("expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_comments_and_blanks_ignored() {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(b"# Comment line\n\ndomestic\t500\t599\n").unwrap();
        let path = file.path().to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 599);
    }

    #[test]
    fn test_rounding_half_up() {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(b"international\t500\t1005\n").unwrap();
        let path = file.path().to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 250,
            zone: "international".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 1005);
        assert_eq!(result.surcharge_cents, 201);
        assert_eq!(result.total_cents, 1206);
    }

    #[test]
    fn test_line_numbering_with_comments() {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(b"# Comment\ndomestic\tabc\t599\n").unwrap();
        file.flush().unwrap();
        let path = file.path().to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 2),
            _ => panic!("expected MalformedRateCard error"),
        }
    }
}
