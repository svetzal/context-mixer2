pub mod zones;

use std::collections::BTreeMap;
use std::error::Error;
use std::fmt;
use std::fs;

#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "weight {} grams exceeds limit {} grams", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

struct RateCard {
    bands: BTreeMap<String, Vec<Band>>,
}

#[derive(Debug, Clone)]
struct Band {
    max_grams: u32,
    cents: u64,
}

impl RateCard {
    fn parse(content: &str) -> Result<Self, QuoteError> {
        let mut bands: BTreeMap<String, Vec<Band>> = BTreeMap::new();

        for (line_num, line) in content.lines().enumerate() {
            let line_number = line_num + 1;

            let trimmed = line.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }

            let parts: Vec<&str> = line.split('\t').collect();
            if parts.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: line_number });
            }

            let zone = parts[0].to_string();
            let max_grams: u32 = parts[1]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
            let cents: u64 = parts[2]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

            bands.entry(zone).or_insert_with(Vec::new).push(Band {
                max_grams,
                cents,
            });
        }

        for zone_bands in bands.values_mut() {
            zone_bands.sort_by_key(|b| b.max_grams);
        }

        Ok(RateCard { bands })
    }

    fn get_band(&self, zone: &str, weight_grams: u32) -> Result<(&Band, u32), QuoteError> {
        let zone_bands = self
            .bands
            .get(zone)
            .ok_or_else(|| QuoteError::UnknownZone(zone.to_string()))?;

        let max_weight = zone_bands
            .last()
            .map(|b| b.max_grams)
            .unwrap_or_default();

        if weight_grams > max_weight {
            return Err(QuoteError::Overweight {
                grams: weight_grams,
                limit: max_weight,
            });
        }

        let band = zone_bands
            .iter()
            .find(|b| b.max_grams >= weight_grams)
            .ok_or_else(|| QuoteError::Overweight {
                grams: weight_grams,
                limit: max_weight,
            })?;

        Ok((band, max_weight))
    }
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let _span = tracing::info_span!(
        "quote",
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
    ).entered();

    let rate_card_path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)
        .and_then(|p| {
            fs::read_to_string(&p).map_err(|_| QuoteError::RateCardUnavailable)
        })?;

    let rate_card = RateCard::parse(&rate_card_path)?;
    let (band, _max_weight) = rate_card.get_band(&parcel.zone, parcel.weight_grams)?;

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let intl_surcharge = (base_cents * 20 + 50) / 100;
        surcharge_cents += intl_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    tracing::info!(total_cents = total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn create_rate_card(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();
        file
    }

    #[test]
    fn test_quote_domestic_under_500g() {
        let rate_card = create_rate_card("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\ninternational\t500\t1499\ninternational\t20000\t4999");

        std::env::set_var("RATECARD_PATH", rate_card.path());
        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 599);
        assert_eq!(result.surcharge_cents, 0);
        assert_eq!(result.total_cents, 599);
        assert_eq!(result.band_max_grams, 500);
    }

    #[test]
    fn test_quote_domestic_between_bands() {
        let rate_card = create_rate_card("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799");

        std::env::set_var("RATECARD_PATH", rate_card.path());
        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 899);
        assert_eq!(result.surcharge_cents, 0);
        assert_eq!(result.total_cents, 899);
        assert_eq!(result.band_max_grams, 2000);
    }

    #[test]
    fn test_quote_domestic_heavy_surcharge() {
        let rate_card = create_rate_card("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799");

        std::env::set_var("RATECARD_PATH", rate_card.path());
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 1799);
        assert_eq!(result.surcharge_cents, 500);
        assert_eq!(result.total_cents, 2299);
        assert_eq!(result.band_max_grams, 20000);
    }

    #[test]
    fn test_quote_international_20pct_surcharge() {
        let rate_card = create_rate_card("domestic\t500\t599\ninternational\t500\t1000");

        std::env::set_var("RATECARD_PATH", rate_card.path());
        let parcel = Parcel {
            weight_grams: 250,
            zone: "international".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 1000);
        assert_eq!(result.surcharge_cents, 200);
        assert_eq!(result.total_cents, 1200);
    }

    #[test]
    fn test_quote_international_20pct_rounding() {
        let rate_card = create_rate_card("international\t500\t1001");

        std::env::set_var("RATECARD_PATH", rate_card.path());
        let parcel = Parcel {
            weight_grams: 250,
            zone: "international".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 1001);
        assert_eq!(result.surcharge_cents, 200);
        assert_eq!(result.total_cents, 1201);
    }

    #[test]
    fn test_quote_international_heavy_both_surcharges() {
        let rate_card = create_rate_card("international\t20000\t5000");

        std::env::set_var("RATECARD_PATH", rate_card.path());
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 5000);
        assert_eq!(result.surcharge_cents, 1500);
        assert_eq!(result.total_cents, 6500);
    }

    #[test]
    fn test_error_unknown_zone() {
        let rate_card = create_rate_card("domestic\t500\t599");

        std::env::set_var("RATECARD_PATH", rate_card.path());
        let parcel = Parcel {
            weight_grams: 250,
            zone: "international".to_string(),
        };

        let result = quote(&parcel);
        match result {
            Err(QuoteError::UnknownZone(ref z)) => assert_eq!(z, "international"),
            _ => panic!("expected UnknownZone error"),
        }
    }

    #[test]
    fn test_error_overweight() {
        let rate_card = create_rate_card("domestic\t500\t599");

        std::env::set_var("RATECARD_PATH", rate_card.path());
        let parcel = Parcel {
            weight_grams: 1000,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::Overweight { grams: 1000, limit: 500 })));
    }

    #[test]
    fn test_error_missing_rate_card() {
        std::env::set_var("RATECARD_PATH", "/nonexistent/path");
        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_error_malformed_rate_card_bad_fields() {
        let rate_card = create_rate_card("domestic\t500");

        std::env::set_var("RATECARD_PATH", rate_card.path());
        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 1 })));
    }

    #[test]
    fn test_error_malformed_rate_card_bad_weight() {
        let rate_card = create_rate_card("domestic\tabc\t599");

        std::env::set_var("RATECARD_PATH", rate_card.path());
        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 1 })));
    }

    #[test]
    fn test_error_malformed_rate_card_bad_cents() {
        let rate_card = create_rate_card("domestic\t500\txyz");

        std::env::set_var("RATECARD_PATH", rate_card.path());
        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 1 })));
    }

    #[test]
    fn test_error_malformed_rate_card_line_number_with_comments() {
        let rate_card = create_rate_card(
            "# comment\n\
             \n\
             domestic\tabc\t599",
        );

        std::env::set_var("RATECARD_PATH", rate_card.path());
        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 3 })));
    }
}
