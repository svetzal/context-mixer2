pub mod zones;

use std::collections::BTreeMap;
use std::error::Error;
use std::fmt;
use std::fs;
use tracing::info;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel too heavy: {} grams exceeds limit {} grams", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

struct RateCard {
    bands: BTreeMap<String, Vec<(u32, u64)>>,
}

impl RateCard {
    fn parse(content: &str) -> Result<Self, QuoteError> {
        let mut bands: BTreeMap<String, Vec<(u32, u64)>> = BTreeMap::new();

        for (line_idx, line) in content.lines().enumerate() {
            let line_num = line_idx + 1;
            let trimmed = line.trim();

            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }

            let parts: Vec<&str> = line.split('\t').collect();
            if parts.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: line_num });
            }

            let zone = parts[0].to_string();
            let band_max_grams: u32 = parts[1]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
            let cents: u64 = parts[2]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

            bands.entry(zone).or_default().push((band_max_grams, cents));
        }

        for bands_list in bands.values_mut() {
            bands_list.sort_by_key(|&(max, _)| max);
        }

        Ok(RateCard { bands })
    }

    fn find_band(&self, zone: &str, weight_grams: u32) -> Result<(u64, u32), QuoteError> {
        let zone_bands = self.bands.get(zone).ok_or_else(|| QuoteError::UnknownZone(zone.to_string()))?;

        for &(band_max, cents) in zone_bands {
            if weight_grams <= band_max {
                return Ok((cents, band_max));
            }
        }

        let max_limit = zone_bands.last().map(|&(max, _)| max).unwrap_or(0);
        Err(QuoteError::Overweight {
            grams: weight_grams,
            limit: max_limit,
        })
    }
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let ratecard_path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let content = fs::read_to_string(&ratecard_path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let ratecard = RateCard::parse(&content)?;

    let (base_cents, band_max_grams) = ratecard.find_band(&parcel.zone, parcel.weight_grams)?;

    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let intl_surcharge = ((base_cents as f64) * 0.2).round() as u64;
        surcharge_cents += intl_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn create_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();
        file
    }

    #[test]
    fn test_basic_domestic_quote() {
        let file = create_ratecard("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n");
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(result.is_ok());
        let quote = result.unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_band_selection() {
        let file = create_ratecard("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n");
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_heavy_surcharge() {
        let file = create_ratecard("domestic\t20000\t1799\n");
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 1799 + 500);
    }

    #[test]
    fn test_international_surcharge() {
        let file = create_ratecard("international\t500\t1000\n");
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        let expected_surcharge = (1000.0_f64 * 0.2).round() as u64;
        assert_eq!(quote.surcharge_cents, expected_surcharge);
        assert_eq!(quote.total_cents, 1000 + expected_surcharge);
    }

    #[test]
    fn test_combined_surcharges() {
        let file = create_ratecard("international\t20000\t1000\n");
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        let intl_surcharge = (1000.0_f64 * 0.2).round() as u64;
        let expected_surcharge = 500 + intl_surcharge;
        assert_eq!(quote.surcharge_cents, expected_surcharge);
        assert_eq!(quote.total_cents, 1000 + expected_surcharge);
    }

    #[test]
    fn test_unknown_zone() {
        let file = create_ratecard("domestic\t500\t599\n");
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "unknown".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::UnknownZone(ref z)) if z == "unknown"));
    }

    #[test]
    fn test_overweight() {
        let file = create_ratecard("domestic\t500\t599\n");
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 1000,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::Overweight { grams: 1000, limit: 500 })));
    }

    #[test]
    fn test_ratecard_unavailable() {
        std::env::set_var("RATECARD_PATH", "/nonexistent/path/ratecard.txt");

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_malformed_ratecard_wrong_field_count() {
        let file = create_ratecard("domestic\t500\n");
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 1 })));
    }

    #[test]
    fn test_malformed_ratecard_invalid_number() {
        let file = create_ratecard("domestic\tabc\t599\n");
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 1 })));
    }

    #[test]
    fn test_comments_and_blanks_ignored() {
        let file = create_ratecard("# This is a comment\n\ndomestic\t500\t599\n\n# Another comment\n");
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
    }

    #[test]
    fn test_rounding_half_up() {
        let file = create_ratecard("international\t500\t1000\n");
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.surcharge_cents, 200);
    }

    #[test]
    fn test_exact_band_max() {
        let file = create_ratecard("domestic\t500\t599\ndomestic\t2000\t899\n");
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }
}
