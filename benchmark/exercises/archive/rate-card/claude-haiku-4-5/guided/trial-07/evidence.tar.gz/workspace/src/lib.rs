pub mod zones;

use std::collections::BTreeMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;
use tracing::info;

#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel too heavy: {} grams exceeds limit {}", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

struct RateBand {
    band_max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card_path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;

    let content = fs::read_to_string(&rate_card_path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut zones: BTreeMap<String, Vec<RateBand>> = BTreeMap::new();

    for (line_num, line) in content.lines().enumerate() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num + 1 });
        }

        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num + 1 })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num + 1 })?;

        zones
            .entry(zone)
            .or_insert_with(Vec::new)
            .push(RateBand {
                band_max_grams,
                cents,
            });
    }

    let bands = zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let matching_band = bands
        .iter()
        .find(|band| band.band_max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = bands.iter().map(|b| b.band_max_grams).max().unwrap_or(0);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = matching_band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let international_surcharge = (base_cents * 20 + 50) / 100;
        surcharge_cents += international_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: matching_band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    static TEST_LOCK: Mutex<()> = Mutex::new(());

    fn create_rate_card(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();
        file
    }

    fn with_rate_card<F>(content: &str, f: F)
    where
        F: FnOnce(),
    {
        let _guard = TEST_LOCK.lock().unwrap();
        let rate_card = create_rate_card(content);
        env::set_var("RATECARD_PATH", rate_card.path());
        f();
    }

    #[test]
    fn test_basic_domestic_quote() {
        with_rate_card("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n", || {
            let parcel = Parcel {
                weight_grams: 250,
                zone: "domestic".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 599);
            assert_eq!(quote.surcharge_cents, 0);
            assert_eq!(quote.total_cents, 599);
            assert_eq!(quote.band_max_grams, 500);
        });
    }

    #[test]
    fn test_domestic_second_band() {
        with_rate_card("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n", || {
            let parcel = Parcel {
                weight_grams: 1500,
                zone: "domestic".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 899);
            assert_eq!(quote.surcharge_cents, 0);
            assert_eq!(quote.total_cents, 899);
            assert_eq!(quote.band_max_grams, 2000);
        });
    }

    #[test]
    fn test_international_surcharge() {
        with_rate_card("international\t500\t1499\ninternational\t20000\t4999\n", || {
            let parcel = Parcel {
                weight_grams: 250,
                zone: "international".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 1499);
            let expected_surcharge = (1499 * 20 + 50) / 100;
            assert_eq!(quote.surcharge_cents, expected_surcharge);
            assert_eq!(quote.total_cents, 1499 + expected_surcharge);
        });
    }

    #[test]
    fn test_overweight_surcharge() {
        with_rate_card("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n", || {
            let parcel = Parcel {
                weight_grams: 15000,
                zone: "domestic".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 1799);
            assert_eq!(quote.surcharge_cents, 500);
            assert_eq!(quote.total_cents, 2299);
        });
    }

    #[test]
    fn test_international_and_overweight() {
        with_rate_card("international\t500\t1499\ninternational\t20000\t4999\n", || {
            let parcel = Parcel {
                weight_grams: 15000,
                zone: "international".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 4999);
            let intl_surcharge = (4999 * 20 + 50) / 100;
            assert_eq!(quote.surcharge_cents, 500 + intl_surcharge);
            assert_eq!(quote.total_cents, 4999 + 500 + intl_surcharge);
        });
    }

    #[test]
    fn test_unknown_zone() {
        with_rate_card("domestic\t500\t599\n", || {
            let parcel = Parcel {
                weight_grams: 250,
                zone: "unknown".to_string(),
            };

            let err = quote(&parcel).unwrap_err();
            match err {
                QuoteError::UnknownZone(zone) => assert_eq!(zone, "unknown"),
                _ => panic!("Expected UnknownZone error"),
            }
        });
    }

    #[test]
    fn test_overweight() {
        with_rate_card("domestic\t500\t599\ndomestic\t2000\t899\n", || {
            let parcel = Parcel {
                weight_grams: 5000,
                zone: "domestic".to_string(),
            };

            let err = quote(&parcel).unwrap_err();
            match err {
                QuoteError::Overweight { grams, limit } => {
                    assert_eq!(grams, 5000);
                    assert_eq!(limit, 2000);
                }
                _ => panic!("Expected Overweight error"),
            }
        });
    }

    #[test]
    fn test_missing_rate_card() {
        env::set_var("RATECARD_PATH", "/nonexistent/path");
        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::RateCardUnavailable => (),
            _ => panic!("Expected RateCardUnavailable error"),
        }
    }

    #[test]
    fn test_unset_rate_card_path() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::RateCardUnavailable => (),
            _ => panic!("Expected RateCardUnavailable error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_non_numeric_band() {
        with_rate_card("domestic\tabc\t599\n", || {
            let parcel = Parcel {
                weight_grams: 250,
                zone: "domestic".to_string(),
            };

            let err = quote(&parcel).unwrap_err();
            match err {
                QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
                _ => panic!("Expected MalformedRateCard error"),
            }
        });
    }

    #[test]
    fn test_malformed_rate_card_non_numeric_cents() {
        with_rate_card("domestic\t500\tabc\n", || {
            let parcel = Parcel {
                weight_grams: 250,
                zone: "domestic".to_string(),
            };

            let err = quote(&parcel).unwrap_err();
            match err {
                QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
                _ => panic!("Expected MalformedRateCard error"),
            }
        });
    }

    #[test]
    fn test_malformed_rate_card_wrong_field_count() {
        with_rate_card("domestic\t500\n", || {
            let parcel = Parcel {
                weight_grams: 250,
                zone: "domestic".to_string(),
            };

            let err = quote(&parcel).unwrap_err();
            match err {
                QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
                _ => panic!("Expected MalformedRateCard error"),
            }
        });
    }

    #[test]
    fn test_malformed_rate_card_line_count_includes_comments() {
        with_rate_card("# comment\ndomestic\tabc\t599\n", || {
            let parcel = Parcel {
                weight_grams: 250,
                zone: "domestic".to_string(),
            };

            let err = quote(&parcel).unwrap_err();
            match err {
                QuoteError::MalformedRateCard { line } => assert_eq!(line, 2),
                _ => panic!("Expected MalformedRateCard error"),
            }
        });
    }

    #[test]
    fn test_comments_and_blanks_ignored() {
        with_rate_card("# Zone\tMax\tCents\n\ndomestic\t500\t599\n\n# Another comment\ndomestic\t2000\t899\n", || {
            let parcel = Parcel {
                weight_grams: 250,
                zone: "domestic".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 599);
        });
    }

    #[test]
    fn test_exact_weight_boundary() {
        with_rate_card("domestic\t500\t599\ndomestic\t2000\t899\n", || {
            let parcel = Parcel {
                weight_grams: 500,
                zone: "domestic".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 599);
            assert_eq!(quote.band_max_grams, 500);
        });
    }

    #[test]
    fn test_display_trait_unknown_zone() {
        let err = QuoteError::UnknownZone("test".to_string());
        let msg = format!("{}", err);
        assert_eq!(msg, "unknown zone: test");
    }

    #[test]
    fn test_display_trait_overweight() {
        let err = QuoteError::Overweight {
            grams: 3000,
            limit: 2000,
        };
        let msg = format!("{}", err);
        assert!(msg.contains("3000"));
        assert!(msg.contains("2000"));
    }

    #[test]
    fn test_display_trait_malformed() {
        let err = QuoteError::MalformedRateCard { line: 5 };
        let msg = format!("{}", err);
        assert!(msg.contains("5"));
    }

    #[test]
    fn test_display_trait_unavailable() {
        let err = QuoteError::RateCardUnavailable;
        let msg = format!("{}", err);
        assert_eq!(msg, "rate card unavailable");
    }
}
