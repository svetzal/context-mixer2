use std::collections::BTreeMap;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {}", zone)
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {} exceeds limit {}", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

struct RateBand {
    band_max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;

    let bands = rate_card
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: bands.last().unwrap().band_max_grams,
        })?;

    let base_cents = band.cents;
    let band_max_grams = band.band_max_grams;

    let mut surcharge_cents = 0u64;

    // Heavy surcharge: weight strictly above 10000 grams
    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    // International surcharge: 20% of base_cents, rounded half-up
    if parcel.zone == "international" {
        let international_surcharge = ((base_cents as f64 * 1.2).round() as u64) - base_cents;
        surcharge_cents += international_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

fn load_rate_card() -> Result<BTreeMap<String, Vec<RateBand>>, QuoteError> {
    let path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let content = fs::read_to_string(&path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut rate_card: BTreeMap<String, Vec<RateBand>> = BTreeMap::new();

    for (line_num, line) in content.lines().enumerate() {
        let line_num = line_num + 1;

        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        rate_card
            .entry(zone)
            .or_insert_with(Vec::new)
            .push(RateBand {
                band_max_grams,
                cents,
            });
    }

    // Sort bands by band_max_grams for each zone
    for bands in rate_card.values_mut() {
        bands.sort_by_key(|b| b.band_max_grams);
    }

    Ok(rate_card)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Mutex;
    use tempfile::TempDir;

    thread_local! {
        static TEST_DIR: std::cell::RefCell<Option<TempDir>> = std::cell::RefCell::new(None);
    }

    lazy_static::lazy_static! {
        static ref ENV_LOCK: Mutex<()> = Mutex::new(());
    }

    struct TestSetup;

    impl TestSetup {
        fn new(content: &str) -> Self {
            let _guard = ENV_LOCK.lock().unwrap();

            let dir = TempDir::new().unwrap();
            let path = dir.path().join("ratecard.txt");
            std::fs::write(&path, content).unwrap();
            let path_str = path.to_string_lossy().to_string();

            TEST_DIR.with(|d| {
                *d.borrow_mut() = Some(dir);
            });

            std::env::set_var("RATECARD_PATH", path_str);
            TestSetup
        }
    }

    impl Drop for TestSetup {
        fn drop(&mut self) {
            std::env::remove_var("RATECARD_PATH");
            TEST_DIR.with(|d| {
                *d.borrow_mut() = None;
            });
        }
    }

    #[test]
    fn test_basic_domestic_quote() {
        let _setup = TestSetup::new("domestic\t500\t599\ndomestic\t2000\t899\n");

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 599);
        assert_eq!(result.surcharge_cents, 0);
        assert_eq!(result.total_cents, 599);
        assert_eq!(result.band_max_grams, 500);
    }

    #[test]
    fn test_band_selection() {
        let _setup = TestSetup::new("domestic\t500\t599\ndomestic\t2000\t899\n");

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 899);
        assert_eq!(result.band_max_grams, 2000);
    }

    #[test]
    fn test_heavy_surcharge() {
        let _setup = TestSetup::new("domestic\t20000\t1000\n");

        let parcel = Parcel {
            weight_grams: 10001,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 1000);
        assert_eq!(result.surcharge_cents, 500);
        assert_eq!(result.total_cents, 1500);
    }

    #[test]
    fn test_no_heavy_surcharge_at_10000() {
        let _setup = TestSetup::new("domestic\t20000\t1000\n");

        let parcel = Parcel {
            weight_grams: 10000,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.surcharge_cents, 0);
    }

    #[test]
    fn test_international_surcharge() {
        let _setup = TestSetup::new("international\t500\t1000\n");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 1000);
        assert_eq!(result.surcharge_cents, 200);
        assert_eq!(result.total_cents, 1200);
    }

    #[test]
    fn test_international_surcharge_rounding() {
        let _setup = TestSetup::new("international\t500\t1001\n");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 1001);
        assert_eq!(result.surcharge_cents, 200);
        assert_eq!(result.total_cents, 1201);
    }

    #[test]
    fn test_combined_surcharges() {
        let _setup = TestSetup::new("international\t20000\t1000\n");

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 1000);
        assert_eq!(result.surcharge_cents, 700);
        assert_eq!(result.total_cents, 1700);
    }

    #[test]
    fn test_unknown_zone() {
        let _setup = TestSetup::new("domestic\t500\t599\n");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "unknown".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::UnknownZone(zone)) => assert_eq!(zone, "unknown"),
            _ => panic!("Expected UnknownZone error"),
        }
    }

    #[test]
    fn test_overweight() {
        let _setup = TestSetup::new("domestic\t500\t599\ndomestic\t2000\t899\n");

        let parcel = Parcel {
            weight_grams: 5000,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 5000);
                assert_eq!(limit, 2000);
            }
            _ => panic!("Expected Overweight error"),
        }
    }

    #[test]
    fn test_missing_rate_card() {
        let _guard = ENV_LOCK.lock().unwrap();
        std::env::set_var("RATECARD_PATH", "/nonexistent/path");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => {}
            _ => panic!("Expected RateCardUnavailable error"),
        }

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_unset_rate_card_path() {
        let _guard = ENV_LOCK.lock().unwrap();
        std::env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => {}
            _ => panic!("Expected RateCardUnavailable error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_wrong_field_count() {
        let _setup = TestSetup::new("domestic\t500\n");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_invalid_number() {
        let _setup = TestSetup::new("domestic\tabc\t599\n");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_line_counting() {
        let _setup = TestSetup::new("# comment\ndomestic\tabc\t599\ndomestic\t500\t599\n");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 2),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_comments_and_blank_lines() {
        let _setup = TestSetup::new("# zone\tband_max_grams\tcents\n\ndomestic\t500\t599\n# another comment\n");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 599);
    }
}
