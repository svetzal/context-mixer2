pub mod zones;

use std::env;
use std::fs;
use std::error::Error;
use std::fmt;
use tracing::info;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => write!(f, "Parcel weight {} exceeds limit {}", grams, limit),
        }
    }
}

impl Error for QuoteError {}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card_path = env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let content = fs::read_to_string(&rate_card_path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands_by_zone: std::collections::HashMap<String, Vec<(u32, u64)>> =
        std::collections::HashMap::new();

    for (line_num, line) in content.lines().enumerate() {
        let line_number = line_num + 1;

        // Skip empty lines and comments
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        // Parse the line: zone<tab>band_max_grams<tab>cents
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1].parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = parts[2].parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        bands_by_zone.entry(zone).or_default()
            .push((band_max_grams, cents));
    }

    // Check if zone exists
    let bands = bands_by_zone.get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    // Sort bands by max_grams
    let mut sorted_bands = bands.clone();
    sorted_bands.sort_by_key(|b| b.0);

    // Find matching band
    let (band_max_grams, base_cents) = sorted_bands.iter()
        .find(|(max_grams, _)| parcel.weight_grams <= *max_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: sorted_bands.last().unwrap().0,
        })?;

    let base_cents = *base_cents;
    let band_max_grams = *band_max_grams;

    // Calculate surcharges
    let mut surcharge_cents = 0u64;

    // Weight surcharge: > 10000 grams adds 500 cents
    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    // Zone surcharge: international adds 20% of base_cents, rounded half-up
    if parcel.zone == "international" {
        let zone_surcharge = (base_cents * 20 + 50) / 100; // half-up rounding
        surcharge_cents += zone_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    info!(
        zone = parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total_cents,
        "Quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::path::PathBuf;
    use tempfile::NamedTempFile;

    fn create_test_rate_card() -> (NamedTempFile, PathBuf) {
        let file = NamedTempFile::new().unwrap();
        let path = file.path().to_path_buf();

        let content = "# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";
        fs::write(&path, content).unwrap();
        (file, path)
    }

    #[test]
    fn test_basic_domestic_quote() {
        let (_file, path) = create_test_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_higher_band() {
        let (_file, path) = create_test_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_international_zone_surcharge() {
        let (_file, path) = create_test_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 250,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1499);
        // 20% of 1499 = 299.8, rounded half-up = 300
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_weight_surcharge() {
        let (_file, path) = create_test_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_combined_surcharges() {
        let (_file, path) = create_test_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 4999);
        // 20% of 4999 = 999.8, rounded half-up = 1000
        // weight surcharge = 500
        // total surcharge = 1000 + 500 = 1500
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_unknown_zone() {
        let (_file, path) = create_test_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 250,
            zone: "unknown".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::UnknownZone(zone)) => assert_eq!(zone, "unknown"),
            _ => panic!("Expected UnknownZone error"),
        }
    }

    #[test]
    fn test_overweight() {
        let (_file, path) = create_test_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 25000,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 25000);
                assert_eq!(limit, 20000);
            },
            _ => panic!("Expected Overweight error"),
        }
    }

    #[test]
    fn test_missing_ratecard() {
        env::set_var("RATECARD_PATH", "/nonexistent/path");

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => {},
            _ => panic!("Expected RateCardUnavailable error"),
        }
    }

    #[test]
    fn test_malformed_ratecard() {
        let file = NamedTempFile::new().unwrap();
        let path = file.path().to_path_buf();

        let content = "# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\tinvalid\t899
";
        fs::write(&path, content).unwrap();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }
}
