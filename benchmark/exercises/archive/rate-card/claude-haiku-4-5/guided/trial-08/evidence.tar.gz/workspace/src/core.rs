use std::collections::BTreeMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;
use tracing::info;

/// A parcel to be shipped with weight and destination zone.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// Quote for shipping a parcel.
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Error type for quote operation failures.
#[derive(Debug, Clone)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {} grams exceeds limit {} grams", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

/// A rate band for a zone: weight threshold and base cost in cents.
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
struct Band {
    band_max_grams: u32,
    cents: u64,
}

/// Calculate a quote for shipping a parcel.
///
/// Reads the rate card from the `RATECARD_PATH` environment variable and
/// calculates the shipping cost including surcharges.
///
/// # Errors
///
/// Returns `QuoteError` if the rate card is unavailable, malformed, the zone
/// is unknown, or the parcel weight exceeds the zone's maximum.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|b| parcel.weight_grams <= b.band_max_grams)
        .ok_or_else(|| {
            let limit = bands.last().unwrap().band_max_grams;
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = band.cents;
    let surcharge_cents = calculate_surcharge(&parcel.zone, parcel.weight_grams, base_cents);
    let total_cents = base_cents + surcharge_cents;

    info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

/// Load rate card from environment variable path.
fn load_rate_card() -> Result<BTreeMap<String, Vec<Band>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut rate_card: BTreeMap<String, Vec<Band>> = BTreeMap::new();

    for (line_num, line) in content.lines().enumerate() {
        let line_number = line_num + 1;
        let trimmed = line.trim();

        // Skip empty lines and comments
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        // Parse tab-separated fields
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        rate_card
            .entry(zone)
            .or_insert_with(Vec::new)
            .push(Band {
                band_max_grams,
                cents,
            });
    }

    // Sort bands by weight threshold within each zone
    for bands in rate_card.values_mut() {
        bands.sort_by_key(|b| b.band_max_grams);
    }

    Ok(rate_card)
}

/// Calculate surcharges: heavy weight and international premium.
fn calculate_surcharge(zone: &str, weight_grams: u32, base_cents: u64) -> u64 {
    let mut surcharge = 0u64;

    // Heavy weight surcharge: 500 cents for weight > 10000 grams
    if weight_grams > 10000 {
        surcharge += 500;
    }

    // International surcharge: 20% of base, rounded half-up
    if zone == "international" {
        let international = (base_cents * 20 + 50) / 100;
        surcharge += international;
    }

    surcharge
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs::File;
    use std::io::Write;
    use tempfile::TempDir;

    fn create_rate_card(dir: &TempDir) -> String {
        let rate_card_path = dir.path().join("ratecard.txt");
        let mut file = File::create(&rate_card_path).unwrap();
        writeln!(file, "# zone\tband_max_grams\tcents").unwrap();
        writeln!(file, "domestic\t500\t599").unwrap();
        writeln!(file, "domestic\t2000\t899").unwrap();
        writeln!(file, "domestic\t20000\t1799").unwrap();
        writeln!(file, "international\t500\t1499").unwrap();
        writeln!(file, "international\t20000\t4999").unwrap();
        rate_card_path.to_string_lossy().to_string()
    }

    #[test]
    fn test_quote_domestic_light() {
        let dir = TempDir::new().unwrap();
        let path = create_rate_card(&dir);
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_quote_domestic_medium() {
        let dir = TempDir::new().unwrap();
        let path = create_rate_card(&dir);
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_quote_international_light() {
        let dir = TempDir::new().unwrap();
        let path = create_rate_card(&dir);
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1499);
        // 20% of 1499 = 299.8, rounded half-up = 300
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_quote_heavy_domestic() {
        let dir = TempDir::new().unwrap();
        let path = create_rate_card(&dir);
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_quote_heavy_international() {
        let dir = TempDir::new().unwrap();
        let path = create_rate_card(&dir);
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 4999);
        // 20% of 4999 = 999.8, rounded half-up = 1000
        // Heavy surcharge = 500
        // Total surcharge = 1500
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_unknown_zone() {
        let dir = TempDir::new().unwrap();
        let path = create_rate_card(&dir);
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "unknown".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "unknown"),
            _ => panic!("expected UnknownZone error"),
        }
    }

    #[test]
    fn test_overweight() {
        let dir = TempDir::new().unwrap();
        let path = create_rate_card(&dir);
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 25000,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 25000);
                assert_eq!(limit, 20000);
            }
            _ => panic!("expected Overweight error"),
        }
    }

    #[test]
    fn test_rate_card_unavailable() {
        env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => (),
            _ => panic!("expected RateCardUnavailable error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_non_numeric_weight() {
        let dir = TempDir::new().unwrap();
        let rate_card_path = dir.path().join("ratecard.txt");
        let mut file = File::create(&rate_card_path).unwrap();
        writeln!(file, "domestic\tabc\t599").unwrap();
        env::set_var("RATECARD_PATH", rate_card_path.to_string_lossy().to_string());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            _ => panic!("expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_wrong_field_count() {
        let dir = TempDir::new().unwrap();
        let rate_card_path = dir.path().join("ratecard.txt");
        let mut file = File::create(&rate_card_path).unwrap();
        writeln!(file, "domestic\t500").unwrap();
        env::set_var("RATECARD_PATH", rate_card_path.to_string_lossy().to_string());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            _ => panic!("expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_line_number_with_comments() {
        let dir = TempDir::new().unwrap();
        let rate_card_path = dir.path().join("ratecard.txt");
        let mut file = File::create(&rate_card_path).unwrap();
        writeln!(file, "# comment").unwrap();
        writeln!(file, "domestic\t500\t599").unwrap();
        writeln!(file, "domestic\tabc\t599").unwrap();
        env::set_var("RATECARD_PATH", rate_card_path.to_string_lossy().to_string());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
            _ => panic!("expected MalformedRateCard error at line 3"),
        }
    }

    #[test]
    fn test_band_matching_exact_boundary() {
        let dir = TempDir::new().unwrap();
        let path = create_rate_card(&dir);
        env::set_var("RATECARD_PATH", &path);

        // Exactly 500 grams should match the 500 band
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_international_surcharge_rounding() {
        let dir = TempDir::new().unwrap();
        let rate_card_path = dir.path().join("ratecard.txt");
        let mut file = File::create(&rate_card_path).unwrap();
        writeln!(file, "test_zone\t500\t1000").unwrap();
        env::set_var("RATECARD_PATH", rate_card_path.to_string_lossy().to_string());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "test_zone".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1000);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 1000);
    }

    #[test]
    fn test_error_display() {
        let err = QuoteError::UnknownZone("mars".to_string());
        assert_eq!(format!("{}", err), "unknown zone: mars");

        let err = QuoteError::Overweight {
            grams: 30000,
            limit: 20000,
        };
        assert_eq!(
            format!("{}", err),
            "parcel 30000 grams exceeds limit 20000 grams"
        );

        let err = QuoteError::MalformedRateCard { line: 5 };
        assert_eq!(format!("{}", err), "malformed rate card at line 5");

        let err = QuoteError::RateCardUnavailable;
        assert_eq!(format!("{}", err), "rate card unavailable");
    }
}
