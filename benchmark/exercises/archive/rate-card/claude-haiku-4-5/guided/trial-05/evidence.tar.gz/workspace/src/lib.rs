pub mod zones;

use std::collections::BTreeMap;
use std::fmt;
use std::fs;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => write!(f, "overweight: {} grams exceeds limit {} grams", grams, limit),
        }
    }
}

impl std::error::Error for QuoteError {}

struct RateBand {
    band_max_grams: u32,
    cents: u64,
}

fn parse_rate_card(content: &str) -> Result<BTreeMap<String, Vec<RateBand>>, QuoteError> {
    let mut zones: BTreeMap<String, Vec<RateBand>> = BTreeMap::new();

    for (line_num, line) in content.lines().enumerate() {
        let line_number = line_num + 1;
        let trimmed = line.trim();

        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        zones
            .entry(zone)
            .or_insert_with(Vec::new)
            .push(RateBand {
                band_max_grams,
                cents,
            });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|b| b.band_max_grams);
    }

    Ok(zones)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let ratecard_path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let content = fs::read_to_string(&ratecard_path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let zones = parse_rate_card(&content)?;

    let bands = zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let matching_band = bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = bands.last().unwrap().band_max_grams;
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = matching_band.cents;
    let band_max_grams = matching_band.band_max_grams;

    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let international_surcharge = (base_cents as f64 * 0.2).round() as u64;
        surcharge_cents += international_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    tracing::info!(
        zone = parcel.zone.as_str(),
        weight_grams = parcel.weight_grams,
        total_cents = total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    fn create_test_ratecard() -> (tempfile::TempDir, String) {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("ratecard.txt");
        let mut file = std::fs::File::create(&path).unwrap();

        writeln!(file, "# zone\tband_max_grams\tcents").unwrap();
        writeln!(file, "domestic\t500\t599").unwrap();
        writeln!(file, "domestic\t2000\t899").unwrap();
        writeln!(file, "domestic\t20000\t1799").unwrap();
        writeln!(file, "international\t500\t1499").unwrap();
        writeln!(file, "international\t20000\t4999").unwrap();

        let path_str = path.to_string_lossy().to_string();
        (dir, path_str)
    }

    #[test]
    fn test_quote_domestic_small() {
        let (_dir, path) = create_test_ratecard();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_quote_domestic_medium() {
        let (_dir, path) = create_test_ratecard();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 1000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_quote_domestic_heavy() {
        let (_dir, path) = create_test_ratecard();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_quote_international_small() {
        let (_dir, path) = create_test_ratecard();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 200,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 1499);
        let expected_surcharge = (1499u64 as f64 * 0.2).round() as u64;
        assert_eq!(quote.surcharge_cents, expected_surcharge);
        assert_eq!(quote.total_cents, 1499 + expected_surcharge);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_quote_international_heavy() {
        let (_dir, path) = create_test_ratecard();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 4999);
        let expected_surcharge = 500 + (4999u64 as f64 * 0.2).round() as u64;
        assert_eq!(quote.surcharge_cents, expected_surcharge);
        assert_eq!(quote.total_cents, 4999 + expected_surcharge);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_error_unknown_zone() {
        let (_dir, path) = create_test_ratecard();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "invalid_zone".to_string(),
        };
        let error = quote(&parcel).unwrap_err();

        match error {
            QuoteError::UnknownZone(zone) => assert_eq!(zone, "invalid_zone"),
            _ => panic!("Expected UnknownZone error"),
        }
    }

    #[test]
    fn test_error_overweight() {
        let (_dir, path) = create_test_ratecard();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 50000,
            zone: "domestic".to_string(),
        };
        let error = quote(&parcel).unwrap_err();

        match error {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 50000);
                assert_eq!(limit, 20000);
            }
            _ => panic!("Expected Overweight error"),
        }
    }

    #[test]
    fn test_error_missing_ratecard() {
        std::env::set_var("RATECARD_PATH", "/nonexistent/path/ratecard.txt");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let error = quote(&parcel).unwrap_err();

        match error {
            QuoteError::RateCardUnavailable => {}
            _ => panic!("Expected RateCardUnavailable error"),
        }
    }

    #[test]
    fn test_error_unset_ratecard_path() {
        std::env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let error = quote(&parcel).unwrap_err();

        match error {
            QuoteError::RateCardUnavailable => {}
            _ => panic!("Expected RateCardUnavailable error"),
        }
    }

    #[test]
    fn test_error_malformed_ratecard_bad_format() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("ratecard.txt");
        let mut file = std::fs::File::create(&path).unwrap();

        writeln!(file, "domestic\t500").unwrap();

        let path_str = path.to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path_str);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let error = quote(&parcel).unwrap_err();

        match error {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_error_malformed_ratecard_bad_number() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("ratecard.txt");
        let mut file = std::fs::File::create(&path).unwrap();

        writeln!(file, "domestic\tabc\t599").unwrap();

        let path_str = path.to_string_lossy().to_string();
        std::env::set_var("RATECARD_PATH", &path_str);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let error = quote(&parcel).unwrap_err();

        match error {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_band_selection_exact_match() {
        let (_dir, path) = create_test_ratecard();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_surcharge_boundary_10000() {
        let (_dir, path) = create_test_ratecard();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel_below = Parcel {
            weight_grams: 10000,
            zone: "domestic".to_string(),
        };
        let quote_below = quote(&parcel_below).unwrap();
        assert_eq!(quote_below.surcharge_cents, 0);

        let parcel_above = Parcel {
            weight_grams: 10001,
            zone: "domestic".to_string(),
        };
        let quote_above = quote(&parcel_above).unwrap();
        assert_eq!(quote_above.surcharge_cents, 500);
    }

    #[test]
    fn test_display_error_messages() {
        let err_unavailable = QuoteError::RateCardUnavailable;
        assert_eq!(err_unavailable.to_string(), "rate card unavailable");

        let err_malformed = QuoteError::MalformedRateCard { line: 5 };
        assert_eq!(err_malformed.to_string(), "malformed rate card at line 5");

        let err_zone = QuoteError::UnknownZone("custom".to_string());
        assert_eq!(err_zone.to_string(), "unknown zone: custom");

        let err_overweight = QuoteError::Overweight { grams: 50000, limit: 20000 };
        assert_eq!(err_overweight.to_string(), "overweight: 50000 grams exceeds limit 20000 grams");
    }
}
