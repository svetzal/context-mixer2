pub mod zones;

use std::error::Error;
use std::fmt;
use std::fs;

#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "Parcel weight {} grams exceeds zone limit of {} grams", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

struct RateBand {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<Vec<RateBand>, QuoteError> {
    let path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let content = fs::read_to_string(&path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands = Vec::new();

    for (line_num, line) in content.lines().enumerate() {
        let line_num = line_num + 1;

        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].to_string();
        let band_max_grams = parts[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = parts[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        bands.push(RateBand {
            zone,
            band_max_grams,
            cents,
        });
    }

    Ok(bands)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_rate_card()?;

    let mut zone_bands: Vec<_> = bands
        .iter()
        .filter(|b| b.zone == parcel.zone)
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.band_max_grams);

    let matching_band = zone_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = zone_bands.last().unwrap().band_max_grams;
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = matching_band.cents;
    let band_max_grams = matching_band.band_max_grams;

    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let intl_surcharge = (base_cents * 20 + 50) / 100;
        surcharge_cents += intl_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!("zone: {}, weight_grams: {}, total_cents: {}", parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::NamedTempFile;
    use std::io::Write;
    use std::sync::Mutex;

    static TEST_LOCK: Mutex<()> = Mutex::new(());

    fn create_rate_card(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();
        file
    }

    #[test]
    fn test_domestic_quote_small_parcel() {
        let _guard = TEST_LOCK.lock().unwrap();
        let card_content = "domestic\t500\t599\ndomestic\t2000\t899\n";
        let file = create_rate_card(card_content);
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_quote_medium_parcel() {
        let _guard = TEST_LOCK.lock().unwrap();
        let card_content = "domestic\t500\t599\ndomestic\t2000\t899\n";
        let file = create_rate_card(card_content);
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 1000,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_domestic_heavy_surcharge() {
        let _guard = TEST_LOCK.lock().unwrap();
        let card_content = "domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n";
        let file = create_rate_card(card_content);
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_international_quote() {
        let _guard = TEST_LOCK.lock().unwrap();
        let card_content = "domestic\t500\t599\ninternational\t500\t1499\ninternational\t20000\t4999\n";
        let file = create_rate_card(card_content);
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1499);
        let expected_surcharge = (1499 * 20 + 50) / 100;
        assert_eq!(quote.surcharge_cents, expected_surcharge);
        assert_eq!(quote.total_cents, 1499 + expected_surcharge);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_international_heavy() {
        let _guard = TEST_LOCK.lock().unwrap();
        let card_content = "domestic\t500\t599\ninternational\t500\t1499\ninternational\t20000\t4999\n";
        let file = create_rate_card(card_content);
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 4999);
        let intl_surcharge = (4999 * 20 + 50) / 100;
        let total_surcharge = 500 + intl_surcharge;
        assert_eq!(quote.surcharge_cents, total_surcharge);
        assert_eq!(quote.total_cents, 4999 + total_surcharge);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_unknown_zone() {
        let _guard = TEST_LOCK.lock().unwrap();
        let card_content = "domestic\t500\t599\n";
        let file = create_rate_card(card_content);
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "unknown".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "unknown"),
            _ => panic!("Expected UnknownZone error"),
        }
    }

    #[test]
    fn test_overweight() {
        let _guard = TEST_LOCK.lock().unwrap();
        let card_content = "domestic\t500\t599\ndomestic\t2000\t899\n";
        let file = create_rate_card(card_content);
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 3000,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 3000);
                assert_eq!(limit, 2000);
            }
            _ => panic!("Expected Overweight error"),
        }
    }

    #[test]
    fn test_missing_rate_card() {
        std::env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => {}
            _ => panic!("Expected RateCardUnavailable error"),
        }
    }

    #[test]
    fn test_rate_card_path_with_comments_and_blanks() {
        let _guard = TEST_LOCK.lock().unwrap();
        let card_content = "# Zone definitions\n\ndomestic\t500\t599\n\n# Heavy goods\ndomestic\t2000\t899\n";
        let file = create_rate_card(card_content);
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
    }

    #[test]
    fn test_malformed_rate_card_not_three_fields() {
        let _guard = TEST_LOCK.lock().unwrap();
        let card_content = "domestic\t500\n";
        let file = create_rate_card(card_content);
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_non_numeric() {
        let _guard = TEST_LOCK.lock().unwrap();
        let card_content = "domestic\tnotanumber\t599\n";
        let file = create_rate_card(card_content);
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_line_number_counting_includes_comments() {
        let _guard = TEST_LOCK.lock().unwrap();
        let card_content = "# Comment line 1\n# Comment line 2\ndomestic\tinvalid\t599\n";
        let file = create_rate_card(card_content);
        let path = file.path().to_path_buf();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
            other => panic!("Expected MalformedRateCard error on line 3, got {:?}", other),
        }
    }

    #[test]
    fn test_error_display_trait() {
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "Rate card unavailable"
        );
        assert_eq!(
            QuoteError::MalformedRateCard { line: 5 }.to_string(),
            "Malformed rate card at line 5"
        );
        assert_eq!(
            QuoteError::UnknownZone("test_zone".to_string()).to_string(),
            "Unknown zone: test_zone"
        );
        assert_eq!(
            QuoteError::Overweight { grams: 3000, limit: 2000 }.to_string(),
            "Parcel weight 3000 grams exceeds zone limit of 2000 grams"
        );
    }
}
