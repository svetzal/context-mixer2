pub mod zones;

use std::collections::BTreeMap;
use std::error::Error;
use std::fmt;
use std::fs;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card on line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel too heavy: {} grams exceeds limit {}", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

struct RateBand {
    band_max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card_path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let content = fs::read_to_string(&rate_card_path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut zones: BTreeMap<String, Vec<RateBand>> = BTreeMap::new();

    for (line_idx, line) in content.lines().enumerate() {
        let line_number = line_idx + 1;
        let trimmed = line.trim();

        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        zones
            .entry(zone)
            .or_insert_with(Vec::new)
            .push(RateBand { band_max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|b| b.band_max_grams);
    }

    let bands = zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|b| parcel.weight_grams <= b.band_max_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: bands.last().map(|b| b.band_max_grams).unwrap_or(0),
        })?;

    let base_cents = band.cents;

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let intl_surcharge = (base_cents as f64 * 0.20).round() as u64;
        surcharge_cents += intl_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "DIAG: quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn create_test_rate_card() -> (NamedTempFile, String) {
        let mut file = NamedTempFile::new().expect("Failed to create temp file");
        let content = "# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";
        file.write_all(content.as_bytes())
            .expect("Failed to write to temp file");
        file.flush().expect("Failed to flush temp file");
        let path = file.path().to_string_lossy().to_string();
        (file, path)
    }

    #[test]
    fn test_basic_domestic_quote() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).expect("Quote should succeed");
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_band_selection() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).expect("Quote should succeed");
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_weight_surcharge() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).expect("Quote should succeed");
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn test_international_surcharge() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).expect("Quote should succeed");
        assert_eq!(quote.base_cents, 1499);
        let expected_surcharge = ((1499.0 * 0.20) as f64).round() as u64;
        assert_eq!(quote.surcharge_cents, expected_surcharge);
        assert_eq!(quote.total_cents, 1499 + expected_surcharge);
    }

    #[test]
    fn test_combined_surcharges() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).expect("Quote should succeed");
        assert_eq!(quote.base_cents, 4999);
        let intl_surcharge = ((4999.0 * 0.20) as f64).round() as u64;
        let expected_surcharge = 500 + intl_surcharge;
        assert_eq!(quote.surcharge_cents, expected_surcharge);
        assert_eq!(quote.total_cents, 4999 + expected_surcharge);
    }

    #[test]
    fn test_unknown_zone() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "unknown".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::UnknownZone(zone)) => assert_eq!(zone, "unknown"),
            _ => panic!("Expected UnknownZone error"),
        }
    }

    #[test]
    fn test_overweight() {
        let (_file, path) = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 25000,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 25000);
                assert_eq!(limit, 20000);
            }
            _ => panic!("Expected Overweight error"),
        }
    }

    #[test]
    fn test_missing_rate_card() {
        std::env::set_var("RATECARD_PATH", "/nonexistent/path/rate.card");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => {}
            _ => panic!("Expected RateCardUnavailable error"),
        }
    }

    #[test]
    fn test_malformed_rate_card() {
        let mut file = NamedTempFile::new().expect("Failed to create temp file");
        let content = "# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\tinvalid
";
        file.write_all(content.as_bytes())
            .expect("Failed to write to temp file");
        file.flush().expect("Failed to flush temp file");
        let path = file.path().to_string_lossy().to_string();

        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_rounding_half_up() {
        let mut file = NamedTempFile::new().expect("Failed to create temp file");
        let content = "domestic\t500\t1000
international\t500\t1000
";
        file.write_all(content.as_bytes())
            .expect("Failed to write to temp file");
        file.flush().expect("Failed to flush temp file");
        let path = file.path().to_string_lossy().to_string();

        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).expect("Quote should succeed");
        let expected_surcharge = ((1000.0 * 0.20) as f64).round() as u64;
        assert_eq!(expected_surcharge, 200);
        assert_eq!(quote.surcharge_cents, 200);
    }
}
