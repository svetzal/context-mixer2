pub mod zones;

use std::collections::BTreeMap;
use std::env;
use std::fmt;
use std::fs;

#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {} grams exceeds limit {} grams", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct RateBand {
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<BTreeMap<String, Vec<RateBand>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut rate_card: BTreeMap<String, Vec<RateBand>> = BTreeMap::new();

    for (line_num, line) in content.lines().enumerate() {
        let line_number = line_num + 1;

        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        rate_card
            .entry(zone)
            .or_insert_with(Vec::new)
            .push(RateBand {
                band_max_grams,
                cents,
            });
    }

    // Sort bands for each zone by band_max_grams
    for bands in rate_card.values_mut() {
        bands.sort_by_key(|b| b.band_max_grams);
    }

    Ok(rate_card)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;

    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let matching_band = bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let max_limit = bands.last().unwrap().band_max_grams;
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: max_limit,
            }
        })?;

    let base_cents = matching_band.cents;
    let band_max_grams = matching_band.band_max_grams;

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let international_surcharge = (base_cents as f64 * 0.2).round() as u64;
        surcharge_cents += international_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    let result = Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    };

    eprintln!(
        "quote: zone={}, weight_grams={}, total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn create_test_rate_card() -> (NamedTempFile, String) {
        let mut file = NamedTempFile::new().unwrap();
        let content = "# zone\tband_max_grams\tcents\n\
                       domestic\t500\t599\n\
                       domestic\t2000\t899\n\
                       domestic\t20000\t1799\n\
                       international\t500\t1499\n\
                       international\t20000\t4999\n";
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();
        let path = file.path().to_str().unwrap().to_string();
        (file, path)
    }

    #[test]
    fn test_missing_rate_card() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_unknown_zone() {
        let (_file, path) = create_test_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "unknown".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::UnknownZone(ref z)) if z == "unknown"));
    }

    #[test]
    fn test_overweight_domestic() {
        let (_file, path) = create_test_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 25000,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::Overweight { grams: 25000, limit: 20000 })));
    }

    #[test]
    fn test_domestic_light() {
        let (_file, path) = create_test_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 599);
        assert_eq!(result.surcharge_cents, 0);
        assert_eq!(result.total_cents, 599);
        assert_eq!(result.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_heavy() {
        let (_file, path) = create_test_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 1799);
        assert_eq!(result.surcharge_cents, 500);
        assert_eq!(result.total_cents, 2299);
        assert_eq!(result.band_max_grams, 20000);
    }

    #[test]
    fn test_international_light() {
        let (_file, path) = create_test_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        };
        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 1499);
        let expected_surcharge = (1499.0_f64 * 0.2).round() as u64;
        assert_eq!(result.surcharge_cents, expected_surcharge);
        assert_eq!(result.total_cents, 1499 + expected_surcharge);
        assert_eq!(result.band_max_grams, 500);
    }

    #[test]
    fn test_international_heavy() {
        let (_file, path) = create_test_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 4999);
        let weight_surcharge = 500;
        let intl_surcharge = (4999.0_f64 * 0.2).round() as u64;
        assert_eq!(result.surcharge_cents, weight_surcharge + intl_surcharge);
        assert_eq!(result.total_cents, 4999 + weight_surcharge + intl_surcharge);
        assert_eq!(result.band_max_grams, 20000);
    }

    #[test]
    fn test_band_boundary() {
        let (_file, path) = create_test_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 599);
        assert_eq!(result.band_max_grams, 500);
    }

    #[test]
    fn test_between_bands() {
        let (_file, path) = create_test_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 899);
        assert_eq!(result.band_max_grams, 2000);
    }

    #[test]
    fn test_malformed_rate_card() {
        let mut file = NamedTempFile::new().unwrap();
        let content = "# zone\tband_max_grams\tcents\n\
                       domestic\t500\n";
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();
        let path = file.path().to_str().unwrap().to_string();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 2 })));
    }

    #[test]
    fn test_malformed_number() {
        let mut file = NamedTempFile::new().unwrap();
        let content = "# zone\tband_max_grams\tcents\n\
                       domestic\tabc\t599\n";
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();
        let path = file.path().to_str().unwrap().to_string();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 2 })));
    }
}
