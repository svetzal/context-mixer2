pub mod zones;

use std::collections::BTreeMap;
use std::error::Error;
use std::fmt;
use std::fs;

#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {} grams exceeds limit of {}", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

struct Band {
    band_max_grams: u32,
    cents: u64,
}

fn read_rate_card() -> Result<BTreeMap<String, Vec<Band>>, QuoteError> {
    let path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let content = fs::read_to_string(&path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

    for (line_num, line) in content.lines().enumerate() {
        let line_num = line_num + 1;

        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        zones
            .entry(zone)
            .or_insert_with(Vec::new)
            .push(Band {
                band_max_grams,
                cents,
            });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|b| b.band_max_grams);
    }

    Ok(zones)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let zones = read_rate_card()?;

    let bands = zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: bands.last().unwrap().band_max_grams,
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let intl_surcharge = (base_cents * 20 + 50) / 100;
        surcharge_cents += intl_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "DIAG zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn create_test_rate_card(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();
        file
    }

    #[test]
    fn test_domestic_under_500g() {
        let file = create_test_rate_card(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n\
             international\t500\t1499\n\
             international\t20000\t4999\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_heavy_over_10000g() {
        let file = create_test_rate_card(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_international_adds_20_percent() {
        let file = create_test_rate_card(
            "domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n\
             international\t500\t1000\n\
             international\t20000\t5000\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 1000);
        let expected_surcharge = (1000 * 20 + 50) / 100;
        assert_eq!(quote.surcharge_cents, expected_surcharge);
        assert_eq!(quote.total_cents, 1000 + expected_surcharge);
    }

    #[test]
    fn test_international_heavy_both_surcharges() {
        let file = create_test_rate_card(
            "domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n\
             international\t500\t1000\n\
             international\t20000\t5000\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 5000);
        let intl_surcharge = (5000 * 20 + 50) / 100;
        let expected_surcharge = 500 + intl_surcharge;
        assert_eq!(quote.surcharge_cents, expected_surcharge);
        assert_eq!(quote.total_cents, 5000 + expected_surcharge);
    }

    #[test]
    fn test_unknown_zone() {
        let file = create_test_rate_card(
            "domestic\t500\t599\n\
             international\t500\t1499\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "martian".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::UnknownZone(zone)) => assert_eq!(zone, "martian"),
            _ => panic!("Expected UnknownZone error"),
        }
    }

    #[test]
    fn test_overweight() {
        let file = create_test_rate_card(
            "domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 25000,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 25000);
                assert_eq!(limit, 20000);
            }
            _ => panic!("Expected Overweight error"),
        }
    }

    #[test]
    fn test_rate_card_unavailable() {
        std::env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => {},
            _ => panic!("Expected RateCardUnavailable error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_non_numeric() {
        let file = create_test_rate_card(
            "domestic\t500\tabc\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_wrong_columns() {
        let file = create_test_rate_card(
            "domestic\t500\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_line_numbering() {
        let file = create_test_rate_card(
            "# comment\n\
             \n\
             domestic\t500\tinvalid\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_band_matching_first_fit() {
        let file = create_test_rate_card(
            "domestic\t500\t100\n\
             domestic\t2000\t200\n\
             domestic\t20000\t300\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 501,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 200);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_error_display_trait() {
        let err = QuoteError::UnknownZone("test".to_string());
        assert_eq!(format!("{}", err), "unknown zone: test");

        let err = QuoteError::Overweight {
            grams: 100,
            limit: 50,
        };
        assert_eq!(
            format!("{}", err),
            "overweight: 100 grams exceeds limit of 50"
        );

        let err = QuoteError::RateCardUnavailable;
        assert_eq!(format!("{}", err), "rate card unavailable");

        let err = QuoteError::MalformedRateCard { line: 5 };
        assert_eq!(format!("{}", err), "malformed rate card at line 5");
    }
}
