pub mod zones;

use std::collections::BTreeMap;
use std::fmt;
use std::fs;
use std::path::Path;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {} grams exceeds limit {} grams", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct RateBand {
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card(path: &Path) -> Result<BTreeMap<String, Vec<RateBand>>, QuoteError> {
    let content = fs::read_to_string(path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut rate_card: BTreeMap<String, Vec<RateBand>> = BTreeMap::new();

    for (line_num, line) in content.lines().enumerate() {
        let line_number = line_num + 1;

        // Skip empty lines and comments
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1].parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = parts[2].parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        rate_card
            .entry(zone)
            .or_insert_with(Vec::new)
            .push(RateBand {
                band_max_grams,
                cents,
            });
    }

    // Sort bands for each zone by band_max_grams
    for bands in rate_card.values_mut() {
        bands.sort_by_key(|b| b.band_max_grams);
    }

    Ok(rate_card)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card_path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let rate_card = load_rate_card(Path::new(&rate_card_path))?;

    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    // Find the matching band: first one where band_max_grams >= weight
    let band = bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: bands.last().unwrap().band_max_grams,
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    // Weight surcharge: > 10000 grams adds 500 cents
    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    // International surcharge: 20% of base_cents, rounded half-up
    if parcel.zone == "international" {
        let international_surcharge = (base_cents * 20 + 50) / 100; // half-up rounding
        surcharge_cents += international_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    // Observability: emit diagnostic record
    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn create_test_rate_card() -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        writeln!(file, "# zone\tband_max_grams\tcents").unwrap();
        writeln!(file, "domestic\t500\t599").unwrap();
        writeln!(file, "domestic\t2000\t899").unwrap();
        writeln!(file, "domestic\t20000\t1799").unwrap();
        writeln!(file, "international\t500\t1499").unwrap();
        writeln!(file, "international\t20000\t4999").unwrap();
        file
    }

    #[test]
    fn test_domestic_light_parcel() {
        let file = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_medium_parcel() {
        let file = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_domestic_heavy_parcel() {
        let file = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500); // > 10000 grams
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_international_light_parcel() {
        let file = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1499);
        // International surcharge: 1499 * 20 / 100 = 299.8, rounded up = 300
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_international_heavy_parcel() {
        let file = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 4999);
        // Weight surcharge: 500
        // International surcharge: 4999 * 20 / 100 = 999.8, rounded up = 1000
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_unknown_zone() {
        let file = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "unknown".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "unknown"),
            _ => panic!("Expected UnknownZone error"),
        }
    }

    #[test]
    fn test_overweight() {
        let file = create_test_rate_card();
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 30000,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 30000);
                assert_eq!(limit, 20000);
            }
            _ => panic!("Expected Overweight error"),
        }
    }

    #[test]
    fn test_rate_card_unavailable() {
        std::env::set_var("RATECARD_PATH", "/nonexistent/path");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => {}
            _ => panic!("Expected RateCardUnavailable error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_wrong_field_count() {
        let mut file = NamedTempFile::new().unwrap();
        writeln!(file, "domestic\t500").unwrap(); // Missing cents field
        file.flush().unwrap();

        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line: 1 }) => {}
            _ => panic!("Expected MalformedRateCard error at line 1"),
        }
    }

    #[test]
    fn test_malformed_rate_card_invalid_number() {
        let mut file = NamedTempFile::new().unwrap();
        writeln!(file, "domestic\tabc\t599").unwrap(); // Invalid band_max_grams
        file.flush().unwrap();

        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line: 1 }) => {}
            _ => panic!("Expected MalformedRateCard error at line 1"),
        }
    }

    #[test]
    fn test_comments_and_blank_lines_ignored() {
        let mut file = NamedTempFile::new().unwrap();
        writeln!(file, "# This is a comment").unwrap();
        writeln!(file, "").unwrap();
        writeln!(file, "domestic\t500\t599").unwrap();
        writeln!(file, "# Another comment").unwrap();
        writeln!(file, "").unwrap();
        writeln!(file, "domestic\t2000\t899").unwrap();
        file.flush().unwrap();

        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_error_display() {
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "rate card unavailable"
        );
        assert_eq!(
            QuoteError::MalformedRateCard { line: 5 }.to_string(),
            "malformed rate card at line 5"
        );
        assert_eq!(
            QuoteError::UnknownZone("mars".to_string()).to_string(),
            "unknown zone: mars"
        );
        assert_eq!(
            QuoteError::Overweight { grams: 30000, limit: 20000 }.to_string(),
            "parcel weight 30000 grams exceeds limit 20000 grams"
        );
    }
}
