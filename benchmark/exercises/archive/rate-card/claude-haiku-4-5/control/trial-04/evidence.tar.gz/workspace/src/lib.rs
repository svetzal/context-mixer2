pub mod zones;

use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::fmt;
use std::error::Error;

#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "Malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "Parcel weight {} grams exceeds limit {} grams", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone)]
struct Band {
    band_max_grams: u32,
    cents: u64,
}

#[derive(Debug, Clone)]
struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

impl RateCard {
    fn load() -> Result<Self, QuoteError> {
        let path = env::var("RATECARD_PATH")
            .map_err(|_| QuoteError::RateCardUnavailable)?;

        let content = fs::read_to_string(&path)
            .map_err(|_| QuoteError::RateCardUnavailable)?;

        let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();
        let mut line_number = 0;

        for line in content.lines() {
            line_number += 1;

            let trimmed = line.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }

            let parts: Vec<&str> = line.split('\t').collect();
            if parts.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: line_number });
            }

            let zone = parts[0].to_string();
            let band_max_grams: u32 = parts[1].parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
            let cents: u64 = parts[2].parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

            zones.entry(zone).or_insert_with(Vec::new).push(Band {
                band_max_grams,
                cents,
            });
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|b| b.band_max_grams);
        }

        Ok(RateCard { zones })
    }

    fn get_quote(&self, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let bands = self.zones.get(&parcel.zone)
            .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

        let band = bands.iter()
            .find(|b| b.band_max_grams >= parcel.weight_grams)
            .ok_or_else(|| {
                let limit = bands.last().map(|b| b.band_max_grams).unwrap_or(0);
                QuoteError::Overweight {
                    grams: parcel.weight_grams,
                    limit,
                }
            })?;

        let base_cents = band.cents;
        let mut surcharge_cents = 0u64;

        if parcel.weight_grams > 10000 {
            surcharge_cents += 500;
        }

        if parcel.zone == "international" {
            let international_surcharge = (base_cents * 20 + 50) / 100;
            surcharge_cents += international_surcharge;
        }

        let total_cents = base_cents + surcharge_cents;

        Ok(Quote {
            base_cents,
            surcharge_cents,
            total_cents,
            band_max_grams: band.band_max_grams,
        })
    }
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = RateCard::load()?;
    let quote = rate_card.get_quote(parcel)?;

    eprintln!(
        "Zone: {}, Weight: {} grams, Total: {} cents",
        parcel.zone, parcel.weight_grams, quote.total_cents
    );

    Ok(quote)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::path::PathBuf;
    use tempfile::TempDir;

    fn setup_rate_card() -> (TempDir, PathBuf) {
        let temp_dir = TempDir::new().unwrap();
        let rate_card_path = temp_dir.path().join("rate_card.txt");

        let content = "# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

        fs::write(&rate_card_path, content).unwrap();
        (temp_dir, rate_card_path)
    }

    #[test]
    fn test_simple_domestic_quote() {
        let (temp_dir, path) = setup_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);

        drop(temp_dir);
    }

    #[test]
    fn test_weight_surcharge() {
        let (temp_dir, path) = setup_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };

        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);

        drop(temp_dir);
    }

    #[test]
    fn test_international_surcharge() {
        let (temp_dir, path) = setup_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        };

        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 1499);
        let expected_surcharge = (1499 * 20 + 50) / 100;
        assert_eq!(q.surcharge_cents, expected_surcharge);
        assert_eq!(q.total_cents, 1499 + expected_surcharge);
        assert_eq!(q.band_max_grams, 500);

        drop(temp_dir);
    }

    #[test]
    fn test_combined_surcharges() {
        let (temp_dir, path) = setup_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };

        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 4999);
        let international_surcharge = (4999 * 20 + 50) / 100;
        let weight_surcharge = 500;
        let expected_surcharge = international_surcharge + weight_surcharge;
        assert_eq!(q.surcharge_cents, expected_surcharge);
        assert_eq!(q.total_cents, 4999 + expected_surcharge);
        assert_eq!(q.band_max_grams, 20000);

        drop(temp_dir);
    }

    #[test]
    fn test_unknown_zone() {
        let (temp_dir, path) = setup_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "unknown".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "unknown"),
            _ => panic!("Expected UnknownZone error"),
        }

        drop(temp_dir);
    }

    #[test]
    fn test_overweight() {
        let (temp_dir, path) = setup_rate_card();
        env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 50000,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 50000);
                assert_eq!(limit, 20000);
            }
            _ => panic!("Expected Overweight error"),
        }

        drop(temp_dir);
    }

    #[test]
    fn test_missing_rate_card() {
        env::set_var("RATECARD_PATH", "/nonexistent/path/to/rate_card.txt");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => {}
            _ => panic!("Expected RateCardUnavailable error"),
        }
    }

    #[test]
    fn test_malformed_rate_card() {
        let temp_dir = TempDir::new().unwrap();
        let rate_card_path = temp_dir.path().join("rate_card.txt");

        let content = "# zone\tband_max_grams\tcents
domestic\t500\t599
invalid line with no tabs
domestic\t2000\t899
";

        fs::write(&rate_card_path, content).unwrap();
        env::set_var("RATECARD_PATH", &rate_card_path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_line_counting_includes_comments_and_blanks() {
        let temp_dir = TempDir::new().unwrap();
        let rate_card_path = temp_dir.path().join("rate_card.txt");

        let content = "# comment line 1
# comment line 2

domestic\t500\t599
invalid\t500
";

        fs::write(&rate_card_path, content).unwrap();
        env::set_var("RATECARD_PATH", &rate_card_path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 5),
            _ => panic!("Expected MalformedRateCard error at line 5"),
        }
    }

    #[test]
    fn test_invalid_number_format() {
        let temp_dir = TempDir::new().unwrap();
        let rate_card_path = temp_dir.path().join("rate_card.txt");

        let content = "domestic\tabc\t599
";

        fs::write(&rate_card_path, content).unwrap();
        env::set_var("RATECARD_PATH", &rate_card_path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }
}

