pub mod zones;

use std::error::Error;
use std::fmt;
use std::fs;

#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {} grams exceeds limit {} grams", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone)]
struct RateCardBand {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<Vec<RateCardBand>, QuoteError> {
    let path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let content = fs::read_to_string(&path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands = Vec::new();
    for (line_num, line) in content.lines().enumerate() {
        let line = line.trim();

        // Skip empty lines and comments
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard {
                line: line_num + 1,
            });
        }

        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard {
                line: line_num + 1,
            })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard {
                line: line_num + 1,
            })?;

        bands.push(RateCardBand {
            zone,
            band_max_grams,
            cents,
        });
    }

    Ok(bands)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_rate_card()?;

    // Find all bands for this zone, sorted by band_max_grams
    let mut zone_bands: Vec<_> = bands
        .iter()
        .filter(|b| b.zone == parcel.zone)
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.band_max_grams);

    // Find the matching band: first whose band_max_grams >= weight
    let matching_band = zone_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: zone_bands.last().unwrap().band_max_grams,
        })?;

    let base_cents = matching_band.cents;
    let band_max_grams = matching_band.band_max_grams;

    // Calculate surcharges
    let mut surcharge_cents = 0u64;

    // Weight surcharge: +500 cents if strictly above 10000 grams
    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    // Zone surcharge: +20% of base_cents if international (rounded half-up)
    if parcel.zone == "international" {
        let international_surcharge = (base_cents * 20 + 50) / 100;
        surcharge_cents += international_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    // Emit diagnostic record
    eprintln!(
        "quote: zone={}, weight_grams={}, total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    static LOCK: Mutex<()> = Mutex::new(());

    fn with_lock<F: FnOnce()>(f: F) {
        let _guard = LOCK.lock().unwrap();
        f();
    }

    fn create_rate_card(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();
        file
    }

    #[test]
    fn test_basic_domestic_quote() {
        with_lock(|| {
            let rate_card = create_rate_card("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n");
            std::env::set_var("RATECARD_PATH", rate_card.path());

            let parcel = Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 599);
            assert_eq!(quote.surcharge_cents, 0);
            assert_eq!(quote.total_cents, 599);
            assert_eq!(quote.band_max_grams, 500);
        });
    }

    #[test]
    fn test_domestic_band_selection() {
        with_lock(|| {
            let rate_card = create_rate_card("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n");
            std::env::set_var("RATECARD_PATH", rate_card.path());

            let parcel = Parcel {
                weight_grams: 1500,
                zone: "domestic".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 899);
            assert_eq!(quote.band_max_grams, 2000);
        });
    }

    #[test]
    fn test_weight_surcharge() {
        with_lock(|| {
            let rate_card = create_rate_card("domestic\t20000\t1799\n");
            std::env::set_var("RATECARD_PATH", rate_card.path());

            let parcel = Parcel {
                weight_grams: 10001,
                zone: "domestic".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 1799);
            assert_eq!(quote.surcharge_cents, 500);
            assert_eq!(quote.total_cents, 2299);
        });
    }

    #[test]
    fn test_international_surcharge() {
        with_lock(|| {
            let rate_card = create_rate_card("international\t500\t1499\n");
            std::env::set_var("RATECARD_PATH", rate_card.path());

            let parcel = Parcel {
                weight_grams: 100,
                zone: "international".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 1499);
            // 20% of 1499 = 299.8, rounded half-up = 300
            assert_eq!(quote.surcharge_cents, 300);
            assert_eq!(quote.total_cents, 1799);
        });
    }

    #[test]
    fn test_combined_surcharges() {
        with_lock(|| {
            let rate_card = create_rate_card("international\t20000\t5000\n");
            std::env::set_var("RATECARD_PATH", rate_card.path());

            let parcel = Parcel {
                weight_grams: 10001,
                zone: "international".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 5000);
            // Weight: 500, International: 20% of 5000 = 1000
            assert_eq!(quote.surcharge_cents, 1500);
            assert_eq!(quote.total_cents, 6500);
        });
    }

    #[test]
    fn test_unknown_zone() {
        with_lock(|| {
            let rate_card = create_rate_card("domestic\t500\t599\n");
            std::env::set_var("RATECARD_PATH", rate_card.path());

            let parcel = Parcel {
                weight_grams: 100,
                zone: "unknown".to_string(),
            };

            match quote(&parcel) {
                Err(QuoteError::UnknownZone(zone)) => assert_eq!(zone, "unknown"),
                _ => panic!("Expected UnknownZone error"),
            }
        });
    }

    #[test]
    fn test_overweight() {
        with_lock(|| {
            let rate_card = create_rate_card("domestic\t500\t599\n");
            std::env::set_var("RATECARD_PATH", rate_card.path());

            let parcel = Parcel {
                weight_grams: 1000,
                zone: "domestic".to_string(),
            };

            match quote(&parcel) {
                Err(QuoteError::Overweight { grams, limit }) => {
                    assert_eq!(grams, 1000);
                    assert_eq!(limit, 500);
                }
                _ => panic!("Expected Overweight error"),
            }
        });
    }

    #[test]
    fn test_missing_rate_card() {
        with_lock(|| {
            std::env::set_var("RATECARD_PATH", "/nonexistent/path");

            let parcel = Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            };

            match quote(&parcel) {
                Err(QuoteError::RateCardUnavailable) => {}
                _ => panic!("Expected RateCardUnavailable error"),
            }
        });
    }

    #[test]
    fn test_malformed_rate_card_not_enough_fields() {
        with_lock(|| {
            let rate_card = create_rate_card("domestic\t500\n");
            std::env::set_var("RATECARD_PATH", rate_card.path());

            let parcel = Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            };

            match quote(&parcel) {
                Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
                _ => panic!("Expected MalformedRateCard error"),
            }
        });
    }

    #[test]
    fn test_malformed_rate_card_invalid_number() {
        with_lock(|| {
            let rate_card = create_rate_card("domestic\tabc\t599\n");
            std::env::set_var("RATECARD_PATH", rate_card.path());

            let parcel = Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            };

            match quote(&parcel) {
                Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
                _ => panic!("Expected MalformedRateCard error"),
            }
        });
    }

    #[test]
    fn test_rate_card_with_comments_and_blanks() {
        with_lock(|| {
            let rate_card = create_rate_card("# comment\n\ndomestic\t500\t599\n# another\ndomestic\t2000\t899\n\n");
            std::env::set_var("RATECARD_PATH", rate_card.path());

            let parcel = Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 599);
        });
    }
}
