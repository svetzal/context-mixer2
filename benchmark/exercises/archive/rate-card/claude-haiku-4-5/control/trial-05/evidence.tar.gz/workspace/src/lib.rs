use std::collections::BTreeMap;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {} grams exceeds limit of {}", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

struct RateBand {
    band_max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card_path =
        std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;

    let content =
        fs::read_to_string(&rate_card_path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut zones: BTreeMap<String, Vec<RateBand>> = BTreeMap::new();

    for (line_num, line) in content.lines().enumerate() {
        let line_num = line_num + 1;
        let trimmed = line.trim();

        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        zones
            .entry(zone)
            .or_insert_with(Vec::new)
            .push(RateBand {
                band_max_grams,
                cents,
            });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|b| b.band_max_grams);
    }

    let bands = zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let matching_band = bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = bands.last().unwrap().band_max_grams;
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = matching_band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let international_charge = (base_cents as f64 * 0.2).round() as u64;
        surcharge_cents += international_charge;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote: zone={}, weight_grams={}, total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: matching_band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn create_test_rate_card() -> (NamedTempFile, String) {
        let mut file = NamedTempFile::new().unwrap();
        let content = "# zone\tband_max_grams\tcents\n\
                       domestic\t500\t599\n\
                       domestic\t2000\t899\n\
                       domestic\t20000\t1799\n\
                       international\t500\t1499\n\
                       international\t20000\t4999\n";
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();
        let path = file.path().to_string_lossy().to_string();
        (file, path)
    }

    struct EnvGuard {
        _lock: std::sync::MutexGuard<'static, ()>,
        old_value: Option<String>,
    }

    impl EnvGuard {
        fn new(key: &str, value: &str) -> Self {
            let lock = ENV_LOCK.lock().unwrap();
            let old_value = std::env::var(key).ok();
            std::env::set_var(key, value);
            EnvGuard {
                _lock: lock,
                old_value,
            }
        }
    }

    impl Drop for EnvGuard {
        fn drop(&mut self) {
            match &self.old_value {
                Some(v) => std::env::set_var("RATECARD_PATH", v),
                None => std::env::remove_var("RATECARD_PATH"),
            }
        }
    }

    #[test]
    fn test_domestic_light() {
        let (_file, path) = create_test_rate_card();
        let _guard = EnvGuard::new("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_medium() {
        let (_file, path) = create_test_rate_card();
        let _guard = EnvGuard::new("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn test_domestic_heavy() {
        let (_file, path) = create_test_rate_card();
        let _guard = EnvGuard::new("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn test_international_light() {
        let (_file, path) = create_test_rate_card();
        let _guard = EnvGuard::new("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 250,
            zone: "international".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 1499);
        let surcharge = (1499.0_f64 * 0.2).round() as u64;
        assert_eq!(q.surcharge_cents, surcharge);
        assert_eq!(q.total_cents, q.base_cents + surcharge);
    }

    #[test]
    fn test_international_heavy() {
        let (_file, path) = create_test_rate_card();
        let _guard = EnvGuard::new("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 4999);
        let international_charge = (4999.0_f64 * 0.2).round() as u64;
        let total_surcharge = 500 + international_charge;
        assert_eq!(q.surcharge_cents, total_surcharge);
        assert_eq!(q.total_cents, q.base_cents + total_surcharge);
    }

    #[test]
    fn test_unknown_zone() {
        let (_file, path) = create_test_rate_card();
        let _guard = EnvGuard::new("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "nonexistent".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "nonexistent"),
            _ => panic!("expected UnknownZone error"),
        }
    }

    #[test]
    fn test_overweight() {
        let (_file, path) = create_test_rate_card();
        let _guard = EnvGuard::new("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 25000,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 25000);
                assert_eq!(limit, 20000);
            }
            _ => panic!("expected Overweight error"),
        }
    }

    #[test]
    fn test_missing_rate_card() {
        let _guard = EnvGuard::new("RATECARD_PATH", "/nonexistent/path/to/rate/card");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => {}
            _ => panic!("expected RateCardUnavailable error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_bad_field_count() {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(b"domestic\t500\t599\ninvalid line\n")
            .unwrap();
        file.flush().unwrap();
        let path = file.path().to_string_lossy().to_string();
        let _guard = EnvGuard::new("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 2),
            _ => panic!("expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_bad_number() {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(b"domestic\tabc\t599\n").unwrap();
        file.flush().unwrap();
        let path = file.path().to_string_lossy().to_string();
        let _guard = EnvGuard::new("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            _ => panic!("expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_boundary_exact_band_match() {
        let (_file, path) = create_test_rate_card();
        let _guard = EnvGuard::new("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn test_comments_and_blank_lines() {
        let mut file = NamedTempFile::new().unwrap();
        let content = "# This is a comment\n\
                       \n\
                       domestic\t500\t599\n\
                       \n\
                       # Another comment\n\
                       domestic\t2000\t899\n";
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();
        let path = file.path().to_string_lossy().to_string();
        let _guard = EnvGuard::new("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
    }
}
