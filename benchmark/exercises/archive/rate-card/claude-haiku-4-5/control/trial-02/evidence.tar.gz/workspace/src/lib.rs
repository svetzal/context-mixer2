pub mod zones;

use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::fmt;
use std::error::Error;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "Parcel too heavy: {} grams exceeds limit of {} grams", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

struct Band {
    band_max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card_path = env::var("RATECARD_PATH").ok();
    let rate_card_path = match rate_card_path {
        Some(path) => path,
        None => return Err(QuoteError::RateCardUnavailable),
    };

    let content = fs::read_to_string(&rate_card_path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

    for (line_num, line) in content.lines().enumerate() {
        let line_number = line_num + 1;

        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1].parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = parts[2].parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        zones.entry(zone).or_insert_with(Vec::new).push(Band {
            band_max_grams,
            cents,
        });
    }

    // Sort bands by band_max_grams
    for bands in zones.values_mut() {
        bands.sort_by_key(|b| b.band_max_grams);
    }

    let bands = zones.get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let matching_band = bands.iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = bands.last().unwrap().band_max_grams;
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = matching_band.cents;

    let mut surcharge_cents = 0u64;

    // Surcharge for weight > 10000 grams
    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    // Surcharge for international zone: 20% of base_cents, rounded half-up
    if parcel.zone == "international" {
        let international_surcharge = (base_cents * 20 + 50) / 100; // half-up rounding
        surcharge_cents += international_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!("quote: zone={}, weight_grams={}, total_cents={}", parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: matching_band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    static TEST_LOCK: Mutex<()> = Mutex::new(());

    fn create_rate_card(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();
        file
    }

    fn run_with_rate_card<F>(content: &str, test: F)
    where
        F: FnOnce(),
    {
        let _guard = TEST_LOCK.lock().unwrap();
        let rate_card = create_rate_card(content);
        env::set_var("RATECARD_PATH", rate_card.path());
        test();
        drop(rate_card);
    }

    #[test]
    fn test_basic_quote() {
        run_with_rate_card("domestic\t500\t599\ndomestic\t2000\t899\n", || {
            let parcel = Parcel {
                weight_grams: 300,
                zone: "domestic".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 599);
            assert_eq!(quote.surcharge_cents, 0);
            assert_eq!(quote.total_cents, 599);
            assert_eq!(quote.band_max_grams, 500);
        });
    }

    #[test]
    fn test_band_selection() {
        run_with_rate_card("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n", || {
            let parcel = Parcel {
                weight_grams: 1500,
                zone: "domestic".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 899);
            assert_eq!(quote.band_max_grams, 2000);
        });
    }

    #[test]
    fn test_overweight() {
        run_with_rate_card("domestic\t500\t599\ndomestic\t2000\t899\n", || {
            let parcel = Parcel {
                weight_grams: 5000,
                zone: "domestic".to_string(),
            };

            match quote(&parcel) {
                Err(QuoteError::Overweight { grams, limit }) => {
                    assert_eq!(grams, 5000);
                    assert_eq!(limit, 2000);
                }
                _ => panic!("Expected Overweight error"),
            }
        });
    }

    #[test]
    fn test_weight_surcharge() {
        run_with_rate_card("domestic\t20000\t1000\n", || {
            let parcel = Parcel {
                weight_grams: 10001,
                zone: "domestic".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 1000);
            assert_eq!(quote.surcharge_cents, 500);
            assert_eq!(quote.total_cents, 1500);
        });
    }

    #[test]
    fn test_international_surcharge() {
        run_with_rate_card("international\t500\t1000\n", || {
            let parcel = Parcel {
                weight_grams: 300,
                zone: "international".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 1000);
            // 20% of 1000 = 200
            assert_eq!(quote.surcharge_cents, 200);
            assert_eq!(quote.total_cents, 1200);
        });
    }

    #[test]
    fn test_international_surcharge_rounding() {
        run_with_rate_card("international\t500\t1500\n", || {
            let parcel = Parcel {
                weight_grams: 300,
                zone: "international".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 1500);
            // 20% of 1500 = 300
            assert_eq!(quote.surcharge_cents, 300);
            assert_eq!(quote.total_cents, 1800);
        });
    }

    #[test]
    fn test_combined_surcharges() {
        run_with_rate_card("international\t20000\t1000\n", || {
            let parcel = Parcel {
                weight_grams: 10001,
                zone: "international".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 1000);
            // 500 for weight + 200 for international
            assert_eq!(quote.surcharge_cents, 700);
            assert_eq!(quote.total_cents, 1700);
        });
    }

    #[test]
    fn test_unknown_zone() {
        run_with_rate_card("domestic\t500\t599\n", || {
            let parcel = Parcel {
                weight_grams: 300,
                zone: "unknown".to_string(),
            };

            match quote(&parcel) {
                Err(QuoteError::UnknownZone(zone)) => {
                    assert_eq!(zone, "unknown");
                }
                _ => panic!("Expected UnknownZone error"),
            }
        });
    }

    #[test]
    fn test_rate_card_unavailable() {
        env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => {}
            _ => panic!("Expected RateCardUnavailable error"),
        }
    }

    #[test]
    fn test_malformed_rate_card() {
        run_with_rate_card("domestic\t500\t599\ninvalid\n", || {
            let parcel = Parcel {
                weight_grams: 300,
                zone: "domestic".to_string(),
            };

            match quote(&parcel) {
                Err(QuoteError::MalformedRateCard { line }) => {
                    assert_eq!(line, 2);
                }
                _ => panic!("Expected MalformedRateCard error"),
            }
        });
    }

    #[test]
    fn test_malformed_rate_card_non_numeric() {
        run_with_rate_card("domestic\tabc\t599\n", || {
            let parcel = Parcel {
                weight_grams: 300,
                zone: "domestic".to_string(),
            };

            match quote(&parcel) {
                Err(QuoteError::MalformedRateCard { line }) => {
                    assert_eq!(line, 1);
                }
                _ => panic!("Expected MalformedRateCard error"),
            }
        });
    }

    #[test]
    fn test_comments_and_blanks() {
        run_with_rate_card("# zone\tband_max_grams\tcents\n\ndomestic\t500\t599\n# more comments\n\ndomestic\t2000\t899\n", || {
            let parcel = Parcel {
                weight_grams: 1500,
                zone: "domestic".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 899);
            assert_eq!(quote.band_max_grams, 2000);
        });
    }

    #[test]
    fn test_boundary_weight() {
        run_with_rate_card("domestic\t500\t599\ndomestic\t2000\t899\n", || {
            // Exactly at boundary
            let parcel = Parcel {
                weight_grams: 500,
                zone: "domestic".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 599);
            assert_eq!(quote.band_max_grams, 500);
        });
    }

    #[test]
    fn test_boundary_weight_just_over() {
        run_with_rate_card("domestic\t500\t599\ndomestic\t2000\t899\n", || {
            // Just over boundary
            let parcel = Parcel {
                weight_grams: 501,
                zone: "domestic".to_string(),
            };

            let quote = quote(&parcel).unwrap();
            assert_eq!(quote.base_cents, 899);
            assert_eq!(quote.band_max_grams, 2000);
        });
    }
}
