pub mod zones;

use std::collections::HashMap;
use std::env;
use std::fs;
use std::fmt;
use std::error::Error;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "Parcel weight {} exceeds zone limit {}", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card_path = env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let content = fs::read_to_string(&rate_card_path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let bands = parse_rate_card(&content)?;

    let zone_bands = bands.get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let matching_band = zone_bands.iter()
        .find(|(band_max, _)| *band_max >= parcel.weight_grams);

    let (band_max_grams, base_cents) = match matching_band {
        Some((band_max, cents)) => (*band_max, *cents),
        None => {
            let limit = zone_bands.iter().map(|(max, _)| *max).max().unwrap_or(0);
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let intl_surcharge = (base_cents * 20 + 50) / 100;
        surcharge_cents += intl_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!("DIAGNOSTIC: zone={}, weight_grams={}, total_cents={}",
              parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

fn parse_rate_card(content: &str) -> Result<HashMap<String, Vec<(u32, u64)>>, QuoteError> {
    let mut bands: HashMap<String, Vec<(u32, u64)>> = HashMap::new();

    for (line_num, line) in content.lines().enumerate() {
        let actual_line_num = line_num + 1;

        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: actual_line_num });
        }

        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1].parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: actual_line_num })?;
        let cents: u64 = parts[2].parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: actual_line_num })?;

        bands.entry(zone).or_insert_with(Vec::new).push((band_max_grams, cents));
    }

    for zone_bands in bands.values_mut() {
        zone_bands.sort_by_key(|(band_max, _)| *band_max);
    }

    Ok(bands)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn create_rate_card(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();
        file
    }

    #[test]
    fn test_basic_quote() {
        let file = create_rate_card("domestic\t500\t599\ndomestic\t2000\t899\n");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_band_selection() {
        let file = create_rate_card("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_heavy_surcharge() {
        let file = create_rate_card("domestic\t20000\t1799\n");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn test_international_surcharge() {
        let file = create_rate_card("international\t500\t1000\n");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1000);
        assert_eq!(quote.surcharge_cents, 200);
        assert_eq!(quote.total_cents, 1200);
    }

    #[test]
    fn test_both_surcharges() {
        let file = create_rate_card("international\t20000\t1000\n");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1000);
        assert_eq!(quote.surcharge_cents, 700);
        assert_eq!(quote.total_cents, 1700);
    }

    #[test]
    fn test_unknown_zone() {
        let file = create_rate_card("domestic\t500\t599\n");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "unknown".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::UnknownZone(zone)) => assert_eq!(zone, "unknown"),
            _ => panic!("Expected UnknownZone error"),
        }
    }

    #[test]
    fn test_overweight() {
        let file = create_rate_card("domestic\t500\t599\ndomestic\t2000\t899\n");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 5000,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 5000);
                assert_eq!(limit, 2000);
            }
            _ => panic!("Expected Overweight error"),
        }
    }

    #[test]
    fn test_missing_rate_card() {
        env::set_var("RATECARD_PATH", "/nonexistent/path/file.txt");

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => {}
            _ => panic!("Expected RateCardUnavailable error"),
        }
    }

    #[test]
    fn test_malformed_rate_card() {
        let file = create_rate_card("domestic\t500\tinvalid\n");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_wrong_field_count() {
        let file = create_rate_card("domestic\t500\n");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        match quote(&parcel) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_comments_and_blanks() {
        let file = create_rate_card("# This is a comment\n\ndomestic\t500\t599\n# Another comment\ndomestic\t2000\t899\n");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
    }

    #[test]
    fn test_international_rounding() {
        let file = create_rate_card("international\t500\t333\n");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 250,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 333);
        assert_eq!(quote.surcharge_cents, 67);
        assert_eq!(quote.total_cents, 400);
    }
}
