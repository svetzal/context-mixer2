pub mod zones;

use std::collections::HashMap;
use std::env;
use std::fmt;
use std::fs;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weighs {grams}g, exceeding the {limit}g limit")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut card: HashMap<String, Vec<Band>> = HashMap::new();

    for (idx, raw_line) in contents.lines().enumerate() {
        let line_number = idx + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = raw_line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = fields[0].trim().to_string();
        let band_max_grams: u32 = fields[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        card.entry(zone)
            .or_default()
            .push(Band { band_max_grams, cents });
    }

    Ok(card)
}

fn twenty_percent_rounded_half_up(base_cents: u64) -> u64 {
    (base_cents * 20 + 50) / 100
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = load_rate_card()?;

    let mut bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?
        .iter()
        .collect::<Vec<_>>();
    bands.sort_by_key(|band| band.band_max_grams);

    let band = match bands
        .iter()
        .find(|band| band.band_max_grams >= parcel.weight_grams)
    {
        Some(band) => *band,
        None => {
            let limit = bands.last().unwrap().band_max_grams;
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let band_max_grams = band.band_max_grams;

    let mut surcharge_cents = 0u64;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += twenty_percent_rounded_half_up(base_cents);
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "ratecard.quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    const CARD: &str = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\ninternational\t500\t1499\ninternational\t20000\t4999\n";

    fn with_rate_card<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        let _guard = ENV_LOCK.lock().unwrap();
        let mut file = tempfile::NamedTempFile::new().unwrap();
        write!(file, "{contents}").unwrap();
        env::set_var("RATECARD_PATH", file.path());
        let result = test();
        env::remove_var("RATECARD_PATH");
        result
    }

    #[test]
    fn domestic_quote_matches_smallest_sufficient_band() {
        with_rate_card(CARD, || {
            let parcel = Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            };
            let q = quote(&parcel).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
        });
    }

    #[test]
    fn boundary_weight_matches_band_inclusive() {
        with_rate_card(CARD, || {
            let parcel = Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            };
            let q = quote(&parcel).unwrap();
            assert_eq!(q.band_max_grams, 500);
            assert_eq!(q.base_cents, 599);
        });
    }

    #[test]
    fn heavy_domestic_gets_weight_surcharge() {
        with_rate_card(CARD, || {
            let parcel = Parcel {
                weight_grams: 15000,
                zone: "domestic".into(),
            };
            let q = quote(&parcel).unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
        });
    }

    #[test]
    fn international_gets_percentage_surcharge() {
        with_rate_card(CARD, || {
            let parcel = Parcel {
                weight_grams: 100,
                zone: "international".into(),
            };
            let q = quote(&parcel).unwrap();
            assert_eq!(q.base_cents, 1499);
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_heavy_gets_both_surcharges() {
        with_rate_card(CARD, || {
            let parcel = Parcel {
                weight_grams: 15000,
                zone: "international".into(),
            };
            let q = quote(&parcel).unwrap();
            assert_eq!(q.base_cents, 4999);
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
        });
    }

    #[test]
    fn unknown_zone_errors() {
        with_rate_card(CARD, || {
            let parcel = Parcel {
                weight_grams: 100,
                zone: "lunar".into(),
            };
            match quote(&parcel).unwrap_err() {
                QuoteError::UnknownZone(zone) => assert_eq!(zone, "lunar"),
                other => panic!("expected UnknownZone, got {other:?}"),
            }
        });
    }

    #[test]
    fn overweight_errors_with_limit() {
        with_rate_card(CARD, || {
            let parcel = Parcel {
                weight_grams: 25000,
                zone: "domestic".into(),
            };
            match quote(&parcel).unwrap_err() {
                QuoteError::Overweight { grams, limit } => {
                    assert_eq!(grams, 25000);
                    assert_eq!(limit, 20000);
                }
                other => panic!("expected Overweight, got {other:?}"),
            }
        });
    }

    #[test]
    fn malformed_line_missing_field_reports_line_number() {
        let card = "# header\ndomestic\t500\n";
        with_rate_card(card, || {
            let parcel = Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            };
            match quote(&parcel).unwrap_err() {
                QuoteError::MalformedRateCard { line } => assert_eq!(line, 2),
                other => panic!("expected MalformedRateCard, got {other:?}"),
            }
        });
    }

    #[test]
    fn malformed_number_counts_blanks_and_comments() {
        let card = "# header\n\ndomestic\tnotanumber\t599\n";
        with_rate_card(card, || {
            let parcel = Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            };
            match quote(&parcel).unwrap_err() {
                QuoteError::MalformedRateCard { line } => assert_eq!(line, 3),
                other => panic!("expected MalformedRateCard, got {other:?}"),
            }
        });
    }

    #[test]
    fn missing_env_var_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap();
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        assert!(matches!(
            quote(&parcel).unwrap_err(),
            QuoteError::RateCardUnavailable
        ));
    }

    #[test]
    fn missing_file_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap();
        env::set_var("RATECARD_PATH", "/nonexistent/path/does/not/exist.tsv");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        assert!(matches!(
            quote(&parcel).unwrap_err(),
            QuoteError::RateCardUnavailable
        ));
        env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn error_display_is_human_readable() {
        let err = QuoteError::UnknownZone("mars".into());
        assert_eq!(format!("{err}"), "unknown zone: mars");
    }
}
