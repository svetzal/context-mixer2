use std::collections::HashMap;

use crate::QuoteError;

pub struct Band {
    pub band_max_grams: u32,
    pub cents: u64,
}

pub struct RateCard {
    zones: HashMap<String, Vec<Band>>,
}

impl RateCard {
    pub fn parse(contents: &str) -> Result<Self, QuoteError> {
        let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

        for (index, line) in contents.lines().enumerate() {
            let line_number = index + 1;
            let trimmed = line.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }

            let fields: Vec<&str> = line.split('\t').collect();
            if fields.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: line_number });
            }

            let zone = fields[0].trim().to_string();
            let band_max_grams: u32 = fields[1]
                .trim()
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
            let cents: u64 = fields[2]
                .trim()
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

            zones
                .entry(zone)
                .or_insert_with(Vec::new)
                .push(Band { band_max_grams, cents });
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.band_max_grams);
        }

        Ok(RateCard { zones })
    }

    pub fn lookup(&self, zone: &str, weight_grams: u32) -> Result<&Band, QuoteError> {
        let bands = self
            .zones
            .get(zone)
            .ok_or_else(|| QuoteError::UnknownZone(zone.to_string()))?;

        bands
            .iter()
            .find(|band| band.band_max_grams >= weight_grams)
            .ok_or_else(|| {
                let limit = bands.last().map(|b| b.band_max_grams).unwrap_or(0);
                QuoteError::Overweight {
                    grams: weight_grams,
                    limit,
                }
            })
    }
}
