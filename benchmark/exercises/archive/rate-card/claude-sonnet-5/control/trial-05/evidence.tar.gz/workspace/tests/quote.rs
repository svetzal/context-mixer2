use std::io::Write;
use std::sync::Mutex;

use ratecard::{quote, Parcel, QuoteError};

// RATECARD_PATH is process-global state; serialize tests that touch it.
static ENV_LOCK: Mutex<()> = Mutex::new(());

const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

struct RateCardFile {
    _file: tempfile::NamedTempFile,
}

fn with_rate_card(contents: &str) -> RateCardFile {
    let mut file = tempfile::NamedTempFile::new().expect("create temp rate card");
    file.write_all(contents.as_bytes())
        .expect("write temp rate card");
    file.flush().expect("flush temp rate card");
    std::env::set_var("RATECARD_PATH", file.path());
    RateCardFile { _file: file }
}

fn parcel(zone: &str, weight_grams: u32) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_string(),
    }
}

#[test]
fn quote_picks_first_band_meeting_or_exceeding_weight() {
    let _guard = ENV_LOCK.lock().unwrap();
    let _card = with_rate_card(SAMPLE_CARD);

    let q = quote(&parcel("domestic", 500)).expect("quote");
    assert_eq!(q.base_cents, 599);
    assert_eq!(q.band_max_grams, 500);
    assert_eq!(q.surcharge_cents, 0);
    assert_eq!(q.total_cents, 599);

    let q = quote(&parcel("domestic", 501)).expect("quote");
    assert_eq!(q.base_cents, 899);
    assert_eq!(q.band_max_grams, 2000);
}

#[test]
fn quote_adds_overweight_surcharge_above_10000_grams() {
    let _guard = ENV_LOCK.lock().unwrap();
    let _card = with_rate_card(SAMPLE_CARD);

    let q = quote(&parcel("domestic", 10000)).expect("quote");
    assert_eq!(q.surcharge_cents, 0);
    assert_eq!(q.total_cents, q.base_cents);

    let q = quote(&parcel("domestic", 10001)).expect("quote");
    assert_eq!(q.base_cents, 1799);
    assert_eq!(q.surcharge_cents, 500);
    assert_eq!(q.total_cents, 2299);
}

#[test]
fn quote_adds_international_surcharge_rounded_half_up() {
    let _guard = ENV_LOCK.lock().unwrap();
    let _card = with_rate_card(SAMPLE_CARD);

    // base_cents = 1499; 20% = 299.8 -> rounds up to 300
    let q = quote(&parcel("international", 500)).expect("quote");
    assert_eq!(q.base_cents, 1499);
    assert_eq!(q.surcharge_cents, 300);
    assert_eq!(q.total_cents, 1799);
}

#[test]
fn quote_combines_overweight_and_international_surcharges() {
    let _guard = ENV_LOCK.lock().unwrap();
    let _card = with_rate_card(SAMPLE_CARD);

    // base_cents = 4999; 20% = 999.8 -> rounds up to 1000; plus 500 overweight
    let q = quote(&parcel("international", 15000)).expect("quote");
    assert_eq!(q.base_cents, 4999);
    assert_eq!(q.surcharge_cents, 1500);
    assert_eq!(q.total_cents, 6499);
}

#[test]
fn quote_rejects_unknown_zone() {
    let _guard = ENV_LOCK.lock().unwrap();
    let _card = with_rate_card(SAMPLE_CARD);

    let err = quote(&parcel("lunar", 100)).unwrap_err();
    match err {
        QuoteError::UnknownZone(zone) => assert_eq!(zone, "lunar"),
        other => panic!("expected UnknownZone, got {other:?}"),
    }
}

#[test]
fn quote_rejects_overweight_parcel() {
    let _guard = ENV_LOCK.lock().unwrap();
    let _card = with_rate_card(SAMPLE_CARD);

    let err = quote(&parcel("domestic", 20001)).unwrap_err();
    match err {
        QuoteError::Overweight { grams, limit } => {
            assert_eq!(grams, 20001);
            assert_eq!(limit, 20000);
        }
        other => panic!("expected Overweight, got {other:?}"),
    }
}

#[test]
fn quote_reports_rate_card_unavailable_when_env_unset() {
    let _guard = ENV_LOCK.lock().unwrap();
    std::env::remove_var("RATECARD_PATH");

    let err = quote(&parcel("domestic", 100)).unwrap_err();
    assert!(matches!(err, QuoteError::RateCardUnavailable));
}

#[test]
fn quote_reports_rate_card_unavailable_when_file_missing() {
    let _guard = ENV_LOCK.lock().unwrap();
    std::env::set_var("RATECARD_PATH", "/nonexistent/path/does-not-exist.tsv");

    let err = quote(&parcel("domestic", 100)).unwrap_err();
    assert!(matches!(err, QuoteError::RateCardUnavailable));
}

#[test]
fn quote_reports_malformed_line_with_wrong_field_count() {
    let _guard = ENV_LOCK.lock().unwrap();
    let card = "domestic\t500\t599\ndomestic\t2000\n";
    let _card = with_rate_card(card);

    let err = quote(&parcel("domestic", 100)).unwrap_err();
    match err {
        QuoteError::MalformedRateCard { line } => assert_eq!(line, 2),
        other => panic!("expected MalformedRateCard, got {other:?}"),
    }
}

#[test]
fn quote_reports_malformed_line_with_unparseable_number() {
    let _guard = ENV_LOCK.lock().unwrap();
    let card = "# header\n\ndomestic\tfive-hundred\t599\n";
    let _card = with_rate_card(card);

    let err = quote(&parcel("domestic", 100)).unwrap_err();
    match err {
        QuoteError::MalformedRateCard { line } => assert_eq!(line, 3),
        other => panic!("expected MalformedRateCard, got {other:?}"),
    }
}

#[test]
fn quote_error_implements_display_and_error() {
    fn assert_error<E: std::error::Error>(_e: &E) {}
    let err = QuoteError::UnknownZone("mars".to_string());
    assert_error(&err);
    assert_eq!(err.to_string(), "unknown zone: mars");
}
