mod rate_card;
pub mod zones;

use std::fmt;

use rate_card::RateCard;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

const OVERWEIGHT_SURCHARGE_THRESHOLD_GRAMS: u32 = 10000;
const OVERWEIGHT_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = std::fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let card = RateCard::parse(&contents)?;
    let band = card.lookup(&parcel.zone, parcel.weight_grams)?;

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > OVERWEIGHT_SURCHARGE_THRESHOLD_GRAMS {
        surcharge_cents += OVERWEIGHT_SURCHARGE_CENTS;
    }

    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge_cents += round_half_up_percent(base_cents, 20);
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "ratecard.quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

fn round_half_up_percent(amount_cents: u64, percent: u64) -> u64 {
    (amount_cents * percent + 50) / 100
}
