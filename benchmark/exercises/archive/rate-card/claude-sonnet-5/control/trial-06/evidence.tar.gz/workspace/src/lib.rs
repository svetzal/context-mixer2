pub mod zones;

use std::collections::HashMap;
use std::fmt;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card(path: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let contents =
        std::fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands: HashMap<String, Vec<Band>> = HashMap::new();

    for (idx, raw_line) in contents.lines().enumerate() {
        let line_number = idx + 1;
        let trimmed = raw_line.trim();

        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = raw_line.split('\t').collect();
        let [zone, band_max_grams, cents] = fields.as_slice() else {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        };

        let band_max_grams: u32 = band_max_grams
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = cents
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        bands
            .entry(zone.trim().to_string())
            .or_default()
            .push(Band { band_max_grams, cents });
    }

    for zone_bands in bands.values_mut() {
        zone_bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(bands)
}

fn round_half_up_20_percent(base_cents: u64) -> u64 {
    (base_cents * 20 + 50) / 100
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let rate_card = load_rate_card(&path)?;

    let zone_bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let matching_band = zone_bands
        .iter()
        .find(|band| band.band_max_grams >= parcel.weight_grams);

    let band = match matching_band {
        Some(band) => band,
        None => {
            let limit = zone_bands
                .iter()
                .map(|band| band.band_max_grams)
                .max()
                .unwrap_or(0);
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let band_max_grams = band.band_max_grams;

    let mut surcharge_cents = 0u64;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += round_half_up_20_percent(base_cents);
    }

    let total_cents = base_cents + surcharge_cents;

    let quote = Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    };

    eprintln!(
        "quote: zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, quote.total_cents
    );

    Ok(quote)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::{Mutex, OnceLock};

    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    struct EnvGuard {
        _lock: std::sync::MutexGuard<'static, ()>,
    }

    impl Drop for EnvGuard {
        fn drop(&mut self) {
            unsafe {
                std::env::remove_var("RATECARD_PATH");
            }
        }
    }

    fn with_rate_card(contents: &str) -> (EnvGuard, tempfile::TempDir) {
        let lock = env_lock().lock().unwrap_or_else(|e| e.into_inner());
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("rates.tsv");
        std::fs::write(&path, contents).unwrap();
        unsafe {
            std::env::set_var("RATECARD_PATH", &path);
        }
        (EnvGuard { _lock: lock }, dir)
    }

    #[test]
    fn domestic_light_parcel_hits_first_band() {
        let (_guard, _dir) = with_rate_card(SAMPLE_CARD);
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
    }

    #[test]
    fn domestic_boundary_weight_matches_band_max() {
        let (_guard, _dir) = with_rate_card(SAMPLE_CARD);
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn domestic_heavy_parcel_gets_weight_surcharge() {
        let (_guard, _dir) = with_rate_card(SAMPLE_CARD);
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn international_adds_percentage_surcharge_rounded_half_up() {
        let (_guard, _dir) = with_rate_card(SAMPLE_CARD);
        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 1499);
        // 20% of 1499 = 299.8 -> rounds to 300
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_heavy_parcel_combines_both_surcharges() {
        let (_guard, _dir) = with_rate_card(SAMPLE_CARD);
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 4999);
        // 20% of 4999 = 999.8 -> rounds to 1000, plus 500 weight surcharge
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_is_reported() {
        let (_guard, _dir) = with_rate_card(SAMPLE_CARD);
        let parcel = Parcel {
            weight_grams: 100,
            zone: "lunar".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".to_string()));
    }

    #[test]
    fn overweight_parcel_is_reported_with_limit() {
        let (_guard, _dir) = with_rate_card(SAMPLE_CARD);
        let parcel = Parcel {
            weight_grams: 25000,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 25000,
                limit: 20000
            }
        );
    }

    #[test]
    fn missing_env_var_is_unavailable() {
        let _lock = env_lock().lock().unwrap_or_else(|e| e.into_inner());
        unsafe {
            std::env::remove_var("RATECARD_PATH");
        }
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn unreadable_path_is_unavailable() {
        let _lock = env_lock().lock().unwrap_or_else(|e| e.into_inner());
        unsafe {
            std::env::set_var("RATECARD_PATH", "/no/such/path/rates.tsv");
        }
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
        unsafe {
            std::env::remove_var("RATECARD_PATH");
        }
    }

    #[test]
    fn malformed_line_reports_one_based_line_number_including_comments() {
        let card = "# header\n\ndomestic\t500\tnotanumber\n";
        let (_guard, _dir) = with_rate_card(card);
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn malformed_line_wrong_field_count() {
        let card = "domestic\t500\n";
        let (_guard, _dir) = with_rate_card(card);
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn error_display_and_error_trait() {
        let err: Box<dyn std::error::Error> = Box::new(QuoteError::UnknownZone("x".into()));
        assert_eq!(err.to_string(), "unknown zone: x");
    }
}
