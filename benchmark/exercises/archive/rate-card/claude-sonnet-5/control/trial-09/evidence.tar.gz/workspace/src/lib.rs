//! Shipping quotes priced against a zone rate card.
//!
//! [`quote`] is the sole effect boundary: it reads `RATECARD_PATH`, reads and
//! parses that file, and prices the parcel. Parsing ([`rate_card`]) and
//! pricing ([`quote_calc`]) are pure functions of their inputs and are tested
//! independently of any environment or filesystem state.

mod quote_calc;
mod rate_card;
pub mod zones;

use std::fmt;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "rate card is malformed at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => write!(
                f,
                "parcel weighs {grams}g, which exceeds the {limit}g limit for its zone"
            ),
        }
    }
}

impl std::error::Error for QuoteError {}

/// Prices `parcel` against the rate card named by the `RATECARD_PATH`
/// environment variable.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let text = read_rate_card()?;
    let bands = rate_card::parse(&text)?;
    let result = quote_calc::calculate(&bands, parcel);

    if let Ok(quote) = &result {
        tracing::info!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            total_cents = quote.total_cents,
            "quote calculated"
        );
    }

    result
}

fn read_rate_card() -> Result<String, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    std::fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn display_messages_name_the_offending_condition() {
        assert_eq!(
            QuoteError::MalformedRateCard { line: 4 }.to_string(),
            "rate card is malformed at line 4"
        );
        assert_eq!(
            QuoteError::UnknownZone("moon".to_string()).to_string(),
            "unknown zone: moon"
        );
        assert_eq!(
            QuoteError::Overweight {
                grams: 25000,
                limit: 20000
            }
            .to_string(),
            "parcel weighs 25000g, which exceeds the 20000g limit for its zone"
        );
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "rate card is unavailable"
        );
    }

    #[test]
    fn quote_error_is_a_std_error() {
        let error: Box<dyn std::error::Error> = Box::new(QuoteError::RateCardUnavailable);
        assert_eq!(error.to_string(), "rate card is unavailable");
    }
}
