//! Parsing for the tab-separated rate card format. Pure text in, structured
//! bands or a `MalformedRateCard` error out — no I/O here.

use crate::QuoteError;

#[derive(Debug, Clone)]
pub(crate) struct Band {
    pub zone: String,
    pub band_max_grams: u32,
    pub cents: u64,
}

pub(crate) fn parse(text: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();

    for (index, raw_line) in text.lines().enumerate() {
        let line_number = index + 1;

        if raw_line.is_empty() || raw_line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = raw_line.split('\t').collect();
        let [zone, band_max_grams, cents] = fields.as_slice() else {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        };

        let band_max_grams: u32 = band_max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = cents
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        bands.push(Band {
            zone: (*zone).to_string(),
            band_max_grams,
            cents,
        });
    }

    Ok(bands)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ignores_comments_and_blank_lines() {
        let bands = parse("# zone\tband_max_grams\tcents\n\ndomestic\t500\t599\n").unwrap();

        assert_eq!(bands.len(), 1);
        assert_eq!(bands[0].zone, "domestic");
        assert_eq!(bands[0].band_max_grams, 500);
        assert_eq!(bands[0].cents, 599);
    }

    #[test]
    fn parses_every_band_in_the_file() {
        let bands = parse("domestic\t500\t599\ninternational\t500\t1499\n").unwrap();

        assert_eq!(bands.len(), 2);
        assert_eq!(bands[1].zone, "international");
        assert_eq!(bands[1].cents, 1499);
    }

    #[test]
    fn reports_the_line_number_of_a_line_missing_a_field() {
        let error = parse("domestic\t500\n").unwrap_err();

        assert!(matches!(error, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn reports_the_line_number_of_an_unparsable_number_counting_comments_and_blanks() {
        let text = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\n\ndomestic\tnotanumber\t899\n";

        let error = parse(text).unwrap_err();

        assert!(matches!(error, QuoteError::MalformedRateCard { line: 4 }));
    }
}
