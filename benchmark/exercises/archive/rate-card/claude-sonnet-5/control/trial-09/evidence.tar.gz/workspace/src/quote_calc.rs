//! Pricing a parcel against already-parsed rate card bands. Pure computation —
//! no I/O, no environment.

use crate::rate_card::Band;
use crate::{Parcel, Quote, QuoteError};

const HEAVY_PARCEL_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_PARCEL_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";

pub(crate) fn calculate(bands: &[Band], parcel: &Parcel) -> Result<Quote, QuoteError> {
    let zone_bands: Vec<&Band> = bands.iter().filter(|band| band.zone == parcel.zone).collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let band = match zone_bands
        .iter()
        .find(|band| band.band_max_grams >= parcel.weight_grams)
    {
        Some(band) => *band,
        None => {
            let limit = zone_bands
                .iter()
                .map(|band| band.band_max_grams)
                .max()
                .expect("zone_bands is non-empty");
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > HEAVY_PARCEL_THRESHOLD_GRAMS {
        surcharge_cents += HEAVY_PARCEL_SURCHARGE_CENTS;
    }

    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge_cents += round_half_up_20_percent(base_cents);
    }

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.band_max_grams,
    })
}

/// 20% of `cents`, rounded half-up to the cent.
fn round_half_up_20_percent(cents: u64) -> u64 {
    (cents * 2 + 5) / 10
}

#[cfg(test)]
mod tests {
    use super::*;

    fn band(zone: &str, band_max_grams: u32, cents: u64) -> Band {
        Band {
            zone: zone.to_string(),
            band_max_grams,
            cents,
        }
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    /// Take the error without requiring `Quote` to implement `Debug`.
    fn error_from(outcome: Result<Quote, QuoteError>) -> QuoteError {
        match outcome {
            Ok(_) => panic!("expected an error"),
            Err(error) => error,
        }
    }

    fn domestic_and_international_bands() -> Vec<Band> {
        vec![
            band("domestic", 500, 599),
            band("domestic", 2000, 899),
            band("domestic", 20000, 1799),
            band("international", 500, 1499),
            band("international", 20000, 4999),
        ]
    }

    #[test]
    fn picks_the_first_band_whose_ceiling_covers_the_weight() {
        let bands = domestic_and_international_bands();

        let result = calculate(&bands, &parcel(1500, "domestic")).unwrap();

        assert_eq!(result.band_max_grams, 2000);
        assert_eq!(result.base_cents, 899);
        assert_eq!(result.surcharge_cents, 0);
        assert_eq!(result.total_cents, 899);
    }

    #[test]
    fn a_band_ceiling_is_inclusive() {
        let bands = domestic_and_international_bands();

        let result = calculate(&bands, &parcel(500, "domestic")).unwrap();

        assert_eq!(result.band_max_grams, 500);
        assert_eq!(result.base_cents, 599);
    }

    #[test]
    fn the_heavy_parcel_surcharge_applies_strictly_above_the_threshold() {
        let bands = domestic_and_international_bands();

        let at_threshold = calculate(&bands, &parcel(10000, "domestic")).unwrap();
        assert_eq!(at_threshold.surcharge_cents, 0);

        let above_threshold = calculate(&bands, &parcel(15000, "domestic")).unwrap();
        assert_eq!(above_threshold.surcharge_cents, 500);
        assert_eq!(above_threshold.total_cents, 2299);
    }

    #[test]
    fn the_international_surcharge_is_twenty_percent_rounded_half_up() {
        let bands = domestic_and_international_bands();

        // 20% of 1499 is 299.8, which rounds to 300 only under half-up rounding.
        let result = calculate(&bands, &parcel(400, "international")).unwrap();

        assert_eq!(result.surcharge_cents, 300);
        assert_eq!(result.total_cents, 1799);
    }

    #[test]
    fn surcharges_accumulate() {
        let bands = domestic_and_international_bands();

        // 20% of 4999 is 999.8, rounding to 1000, plus 500 for the weight.
        let result = calculate(&bands, &parcel(15000, "international")).unwrap();

        assert_eq!(result.surcharge_cents, 1500);
        assert_eq!(result.total_cents, 6499);
    }

    #[test]
    fn an_unlisted_zone_names_itself() {
        let bands = domestic_and_international_bands();

        let error = error_from(calculate(&bands, &parcel(400, "moon")));

        match error {
            QuoteError::UnknownZone(zone) => assert_eq!(zone, "moon"),
            other => panic!("expected UnknownZone, got {other:?}"),
        }
    }

    #[test]
    fn a_weight_beyond_every_band_reports_the_zones_largest_limit() {
        let bands = domestic_and_international_bands();

        let error = error_from(calculate(&bands, &parcel(25000, "domestic")));

        match error {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 25000);
                assert_eq!(limit, 20000);
            }
            other => panic!("expected Overweight, got {other:?}"),
        }
    }
}
