//! End-to-end coverage of the `quote` effect boundary: reading `RATECARD_PATH`
//! and the file it names. Pricing rules themselves are covered by the crate's
//! internal unit tests against pure functions; this file only exercises the
//! I/O wiring.
//!
//! `RATECARD_PATH` is process-global, so every test that touches it takes
//! `ENV_LOCK` for the duration of its interaction with the environment.

use std::sync::Mutex;

use ratecard::{quote, Parcel, QuoteError};

static ENV_LOCK: Mutex<()> = Mutex::new(());

const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
international\t500\t1499\n";

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_string(),
    }
}

/// Take the error without requiring `Quote` to implement `Debug`.
fn error_from(outcome: Result<ratecard::Quote, QuoteError>) -> QuoteError {
    match outcome {
        Ok(_) => panic!("expected an error"),
        Err(error) => error,
    }
}

fn with_rate_card(contents: &str, run: impl FnOnce()) {
    let _guard = ENV_LOCK.lock().unwrap();
    let file = tempfile::NamedTempFile::new().expect("create a scratch rate card");
    std::fs::write(file.path(), contents).expect("write the rate card");
    // SAFETY: ENV_LOCK serializes every test in this binary that reads or
    // writes RATECARD_PATH, so no other thread observes it mid-mutation.
    unsafe { std::env::set_var("RATECARD_PATH", file.path()) };

    run();

    unsafe { std::env::remove_var("RATECARD_PATH") };
}

#[test]
fn quotes_a_parcel_from_a_real_file_on_disk() {
    with_rate_card(CARD, || {
        let result = quote(&parcel(400, "domestic")).expect("a quote");

        assert_eq!(result.band_max_grams, 500);
        assert_eq!(result.base_cents, 599);
        assert_eq!(result.total_cents, 599);
    });
}

#[test]
fn an_unset_env_var_is_unavailable_rather_than_a_panic() {
    let _guard = ENV_LOCK.lock().unwrap();
    // SAFETY: ENV_LOCK held for the duration of this test's interaction
    // with RATECARD_PATH.
    unsafe { std::env::remove_var("RATECARD_PATH") };

    let error = error_from(quote(&parcel(400, "domestic")));

    assert!(matches!(error, QuoteError::RateCardUnavailable));
}

#[test]
fn a_path_naming_no_file_is_unavailable_rather_than_a_panic() {
    let _guard = ENV_LOCK.lock().unwrap();
    // SAFETY: ENV_LOCK held for the duration of this test's interaction
    // with RATECARD_PATH.
    unsafe { std::env::set_var("RATECARD_PATH", "/nonexistent/does-not-exist.tsv") };

    let error = error_from(quote(&parcel(400, "domestic")));

    assert!(matches!(error, QuoteError::RateCardUnavailable));

    unsafe { std::env::remove_var("RATECARD_PATH") };
}

#[test]
fn errors_are_displayable_and_std_errors() {
    with_rate_card(CARD, || {
        let error = error_from(quote(&parcel(400, "moon")));

        assert_eq!(error.to_string(), "unknown zone: moon");
        let _: &dyn std::error::Error = &error;
    });
}
