pub mod zones;

mod rate_card;

use std::env;
use std::fmt;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weighs {grams}g, over the {limit}g limit")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

const OVERWEIGHT_SURCHARGE_THRESHOLD_GRAMS: u32 = 10_000;
const OVERWEIGHT_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let zones = rate_card::load(&path)?;

    let bands = zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let limit = bands
        .last()
        .map(|band| band.band_max_grams)
        .unwrap_or(0);

    let band = bands
        .iter()
        .find(|band| band.band_max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let base_cents = band.cents;
    let band_max_grams = band.band_max_grams;

    let mut surcharge_cents = 0u64;
    if parcel.weight_grams > OVERWEIGHT_SURCHARGE_THRESHOLD_GRAMS {
        surcharge_cents += OVERWEIGHT_SURCHARGE_CENTS;
    }
    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    log::info!(
        "quote: zone={} weight_grams={} total_cents={}",
        parcel.zone,
        parcel.weight_grams,
        total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    // RATECARD_PATH is process-global; serialize tests that touch it.
    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn card_with(contents: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().expect("create temp rate card");
        file.write_all(contents.as_bytes()).expect("write rate card");
        file
    }

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\ninternational\t500\t1499\ninternational\t20000\t4999\n";

    fn with_card<T>(contents: &str, f: impl FnOnce() -> T) -> T {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let file = card_with(contents);
        env::set_var("RATECARD_PATH", file.path());
        let result = f();
        env::remove_var("RATECARD_PATH");
        result
    }

    #[test]
    fn picks_the_first_band_at_or_above_the_weight() {
        with_card(SAMPLE, || {
            let parcel = Parcel {
                weight_grams: 500,
                zone: "domestic".to_string(),
            };
            let q = quote(&parcel).expect("quote");
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
        });
    }

    #[test]
    fn picks_the_next_band_when_over_the_smaller_one() {
        with_card(SAMPLE, || {
            let parcel = Parcel {
                weight_grams: 501,
                zone: "domestic".to_string(),
            };
            let q = quote(&parcel).expect("quote");
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
        });
    }

    #[test]
    fn overweight_surcharge_applies_strictly_above_10000() {
        with_card(SAMPLE, || {
            let parcel = Parcel {
                weight_grams: 10000,
                zone: "domestic".to_string(),
            };
            let q = quote(&parcel).expect("quote");
            assert_eq!(q.surcharge_cents, 0);

            let parcel = Parcel {
                weight_grams: 10001,
                zone: "domestic".to_string(),
            };
            let q = quote(&parcel).expect("quote");
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, q.base_cents + 500);
        });
    }

    #[test]
    fn international_surcharge_is_20_percent_rounded_half_up() {
        with_card(SAMPLE, || {
            let parcel = Parcel {
                weight_grams: 500,
                zone: "international".to_string(),
            };
            let q = quote(&parcel).expect("quote");
            // 1499 * 0.20 = 299.8 -> rounds to 300
            assert_eq!(q.base_cents, 1499);
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_and_overweight_surcharges_combine() {
        with_card(SAMPLE, || {
            let parcel = Parcel {
                weight_grams: 20000,
                zone: "international".to_string(),
            };
            let q = quote(&parcel).expect("quote");
            assert_eq!(q.base_cents, 4999);
            // 4999 * 0.20 = 999.8 -> 1000, plus 500 overweight surcharge
            assert_eq!(q.surcharge_cents, 1000 + 500);
            assert_eq!(q.total_cents, 4999 + 1000 + 500);
        });
    }

    #[test]
    fn unknown_zone_is_reported() {
        with_card(SAMPLE, || {
            let parcel = Parcel {
                weight_grams: 100,
                zone: "lunar".to_string(),
            };
            match quote(&parcel) {
                Err(QuoteError::UnknownZone(zone)) => assert_eq!(zone, "lunar"),
                other => panic!("expected UnknownZone, got {other:?}"),
            }
        });
    }

    #[test]
    fn overweight_beyond_the_largest_band_is_reported() {
        with_card(SAMPLE, || {
            let parcel = Parcel {
                weight_grams: 20001,
                zone: "domestic".to_string(),
            };
            match quote(&parcel) {
                Err(QuoteError::Overweight { grams, limit }) => {
                    assert_eq!(grams, 20001);
                    assert_eq!(limit, 20000);
                }
                other => panic!("expected Overweight, got {other:?}"),
            }
        });
    }

    #[test]
    fn missing_ratecard_path_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        match quote(&parcel) {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected RateCardUnavailable, got {other:?}"),
        }
    }

    #[test]
    fn unreadable_ratecard_path_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        env::set_var("RATECARD_PATH", "/nonexistent/path/does/not/exist.tsv");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);
        env::remove_var("RATECARD_PATH");
        match result {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected RateCardUnavailable, got {other:?}"),
        }
    }

    #[test]
    fn malformed_line_reports_its_1_based_line_number() {
        let contents = "# header\ndomestic\t500\t599\ndomestic\tnot-a-number\t899\n";
        with_card(contents, || {
            let parcel = Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            };
            match quote(&parcel) {
                Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
                other => panic!("expected MalformedRateCard, got {other:?}"),
            }
        });
    }

    #[test]
    fn malformed_line_with_wrong_field_count_reports_its_line_number() {
        let contents = "domestic\t500\t599\ndomestic\t2000\n";
        with_card(contents, || {
            let parcel = Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            };
            match quote(&parcel) {
                Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 2),
                other => panic!("expected MalformedRateCard, got {other:?}"),
            }
        });
    }

    #[test]
    fn blank_and_comment_lines_are_ignored_but_still_counted() {
        let contents = "\n# comment\ndomestic\t500\t599\n\ndomestic\t2000\t899\n";
        with_card(contents, || {
            let parcel = Parcel {
                weight_grams: 1000,
                zone: "domestic".to_string(),
            };
            let q = quote(&parcel).expect("quote");
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
        });
    }

    #[test]
    fn error_display_and_error_trait() {
        let err = QuoteError::UnknownZone("mars".to_string());
        assert_eq!(err.to_string(), "unknown zone: mars");
        let _: &dyn std::error::Error = &err;
    }
}
