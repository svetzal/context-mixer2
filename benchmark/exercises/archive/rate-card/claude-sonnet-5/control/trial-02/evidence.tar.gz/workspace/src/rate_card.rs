use std::collections::HashMap;
use std::fs;

use crate::QuoteError;

pub(crate) struct Band {
    pub(crate) band_max_grams: u32,
    pub(crate) cents: u64,
}

pub(crate) fn load(path: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

    for (idx, line) in contents.lines().enumerate() {
        let line_number = idx + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        let [zone, band_max_grams, cents] = fields.as_slice() else {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        };

        let band_max_grams: u32 = band_max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = cents
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        zones
            .entry((*zone).to_string())
            .or_default()
            .push(Band { band_max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(zones)
}
