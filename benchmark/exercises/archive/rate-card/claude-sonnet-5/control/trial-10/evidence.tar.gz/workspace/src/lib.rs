pub mod zones;

use std::collections::HashMap;
use std::env;
use std::fmt;
use std::fs;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut card: HashMap<String, Vec<Band>> = HashMap::new();

    for (idx, line) in contents.lines().enumerate() {
        let line_number = idx + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = fields[0].trim().to_string();
        let band_max_grams: u32 = fields[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        card.entry(zone)
            .or_default()
            .push(Band { band_max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|b| b.band_max_grams);
    }

    Ok(card)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = load_rate_card()?;

    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: bands.last().map(|b| b.band_max_grams).unwrap_or(0),
        })?;

    let base_cents = band.cents;
    let band_max_grams = band.band_max_grams;

    let mut surcharge_cents = 0u64;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up to the cent.
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    log::info!(
        "quote computed: zone={} weight_grams={} total_cents={}",
        parcel.zone,
        parcel.weight_grams,
        total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn with_rate_card(contents: &str, f: impl FnOnce()) {
        let _guard = ENV_LOCK.lock().unwrap();
        let mut file = tempfile::NamedTempFile::new().unwrap();
        file.write_all(contents.as_bytes()).unwrap();
        env::set_var("RATECARD_PATH", file.path());
        f();
        env::remove_var("RATECARD_PATH");
    }

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\ninternational\t500\t1499\ninternational\t20000\t4999\n";

    #[test]
    fn picks_the_first_band_at_or_above_the_weight() {
        with_rate_card(SAMPLE, || {
            let parcel = Parcel {
                weight_grams: 450,
                zone: "domestic".to_string(),
            };
            let q = quote(&parcel).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
        });
    }

    #[test]
    fn weight_exactly_on_a_band_boundary_matches_that_band() {
        with_rate_card(SAMPLE, || {
            let parcel = Parcel {
                weight_grams: 500,
                zone: "domestic".to_string(),
            };
            let q = quote(&parcel).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn heavy_domestic_parcel_gets_the_weight_surcharge() {
        with_rate_card(SAMPLE, || {
            let parcel = Parcel {
                weight_grams: 15000,
                zone: "domestic".to_string(),
            };
            let q = quote(&parcel).unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
        });
    }

    #[test]
    fn international_parcel_gets_a_twenty_percent_surcharge() {
        with_rate_card(SAMPLE, || {
            let parcel = Parcel {
                weight_grams: 100,
                zone: "international".to_string(),
            };
            let q = quote(&parcel).unwrap();
            assert_eq!(q.base_cents, 1499);
            // 1499 * 0.2 = 299.8 -> rounds half-up to 300
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn heavy_international_parcel_stacks_both_surcharges() {
        with_rate_card(SAMPLE, || {
            let parcel = Parcel {
                weight_grams: 15000,
                zone: "international".to_string(),
            };
            let q = quote(&parcel).unwrap();
            assert_eq!(q.base_cents, 4999);
            // 4999 * 0.2 = 999.8 -> 1000, plus 500 weight surcharge
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
        });
    }

    #[test]
    fn unknown_zone_is_reported() {
        with_rate_card(SAMPLE, || {
            let parcel = Parcel {
                weight_grams: 100,
                zone: "lunar".to_string(),
            };
            let err = quote(&parcel).unwrap_err();
            assert_eq!(err, QuoteError::UnknownZone("lunar".to_string()));
        });
    }

    #[test]
    fn overweight_parcel_is_reported_with_the_zone_limit() {
        with_rate_card(SAMPLE, || {
            let parcel = Parcel {
                weight_grams: 25000,
                zone: "domestic".to_string(),
            };
            let err = quote(&parcel).unwrap_err();
            assert_eq!(
                err,
                QuoteError::Overweight {
                    grams: 25000,
                    limit: 20000
                }
            );
        });
    }

    #[test]
    fn missing_env_var_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap();
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn unreadable_path_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap();
        env::set_var("RATECARD_PATH", "/no/such/path/for/ratecard/tests");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
        env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn malformed_line_reports_its_one_based_number() {
        let contents = "# header\ndomestic\t500\t599\nbroken-line\ninternational\t500\t1499\n";
        with_rate_card(contents, || {
            let parcel = Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            };
            let err = quote(&parcel).unwrap_err();
            assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
        });
    }

    #[test]
    fn malformed_number_reports_its_line() {
        let contents = "domestic\tnot-a-number\t599\n";
        with_rate_card(contents, || {
            let parcel = Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            };
            let err = quote(&parcel).unwrap_err();
            assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
        });
    }

    #[test]
    fn blank_and_comment_lines_still_count_towards_line_numbers() {
        let contents = "\n# comment\n\ndomestic\t500\n";
        with_rate_card(contents, || {
            let parcel = Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            };
            let err = quote(&parcel).unwrap_err();
            assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
        });
    }

    #[test]
    fn display_messages_are_human_readable() {
        assert_eq!(
            QuoteError::UnknownZone("mars".to_string()).to_string(),
            "unknown zone: mars"
        );
        assert_eq!(
            QuoteError::Overweight {
                grams: 100,
                limit: 50
            }
            .to_string(),
            "parcel weight 100g exceeds zone limit of 50g"
        );
        assert_eq!(
            QuoteError::MalformedRateCard { line: 7 }.to_string(),
            "malformed rate card at line 7"
        );
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "rate card unavailable"
        );
    }

    // A minimal `log::Log` implementation so this test can assert that
    // `quote` actually emits a diagnostic record, without pulling in a
    // full logging backend as a dependency.
    struct CapturingLogger {
        records: Mutex<Vec<String>>,
    }

    impl log::Log for CapturingLogger {
        fn enabled(&self, _metadata: &log::Metadata) -> bool {
            true
        }

        fn log(&self, record: &log::Record) {
            self.records
                .lock()
                .unwrap()
                .push(format!("{}", record.args()));
        }

        fn flush(&self) {}
    }

    static LOGGER: CapturingLogger = CapturingLogger {
        records: Mutex::new(Vec::new()),
    };
    static LOGGER_INIT: AtomicUsize = AtomicUsize::new(0);

    fn install_logger() {
        if LOGGER_INIT.swap(1, Ordering::SeqCst) == 0 {
            log::set_logger(&LOGGER).unwrap();
            log::set_max_level(log::LevelFilter::Info);
        }
    }

    #[test]
    fn quote_emits_a_diagnostic_record() {
        install_logger();

        // Hold the env lock for the whole clear-call-assert sequence so a
        // concurrently running test can't sneak a log record in between.
        let _guard = ENV_LOCK.lock().unwrap();
        LOGGER.records.lock().unwrap().clear();

        let mut file = tempfile::NamedTempFile::new().unwrap();
        file.write_all(SAMPLE.as_bytes()).unwrap();
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        quote(&parcel).unwrap();

        env::remove_var("RATECARD_PATH");

        let records = LOGGER.records.lock().unwrap();
        assert_eq!(records.len(), 1);
        let record = &records[0];
        assert!(record.contains("domestic"));
        assert!(record.contains("100"));
        assert!(record.contains("599"));
    }
}
