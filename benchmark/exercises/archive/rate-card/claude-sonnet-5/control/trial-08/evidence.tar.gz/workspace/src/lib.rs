mod error;
mod rate_card;

pub use error::QuoteError;

const OVERWEIGHT_SURCHARGE_CENTS: u64 = 500;
const OVERWEIGHT_THRESHOLD_GRAMS: u32 = 10_000;
const INTERNATIONAL_ZONE: &str = "international";
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = rate_card::load()?;

    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|band| band.band_max_grams >= parcel.weight_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: bands.iter().map(|band| band.band_max_grams).max().unwrap_or(0),
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > OVERWEIGHT_THRESHOLD_GRAMS {
        surcharge_cents += OVERWEIGHT_SURCHARGE_CENTS;
    }
    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge_cents += round_half_up_percent(base_cents, INTERNATIONAL_SURCHARGE_PERCENT);
    }

    let total_cents = base_cents + surcharge_cents;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

fn round_half_up_percent(cents: u64, percent: u64) -> u64 {
    (cents * percent + 50) / 100
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn with_card(contents: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().expect("create temp rate card");
        write!(file, "{contents}").expect("write temp rate card");
        file
    }

    fn lock() -> std::sync::MutexGuard<'static, ()> {
        ENV_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner())
    }

    #[test]
    fn light_domestic_parcel_uses_first_matching_band() {
        let _guard = lock();
        let file = with_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 300, zone: "domestic".to_string() };
        let result = quote(&parcel).unwrap();

        assert_eq!(result.base_cents, 599);
        assert_eq!(result.surcharge_cents, 0);
        assert_eq!(result.total_cents, 599);
        assert_eq!(result.band_max_grams, 500);
    }

    #[test]
    fn weight_exactly_at_band_boundary_matches_that_band() {
        let _guard = lock();
        let file = with_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 500, zone: "domestic".to_string() };
        let result = quote(&parcel).unwrap();

        assert_eq!(result.band_max_grams, 500);
        assert_eq!(result.base_cents, 599);
    }

    #[test]
    fn weight_just_above_boundary_rolls_to_next_band() {
        let _guard = lock();
        let file = with_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 501, zone: "domestic".to_string() };
        let result = quote(&parcel).unwrap();

        assert_eq!(result.band_max_grams, 2000);
        assert_eq!(result.base_cents, 899);
    }

    #[test]
    fn heavy_parcel_adds_overweight_surcharge() {
        let _guard = lock();
        let file = with_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 15000, zone: "domestic".to_string() };
        let result = quote(&parcel).unwrap();

        assert_eq!(result.base_cents, 1799);
        assert_eq!(result.surcharge_cents, 500);
        assert_eq!(result.total_cents, 2299);
    }

    #[test]
    fn weight_at_exactly_ten_thousand_grams_has_no_surcharge() {
        let _guard = lock();
        let file = with_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 10_000, zone: "domestic".to_string() };
        let result = quote(&parcel).unwrap();

        assert_eq!(result.surcharge_cents, 0);
    }

    #[test]
    fn international_zone_adds_twenty_percent_rounded_half_up() {
        let _guard = lock();
        let file = with_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", file.path());

        // base_cents = 1499, 20% = 299.8 -> rounds up to 300
        let parcel = Parcel { weight_grams: 500, zone: "international".to_string() };
        let result = quote(&parcel).unwrap();

        assert_eq!(result.base_cents, 1499);
        assert_eq!(result.surcharge_cents, 300);
        assert_eq!(result.total_cents, 1799);
    }

    #[test]
    fn international_and_overweight_surcharges_combine() {
        let _guard = lock();
        let file = with_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", file.path());

        // base_cents = 4999, 20% = 999.8 -> rounds to 1000, plus 500 overweight
        let parcel = Parcel { weight_grams: 15000, zone: "international".to_string() };
        let result = quote(&parcel).unwrap();

        assert_eq!(result.base_cents, 4999);
        assert_eq!(result.surcharge_cents, 1500);
        assert_eq!(result.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_is_reported() {
        let _guard = lock();
        let file = with_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 100, zone: "lunar".to_string() };
        let err = quote(&parcel).unwrap_err();

        match err {
            QuoteError::UnknownZone(zone) => assert_eq!(zone, "lunar"),
            other => panic!("expected UnknownZone, got {other:?}"),
        }
    }

    #[test]
    fn overweight_parcel_is_reported_with_limit() {
        let _guard = lock();
        let file = with_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 20_001, zone: "domestic".to_string() };
        let err = quote(&parcel).unwrap_err();

        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 20_001);
                assert_eq!(limit, 20_000);
            }
            other => panic!("expected Overweight, got {other:?}"),
        }
    }

    #[test]
    fn missing_env_var_is_unavailable() {
        let _guard = lock();
        std::env::remove_var("RATECARD_PATH");

        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let err = quote(&parcel).unwrap_err();

        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn unreadable_path_is_unavailable() {
        let _guard = lock();
        std::env::set_var("RATECARD_PATH", "/nonexistent/path/does-not-exist.tsv");

        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let err = quote(&parcel).unwrap_err();

        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn malformed_line_wrong_field_count_reports_line_number() {
        let _guard = lock();
        let file = with_card("# header\ndomestic\t500\n");
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let err = quote(&parcel).unwrap_err();

        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn malformed_line_bad_number_reports_line_number() {
        let _guard = lock();
        let file = with_card("# header\ndomestic\tabc\t599\n");
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let err = quote(&parcel).unwrap_err();

        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn comments_and_blank_lines_count_toward_line_numbers() {
        let _guard = lock();
        let file = with_card("# header\n\ndomestic\t500\t599\nbad line here\n");
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let err = quote(&parcel).unwrap_err();

        assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn error_messages_are_displayable() {
        assert_eq!(
            QuoteError::UnknownZone("mars".to_string()).to_string(),
            "unknown zone: mars"
        );
        assert_eq!(
            QuoteError::Overweight { grams: 100, limit: 50 }.to_string(),
            "parcel weighs 100g, which exceeds the 50g limit"
        );
        assert_eq!(
            QuoteError::MalformedRateCard { line: 3 }.to_string(),
            "rate card is malformed at line 3"
        );
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "rate card is unavailable"
        );
    }

    #[test]
    fn quote_error_implements_std_error() {
        fn assert_error<E: std::error::Error>(_: &E) {}
        assert_error(&QuoteError::RateCardUnavailable);
    }
}
