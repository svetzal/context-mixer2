use std::collections::HashMap;
use std::env;
use std::fs;

use crate::error::QuoteError;

pub struct Band {
    pub band_max_grams: u32,
    pub cents: u64,
}

pub type RateCard = HashMap<String, Vec<Band>>;

pub fn load() -> Result<RateCard, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse(&contents)
}

fn parse(contents: &str) -> Result<RateCard, QuoteError> {
    let mut card: RateCard = HashMap::new();

    for (idx, line) in contents.lines().enumerate() {
        let line_number = idx + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = fields[0].to_string();
        let band_max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        card.entry(zone)
            .or_default()
            .push(Band { band_max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(card)
}
