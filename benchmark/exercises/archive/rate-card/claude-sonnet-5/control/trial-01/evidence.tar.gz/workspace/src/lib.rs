pub mod zones;

use std::collections::HashMap;
use std::env;
use std::fmt;
use std::fs;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    band_max_grams: u32,
    cents: u64,
}

type RateCard = HashMap<String, Vec<Band>>;

fn parse_rate_card(content: &str) -> Result<RateCard, QuoteError> {
    let mut rate_card: RateCard = HashMap::new();

    for (index, raw_line) in content.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = raw_line.trim();

        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = trimmed.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = fields[0].trim().to_string();
        let band_max_grams: u32 = fields[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        rate_card.entry(zone).or_default().push(Band {
            band_max_grams,
            cents,
        });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(rate_card)
}

fn round_half_up_percent(cents: u64, percent: u64) -> u64 {
    (cents * percent + 50) / 100
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let rate_card = parse_rate_card(&content)?;

    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let limit = bands
        .last()
        .map(|band| band.band_max_grams)
        .unwrap_or(0);

    if parcel.weight_grams > limit {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        });
    }

    let band = bands
        .iter()
        .find(|band| band.band_max_grams >= parcel.weight_grams)
        .expect("weight within limit must match a band");

    let base_cents = band.cents;
    let band_max_grams = band.band_max_grams;

    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += round_half_up_percent(base_cents, 20);
    }

    let total_cents = base_cents + surcharge_cents;

    log::info!(
        "quote: zone={} weight_grams={} total_cents={}",
        parcel.zone,
        parcel.weight_grams,
        total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn with_rate_card(contents: &str, test: impl FnOnce()) {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let mut file = tempfile::NamedTempFile::new().expect("create temp rate card");
        file.write_all(contents.as_bytes())
            .expect("write rate card");
        env::set_var("RATECARD_PATH", file.path());
        test();
        env::remove_var("RATECARD_PATH");
    }

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    #[test]
    fn picks_first_band_at_or_above_weight() {
        with_rate_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 400,
                zone: "domestic".to_string(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
        });
    }

    #[test]
    fn picks_exact_boundary_band() {
        with_rate_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 500,
                zone: "domestic".to_string(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn heavy_domestic_parcel_gets_weight_surcharge() {
        with_rate_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 15000,
                zone: "domestic".to_string(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
        });
    }

    #[test]
    fn exactly_ten_thousand_grams_has_no_weight_surcharge() {
        with_rate_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 10_000,
                zone: "domestic".to_string(),
            })
            .unwrap();
            assert_eq!(q.surcharge_cents, 0);
        });
    }

    #[test]
    fn international_parcel_gets_percentage_surcharge_rounded_half_up() {
        with_rate_card(SAMPLE, || {
            // base_cents = 1499 -> 20% = 299.8 -> rounds up to 300
            let q = quote(&Parcel {
                weight_grams: 500,
                zone: "international".to_string(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 1499);
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn heavy_international_parcel_gets_both_surcharges() {
        with_rate_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 15000,
                zone: "international".to_string(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 4999);
            // 20% of 4999 = 999.8 -> rounds to 1000, plus 500 weight surcharge
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
        });
    }

    #[test]
    fn unknown_zone_is_reported() {
        with_rate_card(SAMPLE, || {
            let err = quote(&Parcel {
                weight_grams: 100,
                zone: "lunar".to_string(),
            })
            .unwrap_err();
            assert_eq!(err, QuoteError::UnknownZone("lunar".to_string()));
        });
    }

    #[test]
    fn overweight_parcel_is_reported_with_zone_limit() {
        with_rate_card(SAMPLE, || {
            let err = quote(&Parcel {
                weight_grams: 25000,
                zone: "domestic".to_string(),
            })
            .unwrap_err();
            assert_eq!(
                err,
                QuoteError::Overweight {
                    grams: 25000,
                    limit: 20000
                }
            );
        });
    }

    #[test]
    fn missing_env_var_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        env::remove_var("RATECARD_PATH");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn unreadable_path_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        env::set_var("RATECARD_PATH", "/nonexistent/path/does-not-exist.tsv");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
        env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn malformed_line_reports_one_based_line_number() {
        let contents = "# header\ndomestic\t500\t599\nbroken-line-here\ninternational\t500\t1499\n";
        with_rate_card(contents, || {
            let err = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            })
            .unwrap_err();
            assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
        });
    }

    #[test]
    fn malformed_number_reports_its_line_number() {
        let contents = "domestic\t500\t599\ndomestic\tabc\t899\n";
        with_rate_card(contents, || {
            let err = quote(&Parcel {
                weight_grams: 1000,
                zone: "domestic".to_string(),
            })
            .unwrap_err();
            assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
        });
    }

    #[test]
    fn error_messages_are_displayable() {
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "rate card unavailable"
        );
        assert_eq!(
            QuoteError::MalformedRateCard { line: 4 }.to_string(),
            "malformed rate card at line 4"
        );
        assert_eq!(
            QuoteError::UnknownZone("mars".to_string()).to_string(),
            "unknown zone: mars"
        );
        assert_eq!(
            QuoteError::Overweight {
                grams: 100,
                limit: 50
            }
            .to_string(),
            "parcel weight 100g exceeds zone limit 50g"
        );
    }

    struct CapturingLogger {
        records: Mutex<Vec<String>>,
    }

    impl log::Log for CapturingLogger {
        fn enabled(&self, _metadata: &log::Metadata) -> bool {
            true
        }

        fn log(&self, record: &log::Record) {
            self.records
                .lock()
                .unwrap()
                .push(record.args().to_string());
        }

        fn flush(&self) {}
    }

    static CAPTURING_LOGGER: CapturingLogger = CapturingLogger {
        records: Mutex::new(Vec::new()),
    };

    #[test]
    fn emits_diagnostic_record_with_zone_weight_and_total() {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let _ = log::set_logger(&CAPTURING_LOGGER);
        log::set_max_level(log::LevelFilter::Info);

        let mut file = tempfile::NamedTempFile::new().expect("create temp rate card");
        file.write_all(SAMPLE.as_bytes()).expect("write rate card");
        env::set_var("RATECARD_PATH", file.path());

        quote(&Parcel {
            weight_grams: 400,
            zone: "domestic".to_string(),
        })
        .unwrap();

        env::remove_var("RATECARD_PATH");

        let records = CAPTURING_LOGGER.records.lock().unwrap();
        let last = records.last().expect("a diagnostic record was emitted");
        assert!(last.contains("domestic"));
        assert!(last.contains("400"));
        assert!(last.contains("599"));
    }
}
