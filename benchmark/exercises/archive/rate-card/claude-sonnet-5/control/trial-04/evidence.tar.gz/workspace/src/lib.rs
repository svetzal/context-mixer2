pub mod zones;

use std::collections::HashMap;
use std::env;
use std::fmt;
use std::fs;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weighs {grams}g, over the {limit}g limit")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    band_max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut card: HashMap<String, Vec<Band>> = HashMap::new();

    for (idx, raw_line) in contents.lines().enumerate() {
        let line_number = idx + 1;
        let line = raw_line.trim_end_matches('\r');

        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = fields[0].to_string();
        let band_max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        card.entry(zone).or_default().push(Band {
            band_max_grams,
            cents,
        });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(card)
}

fn round_half_up_percent(base_cents: u64, percent: u64) -> u64 {
    (base_cents * percent + 50) / 100
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = load_rate_card()?;

    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let limit = bands
        .last()
        .map(|band| band.band_max_grams)
        .unwrap_or(0);

    if parcel.weight_grams > limit {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        });
    }

    let band = bands
        .iter()
        .find(|band| band.band_max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let base_cents = band.cents;
    let band_max_grams = band.band_max_grams;

    let mut surcharge_cents = 0u64;
    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += round_half_up_percent(base_cents, 20);
    }

    let total_cents = base_cents + surcharge_cents;

    log::info!(
        "quote computed: zone={} weight_grams={} total_cents={}",
        parcel.zone,
        parcel.weight_grams,
        total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    // RATECARD_PATH is a process-wide env var; serialize tests that touch it.
    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn with_rate_card(contents: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().expect("create temp rate card");
        file.write_all(contents.as_bytes())
            .expect("write temp rate card");
        file
    }

    const SAMPLE_CARD: &str = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\ninternational\t500\t1499\ninternational\t20000\t4999\n";

    #[test]
    fn domestic_light_parcel_uses_first_band() {
        let _guard = ENV_LOCK.lock().unwrap();
        let file = with_rate_card(SAMPLE_CARD);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel).expect("quote should succeed");

        assert_eq!(result.base_cents, 599);
        assert_eq!(result.surcharge_cents, 0);
        assert_eq!(result.total_cents, 599);
        assert_eq!(result.band_max_grams, 500);
    }

    #[test]
    fn domestic_parcel_at_exact_band_boundary_matches_that_band() {
        let _guard = ENV_LOCK.lock().unwrap();
        let file = with_rate_card(SAMPLE_CARD);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel).expect("quote should succeed");

        assert_eq!(result.base_cents, 599);
        assert_eq!(result.band_max_grams, 500);
    }

    #[test]
    fn heavy_domestic_parcel_gets_overweight_surcharge() {
        let _guard = ENV_LOCK.lock().unwrap();
        let file = with_rate_card(SAMPLE_CARD);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel).expect("quote should succeed");

        assert_eq!(result.base_cents, 1799);
        assert_eq!(result.surcharge_cents, 500);
        assert_eq!(result.total_cents, 2299);
        assert_eq!(result.band_max_grams, 20000);
    }

    #[test]
    fn international_parcel_gets_percentage_surcharge_rounded_half_up() {
        let _guard = ENV_LOCK.lock().unwrap();
        let file = with_rate_card(SAMPLE_CARD);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 400,
            zone: "international".to_string(),
        };
        let result = quote(&parcel).expect("quote should succeed");

        // 20% of 1499 = 299.8 -> rounds half-up to 300
        assert_eq!(result.base_cents, 1499);
        assert_eq!(result.surcharge_cents, 300);
        assert_eq!(result.total_cents, 1799);
    }

    #[test]
    fn international_heavy_parcel_stacks_both_surcharges() {
        let _guard = ENV_LOCK.lock().unwrap();
        let file = with_rate_card(SAMPLE_CARD);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let result = quote(&parcel).expect("quote should succeed");

        assert_eq!(result.base_cents, 4999);
        // 20% of 4999 = 999.8 -> 1000, plus 500 overweight surcharge
        assert_eq!(result.surcharge_cents, 1500);
        assert_eq!(result.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_is_reported() {
        let _guard = ENV_LOCK.lock().unwrap();
        let file = with_rate_card(SAMPLE_CARD);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "lunar".to_string(),
        };
        let err = quote(&parcel).unwrap_err();

        match err {
            QuoteError::UnknownZone(zone) => assert_eq!(zone, "lunar"),
            other => panic!("expected UnknownZone, got {other:?}"),
        }
    }

    #[test]
    fn overweight_parcel_carries_zone_limit() {
        let _guard = ENV_LOCK.lock().unwrap();
        let file = with_rate_card(SAMPLE_CARD);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 25000,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();

        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 25000);
                assert_eq!(limit, 20000);
            }
            other => panic!("expected Overweight, got {other:?}"),
        }
    }

    #[test]
    fn missing_env_var_is_rate_card_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap();
        env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();

        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn unreadable_path_is_rate_card_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap();
        env::set_var("RATECARD_PATH", "/nonexistent/path/does/not/exist.tsv");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();

        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn malformed_line_reports_one_based_line_number_including_comments() {
        let _guard = ENV_LOCK.lock().unwrap();
        let contents = "# header comment\n\ndomestic\t500\t599\ndomestic\tnot-a-number\t899\n";
        let file = with_rate_card(contents);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();

        assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn malformed_line_with_wrong_field_count() {
        let _guard = ENV_LOCK.lock().unwrap();
        let contents = "domestic\t500\n";
        let file = with_rate_card(contents);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();

        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn error_display_messages_are_human_readable() {
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "rate card unavailable"
        );
        assert_eq!(
            QuoteError::MalformedRateCard { line: 3 }.to_string(),
            "malformed rate card at line 3"
        );
        assert_eq!(
            QuoteError::UnknownZone("mars".to_string()).to_string(),
            "unknown zone: mars"
        );
        assert_eq!(
            QuoteError::Overweight {
                grams: 100,
                limit: 50
            }
            .to_string(),
            "parcel weighs 100g, over the 50g limit"
        );
    }
}
