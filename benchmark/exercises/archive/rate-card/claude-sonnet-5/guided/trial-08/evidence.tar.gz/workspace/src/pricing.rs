//! Pure computation of a [`Quote`] from a parsed rate card and a parcel.
//!
//! Contains no I/O: the rate card is already parsed by the time it reaches
//! this module.

use crate::parser::RateCard;
use crate::{Parcel, Quote, QuoteError};

const OVERWEIGHT_THRESHOLD_GRAMS: u32 = 10_000;
const OVERWEIGHT_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

pub(crate) fn compute_quote(rate_card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: bands.last().map_or(0, |band| band.max_grams),
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > OVERWEIGHT_THRESHOLD_GRAMS {
        surcharge_cents += OVERWEIGHT_SURCHARGE_CENTS;
    }

    if parcel.zone == INTERNATIONAL_ZONE {
        // Round half-up to the cent: add half the divisor before truncating.
        surcharge_cents += (base_cents * INTERNATIONAL_SURCHARGE_PERCENT + 50) / 100;
    }

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
// unwrap/expect/panic are idiomatic in test assertions; the crate-level
// restriction lints target non-test library code.
#[allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]
mod tests {
    use super::*;
    use crate::parser::Band;
    use std::collections::HashMap;

    fn card(entries: &[(&str, &[(u32, u64)])]) -> RateCard {
        let mut card: RateCard = HashMap::new();
        for (zone, bands) in entries {
            card.insert(
                (*zone).to_string(),
                bands
                    .iter()
                    .map(|(max_grams, cents)| Band {
                        max_grams: *max_grams,
                        cents: *cents,
                    })
                    .collect(),
            );
        }
        card
    }

    fn parcel(zone: &str, weight_grams: u32) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn picks_first_band_at_or_above_weight() {
        let rc = card(&[("domestic", &[(500, 599), (2000, 899)])]);
        let quote = compute_quote(&rc, &parcel("domestic", 500)).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);

        let quote = compute_quote(&rc, &parcel("domestic", 501)).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn weight_above_10000_adds_flat_surcharge() {
        let rc = card(&[("domestic", &[(20000, 1799)])]);
        let quote = compute_quote(&rc, &parcel("domestic", 10001)).unwrap();
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 1799 + 500);
    }

    #[test]
    fn weight_at_exactly_10000_has_no_flat_surcharge() {
        let rc = card(&[("domestic", &[(20000, 1799)])]);
        let quote = compute_quote(&rc, &parcel("domestic", 10000)).unwrap();
        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_20_percent_rounded_half_up() {
        let rc = card(&[("international", &[(500, 1499)])]);
        let quote = compute_quote(&rc, &parcel("international", 500)).unwrap();
        // 1499 * 0.2 = 299.8 -> rounds up to 300
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1499 + 300);
    }

    #[test]
    fn international_and_overweight_surcharges_combine() {
        let rc = card(&[("international", &[(20000, 4999)])]);
        let quote = compute_quote(&rc, &parcel("international", 15000)).unwrap();
        // 4999 * 0.2 = 999.8 -> 1000, plus 500 flat
        assert_eq!(quote.surcharge_cents, 1000 + 500);
        assert_eq!(quote.total_cents, 4999 + 1000 + 500);
    }

    #[test]
    fn unknown_zone_is_reported() {
        let rc = card(&[("domestic", &[(500, 599)])]);
        let err = compute_quote(&rc, &parcel("lunar", 100)).unwrap_err();
        match err {
            QuoteError::UnknownZone(zone) => assert_eq!(zone, "lunar"),
            other => panic!("expected UnknownZone, got {other:?}"),
        }
    }

    #[test]
    fn weight_above_largest_band_is_overweight() {
        let rc = card(&[("domestic", &[(500, 599), (2000, 899)])]);
        let err = compute_quote(&rc, &parcel("domestic", 2001)).unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 2001);
                assert_eq!(limit, 2000);
            }
            other => panic!("expected Overweight, got {other:?}"),
        }
    }
}
