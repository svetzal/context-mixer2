//! Shipping quotes for the fulfilment service.
//!
//! Warehouse operators price outbound parcels against a rate card that
//! operations maintains and redeploys without a code change. This crate reads
//! that card from the path in `RATECARD_PATH` and turns a [`Parcel`] into a
//! [`Quote`].

mod parser;
mod pricing;
pub mod zones;

use std::fmt;

use tracing::{info, instrument};

/// A parcel to be quoted.
#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A calculated shipping quote.
#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Failure modes for [`quote`].
#[derive(Debug)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, or the file it names can't be read.
    RateCardUnavailable,
    /// The rate card contains an unparsable line, at the given 1-based line number.
    MalformedRateCard { line: usize },
    /// The parcel's zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "rate card is malformed at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => write!(
                f,
                "parcel weighs {grams}g, which exceeds the {limit}g limit"
            ),
        }
    }
}

impl std::error::Error for QuoteError {}

/// Calculate a shipping quote for `parcel` using the rate card at the path
/// named by the `RATECARD_PATH` environment variable.
///
/// ```
/// use std::io::Write;
///
/// let mut file = tempfile::NamedTempFile::new().unwrap();
/// writeln!(file, "domestic\t500\t599").unwrap();
/// std::env::set_var("RATECARD_PATH", file.path());
///
/// let parcel = ratecard::Parcel {
///     weight_grams: 100,
///     zone: "domestic".to_string(),
/// };
/// let quote = ratecard::quote(&parcel).unwrap();
/// assert_eq!(quote.total_cents, 599);
/// ```
///
/// # Errors
///
/// Returns [`QuoteError`] if the rate card is unavailable or malformed, the
/// parcel's zone is unknown, or the parcel is too heavy for its zone.
#[instrument(skip(parcel), fields(zone = %parcel.zone, weight_grams = parcel.weight_grams))]
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content =
        std::fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let rate_card = parser::parse_rate_card(&content)?;
    let result = pricing::compute_quote(&rate_card, parcel)?;

    info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = result.total_cents,
        "quote calculated"
    );

    Ok(result)
}
