//! Cross-module wiring: the `quote` boundary function reading a real file
//! through `RATECARD_PATH` and returning the right `QuoteError` variant for
//! each failure mode.

// unwrap/expect/panic are idiomatic in test assertions; the crate-level
// restriction lints target non-test library code.
#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

use std::io::Write;
use std::sync::Mutex;

use ratecard::{quote, Parcel, QuoteError};

/// `RATECARD_PATH` is process-global, and integration tests in this binary
/// run concurrently on separate threads. Serialize access so tests don't
/// stomp on each other's environment variable.
static ENV_LOCK: Mutex<()> = Mutex::new(());

fn parcel(zone: &str, weight_grams: u32) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_string(),
    }
}

fn write_rate_card(contents: &str) -> tempfile::NamedTempFile {
    let mut file = tempfile::NamedTempFile::new().expect("create temp rate card");
    file.write_all(contents.as_bytes())
        .expect("write temp rate card");
    file
}

const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

#[test]
fn happy_path_domestic_picks_matching_band() {
    let _guard = ENV_LOCK.lock().unwrap();
    let file = write_rate_card(SAMPLE_CARD);
    std::env::set_var("RATECARD_PATH", file.path());

    let result = quote(&parcel("domestic", 100)).unwrap();
    assert_eq!(result.base_cents, 599);
    assert_eq!(result.band_max_grams, 500);
    assert_eq!(result.surcharge_cents, 0);
    assert_eq!(result.total_cents, 599);
}

#[test]
fn international_surcharge_and_overweight_surcharge_combine() {
    let _guard = ENV_LOCK.lock().unwrap();
    let file = write_rate_card(SAMPLE_CARD);
    std::env::set_var("RATECARD_PATH", file.path());

    let result = quote(&parcel("international", 15000)).unwrap();
    assert_eq!(result.base_cents, 4999);
    // 4999 * 0.2 = 999.8 -> 1000, plus the flat 500 overweight surcharge.
    assert_eq!(result.surcharge_cents, 1500);
    assert_eq!(result.total_cents, 4999 + 1500);
    assert_eq!(result.band_max_grams, 20000);
}

#[test]
fn missing_env_var_is_rate_card_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap();
    std::env::remove_var("RATECARD_PATH");

    let err = quote(&parcel("domestic", 100)).unwrap_err();
    assert!(matches!(err, QuoteError::RateCardUnavailable));
}

#[test]
fn unreadable_path_is_rate_card_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap();
    std::env::set_var("RATECARD_PATH", "/nonexistent/path/does-not-exist.tsv");

    let err = quote(&parcel("domestic", 100)).unwrap_err();
    assert!(matches!(err, QuoteError::RateCardUnavailable));
}

#[test]
fn malformed_line_reports_one_based_line_number_including_comments_and_blanks() {
    let _guard = ENV_LOCK.lock().unwrap();
    let file = write_rate_card("# header\n\ndomestic\t500\tnot-a-number\n");
    std::env::set_var("RATECARD_PATH", file.path());

    let err = quote(&parcel("domestic", 100)).unwrap_err();
    assert!(matches!(err, QuoteError::MalformedRateCard { line: 3 }));
}

#[test]
fn unknown_zone_carries_the_requested_zone() {
    let _guard = ENV_LOCK.lock().unwrap();
    let file = write_rate_card(SAMPLE_CARD);
    std::env::set_var("RATECARD_PATH", file.path());

    let err = quote(&parcel("lunar", 100)).unwrap_err();
    match err {
        QuoteError::UnknownZone(zone) => assert_eq!(zone, "lunar"),
        other => panic!("expected UnknownZone, got {other:?}"),
    }
}

#[test]
fn weight_above_largest_band_is_overweight_with_limit() {
    let _guard = ENV_LOCK.lock().unwrap();
    let file = write_rate_card(SAMPLE_CARD);
    std::env::set_var("RATECARD_PATH", file.path());

    let err = quote(&parcel("domestic", 20001)).unwrap_err();
    match err {
        QuoteError::Overweight { grams, limit } => {
            assert_eq!(grams, 20001);
            assert_eq!(limit, 20000);
        }
        other => panic!("expected Overweight, got {other:?}"),
    }
}

#[test]
fn quote_error_implements_display_and_std_error() {
    fn assert_error<E: std::error::Error>(_: &E) {}

    let err = QuoteError::UnknownZone("lunar".to_string());
    assert_error(&err);
    assert_eq!(err.to_string(), "unknown zone: lunar");

    let err = QuoteError::Overweight {
        grams: 100,
        limit: 50,
    };
    assert_eq!(
        err.to_string(),
        "parcel weighs 100g, which exceeds the 50g limit"
    );
}
