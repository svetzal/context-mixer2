//! Pure parsing of tab-separated rate card text into an in-memory rate card.
//!
//! Contains no I/O: callers are responsible for reading the file content and
//! handing it to [`parse_rate_card`].

use std::collections::HashMap;

use crate::QuoteError;

#[derive(Debug, Clone, Copy)]
pub(crate) struct Band {
    pub(crate) max_grams: u32,
    pub(crate) cents: u64,
}

pub(crate) type RateCard = HashMap<String, Vec<Band>>;

/// Parse tab-separated rate card text into bands grouped by zone.
///
/// Bands within a zone are returned in ascending `max_grams` order,
/// regardless of the order they appear in the source text.
pub(crate) fn parse_rate_card(content: &str) -> Result<RateCard, QuoteError> {
    let mut card: RateCard = HashMap::new();

    for (index, line) in content.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = fields[0].to_string();
        let max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        card.entry(zone).or_default().push(Band { max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(card)
}

#[cfg(test)]
// unwrap/expect/panic are idiomatic in test assertions; the crate-level
// restriction lints target non-test library code.
#[allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]
mod tests {
    use super::*;

    #[test]
    fn ignores_blank_and_comment_lines() {
        let content = "# zone\tband_max_grams\tcents\n\ndomestic\t500\t599\n";
        let card = parse_rate_card(content).unwrap();
        assert_eq!(card.len(), 1);
        assert_eq!(card["domestic"].len(), 1);
    }

    #[test]
    fn sorts_bands_ascending_regardless_of_source_order() {
        let content = "domestic\t2000\t899\ndomestic\t500\t599\n";
        let card = parse_rate_card(content).unwrap();
        let bands = &card["domestic"];
        assert_eq!(bands[0].max_grams, 500);
        assert_eq!(bands[1].max_grams, 2000);
    }

    #[test]
    fn groups_multiple_zones() {
        let content = "domestic\t500\t599\ninternational\t500\t1499\n";
        let card = parse_rate_card(content).unwrap();
        assert_eq!(card.len(), 2);
        assert!(card.contains_key("domestic"));
        assert!(card.contains_key("international"));
    }

    #[test]
    fn wrong_field_count_is_malformed_with_line_number() {
        let content = "domestic\t500\t599\ndomestic\t500\n";
        let err = parse_rate_card(content).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 2 }));
    }

    #[test]
    fn unparseable_number_is_malformed_with_line_number() {
        let content = "# header\ndomestic\tabc\t599\n";
        let err = parse_rate_card(content).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 2 }));
    }

    #[test]
    fn line_numbers_count_comments_and_blanks() {
        let content = "# comment\n\ndomestic\t500\tnot-a-number\n";
        let err = parse_rate_card(content).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn empty_content_yields_empty_card() {
        let card = parse_rate_card("").unwrap();
        assert!(card.is_empty());
    }
}
