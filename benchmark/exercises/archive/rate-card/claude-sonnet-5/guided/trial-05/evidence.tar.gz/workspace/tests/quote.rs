//! Integration tests for the `RATECARD_PATH` / filesystem boundary. Pure
//! parsing and pricing behaviour is covered by unit tests inside the crate.

#![allow(clippy::unwrap_used)]

use ratecard::{quote, Parcel, QuoteError};
use std::io::Write;
use std::sync::Mutex;

// `RATECARD_PATH` is process-global state; serialize tests that touch it so
// they don't race each other under the default parallel test runner.
static ENV_LOCK: Mutex<()> = Mutex::new(());

fn write_card(contents: &str) -> tempfile::NamedTempFile {
    let mut file = tempfile::NamedTempFile::new().unwrap();
    write!(file, "{contents}").unwrap();
    file
}

fn set_ratecard_path(path: &std::path::Path) {
    // SAFETY: callers hold `ENV_LOCK`, so no other test thread observes an
    // inconsistent value while this write is in progress.
    unsafe {
        std::env::set_var("RATECARD_PATH", path);
    }
}

#[test]
fn quotes_domestic_parcel_from_matching_band() {
    let _guard = ENV_LOCK.lock().unwrap();
    let card = write_card("domestic\t500\t599\ndomestic\t2000\t899\n");
    set_ratecard_path(card.path());

    let parcel = Parcel {
        weight_grams: 400,
        zone: "domestic".to_string(),
    };
    let result = quote(&parcel).unwrap();

    assert_eq!(result.base_cents, 599);
    assert_eq!(result.band_max_grams, 500);
    assert_eq!(result.surcharge_cents, 0);
    assert_eq!(result.total_cents, 599);
}

#[test]
fn ignores_comments_and_blank_lines_in_the_card() {
    let _guard = ENV_LOCK.lock().unwrap();
    let card = write_card("# zone\tband_max_grams\tcents\n\ndomestic\t500\t599\n");
    set_ratecard_path(card.path());

    let parcel = Parcel {
        weight_grams: 100,
        zone: "domestic".to_string(),
    };
    let result = quote(&parcel).unwrap();

    assert_eq!(result.total_cents, 599);
}

#[test]
fn unknown_zone_is_reported() {
    let _guard = ENV_LOCK.lock().unwrap();
    let card = write_card("domestic\t500\t599\n");
    set_ratecard_path(card.path());

    let parcel = Parcel {
        weight_grams: 100,
        zone: "lunar".to_string(),
    };
    let err = quote(&parcel).unwrap_err();

    assert_eq!(err, QuoteError::UnknownZone("lunar".to_string()));
}

#[test]
fn overweight_parcel_is_reported_with_limit() {
    let _guard = ENV_LOCK.lock().unwrap();
    let card = write_card("domestic\t500\t599\ndomestic\t2000\t899\n");
    set_ratecard_path(card.path());

    let parcel = Parcel {
        weight_grams: 5000,
        zone: "domestic".to_string(),
    };
    let err = quote(&parcel).unwrap_err();

    assert_eq!(
        err,
        QuoteError::Overweight {
            grams: 5000,
            limit: 2000,
        }
    );
}

#[test]
fn malformed_line_reports_one_based_line_number_including_comments_and_blanks() {
    let _guard = ENV_LOCK.lock().unwrap();
    let card = write_card("# header\n\ndomestic\tnot-a-number\t899\n");
    set_ratecard_path(card.path());

    let parcel = Parcel {
        weight_grams: 100,
        zone: "domestic".to_string(),
    };
    let err = quote(&parcel).unwrap_err();

    assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
}

#[test]
fn missing_env_var_is_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap();
    // SAFETY: `_guard` holds `ENV_LOCK` for the duration of this test.
    unsafe {
        std::env::remove_var("RATECARD_PATH");
    }

    let parcel = Parcel {
        weight_grams: 100,
        zone: "domestic".to_string(),
    };
    let err = quote(&parcel).unwrap_err();

    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn unreadable_path_is_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap();
    set_ratecard_path(std::path::Path::new(
        "/nonexistent/directory/does-not-exist.tsv",
    ));

    let parcel = Parcel {
        weight_grams: 100,
        zone: "domestic".to_string(),
    };
    let err = quote(&parcel).unwrap_err();

    assert_eq!(err, QuoteError::RateCardUnavailable);
}
