//! Pure quote calculation from already-parsed bands. No I/O lives here so
//! pricing behaviour can be tested without a filesystem.

use crate::errors::QuoteError;
use crate::rate_card::Band;
use crate::{Parcel, Quote};

const HEAVY_WEIGHT_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_WEIGHT_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

/// Compute a quote for `parcel` against the zone's bands.
///
/// Bands are expected to include only those relevant to `parcel.zone`'s
/// pricing; this function filters by zone itself so callers can pass the
/// full parsed rate card.
pub(crate) fn compute_quote(bands: &[Band], parcel: &Parcel) -> Result<Quote, QuoteError> {
    let mut zone_bands: Vec<&Band> = bands.iter().filter(|b| b.zone == parcel.zone).collect();
    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }
    zone_bands.sort_by_key(|b| b.band_max_grams);

    let Some(matching) = zone_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
    else {
        // Safe to unwrap: `zone_bands` is non-empty, so it has a last element.
        let limit = zone_bands[zone_bands.len() - 1].band_max_grams;
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        });
    };

    let base_cents = matching.cents;
    let band_max_grams = matching.band_max_grams;

    let mut surcharge_cents = 0u64;
    if parcel.weight_grams > HEAVY_WEIGHT_THRESHOLD_GRAMS {
        surcharge_cents += HEAVY_WEIGHT_SURCHARGE_CENTS;
    }
    if parcel.zone == "international" {
        surcharge_cents += round_half_up_percent(base_cents, INTERNATIONAL_SURCHARGE_PERCENT);
    }

    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

/// `percent`% of `amount_cents`, rounded half-up to the cent.
fn round_half_up_percent(amount_cents: u64, percent: u64) -> u64 {
    (amount_cents * percent * 10 + 500) / 1000
}

#[cfg(test)]
#[allow(clippy::unwrap_used)]
mod tests {
    use super::*;

    fn band(zone: &str, band_max_grams: u32, cents: u64) -> Band {
        Band {
            zone: zone.to_string(),
            band_max_grams,
            cents,
        }
    }

    fn parcel(zone: &str, weight_grams: u32) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn selects_first_band_at_or_above_weight() {
        let bands = vec![
            band("domestic", 500, 599),
            band("domestic", 2000, 899),
            band("domestic", 20000, 1799),
        ];
        let quote = compute_quote(&bands, &parcel("domestic", 1500)).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn weight_exactly_at_band_boundary_matches_that_band() {
        let bands = vec![band("domestic", 500, 599), band("domestic", 2000, 899)];
        let quote = compute_quote(&bands, &parcel("domestic", 500)).unwrap();
        assert_eq!(quote.base_cents, 599);
    }

    #[test]
    fn unknown_zone_is_rejected() {
        let bands = vec![band("domestic", 500, 599)];
        let err = compute_quote(&bands, &parcel("lunar", 100)).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".to_string()));
    }

    #[test]
    fn overweight_carries_largest_band_as_limit() {
        let bands = vec![band("domestic", 500, 599), band("domestic", 2000, 899)];
        let err = compute_quote(&bands, &parcel("domestic", 2500)).unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 2500,
                limit: 2000,
            }
        );
    }

    #[test]
    fn heavy_weight_adds_flat_surcharge() {
        let bands = vec![band("domestic", 20000, 1799)];
        let quote = compute_quote(&bands, &parcel("domestic", 10001)).unwrap();
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn weight_at_threshold_is_not_surcharged() {
        let bands = vec![band("domestic", 20000, 1799)];
        let quote = compute_quote(&bands, &parcel("domestic", 10000)).unwrap();
        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_percentage_surcharge_rounded_half_up() {
        let bands = vec![band("international", 500, 1499)];
        let quote = compute_quote(&bands, &parcel("international", 500)).unwrap();
        // 20% of 1499 = 299.8, rounds half-up to 300.
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn surcharges_combine() {
        let bands = vec![band("international", 20000, 4999)];
        let quote = compute_quote(&bands, &parcel("international", 15000)).unwrap();
        // 500 flat + round_half_up(20% of 4999 = 999.8) = 500 + 1000 = 1500.
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }
}
