//! Pure parsing of the tab-separated rate card format. No I/O lives here so
//! the parsing behaviour can be tested without a filesystem.

use crate::errors::QuoteError;

/// One pricing band for a single zone.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct Band {
    pub(crate) zone: String,
    pub(crate) band_max_grams: u32,
    pub(crate) cents: u64,
}

/// Parse the rate card's contents into bands.
///
/// Empty lines and lines beginning with `#` are ignored. Every other line
/// must be exactly three tab-separated fields (`zone`, `band_max_grams`,
/// `cents`) with numeric fields that parse; otherwise the line is malformed.
pub(crate) fn parse_rate_card(contents: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();

    for (index, raw_line) in contents.lines().enumerate() {
        let line = index + 1;

        if raw_line.is_empty() || raw_line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = raw_line.split('\t').collect();
        let [zone, band_max_grams, cents] = fields.as_slice() else {
            return Err(QuoteError::MalformedRateCard { line });
        };

        let band_max_grams: u32 = band_max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line })?;
        let cents: u64 = cents
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line })?;

        bands.push(Band {
            zone: (*zone).to_string(),
            band_max_grams,
            cents,
        });
    }

    Ok(bands)
}

#[cfg(test)]
#[allow(clippy::unwrap_used)]
mod tests {
    use super::*;

    #[test]
    fn ignores_blank_and_comment_lines() {
        let bands = parse_rate_card("# header\n\ndomestic\t500\t599\n").unwrap();
        assert_eq!(
            bands,
            vec![Band {
                zone: "domestic".to_string(),
                band_max_grams: 500,
                cents: 599,
            }]
        );
    }

    #[test]
    fn parses_multiple_zones_and_bands() {
        let bands = parse_rate_card(
            "domestic\t500\t599\ndomestic\t2000\t899\ninternational\t500\t1499\n",
        )
        .unwrap();
        assert_eq!(bands.len(), 3);
    }

    #[test]
    fn rejects_wrong_field_count() {
        let err = parse_rate_card("domestic\t500\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn rejects_unparseable_numbers() {
        let err = parse_rate_card("domestic\tnot-a-number\t599\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn line_number_counts_comments_and_blanks() {
        let err =
            parse_rate_card("# header\n\ndomestic\t500\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }
}
