//! Shipping quotes for the fulfilment service.
//!
//! Warehouse operators price outbound parcels against a rate card that
//! operations maintains and redeploys without a code change. This crate
//! owns reading that card (the imperative shell, in [`quote`]) and turning
//! a parcel into a [`Quote`] (pure logic, in the private `pricing` and
//! `rate_card` modules).

mod errors;
mod pricing;
mod rate_card;

/// Zone labels and display helpers.
pub mod zones;

use std::env;
use std::fs;

pub use errors::QuoteError;

/// A parcel to be quoted.
#[derive(Debug, Clone)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Destination zone, matched against the rate card's zone column.
    pub zone: String,
}

/// A calculated shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// The matching band's price, before surcharges.
    pub base_cents: u64,
    /// The sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// The matching band's weight threshold.
    pub band_max_grams: u32,
}

/// Calculate a shipping quote for `parcel` using the rate card at the path
/// in the `RATECARD_PATH` environment variable.
///
/// # Errors
///
/// Returns [`QuoteError::RateCardUnavailable`] if `RATECARD_PATH` is unset
/// or the file it names cannot be read; [`QuoteError::MalformedRateCard`] if
/// a line in the card does not parse; [`QuoteError::UnknownZone`] if
/// `parcel.zone` has no bands in the card; and [`QuoteError::Overweight`] if
/// `parcel.weight_grams` exceeds the zone's largest band.
///
/// # Examples
///
/// ```
/// use std::io::Write;
/// use ratecard::{quote, Parcel};
///
/// let mut file = tempfile::NamedTempFile::new().unwrap();
/// writeln!(file, "domestic\t500\t599").unwrap();
/// unsafe {
///     std::env::set_var("RATECARD_PATH", file.path());
/// }
///
/// let parcel = Parcel { weight_grams: 250, zone: "domestic".to_string() };
/// let result = quote(&parcel).unwrap();
/// assert_eq!(result.total_cents, 599);
/// ```
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "ratecard.quote",
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = tracing::field::Empty,
    );
    let _guard = span.enter();

    let result = read_and_quote(parcel);

    if let Ok(ref computed) = result {
        span.record("total_cents", computed.total_cents);
        tracing::info!("quote computed");
    }

    result
}

fn read_and_quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = rate_card::parse_rate_card(&contents)?;
    pricing::compute_quote(&bands, parcel)
}
