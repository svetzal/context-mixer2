use std::fmt;

/// The reasons a [`crate::quote`] call can fail.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card at `RATECARD_PATH` is missing, unset, or unreadable.
    RateCardUnavailable,
    /// A rate card line did not parse, at the given 1-based line number.
    MalformedRateCard {
        /// 1-based line number, counting comments and blank lines.
        line: usize,
    },
    /// The parcel's zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight {
        /// The parcel's weight in grams.
        grams: u32,
        /// The zone's largest `band_max_grams`.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card is unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "rate card is malformed at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}
