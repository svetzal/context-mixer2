//! Integration tests for the `RATECARD_PATH` boundary: reading, missing
//! files, and malformed content. Pure pricing and parsing behaviour is
//! covered by the crate's inline unit tests instead.
#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

use std::io::Write;
use std::sync::Mutex;

use ratecard::{quote, Parcel, QuoteError};

/// `RATECARD_PATH` is process-wide state, so tests that touch it must not
/// run concurrently with each other.
static ENV_LOCK: Mutex<()> = Mutex::new(());

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_string(),
    }
}

fn with_rate_card<T>(contents: &str, run: impl FnOnce() -> T) -> T {
    let _guard = ENV_LOCK.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
    let mut file = tempfile::NamedTempFile::new().expect("create temp rate card");
    file.write_all(contents.as_bytes())
        .expect("write temp rate card");
    std::env::set_var("RATECARD_PATH", file.path());
    let outcome = run();
    std::env::remove_var("RATECARD_PATH");
    outcome
}

const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

#[test]
fn quotes_a_domestic_parcel() {
    with_rate_card(CARD, || {
        let result = quote(&parcel(200, "domestic")).expect("quote succeeds");
        assert_eq!(result.base_cents, 599);
        assert_eq!(result.surcharge_cents, 0);
        assert_eq!(result.total_cents, 599);
        assert_eq!(result.band_max_grams, 500);
    });
}

#[test]
fn quotes_an_international_parcel_with_surcharge() {
    with_rate_card(CARD, || {
        let result = quote(&parcel(500, "international")).expect("quote succeeds");
        assert_eq!(result.base_cents, 1499);
        assert_eq!(result.surcharge_cents, 300);
        assert_eq!(result.total_cents, 1799);
    });
}

#[test]
fn missing_env_var_is_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
    std::env::remove_var("RATECARD_PATH");
    let result = quote(&parcel(200, "domestic"));
    assert_eq!(result.unwrap_err(), QuoteError::RateCardUnavailable);
}

#[test]
fn nonexistent_file_is_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
    std::env::set_var("RATECARD_PATH", "/nonexistent/path/does-not-exist.tsv");
    let result = quote(&parcel(200, "domestic"));
    std::env::remove_var("RATECARD_PATH");
    assert_eq!(result.unwrap_err(), QuoteError::RateCardUnavailable);
}

#[test]
fn malformed_line_reports_its_line_number_including_comments_and_blanks() {
    let contents = "# header\n\ndomestic\t500\n";
    with_rate_card(contents, || {
        let result = quote(&parcel(200, "domestic"));
        assert_eq!(result.unwrap_err(), QuoteError::MalformedRateCard { line: 3 });
    });
}

#[test]
fn unknown_zone_carries_the_requested_zone() {
    with_rate_card(CARD, || {
        let result = quote(&parcel(200, "lunar"));
        assert_eq!(
            result.unwrap_err(),
            QuoteError::UnknownZone("lunar".to_string())
        );
    });
}

#[test]
fn overweight_carries_the_zone_limit() {
    with_rate_card(CARD, || {
        let result = quote(&parcel(20001, "domestic"));
        assert_eq!(
            result.unwrap_err(),
            QuoteError::Overweight {
                grams: 20001,
                limit: 20000
            }
        );
    });
}

#[test]
fn heavy_international_parcel_stacks_both_surcharges() {
    with_rate_card(CARD, || {
        let result = quote(&parcel(15000, "international")).expect("quote succeeds");
        assert_eq!(result.base_cents, 4999);
        assert_eq!(result.surcharge_cents, 500 + 1000);
        assert_eq!(result.total_cents, 6499);
    });
}
