//! Shipping quotes for outbound parcels, priced against a rate card that
//! operations maintains outside the codebase.
//!
//! [`quote`] is a thin imperative shell: it reads the rate card named by the
//! `RATECARD_PATH` environment variable and delegates parsing and pricing to
//! pure internal functions that are testable without any filesystem or
//! environment access.

mod error;
mod pricing;
mod rate_card;
pub mod zones;

use std::env;
use std::fs;

pub use error::QuoteError;

/// A parcel to be quoted.
#[derive(Debug, Clone)]
pub struct Parcel {
    /// The parcel's weight, in grams.
    pub weight_grams: u32,
    /// The shipping zone the parcel is destined for.
    pub zone: String,
}

/// A priced quote for a [`Parcel`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// The base price for the matching band, in cents.
    pub base_cents: u64,
    /// The sum of any surcharges, in cents.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// The `band_max_grams` of the band that matched the parcel's weight.
    pub band_max_grams: u32,
}

/// Prices `parcel` against the rate card named by the `RATECARD_PATH`
/// environment variable.
///
/// # Errors
///
/// Returns [`QuoteError::RateCardUnavailable`] if `RATECARD_PATH` is unset
/// or names a file that cannot be read, [`QuoteError::MalformedRateCard`] if
/// the file has a line that cannot be parsed, [`QuoteError::UnknownZone`] if
/// `parcel.zone` has no bands, and [`QuoteError::Overweight`] if
/// `parcel.weight_grams` exceeds the zone's largest band.
///
/// # Examples
///
/// ```
/// use ratecard::{quote, Parcel};
///
/// let path = std::env::temp_dir().join(format!("ratecard-doctest-{}.tsv", std::process::id()));
/// std::fs::write(&path, "domestic\t500\t599\n").unwrap();
/// std::env::set_var("RATECARD_PATH", &path);
///
/// let result = quote(&Parcel { weight_grams: 200, zone: "domestic".to_string() }).unwrap();
/// assert_eq!(result.total_cents, 599);
///
/// std::fs::remove_file(&path).unwrap();
/// ```
#[tracing::instrument(
    name = "ratecard.quote",
    skip(parcel),
    fields(zone = %parcel.zone, weight_grams = parcel.weight_grams, total_cents)
)]
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let result = quote_inner(parcel);

    match &result {
        Ok(q) => {
            tracing::Span::current().record("total_cents", q.total_cents);
            tracing::info!(total_cents = q.total_cents, "quote calculated");
        }
        Err(error) => {
            tracing::warn!(%error, "quote failed");
        }
    }

    result
}

fn quote_inner(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var(RATECARD_PATH_VAR).map_err(|_| QuoteError::RateCardUnavailable)?;
    let text = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = rate_card::parse(&text)?;
    pricing::compute(&card, parcel)
}

const RATECARD_PATH_VAR: &str = "RATECARD_PATH";
