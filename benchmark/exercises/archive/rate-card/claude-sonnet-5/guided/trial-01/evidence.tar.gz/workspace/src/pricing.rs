//! Pure quote computation given an already-parsed rate card. No I/O.

use crate::rate_card::RateCard;
use crate::{Parcel, Quote, QuoteError};

const OVERWEIGHT_SURCHARGE_THRESHOLD_GRAMS: u32 = 10_000;
const OVERWEIGHT_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";

pub(crate) fn compute(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = card
        .bands_for(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = bands.iter().map(|band| band.max_grams).max().unwrap_or(0);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > OVERWEIGHT_SURCHARGE_THRESHOLD_GRAMS {
        surcharge_cents += OVERWEIGHT_SURCHARGE_CENTS;
    }

    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge_cents += round_half_up_20_percent(base_cents);
    }

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

/// 20% of `cents`, rounded half-up to the nearest whole cent.
///
/// `cents / 5` has at most one decimal digit of fractional cents (tenths),
/// so `(2 * cents + 5) / 10` implements round-half-up without ever landing
/// on an exact tie.
fn round_half_up_20_percent(cents: u64) -> u64 {
    (cents * 2 + 5) / 10
}

#[cfg(test)]
mod tests {
    #![allow(clippy::unwrap_used, clippy::expect_used)]

    use super::*;
    use crate::rate_card::parse;

    const CARD: &str = "\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn picks_the_first_band_at_or_above_weight() {
        let card = parse(CARD).unwrap();
        let quote = compute(&card, &parcel(500, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
    }

    #[test]
    fn picks_the_next_band_when_weight_falls_between() {
        let card = parse(CARD).unwrap();
        let quote = compute(&card, &parcel(501, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn adds_heavy_parcel_surcharge_above_10000_grams() {
        let card = parse(CARD).unwrap();
        let quote = compute(&card, &parcel(10001, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn does_not_add_heavy_surcharge_at_exactly_10000_grams() {
        let card = parse(CARD).unwrap();
        let quote = compute(&card, &parcel(10000, "domestic")).unwrap();
        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn adds_international_surcharge_rounded_half_up() {
        let card = parse(CARD).unwrap();
        let quote = compute(&card, &parcel(500, "international")).unwrap();
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300); // 299.8 -> 300
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn stacks_heavy_and_international_surcharges() {
        let card = parse(CARD).unwrap();
        let quote = compute(&card, &parcel(20000, "international")).unwrap();
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 500 + 1000); // 999.8 -> 1000
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_is_reported_with_the_requested_name() {
        let card = parse(CARD).unwrap();
        let err = compute(&card, &parcel(100, "lunar")).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".to_string()));
    }

    #[test]
    fn overweight_is_reported_with_the_zone_limit() {
        let card = parse(CARD).unwrap();
        let err = compute(&card, &parcel(20001, "domestic")).unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 20001,
                limit: 20000
            }
        );
    }
}
