use std::fmt;

/// Reasons a [`crate::quote`] call can fail.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` was unset, or the file it names could not be read.
    RateCardUnavailable,
    /// The rate card contained a line that could not be parsed.
    ///
    /// `line` is the 1-based line number, counting every line in the file
    /// including comments and blanks.
    MalformedRateCard {
        /// The 1-based line number of the offending line.
        line: usize,
    },
    /// The parcel's zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel's weight exceeds the zone's largest band.
    Overweight {
        /// The parcel's weight, in grams.
        grams: u32,
        /// The zone's largest `band_max_grams`.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weighs {grams}g, exceeding the {limit}g limit")
            }
        }
    }
}

impl std::error::Error for QuoteError {}
