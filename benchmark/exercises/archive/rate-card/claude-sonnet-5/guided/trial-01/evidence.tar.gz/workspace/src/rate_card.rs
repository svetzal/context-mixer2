//! Pure parsing of the tab-separated rate card format. Nothing here touches
//! the filesystem or the environment, so it is testable with plain strings.

use std::collections::HashMap;

use crate::QuoteError;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct Band {
    pub(crate) max_grams: u32,
    pub(crate) cents: u64,
}

#[derive(Debug, Default, Clone, PartialEq, Eq)]
pub(crate) struct RateCard {
    zones: HashMap<String, Vec<Band>>,
}

impl RateCard {
    pub(crate) fn bands_for(&self, zone: &str) -> Option<&[Band]> {
        self.zones.get(zone).map(Vec::as_slice)
    }
}

/// Parses the tab-separated rate card format.
///
/// Empty lines and lines beginning with `#` are ignored. Every other line
/// must be exactly `zone\tband_max_grams\tcents`, with the numeric fields
/// parsing as `u32` and `u64` respectively. Bands are sorted ascending by
/// `band_max_grams` within each zone regardless of file order.
pub(crate) fn parse(text: &str) -> Result<RateCard, QuoteError> {
    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, raw_line) in text.lines().enumerate() {
        let line_number = index + 1;
        let line = raw_line.trim_end_matches('\r');

        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        let [zone, max_grams, cents] = fields.as_slice() else {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        };

        let max_grams: u32 = max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = cents
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        zones
            .entry((*zone).to_string())
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(RateCard { zones })
}

#[cfg(test)]
mod tests {
    #![allow(clippy::unwrap_used, clippy::expect_used)]

    use super::*;

    #[test]
    fn ignores_blank_and_comment_lines() {
        let card = parse("# header\n\ndomestic\t500\t599\n").unwrap();
        assert_eq!(
            card.bands_for("domestic"),
            Some(&[Band {
                max_grams: 500,
                cents: 599
            }][..])
        );
    }

    #[test]
    fn sorts_bands_ascending_regardless_of_file_order() {
        let card = parse("domestic\t2000\t899\ndomestic\t500\t599\n").unwrap();
        assert_eq!(
            card.bands_for("domestic"),
            Some(
                &[
                    Band {
                        max_grams: 500,
                        cents: 599
                    },
                    Band {
                        max_grams: 2000,
                        cents: 899
                    }
                ][..]
            )
        );
    }

    #[test]
    fn unknown_zone_has_no_bands() {
        let card = parse("domestic\t500\t599\n").unwrap();
        assert_eq!(card.bands_for("international"), None);
    }

    #[test]
    fn rejects_wrong_field_count() {
        let err = parse("domestic\t500\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn rejects_unparsable_numbers() {
        let err = parse("domestic\tabc\t599\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn reports_the_correct_line_counting_comments_and_blanks() {
        let err = parse("# header\n\ndomestic\t500\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }
}
