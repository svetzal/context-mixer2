//! Pure quote calculation from a parsed rate table. No I/O happens here; see
//! [`crate::loader`] for reading the rate card and [`crate::parser`] for
//! parsing it.

use crate::error::QuoteError;
use crate::parser::RateTable;
use crate::{Parcel, Quote};

const OVERWEIGHT_THRESHOLD_GRAMS: u32 = 10_000;
const OVERWEIGHT_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";

pub(crate) fn calculate(parcel: &Parcel, rate_table: &RateTable) -> Result<Quote, QuoteError> {
    let bands = rate_table
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: bands.iter().map(|band| band.max_grams).max().unwrap_or(0),
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > OVERWEIGHT_THRESHOLD_GRAMS {
        surcharge_cents += OVERWEIGHT_SURCHARGE_CENTS;
    }
    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge_cents += international_surcharge(base_cents);
    }

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

/// 20% of `base_cents`, rounded half-up to the cent.
fn international_surcharge(base_cents: u64) -> u64 {
    (base_cents * 20 + 50) / 100
}

#[cfg(test)]
mod tests {
    #![allow(clippy::unwrap_used)]

    use super::*;
    use crate::parser::Band;
    use std::collections::HashMap;

    fn table() -> RateTable {
        let mut table = HashMap::new();
        table.insert(
            "domestic".to_string(),
            vec![
                Band { max_grams: 500, cents: 599 },
                Band { max_grams: 2000, cents: 899 },
                Band { max_grams: 20000, cents: 1799 },
            ],
        );
        table.insert(
            "international".to_string(),
            vec![
                Band { max_grams: 500, cents: 1499 },
                Band { max_grams: 20000, cents: 4999 },
            ],
        );
        table
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel { weight_grams, zone: zone.to_string() }
    }

    #[test]
    fn picks_smallest_band_at_or_above_weight() {
        let quote = calculate(&parcel(300, "domestic"), &table()).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.total_cents, 599);
    }

    #[test]
    fn weight_exactly_on_a_band_boundary_matches_that_band() {
        let quote = calculate(&parcel(500, "domestic"), &table()).unwrap();
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.base_cents, 599);
    }

    #[test]
    fn overweight_surcharge_applies_strictly_above_threshold() {
        let quote = calculate(&parcel(10_000, "domestic"), &table()).unwrap();
        assert_eq!(quote.surcharge_cents, 0);

        let quote = calculate(&parcel(10_001, "domestic"), &table()).unwrap();
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, quote.base_cents + 500);
    }

    #[test]
    fn international_surcharge_is_twenty_percent_rounded_half_up() {
        let quote = calculate(&parcel(500, "international"), &table()).unwrap();
        // 20% of 1499 = 299.8 -> 300
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn international_and_overweight_surcharges_add_together() {
        let quote = calculate(&parcel(15_000, "international"), &table()).unwrap();
        // 20% of 4999 = 999.8 -> 1000, plus the 500 overweight surcharge
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 4999 + 1500);
    }

    #[test]
    fn unknown_zone_is_reported_with_the_requested_zone() {
        let err = calculate(&parcel(100, "lunar"), &table()).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".to_string()));
    }

    #[test]
    fn overweight_reports_the_zones_largest_band() {
        let err = calculate(&parcel(20_001, "domestic"), &table()).unwrap_err();
        assert_eq!(err, QuoteError::Overweight { grams: 20_001, limit: 20_000 });
    }
}
