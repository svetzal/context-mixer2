//! The thin imperative shell that reads the rate card off disk. All parsing
//! and calculation logic lives in [`crate::parser`] and [`crate::calculator`]
//! and can be tested without touching the filesystem or environment.

use std::env;
use std::fs;

use crate::error::QuoteError;

const RATECARD_PATH_VAR: &str = "RATECARD_PATH";

/// Reads the raw rate card text from the path in `RATECARD_PATH`.
pub(crate) fn load_rate_card() -> Result<String, QuoteError> {
    let path = env::var(RATECARD_PATH_VAR).map_err(|_| QuoteError::RateCardUnavailable)?;
    fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)
}
