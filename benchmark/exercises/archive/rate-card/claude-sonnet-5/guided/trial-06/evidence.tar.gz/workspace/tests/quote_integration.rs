//! Boundary and cross-module tests: real files, real environment variables,
//! real `quote` calls. Pure calculation and parsing behaviour is covered by
//! the crate's inline unit tests instead.
#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

use std::io::Write;
use std::sync::Mutex;

use ratecard::{Parcel, QuoteError};
use tempfile::NamedTempFile;

// `RATECARD_PATH` is process-global; serialize every test that touches it so
// tests running on separate threads don't observe each other's value.
static RATECARD_PATH_LOCK: Mutex<()> = Mutex::new(());

const SAMPLE_RATE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

/// Writes `contents` to a temp file, points `RATECARD_PATH` at it for the
/// duration of `body`, and restores the previous value afterwards.
fn with_rate_card<T>(contents: &str, body: impl FnOnce() -> T) -> T {
    let _guard = RATECARD_PATH_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());

    let mut file = NamedTempFile::new().expect("create temp rate card");
    file.write_all(contents.as_bytes()).expect("write temp rate card");

    let previous = std::env::var("RATECARD_PATH").ok();
    unsafe { std::env::set_var("RATECARD_PATH", file.path()) };

    let result = body();

    match previous {
        Some(value) => unsafe { std::env::set_var("RATECARD_PATH", value) },
        None => unsafe { std::env::remove_var("RATECARD_PATH") },
    }

    result
}

fn without_rate_card_path<T>(body: impl FnOnce() -> T) -> T {
    let _guard = RATECARD_PATH_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());

    let previous = std::env::var("RATECARD_PATH").ok();
    unsafe { std::env::remove_var("RATECARD_PATH") };

    let result = body();

    if let Some(value) = previous {
        unsafe { std::env::set_var("RATECARD_PATH", value) };
    }

    result
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel { weight_grams, zone: zone.to_string() }
}

#[test]
fn quotes_a_domestic_parcel_within_its_lightest_band() {
    with_rate_card(SAMPLE_RATE_CARD, || {
        let quote = ratecard::quote(&parcel(300, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    });
}

#[test]
fn applies_overweight_surcharge_strictly_above_ten_thousand_grams() {
    with_rate_card(SAMPLE_RATE_CARD, || {
        let at_threshold = ratecard::quote(&parcel(10_000, "domestic")).unwrap();
        assert_eq!(at_threshold.surcharge_cents, 0);

        let above_threshold = ratecard::quote(&parcel(10_001, "domestic")).unwrap();
        assert_eq!(above_threshold.surcharge_cents, 500);
        assert_eq!(above_threshold.total_cents, above_threshold.base_cents + 500);
    });
}

#[test]
fn applies_international_surcharge_rounded_half_up() {
    with_rate_card(SAMPLE_RATE_CARD, || {
        let quote = ratecard::quote(&parcel(500, "international")).unwrap();
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    });
}

#[test]
fn combines_overweight_and_international_surcharges() {
    with_rate_card(SAMPLE_RATE_CARD, || {
        let quote = ratecard::quote(&parcel(15_000, "international")).unwrap();
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    });
}

#[test]
fn unknown_zone_carries_the_requested_zone() {
    with_rate_card(SAMPLE_RATE_CARD, || {
        let err = ratecard::quote(&parcel(100, "lunar")).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".to_string()));
    });
}

#[test]
fn overweight_carries_the_zones_largest_band() {
    with_rate_card(SAMPLE_RATE_CARD, || {
        let err = ratecard::quote(&parcel(20_001, "domestic")).unwrap_err();
        assert_eq!(err, QuoteError::Overweight { grams: 20_001, limit: 20_000 });
    });
}

#[test]
fn malformed_line_reports_its_one_based_number_including_comments_and_blanks() {
    let rate_card = "# header\n\ndomestic\t500\tnot-a-number\n";
    with_rate_card(rate_card, || {
        let err = ratecard::quote(&parcel(100, "domestic")).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    });
}

#[test]
fn missing_env_var_is_rate_card_unavailable() {
    without_rate_card_path(|| {
        let err = ratecard::quote(&parcel(100, "domestic")).unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    });
}

#[test]
fn unreadable_path_is_rate_card_unavailable() {
    let _guard = RATECARD_PATH_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    let previous = std::env::var("RATECARD_PATH").ok();
    unsafe { std::env::set_var("RATECARD_PATH", "/nonexistent/rate-card.tsv") };

    let err = ratecard::quote(&parcel(100, "domestic")).unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);

    match previous {
        Some(value) => unsafe { std::env::set_var("RATECARD_PATH", value) },
        None => unsafe { std::env::remove_var("RATECARD_PATH") },
    }
}

#[test]
#[tracing_test::traced_test]
fn a_successful_quote_emits_a_diagnostic_record_with_zone_weight_and_total() {
    with_rate_card(SAMPLE_RATE_CARD, || {
        let quote = ratecard::quote(&parcel(300, "domestic")).unwrap();
        assert_eq!(quote.total_cents, 599);
    });

    assert!(logs_contain("zone"));
    assert!(logs_contain("domestic"));
    assert!(logs_contain("weight_grams"));
    assert!(logs_contain("300"));
    assert!(logs_contain("total_cents"));
    assert!(logs_contain("599"));
}
