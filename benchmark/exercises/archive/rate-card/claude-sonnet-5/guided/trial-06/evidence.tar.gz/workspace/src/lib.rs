//! Shipping quotes for the fulfilment service.
//!
//! Warehouse operators price outbound parcels against a rate card that
//! operations maintains and redeploys without a code change. This crate
//! reads that card and turns a [`Parcel`] into a [`Quote`].

mod calculator;
mod error;
mod loader;
mod parser;
pub mod zones;

pub use error::QuoteError;

/// A parcel awaiting a shipping quote.
#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A computed shipping quote.
#[derive(Debug, Clone, Copy)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Quotes `parcel` against the rate card at the path in `RATECARD_PATH`.
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// let mut file = tempfile::NamedTempFile::new().unwrap();
/// writeln!(file, "domestic\t500\t599").unwrap();
/// unsafe { std::env::set_var("RATECARD_PATH", file.path()) };
///
/// let parcel = ratecard::Parcel { weight_grams: 300, zone: "domestic".to_string() };
/// let quote = ratecard::quote(&parcel).unwrap();
///
/// assert_eq!(quote.total_cents, 599);
/// ```
///
/// # Errors
///
/// Returns [`QuoteError`] when `RATECARD_PATH` is unset or unreadable, the
/// rate card is malformed, the parcel's zone is absent from the rate card, or
/// the parcel's weight exceeds every band for its zone.
#[tracing::instrument(
    name = "ratecard.quote",
    skip(parcel),
    fields(zone = %parcel.zone, weight_grams = parcel.weight_grams, total_cents = tracing::field::Empty)
)]
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let raw_rate_card = loader::load_rate_card()?;
    let rate_table = parser::parse(&raw_rate_card)?;
    let computed = calculator::calculate(parcel, &rate_table)?;

    tracing::Span::current().record("total_cents", computed.total_cents);
    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = computed.total_cents,
        "quote calculated"
    );

    Ok(computed)
}
