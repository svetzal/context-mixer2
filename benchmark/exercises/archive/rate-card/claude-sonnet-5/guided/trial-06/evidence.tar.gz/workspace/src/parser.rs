//! Pure parsing of the tab-separated rate card format into an in-memory
//! table. No I/O happens here; see [`crate::loader`] for reading the file.

use std::collections::HashMap;

use crate::error::QuoteError;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct Band {
    pub(crate) max_grams: u32,
    pub(crate) cents: u64,
}

pub(crate) type RateTable = HashMap<String, Vec<Band>>;

/// Parses `text` into a table of zone -> bands, sorted ascending by
/// `max_grams` within each zone.
pub(crate) fn parse(text: &str) -> Result<RateTable, QuoteError> {
    let mut table: RateTable = HashMap::new();

    for (index, line) in text.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        let [zone, band_max_grams, cents] = fields.as_slice() else {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        };

        let band_max_grams: u32 = band_max_grams
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = cents
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        table
            .entry(zone.trim().to_string())
            .or_default()
            .push(Band { max_grams: band_max_grams, cents });
    }

    for bands in table.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(table)
}

#[cfg(test)]
mod tests {
    #![allow(clippy::unwrap_used)]

    use super::*;

    #[test]
    fn ignores_comments_and_blank_lines() {
        let table = parse("# header\n\ndomestic\t500\t599\n").unwrap();
        assert_eq!(table["domestic"], vec![Band { max_grams: 500, cents: 599 }]);
    }

    #[test]
    fn sorts_bands_ascending_regardless_of_file_order() {
        let table = parse("domestic\t2000\t899\ndomestic\t500\t599\n").unwrap();
        assert_eq!(
            table["domestic"],
            vec![
                Band { max_grams: 500, cents: 599 },
                Band { max_grams: 2000, cents: 899 },
            ]
        );
    }

    #[test]
    fn separates_zones() {
        let table = parse("domestic\t500\t599\ninternational\t500\t1499\n").unwrap();
        assert_eq!(table.len(), 2);
        assert!(table.contains_key("domestic"));
        assert!(table.contains_key("international"));
    }

    #[test]
    fn rejects_wrong_field_count() {
        let err = parse("domestic\t500\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn rejects_unparseable_numbers() {
        let err = parse("domestic\tfive-hundred\t599\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn line_number_counts_comments_and_blanks() {
        let err = parse("# header\n\ndomestic\t500\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }
}
