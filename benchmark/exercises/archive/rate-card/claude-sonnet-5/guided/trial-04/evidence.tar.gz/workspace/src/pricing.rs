//! Pure quote calculation over already-parsed rate card bands. No I/O here.

use crate::parsing::Band;
use crate::{Parcel, Quote, QuoteError};

const HEAVY_SURCHARGE_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

pub(crate) fn compute_quote(bands: &[Band], parcel: &Parcel) -> Result<Quote, QuoteError> {
    let mut zone_bands: Vec<&Band> = bands.iter().filter(|band| band.zone == parcel.zone).collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|band| band.band_max_grams);

    let limit = zone_bands.last().map_or(0, |band| band.band_max_grams);
    let band = zone_bands
        .iter()
        .find(|band| band.band_max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let base_cents = band.cents;

    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > HEAVY_SURCHARGE_THRESHOLD_GRAMS {
        surcharge_cents += HEAVY_SURCHARGE_CENTS;
    }
    if parcel.zone == "international" {
        surcharge_cents += round_half_up_percentage(base_cents, INTERNATIONAL_SURCHARGE_PERCENT);
    }

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.band_max_grams,
    })
}

/// `percent`% of `amount_cents`, rounded half-up to the nearest cent.
fn round_half_up_percentage(amount_cents: u64, percent: u64) -> u64 {
    (amount_cents * percent + 50) / 100
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used)]
mod tests {
    use super::*;

    fn band(zone: &str, band_max_grams: u32, cents: u64) -> Band {
        Band {
            zone: zone.to_string(),
            band_max_grams,
            cents,
        }
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    fn sample_bands() -> Vec<Band> {
        vec![
            band("domestic", 500, 599),
            band("domestic", 2000, 899),
            band("domestic", 20000, 1799),
            band("international", 500, 1499),
            band("international", 20000, 4999),
        ]
    }

    #[test]
    fn picks_first_band_at_or_above_weight() {
        let quote = compute_quote(&sample_bands(), &parcel(200, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
    }

    #[test]
    fn weight_exactly_on_a_band_boundary_matches_that_band() {
        let quote = compute_quote(&sample_bands(), &parcel(500, "domestic")).unwrap();
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn unknown_zone_is_reported() {
        let err = compute_quote(&sample_bands(), &parcel(200, "lunar")).unwrap_err();
        assert!(matches!(err, QuoteError::UnknownZone(zone) if zone == "lunar"));
    }

    #[test]
    fn overweight_carries_the_zones_largest_band() {
        let err = compute_quote(&sample_bands(), &parcel(20001, "domestic")).unwrap_err();
        assert!(matches!(
            err,
            QuoteError::Overweight {
                grams: 20001,
                limit: 20000
            }
        ));
    }

    #[test]
    fn heavy_parcels_add_a_flat_surcharge() {
        let quote = compute_quote(&sample_bands(), &parcel(10001, "domestic")).unwrap();
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, quote.base_cents + 500);
    }

    #[test]
    fn weight_at_exactly_the_threshold_has_no_surcharge() {
        let quote = compute_quote(&sample_bands(), &parcel(10000, "domestic")).unwrap();
        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_twenty_percent_rounded_half_up() {
        // 20% of 1499 = 299.8 -> rounds up to 300
        let quote = compute_quote(&sample_bands(), &parcel(200, "international")).unwrap();
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn international_and_heavy_surcharges_combine() {
        let quote = compute_quote(&sample_bands(), &parcel(15000, "international")).unwrap();
        // 20% of 4999 = 999.8 -> 1000, plus the 500 heavy surcharge
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn band_order_in_the_rate_card_does_not_matter() {
        let mut bands = sample_bands();
        bands.reverse();
        let quote = compute_quote(&bands, &parcel(200, "domestic")).unwrap();
        assert_eq!(quote.band_max_grams, 500);
    }
}
