//! Wiring tests: does `quote` correctly read `RATECARD_PATH` and the file it
//! names? Pure parsing and pricing behaviour is already covered by the
//! crate's inline unit tests; this file only exercises the imperative shell.
#![allow(clippy::unwrap_used, clippy::expect_used)]

use std::io::Write;
use std::sync::Mutex;

use ratecard::{quote, Parcel, QuoteError};

// `RATECARD_PATH` is process-global state. Serialize the tests that touch it
// so they don't race across threads within this test binary.
static ENV_GUARD: Mutex<()> = Mutex::new(());

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_string(),
    }
}

fn with_rate_card<R>(contents: &str, run: impl FnOnce() -> R) -> R {
    let _guard = ENV_GUARD.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    let mut file = tempfile::NamedTempFile::new().expect("create temp rate card");
    write!(file, "{contents}").expect("write temp rate card");
    std::env::set_var("RATECARD_PATH", file.path());
    let result = run();
    std::env::remove_var("RATECARD_PATH");
    result
}

const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

#[test]
fn reads_the_rate_card_named_by_the_env_var() {
    let result = with_rate_card(SAMPLE_CARD, || quote(&parcel(200, "domestic")));
    let quote = result.expect("quote succeeds");
    assert_eq!(quote.base_cents, 599);
    assert_eq!(quote.total_cents, 599);
    assert_eq!(quote.band_max_grams, 500);
}

#[test]
fn missing_env_var_is_rate_card_unavailable() {
    let _guard = ENV_GUARD.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    std::env::remove_var("RATECARD_PATH");

    let err = quote(&parcel(200, "domestic")).unwrap_err();
    assert!(matches!(err, QuoteError::RateCardUnavailable));
}

#[test]
fn unreadable_path_is_rate_card_unavailable() {
    let _guard = ENV_GUARD.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    std::env::set_var("RATECARD_PATH", "/nonexistent/path/does-not-exist.tsv");

    let err = quote(&parcel(200, "domestic")).unwrap_err();
    assert!(matches!(err, QuoteError::RateCardUnavailable));

    std::env::remove_var("RATECARD_PATH");
}

#[test]
fn malformed_line_in_the_file_is_reported_with_its_line_number() {
    let card = "domestic\t500\t599\ndomestic\tnot-a-number\t899\n";
    let result = with_rate_card(card, || quote(&parcel(200, "domestic")));
    let err = result.unwrap_err();
    assert!(matches!(err, QuoteError::MalformedRateCard { line: 2 }));
}

#[test]
fn unknown_zone_is_reported() {
    let result = with_rate_card(SAMPLE_CARD, || quote(&parcel(200, "lunar")));
    let err = result.unwrap_err();
    assert!(matches!(err, QuoteError::UnknownZone(zone) if zone == "lunar"));
}

#[test]
fn overweight_is_reported() {
    let result = with_rate_card(SAMPLE_CARD, || quote(&parcel(20001, "domestic")));
    let err = result.unwrap_err();
    assert!(matches!(
        err,
        QuoteError::Overweight {
            grams: 20001,
            limit: 20000
        }
    ));
}

#[test]
fn international_surcharge_end_to_end() {
    let result = with_rate_card(SAMPLE_CARD, || quote(&parcel(200, "international")));
    let quote = result.expect("quote succeeds");
    assert_eq!(quote.base_cents, 1499);
    assert_eq!(quote.surcharge_cents, 300);
    assert_eq!(quote.total_cents, 1799);
}
