//! Confirms `quote` emits a diagnostic record carrying the zone, weight,
//! and total, as required for operators to observe quoting in production.
#![allow(clippy::unwrap_used, clippy::expect_used)]

use std::io::Write;
use std::sync::Mutex;

use ratecard::{quote, Parcel};
use tracing_test::traced_test;

static ENV_GUARD: Mutex<()> = Mutex::new(());

#[traced_test]
#[test]
fn quote_emits_zone_weight_and_total() {
    let _guard = ENV_GUARD.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    let mut file = tempfile::NamedTempFile::new().expect("create temp rate card");
    writeln!(file, "domestic\t500\t599").expect("write temp rate card");
    std::env::set_var("RATECARD_PATH", file.path());

    let parcel = Parcel {
        weight_grams: 200,
        zone: "domestic".to_string(),
    };
    quote(&parcel).expect("quote succeeds");

    std::env::remove_var("RATECARD_PATH");

    assert!(logs_contain("zone"));
    assert!(logs_contain("domestic"));
    assert!(logs_contain("weight_grams"));
    assert!(logs_contain("total_cents"));
}
