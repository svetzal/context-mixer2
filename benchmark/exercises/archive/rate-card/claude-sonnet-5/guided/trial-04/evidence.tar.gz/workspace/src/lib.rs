//! Shipping quotes for the fulfilment service.
//!
//! [`quote`] prices a [`Parcel`] against a tab-separated rate card loaded
//! from the path in the `RATECARD_PATH` environment variable. Reading that
//! environment variable and file is the only I/O this crate performs; rate
//! card parsing and price calculation are pure internal modules, tested
//! independently of any filesystem access.

mod parsing;
mod pricing;
pub mod zones;

use std::env;
use std::fmt;

/// A parcel to be quoted for shipping.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A calculated shipping quote.
#[derive(Debug, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Failure modes for [`quote`].
#[derive(Debug)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, or the file it names cannot be read.
    RateCardUnavailable,
    /// The rate card has a line that isn't three tab-separated fields, or
    /// whose numbers don't parse. `line` is 1-based and counts every line,
    /// including comments and blanks.
    MalformedRateCard { line: usize },
    /// `Parcel::zone` doesn't appear in the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel of {grams}g exceeds the {limit}g limit for its zone")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Quote shipping for `parcel` against the rate card at `RATECARD_PATH`.
///
/// # Examples
///
/// ```
/// use std::io::Write;
/// use ratecard::{quote, Parcel};
///
/// let mut file = tempfile::NamedTempFile::new().expect("temp file");
/// writeln!(file, "domestic\t500\t599").expect("write rate card");
/// std::env::set_var("RATECARD_PATH", file.path());
///
/// let parcel = Parcel { weight_grams: 200, zone: "domestic".to_string() };
/// let result = quote(&parcel).expect("quote");
/// assert_eq!(result.total_cents, 599);
/// ```
///
/// # Errors
///
/// Returns [`QuoteError`] if `RATECARD_PATH` is unset or unreadable, the
/// rate card is malformed, the zone is unknown, or the parcel is over the
/// zone's heaviest band.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "ratecard.quote",
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = tracing::field::Empty,
    );
    let _entered = span.enter();

    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let text = std::fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = parsing::parse_rate_card(&text)?;
    let result = pricing::compute_quote(&bands, parcel);

    if let Ok(quote) = &result {
        span.record("total_cents", quote.total_cents);
        tracing::info!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            total_cents = quote.total_cents,
            "quote calculated"
        );
    }

    result
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used)]
mod tests {
    use super::*;

    #[test]
    fn display_messages_are_human_readable() {
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "rate card unavailable"
        );
        assert_eq!(
            QuoteError::MalformedRateCard { line: 3 }.to_string(),
            "malformed rate card at line 3"
        );
        assert_eq!(
            QuoteError::UnknownZone("lunar".to_string()).to_string(),
            "unknown zone: lunar"
        );
        assert_eq!(
            QuoteError::Overweight {
                grams: 100,
                limit: 50
            }
            .to_string(),
            "parcel of 100g exceeds the 50g limit for its zone"
        );
    }

    #[test]
    fn quote_error_is_a_std_error() {
        fn assert_error<E: std::error::Error>() {}
        assert_error::<QuoteError>();
    }
}
