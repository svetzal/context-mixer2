//! Pure parsing of the tab-separated rate card format. No I/O here — the
//! shell in `lib.rs` reads the file and hands its contents to [`parse_rate_card`].

use crate::QuoteError;

/// One priced band for a single zone.
#[derive(Debug, Clone)]
pub(crate) struct Band {
    pub zone: String,
    pub band_max_grams: u32,
    pub cents: u64,
}

/// Parse a tab-separated rate card. Blank lines and lines starting with `#`
/// are ignored. Line numbers in errors are 1-based and count every line,
/// including the ignored ones.
pub(crate) fn parse_rate_card(text: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();

    for (index, line) in text.lines().enumerate() {
        let line_number = index + 1;

        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let zone = fields.next();
        let band_max_grams = fields.next();
        let cents = fields.next();
        let extra = fields.next();

        let (zone, band_max_grams, cents) = match (zone, band_max_grams, cents, extra) {
            (Some(zone), Some(band_max_grams), Some(cents), None) => {
                (zone, band_max_grams, cents)
            }
            _ => return Err(QuoteError::MalformedRateCard { line: line_number }),
        };

        let band_max_grams: u32 = band_max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = cents
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        bands.push(Band {
            zone: zone.to_string(),
            band_max_grams,
            cents,
        });
    }

    Ok(bands)
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used)]
mod tests {
    use super::*;

    #[test]
    fn parses_bands_ignoring_comments_and_blanks() {
        let text = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\n\ninternational\t20000\t4999\n";
        let bands = parse_rate_card(text).unwrap();

        assert_eq!(bands.len(), 2);
        assert_eq!(bands[0].zone, "domestic");
        assert_eq!(bands[0].band_max_grams, 500);
        assert_eq!(bands[0].cents, 599);
        assert_eq!(bands[1].zone, "international");
        assert_eq!(bands[1].band_max_grams, 20000);
        assert_eq!(bands[1].cents, 4999);
    }

    #[test]
    fn rejects_wrong_field_count() {
        let text = "domestic\t500\n";
        let err = parse_rate_card(text).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn rejects_extra_fields() {
        let text = "domestic\t500\t599\textra\n";
        let err = parse_rate_card(text).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn rejects_unparseable_numbers() {
        let text = "domestic\tfive-hundred\t599\n";
        let err = parse_rate_card(text).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn line_numbers_count_comments_and_blanks() {
        let text = "# header\n\ndomestic\t500\t599\ndomestic\tbad\t599\n";
        let err = parse_rate_card(text).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 4 }));
    }
}
