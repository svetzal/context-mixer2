//! Shipping quotes priced against a tab-separated rate card.
//!
//! [`quote`] reads the rate card named by the `RATECARD_PATH` environment
//! variable and prices a [`Parcel`] against it. Parsing and pricing are pure
//! (see the private `rates` module); this module is the thin imperative
//! shell that performs the environment and filesystem I/O.
//!
//! ```no_run
//! use ratecard::{quote, Parcel};
//!
//! let parcel = Parcel { weight_grams: 750, zone: "domestic".to_string() };
//! match quote(&parcel) {
//!     Ok(q) => println!("total: {} cents", q.total_cents),
//!     Err(err) => eprintln!("could not quote: {err}"),
//! }
//! ```

mod rates;
pub mod zones;

use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

/// A parcel to be quoted: its weight and the shipping zone it is going to.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A priced quote for a [`Parcel`].
#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Reasons [`quote`] can fail to produce a [`Quote`].
#[derive(Debug)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, or the file it names cannot be read.
    RateCardUnavailable,
    /// The rate card has a line that isn't three tab-separated fields, or
    /// whose numeric fields don't parse. `line` is the 1-based line number.
    MalformedRateCard { line: usize },
    /// The parcel's zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel's weight exceeds the zone's largest band.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "rate card is malformed at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weighs {grams}g, over the {limit}g limit")
            }
        }
    }
}

impl Error for QuoteError {}

/// Prices `parcel` against the rate card at `RATECARD_PATH`.
///
/// # Errors
///
/// Returns [`QuoteError::RateCardUnavailable`] if `RATECARD_PATH` is unset
/// or unreadable, [`QuoteError::MalformedRateCard`] if the card is not
/// well-formed, [`QuoteError::UnknownZone`] if `parcel.zone` has no bands,
/// and [`QuoteError::Overweight`] if `parcel.weight_grams` exceeds the
/// zone's largest band.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let bands = rates::parse(&contents)?;
    let result = rates::calculate(&bands, parcel);

    match &result {
        Ok(computed) => tracing::info!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            total_cents = computed.total_cents,
            "quote calculated"
        ),
        Err(err) => tracing::warn!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            error = %err,
            "quote failed"
        ),
    }

    result
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;

    #[test]
    fn error_display_messages_are_human_readable() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card is unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 4 }.to_string(),
            "rate card is malformed at line 4"
        );
        assert_eq!(
            QuoteError::UnknownZone("mars".to_string()).to_string(),
            "unknown zone: mars"
        );
        assert_eq!(
            QuoteError::Overweight { grams: 25_000, limit: 20_000 }.to_string(),
            "parcel weighs 25000g, over the 20000g limit"
        );
    }

    // RATECARD_PATH is process-global; serialize tests that touch it.
    static ENV_LOCK: Mutex<()> = Mutex::new(());

    #[test]
    #[tracing_test::traced_test]
    fn a_successful_quote_emits_a_queryable_diagnostic_record() {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
        let mut file = tempfile::NamedTempFile::new().expect("temp file");
        writeln!(file, "domestic\t500\t599").expect("write temp file");
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        quote(&parcel).expect("quote");

        env::remove_var("RATECARD_PATH");

        assert!(logs_contain("zone=domestic"));
        assert!(logs_contain("weight_grams=100"));
        assert!(logs_contain("total_cents=599"));
    }
}
