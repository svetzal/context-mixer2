//! Wiring tests: `quote` reading `RATECARD_PATH` and the filesystem.
//!
//! Pure pricing behaviour lives in `src/rates.rs`'s unit tests; this file
//! only exercises the environment/filesystem shell around it.

#![allow(clippy::unwrap_used, clippy::expect_used)]

use ratecard::{quote, Parcel, QuoteError};
use std::env;
use std::io::Write;
use std::sync::Mutex;

// RATECARD_PATH is process-global; serialize tests that touch it.
static ENV_LOCK: Mutex<()> = Mutex::new(());

fn with_rate_card(contents: &str, run: impl FnOnce()) {
    let _guard = ENV_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    let mut file = tempfile::NamedTempFile::new().expect("temp file");
    write!(file, "{contents}").expect("write temp file");
    env::set_var("RATECARD_PATH", file.path());
    run();
    env::remove_var("RATECARD_PATH");
}

const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn parcel(zone: &str, weight_grams: u32) -> Parcel {
    Parcel { weight_grams, zone: zone.to_string() }
}

#[test]
fn quotes_a_known_zone_from_the_configured_card() {
    with_rate_card(CARD, || {
        let quote = quote(&parcel("domestic", 100)).expect("quote");
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    });
}

#[test]
fn missing_env_var_is_rate_card_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    env::remove_var("RATECARD_PATH");
    assert!(matches!(
        quote(&parcel("domestic", 100)),
        Err(QuoteError::RateCardUnavailable)
    ));
}

#[test]
fn unreadable_path_is_rate_card_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    env::set_var("RATECARD_PATH", "/nonexistent/path/does-not-exist.tsv");
    assert!(matches!(
        quote(&parcel("domestic", 100)),
        Err(QuoteError::RateCardUnavailable)
    ));
    env::remove_var("RATECARD_PATH");
}

#[test]
fn malformed_card_propagates_line_number() {
    with_rate_card("domestic\t500\t599\ndomestic\tbad\t599\n", || {
        assert!(matches!(
            quote(&parcel("domestic", 100)),
            Err(QuoteError::MalformedRateCard { line: 2 })
        ));
    });
}

#[test]
fn unknown_zone_propagates_from_the_shell() {
    with_rate_card(CARD, || {
        let err = quote(&parcel("lunar", 100)).unwrap_err();
        assert!(matches!(err, QuoteError::UnknownZone(zone) if zone == "lunar"));
    });
}

#[test]
fn overweight_parcel_propagates_from_the_shell() {
    with_rate_card(CARD, || {
        let err = quote(&parcel("domestic", 20_001)).unwrap_err();
        assert!(matches!(
            err,
            QuoteError::Overweight { grams: 20_001, limit: 20_000 }
        ));
    });
}
