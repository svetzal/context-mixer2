//! Pure rate-card parsing and quote calculation.
//!
//! Nothing in this module touches the filesystem or the environment: it
//! takes rate-card text and a [`Parcel`] and returns a [`Quote`] or a
//! [`QuoteError`]. That keeps the pricing policy testable without any I/O.

use crate::{Parcel, Quote, QuoteError};

#[derive(Debug)]
pub(crate) struct Band {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

/// Parses tab-separated rate-card text into bands.
///
/// Blank lines and lines starting with `#` are ignored. Every other line
/// must be exactly three tab-separated fields: zone, band max grams, cents.
pub(crate) fn parse(contents: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();
    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        let [zone, band_max_grams, cents] = fields[..] else {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        };

        let band_max_grams: u32 = band_max_grams
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = cents
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        bands.push(Band {
            zone: zone.trim().to_string(),
            band_max_grams,
            cents,
        });
    }
    Ok(bands)
}

/// Calculates a quote for `parcel` against already-parsed `bands`.
pub(crate) fn calculate(bands: &[Band], parcel: &Parcel) -> Result<Quote, QuoteError> {
    let mut zone_bands: Vec<&Band> = bands.iter().filter(|band| band.zone == parcel.zone).collect();
    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }
    zone_bands.sort_by_key(|band| band.band_max_grams);

    let matched = zone_bands
        .iter()
        .find(|band| band.band_max_grams >= parcel.weight_grams);
    let Some(band) = matched else {
        // Safe: zone_bands is non-empty, so it has a last element.
        let limit = zone_bands[zone_bands.len() - 1].band_max_grams;
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        });
    };

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += round_half_up_20_percent(base_cents);
    }

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.band_max_grams,
    })
}

/// 20% of `base_cents`, rounded half-up to the nearest whole cent.
fn round_half_up_20_percent(base_cents: u64) -> u64 {
    (base_cents * 20 + 50) / 100
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used)]
mod tests {
    use super::*;

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn parcel(zone: &str, weight_grams: u32) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn ignores_comments_and_blank_lines() {
        let bands = parse("\n# comment\ndomestic\t500\t599\n\n").expect("parses");
        assert_eq!(bands.len(), 1);
    }

    #[test]
    fn picks_first_band_at_or_above_weight() {
        let bands = parse(CARD).expect("parses");
        let quote = calculate(&bands, &parcel("domestic", 500)).expect("quote");
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);

        let quote = calculate(&bands, &parcel("domestic", 501)).expect("quote");
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn adds_heavy_parcel_surcharge_above_10000_grams() {
        let bands = parse(CARD).expect("parses");
        let quote = calculate(&bands, &parcel("domestic", 10_000)).expect("quote");
        assert_eq!(quote.surcharge_cents, 0);

        let quote = calculate(&bands, &parcel("domestic", 10_001)).expect("quote");
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, quote.base_cents + 500);
    }

    #[test]
    fn adds_international_surcharge_rounded_half_up() {
        let bands = parse(CARD).expect("parses");
        let quote = calculate(&bands, &parcel("international", 500)).expect("quote");
        // 1499 * 0.2 = 299.8 -> rounds up to 300
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1499 + 300);
    }

    #[test]
    fn combines_heavy_and_international_surcharges() {
        let bands = parse(CARD).expect("parses");
        let quote = calculate(&bands, &parcel("international", 15_000)).expect("quote");
        // base 4999, +500 heavy, +20% of 4999 rounded half-up = 1000
        assert_eq!(quote.surcharge_cents, 500 + 1000);
        assert_eq!(quote.total_cents, 4999 + 500 + 1000);
    }

    #[test]
    fn unknown_zone_is_rejected() {
        let bands = parse(CARD).expect("parses");
        let err = calculate(&bands, &parcel("lunar", 100)).unwrap_err();
        assert!(matches!(err, QuoteError::UnknownZone(zone) if zone == "lunar"));
    }

    #[test]
    fn overweight_parcel_is_rejected() {
        let bands = parse(CARD).expect("parses");
        let err = calculate(&bands, &parcel("domestic", 20_001)).unwrap_err();
        assert!(matches!(
            err,
            QuoteError::Overweight { grams: 20_001, limit: 20_000 }
        ));
    }

    #[test]
    fn malformed_line_reports_its_line_number() {
        let err = parse("domestic\t500\t599\ndomestic\tnot-a-number\t599\n").unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 2 }));
    }

    #[test]
    fn wrong_field_count_is_malformed() {
        let err = parse("# header\ndomestic\t500\n").unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 2 }));
    }

    #[test]
    fn line_numbers_count_comments_and_blanks() {
        let err = parse("# comment\n\ndomestic\t500\n").unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 3 }));
    }
}
