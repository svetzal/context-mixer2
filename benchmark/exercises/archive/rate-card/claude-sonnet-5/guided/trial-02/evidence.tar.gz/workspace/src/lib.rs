//! Shipping quotes for the fulfilment service.
//!
//! Warehouse operators price outbound parcels against a rate card that
//! operations maintains and redeploys without a code change. [`quote`] reads
//! that card from the path in the `RATECARD_PATH` environment variable and
//! turns a [`Parcel`] into a [`Quote`].

mod rate_card;
pub mod zones;

use std::env;
use std::fmt;
use std::fs;

use rate_card::{compute_quote, parse_rate_card};

/// A parcel awaiting a shipping quote.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A priced quote for a [`Parcel`].
#[derive(Debug, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Reasons [`quote`] cannot produce a [`Quote`].
#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, or the file it names cannot be read.
    RateCardUnavailable,
    /// The rate card has a line that isn't three tab-separated fields, or
    /// whose numeric fields don't parse. `line` is the 1-based line number.
    MalformedRateCard { line: usize },
    /// The parcel's zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel's weight exceeds every band for its zone. `limit` is that
    /// zone's largest `band_max_grams`.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card is unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "rate card is malformed at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weighs {grams}g, which exceeds the {limit}g limit")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Quotes shipping for `parcel` against the rate card at `RATECARD_PATH`.
///
/// # Errors
///
/// Returns [`QuoteError::RateCardUnavailable`] if `RATECARD_PATH` is unset or
/// the file it names can't be read, [`QuoteError::MalformedRateCard`] if the
/// card can't be parsed, [`QuoteError::UnknownZone`] if `parcel.zone` has no
/// bands, and [`QuoteError::Overweight`] if `parcel.weight_grams` exceeds
/// every band for its zone.
///
/// ```
/// use std::io::Write;
///
/// let mut file = tempfile::NamedTempFile::new().unwrap();
/// writeln!(file, "domestic\t500\t599").unwrap();
/// writeln!(file, "domestic\t20000\t1799").unwrap();
/// std::env::set_var("RATECARD_PATH", file.path());
///
/// let parcel = ratecard::Parcel { weight_grams: 250, zone: "domestic".to_string() };
/// let quote = ratecard::quote(&parcel).unwrap();
///
/// assert_eq!(quote.base_cents, 599);
/// assert_eq!(quote.total_cents, 599);
/// ```
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let bands = parse_rate_card(&contents)?;
    let quote = compute_quote(&bands, parcel)?;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = quote.total_cents,
        "quoted shipping"
    );

    Ok(quote)
}
