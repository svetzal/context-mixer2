//! Pure parsing and pricing logic. Nothing in this module touches the
//! filesystem or the environment, so it can be tested without I/O.

use crate::{Parcel, Quote, QuoteError};

/// One band of a zone's rate table: the parcel qualifies for it when its
/// weight is at or below `band_max_grams`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct Band {
    pub zone: String,
    pub band_max_grams: u32,
    pub cents: u64,
}

/// Parses a tab-separated rate card. Blank lines and lines starting with `#`
/// are skipped. Every other line must be exactly `zone\tband_max_grams\tcents`
/// with the numeric fields parseable, or the whole card is rejected.
pub(crate) fn parse_rate_card(contents: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        let [zone, band_max_grams, cents] = fields.as_slice() else {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        };

        let band_max_grams: u32 = band_max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = cents
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        bands.push(Band {
            zone: (*zone).to_string(),
            band_max_grams,
            cents,
        });
    }

    Ok(bands)
}

/// Prices a parcel against already-parsed bands.
pub(crate) fn compute_quote(bands: &[Band], parcel: &Parcel) -> Result<Quote, QuoteError> {
    let zone_bands: Vec<&Band> = bands.iter().filter(|band| band.zone == parcel.zone).collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let matching = zone_bands
        .iter()
        .filter(|band| band.band_max_grams >= parcel.weight_grams)
        .min_by_key(|band| band.band_max_grams);

    let Some(band) = matching else {
        let limit = zone_bands
            .iter()
            .map(|band| band.band_max_grams)
            .max()
            .unwrap_or(0);
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        });
    };

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    #![allow(clippy::unwrap_used, clippy::expect_used)]

    use super::*;

    fn sample_card() -> &'static str {
        "# zone\tband_max_grams\tcents\n\
         domestic\t500\t599\n\
         domestic\t2000\t899\n\
         domestic\t20000\t1799\n\
         international\t500\t1499\n\
         international\t20000\t4999\n"
    }

    #[test]
    fn parses_bands_and_skips_comments_and_blanks() {
        let bands = parse_rate_card(sample_card()).unwrap();
        assert_eq!(bands.len(), 5);
        assert_eq!(
            bands[0],
            Band {
                zone: "domestic".to_string(),
                band_max_grams: 500,
                cents: 599,
            }
        );
    }

    #[test]
    fn rejects_line_with_wrong_field_count() {
        let contents = "domestic\t500\n";
        let err = parse_rate_card(contents).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn rejects_unparseable_number_and_reports_1_based_line() {
        let contents = "# header\ndomestic\tfive-hundred\t599\n";
        let err = parse_rate_card(contents).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 2 }));
    }

    #[test]
    fn picks_smallest_band_at_or_above_weight() {
        let bands = parse_rate_card(sample_card()).unwrap();
        let parcel = Parcel {
            weight_grams: 600,
            zone: "domestic".to_string(),
        };
        let quote = compute_quote(&bands, &parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
    }

    #[test]
    fn boundary_weight_matches_that_bands_max() {
        let bands = parse_rate_card(sample_card()).unwrap();
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let quote = compute_quote(&bands, &parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn heavy_domestic_parcel_gets_weight_surcharge() {
        let bands = parse_rate_card(sample_card()).unwrap();
        let parcel = Parcel {
            weight_grams: 10_001,
            zone: "domestic".to_string(),
        };
        let quote = compute_quote(&bands, &parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn weight_at_exactly_10000_grams_has_no_surcharge() {
        let bands = parse_rate_card(sample_card()).unwrap();
        let parcel = Parcel {
            weight_grams: 10_000,
            zone: "domestic".to_string(),
        };
        let quote = compute_quote(&bands, &parcel).unwrap();
        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn international_gets_20_percent_surcharge_rounded_half_up() {
        let bands = parse_rate_card(sample_card()).unwrap();
        let parcel = Parcel {
            weight_grams: 500,
            zone: "international".to_string(),
        };
        let quote = compute_quote(&bands, &parcel).unwrap();
        // 1499 * 0.2 = 299.8 -> rounds to 300
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn heavy_international_parcel_stacks_both_surcharges() {
        let bands = parse_rate_card(sample_card()).unwrap();
        let parcel = Parcel {
            weight_grams: 10_001,
            zone: "international".to_string(),
        };
        let quote = compute_quote(&bands, &parcel).unwrap();
        // 4999 * 0.2 = 999.8 -> rounds to 1000, plus 500 weight surcharge
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_is_reported_with_the_requested_zone() {
        let bands = parse_rate_card(sample_card()).unwrap();
        let parcel = Parcel {
            weight_grams: 100,
            zone: "lunar".to_string(),
        };
        let err = compute_quote(&bands, &parcel).unwrap_err();
        assert!(matches!(err, QuoteError::UnknownZone(zone) if zone == "lunar"));
    }

    #[test]
    fn overweight_reports_the_zones_largest_band() {
        let bands = parse_rate_card(sample_card()).unwrap();
        let parcel = Parcel {
            weight_grams: 20_001,
            zone: "domestic".to_string(),
        };
        let err = compute_quote(&bands, &parcel).unwrap_err();
        assert!(matches!(
            err,
            QuoteError::Overweight { grams: 20_001, limit: 20_000 }
        ));
    }
}
