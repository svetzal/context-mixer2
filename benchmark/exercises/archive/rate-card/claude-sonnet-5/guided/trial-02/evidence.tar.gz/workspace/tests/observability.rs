//! Verifies that a successful quote emits a diagnostic record carrying the
//! zone, weight, and total, as required for operating this service.

#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

mod common;

use ratecard::Parcel;

const SAMPLE_CARD: &str = "domestic\t500\t599\n";

#[tracing_test::traced_test]
#[test]
fn quoting_emits_zone_weight_and_total() {
    let _guard = common::lock_env();
    let _card = common::set_rate_card(SAMPLE_CARD);

    let parcel = Parcel {
        weight_grams: 250,
        zone: "domestic".to_string(),
    };
    let quote = ratecard::quote(&parcel).expect("quote succeeds");

    assert!(logs_contain("zone=domestic"));
    assert!(logs_contain("weight_grams=250"));
    assert!(logs_contain(&format!("total_cents={}", quote.total_cents)));

    std::env::remove_var("RATECARD_PATH");
}
