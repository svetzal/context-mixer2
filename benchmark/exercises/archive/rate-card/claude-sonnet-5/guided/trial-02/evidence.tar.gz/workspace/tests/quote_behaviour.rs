//! Wiring tests: env var lookup, file reading, and the full parse-then-price
//! round trip through the public `quote` entry point. Pure pricing rules are
//! covered by the crate's inline unit tests.

#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

mod common;

use ratecard::{Parcel, QuoteError};

const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

#[test]
fn quotes_a_domestic_parcel_end_to_end() {
    let _guard = common::lock_env();
    let _card = common::set_rate_card(SAMPLE_CARD);

    let parcel = Parcel {
        weight_grams: 250,
        zone: "domestic".to_string(),
    };
    let quote = ratecard::quote(&parcel).expect("quote succeeds");

    assert_eq!(quote.base_cents, 599);
    assert_eq!(quote.surcharge_cents, 0);
    assert_eq!(quote.total_cents, 599);
    assert_eq!(quote.band_max_grams, 500);

    std::env::remove_var("RATECARD_PATH");
}

#[test]
fn missing_env_var_is_rate_card_unavailable() {
    let _guard = common::lock_env();
    std::env::remove_var("RATECARD_PATH");

    let parcel = Parcel {
        weight_grams: 250,
        zone: "domestic".to_string(),
    };
    let err = ratecard::quote(&parcel).expect_err("no env var set");

    assert!(matches!(err, QuoteError::RateCardUnavailable));
}

#[test]
fn unreadable_path_is_rate_card_unavailable() {
    let _guard = common::lock_env();
    std::env::set_var("RATECARD_PATH", "/nonexistent/path/does-not-exist.tsv");

    let parcel = Parcel {
        weight_grams: 250,
        zone: "domestic".to_string(),
    };
    let err = ratecard::quote(&parcel).expect_err("path does not exist");

    assert!(matches!(err, QuoteError::RateCardUnavailable));

    std::env::remove_var("RATECARD_PATH");
}

#[test]
fn malformed_line_reports_1_based_number_counting_comments_and_blanks() {
    let _guard = common::lock_env();
    let contents = "# header\n\n\
                     domestic\t500\t599\n\
                     domestic\tnot-a-number\t899\n";
    let _card = common::set_rate_card(contents);

    let parcel = Parcel {
        weight_grams: 250,
        zone: "domestic".to_string(),
    };
    let err = ratecard::quote(&parcel).expect_err("card is malformed");

    assert!(matches!(err, QuoteError::MalformedRateCard { line: 4 }));

    std::env::remove_var("RATECARD_PATH");
}

#[test]
fn unknown_zone_carries_the_requested_zone() {
    let _guard = common::lock_env();
    let _card = common::set_rate_card(SAMPLE_CARD);

    let parcel = Parcel {
        weight_grams: 100,
        zone: "lunar".to_string(),
    };
    let err = ratecard::quote(&parcel).expect_err("zone is unknown");

    match err {
        QuoteError::UnknownZone(zone) => assert_eq!(zone, "lunar"),
        other => panic!("expected UnknownZone, got {other:?}"),
    }

    std::env::remove_var("RATECARD_PATH");
}

#[test]
fn overweight_carries_the_zones_largest_band() {
    let _guard = common::lock_env();
    let _card = common::set_rate_card(SAMPLE_CARD);

    let parcel = Parcel {
        weight_grams: 20_001,
        zone: "international".to_string(),
    };
    let err = ratecard::quote(&parcel).expect_err("parcel is overweight");

    assert!(matches!(
        err,
        QuoteError::Overweight {
            grams: 20_001,
            limit: 20_000
        }
    ));

    std::env::remove_var("RATECARD_PATH");
}

#[test]
fn international_surcharge_stacks_with_weight_surcharge() {
    let _guard = common::lock_env();
    let _card = common::set_rate_card(SAMPLE_CARD);

    let parcel = Parcel {
        weight_grams: 15_000,
        zone: "international".to_string(),
    };
    let quote = ratecard::quote(&parcel).expect("quote succeeds");

    // base 4999, +20% (999.8 -> 1000) international, +500 weight surcharge
    assert_eq!(quote.base_cents, 4999);
    assert_eq!(quote.surcharge_cents, 1500);
    assert_eq!(quote.total_cents, 6499);

    std::env::remove_var("RATECARD_PATH");
}

#[test]
fn errors_implement_display_and_std_error() {
    fn assert_error<E: std::error::Error>(_: &E) {}
    let err = QuoteError::UnknownZone("mars".to_string());
    assert_error(&err);
    assert_eq!(err.to_string(), "unknown zone: mars");
}
