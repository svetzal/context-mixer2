//! Shared test support. `RATECARD_PATH` is process-wide state, so tests that
//! touch it must hold [`lock_env`] for the duration of the mutation.

#![allow(clippy::unwrap_used, clippy::expect_used)]

use std::io::Write;
use std::sync::{Mutex, MutexGuard, PoisonError};

pub static ENV_LOCK: Mutex<()> = Mutex::new(());

pub fn lock_env() -> MutexGuard<'static, ()> {
    ENV_LOCK.lock().unwrap_or_else(PoisonError::into_inner)
}

/// Writes `contents` to a fresh temp file and points `RATECARD_PATH` at it.
/// The returned handle must stay alive for as long as the path is in use.
pub fn set_rate_card(contents: &str) -> tempfile::NamedTempFile {
    let mut file = tempfile::NamedTempFile::new().expect("create temp rate card");
    file.write_all(contents.as_bytes())
        .expect("write temp rate card");
    std::env::set_var("RATECARD_PATH", file.path());
    file
}
