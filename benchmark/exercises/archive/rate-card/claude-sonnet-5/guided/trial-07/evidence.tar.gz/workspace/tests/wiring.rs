//! Cross-module wiring tests: these exercise the real `RATECARD_PATH`
//! environment variable and real filesystem reads, proving the public
//! `quote` entry point is wired to its I/O correctly. Pure parsing and
//! pricing behaviour is covered by unit tests inside the crate instead.

use std::io::Write;
use std::sync::Mutex;

use ratecard::{quote, Parcel, QuoteError};

// `RATECARD_PATH` is process-global state; serialize the tests in this
// binary so they don't race each other across threads.
static ENV_LOCK: Mutex<()> = Mutex::new(());

const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

#[test]
fn quotes_a_parcel_end_to_end() {
    let _guard = ENV_LOCK.lock().unwrap();
    let mut file = tempfile::NamedTempFile::new().unwrap();
    write!(file, "{SAMPLE_CARD}").unwrap();
    std::env::set_var("RATECARD_PATH", file.path());

    let parcel = Parcel { weight_grams: 15000, zone: "international".to_string() };
    let result = quote(&parcel).unwrap();

    assert_eq!(result.base_cents, 4999);
    assert_eq!(result.surcharge_cents, 1500);
    assert_eq!(result.total_cents, 6499);
    assert_eq!(result.band_max_grams, 20000);

    std::env::remove_var("RATECARD_PATH");
}

#[test]
fn missing_env_var_is_rate_card_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap();
    std::env::remove_var("RATECARD_PATH");

    let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
    let err = quote(&parcel).unwrap_err();

    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn unreadable_path_is_rate_card_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap();
    std::env::set_var("RATECARD_PATH", "/nonexistent/path/does-not-exist.tsv");

    let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
    let err = quote(&parcel).unwrap_err();

    assert_eq!(err, QuoteError::RateCardUnavailable);

    std::env::remove_var("RATECARD_PATH");
}
