//! The I/O boundary: a gateway trait for loading rate card text, and the
//! thin real adapter that reads it from `RATECARD_PATH`. Core logic depends
//! only on [`RateCardSource`], never on `std::env` or `std::fs` directly.

use std::env;
use std::fs;

use crate::QuoteError;

pub(crate) trait RateCardSource {
    fn load(&self) -> Result<String, QuoteError>;
}

pub(crate) struct EnvFileRateCardSource;

impl RateCardSource for EnvFileRateCardSource {
    fn load(&self) -> Result<String, QuoteError> {
        let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
        fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}
