//! Shipping quotes priced against an operator-maintained rate card.
//!
//! [`quote`] reads a tab-separated rate card from the path in the
//! `RATECARD_PATH` environment variable and prices a [`Parcel`] against it.
//! Parsing and pricing are pure; reading the card from disk is the only
//! side effect, isolated behind an internal gateway trait.
//!
//! # Examples
//!
//! ```
//! use std::io::Write;
//!
//! let mut file = tempfile::NamedTempFile::new().unwrap();
//! writeln!(file, "domestic\t500\t599").unwrap();
//! std::env::set_var("RATECARD_PATH", file.path());
//!
//! let parcel = ratecard::Parcel { weight_grams: 100, zone: "domestic".to_string() };
//! let quote = ratecard::quote(&parcel).unwrap();
//! assert_eq!(quote.total_cents, 599);
//! ```

mod parsing;
mod pricing;
mod source;
pub mod zones;

use source::{EnvFileRateCardSource, RateCardSource};

/// A parcel to be quoted: its weight and the shipping zone it's headed to.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A priced quote for a [`Parcel`].
#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// The ways a [`quote`] request can fail.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, or the file it names can't be read.
    RateCardUnavailable,
    /// The rate card has a line that isn't valid, at this 1-based line number.
    MalformedRateCard { line: usize },
    /// The parcel's zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel of {grams}g exceeds the {limit}g limit for its zone")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Quotes a parcel against the rate card at `RATECARD_PATH`.
///
/// See the [module-level docs](crate) for behaviour details.
#[tracing::instrument(skip(parcel), fields(zone = %parcel.zone, weight_grams = parcel.weight_grams))]
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let result = quote_from_source(parcel, &EnvFileRateCardSource);
    if let Ok(ref quote) = result {
        tracing::info!(total_cents = quote.total_cents, "quote computed");
    }
    result
}

fn quote_from_source(parcel: &Parcel, source: &dyn RateCardSource) -> Result<Quote, QuoteError> {
    let contents = source.load()?;
    let card = parsing::parse_rate_card(&contents)?;
    pricing::price(parcel, &card)
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    struct InMemoryRateCardSource {
        contents: Result<String, QuoteError>,
    }

    impl RateCardSource for InMemoryRateCardSource {
        fn load(&self) -> Result<String, QuoteError> {
            self.contents.clone()
        }
    }

    fn source(contents: &str) -> InMemoryRateCardSource {
        InMemoryRateCardSource { contents: Ok(contents.to_string()) }
    }

    #[test]
    fn quotes_a_domestic_parcel() {
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let quote = quote_from_source(&parcel, &source(SAMPLE_CARD)).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn unknown_zone_surfaces_as_an_error() {
        let parcel = Parcel { weight_grams: 100, zone: "lunar".to_string() };
        let err = quote_from_source(&parcel, &source(SAMPLE_CARD)).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".to_string()));
    }

    #[test]
    fn unreadable_source_surfaces_as_rate_card_unavailable() {
        let unavailable = InMemoryRateCardSource { contents: Err(QuoteError::RateCardUnavailable) };
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let err = quote_from_source(&parcel, &unavailable).unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn malformed_card_surfaces_its_line_number() {
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let err = quote_from_source(&parcel, &source("domestic\t500\n")).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn error_messages_are_human_readable() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 3 }.to_string(),
            "malformed rate card at line 3"
        );
        assert_eq!(
            QuoteError::UnknownZone("lunar".to_string()).to_string(),
            "unknown zone: lunar"
        );
        assert_eq!(
            QuoteError::Overweight { grams: 30000, limit: 20000 }.to_string(),
            "parcel of 30000g exceeds the 20000g limit for its zone"
        );
    }
}
