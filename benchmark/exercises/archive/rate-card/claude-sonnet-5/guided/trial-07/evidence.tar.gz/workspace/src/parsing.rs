//! Pure parsing of the tab-separated rate card text format. No I/O here —
//! callers supply the file contents and get back structured bands or a
//! [`QuoteError`] naming the offending line.

use std::collections::HashMap;

use crate::QuoteError;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct RateBand {
    pub(crate) max_grams: u32,
    pub(crate) cents: u64,
}

pub(crate) type RateCard = HashMap<String, Vec<RateBand>>;

/// Parses tab-separated `zone\tband_max_grams\tcents` lines into bands per
/// zone, sorted ascending by `band_max_grams`. Blank lines and lines
/// starting with `#` are ignored. Any other line that isn't exactly three
/// tab-separated fields, or whose numeric fields don't parse, is reported
/// as [`QuoteError::MalformedRateCard`] carrying its 1-based line number.
pub(crate) fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut card: RateCard = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let [zone, max_grams, cents] = [fields[0], fields[1], fields[2]];

        let max_grams: u32 = max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = cents
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        card.entry(zone.to_string())
            .or_default()
            .push(RateBand { max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(card)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ignores_blank_and_comment_lines() {
        let card = parse_rate_card("# a comment\n\ndomestic\t500\t599\n").unwrap();
        assert_eq!(
            card.get("domestic"),
            Some(&vec![RateBand { max_grams: 500, cents: 599 }])
        );
    }

    #[test]
    fn sorts_bands_ascending_by_max_grams() {
        let card = parse_rate_card("domestic\t2000\t899\ndomestic\t500\t599\n").unwrap();
        assert_eq!(
            card["domestic"],
            vec![
                RateBand { max_grams: 500, cents: 599 },
                RateBand { max_grams: 2000, cents: 899 },
            ]
        );
    }

    #[test]
    fn groups_multiple_zones_independently() {
        let card = parse_rate_card("domestic\t500\t599\ninternational\t500\t1499\n").unwrap();
        assert_eq!(card.len(), 2);
        assert!(card.contains_key("domestic"));
        assert!(card.contains_key("international"));
    }

    #[test]
    fn wrong_field_count_is_malformed() {
        let err = parse_rate_card("domestic\t500\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn non_numeric_field_is_malformed() {
        let err = parse_rate_card("domestic\theavy\t599\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn line_number_counts_comments_and_blanks() {
        let contents = "# header\n\ndomestic\t500\n";
        let err = parse_rate_card(contents).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }
}
