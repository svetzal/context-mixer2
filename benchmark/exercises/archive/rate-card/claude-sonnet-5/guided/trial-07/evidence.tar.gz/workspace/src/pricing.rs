//! Pure pricing: turns a parsed [`RateCard`] and a [`Parcel`] into a
//! [`Quote`]. No I/O here — parsing and reading the rate card happen
//! elsewhere.

use crate::parsing::RateCard;
use crate::{Parcel, Quote, QuoteError};

const OVERWEIGHT_SURCHARGE_THRESHOLD_GRAMS: u32 = 10_000;
const OVERWEIGHT_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

pub(crate) fn price(parcel: &Parcel, card: &RateCard) -> Result<Quote, QuoteError> {
    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: bands.last().map_or(0, |band| band.max_grams),
        })?;

    let mut surcharge_cents = 0u64;
    if parcel.weight_grams > OVERWEIGHT_SURCHARGE_THRESHOLD_GRAMS {
        surcharge_cents += OVERWEIGHT_SURCHARGE_CENTS;
    }
    if parcel.zone == INTERNATIONAL_ZONE {
        // Half-up rounding of an integer percentage: add half the divisor
        // before truncating integer division.
        surcharge_cents += (band.cents * INTERNATIONAL_SURCHARGE_PERCENT + 50) / 100;
    }

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use std::collections::HashMap;

    use super::*;
    use crate::parsing::RateBand;

    fn card() -> RateCard {
        let mut card = HashMap::new();
        card.insert(
            "domestic".to_string(),
            vec![
                RateBand { max_grams: 500, cents: 599 },
                RateBand { max_grams: 2000, cents: 899 },
                RateBand { max_grams: 20000, cents: 1799 },
            ],
        );
        card.insert(
            "international".to_string(),
            vec![
                RateBand { max_grams: 500, cents: 1499 },
                RateBand { max_grams: 20000, cents: 4999 },
            ],
        );
        card
    }

    #[test]
    fn picks_the_first_band_at_or_above_the_weight() {
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let quote = price(&parcel, &card()).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn weight_exactly_on_a_band_boundary_matches_that_band() {
        let parcel = Parcel { weight_grams: 500, zone: "domestic".to_string() };
        let quote = price(&parcel, &card()).unwrap();
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn weight_just_above_a_boundary_moves_to_the_next_band() {
        let parcel = Parcel { weight_grams: 501, zone: "domestic".to_string() };
        let quote = price(&parcel, &card()).unwrap();
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn no_surcharge_under_threshold_and_domestic() {
        let parcel = Parcel { weight_grams: 1000, zone: "domestic".to_string() };
        let quote = price(&parcel, &card()).unwrap();
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, quote.base_cents);
    }

    #[test]
    fn overweight_parcel_adds_flat_surcharge() {
        let parcel = Parcel { weight_grams: 15000, zone: "domestic".to_string() };
        let quote = price(&parcel, &card()).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn international_zone_adds_percentage_surcharge_rounded_half_up() {
        let parcel = Parcel { weight_grams: 400, zone: "international".to_string() };
        let quote = price(&parcel, &card()).unwrap();
        // 1499 * 0.20 = 299.8 -> rounds to 300
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn combines_weight_and_international_surcharges() {
        let parcel = Parcel { weight_grams: 15000, zone: "international".to_string() };
        let quote = price(&parcel, &card()).unwrap();
        // 4999 * 0.20 = 999.8 -> rounds to 1000, plus 500 flat
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_is_reported_with_the_requested_zone() {
        let parcel = Parcel { weight_grams: 100, zone: "lunar".to_string() };
        let err = price(&parcel, &card()).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".to_string()));
    }

    #[test]
    fn overweight_parcel_is_reported_with_the_zones_largest_band() {
        let parcel = Parcel { weight_grams: 25000, zone: "domestic".to_string() };
        let err = price(&parcel, &card()).unwrap_err();
        assert_eq!(err, QuoteError::Overweight { grams: 25000, limit: 20000 });
    }
}
