use std::collections::HashMap;

use crate::model::QuoteError;

/// One pricing band for a zone: parcels up to `band_max_grams` cost `cents`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct Band {
    pub(crate) band_max_grams: u32,
    pub(crate) cents: u64,
}

/// A parsed rate card, grouped by zone.
#[derive(Debug, Default, PartialEq, Eq)]
pub(crate) struct RateCard {
    zones: HashMap<String, Vec<Band>>,
}

impl RateCard {
    pub(crate) fn bands_for(&self, zone: &str) -> Option<&[Band]> {
        self.zones.get(zone).map(Vec::as_slice)
    }
}

/// Parses a tab-separated rate card. Blank lines and lines starting with `#`
/// are ignored; every other line must be `zone\tband_max_grams\tcents`.
pub(crate) fn parse(contents: &str) -> Result<RateCard, QuoteError> {
    let mut card = RateCard::default();

    for (index, raw_line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let line = raw_line.trim_end_matches('\r');

        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        let [zone, band_max_grams, cents] = fields.as_slice() else {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        };

        let band_max_grams: u32 = band_max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 =
            cents.parse().map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        card.zones.entry((*zone).to_owned()).or_default().push(Band {
            band_max_grams,
            cents,
        });
    }

    Ok(card)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ignores_blank_lines_and_comments() {
        let card = parse("# header\n\ndomestic\t500\t599\n").unwrap();
        assert_eq!(
            card.bands_for("domestic"),
            Some(
                [Band {
                    band_max_grams: 500,
                    cents: 599
                }]
                .as_slice()
            )
        );
    }

    #[test]
    fn groups_multiple_bands_per_zone() {
        let card = parse("domestic\t500\t599\ndomestic\t2000\t899\n").unwrap();
        assert_eq!(card.bands_for("domestic").unwrap().len(), 2);
    }

    #[test]
    fn unknown_zone_has_no_bands() {
        let card = parse("domestic\t500\t599\n").unwrap();
        assert_eq!(card.bands_for("international"), None);
    }

    #[test]
    fn rejects_line_with_wrong_field_count() {
        let err = parse("domestic\t500\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn rejects_unparseable_band_max_grams() {
        let err = parse("domestic\tabc\t599\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn rejects_unparseable_cents() {
        let err = parse("domestic\t500\txyz\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn reports_1_based_line_number_counting_comments_and_blanks() {
        let err = parse("# header\n\ndomestic\t500\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }
}
