//! Wiring tests: exercise the public `quote` function end to end, through a
//! real `RATECARD_PATH` environment variable and a real file on disk.

#![allow(clippy::unwrap_used, clippy::expect_used)]

use std::io::Write;
use std::sync::Mutex;

use ratecard::{Parcel, QuoteError};
use tempfile::NamedTempFile;

// `RATECARD_PATH` is process-global state; serialize the tests in this file
// so they don't race each other on separate threads.
static ENV_LOCK: Mutex<()> = Mutex::new(());

fn with_rate_card<R>(contents: &str, run: impl FnOnce() -> R) -> R {
    let _guard = ENV_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    let mut file = NamedTempFile::new().expect("create temp rate card");
    write!(file, "{contents}").expect("write temp rate card");
    std::env::set_var("RATECARD_PATH", file.path());
    let result = run();
    std::env::remove_var("RATECARD_PATH");
    result
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_owned(),
    }
}

const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

#[test]
fn domestic_parcel_within_first_band() {
    let quote = with_rate_card(SAMPLE_CARD, || ratecard::quote(&parcel(500, "domestic")))
        .expect("quote should succeed");
    assert_eq!(quote.base_cents, 599);
    assert_eq!(quote.surcharge_cents, 0);
    assert_eq!(quote.total_cents, 599);
    assert_eq!(quote.band_max_grams, 500);
}

#[test]
fn heavy_domestic_parcel_gets_flat_surcharge() {
    let quote = with_rate_card(SAMPLE_CARD, || ratecard::quote(&parcel(10001, "domestic")))
        .expect("quote should succeed");
    assert_eq!(quote.base_cents, 1799);
    assert_eq!(quote.surcharge_cents, 500);
    assert_eq!(quote.total_cents, 2299);
}

#[test]
fn international_parcel_gets_percentage_surcharge() {
    let quote = with_rate_card(SAMPLE_CARD, || ratecard::quote(&parcel(500, "international")))
        .expect("quote should succeed");
    assert_eq!(quote.base_cents, 1499);
    assert_eq!(quote.surcharge_cents, 300); // 1499 * 0.2 = 299.8 -> 300
    assert_eq!(quote.total_cents, 1799);
}

#[test]
fn unknown_zone_is_reported() {
    let err = with_rate_card(SAMPLE_CARD, || ratecard::quote(&parcel(100, "lunar")))
        .expect_err("unknown zone should fail");
    assert_eq!(err, QuoteError::UnknownZone("lunar".to_owned()));
}

#[test]
fn overweight_parcel_is_reported_with_zone_limit() {
    let err = with_rate_card(SAMPLE_CARD, || ratecard::quote(&parcel(20001, "domestic")))
        .expect_err("overweight parcel should fail");
    assert_eq!(
        err,
        QuoteError::Overweight {
            grams: 20001,
            limit: 20000
        }
    );
}

#[test]
fn malformed_rate_card_reports_1_based_line_number() {
    let bad_card = "# header\n\ndomestic\t500\n";
    let err = with_rate_card(bad_card, || ratecard::quote(&parcel(100, "domestic")))
        .expect_err("malformed rate card should fail");
    assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
}

#[test]
fn missing_ratecard_path_is_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    std::env::remove_var("RATECARD_PATH");
    let err = ratecard::quote(&parcel(100, "domestic")).expect_err("should be unavailable");
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn unreadable_ratecard_path_is_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    std::env::set_var("RATECARD_PATH", "/nonexistent/path/does/not/exist");
    let err = ratecard::quote(&parcel(100, "domestic")).expect_err("should be unavailable");
    assert_eq!(err, QuoteError::RateCardUnavailable);
    std::env::remove_var("RATECARD_PATH");
}

#[test]
fn quote_error_implements_display_and_error() {
    fn assert_error<E: std::error::Error>() {}
    assert_error::<QuoteError>();

    let displayed = format!("{}", QuoteError::UnknownZone("mars".to_owned()));
    assert!(displayed.contains("mars"));
}
