//! Shipping quotes for the fulfilment service.
//!
//! [`quote`] turns a [`Parcel`] into a [`Quote`] by reading a tab-separated
//! rate card from the path named by the `RATECARD_PATH` environment
//! variable.

#![cfg_attr(test, allow(clippy::unwrap_used, clippy::expect_used))]

mod calc;
mod gateway;
mod model;
mod parser;
pub mod zones;

pub use model::{Parcel, Quote, QuoteError};

use gateway::{EnvFileSource, RateCardSource};

/// Quotes a parcel against the rate card at `RATECARD_PATH`.
///
/// ```
/// use std::io::Write;
///
/// let mut file = tempfile::NamedTempFile::new().unwrap();
/// writeln!(file, "domestic\t500\t599").unwrap();
/// std::env::set_var("RATECARD_PATH", file.path());
///
/// let parcel = ratecard::Parcel { weight_grams: 400, zone: "domestic".into() };
/// let quote = ratecard::quote(&parcel).unwrap();
/// assert_eq!(quote.total_cents, 599);
/// ```
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_from_source(&EnvFileSource, parcel)
}

fn quote_from_source(source: &dyn RateCardSource, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let contents = source.load()?;
    let card = parser::parse(&contents)?;
    let quote = calc::compute_quote(&card, parcel)?;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = quote.total_cents,
        "quote calculated"
    );

    Ok(quote)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::QuoteError;

    struct FakeSource(&'static str);

    impl RateCardSource for FakeSource {
        fn load(&self) -> Result<String, QuoteError> {
            Ok(self.0.to_owned())
        }
    }

    struct UnavailableSource;

    impl RateCardSource for UnavailableSource {
        fn load(&self) -> Result<String, QuoteError> {
            Err(QuoteError::RateCardUnavailable)
        }
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_owned(),
        }
    }

    #[test]
    fn quotes_from_a_source_without_touching_the_filesystem() {
        let source = FakeSource("domestic\t500\t599\n");
        let quote = quote_from_source(&source, &parcel(100, "domestic")).unwrap();
        assert_eq!(quote.total_cents, 599);
    }

    #[test]
    fn propagates_unavailable_source() {
        let err = quote_from_source(&UnavailableSource, &parcel(100, "domestic")).unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn propagates_malformed_rate_card() {
        let source = FakeSource("domestic\t500\n");
        let err = quote_from_source(&source, &parcel(100, "domestic")).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }
}
