use std::env;
use std::fs;

use crate::model::QuoteError;

/// A source of raw rate card text. Isolates the pure quote logic from the
/// filesystem and environment so tests can substitute an in-memory fake.
pub(crate) trait RateCardSource {
    fn load(&self) -> Result<String, QuoteError>;
}

/// Production source: reads the path named by `RATECARD_PATH` from disk.
pub(crate) struct EnvFileSource;

impl RateCardSource for EnvFileSource {
    fn load(&self) -> Result<String, QuoteError> {
        let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
        fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    struct FakeSource(Result<String, QuoteError>);

    impl RateCardSource for FakeSource {
        fn load(&self) -> Result<String, QuoteError> {
            match &self.0 {
                Ok(contents) => Ok(contents.clone()),
                Err(QuoteError::RateCardUnavailable) => Err(QuoteError::RateCardUnavailable),
                Err(_) => unreachable!("test only exercises RateCardUnavailable"),
            }
        }
    }

    #[test]
    fn fake_source_round_trips_contents() {
        let source = FakeSource(Ok("domestic\t500\t599\n".to_owned()));
        assert_eq!(source.load().unwrap(), "domestic\t500\t599\n");
    }

    #[test]
    fn fake_source_surfaces_unavailable() {
        let source = FakeSource(Err(QuoteError::RateCardUnavailable));
        assert_eq!(source.load().unwrap_err(), QuoteError::RateCardUnavailable);
    }
}
