use crate::model::{Parcel, Quote, QuoteError};
use crate::parser::RateCard;

const HEAVY_WEIGHT_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_WEIGHT_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

/// Computes a quote for `parcel` from an already-parsed rate card. Pure:
/// no I/O, deterministic given its inputs.
pub(crate) fn compute_quote(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = card
        .bands_for(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let matching_band = bands
        .iter()
        .filter(|band| band.band_max_grams >= parcel.weight_grams)
        .min_by_key(|band| band.band_max_grams);

    let band = match matching_band {
        Some(band) => band,
        None => {
            let limit = bands.iter().map(|band| band.band_max_grams).max().unwrap_or(0);
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let surcharge_cents = surcharge(base_cents, parcel);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.band_max_grams,
    })
}

fn surcharge(base_cents: u64, parcel: &Parcel) -> u64 {
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > HEAVY_WEIGHT_THRESHOLD_GRAMS {
        surcharge_cents += HEAVY_WEIGHT_SURCHARGE_CENTS;
    }

    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge_cents += round_half_up_percent(base_cents, INTERNATIONAL_SURCHARGE_PERCENT);
    }

    surcharge_cents
}

/// `percent`% of `cents`, rounded half-up to the nearest cent.
fn round_half_up_percent(cents: u64, percent: u64) -> u64 {
    let numerator = u128::from(cents) * u128::from(percent);
    let rounded = (numerator + 50) / 100;
    rounded as u64
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::parser::parse;

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_owned(),
        }
    }

    fn sample_card() -> RateCard {
        parse(
            "domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n\
             international\t500\t1499\n\
             international\t20000\t4999\n",
        )
        .unwrap()
    }

    #[test]
    fn picks_smallest_band_at_or_above_weight() {
        let quote = compute_quote(&sample_card(), &parcel(500, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);

        let quote = compute_quote(&sample_card(), &parcel(501, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn unknown_zone_errors() {
        let err = compute_quote(&sample_card(), &parcel(100, "lunar")).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".to_owned()));
    }

    #[test]
    fn overweight_errors_with_zone_limit() {
        let err = compute_quote(&sample_card(), &parcel(20001, "domestic")).unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 20001,
                limit: 20000
            }
        );
    }

    #[test]
    fn heavy_parcel_adds_flat_surcharge() {
        let quote = compute_quote(&sample_card(), &parcel(10001, "domestic")).unwrap();
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, quote.base_cents + 500);

        let quote = compute_quote(&sample_card(), &parcel(10000, "domestic")).unwrap();
        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_20_percent_rounded_half_up() {
        // 1499 * 0.2 = 299.8 -> rounds to 300
        let quote = compute_quote(&sample_card(), &parcel(500, "international")).unwrap();
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1499 + 300);
    }

    #[test]
    fn international_and_heavy_surcharges_stack() {
        let quote = compute_quote(&sample_card(), &parcel(10001, "international")).unwrap();
        // base 4999 * 0.2 = 999.8 -> 1000, plus 500 flat
        assert_eq!(quote.surcharge_cents, 1000 + 500);
    }

    #[test]
    fn round_half_up_boundary() {
        // exactly .5 should round up: 25 * 0.2 = 5.0 exactly, no ambiguity;
        // use a value that lands on a true half-cent boundary instead.
        assert_eq!(round_half_up_percent(125, 20), 25); // 25.0 exact
        assert_eq!(round_half_up_percent(127, 20), 25); // 25.4 -> 25
        assert_eq!(round_half_up_percent(128, 20), 26); // 25.6 -> 26
    }
}
