//! Integration tests for the boundary wiring around `quote`: reading the
//! `RATECARD_PATH` environment variable, reading the file it names, and
//! emitting a tracing span with the fields operators need. Pure calculation
//! behaviour (band selection, surcharges, rounding, malformed-line
//! detection) is covered by the inline unit tests in `src/domain.rs`.

use std::collections::HashMap;
use std::io::Write;
use std::sync::{Arc, Mutex};

use ratecard::{quote, Parcel, QuoteError};
use tracing::field::{Field, Visit};
use tracing::span::{Attributes, Id, Record};
use tracing::{Event, Metadata, Subscriber};

// `RATECARD_PATH` is process-global, so tests that touch it must not run
// concurrently with each other.
static ENV_GUARD: Mutex<()> = Mutex::new(());

fn with_rate_card<R>(contents: &str, run: impl FnOnce() -> R) -> R {
    let _lock = ENV_GUARD.lock().unwrap();
    let mut file = tempfile::NamedTempFile::new().expect("create temp rate card");
    file.write_all(contents.as_bytes()).expect("write temp rate card");
    std::env::set_var("RATECARD_PATH", file.path());
    let result = run();
    std::env::remove_var("RATECARD_PATH");
    result
}

fn with_missing_rate_card_path<R>(run: impl FnOnce() -> R) -> R {
    let _lock = ENV_GUARD.lock().unwrap();
    std::env::remove_var("RATECARD_PATH");
    run()
}

fn with_unreadable_rate_card_path<R>(run: impl FnOnce() -> R) -> R {
    let _lock = ENV_GUARD.lock().unwrap();
    std::env::set_var("RATECARD_PATH", "/does/not/exist/ratecard.tsv");
    let result = run();
    std::env::remove_var("RATECARD_PATH");
    result
}

const SAMPLE_CARD: &str = "domestic\t500\t599\ninternational\t20000\t4999\n";

#[test]
fn quotes_a_parcel_from_the_configured_rate_card() {
    let result = with_rate_card(SAMPLE_CARD, || {
        quote(&Parcel { weight_grams: 100, zone: "domestic".to_string() })
    });

    let quote = result.expect("quote succeeds");
    assert_eq!(quote.base_cents, 599);
    assert_eq!(quote.total_cents, 599);
}

#[test]
fn unset_ratecard_path_is_unavailable() {
    let result = with_missing_rate_card_path(|| {
        quote(&Parcel { weight_grams: 100, zone: "domestic".to_string() })
    });

    assert_eq!(result.unwrap_err(), QuoteError::RateCardUnavailable);
}

#[test]
fn unreadable_ratecard_path_is_unavailable() {
    let result = with_unreadable_rate_card_path(|| {
        quote(&Parcel { weight_grams: 100, zone: "domestic".to_string() })
    });

    assert_eq!(result.unwrap_err(), QuoteError::RateCardUnavailable);
}

#[test]
fn unknown_zone_flows_through_from_the_file() {
    let result = with_rate_card(SAMPLE_CARD, || {
        quote(&Parcel { weight_grams: 100, zone: "lunar".to_string() })
    });

    assert_eq!(result.unwrap_err(), QuoteError::UnknownZone("lunar".to_string()));
}

#[test]
fn malformed_rate_card_reports_line_number() {
    let result = with_rate_card("domestic\t500\n", || {
        quote(&Parcel { weight_grams: 100, zone: "domestic".to_string() })
    });

    assert_eq!(result.unwrap_err(), QuoteError::MalformedRateCard { line: 1 });
}

/// A minimal `Subscriber` that records the fields of the first span it
/// sees, so tests can assert on what `quote` reports for observability
/// without pulling in a full tracing backend.
#[derive(Clone, Default)]
struct CapturingSubscriber {
    fields: Arc<Mutex<HashMap<String, String>>>,
}

struct FieldVisitor<'a>(&'a mut HashMap<String, String>);

impl Visit for FieldVisitor<'_> {
    fn record_debug(&mut self, field: &Field, value: &dyn std::fmt::Debug) {
        self.0.insert(field.name().to_string(), format!("{value:?}"));
    }

    fn record_u64(&mut self, field: &Field, value: u64) {
        self.0.insert(field.name().to_string(), value.to_string());
    }

    fn record_str(&mut self, field: &Field, value: &str) {
        self.0.insert(field.name().to_string(), value.to_string());
    }
}

impl Subscriber for CapturingSubscriber {
    fn enabled(&self, _metadata: &Metadata<'_>) -> bool {
        true
    }

    fn new_span(&self, attrs: &Attributes<'_>) -> Id {
        let mut fields = self.fields.lock().unwrap();
        attrs.record(&mut FieldVisitor(&mut fields));
        Id::from_u64(1)
    }

    fn record(&self, _span: &Id, values: &Record<'_>) {
        let mut fields = self.fields.lock().unwrap();
        values.record(&mut FieldVisitor(&mut fields));
    }

    fn record_follows_from(&self, _span: &Id, _follows: &Id) {}

    fn event(&self, _event: &Event<'_>) {}

    fn enter(&self, _span: &Id) {}

    fn exit(&self, _span: &Id) {}
}

#[test]
fn quote_reports_zone_weight_and_total_for_operators() {
    let subscriber = CapturingSubscriber::default();
    let fields = subscriber.fields.clone();

    let result = with_rate_card(SAMPLE_CARD, || {
        tracing::subscriber::with_default(subscriber, || {
            quote(&Parcel { weight_grams: 100, zone: "domestic".to_string() })
        })
    });
    assert!(result.is_ok());

    let fields = fields.lock().unwrap();
    assert_eq!(fields.get("zone").map(String::as_str), Some("domestic"));
    assert_eq!(fields.get("weight_grams").map(String::as_str), Some("100"));
    assert_eq!(fields.get("total_cents").map(String::as_str), Some("599"));
}
