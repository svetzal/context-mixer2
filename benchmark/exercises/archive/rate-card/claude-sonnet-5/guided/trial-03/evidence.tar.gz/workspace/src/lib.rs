//! Shipping rate quotes for outbound parcels, priced against a rate card
//! that operations maintains and redeploys without a code change.
//!
//! [`quote`] is the thin imperative shell: it reads the rate card named by
//! the `RATECARD_PATH` environment variable and hands the parsed card and
//! the parcel to a pure calculation.

mod domain;
pub mod zones;

use std::env;
use std::fs;

pub use domain::{Parcel, Quote, QuoteError};
use domain::{compute_quote, parse_rate_card, RateCard};

const RATECARD_PATH_VAR: &str = "RATECARD_PATH";

/// Quotes shipping for `parcel` against the rate card named by the
/// `RATECARD_PATH` environment variable.
///
/// ```
/// use std::io::Write;
///
/// let mut file = tempfile::NamedTempFile::new().unwrap();
/// writeln!(file, "domestic\t500\t599").unwrap();
/// std::env::set_var("RATECARD_PATH", file.path());
///
/// let parcel = ratecard::Parcel { weight_grams: 100, zone: "domestic".to_string() };
/// let quote = ratecard::quote(&parcel).unwrap();
/// assert_eq!(quote.total_cents, 599);
/// ```
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "ratecard.quote",
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = tracing::field::Empty,
    );
    let _enter = span.enter();

    let result = load_rate_card().and_then(|card| compute_quote(&card, parcel));

    match &result {
        Ok(quote) => {
            span.record("total_cents", quote.total_cents);
        }
        Err(error) => tracing::warn!(%error, "quote failed"),
    }

    result
}

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = env::var(RATECARD_PATH_VAR).map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}
