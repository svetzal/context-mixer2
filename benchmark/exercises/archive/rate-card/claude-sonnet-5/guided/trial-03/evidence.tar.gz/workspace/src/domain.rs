//! Pure quote calculation: parsing a rate card's text and pricing a parcel
//! against it. Nothing here touches the environment, the filesystem, or any
//! other I/O, so it is cheap and deterministic to test.

use std::collections::HashMap;
use std::fmt;

/// A parcel to be quoted.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A calculated shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Failure modes for [`crate::quote`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone {zone:?}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weighs {grams}g, over the {limit}g limit")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// A rate card parsed from text: bands grouped by zone, sorted ascending by
/// `max_grams` within each zone.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub(crate) struct RateCard {
    bands_by_zone: HashMap<String, Vec<Band>>,
}

const INTERNATIONAL_ZONE: &str = "international";
const OVERWEIGHT_SURCHARGE_THRESHOLD_GRAMS: u32 = 10_000;
const OVERWEIGHT_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

/// Parses a tab-separated rate card: `zone\tband_max_grams\tcents` per line.
/// Blank lines and lines starting with `#` are skipped, but every line
/// (including those) counts toward the 1-based line numbers used in
/// [`QuoteError::MalformedRateCard`].
pub(crate) fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut bands_by_zone: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = fields[0];
        let band_max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        bands_by_zone
            .entry(zone.to_string())
            .or_default()
            .push(Band { max_grams: band_max_grams, cents });
    }

    for bands in bands_by_zone.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(RateCard { bands_by_zone })
}

/// Prices `parcel` against `card`.
pub(crate) fn compute_quote(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = card
        .bands_by_zone
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: bands.last().map_or(0, |band| band.max_grams),
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > OVERWEIGHT_SURCHARGE_THRESHOLD_GRAMS {
        surcharge_cents += OVERWEIGHT_SURCHARGE_CENTS;
    }
    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge_cents += round_half_up_to_cent(base_cents * INTERNATIONAL_SURCHARGE_PERCENT);
    }

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

/// Rounds `hundredths_of_a_cent / 100` half-up to the nearest cent.
fn round_half_up_to_cent(hundredths_of_a_cent: u64) -> u64 {
    (hundredths_of_a_cent + 50) / 100
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn parcel(zone: &str, weight_grams: u32) -> Parcel {
        Parcel { weight_grams, zone: zone.to_string() }
    }

    fn sample_card() -> RateCard {
        parse_rate_card(SAMPLE_CARD).expect("sample card parses")
    }

    #[test]
    fn selects_first_band_at_or_above_weight() {
        let quote = compute_quote(&sample_card(), &parcel("domestic", 100)).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
    }

    #[test]
    fn selects_band_exactly_at_boundary_weight() {
        let quote = compute_quote(&sample_card(), &parcel("domestic", 500)).unwrap();
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.base_cents, 599);
    }

    #[test]
    fn selects_next_band_just_above_boundary_weight() {
        let quote = compute_quote(&sample_card(), &parcel("domestic", 501)).unwrap();
        assert_eq!(quote.band_max_grams, 2000);
        assert_eq!(quote.base_cents, 899);
    }

    #[test]
    fn adds_overweight_surcharge_strictly_above_ten_kilograms() {
        let at_threshold = compute_quote(&sample_card(), &parcel("domestic", 10_000)).unwrap();
        assert_eq!(at_threshold.surcharge_cents, 0);

        let above_threshold = compute_quote(&sample_card(), &parcel("domestic", 10_001)).unwrap();
        assert_eq!(above_threshold.surcharge_cents, 500);
        assert_eq!(above_threshold.total_cents, 1799 + 500);
    }

    #[test]
    fn adds_international_surcharge_rounded_half_up() {
        // 20% of 1499 = 299.8 -> rounds up to 300.
        let quote = compute_quote(&sample_card(), &parcel("international", 100)).unwrap();
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn combines_overweight_and_international_surcharges() {
        // 20% of 4999 = 999.8 -> rounds up to 1000, plus 500 overweight.
        let quote = compute_quote(&sample_card(), &parcel("international", 15_000)).unwrap();
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1000 + 500);
        assert_eq!(quote.total_cents, 4999 + 1000 + 500);
    }

    #[test]
    fn unknown_zone_is_reported_with_the_requested_zone() {
        let err = compute_quote(&sample_card(), &parcel("lunar", 100)).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".to_string()));
    }

    #[test]
    fn weight_above_largest_band_is_overweight_with_that_limit() {
        let err = compute_quote(&sample_card(), &parcel("domestic", 20_001)).unwrap_err();
        assert_eq!(err, QuoteError::Overweight { grams: 20_001, limit: 20_000 });
    }

    #[test]
    fn malformed_line_with_wrong_field_count_reports_its_line_number() {
        let card = "domestic\t500\t599\nnot-three-fields\n";
        let err = parse_rate_card(card).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn malformed_line_with_unparseable_number_reports_its_line_number() {
        let card = "domestic\t500\t599\ndomestic\tabc\t899\n";
        let err = parse_rate_card(card).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn blank_and_comment_lines_are_ignored_but_still_counted() {
        let card = "# header\n\ndomestic\t500\t599\n\nbroken\n";
        let err = parse_rate_card(card).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 5 });
    }

    #[test]
    fn quote_error_display_messages_are_human_readable() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 3 }.to_string(),
            "malformed rate card at line 3"
        );
        assert_eq!(
            QuoteError::UnknownZone("mars".to_string()).to_string(),
            "unknown zone \"mars\""
        );
        assert_eq!(
            QuoteError::Overweight { grams: 25_000, limit: 20_000 }.to_string(),
            "parcel weighs 25000g, over the 20000g limit"
        );
    }
}
