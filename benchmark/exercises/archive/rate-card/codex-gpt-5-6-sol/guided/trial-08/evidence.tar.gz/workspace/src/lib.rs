//! Shipping quotes calculated from an operations-managed rate card.

mod zones;

use std::{env, error::Error, fmt, fs};

use tracing::{info, info_span};

/// A parcel to be priced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Rate-card zone name.
    pub zone: String,
}

/// The itemized price selected for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Price of the matching rate band, before surcharges.
    pub base_cents: u64,
    /// Sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// Final price, in cents.
    pub total_cents: u64,
    /// Upper weight threshold of the selected band.
    pub band_max_grams: u32,
}

/// Expected failures while loading a rate card or pricing a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The configured rate card could not be read.
    RateCardUnavailable,
    /// A non-comment line in the card is invalid.
    MalformedRateCard {
        /// One-based physical line number in the card.
        line: usize,
    },
    /// The requested zone has no bands in the card.
    UnknownZone(String),
    /// The parcel exceeds the greatest band for its zone.
    Overweight {
        /// Requested parcel weight.
        grams: u32,
        /// Greatest configured weight for the requested zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

/// Loads the configured rate card and calculates a quote for `parcel`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let span = info_span!(
        "shipping_quote",
        zone = parcel.zone.as_str(),
        weight_grams = parcel.weight_grams
    );
    let _entered = span.enter();
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let rate_card = zones::RateCard::parse(&contents)?;
    let quote = rate_card.quote(parcel)?;

    info!(total_cents = quote.total_cents, "shipping quote calculated");
    Ok(quote)
}
