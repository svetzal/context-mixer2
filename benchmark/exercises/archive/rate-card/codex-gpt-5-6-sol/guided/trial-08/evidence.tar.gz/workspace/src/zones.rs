//! Pure rate-card parsing and quote policy.

use std::collections::HashMap;

use crate::{Parcel, Quote, QuoteError};

#[derive(Debug, Clone, Copy)]
struct Band {
    max_grams: u32,
    cents: u64,
}

pub(crate) struct RateCard {
    bands_by_zone: HashMap<String, Vec<Band>>,
}

impl RateCard {
    pub(crate) fn parse(contents: &str) -> Result<Self, QuoteError> {
        let mut bands_by_zone: HashMap<String, Vec<Band>> = HashMap::new();
        for (index, line) in contents.lines().enumerate() {
            if line.is_empty() || line.starts_with('#') {
                continue;
            }
            let fields: Vec<_> = line.split('\t').collect();
            if fields.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: index + 1 });
            }
            let max_grams = fields[1]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
            let cents = fields[2]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
            bands_by_zone
                .entry(fields[0].to_owned())
                .or_default()
                .push(Band { max_grams, cents });
        }
        for bands in bands_by_zone.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }
        Ok(Self { bands_by_zone })
    }

    pub(crate) fn quote(&self, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let bands = self
            .bands_by_zone
            .get(&parcel.zone)
            .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
        let limit = bands.last().map_or(0, |band| band.max_grams);
        let band = bands.iter().find(|band| band.max_grams >= parcel.weight_grams).ok_or(
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            },
        )?;

        let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
        let zone_surcharge = if parcel.zone == "international" {
            // Adding half the divisor implements integer half-up rounding.
            (band.cents * 20 + 50) / 100
        } else {
            0
        };
        let surcharge_cents = weight_surcharge + zone_surcharge;
        Ok(Quote {
            base_cents: band.cents,
            surcharge_cents,
            total_cents: band.cents + surcharge_cents,
            band_max_grams: band.max_grams,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::RateCard;
    use crate::{Parcel, QuoteError};

    const CARD: &str = "domestic\t20000\t1799\ndomestic\t500\t599\ninternational\t20000\t4999\n";

    #[test]
    fn selects_sorted_band_and_adds_applicable_surcharges() {
        let Ok(card) = RateCard::parse(CARD) else {
            panic!("fixture should be valid");
        };
        let Ok(quote) = card.quote(&Parcel {
            weight_grams: 10_001,
            zone: "international".to_owned(),
        }) else {
            panic!("parcel should be covered");
        };
        assert_eq!(quote.base_cents, 4_999);
        assert_eq!(quote.surcharge_cents, 1_500);
        assert_eq!(quote.total_cents, 6_499);
        assert_eq!(quote.band_max_grams, 20_000);
    }

    #[test]
    fn reports_physical_line_number_for_bad_input() {
        let error = RateCard::parse("# heading\n\nbad row\n").err();
        assert_eq!(error, Some(QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn distinguishes_unknown_and_overweight_parcels() {
        let Ok(card) = RateCard::parse(CARD) else {
            panic!("fixture should be valid");
        };
        let unknown = card.quote(&Parcel {
            weight_grams: 1,
            zone: "moon".to_owned(),
        });
        assert_eq!(unknown, Err(QuoteError::UnknownZone("moon".to_owned())));
        let overweight = card.quote(&Parcel {
            weight_grams: 20_001,
            zone: "domestic".to_owned(),
        });
        assert_eq!(
            overweight,
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            })
        );
    }
}
