//! Public boundary tests for filesystem-backed quote calculation.

use std::{env, fs, sync::Mutex};

use ratecard::{quote, Parcel, QuoteError};
use tempfile::NamedTempFile;

static ENV_LOCK: Mutex<()> = Mutex::new(());

fn with_card<T>(contents: &str, operation: impl FnOnce() -> T) -> T {
    let Ok(_guard) = ENV_LOCK.lock() else {
        panic!("environment lock should not be poisoned");
    };
    let Ok(file) = NamedTempFile::new() else {
        panic!("temporary rate card should be created");
    };
    if let Err(error) = fs::write(file.path(), contents) {
        panic!("rate card should be writable: {error}");
    }
    env::set_var("RATECARD_PATH", file.path());
    let result = operation();
    env::remove_var("RATECARD_PATH");
    result
}

#[test]
fn calculates_a_file_backed_quote() {
    with_card("domestic\t500\t599\ndomestic\t2000\t899\n", || {
        let Ok(result) = quote(&Parcel {
            weight_grams: 501,
            zone: "domestic".to_owned(),
        }) else {
            panic!("parcel should receive a quote");
        };
        assert_eq!(result.base_cents, 899);
        assert_eq!(result.total_cents, 899);
        assert_eq!(result.band_max_grams, 2_000);
    });
}

#[test]
fn maps_an_unreadable_path_to_unavailable() {
    let Ok(_guard) = ENV_LOCK.lock() else {
        panic!("environment lock should not be poisoned");
    };
    env::set_var("RATECARD_PATH", "/a/path/that/does/not/exist");
    let result = quote(&Parcel {
        weight_grams: 1,
        zone: "domestic".to_owned(),
    });
    env::remove_var("RATECARD_PATH");
    assert_eq!(result, Err(QuoteError::RateCardUnavailable));
}
