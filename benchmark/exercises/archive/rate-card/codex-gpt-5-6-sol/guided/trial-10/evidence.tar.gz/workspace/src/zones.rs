use crate::QuoteError;

/// A parcel to be priced for shipment.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Rate-card zone name.
    pub zone: String,
}

/// The monetary and band details of a shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Price of the matching rate band before surcharges.
    pub base_cents: u64,
    /// Sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// Base price plus surcharges.
    pub total_cents: u64,
    /// Maximum weight of the selected rate band.
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct Band {
    zone: String,
    max_grams: u32,
    cents: u64,
}

pub(crate) fn parse_rate_card(contents: &str) -> Result<Vec<Band>, QuoteError> {
    contents
        .lines()
        .enumerate()
        .filter_map(|(index, line)| {
            let trimmed = line.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                None
            } else {
                Some(parse_band(line, index + 1))
            }
        })
        .collect()
}

fn parse_band(line: &str, line_number: usize) -> Result<Band, QuoteError> {
    let mut fields = line.split('\t');
    let (Some(zone), Some(max_grams), Some(cents), None) =
        (fields.next(), fields.next(), fields.next(), fields.next())
    else {
        return Err(QuoteError::MalformedRateCard { line: line_number });
    };

    let max_grams = max_grams
        .parse()
        .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
    let cents = cents.parse().map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

    Ok(Band {
        zone: zone.to_owned(),
        max_grams,
        cents,
    })
}

pub(crate) fn calculate(parcel: &Parcel, rate_card: &[Band]) -> Result<Quote, QuoteError> {
    let mut zone_bands: Vec<&Band> =
        rate_card.iter().filter(|band| band.zone == parcel.zone).collect();
    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }
    zone_bands.sort_unstable_by_key(|band| band.max_grams);

    let limit = zone_bands.last().map_or(0, |band| band.max_grams);
    let band = zone_bands
        .into_iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        rounded_twenty_percent(band.cents)
    } else {
        0
    };
    let surcharge_cents = weight_surcharge.saturating_add(international_surcharge);

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    })
}

fn rounded_twenty_percent(cents: u64) -> u64 {
    cents / 5 + u64::from(cents % 5 >= 3)
}

/// Return a human-friendly label for a known shipping zone.
#[must_use]
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const CARD: &str = "# zone\tband_max_grams\tcents\n\n\
domestic\t20000\t1799\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    #[test]
    fn selects_bands_in_numeric_order() -> Result<(), QuoteError> {
        let card = parse_rate_card(CARD)?;
        let result = calculate(
            &Parcel {
                weight_grams: 501,
                zone: "domestic".to_owned(),
            },
            &card,
        )?;

        assert_eq!(result.base_cents, 899);
        assert_eq!(result.band_max_grams, 2000);
        assert_eq!(result.total_cents, 899);
        Ok(())
    }

    #[test]
    fn adds_weight_and_rounded_international_surcharges() -> Result<(), QuoteError> {
        let card = parse_rate_card(CARD)?;
        let result = calculate(
            &Parcel {
                weight_grams: 10_001,
                zone: "international".to_owned(),
            },
            &card,
        )?;

        assert_eq!(result.surcharge_cents, 1500);
        assert_eq!(result.total_cents, 6499);
        Ok(())
    }

    #[test]
    fn malformed_line_reports_physical_line_number() {
        assert_eq!(
            parse_rate_card("# heading\n\nbad\n"),
            Err(QuoteError::MalformedRateCard { line: 3 })
        );
    }

    #[test]
    fn distinguishes_unknown_zones_and_overweight_parcels() -> Result<(), QuoteError> {
        let card = parse_rate_card(CARD)?;
        let unknown = calculate(
            &Parcel {
                weight_grams: 1,
                zone: "moon".to_owned(),
            },
            &card,
        );
        assert_eq!(unknown, Err(QuoteError::UnknownZone("moon".to_owned())));

        let overweight = calculate(
            &Parcel {
                weight_grams: 20_001,
                zone: "domestic".to_owned(),
            },
            &card,
        );
        assert_eq!(
            overweight,
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            })
        );
        Ok(())
    }
}
