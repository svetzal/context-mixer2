//! Shipping quote calculation backed by an operator-maintained rate card.

mod zones;

use std::{env, error::Error, fmt, fs};

pub use zones::{zone_label, Parcel, Quote};

/// A failure to load a rate card or calculate a quote from it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The configured rate card could not be found or read.
    RateCardUnavailable,
    /// A non-comment rate-card line did not have the required format.
    MalformedRateCard {
        /// The one-based source line containing the malformed record.
        line: usize,
    },
    /// The requested zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel exceeds the largest band configured for its zone.
    Overweight {
        /// The requested parcel weight.
        grams: u32,
        /// The largest configured weight for the requested zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

/// Calculate a shipping quote using the file named by `RATECARD_PATH`.
///
/// # Errors
///
/// Returns [`QuoteError`] when the rate card is unavailable or malformed, the
/// zone is unknown, or the parcel is heavier than its zone permits.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let result = (|| {
        let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
        let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
        let rate_card = zones::parse_rate_card(&contents)?;
        zones::calculate(parcel, &rate_card)
    })();

    match &result {
        Ok(calculated) => eprintln!(
            "event=shipping_quote zone={:?} weight_grams={} total_cents={}",
            parcel.zone, parcel.weight_grams, calculated.total_cents
        ),
        Err(error) => eprintln!(
            "event=shipping_quote zone={:?} weight_grams={} error={error:?}",
            parcel.zone, parcel.weight_grams
        ),
    }

    result
}
