//! Labels for known shipping zones.

/// Returns a human-friendly label for a well-known zone.
#[must_use]
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}
