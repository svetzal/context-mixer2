//! Shipping quotes calculated from an operations-managed rate card.

use std::{env, error::Error, fmt, fs};

pub mod zones;

/// A parcel to be priced for shipment.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Rate-card zone name.
    pub zone: String,
}

/// The itemized price of shipping a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Price of the matching weight band, before surcharges.
    pub base_cents: u64,
    /// Sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// Final price, including surcharges.
    pub total_cents: u64,
    /// Upper weight bound of the selected rate-card band.
    pub band_max_grams: u32,
}

/// Expected failures while loading a rate card or calculating a quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The configured rate card could not be read.
    RateCardUnavailable,
    /// A non-comment rate-card line has invalid fields.
    MalformedRateCard {
        /// One-based physical line number in the rate-card file.
        line: usize,
    },
    /// The requested zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel exceeds the largest band for its zone.
    Overweight {
        /// Requested parcel weight.
        grams: u32,
        /// Largest supported weight for the requested zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    zone: String,
    max_grams: u32,
    cents: u64,
}

fn parse_rate_card(contents: &str) -> Result<Vec<Band>, QuoteError> {
    contents
        .lines()
        .enumerate()
        .filter_map(|(index, line)| {
            let line_number = index + 1;
            if line.is_empty() || line.starts_with('#') {
                return None;
            }

            let mut fields = line.split('\t');
            let zone = fields.next();
            let max_grams = fields.next();
            let cents = fields.next();
            if fields.next().is_some() {
                return Some(Err(QuoteError::MalformedRateCard { line: line_number }));
            }

            Some(match (zone, max_grams, cents) {
                (Some(zone), Some(max_grams), Some(cents)) => {
                    match (max_grams.parse(), cents.parse()) {
                        (Ok(max_grams), Ok(cents)) => Ok(Band {
                            zone: zone.to_owned(),
                            max_grams,
                            cents,
                        }),
                        _ => Err(QuoteError::MalformedRateCard { line: line_number }),
                    }
                }
                _ => Err(QuoteError::MalformedRateCard { line: line_number }),
            })
        })
        .collect()
}

fn calculate_quote(parcel: &Parcel, bands: &[Band]) -> Result<Quote, QuoteError> {
    let mut zone_bands: Vec<_> = bands.iter().filter(|band| band.zone == parcel.zone).collect();
    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }
    zone_bands.sort_unstable_by_key(|band| band.max_grams);

    let limit = zone_bands.last().map_or(0, |band| band.max_grams);
    let band = zone_bands
        .into_iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        // Adding half the divisor implements round-half-up using integer arithmetic.
        (band.cents * 20 + 50) / 100
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

/// Calculates a shipping quote using the file configured by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = parse_rate_card(&contents)?;
    let result = calculate_quote(parcel, &bands);
    if let Ok(quote) = &result {
        eprintln!(
            "event=shipping_quote zone={:?} weight_grams={} total_cents={}",
            parcel.zone, parcel.weight_grams, quote.total_cents
        );
    }
    result
}

#[cfg(test)]
mod tests {
    use super::*;

    fn card() -> Vec<Band> {
        parse_rate_card(
            "domestic\t2000\t899\ndomestic\t500\t599\ninternational\t20000\t4999\ninternational\t500\t1499\n",
        )
        .unwrap_or_default()
    }

    #[test]
    fn chooses_the_first_matching_band_after_sorting() {
        let result = calculate_quote(
            &Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            },
            &card(),
        );
        assert_eq!(result.map(|quote| quote.base_cents), Ok(599));
    }

    #[test]
    fn adds_weight_and_international_surcharges() {
        let result = calculate_quote(
            &Parcel {
                weight_grams: 10_001,
                zone: "international".into(),
            },
            &card(),
        );
        assert_eq!(result.map(|quote| quote.surcharge_cents), Ok(1_500));
    }

    #[test]
    fn reports_unknown_and_overweight_zones() {
        assert_eq!(
            calculate_quote(
                &Parcel {
                    weight_grams: 1,
                    zone: "moon".into()
                },
                &card()
            ),
            Err(QuoteError::UnknownZone("moon".into()))
        );
        assert_eq!(
            calculate_quote(
                &Parcel {
                    weight_grams: 2_001,
                    zone: "domestic".into()
                },
                &card()
            ),
            Err(QuoteError::Overweight {
                grams: 2_001,
                limit: 2_000
            })
        );
    }

    #[test]
    fn malformed_line_numbers_include_comments_and_blanks() {
        assert_eq!(
            parse_rate_card("# heading\n\ndomestic\tnot-a-number\t599"),
            Err(QuoteError::MalformedRateCard { line: 3 })
        );
    }
}
