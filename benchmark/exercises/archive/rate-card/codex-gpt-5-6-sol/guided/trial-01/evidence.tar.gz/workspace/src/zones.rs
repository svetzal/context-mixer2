//! Human-readable labels for well-known shipping zones.

/// Return the display label for a zone, preserving unknown names.
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}
