//! Shipping quotes calculated from an operations-managed rate card.

use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

/// A parcel to price.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Rate-card zone name.
    pub zone: String,
}

/// The selected rate and all charges applied to it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Price of the matching weight band.
    pub base_cents: u64,
    /// Sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// Base price plus surcharges.
    pub total_cents: u64,
    /// Upper weight threshold of the selected band.
    pub band_max_grams: u32,
}

/// A failure to load or apply a rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The configured rate card could not be read.
    RateCardUnavailable,
    /// A non-comment rate-card line has an invalid shape or number.
    MalformedRateCard {
        /// One-based physical line number in the card.
        line: usize,
    },
    /// The requested zone has no bands in the card.
    UnknownZone(String),
    /// The parcel is heavier than every band for its zone.
    Overweight {
        /// Requested parcel weight.
        grams: u32,
        /// Largest supported weight for the requested zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    zone: String,
    max_grams: u32,
    cents: u64,
}

/// Calculate a shipping quote using the card configured by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = parse_rate_card(&contents)?;
    let result = calculate_quote(parcel, &bands);

    if let Ok(calculated) = &result {
        eprintln!(
            "ratecard_quote zone={} weight_grams={} total_cents={}",
            parcel.zone, parcel.weight_grams, calculated.total_cents
        );
    }

    result
}

fn parse_rate_card(contents: &str) -> Result<Vec<Band>, QuoteError> {
    contents
        .lines()
        .enumerate()
        .filter_map(|(index, line)| {
            let trimmed = line.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                return None;
            }

            Some(parse_band(line, index.saturating_add(1)))
        })
        .collect()
}

fn parse_band(line: &str, line_number: usize) -> Result<Band, QuoteError> {
    let mut fields = line.split('\t');
    let malformed = || QuoteError::MalformedRateCard { line: line_number };
    let zone = fields.next().ok_or_else(malformed)?;
    let max_grams = fields.next().ok_or_else(malformed)?.parse().map_err(|_| malformed())?;
    let cents = fields.next().ok_or_else(malformed)?.parse().map_err(|_| malformed())?;

    if fields.next().is_some() {
        return Err(malformed());
    }

    Ok(Band {
        zone: zone.to_owned(),
        max_grams,
        cents,
    })
}

fn calculate_quote(parcel: &Parcel, bands: &[Band]) -> Result<Quote, QuoteError> {
    let mut zone_bands: Vec<&Band> = bands.iter().filter(|band| band.zone == parcel.zone).collect();
    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }
    zone_bands.sort_unstable_by_key(|band| band.max_grams);

    let limit = zone_bands.last().map_or(0, |band| band.max_grams);
    let band = zone_bands
        .into_iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let weight_surcharge = if parcel.weight_grams > 10_000 {
        500_u64
    } else {
        0
    };
    // Integer division rounds down, so adding half the divisor gives half-up rounding.
    let international_surcharge = if parcel.zone == "international" {
        band.cents
            .checked_mul(20)
            .and_then(|value| value.checked_add(50))
            .map(|value| value / 100)
            .unwrap_or(u64::MAX)
    } else {
        0
    };
    let surcharge_cents = weight_surcharge.saturating_add(international_surcharge);
    let total_cents = band.cents.saturating_add(surcharge_cents);

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn band(zone: &str, max_grams: u32, cents: u64) -> Band {
        Band {
            zone: zone.to_owned(),
            max_grams,
            cents,
        }
    }

    #[test]
    fn parses_physical_line_numbers_and_ignores_comments_and_blanks() {
        let card = "# heading\n\ndomestic\t500\t599\nbroken";
        assert_eq!(parse_rate_card(card), Err(QuoteError::MalformedRateCard { line: 4 }));
    }

    #[test]
    fn selects_bands_by_threshold_even_when_card_is_unsorted() {
        let bands = [band("domestic", 2_000, 899), band("domestic", 500, 599)];
        let result = calculate_quote(
            &Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            },
            &bands,
        )
        .expect("quote should succeed");
        assert_eq!(result.base_cents, 599);
        assert_eq!(result.band_max_grams, 500);
    }

    #[test]
    fn adds_weight_and_rounded_international_surcharges() {
        let bands = [band("international", 20_000, 1_503)];
        let result = calculate_quote(
            &Parcel {
                weight_grams: 10_001,
                zone: "international".into(),
            },
            &bands,
        )
        .expect("quote should succeed");
        assert_eq!(result.surcharge_cents, 801);
        assert_eq!(result.total_cents, 2_304);
    }

    #[test]
    fn distinguishes_unknown_zone_from_overweight() {
        let bands = [band("domestic", 500, 599)];
        assert_eq!(
            calculate_quote(
                &Parcel {
                    weight_grams: 1,
                    zone: "moon".into(),
                },
                &bands,
            ),
            Err(QuoteError::UnknownZone("moon".into()))
        );
        assert_eq!(
            calculate_quote(
                &Parcel {
                    weight_grams: 501,
                    zone: "domestic".into(),
                },
                &bands,
            ),
            Err(QuoteError::Overweight {
                grams: 501,
                limit: 500,
            })
        );
    }
}
