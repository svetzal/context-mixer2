//! Public-contract tests that exercise the filesystem configuration boundary.

use std::env;
use std::fs;
use std::path::PathBuf;
use std::sync::{Mutex, OnceLock};

use ratecard::{quote, Parcel, QuoteError};

fn environment_lock() -> std::sync::MutexGuard<'static, ()> {
    static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    LOCK.get_or_init(|| Mutex::new(()))
        .lock()
        .expect("environment lock should not be poisoned")
}

fn rate_card_path() -> PathBuf {
    env::temp_dir().join(format!("ratecard-test-{}.tsv", std::process::id()))
}

#[test]
fn quote_reads_the_configured_card_and_returns_public_fields() {
    let _guard = environment_lock();
    let card = rate_card_path();
    fs::write(&card, "domestic\t20000\t1799\ndomestic\t500\t599\ninternational\t20000\t4999\n")
        .expect("write rate card");
    env::set_var("RATECARD_PATH", &card);

    let result = quote(&Parcel {
        weight_grams: 10_001,
        zone: "domestic".into(),
    })
    .expect("quote should succeed");

    env::remove_var("RATECARD_PATH");
    fs::remove_file(card).expect("remove temporary rate card");
    assert_eq!(result.base_cents, 1_799);
    assert_eq!(result.surcharge_cents, 500);
    assert_eq!(result.total_cents, 2_299);
    assert_eq!(result.band_max_grams, 20_000);
}

#[test]
fn unavailable_path_has_a_typed_error() {
    let _guard = environment_lock();
    env::remove_var("RATECARD_PATH");
    assert_eq!(
        quote(&Parcel {
            weight_grams: 1,
            zone: "domestic".into(),
        }),
        Err(QuoteError::RateCardUnavailable)
    );
}
