//! Public contract tests for rate-card loading and quote calculation.

use ratecard::{quote, Parcel, Quote, QuoteError};
use std::sync::Mutex;

static ENVIRONMENT: Mutex<()> = Mutex::new(());

#[test]
fn reads_the_configured_card_and_stacks_surcharges() {
    let _guard = ENVIRONMENT.lock().unwrap();
    let card = tempfile::NamedTempFile::new().unwrap();
    std::fs::write(
        card.path(),
        "# zone\tmax\tcents\ndomestic\t500\t599\ninternational\t20000\t4999\n",
    )
    .unwrap();
    std::env::set_var("RATECARD_PATH", card.path());

    let result = quote(&Parcel {
        weight_grams: 10_001,
        zone: "international".to_owned(),
    });

    std::env::remove_var("RATECARD_PATH");
    assert_eq!(
        result,
        Ok(Quote {
            base_cents: 4999,
            surcharge_cents: 1500,
            total_cents: 6499,
            band_max_grams: 20_000,
        })
    );
}

#[test]
fn unavailable_path_has_a_domain_error() {
    let _guard = ENVIRONMENT.lock().unwrap();
    std::env::remove_var("RATECARD_PATH");
    let result = quote(&Parcel {
        weight_grams: 1,
        zone: "domestic".to_owned(),
    });
    assert_eq!(result, Err(QuoteError::RateCardUnavailable));
}
