//! Pure rate-card parsing and quote policy.

use crate::QuoteError;

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct Band {
    pub(crate) zone: String,
    pub(crate) max_grams: u32,
    pub(crate) cents: u64,
}

pub(crate) fn parse_rate_card(contents: &str) -> Result<Vec<Band>, QuoteError> {
    contents
        .lines()
        .enumerate()
        .filter_map(|(index, line)| {
            if line.is_empty() || line.starts_with('#') {
                None
            } else {
                Some(parse_band(line, index + 1))
            }
        })
        .collect()
}

fn parse_band(line: &str, line_number: usize) -> Result<Band, QuoteError> {
    let mut fields = line.split('\t');
    let (Some(zone), Some(max_grams), Some(cents), None) =
        (fields.next(), fields.next(), fields.next(), fields.next())
    else {
        return Err(QuoteError::MalformedRateCard { line: line_number });
    };

    let max_grams = max_grams
        .parse()
        .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
    let cents = cents.parse().map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

    Ok(Band {
        zone: zone.to_owned(),
        max_grams,
        cents,
    })
}

pub(crate) fn select_band<'a>(
    bands: &'a [Band],
    zone: &str,
    weight_grams: u32,
) -> Result<&'a Band, QuoteError> {
    let mut zone_bands: Vec<&Band> = bands.iter().filter(|band| band.zone == zone).collect();
    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(zone.to_owned()));
    }
    zone_bands.sort_unstable_by_key(|band| band.max_grams);

    zone_bands
        .iter()
        .copied()
        .find(|band| weight_grams <= band.max_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: weight_grams,
            limit: zone_bands.last().map_or(0, |band| band.max_grams),
        })
}

pub(crate) fn surcharge_cents(zone: &str, weight_grams: u32, base_cents: u64) -> u64 {
    let heavy = u64::from(weight_grams > 10_000) * 500;
    let international = if zone == "international" {
        (base_cents + 2) / 5
    } else {
        0
    };
    heavy + international
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn malformed_numbers_report_physical_line_numbers() {
        let error = parse_rate_card("# heading\n\nzone\tbad\t100\n").unwrap_err();
        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn selection_sorts_bands_and_uses_inclusive_thresholds() {
        let bands = parse_rate_card("domestic\t2000\t899\ndomestic\t500\t599").unwrap();
        assert_eq!(select_band(&bands, "domestic", 500).unwrap().cents, 599);
    }

    #[test]
    fn reports_largest_band_when_overweight() {
        let bands = parse_rate_card("domestic\t500\t599\ndomestic\t2000\t899").unwrap();
        assert_eq!(
            select_band(&bands, "domestic", 2001),
            Err(QuoteError::Overweight {
                grams: 2001,
                limit: 2000
            })
        );
    }

    #[test]
    fn surcharges_stack_and_international_rounds_half_up() {
        assert_eq!(surcharge_cents("international", 10_001, 1_503), 801);
        assert_eq!(surcharge_cents("domestic", 10_000, 599), 0);
    }
}
