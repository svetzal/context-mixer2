//! Shipping quote calculation from an operations-managed rate card.

mod zones;

use std::{env, fmt, fs};

/// A parcel to price for shipment.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Rate-card zone name.
    pub zone: String,
}

/// The calculated price and selected rate band.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Quote {
    /// Price of the matching rate band, before surcharges.
    pub base_cents: u64,
    /// Sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// Final price, in cents.
    pub total_cents: u64,
    /// Upper weight threshold of the selected band.
    pub band_max_grams: u32,
}

/// Expected failures while loading a rate card or calculating a quote.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum QuoteError {
    /// The configured rate card could not be read.
    RateCardUnavailable,
    /// A non-comment rate-card line did not have the required shape.
    MalformedRateCard {
        /// One-based physical line number.
        line: usize,
    },
    /// No bands exist for the requested zone.
    UnknownZone(String),
    /// The parcel exceeds the largest band in its zone.
    Overweight {
        /// Requested parcel weight.
        grams: u32,
        /// Largest supported weight in the zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Calculates a quote using the file named by `RATECARD_PATH`.
///
/// # Errors
///
/// Returns [`QuoteError::RateCardUnavailable`] when the configured file cannot
/// be read, [`QuoteError::MalformedRateCard`] when its contents are invalid,
/// and a zone or weight error when no band can serve the parcel.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = zones::parse_rate_card(&contents)?;
    let band = zones::select_band(&bands, &parcel.zone, parcel.weight_grams)?;
    let surcharge_cents = zones::surcharge_cents(&parcel.zone, parcel.weight_grams, band.cents);
    let total_cents = band.cents + surcharge_cents;

    eprintln!(
        "event=shipping_quote zone={:?} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}
