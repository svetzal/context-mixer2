use std::{
    env, fs,
    sync::{LazyLock, Mutex},
};

use ratecard::{quote, Parcel, QuoteError};

static ENV_LOCK: LazyLock<Mutex<()>> = LazyLock::new(|| Mutex::new(()));

#[test]
fn quote_reads_the_configured_rate_card() {
    let _guard = ENV_LOCK.lock().unwrap();
    let directory = tempfile::tempdir().unwrap();
    let path = directory.path().join("rates.tsv");
    fs::write(&path, "domestic\t500\t599\ndomestic\t2000\t899\ninternational\t2000\t1499\n")
        .unwrap();
    env::set_var("RATECARD_PATH", &path);

    let result = quote(&Parcel {
        weight_grams: 501,
        zone: "domestic".into(),
    })
    .unwrap();

    assert_eq!(result.base_cents, 899);
    assert_eq!(result.surcharge_cents, 0);
    assert_eq!(result.total_cents, 899);
    assert_eq!(result.band_max_grams, 2_000);
}

#[test]
fn unreadable_configured_path_is_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap();
    let directory = tempfile::tempdir().unwrap();
    env::set_var("RATECARD_PATH", directory.path().join("missing.tsv"));

    let result = quote(&Parcel {
        weight_grams: 1,
        zone: "domestic".into(),
    });

    assert_eq!(result, Err(QuoteError::RateCardUnavailable));
}
