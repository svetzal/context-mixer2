//! Shipping quote calculation backed by an operations-managed rate card.

use std::{env, fmt, fs, io};

pub mod zones;

/// A parcel to price for shipment.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// The parcel's weight in grams.
    pub weight_grams: u32,
    /// The rate-card zone to use.
    pub zone: String,
}

/// The itemized price of shipping a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Price of the matching weight band, before surcharges.
    pub base_cents: u64,
    /// Sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// Final shipping price.
    pub total_cents: u64,
    /// Upper weight threshold of the selected band.
    pub band_max_grams: u32,
}

/// Expected failures while loading a rate card or pricing a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The configured rate card could not be located or read.
    RateCardUnavailable,
    /// A non-comment rate-card line did not have the required shape.
    MalformedRateCard {
        /// One-based physical line number in the rate-card file.
        line: usize,
    },
    /// No bands were configured for the requested zone.
    UnknownZone(String),
    /// The parcel is heavier than every band configured for its zone.
    Overweight {
        /// Requested parcel weight.
        grams: u32,
        /// Largest configured band for the requested zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    zone: String,
    max_grams: u32,
    cents: u64,
}

trait RateCardSource {
    fn read(&self) -> io::Result<String>;
}

struct EnvironmentRateCard;

impl RateCardSource for EnvironmentRateCard {
    fn read(&self) -> io::Result<String> {
        let path = env::var_os("RATECARD_PATH")
            .ok_or_else(|| io::Error::new(io::ErrorKind::NotFound, "RATECARD_PATH is unset"))?;
        fs::read_to_string(path)
    }
}

/// Calculates a shipping quote using the rate card named by `RATECARD_PATH`.
///
/// # Errors
///
/// Returns [`QuoteError`] if the card cannot be read or parsed, the zone is
/// absent, or the parcel exceeds the zone's largest weight band.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_from(&EnvironmentRateCard, parcel)
}

fn quote_from(source: &impl RateCardSource, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let contents = source.read().map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = parse_rate_card(&contents)?;
    let result = calculate_quote(&bands, parcel)?;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = result.total_cents,
        "shipping quote calculated"
    );
    Ok(result)
}

fn parse_rate_card(contents: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();
    for (index, line) in contents.lines().enumerate() {
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        }
        let max_grams = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        let cents = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        bands.push(Band {
            zone: fields[0].to_owned(),
            max_grams,
            cents,
        });
    }
    bands.sort_by_key(|band| band.max_grams);
    Ok(bands)
}

fn calculate_quote(bands: &[Band], parcel: &Parcel) -> Result<Quote, QuoteError> {
    let zone_bands: Vec<_> = bands.iter().filter(|band| band.zone == parcel.zone).collect();
    let limit = zone_bands
        .last()
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?
        .max_grams;
    let band = zone_bands
        .into_iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        rounded_twenty_percent(band.cents)
    } else {
        0
    };
    let surcharge_cents = weight_surcharge.saturating_add(international_surcharge);

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    })
}

fn rounded_twenty_percent(cents: u64) -> u64 {
    cents / 5 + u64::from(cents % 5 >= 3)
}

#[cfg(test)]
mod tests {
    use super::*;

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t2000\t899\n\
domestic\t500\t599\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    #[test]
    fn selects_sorted_band_and_combines_surcharges() {
        let bands = parse_rate_card(CARD).unwrap();
        let quote = calculate_quote(
            &bands,
            &Parcel {
                weight_grams: 10_001,
                zone: "international".into(),
            },
        )
        .unwrap();

        assert_eq!(quote.base_cents, 4_999);
        assert_eq!(quote.surcharge_cents, 1_500);
        assert_eq!(quote.total_cents, 6_499);
        assert_eq!(quote.band_max_grams, 20_000);
    }

    #[test]
    fn reports_physical_line_number_for_malformed_input() {
        let error = parse_rate_card("# heading\n\nbad line\n").unwrap_err();
        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn distinguishes_unknown_zone_from_overweight() {
        let bands = parse_rate_card(CARD).unwrap();
        assert_eq!(
            calculate_quote(
                &bands,
                &Parcel {
                    weight_grams: 1,
                    zone: "moon".into(),
                }
            ),
            Err(QuoteError::UnknownZone("moon".into()))
        );
        assert_eq!(
            calculate_quote(
                &bands,
                &Parcel {
                    weight_grams: 20_001,
                    zone: "domestic".into(),
                }
            ),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            })
        );
    }

    #[test]
    fn rounds_international_percentage_half_up() {
        assert_eq!(rounded_twenty_percent(2), 0);
        assert_eq!(rounded_twenty_percent(3), 1);
        assert_eq!(rounded_twenty_percent(8), 2);
    }
}
