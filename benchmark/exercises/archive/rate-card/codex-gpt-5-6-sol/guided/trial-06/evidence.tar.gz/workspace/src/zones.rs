//! Human-readable labels for built-in shipping zones.

/// Returns a display label for a known zone, or the supplied value otherwise.
#[must_use]
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}
