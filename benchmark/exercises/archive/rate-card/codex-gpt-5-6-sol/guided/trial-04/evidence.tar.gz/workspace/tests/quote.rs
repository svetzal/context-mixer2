//! Public-contract tests for rate-card filesystem wiring.

use std::{env, fs, sync::Mutex};

use ratecard::{quote, Parcel, Quote};

static ENV_LOCK: Mutex<()> = Mutex::new(());

#[test]
fn quote_reads_the_configured_rate_card() {
    let _guard = ENV_LOCK.lock().unwrap();
    let directory = tempfile::tempdir().unwrap();
    let path = directory.path().join("rates.tsv");
    fs::write(&path, "domestic\t500\t599\ninternational\t20000\t4999\n").unwrap();
    let previous_path = env::var_os("RATECARD_PATH");
    env::set_var("RATECARD_PATH", &path);

    let result = quote(&Parcel {
        weight_grams: 10_001,
        zone: "international".into(),
    });

    if let Some(previous_path) = previous_path {
        env::set_var("RATECARD_PATH", previous_path);
    } else {
        env::remove_var("RATECARD_PATH");
    }
    assert_eq!(
        result,
        Ok(Quote {
            base_cents: 4_999,
            surcharge_cents: 1_500,
            total_cents: 6_499,
            band_max_grams: 20_000,
        })
    );
}
