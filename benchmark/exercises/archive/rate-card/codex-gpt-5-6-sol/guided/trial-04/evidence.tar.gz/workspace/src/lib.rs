//! Shipping quotes calculated from an operations-managed rate card.

mod rate_card;
pub mod zones;

pub use rate_card::{quote, Parcel, Quote, QuoteError};
