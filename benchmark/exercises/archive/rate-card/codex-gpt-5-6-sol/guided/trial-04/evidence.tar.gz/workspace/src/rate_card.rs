//! Rate-card parsing, quote policy, and filesystem orchestration.

use std::{collections::HashMap, env, error::Error, fmt, fs};

/// A parcel to be priced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Rate-card zone name.
    pub zone: String,
}

/// The itemized price of shipping a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Price of the matching weight band, before surcharges.
    pub base_cents: u64,
    /// Sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// Final price, including surcharges.
    pub total_cents: u64,
    /// Upper weight limit of the selected band.
    pub band_max_grams: u32,
}

/// An expected failure while loading a rate card or calculating a quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The configured rate card could not be read.
    RateCardUnavailable,
    /// A non-comment line in the rate card was invalid.
    MalformedRateCard {
        /// One-based physical line number, including comments and blank lines.
        line: usize,
    },
    /// The requested zone did not occur in the rate card.
    UnknownZone(String),
    /// The parcel exceeded the largest band for its zone.
    Overweight {
        /// Requested parcel weight.
        grams: u32,
        /// Largest supported weight for the requested zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

type RateCard = HashMap<String, Vec<Band>>;

/// Calculate a shipping quote using the file named by `RATECARD_PATH`.
///
/// # Errors
///
/// Returns [`QuoteError`] when the card cannot be loaded or parsed, when the
/// zone is absent, or when the parcel is heavier than the zone supports.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = parse_rate_card(&contents)?;
    let result = calculate_quote(parcel, &card)?;

    eprintln!(
        "event=shipping_quote zone={:?} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, result.total_cents
    );
    Ok(result)
}

fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut card: RateCard = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let mut fields = line.split('\t');
        let (Some(zone), Some(max_grams), Some(cents), None) =
            (fields.next(), fields.next(), fields.next(), fields.next())
        else {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        };
        let max_grams = max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        let cents = cents.parse().map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        card.entry(zone.to_owned()).or_default().push(Band { max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }
    Ok(card)
}

fn calculate_quote(parcel: &Parcel, card: &RateCard) -> Result<Quote, QuoteError> {
    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let limit = bands.last().map_or(0, |band| band.max_grams);
    let band = bands.iter().find(|band| band.max_grams >= parcel.weight_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        },
    )?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    // Dividing by five is 20%; remainders three and four round up to a cent.
    let international_surcharge = if parcel.zone == "international" {
        band.cents / 5 + u64::from(band.cents % 5 >= 3)
    } else {
        0
    };
    let surcharge_cents = weight_surcharge.saturating_add(international_surcharge);
    let total_cents = band.cents.saturating_add(surcharge_cents);

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t20000\t1799\n\
domestic\t500\t599\n\
international\t20000\t4999\n\
international\t500\t1499\n";

    fn parsed_card() -> RateCard {
        parse_rate_card(CARD).unwrap()
    }

    #[test]
    fn selects_the_first_band_by_ascending_weight() {
        let result = calculate_quote(
            &Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            },
            &parsed_card(),
        )
        .unwrap();
        assert_eq!(
            result,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500
            }
        );
    }

    #[test]
    fn adds_weight_and_rounded_international_surcharges() {
        let result = calculate_quote(
            &Parcel {
                weight_grams: 10_001,
                zone: "international".into(),
            },
            &parsed_card(),
        )
        .unwrap();
        assert_eq!(result.surcharge_cents, 1_500);
        assert_eq!(result.total_cents, 6_499);
    }

    #[test]
    fn reports_unknown_and_overweight_zones() {
        let card = parsed_card();
        assert_eq!(
            calculate_quote(
                &Parcel {
                    weight_grams: 1,
                    zone: "moon".into()
                },
                &card
            ),
            Err(QuoteError::UnknownZone("moon".into()))
        );
        assert_eq!(
            calculate_quote(
                &Parcel {
                    weight_grams: 20_001,
                    zone: "domestic".into()
                },
                &card
            ),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            })
        );
    }

    #[test]
    fn malformed_line_number_counts_ignored_lines() {
        assert_eq!(
            parse_rate_card("# heading\n\nbad line\n"),
            Err(QuoteError::MalformedRateCard { line: 3 })
        );
    }

    #[test]
    fn percentage_rounds_half_up() {
        let card = parse_rate_card("international\t1\t3\n").unwrap();
        let result = calculate_quote(
            &Parcel {
                weight_grams: 1,
                zone: "international".into(),
            },
            &card,
        )
        .unwrap();
        assert_eq!(result.surcharge_cents, 1);
    }
}
