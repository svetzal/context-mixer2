//! Shipping quotes calculated from an operations-managed rate card.

mod rate_card;
pub mod zones;

use std::{env, fs};

use rate_card::RateCard;

/// A parcel to price.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Rate-card zone to use.
    pub zone: String,
}

/// The price selected for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Price of the matching rate-card band.
    pub base_cents: u64,
    /// Sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// Base price plus surcharges.
    pub total_cents: u64,
    /// Upper weight threshold of the selected band.
    pub band_max_grams: u32,
}

/// An expected failure while loading a rate card or calculating a quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The configured rate card could not be read.
    RateCardUnavailable,
    /// A non-comment line in the rate card was invalid.
    MalformedRateCard {
        /// One-based physical line number, including comments and blank lines.
        line: usize,
    },
    /// The requested zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel exceeds the largest band for its zone.
    Overweight {
        /// Requested parcel weight.
        grams: u32,
        /// Largest configured weight for the requested zone.
        limit: u32,
    },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Calculate a shipping quote using the file named by `RATECARD_PATH`.
///
/// # Errors
///
/// Returns [`QuoteError`] when the card cannot be read or parsed, or when the
/// parcel cannot be priced by the card.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let result = RateCard::parse(&contents)?.quote(parcel)?;

    tracing::info!(
        zone = parcel.zone.as_str(),
        weight_grams = parcel.weight_grams,
        total_cents = result.total_cents,
        "shipping quote calculated"
    );

    Ok(result)
}
