//! Public API integration tests.

use std::{env, fs};

use ratecard::{quote, Parcel, Quote, QuoteError};

#[test]
fn public_api_reads_the_configured_rate_card() -> Result<(), Box<dyn std::error::Error>> {
    let directory = tempfile::tempdir()?;
    let path = directory.path().join("rates.tsv");
    fs::write(&path, "domestic\t500\t599\ndomestic\t20000\t1799\ninternational\t20000\t4999\n")?;
    env::set_var("RATECARD_PATH", &path);

    let result = quote(&Parcel {
        weight_grams: 10_001,
        zone: "international".to_owned(),
    });

    env::remove_var("RATECARD_PATH");
    assert_eq!(
        result?,
        Quote {
            base_cents: 4999,
            surcharge_cents: 1500,
            total_cents: 6499,
            band_max_grams: 20_000,
        }
    );
    assert_eq!(
        quote(&Parcel {
            weight_grams: 1,
            zone: "domestic".to_owned()
        }),
        Err(QuoteError::RateCardUnavailable)
    );
    Ok(())
}
