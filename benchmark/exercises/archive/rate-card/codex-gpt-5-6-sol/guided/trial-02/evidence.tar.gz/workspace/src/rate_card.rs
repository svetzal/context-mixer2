//! Pure rate-card parsing and quote policy.

use std::collections::HashMap;

use crate::{Parcel, Quote, QuoteError};

#[derive(Debug, Clone, Copy)]
struct Band {
    max_grams: u32,
    cents: u64,
}

pub(crate) struct RateCard {
    bands_by_zone: HashMap<String, Vec<Band>>,
}

impl RateCard {
    pub(crate) fn parse(contents: &str) -> Result<Self, QuoteError> {
        let mut bands_by_zone: HashMap<String, Vec<Band>> = HashMap::new();

        for (index, line) in contents.lines().enumerate() {
            if line.is_empty() || line.starts_with('#') {
                continue;
            }

            let mut fields = line.split('\t');
            let zone = fields.next();
            let max_grams = fields.next().and_then(|value| value.parse::<u32>().ok());
            let cents = fields.next().and_then(|value| value.parse::<u64>().ok());
            if zone.is_none() || max_grams.is_none() || cents.is_none() || fields.next().is_some() {
                return Err(QuoteError::MalformedRateCard { line: index + 1 });
            }

            // The checks above establish all three fields without panicking on bad input.
            if let (Some(zone), Some(max_grams), Some(cents)) = (zone, max_grams, cents) {
                bands_by_zone
                    .entry(zone.to_owned())
                    .or_default()
                    .push(Band { max_grams, cents });
            }
        }

        for bands in bands_by_zone.values_mut() {
            bands.sort_unstable_by_key(|band| band.max_grams);
        }

        Ok(Self { bands_by_zone })
    }

    pub(crate) fn quote(&self, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let bands = self
            .bands_by_zone
            .get(&parcel.zone)
            .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
        let limit = bands.last().map_or(0, |band| band.max_grams);
        let band = bands.iter().find(|band| band.max_grams >= parcel.weight_grams).ok_or(
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            },
        )?;

        let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
        // Dividing by 100 after adding half the denominator implements half-up rounding.
        let international_surcharge = if parcel.zone == "international" {
            (band.cents * 20 + 50) / 100
        } else {
            0
        };
        let surcharge_cents = weight_surcharge + international_surcharge;

        Ok(Quote {
            base_cents: band.cents,
            surcharge_cents,
            total_cents: band.cents + surcharge_cents,
            band_max_grams: band.max_grams,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::RateCard;
    use crate::{Parcel, Quote, QuoteError};

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t20000\t1799\n\
domestic\t500\t599\n\
international\t20000\t4999\n\
international\t500\t1499\n";

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_owned(),
        }
    }

    #[test]
    fn sorts_bands_and_uses_the_first_matching_threshold() -> Result<(), QuoteError> {
        let card = RateCard::parse(CARD)?;
        assert_eq!(
            card.quote(&parcel(500, "domestic"))?,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );
        assert_eq!(card.quote(&parcel(501, "domestic"))?.band_max_grams, 20_000);
        Ok(())
    }

    #[test]
    fn adds_weight_and_rounded_international_surcharges() -> Result<(), QuoteError> {
        let card = RateCard::parse(CARD)?;
        assert_eq!(
            card.quote(&parcel(10_001, "international"))?,
            Quote {
                base_cents: 4999,
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20_000,
            }
        );
        Ok(())
    }

    #[test]
    fn reports_zone_and_weight_failures() -> Result<(), QuoteError> {
        let card = RateCard::parse(CARD)?;
        assert_eq!(card.quote(&parcel(1, "moon")), Err(QuoteError::UnknownZone("moon".into())));
        assert_eq!(
            card.quote(&parcel(20_001, "domestic")),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            })
        );
        Ok(())
    }

    #[test]
    fn malformed_line_number_counts_ignored_lines() {
        let result = RateCard::parse("# heading\n\nbad line\n");
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 3 })));
    }
}
