//! Pure rate-card parsing and quote-calculation policy.

use std::collections::HashMap;

use crate::{Parcel, Quote, QuoteError};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

#[derive(Debug, Default)]
pub(crate) struct RateCard {
    bands_by_zone: HashMap<String, Vec<Band>>,
}

impl RateCard {
    pub(crate) fn parse(contents: &str) -> Result<Self, QuoteError> {
        let mut card = Self::default();
        for (index, physical_line) in contents.lines().enumerate() {
            let line_number = index + 1;
            let line = physical_line.strip_suffix('\r').unwrap_or(physical_line);
            if line.is_empty() || line.starts_with('#') {
                continue;
            }

            let mut fields = line.split('\t');
            let (Some(zone), Some(max_grams), Some(cents), None) =
                (fields.next(), fields.next(), fields.next(), fields.next())
            else {
                return Err(QuoteError::MalformedRateCard { line: line_number });
            };
            let max_grams = max_grams
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
            let cents =
                cents.parse().map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
            card.bands_by_zone
                .entry(zone.to_owned())
                .or_default()
                .push(Band { max_grams, cents });
        }
        for bands in card.bands_by_zone.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }
        Ok(card)
    }

    pub(crate) fn quote(&self, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let bands = self
            .bands_by_zone
            .get(&parcel.zone)
            .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
        let limit = bands.last().map_or(0, |band| band.max_grams);
        let band = bands.iter().find(|band| band.max_grams >= parcel.weight_grams).ok_or(
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            },
        )?;

        let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
        let zone_surcharge = if parcel.zone == "international" {
            ((u128::from(band.cents) * 20 + 50) / 100) as u64
        } else {
            0
        };
        let surcharge_cents = weight_surcharge.saturating_add(zone_surcharge);

        Ok(Quote {
            base_cents: band.cents,
            surcharge_cents,
            total_cents: band.cents.saturating_add(surcharge_cents),
            band_max_grams: band.max_grams,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const CARD: &str =
        "# rates\ninternational\t20000\t4999\ndomestic\t2000\t899\n\ndomestic\t500\t599\n";

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_owned(),
        }
    }

    #[test]
    fn sorts_bands_and_selects_the_first_threshold() {
        let card = RateCard::parse(CARD).unwrap();
        let result = card.quote(&parcel(500, "domestic")).unwrap();
        assert_eq!(result.base_cents, 599);
        assert_eq!(result.band_max_grams, 500);
    }

    #[test]
    fn adds_weight_and_rounded_international_surcharges() {
        let card = RateCard::parse(CARD).unwrap();
        let result = card.quote(&parcel(10_001, "international")).unwrap();
        assert_eq!(result.surcharge_cents, 1_500);
        assert_eq!(result.total_cents, 6_499);
    }

    #[test]
    fn reports_physical_line_for_malformed_data() {
        assert_eq!(
            RateCard::parse("# heading\n\nbad\tdata\n").unwrap_err(),
            QuoteError::MalformedRateCard { line: 3 }
        );
    }

    #[test]
    fn distinguishes_unknown_zone_and_overweight() {
        let card = RateCard::parse(CARD).unwrap();
        assert_eq!(card.quote(&parcel(1, "moon")), Err(QuoteError::UnknownZone("moon".into())));
        assert_eq!(
            card.quote(&parcel(2_001, "domestic")),
            Err(QuoteError::Overweight {
                grams: 2_001,
                limit: 2_000
            })
        );
    }
}
