//! Shipping quotes calculated from an operations-managed rate card.

mod rate_card;
pub mod zones;

use std::{fmt, path::PathBuf};

use crate::rate_card::RateCard;

/// A parcel to price for shipping.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Rate-card zone used to route the parcel.
    pub zone: String,
}

/// The monetary and band details of a shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Price of the matching weight band, before surcharges.
    pub base_cents: u64,
    /// Sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// Final price, including surcharges.
    pub total_cents: u64,
    /// Upper weight threshold of the selected band.
    pub band_max_grams: u32,
}

/// Expected failures while loading a rate card or calculating a quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The configured rate card could not be located or read.
    RateCardUnavailable,
    /// A rate-card line did not have the required format.
    MalformedRateCard {
        /// One-based physical line number.
        line: usize,
    },
    /// The requested zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel exceeds the largest configured band for its zone.
    Overweight {
        /// Requested parcel weight.
        grams: u32,
        /// Largest supported weight for the zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Supplies raw rate-card contents at the crate's effect boundary.
pub trait RateCardSource {
    /// Loads the current rate card.
    ///
    /// # Errors
    ///
    /// Returns [`QuoteError::RateCardUnavailable`] when the source cannot load.
    fn load(&self) -> Result<String, QuoteError>;
}

/// Rate-card source backed by `RATECARD_PATH` and the filesystem.
#[derive(Debug, Default, Clone, Copy)]
pub struct FileRateCardSource;

impl RateCardSource for FileRateCardSource {
    fn load(&self) -> Result<String, QuoteError> {
        let path = std::env::var_os("RATECARD_PATH")
            .filter(|value| !value.is_empty())
            .map(PathBuf::from)
            .ok_or(QuoteError::RateCardUnavailable)?;
        std::fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}

/// Calculates a shipping quote using the file named by `RATECARD_PATH`.
///
/// Successful calls emit a structured `ratecard.quote` event with the zone,
/// weight, and resulting total.
///
/// # Errors
///
/// Returns a [`QuoteError`] when the card cannot be loaded or the requested
/// quote cannot be calculated.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_with(parcel, &FileRateCardSource)
}

/// Calculates a quote using an explicit rate-card source.
///
/// This entry point permits deterministic boundary tests and alternate delivery
/// adapters without coupling pricing policy to them.
///
/// # Errors
///
/// Returns source, parsing, or pricing failures as [`QuoteError`].
pub fn quote_with(parcel: &Parcel, source: &dyn RateCardSource) -> Result<Quote, QuoteError> {
    let contents = source.load()?;
    let result = RateCard::parse(&contents)?.quote(parcel)?;
    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = result.total_cents,
        "shipping quote calculated"
    );
    Ok(result)
}
