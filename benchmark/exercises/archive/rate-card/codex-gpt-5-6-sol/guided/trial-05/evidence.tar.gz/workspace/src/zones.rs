//! Human-readable labels for well-known shipping zones.

/// Returns a display label for a zone, preserving unknown zone names.
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}
