//! Public boundary tests for environment and filesystem orchestration.

use std::sync::Mutex;

use ratecard::{quote, quote_with, Parcel, QuoteError, RateCardSource};
static ENVIRONMENT: Mutex<()> = Mutex::new(());

struct StaticCard(&'static str);

impl RateCardSource for StaticCard {
    fn load(&self) -> Result<String, QuoteError> {
        Ok(self.0.to_owned())
    }
}

fn rate_card_path(test_name: &str) -> std::path::PathBuf {
    std::env::temp_dir().join(format!("ratecard-{}-{test_name}.tsv", std::process::id()))
}

#[test]
fn public_entry_point_reads_the_configured_card() {
    let _guard = ENVIRONMENT.lock().unwrap();
    let path = rate_card_path("reads-card");
    std::fs::write(&path, "domestic\t500\t599\n").unwrap();
    std::env::set_var("RATECARD_PATH", &path);
    let result = quote(&Parcel {
        weight_grams: 200,
        zone: "domestic".into(),
    })
    .unwrap();
    std::env::remove_var("RATECARD_PATH");
    std::fs::remove_file(path).unwrap();
    assert_eq!(result.total_cents, 599);
}

#[test]
fn public_entry_point_maps_missing_configuration_to_domain_error() {
    let _guard = ENVIRONMENT.lock().unwrap();
    std::env::remove_var("RATECARD_PATH");
    let result = quote(&Parcel {
        weight_grams: 200,
        zone: "domestic".into(),
    });
    assert_eq!(result, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn cross_module_wiring_accepts_an_in_memory_source() {
    let result = quote_with(
        &Parcel {
            weight_grams: 200,
            zone: "domestic".into(),
        },
        &StaticCard("domestic\t500\t599\n"),
    )
    .unwrap();

    assert_eq!(result.total_cents, 599);
}
