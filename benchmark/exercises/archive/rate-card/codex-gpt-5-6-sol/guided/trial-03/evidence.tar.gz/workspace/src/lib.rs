//! Shipping quotes calculated from an operations-managed rate card.

use std::{env, fmt, fs, io};

use tracing::{field, info, info_span};

pub mod zones;

/// A parcel to price for a shipping zone.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Rate-card zone name.
    pub zone: String,
}

/// The calculated price and selected rate band.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Price supplied by the matching rate-card band.
    pub base_cents: u64,
    /// Sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// Base price plus surcharges.
    pub total_cents: u64,
    /// Maximum weight accepted by the selected band.
    pub band_max_grams: u32,
}

/// Expected failures while loading a rate card or calculating a quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The configured rate card could not be located or read.
    RateCardUnavailable,
    /// A non-comment rate-card line did not have the required shape.
    MalformedRateCard {
        /// One-based physical line number, including comments and blank lines.
        line: usize,
    },
    /// The requested zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel exceeds the largest band configured for its zone.
    Overweight {
        /// Requested parcel weight.
        grams: u32,
        /// Largest configured weight for the requested zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    zone: String,
    max_grams: u32,
    cents: u64,
}

/// Calculates a shipping quote using the file named by `RATECARD_PATH`.
///
/// A tracing span named `shipping_quote` records the zone, parcel weight, and,
/// on success, resulting total for operational diagnostics.
///
/// # Errors
///
/// Returns [`QuoteError`] when the rate card cannot be loaded or parsed, or
/// when the parcel cannot be priced by the configured zones and bands.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let span = info_span!(
        "shipping_quote",
        zone = parcel.zone.as_str(),
        weight_grams = parcel.weight_grams,
        total_cents = field::Empty
    );
    let _entered = span.enter();

    let contents = read_rate_card().map_err(|_error| QuoteError::RateCardUnavailable)?;
    let bands = parse_rate_card(&contents)?;
    let result = calculate_quote(parcel, &bands)?;

    span.record("total_cents", result.total_cents);
    info!(total_cents = result.total_cents, "shipping quote calculated");
    Ok(result)
}

fn read_rate_card() -> Result<String, io::Error> {
    let path = env::var_os("RATECARD_PATH").ok_or_else(|| {
        io::Error::new(io::ErrorKind::NotFound, "RATECARD_PATH is not configured")
    })?;
    fs::read_to_string(path)
}

fn parse_rate_card(contents: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();
    for (index, line) in contents.lines().enumerate() {
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        }
        let max_grams = fields[1]
            .parse()
            .map_err(|_error| QuoteError::MalformedRateCard { line: index + 1 })?;
        let cents = fields[2]
            .parse()
            .map_err(|_error| QuoteError::MalformedRateCard { line: index + 1 })?;
        bands.push(Band {
            zone: fields[0].to_owned(),
            max_grams,
            cents,
        });
    }
    bands.sort_by_key(|band| band.max_grams);
    Ok(bands)
}

fn calculate_quote(parcel: &Parcel, bands: &[Band]) -> Result<Quote, QuoteError> {
    let zone_bands: Vec<_> = bands.iter().filter(|band| band.zone == parcel.zone).collect();
    let limit = zone_bands
        .last()
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?
        .max_grams;
    let band = zone_bands
        .into_iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let mut surcharge_cents = u64::from(parcel.weight_grams > 10_000) * 500;
    if parcel.zone == "international" {
        // One fifth is 20%; a remainder of 3/5 or 4/5 rounds up to the cent.
        surcharge_cents += band.cents / 5 + u64::from(band.cents % 5 >= 3);
    }

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t20000\t1799\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    #[test]
    fn chooses_sorted_band_and_applies_weight_surcharge() {
        let bands = parse_rate_card(CARD).unwrap();
        let result = calculate_quote(
            &Parcel {
                weight_grams: 10_001,
                zone: "domestic".to_owned(),
            },
            &bands,
        )
        .unwrap();

        assert_eq!(result.base_cents, 1799);
        assert_eq!(result.surcharge_cents, 500);
        assert_eq!(result.total_cents, 2299);
        assert_eq!(result.band_max_grams, 20_000);
    }

    #[test]
    fn international_percentage_rounds_half_up() {
        let bands = parse_rate_card(CARD).unwrap();
        let result = calculate_quote(
            &Parcel {
                weight_grams: 500,
                zone: "international".to_owned(),
            },
            &bands,
        )
        .unwrap();

        assert_eq!(result.surcharge_cents, 300);
        assert_eq!(result.total_cents, 1799);
    }

    #[test]
    fn distinguishes_unknown_zone_from_overweight() {
        let bands = parse_rate_card(CARD).unwrap();
        assert_eq!(
            calculate_quote(
                &Parcel {
                    weight_grams: 1,
                    zone: "moon".to_owned(),
                },
                &bands,
            ),
            Err(QuoteError::UnknownZone("moon".to_owned()))
        );
        assert_eq!(
            calculate_quote(
                &Parcel {
                    weight_grams: 20_001,
                    zone: "domestic".to_owned(),
                },
                &bands,
            ),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            })
        );
    }

    #[test]
    fn reports_physical_line_for_malformed_input() {
        let error = parse_rate_card("# heading\n\nbad line\n").unwrap_err();
        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
    }
}
