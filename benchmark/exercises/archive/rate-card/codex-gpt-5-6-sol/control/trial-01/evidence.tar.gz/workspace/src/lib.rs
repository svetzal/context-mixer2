//! Shipping quote calculation backed by an operations-managed rate card.

use std::{env, error::Error, fmt, fs};

pub mod zones;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card line {line} is malformed")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighs {grams} grams; zone limit is {limit} grams")
            }
        }
    }
}

impl Error for QuoteError {}

struct Band {
    zone: String,
    max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let mut bands = parse_rate_card(&contents)?;
    bands.sort_by_key(|band| band.max_grams);

    let zone_bands: Vec<&Band> = bands.iter().filter(|band| band.zone == parcel.zone).collect();
    let limit = zone_bands
        .last()
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?
        .max_grams;
    let band = zone_bands
        .into_iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        ((u128::from(band.cents) * 20 + 50) / 100) as u64
    } else {
        0
    };
    let surcharge_cents = weight_surcharge.saturating_add(international_surcharge);
    let total_cents = band.cents.saturating_add(surcharge_cents);
    let result = Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    };

    eprintln!(
        "ratecard_quote zone={:?} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, result.total_cents
    );
    Ok(result)
}

fn parse_rate_card(contents: &str) -> Result<Vec<Band>, QuoteError> {
    contents
        .lines()
        .enumerate()
        .filter_map(|(index, line)| {
            let trimmed = line.trim();
            (!trimmed.is_empty() && !trimmed.starts_with('#')).then_some((index, line))
        })
        .map(|(index, line)| {
            let line_number = index + 1;
            let fields: Vec<&str> = line.split('\t').collect();
            if fields.len() != 3 || fields[0].is_empty() {
                return Err(QuoteError::MalformedRateCard { line: line_number });
            }
            let max_grams = fields[1]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
            let cents = fields[2]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
            Ok(Band {
                zone: fields[0].to_owned(),
                max_grams,
                cents,
            })
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::{
        atomic::{AtomicUsize, Ordering},
        Mutex,
    };

    static ENV_LOCK: Mutex<()> = Mutex::new(());
    static NEXT_FILE: AtomicUsize = AtomicUsize::new(0);
    const CARD: &str = "# zone\tband_max_grams\tcents\ndomestic\t20000\t1799\ndomestic\t500\t599\ndomestic\t2000\t899\ninternational\t500\t1499\ninternational\t20000\t4999\n";

    fn with_card<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        let _guard = ENV_LOCK.lock().unwrap();
        let path = env::temp_dir().join(format!(
            "ratecard-test-{}-{}.tsv",
            std::process::id(),
            NEXT_FILE.fetch_add(1, Ordering::Relaxed)
        ));
        fs::write(&path, contents).unwrap();
        env::set_var("RATECARD_PATH", &path);
        let result = test();
        env::remove_var("RATECARD_PATH");
        fs::remove_file(path).unwrap();
        result
    }

    #[test]
    fn selects_sorted_band_and_adds_weight_surcharge() {
        with_card(CARD, || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 10_001,
                    zone: "domestic".into()
                }),
                Ok(Quote {
                    base_cents: 1799,
                    surcharge_cents: 500,
                    total_cents: 2299,
                    band_max_grams: 20_000
                })
            )
        });
    }

    #[test]
    fn adds_rounded_international_surcharge() {
        with_card("international\t500\t1499\n", || {
            let result = quote(&Parcel {
                weight_grams: 500,
                zone: "international".into(),
            })
            .unwrap();
            assert_eq!((result.surcharge_cents, result.total_cents), (300, 1799));
        });
    }

    #[test]
    fn distinguishes_unknown_zone_and_overweight() {
        with_card(CARD, || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "lunar".into()
                }),
                Err(QuoteError::UnknownZone("lunar".into()))
            );
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 20_001,
                    zone: "domestic".into()
                }),
                Err(QuoteError::Overweight {
                    grams: 20_001,
                    limit: 20_000
                })
            );
        });
    }

    #[test]
    fn reports_physical_line_for_malformed_card() {
        with_card("# heading\n\ndomestic\tbad\t599\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                }),
                Err(QuoteError::MalformedRateCard { line: 3 })
            )
        });
    }

    #[test]
    fn unavailable_card_is_reported() {
        let _guard = ENV_LOCK.lock().unwrap();
        env::remove_var("RATECARD_PATH");
        assert_eq!(
            quote(&Parcel {
                weight_grams: 1,
                zone: "domestic".into()
            }),
            Err(QuoteError::RateCardUnavailable)
        );
    }
}
