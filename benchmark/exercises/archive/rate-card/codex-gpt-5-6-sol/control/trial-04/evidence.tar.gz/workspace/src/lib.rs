//! Shipping quotes calculated from an operations-managed rate card.

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

/// A parcel to be quoted.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price and selected rate band for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// A failure to load a rate card or quote a parcel from it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighs {grams} grams; zone limit is {limit} grams")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculates a shipping quote using the card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let result = quote_from_card(parcel, &contents)?;

    eprintln!(
        "ratecard_quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, result.total_cents
    );
    Ok(result)
}

fn quote_from_card(parcel: &Parcel, contents: &str) -> Result<Quote, QuoteError> {
    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        }
        let max_grams = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        let cents = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        zones.entry(fields[0].to_owned()).or_default().push(Band { max_grams, cents });
    }

    let bands = zones
        .get_mut(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    bands.sort_unstable_by_key(|band| band.max_grams);

    let limit = bands
        .last()
        .map(|band| band.max_grams)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band = bands.iter().find(|band| band.max_grams >= parcel.weight_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        },
    )?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        ((u128::from(band.cents) * 20 + 50) / 100) as u64
    } else {
        0
    };
    let surcharge_cents = weight_surcharge.saturating_add(international_surcharge);

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t20000\t1799\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_owned(),
        }
    }

    #[test]
    fn selects_the_lowest_matching_band_regardless_of_file_order() {
        let result = quote_from_card(&parcel(500, "domestic"), CARD).unwrap();
        assert_eq!(
            result,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500
            }
        );
    }

    #[test]
    fn adds_weight_and_rounded_international_surcharges() {
        let result = quote_from_card(&parcel(10_001, "international"), CARD).unwrap();
        assert_eq!(
            result,
            Quote {
                base_cents: 4999,
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20_000
            }
        );
    }

    #[test]
    fn reports_unknown_zone_and_zone_specific_limit() {
        assert_eq!(
            quote_from_card(&parcel(1, "moon"), CARD),
            Err(QuoteError::UnknownZone("moon".into()))
        );
        assert_eq!(
            quote_from_card(&parcel(20_001, "domestic"), CARD),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            })
        );
    }

    #[test]
    fn malformed_line_number_counts_comments_and_blanks() {
        let card = "# heading\n\nvalid\t500\t100\nbroken\tvalue\n";
        assert_eq!(
            quote_from_card(&parcel(1, "valid"), card),
            Err(QuoteError::MalformedRateCard { line: 4 })
        );
    }
}
