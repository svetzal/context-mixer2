//! Shipping quote calculation backed by a runtime-configured rate card.

pub mod zones;

use std::error::Error;
use std::fmt;
use std::fs;

/// A parcel to be quoted.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price and selected weight band for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// A failure to load the rate card or quote a parcel from it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds the zone limit of {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    zone: String,
    max_grams: u32,
    cents: u64,
}

/// Calculates a quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = parse_rate_card(&contents)?;
    let result = calculate_quote(parcel, &bands)?;

    eprintln!(
        "quote zone={:?} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, result.total_cents
    );

    Ok(result)
}

fn parse_rate_card(contents: &str) -> Result<Vec<Band>, QuoteError> {
    contents
        .lines()
        .enumerate()
        .filter_map(|(index, line)| {
            let line_number = index + 1;
            if line.is_empty() || line.starts_with('#') {
                return None;
            }

            Some(parse_band(line, line_number))
        })
        .collect()
}

fn parse_band(line: &str, line_number: usize) -> Result<Band, QuoteError> {
    let mut fields = line.split('\t');
    let malformed = || QuoteError::MalformedRateCard { line: line_number };
    let zone = fields.next().filter(|zone| !zone.is_empty()).ok_or_else(malformed)?;
    let max_grams = fields.next().ok_or_else(malformed)?.parse::<u32>().map_err(|_| malformed())?;
    let cents = fields.next().ok_or_else(malformed)?.parse::<u64>().map_err(|_| malformed())?;

    if fields.next().is_some() {
        return Err(malformed());
    }

    Ok(Band {
        zone: zone.to_owned(),
        max_grams,
        cents,
    })
}

fn calculate_quote(parcel: &Parcel, bands: &[Band]) -> Result<Quote, QuoteError> {
    let mut zone_bands: Vec<&Band> = bands.iter().filter(|band| band.zone == parcel.zone).collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|band| band.max_grams);
    let limit = zone_bands.last().expect("zone bands are non-empty").max_grams;
    let band = zone_bands
        .into_iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        // Twenty percent is one fifth; a remainder of 3 or 4 rounds up.
        band.cents / 5 + u64::from(band.cents % 5 >= 3)
    } else {
        0
    };
    let surcharge_cents = weight_surcharge.saturating_add(international_surcharge);

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t20000\t1799\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_owned(),
        }
    }

    #[test]
    fn selects_the_first_matching_band_in_threshold_order() {
        let bands = parse_rate_card(CARD).unwrap();

        let result = calculate_quote(&parcel(500, "domestic"), &bands).unwrap();
        assert_eq!(result.base_cents, 599);
        assert_eq!(result.band_max_grams, 500);

        let result = calculate_quote(&parcel(501, "domestic"), &bands).unwrap();
        assert_eq!(result.base_cents, 899);
        assert_eq!(result.band_max_grams, 2000);
    }

    #[test]
    fn adds_weight_and_rounded_international_surcharges() {
        let bands = parse_rate_card(CARD).unwrap();
        let result = calculate_quote(&parcel(10_001, "international"), &bands).unwrap();

        assert_eq!(result.base_cents, 4999);
        assert_eq!(result.surcharge_cents, 1500);
        assert_eq!(result.total_cents, 6499);
    }

    #[test]
    fn reports_unknown_and_overweight_parcels() {
        let bands = parse_rate_card(CARD).unwrap();

        assert_eq!(
            calculate_quote(&parcel(100, "moon"), &bands),
            Err(QuoteError::UnknownZone("moon".to_owned()))
        );
        assert_eq!(
            calculate_quote(&parcel(20_001, "domestic"), &bands),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            })
        );
    }

    #[test]
    fn malformed_line_number_counts_comments_and_blank_lines() {
        let card = "# heading\n\ndomestic\tnot-a-number\t599\n";
        assert_eq!(parse_rate_card(card), Err(QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn rejects_extra_or_missing_fields() {
        assert_eq!(
            parse_rate_card("domestic\t500\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(
            parse_rate_card("domestic\t500\t599\textra\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }
}
