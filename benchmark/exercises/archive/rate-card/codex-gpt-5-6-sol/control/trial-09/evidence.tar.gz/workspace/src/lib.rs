//! Shipping quote calculation backed by an operations-managed rate card.

use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

/// A parcel to be quoted.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Rate-card zone used to ship the parcel.
    pub zone: String,
}

/// The price and selected rate band for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Price of the matching weight band, before surcharges.
    pub base_cents: u64,
    /// Sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// Final price, including surcharges.
    pub total_cents: u64,
    /// Upper weight threshold of the selected band.
    pub band_max_grams: u32,
}

/// A failure to load a rate card or calculate a quote from it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The configured rate card could not be located or read.
    RateCardUnavailable,
    /// A non-comment line in the rate card was invalid.
    MalformedRateCard { line: usize },
    /// The requested zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel exceeds the largest band for its zone.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => write!(
                formatter,
                "parcel weighs {grams} grams, exceeding the zone limit of {limit} grams"
            ),
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    zone: String,
    max_grams: u32,
    cents: u64,
}

/// Calculates a shipping quote using the file named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = parse_rate_card(&contents)?;
    let result = calculate_quote(parcel, &bands)?;

    eprintln!(
        "ratecard.quote zone={:?} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, result.total_cents
    );

    Ok(result)
}

fn parse_rate_card(contents: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();

    for (index, line) in contents.lines().enumerate() {
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let zone = fields.next();
        let max_grams = fields.next();
        let cents = fields.next();
        if zone.is_none() || max_grams.is_none() || cents.is_none() || fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        }

        let max_grams = max_grams
            .expect("field count checked")
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        let cents = cents
            .expect("field count checked")
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        bands.push(Band {
            zone: zone.expect("field count checked").to_owned(),
            max_grams,
            cents,
        });
    }

    bands.sort_by_key(|band| band.max_grams);
    Ok(bands)
}

fn calculate_quote(parcel: &Parcel, bands: &[Band]) -> Result<Quote, QuoteError> {
    let zone_bands: Vec<&Band> = bands.iter().filter(|band| band.zone == parcel.zone).collect();
    let limit = zone_bands
        .last()
        .map(|band| band.max_grams)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band = zone_bands
        .into_iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        let whole_cents = band.cents / 5;
        let rounded_fraction = u64::from(band.cents % 5 >= 3);
        whole_cents + rounded_fraction
    } else {
        0
    };
    let surcharge_cents = weight_surcharge.saturating_add(international_surcharge);
    let total_cents = band.cents.saturating_add(surcharge_cents);

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t20000\t1799\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_owned(),
        }
    }

    #[test]
    fn selects_the_smallest_applicable_band_even_when_input_is_unsorted() {
        let bands = parse_rate_card(CARD).unwrap();

        let result = calculate_quote(&parcel(501, "domestic"), &bands).unwrap();

        assert_eq!(
            result,
            Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2000,
            }
        );
    }

    #[test]
    fn combines_weight_and_rounded_international_surcharges() {
        let bands = parse_rate_card(CARD).unwrap();

        let result = calculate_quote(&parcel(10_001, "international"), &bands).unwrap();

        assert_eq!(result.base_cents, 4999);
        assert_eq!(result.surcharge_cents, 1500);
        assert_eq!(result.total_cents, 6499);
    }

    #[test]
    fn reports_unknown_zones_and_zone_specific_weight_limits() {
        let bands = parse_rate_card(CARD).unwrap();

        assert_eq!(
            calculate_quote(&parcel(1, "moon"), &bands),
            Err(QuoteError::UnknownZone("moon".to_owned()))
        );
        assert_eq!(
            calculate_quote(&parcel(20_001, "domestic"), &bands),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            })
        );
    }

    #[test]
    fn malformed_line_numbers_include_comments_and_blanks() {
        let card = "# heading\n\nvalid\t500\t100\nbroken\tvalue\n";

        assert_eq!(parse_rate_card(card), Err(QuoteError::MalformedRateCard { line: 4 }));
    }
}
