//! Shipping quotes calculated from an operations-managed rate card.

use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

/// A parcel to price.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price and rate band selected for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// A failure to load or apply the rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

/// Calculate a shipping quote using the file named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let rate_card = RateCard::parse(&contents)?;
    let quote = rate_card.quote(parcel)?;

    emit_quote_diagnostic(parcel, &quote);
    Ok(quote)
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    zone: String,
    max_grams: u32,
    cents: u64,
}

struct RateCard {
    bands: Vec<Band>,
}

impl RateCard {
    fn parse(contents: &str) -> Result<Self, QuoteError> {
        let mut bands = Vec::new();

        for (index, line) in contents.lines().enumerate() {
            let trimmed = line.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }

            let fields: Vec<_> = line.split('\t').collect();
            if fields.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: index + 1 });
            }

            let max_grams = fields[1]
                .trim()
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
            let cents = fields[2]
                .trim()
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
            bands.push(Band {
                zone: fields[0].trim().to_owned(),
                max_grams,
                cents,
            });
        }

        bands.sort_by_key(|band| band.max_grams);
        Ok(Self { bands })
    }

    fn quote(&self, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let zone_bands: Vec<_> =
            self.bands.iter().filter(|band| band.zone == parcel.zone).collect();

        let limit = zone_bands
            .last()
            .map(|band| band.max_grams)
            .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
        let band = zone_bands
            .into_iter()
            .find(|band| band.max_grams >= parcel.weight_grams)
            .ok_or(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            })?;

        let surcharge_cents = surcharge(parcel, band.cents);
        Ok(Quote {
            base_cents: band.cents,
            surcharge_cents,
            total_cents: band.cents + surcharge_cents,
            band_max_grams: band.max_grams,
        })
    }
}

fn surcharge(parcel: &Parcel, base_cents: u64) -> u64 {
    let weight = u64::from(parcel.weight_grams > 10_000) * 500;
    let international = if parcel.zone == "international" {
        // Calculate in a wider type so every valid base price can be rounded safely.
        ((u128::from(base_cents) * 20 + 50) / 100) as u64
    } else {
        0
    };
    weight + international
}

fn emit_quote_diagnostic(parcel: &Parcel, quote: &Quote) {
    eprintln!(
        "ratecard_quote zone={:?} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, quote.total_cents
    );
}

#[cfg(test)]
mod tests {
    use super::*;

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t2000\t899\n\
domestic\t500\t599\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    #[test]
    fn selects_first_matching_band_after_sorting() {
        let card = RateCard::parse(CARD).unwrap();
        let result = card
            .quote(&Parcel {
                weight_grams: 501,
                zone: "domestic".to_owned(),
            })
            .unwrap();

        assert_eq!(result.base_cents, 899);
        assert_eq!(result.band_max_grams, 2000);
        assert_eq!(result.total_cents, 899);
    }

    #[test]
    fn adds_weight_and_rounded_international_surcharges() {
        let card = RateCard::parse(CARD).unwrap();
        let result = card
            .quote(&Parcel {
                weight_grams: 10_001,
                zone: "international".to_owned(),
            })
            .unwrap();

        assert_eq!(result.base_cents, 4999);
        assert_eq!(result.surcharge_cents, 1500);
        assert_eq!(result.total_cents, 6499);
    }

    #[test]
    fn reports_unknown_zone_and_overweight_separately() {
        let card = RateCard::parse(CARD).unwrap();
        assert_eq!(
            card.quote(&Parcel {
                weight_grams: 1,
                zone: "moon".to_owned(),
            }),
            Err(QuoteError::UnknownZone("moon".to_owned()))
        );
        assert_eq!(
            card.quote(&Parcel {
                weight_grams: 20_001,
                zone: "domestic".to_owned(),
            }),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            })
        );
    }

    #[test]
    fn malformed_line_number_counts_comments_and_blanks() {
        let error = RateCard::parse("# heading\n\ndomestic\tnot-a-number\t500\n").err();
        assert_eq!(error, Some(QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn rejects_wrong_field_count() {
        let error = RateCard::parse("domestic\t500\n").err();
        assert_eq!(error, Some(QuoteError::MalformedRateCard { line: 1 }));
    }
}
