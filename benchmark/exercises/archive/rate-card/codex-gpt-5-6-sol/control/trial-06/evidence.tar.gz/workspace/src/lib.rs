//! Shipping quote calculation backed by an operations-managed rate card.

use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

/// A parcel to be priced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price selected for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// A failure to load the rate card or price a parcel from it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    zone: String,
    max_grams: u32,
    cents: u64,
}

/// Calculates a quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let result = calculate_quote(parcel, &parse_rate_card(&contents)?)?;

    // Keep the operational event dependency-free and machine-readable.
    eprintln!(
        "quote zone={:?} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, result.total_cents
    );

    Ok(result)
}

fn parse_rate_card(contents: &str) -> Result<Vec<Band>, QuoteError> {
    contents
        .lines()
        .enumerate()
        .filter_map(|(index, line)| {
            let line_number = index + 1;
            if line.is_empty() || line.starts_with('#') {
                return None;
            }

            Some(parse_band(line, line_number))
        })
        .collect()
}

fn parse_band(line: &str, line_number: usize) -> Result<Band, QuoteError> {
    let mut fields = line.split('\t');
    let malformed = || QuoteError::MalformedRateCard { line: line_number };
    let zone = fields.next().ok_or_else(malformed)?;
    let max_grams = fields.next().ok_or_else(malformed)?.parse().map_err(|_| malformed())?;
    let cents = fields.next().ok_or_else(malformed)?.parse().map_err(|_| malformed())?;

    if zone.is_empty() || fields.next().is_some() {
        return Err(malformed());
    }

    Ok(Band {
        zone: zone.to_owned(),
        max_grams,
        cents,
    })
}

fn calculate_quote(parcel: &Parcel, bands: &[Band]) -> Result<Quote, QuoteError> {
    let mut zone_bands: Vec<&Band> = bands.iter().filter(|band| band.zone == parcel.zone).collect();
    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }
    zone_bands.sort_by_key(|band| band.max_grams);

    let limit = zone_bands.last().expect("zone bands are non-empty").max_grams;
    let band = zone_bands
        .into_iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    // Integer arithmetic gives exact round-half-up behavior for a 20% surcharge.
    let international_surcharge = if parcel.zone == "international" {
        (band.cents * 20 + 50) / 100
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t20000\t1799\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    fn calculate(weight_grams: u32, zone: &str) -> Result<Quote, QuoteError> {
        let parcel = Parcel {
            weight_grams,
            zone: zone.to_owned(),
        };
        calculate_quote(&parcel, &parse_rate_card(CARD).unwrap())
    }

    #[test]
    fn selects_the_first_band_in_threshold_order() {
        let result = calculate(501, "domestic").unwrap();
        assert_eq!(result.base_cents, 899);
        assert_eq!(result.band_max_grams, 2_000);
        assert_eq!(result.total_cents, 899);
    }

    #[test]
    fn band_threshold_is_inclusive() {
        assert_eq!(calculate(500, "domestic").unwrap().base_cents, 599);
    }

    #[test]
    fn surcharges_are_additive_and_international_is_rounded_half_up() {
        let result = calculate(10_001, "international").unwrap();
        assert_eq!(result.base_cents, 4_999);
        assert_eq!(result.surcharge_cents, 1_500);
        assert_eq!(result.total_cents, 6_499);
    }

    #[test]
    fn weight_surcharge_is_strictly_above_ten_kilograms() {
        assert_eq!(calculate(10_000, "domestic").unwrap().surcharge_cents, 0);
        assert_eq!(calculate(10_001, "domestic").unwrap().surcharge_cents, 500);
    }

    #[test]
    fn reports_unknown_zone_verbatim() {
        assert_eq!(calculate(100, "moon"), Err(QuoteError::UnknownZone("moon".to_owned())));
    }

    #[test]
    fn reports_zone_specific_overweight_limit() {
        assert_eq!(
            calculate(20_001, "domestic"),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            })
        );
    }

    #[test]
    fn malformed_line_numbers_include_ignored_lines() {
        let card = "# comment\n\nbad\tdata\n";
        assert_eq!(parse_rate_card(card), Err(QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn rejects_extra_fields_and_invalid_numbers() {
        assert_eq!(
            parse_rate_card("domestic\t500\t599\textra"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(
            parse_rate_card("domestic\tmany\t599"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn public_quote_reads_the_configured_file() {
        let path =
            std::env::temp_dir().join(format!("ratecard-test-{}-rates.tsv", std::process::id()));
        fs::write(&path, CARD).unwrap();
        std::env::set_var("RATECARD_PATH", &path);

        let result = quote(&Parcel {
            weight_grams: 400,
            zone: "domestic".to_owned(),
        })
        .unwrap();

        std::env::remove_var("RATECARD_PATH");
        fs::remove_file(path).unwrap();
        assert_eq!(result.total_cents, 599);
    }
}
