//! Parsing and lookup for zone-specific rate bands.

use std::collections::HashMap;

use crate::QuoteError;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct Band {
    pub(crate) max_grams: u32,
    pub(crate) cents: u64,
}

pub(crate) type RateCard = HashMap<String, Vec<Band>>;

pub(crate) fn parse(contents: &str) -> Result<RateCard, QuoteError> {
    let mut card: RateCard = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let (Some(zone), Some(max_grams), Some(cents), None) =
            (fields.next(), fields.next(), fields.next(), fields.next())
        else {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        };

        let max_grams = max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents =
            cents.parse().map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        card.entry(zone.to_owned()).or_default().push(Band { max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(card)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sorts_bands_within_each_zone() {
        let card = parse("domestic\t2000\t899\ndomestic\t500\t599\n").unwrap();

        assert_eq!(card["domestic"][0].max_grams, 500);
    }

    #[test]
    fn malformed_line_reports_physical_line_number() {
        let error = parse("# heading\n\ndomestic\tnot-a-number\t599\n").unwrap_err();

        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
    }
}
