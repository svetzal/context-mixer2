//! Shipping quote calculation backed by an operational rate-card file.

mod zones;

use std::env;
use std::fmt;
use std::fs;

/// A parcel to price against the current rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The itemized price of shipping a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// A failure to load a rate card or quote the requested parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Calculates a shipping quote using the file named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = zones::parse(&contents)?;

    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band =
        bands.iter().find(|band| band.max_grams >= parcel.weight_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands.last().map_or(0, |band| band.max_grams),
            }
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let zone_surcharge = if parcel.zone == "international" {
        band.cents.saturating_mul(20).saturating_add(50) / 100
    } else {
        0
    };
    let surcharge_cents = weight_surcharge.saturating_add(zone_surcharge);
    let total_cents = band.cents.saturating_add(surcharge_cents);
    let result = Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    };

    eprintln!(
        "ratecard_quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, result.total_cents
    );

    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;
    use std::sync::atomic::{AtomicU64, Ordering};
    use std::sync::Mutex;

    static RATECARD_ENV: Mutex<()> = Mutex::new(());
    static NEXT_FILE: AtomicU64 = AtomicU64::new(0);

    fn temporary_card_path() -> PathBuf {
        let sequence = NEXT_FILE.fetch_add(1, Ordering::Relaxed);
        env::temp_dir().join(format!("ratecard-{}-{sequence}.tsv", std::process::id()))
    }

    fn with_card<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        let _guard = RATECARD_ENV.lock().unwrap();
        let path = temporary_card_path();
        fs::write(&path, contents).unwrap();
        let previous = env::var_os("RATECARD_PATH");
        env::set_var("RATECARD_PATH", &path);
        let result = test();
        match previous {
            Some(value) => env::set_var("RATECARD_PATH", value),
            None => env::remove_var("RATECARD_PATH"),
        }
        fs::remove_file(path).unwrap();
        result
    }

    #[test]
    fn chooses_first_eligible_band_from_an_unsorted_card() {
        with_card("domestic\t20000\t1799\ndomestic\t500\t599\ndomestic\t2000\t899\n", || {
            let result = quote(&Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(
                result,
                Quote {
                    base_cents: 899,
                    surcharge_cents: 0,
                    total_cents: 899,
                    band_max_grams: 2000
                }
            );
        });
    }

    #[test]
    fn adds_weight_and_rounded_international_surcharges() {
        with_card("international\t20000\t1499\n", || {
            let result = quote(&Parcel {
                weight_grams: 10_001,
                zone: "international".into(),
            })
            .unwrap();
            assert_eq!(result.surcharge_cents, 800);
            assert_eq!(result.total_cents, 2299);
        });
    }

    #[test]
    fn distinguishes_unknown_zone_and_overweight() {
        with_card("domestic\t500\t599\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "remote".into()
                }),
                Err(QuoteError::UnknownZone("remote".into()))
            );
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 501,
                    zone: "domestic".into()
                }),
                Err(QuoteError::Overweight {
                    grams: 501,
                    limit: 500
                })
            );
        });
    }

    #[test]
    fn unavailable_path_has_a_dedicated_error() {
        let _guard = RATECARD_ENV.lock().unwrap();
        let previous = env::var_os("RATECARD_PATH");
        env::remove_var("RATECARD_PATH");
        let result = quote(&Parcel {
            weight_grams: 1,
            zone: "domestic".into(),
        });
        if let Some(value) = previous {
            env::set_var("RATECARD_PATH", value);
        }
        assert_eq!(result, Err(QuoteError::RateCardUnavailable));
    }
}
