//! Shipping quotes calculated from an operations-managed rate card.

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

/// A parcel to be quoted.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// The parcel's weight in grams.
    pub weight_grams: u32,
    /// The rate-card zone to use.
    pub zone: String,
}

/// The calculated shipping price for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Price of the matching weight band, before surcharges.
    pub base_cents: u64,
    /// Sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// Final price, including surcharges.
    pub total_cents: u64,
    /// Upper weight threshold of the matching band.
    pub band_max_grams: u32,
}

/// A failure to load the rate card or calculate a quote from it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The configured rate card could not be read.
    RateCardUnavailable,
    /// A non-comment line in the rate card was invalid.
    MalformedRateCard { line: usize },
    /// The requested zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel exceeds the requested zone's largest band.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculates a shipping quote using the rate card at `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let rate_card = parse_rate_card(&contents)?;

    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band =
        bands.iter().find(|band| band.max_grams >= parcel.weight_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands.last().expect("rate-card zones have bands").max_grams,
            }
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    // Integer division rounds down, so adding half the denominator implements
    // round-half-up without using floating point.
    let international_surcharge = if parcel.zone == "international" {
        band.cents.saturating_mul(20).saturating_add(50) / 100
    } else {
        0
    };
    let surcharge_cents = weight_surcharge.saturating_add(international_surcharge);
    let total_cents = band.cents.saturating_add(surcharge_cents);

    eprintln!(
        "ratecard_quote zone={:?} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut rate_card: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let (Some(zone), Some(max_grams), Some(cents), None) =
            (fields.next(), fields.next(), fields.next(), fields.next())
        else {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        };

        let max_grams = max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        let cents = cents.parse().map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;

        rate_card.entry(zone.to_owned()).or_default().push(Band { max_grams, cents });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(rate_card)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;
    use std::sync::atomic::{AtomicU64, Ordering};
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());
    static NEXT_FILE_ID: AtomicU64 = AtomicU64::new(0);

    struct TestRateCard {
        path: PathBuf,
    }

    impl TestRateCard {
        fn new(contents: &str) -> Self {
            let id = NEXT_FILE_ID.fetch_add(1, Ordering::Relaxed);
            let path = env::temp_dir().join(format!("ratecard-{}-{id}.tsv", std::process::id()));
            fs::write(&path, contents).expect("write temporary rate card");
            Self { path }
        }
    }

    impl Drop for TestRateCard {
        fn drop(&mut self) {
            let _ = fs::remove_file(&self.path);
        }
    }

    fn with_rate_card<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        let _guard = ENV_LOCK.lock().expect("environment lock should be usable");
        let file = TestRateCard::new(contents);
        let previous = env::var_os("RATECARD_PATH");
        env::set_var("RATECARD_PATH", &file.path);
        let result = test();
        match previous {
            Some(value) => env::set_var("RATECARD_PATH", value),
            None => env::remove_var("RATECARD_PATH"),
        }
        result
    }

    const CARD: &str = "# zone\tband_max_grams\tcents\n\n\
domestic\t20000\t1799\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    #[test]
    fn selects_the_first_band_in_weight_order() {
        with_rate_card(CARD, || {
            let result = quote(&Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            })
            .expect("quote should succeed");

            assert_eq!(result.base_cents, 899);
            assert_eq!(result.band_max_grams, 2000);
            assert_eq!(result.surcharge_cents, 0);
            assert_eq!(result.total_cents, 899);
        });
    }

    #[test]
    fn adds_weight_and_international_surcharges() {
        with_rate_card(CARD, || {
            let result = quote(&Parcel {
                weight_grams: 10_001,
                zone: "international".into(),
            })
            .expect("quote should succeed");

            assert_eq!(result.base_cents, 4999);
            assert_eq!(result.surcharge_cents, 1500);
            assert_eq!(result.total_cents, 6499);
        });
    }

    #[test]
    fn reports_unknown_zone_and_overweight() {
        with_rate_card(CARD, || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "lunar".into(),
                }),
                Err(QuoteError::UnknownZone("lunar".into()))
            );
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 20_001,
                    zone: "domestic".into(),
                }),
                Err(QuoteError::Overweight {
                    grams: 20_001,
                    limit: 20_000,
                })
            );
        });
    }

    #[test]
    fn malformed_line_number_counts_comments_and_blanks() {
        with_rate_card("# comment\n\ndomestic\tnot-a-number\t599\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".into(),
                }),
                Err(QuoteError::MalformedRateCard { line: 3 })
            );
        });
    }

    #[test]
    fn unavailable_card_is_reported() {
        let _guard = ENV_LOCK.lock().expect("environment lock should be usable");
        let previous = env::var_os("RATECARD_PATH");
        env::remove_var("RATECARD_PATH");
        assert_eq!(
            quote(&Parcel {
                weight_grams: 1,
                zone: "domestic".into(),
            }),
            Err(QuoteError::RateCardUnavailable)
        );
        if let Some(value) = previous {
            env::set_var("RATECARD_PATH", value);
        }
    }

    #[test]
    fn quote_errors_are_standard_errors() {
        let error: &dyn Error = &QuoteError::MalformedRateCard { line: 7 };
        assert_eq!(error.to_string(), "malformed rate card at line 7");
    }
}
