pub mod zones;

use std::{env, error::Error, fmt, fs};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighs {grams} grams, exceeding the {limit} gram limit")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    zone: String,
    max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = parse_rate_card(&contents)?;
    let result = calculate_quote(parcel, &bands)?;

    eprintln!(
        "event=shipping_quote zone={:?} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, result.total_cents
    );
    Ok(result)
}

fn parse_rate_card(contents: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();
    for (index, line) in contents.lines().enumerate() {
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let (Some(zone), Some(max_grams), Some(cents), None) =
            (fields.next(), fields.next(), fields.next(), fields.next())
        else {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        };
        let max_grams = max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        let cents = cents.parse().map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        bands.push(Band {
            zone: zone.to_owned(),
            max_grams,
            cents,
        });
    }
    bands.sort_by_key(|band| band.max_grams);
    Ok(bands)
}

fn calculate_quote(parcel: &Parcel, bands: &[Band]) -> Result<Quote, QuoteError> {
    let zone_bands: Vec<_> = bands.iter().filter(|band| band.zone == parcel.zone).collect();
    let limit = zone_bands
        .last()
        .map(|band| band.max_grams)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band = zone_bands
        .into_iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        // Twenty percent is one fifth; 3/5 and 4/5 round up.
        band.cents / 5 + u64::from(band.cents % 5 >= 3)
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;
    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    const CARD: &str = "# heading\n\
domestic\t20000\t1799\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    fn card() -> Vec<Band> {
        parse_rate_card(CARD).unwrap()
    }

    #[test]
    fn selects_first_matching_band_in_threshold_order() {
        let result = calculate_quote(
            &Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            },
            &card(),
        )
        .unwrap();
        assert_eq!(
            result,
            Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2000
            }
        );
    }

    #[test]
    fn surcharges_add_and_international_percentage_rounds_half_up() {
        let result = calculate_quote(
            &Parcel {
                weight_grams: 10_001,
                zone: "international".into(),
            },
            &card(),
        )
        .unwrap();
        assert_eq!(result.surcharge_cents, 1500);
        assert_eq!(result.total_cents, 6499);
    }

    #[test]
    fn distinguishes_unknown_zones_from_overweight_parcels() {
        assert_eq!(
            calculate_quote(
                &Parcel {
                    weight_grams: 1,
                    zone: "moon".into()
                },
                &card()
            ),
            Err(QuoteError::UnknownZone("moon".into()))
        );
        assert_eq!(
            calculate_quote(
                &Parcel {
                    weight_grams: 20_001,
                    zone: "domestic".into()
                },
                &card()
            ),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            })
        );
    }

    #[test]
    fn malformed_line_number_counts_comments_and_blanks() {
        assert_eq!(
            parse_rate_card("# comment\n\nvalid\t500\t100\nbroken line\n"),
            Err(QuoteError::MalformedRateCard { line: 4 })
        );
    }

    #[test]
    fn rejects_invalid_numbers_and_extra_fields() {
        assert_eq!(
            parse_rate_card("domestic\theavy\t500\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(
            parse_rate_card("domestic\t500\t100\textra\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }
}
