//! Shipping quote calculation backed by a tab-separated rate card.

use std::{collections::HashMap, env, fmt, fs};

pub mod zones;

/// A parcel for which a shipping quote is requested.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Destination zone named by the rate card.
    pub zone: String,
}

/// The selected rate band and the resulting price.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Price from the selected rate-card band.
    pub base_cents: u64,
    /// Combined surcharges applied to the base price.
    pub surcharge_cents: u64,
    /// Final price in cents.
    pub total_cents: u64,
    /// Inclusive upper weight threshold of the selected band.
    pub band_max_grams: u32,
}

/// Failures that can occur while loading a rate card or pricing a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate-card location is absent or cannot be read.
    RateCardUnavailable,
    /// A rate-card line does not have the required tab-separated shape.
    MalformedRateCard {
        /// One-based line number in the rate card.
        line: usize,
    },
    /// The requested zone has no rate-card bands.
    UnknownZone(String),
    /// The parcel exceeds the heaviest band available for its zone.
    Overweight {
        /// Requested parcel weight in grams.
        grams: u32,
        /// Heaviest permitted band for the zone in grams.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighing {grams}g exceeds the {limit}g limit")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

type RateCard = HashMap<String, Vec<Band>>;

/// Calculate a quote using the rate card named by the `RATECARD_PATH` environment variable.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let rate_card = parse_rate_card(&contents)?;
    let result = calculate_quote(&rate_card, parcel)?;

    eprintln!(
        "shipping quote calculated zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, result.total_cents
    );

    Ok(result)
}

fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut rate_card: RateCard = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let zone = fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let max_grams = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        rate_card.entry(zone.to_owned()).or_default().push(Band { max_grams, cents });
    }

    for bands in rate_card.values_mut() {
        bands.sort_unstable_by_key(|band| band.max_grams);
    }

    Ok(rate_card)
}

fn calculate_quote(rate_card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let limit = bands.last().map_or(0, |band| band.max_grams);
    let band = bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        },
    )?;

    let heavy_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        band.cents / 5 + u64::from(band.cents % 5 >= 3)
    } else {
        0
    };
    let surcharge_cents = heavy_surcharge + international_surcharge;

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::{
        sync::{Mutex, OnceLock},
        time::{SystemTime, UNIX_EPOCH},
    };

    fn ratecard_path_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    #[test]
    fn parses_and_sorts_bands_by_weight() {
        let card = parse_rate_card("domestic\t2000\t899\ndomestic\t500\t599\n").unwrap();
        let quote = calculate_quote(
            &card,
            &Parcel {
                weight_grams: 500,
                zone: "domestic".to_owned(),
            },
        )
        .unwrap();

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn combines_heavy_and_international_surcharges() {
        let card = parse_rate_card("international\t20000\t4999\n").unwrap();
        let quote = calculate_quote(
            &card,
            &Parcel {
                weight_grams: 10_001,
                zone: "international".to_owned(),
            },
        )
        .unwrap();

        assert_eq!(quote.surcharge_cents, 1_500);
        assert_eq!(quote.total_cents, 6_499);
    }

    #[test]
    fn rounds_international_surcharge_half_up() {
        let card = parse_rate_card("international\t500\t3\n").unwrap();
        let quote = calculate_quote(
            &card,
            &Parcel {
                weight_grams: 1,
                zone: "international".to_owned(),
            },
        )
        .unwrap();

        assert_eq!(quote.surcharge_cents, 1);
    }

    #[test]
    fn reports_malformed_line_numbers_including_comments() {
        let error = parse_rate_card("# header\n\ndomestic\tnot-a-number\t599\n").unwrap_err();

        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn reports_unknown_and_overweight_zones() {
        let card = parse_rate_card("domestic\t500\t599\n").unwrap();
        let unknown = calculate_quote(
            &card,
            &Parcel {
                weight_grams: 1,
                zone: "elsewhere".to_owned(),
            },
        );
        let overweight = calculate_quote(
            &card,
            &Parcel {
                weight_grams: 501,
                zone: "domestic".to_owned(),
            },
        );

        assert_eq!(unknown, Err(QuoteError::UnknownZone("elsewhere".to_owned())));
        assert_eq!(
            overweight,
            Err(QuoteError::Overweight {
                grams: 501,
                limit: 500
            })
        );
    }

    #[test]
    fn loads_the_rate_card_from_the_configured_path() {
        let _lock = ratecard_path_lock().lock().unwrap();
        let unique_id = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos();
        let path =
            env::temp_dir().join(format!("ratecard-test-{}-{unique_id}", std::process::id()));
        fs::write(&path, "domestic\t500\t599\n").unwrap();
        env::set_var("RATECARD_PATH", &path);

        let result = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".to_owned(),
        });

        env::remove_var("RATECARD_PATH");
        fs::remove_file(path).unwrap();
        assert_eq!(
            result,
            Ok(Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            })
        );
    }
}
