//! Shipping quote calculation backed by an operator-maintained rate card.

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

/// A parcel to price against the configured rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The itemized price of a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Failures that can occur while finding or applying a rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed on line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighing {grams}g exceeds the {limit}g limit")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculate a shipping quote from the rate card selected by `RATECARD_PATH`.
#[tracing::instrument(
    name = "ratecard.quote",
    fields(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = tracing::field::Empty
    )
)]
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = read_rate_card()?;
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band =
        bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands.last().map_or(0, |band| band.max_grams),
            }
        })?;

    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        // One fifth of the base price, rounded half-up without multiplying a u64.
        let international_surcharge = band.cents / 5 + u64::from(band.cents % 5 >= 3);
        surcharge_cents = surcharge_cents.saturating_add(international_surcharge);
    }

    let quote = Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    };

    tracing::Span::current().record("total_cents", quote.total_cents);
    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = quote.total_cents,
        "shipping quote calculated"
    );

    Ok(quote)
}

fn read_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let mut rate_card: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let max_grams = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        rate_card
            .entry(fields[0].to_owned())
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(rate_card)
}

/// Return the human-friendly label for a known shipping zone.
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::sync::{Mutex, OnceLock};

    static ENV_LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    static TEMP_FILE_ID: AtomicUsize = AtomicUsize::new(0);

    struct RateCardEnvironment {
        path: PathBuf,
        previous: Option<std::ffi::OsString>,
    }

    impl Drop for RateCardEnvironment {
        fn drop(&mut self) {
            if let Some(path) = self.previous.take() {
                env::set_var("RATECARD_PATH", path);
            } else {
                env::remove_var("RATECARD_PATH");
            }
            let _ = fs::remove_file(&self.path);
        }
    }

    fn with_rate_card<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        let _guard = ENV_LOCK
            .get_or_init(|| Mutex::new(()))
            .lock()
            .unwrap_or_else(|error| panic!("environment test lock was poisoned: {error}"));
        let path = env::temp_dir().join(format!(
            "ratecard-test-{}-{}",
            std::process::id(),
            TEMP_FILE_ID.fetch_add(1, Ordering::Relaxed)
        ));
        fs::write(&path, contents)
            .unwrap_or_else(|error| panic!("failed to write test rate card: {error}"));
        let _environment = RateCardEnvironment {
            path: path.clone(),
            previous: env::var_os("RATECARD_PATH"),
        };
        env::set_var("RATECARD_PATH", path);
        test()
    }

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t2000\t899\n\
domestic\t500\t599\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    #[test]
    fn selects_the_first_matching_band_in_threshold_order() {
        with_rate_card(CARD, || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 501,
                    zone: "domestic".into(),
                }),
                Ok(Quote {
                    base_cents: 899,
                    surcharge_cents: 0,
                    total_cents: 899,
                    band_max_grams: 2000,
                })
            );
        });
    }

    #[test]
    fn combines_weight_and_international_surcharges() {
        with_rate_card(CARD, || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 10_001,
                    zone: "international".into(),
                }),
                Ok(Quote {
                    base_cents: 4999,
                    surcharge_cents: 1500,
                    total_cents: 6499,
                    band_max_grams: 20_000,
                })
            );
        });
    }

    #[test]
    fn reports_unknown_zone_and_overweight_parcels() {
        with_rate_card(CARD, || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 10,
                    zone: "missing".into(),
                }),
                Err(QuoteError::UnknownZone("missing".into()))
            );
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 20_001,
                    zone: "domestic".into(),
                }),
                Err(QuoteError::Overweight {
                    grams: 20_001,
                    limit: 20_000,
                })
            );
        });
    }

    #[test]
    fn identifies_malformed_lines_by_physical_line_number() {
        with_rate_card("# heading\n\ndomestic\t500\t599\nbad\tnope\t100\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                }),
                Err(QuoteError::MalformedRateCard { line: 4 })
            );
        });
    }

    #[test]
    fn reports_an_unavailable_rate_card() {
        let _guard = ENV_LOCK
            .get_or_init(|| Mutex::new(()))
            .lock()
            .unwrap_or_else(|error| panic!("environment test lock was poisoned: {error}"));
        let previous = env::var_os("RATECARD_PATH");
        env::remove_var("RATECARD_PATH");
        assert_eq!(
            quote(&Parcel {
                weight_grams: 1,
                zone: "domestic".into()
            }),
            Err(QuoteError::RateCardUnavailable)
        );
        if let Some(path) = previous {
            env::set_var("RATECARD_PATH", path);
        }
    }
}
