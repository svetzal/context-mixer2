//! Shipping quote calculation from an operations-maintained rate card.

use std::{env, error::Error, fmt, fs, path::PathBuf};

pub mod zones;

/// A parcel for which a shipping quote is requested.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// The parcel's weight in grams.
    pub weight_grams: u32,
    /// The destination zone as named in the rate card.
    pub zone: String,
}

/// The calculated price and rate band selected for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// The price from the selected rate band, before surcharges.
    pub base_cents: u64,
    /// The combined surcharges applied to the base price.
    pub surcharge_cents: u64,
    /// The final price, including all surcharges.
    pub total_cents: u64,
    /// The upper weight limit of the selected rate band.
    pub band_max_grams: u32,
}

/// A failure encountered while loading a rate card or selecting a quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The configured rate card could not be located or read.
    RateCardUnavailable,
    /// A rate-card record did not have the required tab-separated shape.
    MalformedRateCard {
        /// The one-based source line containing the invalid record.
        line: usize,
    },
    /// The requested zone is not represented in the rate card.
    UnknownZone(String),
    /// The parcel exceeds the heaviest band for its zone.
    Overweight {
        /// The parcel's requested weight.
        grams: u32,
        /// The highest supported weight for the requested zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight of {grams} grams exceeds the {limit}-gram limit")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug)]
struct RateBand {
    max_grams: u32,
    cents: u64,
}

/// Calculate a shipping quote using the rate card at `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = load_rate_card()?;
    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band =
        bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands.last().expect("a configured zone has a band").max_grams,
            }
        })?;

    let surcharge_cents = weight_surcharge(parcel.weight_grams)
        .saturating_add(international_surcharge(&parcel.zone, band.cents));
    let result = Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    };

    emit_quote_diagnostic(parcel, &result);
    Ok(result)
}

fn load_rate_card() -> Result<std::collections::HashMap<String, Vec<RateBand>>, QuoteError> {
    let path = rate_card_path()?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn rate_card_path() -> Result<PathBuf, QuoteError> {
    env::var_os("RATECARD_PATH")
        .filter(|path| !path.is_empty())
        .map(PathBuf::from)
        .ok_or(QuoteError::RateCardUnavailable)
}

fn parse_rate_card(
    contents: &str,
) -> Result<std::collections::HashMap<String, Vec<RateBand>>, QuoteError> {
    let mut card: std::collections::HashMap<String, Vec<RateBand>> =
        std::collections::HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let Some(zone) = fields.next() else {
            unreachable!("a non-empty line has a first field")
        };
        let Some(max_grams) = fields.next() else {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        };
        let Some(cents) = fields.next() else {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        };
        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        }

        let max_grams = max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        let cents = cents.parse().map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        card.entry(zone.to_owned()).or_default().push(RateBand { max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }
    Ok(card)
}

fn weight_surcharge(weight_grams: u32) -> u64 {
    u64::from(weight_grams > 10_000) * 500
}

fn international_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone != "international" {
        return 0;
    }

    // Calculate 20% as one fifth without multiplying a potentially large
    // price. A remainder of three or four fifths rounds up under half-up.
    (base_cents / 5) + u64::from(base_cents % 5 >= 3)
}

fn emit_quote_diagnostic(parcel: &Parcel, quote: &Quote) {
    eprintln!(
        "ratecard.quote zone={:?} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, quote.total_cents
    );
}

#[cfg(test)]
mod tests {
    use std::{
        env, fs,
        sync::{
            atomic::{AtomicUsize, Ordering},
            Mutex,
        },
    };

    use super::{quote, Parcel, Quote, QuoteError};

    static ENV_LOCK: Mutex<()> = Mutex::new(());
    static TEMP_FILE_SEQUENCE: AtomicUsize = AtomicUsize::new(0);

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t2000\t899\n\
domestic\t500\t599\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    fn with_card<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        let _lock = ENV_LOCK.lock().expect("environment lock poisoned");
        let old_path = env::var_os("RATECARD_PATH");
        let path = env::temp_dir().join(format!(
            "ratecard-test-{}-{}",
            std::process::id(),
            TEMP_FILE_SEQUENCE.fetch_add(1, Ordering::Relaxed)
        ));
        fs::write(&path, contents).expect("write rate card");
        env::set_var("RATECARD_PATH", &path);
        let result = test();
        if let Some(old_path) = old_path {
            env::set_var("RATECARD_PATH", old_path);
        } else {
            env::remove_var("RATECARD_PATH");
        }
        fs::remove_file(path).expect("remove temporary rate card");
        result
    }

    #[test]
    fn selects_the_first_eligible_band_after_sorting() {
        with_card(CARD, || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 501,
                    zone: "domestic".into()
                }),
                Ok(Quote {
                    base_cents: 899,
                    surcharge_cents: 0,
                    total_cents: 899,
                    band_max_grams: 2000,
                })
            );
        });
    }

    #[test]
    fn combines_weight_and_international_surcharges() {
        with_card(CARD, || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 10_001,
                    zone: "international".into()
                }),
                Ok(Quote {
                    base_cents: 4999,
                    surcharge_cents: 1500,
                    total_cents: 6499,
                    band_max_grams: 20_000,
                })
            );
        });
    }

    #[test]
    fn reports_unknown_zones_and_overweight_parcels() {
        with_card(CARD, || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "moon".into()
                }),
                Err(QuoteError::UnknownZone("moon".into()))
            );
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 20_001,
                    zone: "domestic".into()
                }),
                Err(QuoteError::Overweight {
                    grams: 20_001,
                    limit: 20_000
                })
            );
        });
    }

    #[test]
    fn identifies_the_physical_line_of_malformed_records() {
        with_card("# comment\n\ndomestic\t500\t599\ninvalid\tline\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                }),
                Err(QuoteError::MalformedRateCard { line: 4 })
            );
        });
    }

    #[test]
    fn unavailable_rate_card_is_reported() {
        let _lock = ENV_LOCK.lock().expect("environment lock poisoned");
        env::remove_var("RATECARD_PATH");
        assert_eq!(
            quote(&Parcel {
                weight_grams: 1,
                zone: "domestic".into()
            }),
            Err(QuoteError::RateCardUnavailable)
        );
    }
}
