//! Pure parsing and pricing rules for shipping zones.

use std::collections::HashMap;

use crate::{Parcel, Quote, QuoteError};

/// A single inclusive rate-card weight band.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct RateBand {
    max_grams: u32,
    cents: u64,
}

pub(crate) type RateCard = HashMap<String, Vec<RateBand>>;

/// Parse the tab-separated rate-card format into bands grouped by zone.
pub(crate) fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut card = RateCard::new();

    for (index, raw_line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let line = raw_line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = raw_line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let max_grams = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        card.entry(fields[0].to_owned())
            .or_default()
            .push(RateBand { max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }
    Ok(card)
}

/// Apply rate-card selection and surcharge rules without performing I/O.
pub(crate) fn calculate_quote(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let largest_band = bands.last().ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band = bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest_band.max_grams,
        },
    )?;

    let international_surcharge = if parcel.zone == "international" {
        // One fifth is 20%. Remainders of 3 or 4 fifths round half-up.
        band.cents / 5 + u64::from(band.cents % 5 >= 3)
    } else {
        0
    };
    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let surcharge_cents = international_surcharge.saturating_add(weight_surcharge);

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::{calculate_quote, parse_rate_card};
    use crate::{Parcel, Quote, QuoteError};

    #[test]
    fn accepts_comments_and_sorts_bands() {
        let card = parse_rate_card("\n# comment\ndomestic\t2000\t899\ndomestic\t500\t599\n")
            .expect("valid card");
        let quote = calculate_quote(
            &card,
            &Parcel {
                weight_grams: 500,
                zone: "domestic".to_owned(),
            },
        );

        assert_eq!(
            quote,
            Ok(Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            })
        );
    }

    #[test]
    fn malformed_line_uses_physical_line_number() {
        assert_eq!(
            parse_rate_card("# first\n\n domestic\t500\t599\ttoo-many\n"),
            Err(QuoteError::MalformedRateCard { line: 3 })
        );
    }
}
