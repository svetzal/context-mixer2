//! Shipping quote calculation from a tab-separated rate card.

pub mod zones;

use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

/// A parcel to be priced against the configured rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// The rate-card zone requested for the parcel.
    pub zone: String,
}

/// The itemized price of a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// The price from the matching rate-card band.
    pub base_cents: u64,
    /// All applicable surcharges.
    pub surcharge_cents: u64,
    /// The combined base price and surcharges.
    pub total_cents: u64,
    /// Upper inclusive weight limit of the matching band.
    pub band_max_grams: u32,
}

/// A failure encountered while obtaining a shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card path was unavailable or could not be read.
    RateCardUnavailable,
    /// A rate-card row did not have the required shape.
    MalformedRateCard {
        /// The one-based line number in the rate-card file.
        line: usize,
    },
    /// The requested zone is absent from the rate card.
    UnknownZone(String),
    /// The parcel exceeds the largest available band for its zone.
    Overweight {
        /// Requested parcel weight.
        grams: u32,
        /// Largest supported weight in the requested zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed on line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighing {grams}g exceeds the {limit}g limit")
            }
        }
    }
}

impl Error for QuoteError {}

/// Calculate a quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "shipping_quote",
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams
    );
    let _span_guard = span.enter();

    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let rate_card = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = zones::parse_rate_card(&rate_card)?;
    let quote = zones::calculate_quote(&bands, parcel)?;

    tracing::info!(total_cents = quote.total_cents, "shipping quote calculated");
    Ok(quote)
}

#[cfg(test)]
mod tests {
    use std::env;
    use std::fs;
    use std::sync::{Mutex, OnceLock};

    use super::{quote, Parcel, Quote, QuoteError};

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    fn environment_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    fn quote_with_card(card: &str, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let _lock = environment_lock().lock().expect("environment lock poisoned");
        let file = tempfile::NamedTempFile::new().expect("temporary rate card");
        fs::write(file.path(), card).expect("write temporary rate card");
        let previous_path = env::var_os("RATECARD_PATH");
        env::set_var("RATECARD_PATH", file.path());
        let result = quote(parcel);
        if let Some(path) = previous_path {
            env::set_var("RATECARD_PATH", path);
        } else {
            env::remove_var("RATECARD_PATH");
        }
        result
    }

    #[test]
    fn prices_matching_band_and_surcharges() {
        let result = quote_with_card(
            CARD,
            &Parcel {
                weight_grams: 10_001,
                zone: "international".to_owned(),
            },
        );

        assert_eq!(
            result,
            Ok(Quote {
                base_cents: 4_999,
                surcharge_cents: 1_500,
                total_cents: 6_499,
                band_max_grams: 20_000,
            })
        );
    }

    #[test]
    fn reports_rate_card_failures() {
        assert_eq!(
            quote_with_card(
                "domestic\t500\tnot-a-number\n",
                &Parcel {
                    weight_grams: 1,
                    zone: "domestic".to_owned(),
                },
            ),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn distinguishes_unknown_zone_from_overweight() {
        assert_eq!(
            quote_with_card(
                CARD,
                &Parcel {
                    weight_grams: 1,
                    zone: "other".to_owned(),
                },
            ),
            Err(QuoteError::UnknownZone("other".to_owned()))
        );
        assert_eq!(
            quote_with_card(
                CARD,
                &Parcel {
                    weight_grams: 20_001,
                    zone: "domestic".to_owned(),
                },
            ),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            })
        );
    }
}
