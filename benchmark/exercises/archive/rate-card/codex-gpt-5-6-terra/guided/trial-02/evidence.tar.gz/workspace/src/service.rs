//! Imperative rate-card loading and pure quote calculation.

use std::env;
use std::fs;

use crate::rate_card::RateCard;
use crate::{Parcel, Quote, QuoteError};

const HEAVY_PARCEL_GRAMS: u32 = 10_000;
const HEAVY_PARCEL_SURCHARGE_CENTS: u64 = 500;

/// Source of rate-card text, allowing the calculation boundary to use controlled adapters.
trait RateCardSource {
    fn read(&self) -> Result<String, QuoteError>;
}

struct EnvironmentRateCard;

impl RateCardSource for EnvironmentRateCard {
    fn read(&self) -> Result<String, QuoteError> {
        let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
        fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}

pub(crate) fn quote_from_environment(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_from_source(&EnvironmentRateCard, parcel)
}

fn quote_from_source(source: &dyn RateCardSource, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let result = source.read().and_then(|contents| {
        let card = RateCard::parse(&contents)?;
        calculate_quote(&card, parcel)
    });

    match &result {
        Ok(quote) => {
            // Keep this intentionally machine-readable so an operator can
            // correlate every successful quote without a logging dependency.
            eprintln!(
                "event=shipping_quote zone={:?} weight_grams={} total_cents={}",
                parcel.zone, parcel.weight_grams, quote.total_cents
            );
        }
        Err(error) => eprintln!(
            "event=shipping_quote_failed zone={:?} weight_grams={} error={:?}",
            parcel.zone, parcel.weight_grams, error
        ),
    }
    result
}

fn calculate_quote(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let mut zone_bands = card.bands_for(&parcel.zone).peekable();
    if zone_bands.peek().is_none() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let mut largest_band = None;
    for band in zone_bands {
        largest_band = Some(band.max_grams);
        if parcel.weight_grams <= band.max_grams {
            let surcharge_cents = surcharge_for(parcel, band.cents);
            return Ok(Quote {
                base_cents: band.cents,
                surcharge_cents,
                total_cents: band.cents.saturating_add(surcharge_cents),
                band_max_grams: band.max_grams,
            });
        }
    }

    match largest_band {
        Some(limit) => Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        }),
        None => Err(QuoteError::UnknownZone(parcel.zone.clone())),
    }
}

fn surcharge_for(parcel: &Parcel, base_cents: u64) -> u64 {
    let heavy_surcharge = if parcel.weight_grams > HEAVY_PARCEL_GRAMS {
        HEAVY_PARCEL_SURCHARGE_CENTS
    } else {
        0
    };
    let international_surcharge = if parcel.zone == "international" {
        // Twenty percent is one fifth. Splitting quotient and remainder keeps
        // the half-up calculation exact even for very large valid prices.
        base_cents / 5 + u64::from(base_cents % 5 >= 3)
    } else {
        0
    };
    heavy_surcharge.saturating_add(international_surcharge)
}

#[cfg(test)]
mod tests {
    use super::{calculate_quote, quote_from_source, RateCardSource};
    use crate::rate_card::RateCard;
    use crate::{Parcel, QuoteError};

    struct MemoryRateCard(&'static str);

    impl RateCardSource for MemoryRateCard {
        fn read(&self) -> Result<String, QuoteError> {
            Ok(self.0.to_owned())
        }
    }

    fn card() -> RateCard {
        RateCard::parse("domestic\t500\t599\ndomestic\t20000\t1799\ninternational\t20000\t4999\n")
            .expect("test card is valid")
    }

    #[test]
    fn adds_both_surcharges_and_rounds_international_half_up() {
        let parcel = Parcel {
            weight_grams: 10_001,
            zone: "international".to_owned(),
        };
        let quote = calculate_quote(&card(), &parcel).expect("quote should be available");
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn distinguishes_unknown_zones_from_overweight_parcels() {
        let unknown = Parcel {
            weight_grams: 1,
            zone: "moon".to_owned(),
        };
        assert_eq!(
            calculate_quote(&card(), &unknown),
            Err(QuoteError::UnknownZone("moon".to_owned()))
        );
        let overweight = Parcel {
            weight_grams: 20_001,
            zone: "domestic".to_owned(),
        };
        assert_eq!(
            calculate_quote(&card(), &overweight),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            })
        );
    }

    #[test]
    fn adapter_boundary_maps_card_errors_without_real_io() {
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_owned(),
        };
        let quote = quote_from_source(&MemoryRateCard("domestic\t500\t599"), &parcel)
            .expect("memory card produces a quote");
        assert_eq!(quote.total_cents, 599);
    }
}
