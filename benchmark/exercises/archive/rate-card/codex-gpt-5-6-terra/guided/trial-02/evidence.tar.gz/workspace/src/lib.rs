//! Quotes shipping parcels using the rate card selected by `RATECARD_PATH`.

mod error;
mod rate_card;
mod service;
pub mod zones;

pub use error::QuoteError;

/// A parcel for which a shipping quote is requested.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Delivery zone as named in the rate card.
    pub zone: String,
}

/// The price returned for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Price of the selected rate-card band.
    pub base_cents: u64,
    /// All applicable surcharges.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// Upper weight threshold of the selected band.
    pub band_max_grams: u32,
}

/// Calculate a shipping quote using the rate card named by `RATECARD_PATH`.
///
/// The environment variable and its file are deliberately read here, at the
/// edge of the crate. Band selection and pricing remain pure operations.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    service::quote_from_environment(parcel)
}
