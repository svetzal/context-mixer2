use std::env;
use std::fs;
use std::sync::{Mutex, OnceLock};

use ratecard::{quote, Parcel, QuoteError};

fn environment_lock() -> &'static Mutex<()> {
    static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    LOCK.get_or_init(|| Mutex::new(()))
}

#[test]
fn public_quote_loads_the_environment_selected_card() {
    let _lock = environment_lock().lock().expect("environment lock is available");
    let path = env::temp_dir().join(format!("ratecard-public-api-{}.tsv", std::process::id()));
    assert!(fs::write(&path, "international\t500\t1499\n").is_ok());

    let previous_path = env::var_os("RATECARD_PATH");
    env::set_var("RATECARD_PATH", &path);

    let parcel = Parcel {
        weight_grams: 500,
        zone: "international".to_owned(),
    };
    let result = quote(&parcel);

    match previous_path {
        Some(value) => env::set_var("RATECARD_PATH", value),
        None => env::remove_var("RATECARD_PATH"),
    }
    assert!(fs::remove_file(&path).is_ok());

    let quote = result.expect("the configured card should quote the parcel");
    assert_eq!(quote.base_cents, 1499);
    assert_eq!(quote.surcharge_cents, 300);
    assert_eq!(quote.total_cents, 1799);
}

#[test]
fn missing_rate_card_path_is_a_recoverable_error() {
    let _lock = environment_lock().lock().expect("environment lock is available");
    let previous_path = env::var_os("RATECARD_PATH");
    env::remove_var("RATECARD_PATH");

    let result = quote(&Parcel {
        weight_grams: 1,
        zone: "domestic".to_owned(),
    });

    match previous_path {
        Some(value) => env::set_var("RATECARD_PATH", value),
        None => env::remove_var("RATECARD_PATH"),
    }
    assert_eq!(result, Err(QuoteError::RateCardUnavailable));
}
