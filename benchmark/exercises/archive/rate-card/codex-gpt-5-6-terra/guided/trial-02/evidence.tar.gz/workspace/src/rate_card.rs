//! Parsing and in-memory representation of tab-separated rate cards.

use crate::QuoteError;

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct Band {
    pub(crate) max_grams: u32,
    pub(crate) cents: u64,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct RateCard {
    bands: Vec<(String, Band)>,
}

impl RateCard {
    pub(crate) fn parse(contents: &str) -> Result<Self, QuoteError> {
        let mut bands = Vec::new();

        for (index, line) in contents.lines().enumerate() {
            if line.is_empty() || line.starts_with('#') {
                continue;
            }

            let line_number = index + 1;
            let mut fields = line.split('\t');
            let Some(zone) = fields.next() else {
                return Err(QuoteError::MalformedRateCard { line: line_number });
            };
            let Some(max_grams) = fields.next() else {
                return Err(QuoteError::MalformedRateCard { line: line_number });
            };
            let Some(cents) = fields.next() else {
                return Err(QuoteError::MalformedRateCard { line: line_number });
            };
            if fields.next().is_some() {
                return Err(QuoteError::MalformedRateCard { line: line_number });
            }

            let max_grams = max_grams
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
            let cents =
                cents.parse().map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
            bands.push((zone.to_owned(), Band { max_grams, cents }));
        }

        // Stable sorting retains file order for duplicate thresholds.
        bands.sort_by_key(|(_, band)| band.max_grams);
        Ok(Self { bands })
    }

    pub(crate) fn bands_for(&self, zone: &str) -> impl Iterator<Item = &Band> {
        let zone = zone.to_owned();
        self.bands
            .iter()
            .filter(move |(band_zone, _)| band_zone == &zone)
            .map(|(_, band)| band)
    }
}

#[cfg(test)]
mod tests {
    use super::RateCard;
    use crate::QuoteError;

    #[test]
    fn ignores_comments_and_sorts_each_zone_by_weight() {
        let card = RateCard::parse("# heading\ndomestic\t2000\t899\n\ndomestic\t500\t599\n")
            .expect("valid card");
        let thresholds: Vec<_> = card.bands_for("domestic").map(|band| band.max_grams).collect();
        assert_eq!(thresholds, [500, 2000]);
    }

    #[test]
    fn reports_the_physical_line_for_invalid_numbers() {
        let error = RateCard::parse("# heading\n\ndomestic\tnot-a-number\t599")
            .expect_err("invalid number must fail");
        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
    }
}
