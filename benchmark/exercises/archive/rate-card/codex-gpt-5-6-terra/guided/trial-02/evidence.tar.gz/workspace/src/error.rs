//! Errors returned while loading a rate card or quoting a parcel.

use std::error::Error;
use std::fmt::{self, Display, Formatter};

/// A failure that callers can handle while requesting a quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The configured rate card could not be located or read.
    RateCardUnavailable,
    /// A rate-card line did not contain the required tab-separated fields.
    MalformedRateCard {
        /// One-based physical line number in the source file.
        line: usize,
    },
    /// The requested zone has no rate-card bands.
    UnknownZone(String),
    /// The parcel exceeds the largest band available for its zone.
    Overweight {
        /// Parcel weight in grams.
        grams: u32,
        /// Largest supported weight in grams.
        limit: u32,
    },
}

impl Display for QuoteError {
    fn fmt(&self, formatter: &mut Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown delivery zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighing {grams}g exceeds the {limit}g limit")
            }
        }
    }
}

impl Error for QuoteError {}
