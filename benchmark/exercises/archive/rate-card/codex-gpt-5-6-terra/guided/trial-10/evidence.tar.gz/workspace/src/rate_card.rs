//! Pure rate-card parsing and quote-calculation policy.

use crate::{Parcel, Quote, QuoteError};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct RateBand {
    pub(crate) max_grams: u32,
    pub(crate) cents: u64,
}

/// Parses the tab-separated rate-card format into zone bands.
pub(crate) fn parse(contents: &str) -> Result<Vec<(String, RateBand)>, QuoteError> {
    let mut bands = Vec::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        let [zone, max_grams, cents] = fields.as_slice() else {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        };
        let max_grams = max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents =
            cents.parse().map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        bands.push(((*zone).to_owned(), RateBand { max_grams, cents }));
    }

    bands.sort_by_key(|(_, band)| band.max_grams);
    Ok(bands)
}

/// Calculates a quote from already-parsed rate bands.
pub(crate) fn calculate(
    parcel: &Parcel,
    rate_bands: &[(String, RateBand)],
) -> Result<Quote, QuoteError> {
    let zone_bands: Vec<_> = rate_bands
        .iter()
        .filter(|(zone, _)| zone == &parcel.zone)
        .map(|(_, band)| *band)
        .collect();

    let Some(last_band) = zone_bands.last() else {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    };
    let Some(band) = zone_bands.iter().find(|band| parcel.weight_grams <= band.max_grams) else {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: last_band.max_grams,
        });
    };

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    // Twenty percent is one fifth. Dividing first avoids overflowing an
    // otherwise-valid `u64` base rate; remainders of 3 or 4 round half-up.
    let international_surcharge = if parcel.zone == "international" {
        band.cents / 5 + u64::from(band.cents % 5 >= 3)
    } else {
        0
    };
    let surcharge_cents = weight_surcharge.saturating_add(international_surcharge);

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::{calculate, parse};
    use crate::{Parcel, QuoteError};

    #[test]
    fn chooses_the_first_matching_band_after_sorting() {
        let rates = parse("domestic\t2000\t899\ndomestic\t500\t599\n").unwrap();
        let quote = calculate(
            &Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            },
            &rates,
        )
        .unwrap();

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn reports_the_physical_line_for_malformed_data() {
        let error = parse("# heading\n\ndomestic\t500\t599\nbad\tdata\n").unwrap_err();
        assert_eq!(error, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn calculates_combined_surcharges() {
        let rates = parse("international\t20000\t4999\n").unwrap();
        let quote = calculate(
            &Parcel {
                weight_grams: 10_001,
                zone: "international".into(),
            },
            &rates,
        )
        .unwrap();

        assert_eq!(quote.surcharge_cents, 1_500);
        assert_eq!(quote.total_cents, 6_499);
    }
}
