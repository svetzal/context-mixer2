//! Shipping quote calculation from an operator-maintained rate card.

mod rate_card;

pub mod zones;

use std::fmt;

/// A parcel to price against the current rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Delivery zone requested by the caller.
    pub zone: String,
}

/// The calculated shipping charge and the band from which it came.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Charge from the selected rate-card band.
    pub base_cents: u64,
    /// Sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// The base charge plus all surcharges.
    pub total_cents: u64,
    /// Inclusive upper weight bound of the selected band.
    pub band_max_grams: u32,
}

/// A recoverable failure while reading or applying a rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate-card path was absent or its file could not be read.
    RateCardUnavailable,
    /// A rate-card line did not contain three valid tab-separated fields.
    MalformedRateCard {
        /// One-based physical line number in the rate-card file.
        line: usize,
    },
    /// The requested zone has no bands in the rate card.
    UnknownZone(String),
    /// The requested weight exceeds the zone's largest configured band.
    Overweight {
        /// Requested parcel weight in grams.
        grams: u32,
        /// Largest configured weight in grams for the requested zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighing {grams}g exceeds the {limit}g limit")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Reads the configured rate card and returns a shipping quote for `parcel`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = std::fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let rate_bands = rate_card::parse(&contents)?;
    let quote = rate_card::calculate(parcel, &rate_bands)?;

    // Keep a dependency-free operational record at the I/O boundary. Callers
    // that need collection can capture standard error in their service runner.
    eprintln!(
        "shipping quote calculated zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, quote.total_cents
    );

    Ok(quote)
}

#[cfg(test)]
mod tests {
    use std::{
        path::PathBuf,
        sync::{atomic::AtomicUsize, atomic::Ordering, Mutex, OnceLock},
    };

    use super::{quote, Parcel, QuoteError};

    fn environment_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    fn rate_card_file(contents: &str) -> PathBuf {
        static SEQUENCE: AtomicUsize = AtomicUsize::new(0);
        let sequence = SEQUENCE.fetch_add(1, Ordering::Relaxed);
        let path = std::env::temp_dir()
            .join(format!("ratecard-test-{}-{sequence}.tsv", std::process::id()));
        std::fs::write(&path, contents).unwrap();
        path
    }

    #[test]
    fn reads_the_rate_card_from_the_environment() {
        let _guard = environment_lock().lock().unwrap();
        let file = rate_card_file("domestic\t500\t599\n");
        std::env::set_var("RATECARD_PATH", &file);

        let result = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        });

        std::env::remove_var("RATECARD_PATH");
        std::fs::remove_file(file).unwrap();
        assert_eq!(result.unwrap().total_cents, 599);
    }

    #[test]
    fn unavailable_when_the_path_is_not_set() {
        let _guard = environment_lock().lock().unwrap();
        std::env::remove_var("RATECARD_PATH");
        let result = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        });

        assert_eq!(result.unwrap_err(), QuoteError::RateCardUnavailable);
    }
}
