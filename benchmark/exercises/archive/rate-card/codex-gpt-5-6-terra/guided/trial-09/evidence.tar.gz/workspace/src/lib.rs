//! Shipping quote calculation backed by an operations-managed rate card.

mod zones;

use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

/// A parcel to price against the current rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Rate-card zone requested for the parcel.
    pub zone: String,
}

/// The price selected from a rate card, including applicable surcharges.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Cost of the matching band before surcharges.
    pub base_cents: u64,
    /// Sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// Final quote amount.
    pub total_cents: u64,
    /// Upper weight limit of the selected band.
    pub band_max_grams: u32,
}

/// Errors encountered while loading or applying a rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// No usable rate-card path was supplied or its file could not be read.
    RateCardUnavailable,
    /// A rate-card record did not have the expected structure.
    MalformedRateCard { line: usize },
    /// The requested zone has no bands in the card.
    UnknownZone(String),
    /// The parcel exceeds the largest available band for its zone.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds {limit}g limit")
            }
        }
    }
}

impl Error for QuoteError {}

/// Calculate a quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "ratecard.quote",
        zone = parcel.zone.as_str(),
        weight_grams = parcel.weight_grams
    );
    let _entered = span.enter();
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = zones::parse(&card)?;
    let result = zones::calculate(&bands, parcel)?;
    tracing::info!(total_cents = result.total_cents, "ratecard quote calculated");
    Ok(result)
}

/// A display label retained for callers that use the original helper.
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}

#[cfg(test)]
mod tests {
    use super::{quote, Parcel, QuoteError};
    use std::env;
    use std::fs;
    use std::sync::{
        atomic::{AtomicUsize, Ordering},
        Mutex, OnceLock,
    };

    fn environment_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    fn with_card(card: &str, test: impl FnOnce()) {
        static NEXT_CARD: AtomicUsize = AtomicUsize::new(0);
        let _guard = environment_lock().lock().expect("environment lock poisoned");
        let path = env::temp_dir().join(format!(
            "ratecard-test-{}-{}",
            std::process::id(),
            NEXT_CARD.fetch_add(1, Ordering::Relaxed)
        ));
        fs::write(&path, card).expect("write card");
        env::set_var("RATECARD_PATH", &path);
        test();
        env::remove_var("RATECARD_PATH");
        fs::remove_file(path).expect("remove temporary card");
    }

    #[test]
    fn selects_first_matching_band_and_surcharges() {
        with_card(
            "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t20000\t1799\ninternational\t20000\t4999\n",
            || {
                let domestic = quote(&Parcel { weight_grams: 500, zone: "domestic".into() })
                    .expect("domestic quote");
                assert_eq!((domestic.base_cents, domestic.surcharge_cents, domestic.total_cents, domestic.band_max_grams), (599, 0, 599, 500));

                let international = quote(&Parcel { weight_grams: 10_001, zone: "international".into() })
                    .expect("international quote");
                assert_eq!((international.base_cents, international.surcharge_cents, international.total_cents), (4999, 1500, 6499));
            },
        );
    }

    #[test]
    fn reports_card_and_selection_errors() {
        let unavailable = quote(&Parcel {
            weight_grams: 1,
            zone: "domestic".into(),
        });
        assert_eq!(unavailable, Err(QuoteError::RateCardUnavailable));

        with_card("domestic\tbad\t599\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                }),
                Err(QuoteError::MalformedRateCard { line: 1 })
            );
        });
        with_card("\n# comment\ndomestic\t500\t599\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "other".into()
                }),
                Err(QuoteError::UnknownZone("other".into()))
            );
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 501,
                    zone: "domestic".into()
                }),
                Err(QuoteError::Overweight {
                    grams: 501,
                    limit: 500
                })
            );
        });
    }
}
