//! Parsing and ordering of rate-card bands by shipping zone.

use crate::{Parcel, Quote, QuoteError};
use std::collections::BTreeMap;

/// One parsed rate-card band.
pub(crate) struct Band {
    pub(crate) max_grams: u32,
    pub(crate) cents: u64,
}

/// Parse all non-comment rate-card records, grouping their bands by zone.
pub(crate) fn parse(contents: &str) -> Result<BTreeMap<&str, Vec<Band>>, QuoteError> {
    let mut zones = BTreeMap::new();
    for (index, raw_line) in contents.lines().enumerate() {
        let line = raw_line.trim_end_matches('\r');
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let fields: Vec<_> = line.split('\t').collect();
        let [zone, max_grams, cents] = fields.as_slice() else {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        };
        let max_grams = max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        let cents = cents.parse().map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        zones.entry(*zone).or_insert_with(Vec::new).push(Band { max_grams, cents });
    }
    for bands in zones.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }
    Ok(zones)
}

/// Select a band and calculate its surcharges without performing I/O.
pub(crate) fn calculate(
    zones: &BTreeMap<&str, Vec<Band>>,
    parcel: &Parcel,
) -> Result<Quote, QuoteError> {
    let zone_bands = zones
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band = zone_bands
        .iter()
        .find(|band| parcel.weight_grams <= band.max_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: zone_bands.last().map_or(0, |band| band.max_grams),
        })?;

    let international_surcharge = if parcel.zone == "international" {
        // Twenty percent is one fifth; this form cannot overflow before rounding.
        band.cents / 5 + u64::from(band.cents % 5 >= 3)
    } else {
        0
    };
    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let surcharge_cents = weight_surcharge.saturating_add(international_surcharge);

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    })
}
