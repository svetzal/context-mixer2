//! Shipping quote calculation backed by an operator-maintained rate card.

use std::{collections::HashMap, env, error::Error, fmt, fs, path::Path};

pub mod zones;

/// A parcel to price against the rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Destination zone named by the rate card.
    pub zone: String,
}

/// The component prices selected for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Price from the selected rate-card band.
    pub base_cents: u64,
    /// Combined applicable surcharges.
    pub surcharge_cents: u64,
    /// Total of the base price and surcharges.
    pub total_cents: u64,
    /// Upper weight boundary of the selected band.
    pub band_max_grams: u32,
}

/// A recoverable failure while loading or applying a rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The configured card could not be located or read.
    RateCardUnavailable,
    /// A card row did not have the required three tab-separated fields.
    MalformedRateCard {
        /// One-based physical line number in the card.
        line: usize,
    },
    /// The requested zone does not appear in the card.
    UnknownZone(String),
    /// The parcel is heavier than this zone permits.
    Overweight {
        /// Parcel weight in grams.
        grams: u32,
        /// Largest configured band for the zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighing {grams}g exceeds the {limit}g limit")
            }
        }
    }
}

impl Error for QuoteError {}

/// Load the configured rate card and calculate a quote for `parcel`.
#[tracing::instrument(
    name = "ratecard.quote",
    skip(parcel),
    fields(zone = %parcel.zone, weight_grams = parcel.weight_grams)
)]
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let rate_card = load_rate_card(Path::new(&path))?;
    let calculated = calculate_quote(&rate_card, parcel)?;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = calculated.total_cents,
        "shipping quote calculated"
    );

    Ok(calculated)
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

type RateCard = HashMap<String, Vec<Band>>;

fn load_rate_card(path: &Path) -> Result<RateCard, QuoteError> {
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut rate_card = RateCard::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        if line.trim().is_empty() || line.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let (Some(zone), Some(max_grams), Some(cents), None) =
            (fields.next(), fields.next(), fields.next(), fields.next())
        else {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        };
        let (Ok(max_grams), Ok(cents)) = (max_grams.parse(), cents.parse()) else {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        };

        rate_card.entry(zone.to_owned()).or_default().push(Band { max_grams, cents });
    }

    for bands in rate_card.values_mut() {
        bands.sort_unstable_by_key(|band| band.max_grams);
    }

    Ok(rate_card)
}

fn calculate_quote(rate_card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let limit = bands.last().map_or(0, |band| band.max_grams);
    let band = bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        },
    )?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        // 20% is one fifth; adding two rounds an integer number of cents half-up.
        band.cents / 5 + (band.cents % 5 + 2) / 5
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t2000\t899\n\
domestic\t500\t599\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_owned(),
        }
    }

    #[test]
    fn selects_the_first_matching_band_after_sorting() {
        let card = parse_rate_card(CARD).unwrap();

        assert_eq!(
            calculate_quote(&card, &parcel(500, "domestic")).unwrap(),
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn combines_weight_and_international_surcharges() {
        let card = parse_rate_card(CARD).unwrap();

        assert_eq!(
            calculate_quote(&card, &parcel(10_001, "international")).unwrap(),
            Quote {
                base_cents: 4999,
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20_000,
            }
        );
    }

    #[test]
    fn reports_unknown_zone_and_overweight() {
        let card = parse_rate_card(CARD).unwrap();

        assert_eq!(
            calculate_quote(&card, &parcel(1, "express")),
            Err(QuoteError::UnknownZone("express".to_owned()))
        );
        assert_eq!(
            calculate_quote(&card, &parcel(20_001, "domestic")),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            })
        );
    }

    #[test]
    fn reports_physical_line_for_malformed_rows() {
        assert_eq!(
            parse_rate_card("# heading\n\n domestic\t500\tnot-a-number\n"),
            Err(QuoteError::MalformedRateCard { line: 3 })
        );
    }
}
