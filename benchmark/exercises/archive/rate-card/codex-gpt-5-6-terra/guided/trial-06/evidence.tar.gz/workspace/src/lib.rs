//! Shipping quote calculation backed by a tab-separated rate card.

pub mod zones;

use std::{collections::HashMap, env, error::Error, fmt, fs};

/// A parcel to price against the configured rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// The parcel's weight in grams.
    pub weight_grams: u32,
    /// The destination zone named in the rate card.
    pub zone: String,
}

/// A price calculated for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// The base price from the matching rate-card band, in cents.
    pub base_cents: u64,
    /// All applicable surcharges, in cents.
    pub surcharge_cents: u64,
    /// The total price, in cents.
    pub total_cents: u64,
    /// The upper weight threshold of the matching band.
    pub band_max_grams: u32,
}

/// A failure encountered while loading or applying a rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card path was missing or could not be read.
    RateCardUnavailable,
    /// A rate-card line had the wrong shape or invalid numeric fields.
    MalformedRateCard { line: usize },
    /// The requested destination zone has no rate-card bands.
    UnknownZone(String),
    /// The parcel exceeds the zone's largest rate-card band.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed on line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit of {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Load the configured rate card and calculate a quote for `parcel`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = load_rate_card()?;
    let quote = calculate_quote(parcel, &card)?;
    eprintln!(
        "shipping_quote zone={:?} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, quote.total_cents
    );
    Ok(quote)
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut card: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, raw_line) in contents.lines().enumerate() {
        let line_number = index + 1;
        if raw_line.trim().is_empty() || raw_line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = raw_line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let max_grams = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        card.entry(fields[0].to_owned()).or_default().push(Band { max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_unstable_by_key(|band| band.max_grams);
    }
    Ok(card)
}

fn calculate_quote(
    parcel: &Parcel,
    card: &HashMap<String, Vec<Band>>,
) -> Result<Quote, QuoteError> {
    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let limit = bands
        .last()
        .map(|band| band.max_grams)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band = bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        },
    )?;

    let weight_surcharge = if parcel.weight_grams > 10_000 { 500 } else { 0 };
    let international_surcharge = if parcel.zone == "international" {
        rounded_fifth(band.cents)
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

fn rounded_fifth(value: u64) -> u64 {
    value / 5 + (value % 5 + 2) / 5
}

#[cfg(test)]
mod tests {
    use std::{env, fs, sync::Mutex};

    use super::{quote, Parcel, QuoteError};

    static RATECARD_ENV_LOCK: Mutex<()> = Mutex::new(());

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    fn with_rate_card<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        let _lock = RATECARD_ENV_LOCK.lock().unwrap();
        let file = tempfile::NamedTempFile::new().unwrap();
        fs::write(file.path(), contents).unwrap();
        env::set_var("RATECARD_PATH", file.path());
        let result = test();
        env::remove_var("RATECARD_PATH");
        result
    }

    #[test]
    fn selects_the_first_matching_band() {
        with_rate_card(CARD, || {
            let result = quote(&Parcel {
                weight_grams: 501,
                zone: "domestic".to_owned(),
            })
            .unwrap();

            assert_eq!(result.base_cents, 899);
            assert_eq!(result.band_max_grams, 2_000);
            assert_eq!(result.surcharge_cents, 0);
            assert_eq!(result.total_cents, 899);
        });
    }

    #[test]
    fn combines_weight_and_international_surcharges() {
        with_rate_card(CARD, || {
            let result = quote(&Parcel {
                weight_grams: 10_001,
                zone: "international".to_owned(),
            })
            .unwrap();

            assert_eq!(result.base_cents, 4_999);
            assert_eq!(result.surcharge_cents, 1_500);
            assert_eq!(result.total_cents, 6_499);
        });
    }

    #[test]
    fn rounds_international_surcharge_half_up() {
        with_rate_card("international\t500\t3\n", || {
            let result = quote(&Parcel {
                weight_grams: 1,
                zone: "international".to_owned(),
            })
            .unwrap();

            assert_eq!(result.surcharge_cents, 1);
        });
    }

    #[test]
    fn reports_unknown_and_overweight_parcels() {
        with_rate_card(CARD, || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "regional".to_owned(),
                }),
                Err(QuoteError::UnknownZone("regional".to_owned()))
            );
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 20_001,
                    zone: "domestic".to_owned(),
                }),
                Err(QuoteError::Overweight {
                    grams: 20_001,
                    limit: 20_000,
                })
            );
        });
    }

    #[test]
    fn reports_unavailable_and_malformed_rate_cards() {
        let _lock = RATECARD_ENV_LOCK.lock().unwrap();
        env::remove_var("RATECARD_PATH");
        assert_eq!(
            quote(&Parcel {
                weight_grams: 1,
                zone: "domestic".to_owned(),
            }),
            Err(QuoteError::RateCardUnavailable)
        );
        drop(_lock);

        with_rate_card("# comment\n\ndomestic\t500\tnot-a-number\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".to_owned(),
                }),
                Err(QuoteError::MalformedRateCard { line: 3 })
            );
        });
    }
}
