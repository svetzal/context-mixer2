//! Shipping quote calculation backed by a tab-separated rate card.

use std::{collections::HashMap, env, error::Error, fmt, fs};

pub mod zones;

/// A parcel to quote for delivery.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Delivery zone requested by the caller.
    pub zone: String,
}

/// The calculated shipping charge for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Charge from the matching rate-card band.
    pub base_cents: u64,
    /// All applicable charges in addition to the base charge.
    pub surcharge_cents: u64,
    /// The total charge in cents.
    pub total_cents: u64,
    /// The upper weight threshold of the matching band.
    pub band_max_grams: u32,
}

/// Failures that can occur while preparing a shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The configured rate card could not be read.
    RateCardUnavailable,
    /// A rate-card record has an invalid shape or numeric value.
    MalformedRateCard { line: usize },
    /// The requested zone has no rate-card entries.
    UnknownZone(String),
    /// The parcel exceeds the largest supported band for its zone.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown delivery zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighing {grams}g exceeds the {limit}g limit")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy)]
struct RateBand {
    max_grams: u32,
    cents: u64,
}

/// Calculates the delivery quote for a parcel using `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let largest_band = bands.last().expect("each populated rate-card zone has at least one band");
    let band = bands.iter().find(|band| parcel.weight_grams <= band.max_grams);
    let band = band.ok_or(QuoteError::Overweight {
        grams: parcel.weight_grams,
        limit: largest_band.max_grams,
    })?;

    let mut surcharge_cents = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += rounded_twenty_percent(band.cents);
    }

    let result = Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    };
    eprintln!(
        "ratecard quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, result.total_cents
    );
    Ok(result)
}

fn load_rate_card() -> Result<HashMap<String, Vec<RateBand>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let mut rate_card: HashMap<String, Vec<RateBand>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let max_grams = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        rate_card
            .entry(fields[0].to_owned())
            .or_default()
            .push(RateBand { max_grams, cents });
    }

    for bands in rate_card.values_mut() {
        bands.sort_unstable_by_key(|band| band.max_grams);
    }
    Ok(rate_card)
}

fn rounded_twenty_percent(cents: u64) -> u64 {
    cents / 5 + u64::from(cents % 5 >= 3)
}

#[cfg(test)]
mod tests {
    use std::{
        env, fs,
        sync::{
            atomic::{AtomicUsize, Ordering},
            Mutex,
        },
    };

    use super::*;

    static ENVIRONMENT: Mutex<()> = Mutex::new(());
    static TEMPORARY_FILE_NUMBER: AtomicUsize = AtomicUsize::new(0);

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    fn with_rate_card<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        let _environment = ENVIRONMENT.lock().expect("environment mutex poisoned");
        let path = env::temp_dir().join(format!(
            "ratecard-test-{}-{}",
            std::process::id(),
            TEMPORARY_FILE_NUMBER.fetch_add(1, Ordering::Relaxed)
        ));
        fs::write(&path, contents).expect("write temporary rate card");
        env::set_var("RATECARD_PATH", &path);
        let result = test();
        env::remove_var("RATECARD_PATH");
        fs::remove_file(path).expect("remove temporary rate card");
        result
    }

    #[test]
    fn quotes_first_matching_domestic_band() {
        with_rate_card(CARD, || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 501,
                    zone: "domestic".into(),
                }),
                Ok(Quote {
                    base_cents: 899,
                    surcharge_cents: 0,
                    total_cents: 899,
                    band_max_grams: 2000,
                })
            );
        });
    }

    #[test]
    fn international_and_heavy_surcharges_stack() {
        with_rate_card(CARD, || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 10_001,
                    zone: "international".into(),
                }),
                Ok(Quote {
                    base_cents: 4999,
                    surcharge_cents: 1500,
                    total_cents: 6499,
                    band_max_grams: 20_000,
                })
            );
        });
    }

    #[test]
    fn reports_unknown_zone_and_overweight() {
        with_rate_card(CARD, || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "regional".into(),
                }),
                Err(QuoteError::UnknownZone("regional".into()))
            );
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 20_001,
                    zone: "domestic".into(),
                }),
                Err(QuoteError::Overweight {
                    grams: 20_001,
                    limit: 20_000,
                })
            );
        });
    }

    #[test]
    fn identifies_malformed_line_with_physical_line_number() {
        with_rate_card("# comment\n\ndomestic\t500\t599\nbad\tvalue\t100\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".into(),
                }),
                Err(QuoteError::MalformedRateCard { line: 4 })
            );
        });
    }

    #[test]
    fn unavailable_rate_card_is_reported() {
        let _environment = ENVIRONMENT.lock().expect("environment mutex poisoned");
        env::remove_var("RATECARD_PATH");
        assert_eq!(
            quote(&Parcel {
                weight_grams: 1,
                zone: "domestic".into(),
            }),
            Err(QuoteError::RateCardUnavailable)
        );
    }

    #[test]
    fn rounds_international_surcharge_half_up() {
        assert_eq!(rounded_twenty_percent(3), 1);
        assert_eq!(rounded_twenty_percent(2), 0);
    }
}
