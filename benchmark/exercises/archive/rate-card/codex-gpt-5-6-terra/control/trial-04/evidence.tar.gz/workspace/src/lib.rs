pub mod zones;

use std::{env, error::Error, fmt, fs};

/// A parcel to be rated against the configured rate card.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price selected for a parcel.
#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// A failure while loading or applying a rate card.
#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed on line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown delivery zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds the {limit}g limit")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug)]
struct Band {
    zone: String,
    max_grams: u32,
    cents: u64,
}

/// Calculate a shipping quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let mut zone_bands: Vec<_> =
        rate_card.into_iter().filter(|band| band.zone == parcel.zone).collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|band| band.max_grams);
    let limit = zone_bands.last().expect("zone bands are non-empty").max_grams;
    let band = zone_bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        },
    )?;

    let mut surcharge_cents = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        // Twenty percent is one fifth; adding two implements half-up rounding.
        surcharge_cents += (band.cents + 2) / 5;
    }

    let result = Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    };

    eprintln!(
        "ratecard quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, result.total_cents
    );

    Ok(result)
}

fn load_rate_card() -> Result<Vec<Band>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    contents
        .lines()
        .enumerate()
        .filter_map(|(index, line)| {
            if line.is_empty() || line.starts_with('#') {
                None
            } else {
                Some(parse_band(line, index + 1))
            }
        })
        .collect()
}

fn parse_band(line: &str, line_number: usize) -> Result<Band, QuoteError> {
    let mut fields = line.split('\t');
    let zone = fields.next();
    let max_grams = fields.next();
    let cents = fields.next();

    if fields.next().is_some() {
        return Err(QuoteError::MalformedRateCard { line: line_number });
    }

    let (Some(zone), Some(max_grams), Some(cents)) = (zone, max_grams, cents) else {
        return Err(QuoteError::MalformedRateCard { line: line_number });
    };

    Ok(Band {
        zone: zone.to_owned(),
        max_grams: max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?,
        cents: cents.parse().map_err(|_| QuoteError::MalformedRateCard { line: line_number })?,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::{
        fs,
        sync::{
            atomic::{AtomicUsize, Ordering},
            Mutex,
        },
    };

    static ENV_LOCK: Mutex<()> = Mutex::new(());
    static NEXT_FIXTURE: AtomicUsize = AtomicUsize::new(0);

    fn with_rate_card<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        let _lock = ENV_LOCK.lock().unwrap();
        let fixture_id = NEXT_FIXTURE.fetch_add(1, Ordering::Relaxed);
        let path =
            env::temp_dir().join(format!("ratecard-test-{}-{fixture_id}.tsv", std::process::id()));
        fs::write(&path, contents).unwrap();
        env::set_var("RATECARD_PATH", &path);
        let result = test();
        env::remove_var("RATECARD_PATH");
        fs::remove_file(path).unwrap();
        result
    }

    const CARD: &str = "# zone\tband_max_grams\tcents\ndomestic\t2000\t899\ndomestic\t500\t599\ndomestic\t20000\t1799\ninternational\t500\t1499\ninternational\t20000\t4999\n";

    #[test]
    fn chooses_the_first_matching_band_in_threshold_order() {
        with_rate_card(CARD, || {
            let quote = quote(&Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(quote.base_cents, 599);
            assert_eq!(quote.band_max_grams, 500);
            assert_eq!(quote.surcharge_cents, 0);
            assert_eq!(quote.total_cents, 599);
        });
    }

    #[test]
    fn combines_weight_and_international_surcharges() {
        with_rate_card(CARD, || {
            let quote = quote(&Parcel {
                weight_grams: 10_001,
                zone: "international".into(),
            })
            .unwrap();
            assert_eq!(quote.base_cents, 4999);
            assert_eq!(quote.surcharge_cents, 1500);
            assert_eq!(quote.total_cents, 6499);
        });
    }

    #[test]
    fn reports_unknown_zone_and_overweight() {
        with_rate_card(CARD, || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "moon".into()
                })
                .unwrap_err(),
                QuoteError::UnknownZone("moon".into())
            );
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 20_001,
                    zone: "domestic".into()
                })
                .unwrap_err(),
                QuoteError::Overweight {
                    grams: 20_001,
                    limit: 20_000
                }
            );
        });
    }

    #[test]
    fn reports_malformed_line_numbers_including_comments() {
        with_rate_card("# comment\n\nbroken\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                })
                .unwrap_err(),
                QuoteError::MalformedRateCard { line: 3 }
            );
        });
    }

    #[test]
    fn missing_rate_card_is_unavailable() {
        let _lock = ENV_LOCK.lock().unwrap();
        env::remove_var("RATECARD_PATH");
        assert_eq!(
            quote(&Parcel {
                weight_grams: 1,
                zone: "domestic".into()
            })
            .unwrap_err(),
            QuoteError::RateCardUnavailable
        );
    }
}
