//! Shipping quote calculation from a tab-separated rate card.

use std::{collections::HashMap, env, error::Error, fmt, fs};

pub mod zones;

/// A parcel to price.
#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price selected for a parcel.
#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// A failure encountered while reading or applying a rate card.
#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculate a quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card_path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let rate_card =
        fs::read_to_string(rate_card_path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let zones = parse_rate_card(&rate_card)?;

    let bands = zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let largest_band = bands.last().expect("rate-card zones always contain a band");
    let band = bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest_band.max_grams,
        },
    )?;

    let mut surcharge_cents = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        // One fifth of the base price, rounded to the nearest cent with halves up.
        surcharge_cents += band.cents / 5 + u64::from(band.cents % 5 >= 3);
    }
    let total_cents = band.cents + surcharge_cents;

    eprintln!(
        "ratecard quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn parse_rate_card(input: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, line) in input.lines().enumerate() {
        let line_number = index + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let max_grams = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        zones.entry(fields[0].to_owned()).or_default().push(Band { max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_unstable_by_key(|band| band.max_grams);
    }
    Ok(zones)
}

pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}

#[cfg(test)]
mod tests {
    use std::{
        env, fs,
        sync::{Mutex, OnceLock},
        time::{SystemTime, UNIX_EPOCH},
    };

    use super::{quote, Parcel, QuoteError};

    fn with_rate_card(contents: &str, test: impl FnOnce()) {
        let _environment_guard = environment_lock().lock().unwrap();
        let path = env::temp_dir().join(format!(
            "ratecard-test-{}-{}.tsv",
            std::process::id(),
            SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos()
        ));
        fs::write(&path, contents).unwrap();
        env::set_var("RATECARD_PATH", &path);
        test();
        env::remove_var("RATECARD_PATH");
        fs::remove_file(path).unwrap();
    }

    fn environment_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    #[test]
    fn selects_sorted_band_and_combines_surcharges() {
        with_rate_card(
            "# example\ndomestic\t2000\t899\ndomestic\t500\t599\ninternational\t20000\t4999\n",
            || {
                let domestic = quote(&Parcel {
                    weight_grams: 500,
                    zone: "domestic".into(),
                })
                .unwrap();
                assert_eq!(domestic.base_cents, 599);
                assert_eq!(domestic.band_max_grams, 500);

                let international = quote(&Parcel {
                    weight_grams: 10_001,
                    zone: "international".into(),
                })
                .unwrap();
                assert_eq!(international.surcharge_cents, 1_500);
                assert_eq!(international.total_cents, 6_499);
            },
        );
    }

    #[test]
    fn reports_unknown_zone_and_overweight() {
        with_rate_card("domestic\t500\t599\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "other".into()
                })
                .unwrap_err(),
                QuoteError::UnknownZone("other".into())
            );
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 501,
                    zone: "domestic".into()
                })
                .unwrap_err(),
                QuoteError::Overweight {
                    grams: 501,
                    limit: 500
                }
            );
        });
    }

    #[test]
    fn reports_bad_card_and_unavailable_card() {
        let _environment_guard = environment_lock().lock().unwrap();
        env::remove_var("RATECARD_PATH");
        assert_eq!(
            quote(&Parcel {
                weight_grams: 1,
                zone: "domestic".into()
            })
            .unwrap_err(),
            QuoteError::RateCardUnavailable
        );
        drop(_environment_guard);
        with_rate_card("# one\n\ndomestic 500 599\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                })
                .unwrap_err(),
                QuoteError::MalformedRateCard { line: 3 }
            );
        });
    }

    #[test]
    fn international_percentage_rounds_half_up() {
        with_rate_card("international\t500\t3\n", || {
            let quote = quote(&Parcel {
                weight_grams: 1,
                zone: "international".into(),
            })
            .unwrap();
            assert_eq!(quote.surcharge_cents, 1);
        });
    }
}
