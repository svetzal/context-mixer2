//! Shipping quote calculation from a tab-separated rate card.

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

/// A parcel for which to calculate a shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The components of a shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Failures that can occur while calculating a quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "rate card is malformed on line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weighing {grams}g exceeds the {limit}g limit")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculates a shipping quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let rate_card = parse_rate_card(&contents)?;

    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let limit = bands
        .last()
        .expect("rate-card parser creates a zone only after adding a band")
        .max_grams;
    let band = bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        },
    )?;

    let mut surcharge_cents: u64 = if parcel.weight_grams > 10_000 { 500 } else { 0 };
    if parcel.zone == "international" {
        surcharge_cents = surcharge_cents.saturating_add(round_twenty_percent(band.cents));
    }
    let total_cents = band.cents.saturating_add(surcharge_cents);
    let result = Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    };

    eprintln!(
        "ratecard quote: zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, result.total_cents
    );

    Ok(result)
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, raw_line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let line = raw_line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = raw_line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let max_grams = fields[1]
            .trim()
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .trim()
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        zones
            .entry(fields[0].trim().to_owned())
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }
    Ok(zones)
}

fn round_twenty_percent(cents: u64) -> u64 {
    // Splitting the division avoids overflowing when cents is close to u64::MAX.
    cents / 5 + u64::from(cents % 5 >= 3)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::sync::{Mutex, OnceLock};

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    fn environment_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    fn with_card<T>(card: &str, operation: impl FnOnce() -> T) -> T {
        let _guard = environment_lock().lock().unwrap();
        static NEXT_FILE: AtomicUsize = AtomicUsize::new(0);
        let file = env::temp_dir().join(format!(
            "ratecard-test-{}-{}",
            std::process::id(),
            NEXT_FILE.fetch_add(1, Ordering::Relaxed)
        ));
        fs::write(&file, card).unwrap();
        env::set_var("RATECARD_PATH", &file);
        let result = operation();
        env::remove_var("RATECARD_PATH");
        fs::remove_file(file).unwrap();
        result
    }

    #[test]
    fn selects_the_first_matching_band() {
        let result = with_card(CARD, || {
            quote(&Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            })
        });
        assert_eq!(
            result.unwrap(),
            Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2000,
            }
        );
    }

    #[test]
    fn adds_international_and_weight_surcharges() {
        let result = with_card(CARD, || {
            quote(&Parcel {
                weight_grams: 10_001,
                zone: "international".into(),
            })
        });
        let quote = result.unwrap();
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn identifies_unknown_and_overweight_parcels() {
        let unknown = with_card(CARD, || {
            quote(&Parcel {
                weight_grams: 1,
                zone: "moon".into(),
            })
        });
        assert_eq!(unknown, Err(QuoteError::UnknownZone("moon".into())));

        let overweight = with_card(CARD, || {
            quote(&Parcel {
                weight_grams: 20_001,
                zone: "domestic".into(),
            })
        });
        assert_eq!(
            overweight,
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            })
        );
    }

    #[test]
    fn reports_the_physical_line_for_malformed_cards() {
        let result = with_card("# a comment\n\n domestic\tnope\t100\n", || {
            quote(&Parcel {
                weight_grams: 1,
                zone: "domestic".into(),
            })
        });
        assert_eq!(result, Err(QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn unavailable_card_is_an_error() {
        let _guard = environment_lock().lock().unwrap();
        env::remove_var("RATECARD_PATH");
        let result = quote(&Parcel {
            weight_grams: 1,
            zone: "domestic".into(),
        });
        assert_eq!(result, Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn rate_bands_are_sorted_by_weight() {
        let result = with_card("domestic\t2000\t900\ndomestic\t500\t600\n", || {
            quote(&Parcel {
                weight_grams: 400,
                zone: "domestic".into(),
            })
        });
        assert_eq!(result.unwrap().base_cents, 600);
    }
}
