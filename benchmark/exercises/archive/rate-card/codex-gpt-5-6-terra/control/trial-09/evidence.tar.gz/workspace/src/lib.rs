pub mod zones;

use std::{env, error::Error, fmt, fs};

/// A parcel to price against the configured rate card.
#[derive(Debug, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price resulting from matching a parcel to a rate band.
#[derive(Debug, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Failures that can occur while loading or applying a rate card.
#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed on line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds the {limit}g limit")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug)]
struct RateBand {
    max_grams: u32,
    cents: u64,
}

/// Calculates a shipping quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .iter()
        .filter(|(zone, _)| zone == &parcel.zone)
        .map(|(_, band)| band)
        .collect::<Vec<_>>();

    if bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let largest_band = bands.last().expect("a non-empty collection always has a final band");
    let band = match bands.iter().find(|band| band.max_grams >= parcel.weight_grams) {
        Some(band) => *band,
        None => {
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: largest_band.max_grams,
            });
        }
    };

    let mut surcharge_cents = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += international_surcharge(band.cents);
    }

    let quote = Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    };

    eprintln!(
        "ratecard quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, quote.total_cents
    );

    Ok(quote)
}

fn load_rate_card() -> Result<Vec<(String, RateBand)>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let mut bands = Vec::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields = line.split('\t').collect::<Vec<_>>();
        let [zone, max_grams, cents] = fields.as_slice() else {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        };
        let max_grams = max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents =
            cents.parse().map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        bands.push(((*zone).to_owned(), RateBand { max_grams, cents }));
    }

    bands.sort_by_key(|(zone, band)| (zone.clone(), band.max_grams));
    Ok(bands)
}

fn international_surcharge(base_cents: u64) -> u64 {
    // 20% is one fifth. Remainders 3 and 4 are at least half a cent and round up.
    base_cents / 5 + u64::from(base_cents % 5 >= 3)
}

#[cfg(test)]
mod tests {
    use std::{
        env, fs,
        sync::{
            atomic::{AtomicUsize, Ordering},
            Mutex,
        },
    };

    use super::*;

    static RATE_CARD_ENV_LOCK: Mutex<()> = Mutex::new(());
    static NEXT_TEST_FILE: AtomicUsize = AtomicUsize::new(0);

    fn with_rate_card<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        let _guard = RATE_CARD_ENV_LOCK.lock().unwrap();
        let path = env::temp_dir().join(format!(
            "ratecard-test-{}-{}",
            std::process::id(),
            NEXT_TEST_FILE.fetch_add(1, Ordering::Relaxed)
        ));
        fs::write(&path, contents).unwrap();
        env::set_var("RATECARD_PATH", &path);
        let result = test();
        env::remove_var("RATECARD_PATH");
        fs::remove_file(path).unwrap();
        result
    }

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    #[test]
    fn selects_the_first_sufficient_band() {
        with_rate_card(CARD, || {
            let quote = quote(&Parcel {
                weight_grams: 501,
                zone: "domestic".to_owned(),
            })
            .unwrap();

            assert_eq!(quote.base_cents, 899);
            assert_eq!(quote.surcharge_cents, 0);
            assert_eq!(quote.total_cents, 899);
            assert_eq!(quote.band_max_grams, 2000);
        });
    }

    #[test]
    fn adds_both_surcharges_and_rounds_international_half_up() {
        with_rate_card(CARD, || {
            let quote = quote(&Parcel {
                weight_grams: 10_001,
                zone: "international".to_owned(),
            })
            .unwrap();

            assert_eq!(quote.base_cents, 4999);
            assert_eq!(quote.surcharge_cents, 1500);
            assert_eq!(quote.total_cents, 6499);
        });
    }

    #[test]
    fn reports_unknown_zones_and_overweight_parcels() {
        with_rate_card(CARD, || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "moon".to_owned()
                }),
                Err(QuoteError::UnknownZone("moon".to_owned()))
            );
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 20_001,
                    zone: "domestic".to_owned()
                }),
                Err(QuoteError::Overweight {
                    grams: 20_001,
                    limit: 20_000
                })
            );
        });
    }

    #[test]
    fn reports_unavailable_and_malformed_rate_cards() {
        let _guard = RATE_CARD_ENV_LOCK.lock().unwrap();
        env::remove_var("RATECARD_PATH");
        assert_eq!(
            quote(&Parcel {
                weight_grams: 1,
                zone: "domestic".to_owned()
            }),
            Err(QuoteError::RateCardUnavailable)
        );
        drop(_guard);

        with_rate_card("# comment\n\ndomestic\tnot-a-number\t599", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".to_owned()
                }),
                Err(QuoteError::MalformedRateCard { line: 3 })
            );
        });
    }
}
