//! Shipping quote calculation from a tab-separated rate card.

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

/// A parcel to quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price components selected for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Errors that can occur while reading a rate card or quoting a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighing {grams} grams exceeds the {limit}-gram limit")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculates a shipping quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = read_rate_card()?;
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let limit = bands.last().expect("every rate-card zone has at least one band").max_grams;
    let band = bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        },
    )?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    // Adding 50 before division implements half-up rounding for 20 percent.
    let international_surcharge = if parcel.zone == "international" {
        (band.cents * 20 + 50) / 100
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;
    let quote = Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    };

    eprintln!(
        "ratecard quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, quote.total_cents
    );

    Ok(quote)
}

fn read_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let mut rate_card: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        let [zone, max_grams, cents] = fields.as_slice() else {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        };
        let max_grams = max_grams
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        let cents = cents
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;

        rate_card.entry((*zone).to_owned()).or_default().push(Band { max_grams, cents });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(rate_card)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;
    use std::sync::{Mutex, OnceLock};
    use std::time::{SystemTime, UNIX_EPOCH};

    fn environment_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    fn with_rate_card<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        let _guard = environment_lock().lock().unwrap();
        let path = temporary_rate_card_path();
        fs::write(&path, contents).unwrap();
        let previous = env::var_os("RATECARD_PATH");
        env::set_var("RATECARD_PATH", &path);
        let result = test();
        match previous {
            Some(value) => env::set_var("RATECARD_PATH", value),
            None => env::remove_var("RATECARD_PATH"),
        }
        fs::remove_file(path).unwrap();
        result
    }

    fn temporary_rate_card_path() -> PathBuf {
        let unique = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos();
        env::temp_dir().join(format!("ratecard-test-{}-{unique}.tsv", std::process::id()))
    }

    #[test]
    fn selects_sorted_band_and_combines_surcharges() {
        with_rate_card(
            "international\t20000\t4999\ninternational\t500\t1499\ndomestic\t20000\t1799\n",
            || {
                assert_eq!(
                    quote(&Parcel {
                        weight_grams: 10_001,
                        zone: "international".into(),
                    }),
                    Ok(Quote {
                        base_cents: 4999,
                        surcharge_cents: 1500,
                        total_cents: 6499,
                        band_max_grams: 20_000,
                    })
                );
            },
        );
    }

    #[test]
    fn rounds_international_surcharge_half_up() {
        with_rate_card("international\t500\t3\n", || {
            let result = quote(&Parcel {
                weight_grams: 500,
                zone: "international".into(),
            });
            assert_eq!(result.unwrap().surcharge_cents, 1);
        });
    }

    #[test]
    fn reports_rate_card_and_selection_errors() {
        {
            let _guard = environment_lock().lock().unwrap();
            let previous = env::var_os("RATECARD_PATH");
            env::remove_var("RATECARD_PATH");
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".into(),
                }),
                Err(QuoteError::RateCardUnavailable)
            );
            if let Some(value) = previous {
                env::set_var("RATECARD_PATH", value);
            }
        }

        with_rate_card("domestic\t500\t599\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "international".into(),
                }),
                Err(QuoteError::UnknownZone("international".into()))
            );
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 501,
                    zone: "domestic".into(),
                }),
                Err(QuoteError::Overweight {
                    grams: 501,
                    limit: 500,
                })
            );
        });
    }

    #[test]
    fn malformed_lines_report_their_physical_line_number() {
        with_rate_card("# heading\n\ndomestic\t500\t599\nbroken\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".into(),
                }),
                Err(QuoteError::MalformedRateCard { line: 4 })
            );
        });
    }
}
