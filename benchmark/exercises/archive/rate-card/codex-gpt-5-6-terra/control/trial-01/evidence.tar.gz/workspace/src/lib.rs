//! Shipping quotes calculated from a tab-separated rate card.

use std::{env, error::Error, fmt, fs};

pub mod zones;

/// A parcel to price.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The component prices selected for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// An error encountered while loading or applying a rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown delivery zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit of {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculates a shipping quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let mut bands: Vec<Band> = rate_card
        .into_iter()
        .filter(|(zone, _)| zone == &parcel.zone)
        .map(|(_, band)| band)
        .collect();

    if bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    bands.sort_unstable_by_key(|band| band.max_grams);
    let limit = bands.last().expect("non-empty bands have a last element").max_grams;
    let band = bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        },
    )?;

    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents = surcharge_cents.saturating_add(percent_half_up(band.cents, 20));
    }

    let result = Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    };

    eprintln!(
        "ratecard quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, result.total_cents
    );
    Ok(result)
}

fn load_rate_card() -> Result<Vec<(String, Band)>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    contents
        .lines()
        .enumerate()
        .filter(|(_, line)| !line.is_empty() && !line.starts_with('#'))
        .map(|(index, line)| parse_band(line, index + 1))
        .collect()
}

fn parse_band(line: &str, line_number: usize) -> Result<(String, Band), QuoteError> {
    let fields: Vec<_> = line.split('\t').collect();
    let malformed = || QuoteError::MalformedRateCard { line: line_number };
    if fields.len() != 3 {
        return Err(malformed());
    }

    let max_grams = fields[1].parse().map_err(|_| malformed())?;
    let cents = fields[2].parse().map_err(|_| malformed())?;
    Ok((fields[0].to_owned(), Band { max_grams, cents }))
}

fn percent_half_up(value: u64, percent: u64) -> u64 {
    // Splitting the division avoids overflowing when the rate itself is large.
    let whole = value / 100;
    let remainder = value % 100;
    whole.saturating_mul(percent).saturating_add((remainder * percent + 50) / 100)
}

/// Returns a human-readable label for the built-in zones.
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}

#[cfg(test)]
mod tests {
    use std::{
        env, fs,
        sync::{
            atomic::{AtomicUsize, Ordering},
            Mutex,
        },
    };

    use super::*;

    static ENV_LOCK: Mutex<()> = Mutex::new(());
    static TEMP_DIRECTORY_COUNTER: AtomicUsize = AtomicUsize::new(0);

    fn with_rate_card<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        let _guard = ENV_LOCK.lock().unwrap();
        let directory = env::temp_dir().join(format!(
            "ratecard-tests-{}-{}",
            std::process::id(),
            TEMP_DIRECTORY_COUNTER.fetch_add(1, Ordering::Relaxed)
        ));
        fs::create_dir(&directory).unwrap();
        let path = directory.join("rates.tsv");
        fs::write(&path, contents).unwrap();
        let previous = env::var_os("RATECARD_PATH");
        env::set_var("RATECARD_PATH", &path);
        let result = test();
        if let Some(value) = previous {
            env::set_var("RATECARD_PATH", value);
        } else {
            env::remove_var("RATECARD_PATH");
        }
        fs::remove_dir_all(directory).unwrap();
        result
    }

    #[test]
    fn selects_the_first_eligible_band_after_sorting() {
        with_rate_card("domestic\t2000\t899\ndomestic\t500\t599\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 500,
                    zone: "domestic".into(),
                }),
                Ok(Quote {
                    base_cents: 599,
                    surcharge_cents: 0,
                    total_cents: 599,
                    band_max_grams: 500,
                })
            );
        });
    }

    #[test]
    fn combines_weight_and_international_surcharges() {
        with_rate_card("international\t20000\t4999\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 10_001,
                    zone: "international".into(),
                }),
                Ok(Quote {
                    base_cents: 4999,
                    surcharge_cents: 1_500,
                    total_cents: 6_499,
                    band_max_grams: 20_000,
                })
            );
        });
    }

    #[test]
    fn reports_rate_card_and_lookup_errors() {
        with_rate_card("# heading\n\ndomestic\t500\t599\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 501,
                    zone: "domestic".into(),
                }),
                Err(QuoteError::Overweight {
                    grams: 501,
                    limit: 500,
                })
            );
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "other".into(),
                }),
                Err(QuoteError::UnknownZone("other".into()))
            );
        });
    }

    #[test]
    fn malformed_lines_keep_physical_line_numbers() {
        with_rate_card("# heading\n\ndomestic\t500\toops\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".into(),
                }),
                Err(QuoteError::MalformedRateCard { line: 3 })
            );
        });
    }
}
