pub mod zones;

use std::{env, fmt, fs};

/// A parcel to price against the current rate card.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The component prices selected for a parcel.
#[derive(Debug, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// A reason a quote could not be calculated.
#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug)]
struct RateBand {
    zone: String,
    max_grams: u32,
    cents: u64,
}

/// Calculate a shipping quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = read_rate_card()?;
    let mut zone_bands: Vec<_> =
        bands.into_iter().filter(|band| band.zone == parcel.zone).collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|band| band.max_grams);
    let limit = zone_bands.last().expect("non-empty zone bands have a largest limit").max_grams;
    let band = zone_bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        },
    )?;

    let international_surcharge = if parcel.zone == "international" {
        // Twenty percent is one fifth. Adding two before division rounds ties up.
        (band.cents + 2) / 5
    } else {
        0
    };
    let weight_surcharge = if parcel.weight_grams > 10_000 { 500 } else { 0 };
    let surcharge_cents = international_surcharge + weight_surcharge;
    let total_cents = band.cents + surcharge_cents;
    let result = Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    };

    eprintln!(
        "ratecard quote: zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, result.total_cents
    );

    Ok(result)
}

fn read_rate_card() -> Result<Vec<RateBand>, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    contents
        .lines()
        .enumerate()
        .filter_map(|(index, raw_line)| {
            let line = raw_line.strip_suffix('\r').unwrap_or(raw_line);
            (!line.is_empty() && !line.starts_with('#')).then_some((index + 1, line))
        })
        .map(|(line_number, line)| parse_band(line, line_number))
        .collect()
}

fn parse_band(line: &str, line_number: usize) -> Result<RateBand, QuoteError> {
    let mut fields = line.split('\t');
    let zone = fields.next();
    let max_grams = fields.next();
    let cents = fields.next();
    if zone.is_none() || max_grams.is_none() || cents.is_none() || fields.next().is_some() {
        return Err(QuoteError::MalformedRateCard { line: line_number });
    }

    let max_grams = max_grams
        .expect("field count was checked")
        .parse()
        .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
    let cents = cents
        .expect("field count was checked")
        .parse()
        .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

    Ok(RateBand {
        zone: zone.expect("field count was checked").to_owned(),
        max_grams,
        cents,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::{
        ffi::OsString,
        sync::{
            atomic::{AtomicUsize, Ordering},
            Mutex,
        },
    };

    static ENV_LOCK: Mutex<()> = Mutex::new(());
    static NEXT_FILE_ID: AtomicUsize = AtomicUsize::new(0);

    fn with_rate_card<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        let _lock = ENV_LOCK.lock().expect("environment lock poisoned");
        let file = env::temp_dir().join(format!(
            "ratecard-test-{}-{}",
            std::process::id(),
            NEXT_FILE_ID.fetch_add(1, Ordering::Relaxed)
        ));
        fs::write(&file, contents).expect("write rate card");
        let old_path = env::var_os("RATECARD_PATH");
        env::set_var("RATECARD_PATH", &file);
        let result = test();
        match old_path {
            Some(path) => env::set_var("RATECARD_PATH", path),
            None => env::remove_var("RATECARD_PATH"),
        }
        fs::remove_file(file).expect("remove temporary rate card");
        result
    }

    const CARD: &str = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\ninternational\t500\t1499\ninternational\t20000\t4999\n";

    #[test]
    fn selects_the_first_matching_band() {
        with_rate_card(CARD, || {
            let result = quote(&Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            })
            .expect("quote succeeds");
            assert_eq!(result.base_cents, 899);
            assert_eq!(result.surcharge_cents, 0);
            assert_eq!(result.total_cents, 899);
            assert_eq!(result.band_max_grams, 2000);
        });
    }

    #[test]
    fn sums_weight_and_international_surcharges() {
        with_rate_card(CARD, || {
            let result = quote(&Parcel {
                weight_grams: 10_001,
                zone: "international".into(),
            })
            .expect("quote succeeds");
            assert_eq!(result.surcharge_cents, 1_500);
            assert_eq!(result.total_cents, 6_499);
        });
    }

    #[test]
    fn rounds_international_surcharge_half_up() {
        with_rate_card("international\t10\t3\n", || {
            let result = quote(&Parcel {
                weight_grams: 1,
                zone: "international".into(),
            })
            .expect("quote succeeds");
            assert_eq!(result.surcharge_cents, 1);
        });
    }

    #[test]
    fn reports_rate_card_and_selection_errors() {
        let _lock = ENV_LOCK.lock().expect("environment lock poisoned");
        let old_path: Option<OsString> = env::var_os("RATECARD_PATH");
        env::remove_var("RATECARD_PATH");
        assert_eq!(
            quote(&Parcel {
                weight_grams: 1,
                zone: "domestic".into()
            }),
            Err(QuoteError::RateCardUnavailable)
        );
        match old_path {
            Some(path) => env::set_var("RATECARD_PATH", path),
            None => env::remove_var("RATECARD_PATH"),
        }
        drop(_lock);

        with_rate_card(CARD, || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "missing".into()
                }),
                Err(QuoteError::UnknownZone("missing".into()))
            );
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 20_001,
                    zone: "domestic".into()
                }),
                Err(QuoteError::Overweight {
                    grams: 20_001,
                    limit: 20_000
                })
            );
        });
    }

    #[test]
    fn reports_physical_line_for_malformed_cards() {
        with_rate_card("# header\n\ndomestic\t500\t599\nbad\tnope\t10\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                }),
                Err(QuoteError::MalformedRateCard { line: 4 })
            );
        });
    }
}
