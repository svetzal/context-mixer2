pub mod zones;

use std::{collections::HashMap, env, error::Error, fmt, fs};

/// A parcel to price against the configured rate card.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The itemized price for a parcel.
#[derive(Debug, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Failures that can occur while reading or applying a rate card.
#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighing {grams}g exceeds the {limit}g limit")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Clone, Copy)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculates a shipping quote from the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band =
        bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands.last().expect("a populated zone has a last band").max_grams,
            }
        })?;

    let international_surcharge = if parcel.zone == "international" {
        // This is 20%, rounded half-up, without multiplying a u64 price.
        band.cents / 5 + ((band.cents % 5) * 20 + 50) / 100
    } else {
        0
    };
    let weight_surcharge = if parcel.weight_grams > 10_000 { 500 } else { 0 };
    let surcharge_cents = international_surcharge + weight_surcharge;
    let total_cents = band.cents + surcharge_cents;

    eprintln!(
        "ratecard quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let mut rate_card: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        let [zone, max_grams, cents] = fields.as_slice() else {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        };
        let max_grams = max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        let cents = cents.parse().map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;

        rate_card.entry((*zone).to_owned()).or_default().push(Band { max_grams, cents });
    }

    for bands in rate_card.values_mut() {
        bands.sort_unstable_by_key(|band| band.max_grams);
    }
    Ok(rate_card)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::{
        fs,
        sync::Mutex,
        time::{SystemTime, UNIX_EPOCH},
    };

    static ENV_LOCK: Mutex<()> = Mutex::new(());
    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    fn with_card<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        let _guard = ENV_LOCK.lock().expect("environment lock poisoned");
        let previous = env::var_os("RATECARD_PATH");
        let unique = SystemTime::now().duration_since(UNIX_EPOCH).expect("current time").as_nanos();
        let path = env::temp_dir().join(format!("ratecard-test-{}-{unique}", std::process::id()));
        fs::write(&path, contents).expect("write card");
        env::set_var("RATECARD_PATH", &path);
        let result = test();
        if let Some(path) = previous {
            env::set_var("RATECARD_PATH", path);
        } else {
            env::remove_var("RATECARD_PATH");
        }
        fs::remove_file(path).expect("remove temporary card");
        result
    }

    #[test]
    fn chooses_the_first_matching_band() {
        with_card(CARD, || {
            let result = quote(&Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(result.base_cents, 899);
            assert_eq!(result.band_max_grams, 2000);
            assert_eq!(result.surcharge_cents, 0);
            assert_eq!(result.total_cents, 899);
        });
    }

    #[test]
    fn accumulates_international_and_weight_surcharges() {
        with_card(CARD, || {
            let result = quote(&Parcel {
                weight_grams: 10_001,
                zone: "international".into(),
            })
            .unwrap();
            assert_eq!(result.surcharge_cents, 1500);
            assert_eq!(result.total_cents, 6499);
        });
    }

    #[test]
    fn reports_malformed_unknown_and_overweight_cases() {
        with_card("domestic\t500\t599\nbad row\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                }),
                Err(QuoteError::MalformedRateCard { line: 2 })
            );
        });
        with_card(CARD, || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "other".into()
                }),
                Err(QuoteError::UnknownZone("other".into()))
            );
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 20_001,
                    zone: "domestic".into()
                }),
                Err(QuoteError::Overweight {
                    grams: 20_001,
                    limit: 20_000
                })
            );
        });
    }

    #[test]
    fn reports_an_unavailable_rate_card() {
        let _guard = ENV_LOCK.lock().expect("environment lock poisoned");
        let previous = env::var_os("RATECARD_PATH");
        env::remove_var("RATECARD_PATH");
        let result = quote(&Parcel {
            weight_grams: 1,
            zone: "domestic".into(),
        });
        if let Some(path) = previous {
            env::set_var("RATECARD_PATH", path);
        }
        assert_eq!(result, Err(QuoteError::RateCardUnavailable));
    }
}
