//! Shipping quote calculation backed by a tab-separated rate card.

use std::{collections::HashMap, env, error::Error, fmt, fs};

pub mod zones;

/// A parcel to price against the configured rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The itemized price for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Errors that can occur while loading a rate card or pricing a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => f.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => write!(f, "rate card is malformed on line {line}"),
            Self::UnknownZone(zone) => write!(f, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit of {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculate a quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card_path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents =
        fs::read_to_string(rate_card_path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let zones = parse_rate_card(&contents)?;

    let bands = zones
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band =
        bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands.last().expect("rate-card zones always contain a band").max_grams,
            }
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    // Twenty percent rounded half-up, without multiplying a possibly large rate.
    let international_surcharge = if parcel.zone == "international" {
        band.cents / 5 + (band.cents % 5 + 2) / 5
    } else {
        0
    };
    let surcharge_cents = weight_surcharge.saturating_add(international_surcharge);
    let total_cents = band.cents.saturating_add(surcharge_cents);
    let quote = Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    };

    // Keep the operational record dependency-free so callers can capture it with stderr.
    eprintln!(
        "ratecard quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, quote.total_cents
    );
    Ok(quote)
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, raw_line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let line = raw_line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        zones.entry(fields[0].to_owned()).or_default().push(Band { max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }
    Ok(zones)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::{
        fs,
        sync::{
            atomic::{AtomicUsize, Ordering},
            Mutex,
        },
    };

    static ENV_LOCK: Mutex<()> = Mutex::new(());
    static NEXT_FILE_ID: AtomicUsize = AtomicUsize::new(0);

    fn with_rate_card<T>(card: &str, test: impl FnOnce() -> T) -> T {
        let _guard = ENV_LOCK.lock().unwrap();
        let path = env::temp_dir().join(format!(
            "ratecard-test-{}-{}",
            std::process::id(),
            NEXT_FILE_ID.fetch_add(1, Ordering::Relaxed)
        ));
        fs::write(&path, card).unwrap();
        env::set_var("RATECARD_PATH", &path);
        let result = test();
        env::remove_var("RATECARD_PATH");
        fs::remove_file(path).unwrap();
        result
    }

    #[test]
    fn prices_matching_band_and_combined_surcharges() {
        with_rate_card(
            "domestic\t500\t599\ndomestic\t20000\t1799\ninternational\t20000\t4999\n",
            || {
                assert_eq!(
                    quote(&Parcel {
                        weight_grams: 10_001,
                        zone: "international".into()
                    })
                    .unwrap(),
                    Quote {
                        base_cents: 4999,
                        surcharge_cents: 1500,
                        total_cents: 6499,
                        band_max_grams: 20_000
                    }
                );
            },
        );
    }

    #[test]
    fn reports_unavailable_malformed_unknown_and_overweight_cards() {
        let _guard = ENV_LOCK.lock().unwrap();
        env::remove_var("RATECARD_PATH");
        assert_eq!(
            quote(&Parcel {
                weight_grams: 1,
                zone: "domestic".into()
            }),
            Err(QuoteError::RateCardUnavailable)
        );
        drop(_guard);

        with_rate_card("# header\n\ndomestic\tnot-a-number\t599\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                }),
                Err(QuoteError::MalformedRateCard { line: 3 })
            );
        });
        with_rate_card("domestic\t500\t599\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "other".into()
                }),
                Err(QuoteError::UnknownZone("other".into()))
            );
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 501,
                    zone: "domestic".into()
                }),
                Err(QuoteError::Overweight {
                    grams: 501,
                    limit: 500
                })
            );
        });
    }
}
