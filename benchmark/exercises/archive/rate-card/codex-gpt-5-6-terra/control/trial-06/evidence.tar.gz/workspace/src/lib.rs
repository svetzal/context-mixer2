//! Shipping quote calculation from a tab-separated rate card.

use std::{collections::HashMap, env, error::Error, fmt, fs};

pub mod zones;

/// A parcel to price using the configured rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The calculated price and band selected for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// A reason that a quote could not be calculated.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card on line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighing {grams}g exceeds the {limit}g limit")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculates a quote for `parcel` using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let cards = load_rate_card()?;
    let bands = cards
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band =
        bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands.last().expect("zones always have at least one band").max_grams,
            }
        })?;

    let mut surcharge_cents = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        // Twenty percent is one fifth.  Splitting quotient and remainder
        // preserves half-up rounding without risking multiplication overflow.
        surcharge_cents += band.cents / 5 + u64::from(band.cents % 5 >= 3);
    }

    let quote = Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    };

    eprintln!(
        "ratecard quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, quote.total_cents
    );

    Ok(quote)
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let mut cards: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        cards.entry(fields[0].to_owned()).or_default().push(Band { max_grams, cents });
    }

    for bands in cards.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(cards)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::{
        fs,
        sync::{
            atomic::{AtomicUsize, Ordering},
            Mutex, OnceLock,
        },
    };

    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    fn with_rate_card<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        static NEXT_FIXTURE: AtomicUsize = AtomicUsize::new(0);
        let _guard = env_lock().lock().unwrap();
        let path = env::temp_dir().join(format!(
            "ratecard-test-{}-{}",
            std::process::id(),
            NEXT_FIXTURE.fetch_add(1, Ordering::Relaxed)
        ));
        fs::write(&path, contents).unwrap();
        env::set_var("RATECARD_PATH", &path);
        let result = test();
        env::remove_var("RATECARD_PATH");
        fs::remove_file(path).unwrap();
        result
    }

    #[test]
    fn selects_the_first_matching_band_even_when_the_card_is_unsorted() {
        with_rate_card("domestic\t2000\t899\ndomestic\t500\t599\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 500,
                    zone: "domestic".into()
                })
                .unwrap(),
                Quote {
                    base_cents: 599,
                    surcharge_cents: 0,
                    total_cents: 599,
                    band_max_grams: 500
                }
            );
        });
    }

    #[test]
    fn adds_both_surcharges_and_rounds_international_half_up() {
        with_rate_card("international\t20000\t1799\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 10_001,
                    zone: "international".into()
                })
                .unwrap(),
                Quote {
                    base_cents: 1799,
                    surcharge_cents: 860,
                    total_cents: 2659,
                    band_max_grams: 20_000
                }
            );
        });
    }

    #[test]
    fn reports_unknown_zones_and_overweight_parcels() {
        with_rate_card("domestic\t500\t599\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "other".into()
                }),
                Err(QuoteError::UnknownZone("other".into()))
            );
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 501,
                    zone: "domestic".into()
                }),
                Err(QuoteError::Overweight {
                    grams: 501,
                    limit: 500
                })
            );
        });
    }

    #[test]
    fn distinguishes_unavailable_and_malformed_cards() {
        let _guard = env_lock().lock().unwrap();
        env::remove_var("RATECARD_PATH");
        assert_eq!(
            quote(&Parcel {
                weight_grams: 1,
                zone: "domestic".into()
            }),
            Err(QuoteError::RateCardUnavailable)
        );
        drop(_guard);

        with_rate_card("# heading\n\ndomestic\tbogus\t599\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                }),
                Err(QuoteError::MalformedRateCard { line: 3 })
            );
        });
    }
}
