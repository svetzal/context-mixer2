use crate::{Quote, QuoteError};
use std::collections::BTreeMap;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Band {
    pub max_grams: u32,
    pub cents: u64,
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ZoneTable {
    zones: BTreeMap<String, Vec<Band>>,
}

impl ZoneTable {
    pub fn get(&self, zone: &str) -> Option<&[Band]> {
        self.zones.get(zone).map(|b| b.as_slice())
    }
}

pub fn parse_rate_card(text: &str) -> Result<ZoneTable, QuoteError> {
    let mut table = ZoneTable::default();

    for (idx, raw) in text.lines().enumerate() {
        let line = idx + 1;
        let content = raw.trim_end_matches(['\r']);
        if content.is_empty() || content.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = content.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line });
        }

        let zone = fields[0].trim();
        let max_grams: u32 = fields[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line })?;
        let cents: u64 = fields[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line })?;

        table
            .zones
            .entry(zone.to_string())
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in table.zones.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(table)
}

fn percent_half_up(amount: u64, numerator: u64, denominator: u64) -> u64 {
    // numerator/percent of `amount`, rounded half-up to a whole unit.
    (amount * numerator + denominator / 2) / denominator
}

pub fn compute_quote(
    table: &ZoneTable,
    zone: &str,
    weight_grams: u32,
) -> Result<Quote, QuoteError> {
    let bands = table
        .get(zone)
        .ok_or_else(|| QuoteError::UnknownZone(zone.to_string()))?;

    let band = match bands.iter().find(|b| b.max_grams >= weight_grams) {
        Some(b) => b,
        None => {
            let limit = bands.last().map(|b| b.max_grams).unwrap_or(0);
            return Err(QuoteError::Overweight {
                grams: weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if zone == "international" {
        surcharge_cents += percent_half_up(base_cents, 20, 100);
    }

    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t20000\t1799
domestic\t2000\t899
domestic\t500\t599
international\t20000\t4999
international\t500\t1499
";

    fn table() -> ZoneTable {
        parse_rate_card(CARD).unwrap()
    }

    #[test]
    fn domestic_band_selection_uses_first_threshold_at_or_above_weight() {
        let t = table();
        let q = compute_quote(&t, "domestic", 400).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);

        let q = compute_quote(&t, "domestic", 500).unwrap();
        assert_eq!(q.band_max_grams, 500);

        let q = compute_quote(&t, "domestic", 1500).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn heavy_weight_surcharge_applies_above_10000() {
        let t = table();
        let q = compute_quote(&t, "domestic", 10_001).unwrap();
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, q.base_cents + 500);

        let q = compute_quote(&t, "domestic", 10_000).unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn international_surcharge_is_20_percent_rounded_half_up() {
        let t = table();
        // 1499 * 20% = 299.8 -> 300
        let q = compute_quote(&t, "international", 400).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn surcharges_add_together() {
        let t = table();
        // international, weight above 10000: 20% of base + 500
        let q = compute_quote(&t, "international", 15_000).unwrap();
        // base 4999, 20% = 999.8 -> 1000, + 500 heavy surcharge
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1000 + 500);
        assert_eq!(q.total_cents, 4999 + 1000 + 500);
    }

    #[test]
    fn unknown_zone_reports_requested_zone() {
        let t = table();
        match compute_quote(&t, "atlantic", 100) {
            Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "atlantic"),
            other => panic!("expected UnknownZone, got {other:?}"),
        }
    }

    #[test]
    fn weight_over_largest_band_reports_overweight_with_limit() {
        let t = table();
        match compute_quote(&t, "domestic", 25_000) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 25_000);
                assert_eq!(limit, 20_000);
            }
            other => panic!("expected Overweight, got {other:?}"),
        }
    }

    #[test]
    fn malformed_card_reports_one_based_line_number() {
         // Line 2 has too few fields.
        let text = "domestic\t500\t599\nbad\n";
        match parse_rate_card(text) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 2),
            other => panic!("expected MalformedRateCard, got {other:?}"),
        }
    }

    #[test]
    fn non_numeric_field_is_malformed() {
        let text = "domestic\tnotanumber\t599\n";
        match parse_rate_card(text) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            other => panic!("expected MalformedRateCard, got {other:?}"),
        }
    }

    #[test]
    fn comments_and_blanks_are_skipped_but_counted_in_line_numbers() {
        let text = "# header\n\ndomestic\t500\t599\n";
        let t = parse_rate_card(text).unwrap();
        let q = compute_quote(&t, "domestic", 100).unwrap();
        assert_eq!(q.base_cents, 599);
    }
}
