mod core;
pub mod zones;

use std::fs;

use core::{compute_quote, parse_rate_card};

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight {
        grams: u32,
        limit: u32,
    },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                f.write_str("rate card is unavailable")
            }
            QuoteError::MalformedRateCard { line } => write!(
                f,
                "rate card is malformed at line {line}"
            ),
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let text = fs::read_to_string(rate_card_path()?).map_err(|_| QuoteError::RateCardUnavailable)?;
    let table = parse_rate_card(&text)?;
    let result = compute_quote(&table, &parcel.zone, parcel.weight_grams);
    let total = result.as_ref().map(|q| q.total_cents).ok();
    record_diagnostic(&parcel.zone, parcel.weight_grams, total);
    result
}

fn rate_card_path() -> Result<std::path::PathBuf, QuoteError> {
    match std::env::var("RATECARD_PATH") {
        Ok(path) if !path.is_empty() => Ok(std::path::PathBuf::from(path)),
        _ => Err(QuoteError::RateCardUnavailable),
    }
}

fn record_diagnostic(zone: &str, weight_grams: u32, total: Option<u64>) {
    tracing::info!(
        zone = %zone,
        weight_grams,
        total_cents = total,
        "quote computed"
    );
}

#[cfg(test)]
mod shell_tests {
    use super::*;
    use std::fs;
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn write_card(text: &str) -> std::io::Result<std::path::PathBuf> {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("ratecard.tsv");
        fs::write(&path, text)?;
         // Keep the tempdir alive for the duration of the process by leaking it.
        std::mem::forget(dir);
        Ok(path.clone())
     }

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

     #[test]
    fn missing_env_is_unavailable() {
        let _lock = ENV_LOCK.lock().unwrap();
        std::env::remove_var("RATECARD_PATH");
        let p = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
         };
        assert_eq!(quote(&p), Err(QuoteError::RateCardUnavailable));
     }

     #[test]
    fn unreadable_path_is_unavailable() {
        let _lock = ENV_LOCK.lock().unwrap();
        std::env::set_var("RATECARD_PATH", "/no/such/file/here.tsv");
        let p = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
         };
        assert_eq!(quote(&p), Err(QuoteError::RateCardUnavailable));
        std::env::remove_var("RATECARD_PATH");
     }

     #[test]
    fn full_quote_flow_reads_card_and_prices() {
        let _lock = ENV_LOCK.lock().unwrap();
        let path = write_card(CARD).unwrap();
        std::env::set_var("RATECARD_PATH", path.to_str().unwrap());

        let p = Parcel {
            weight_grams: 400,
            zone: "international".to_string(),
         };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
        assert_eq!(q.band_max_grams, 500);
        std::env::remove_var("RATECARD_PATH");
     }

     #[test]
    fn malformed_card_surfaces_line_number() {
        let _lock = ENV_LOCK.lock().unwrap();
        let path = write_card("domestic\t500\n").unwrap();
        std::env::set_var("RATECARD_PATH", path.to_str().unwrap());
        let p = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
         };
        assert_eq!(quote(&p), Err(QuoteError::MalformedRateCard { line: 1 }));
        std::env::remove_var("RATECARD_PATH");
     }
}
