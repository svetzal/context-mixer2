//! Shipping quotes for the fulfilment service.
//!
//! A warehouse operator maintains a zone rate card as a tab-separated file and
//! redeploys it without a code change. This crate reads that card and turns a
//! [`Parcel`] into a [`Quote`].
//!
//! The public surface is intentionally small: [`quote`] is the entry point and
//! the types below are its contract.

mod ratecard;

pub use ratecard::RateCard;

pub mod zones;

/// A parcel to be quoted: its weight and the shipping zone it is destined for.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The result of quoting a [`Parcel`].
///
/// All monetary values are in whole cents.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Things that can go wrong when quoting a [`Parcel`].
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, missing, or unreadable.
    RateCardUnavailable,
    /// A line of the rate card was not three tab-separated fields, or one of
    /// its numbers did not parse. Carries the 1-based line number.
    MalformedRateCard { line: usize },
    /// The parcel's zone is absent from the rate card. Carries the zone.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band. Carries the parcel
    /// weight and the largest band's `band_max_grams`.
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {grams}g exceeds limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Quote a [`Parcel`] against the rate card referenced by the `RATECARD_PATH`
/// environment variable.
///
/// The card is read fresh on each call, so operations can redeploy a card
/// without a code change. Each successful quote emits a structured diagnostic
/// record (zone, weight in grams, total in cents) for observability.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH")
         .map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = std::fs::read_to_string(&path)
         .map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = RateCard::parse(&contents)?;
    let quote = card.compute(parcel)?;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = quote.total_cents,
        "quote"
    );

    Ok(quote)
}
