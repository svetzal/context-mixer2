use crate::{Parcel, Quote, QuoteError};
use std::collections::BTreeMap;

/// A parsed rate card: zones mapped to their ascending bands.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

/// A single pricing band: the highest weight (grams) it covers and its flat
/// price in cents.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Band {
    pub max_grams: u32,
    pub cents: u64,
}

/// The weight band above which a flat weight surcharge applies.
const WEIGHT_SURCHARGE_TRIGGER_GRAMS: u32 = 10_000;
/// The flat surcharge (cents) applied when weight is strictly above the trigger.
const WEIGHT_SURCHARGE_CENTS: u64 = 500;

/// The integer numerator of the international surcharge (base * 20 / 100).
const INTL_NUMERATOR: u128 = 20;
const INTL_DENOMINATOR: u128 = 100;

/// The zone name that attracts the international surcharge.
const INTERNATIONAL_ZONE: &str = "international";

impl RateCard {
    /// Parse tab-separated rate card text. Blank lines and lines whose first
    /// trimmed character is `#` are ignored. Every other line must be exactly
    /// three tab-separated fields: `zone`, `band_max_grams`, `cents`. A line
    /// that is not three fields, or whose numbers do not parse, yields
    /// [`QuoteError::MalformedRateCard`] carrying the 1-based line number,
    /// counting every line including comments and blanks.
    ///
    /// ```
    /// use ratecard::{RateCard, Parcel, QuoteError};
    ///
    /// let card = RateCard::parse("domestic\t500\t599\ndomestic\t2000\t899\n")?;
    /// let parcel = Parcel { weight_grams: 750, zone: "domestic".to_string() };
    /// let q = card.compute(&parcel)?;
    /// assert_eq!(q.base_cents, 899);
    /// assert_eq!(q.band_max_grams, 2000);
    /// # Ok::<(), QuoteError>(())
    /// ```
    pub fn parse(contents: &str) -> Result<RateCard, QuoteError> {
        let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

        for (idx, raw) in contents.lines().enumerate() {
            let line_no = idx + 1;
            let content = raw.strip_suffix('\r').unwrap_or(raw);
            if content.trim().is_empty() || content.starts_with('#') {
                continue;
              }

            let fields: Vec<&str> = content.split('\t').collect();
            if fields.len() != 3 {
                return Err(QuoteError::MalformedRateCard {
                    line: line_no,
                });
            }

            let zone = fields[0].to_string();
            let max_grams = fields[1]
                 .parse::<u32>()
                 .map_err(|_| QuoteError::MalformedRateCard {
                    line: line_no,
                })?;
            let cents = fields[2]
                 .parse::<u64>()
                 .map_err(|_| QuoteError::MalformedRateCard {
                    line: line_no,
                })?;

            zones.entry(zone).or_default().push(Band {
                max_grams,
                cents,
            });
        }

        for bands in zones.values_mut() {
            bands.sort_unstable_by_key(|band| band.max_grams);
        }

        Ok(RateCard { zones })
    }

    /// Turn a parcel into a quote against this rate card. Pure: no I/O.
    pub fn compute(&self, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let bands = self
            .zones
            .get(&parcel.zone)
            .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

        let band = bands
            .iter()
            .find(|band| band.max_grams >= parcel.weight_grams)
            .ok_or_else(|| {
                let limit = bands.iter().map(|band| band.max_grams).max().unwrap_or(0);
                QuoteError::Overweight {
                    grams: parcel.weight_grams,
                    limit,
                }
            })?;

        let base_cents = band.cents;
        let band_max_grams = band.max_grams;

        let mut surcharge_cents: u64 = 0;
        if parcel.weight_grams > WEIGHT_SURCHARGE_TRIGGER_GRAMS {
            surcharge_cents += WEIGHT_SURCHARGE_CENTS;
        }
        if parcel.zone == INTERNATIONAL_ZONE {
            let v = (base_cents as u128) * INTL_NUMERATOR;
            let intl = ((v + INTL_DENOMINATOR / 2) / INTL_DENOMINATOR) as u64;
            surcharge_cents += intl;
        }

        Ok(Quote {
            base_cents,
            surcharge_cents,
            total_cents: base_cents + surcharge_cents,
            band_max_grams,
         })
     }
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used)]
mod tests {
    use super::{Band, RateCard};
    use crate::{Parcel, QuoteError};

    fn parcel(weight: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams: weight,
            zone: zone.to_string(),
        }
    }

    fn card() -> RateCard {
        RateCard::parse(
            "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
# a mid-card comment
domestic\t20000\t1799

international\t500\t1499
international\t20000\t4999",
        )
          .expect("rate card should parse")
    }

    #[test]
     fn ignores_comments_and_blank_lines() {
        let c = RateCard::parse("\n# header\n\n")
             .expect("empty card parses");
        assert!(c.compute(&parcel(10, "x")).is_err());
    }

    #[test]
    fn matches_lowest_band_covering_the_weight() {
        let c = card();
        let q = c.compute(&parcel(750, "domestic")).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 899);
     }

    #[test]
     fn weight_exactly_at_band_max_matches_that_band() {
        let c = card();
        let q = c.compute(&parcel(500, "domestic")).unwrap();
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.base_cents, 599);
     }

    #[test]
     fn weight_strictly_above_10kg_adds_flat_surcharge() {
        let c = card();
        let q = c.compute(&parcel(10_001, "domestic")).unwrap();
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 1799 + 500);
     }

    #[test]
     fn weight_exactly_at_10kg_has_no_weight_surcharge() {
        let c = card();
        let q = c.compute(&parcel(10_000, "domestic")).unwrap();
        assert_eq!(q.surcharge_cents, 0);
     }

    #[test]
     fn international_adds_20_percent_rounded_half_up() {
        let c = card();
        let q = c.compute(&parcel(300, "international")).unwrap();
        assert_eq!(q.base_cents, 1499);
        // 1499 * 20% = 299.8 -> rounds half-up to 300
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
     }

    #[test]
     fn international_rounding_is_half_up_on_exact_half() {
        let c = RateCard::parse("international\t500\t25\n").unwrap();
        // 25 * 20% = 5.0 exactly -> 5
        let q = c.compute(&parcel(100, "international")).unwrap();
        assert_eq!(q.surcharge_cents, 5);
       let c = RateCard::parse("international\t500\t155\n").unwrap();
        // 155 * 20% = 31.0 -> 31
        let q = c.compute(&parcel(100, "international")).unwrap();
        assert_eq!(q.surcharge_cents, 31);
       let c = RateCard::parse("international\t500\t125\n").unwrap();
        // 125 * 20% = 25.0 -> 25
        let q = c.compute(&parcel(100, "international")).unwrap();
        assert_eq!(q.surcharge_cents, 25);
    }

    #[test]
    fn international_and_weight_surcharges_add_together() {
        let c = card();
        // 30000g is above the 20000 band -> Overweight, so use 19000 to stay in band.
        let q = c
             .compute(&parcel(19_000, "international"))
             .unwrap();
        assert_eq!(q.base_cents, 4999);
        // weight surcharge 500 + intl 999.8 -> 1000 -> 1500 total surcharge
        assert_eq!(q.surcharge_cents, 500 + 1000);
        assert_eq!(q.total_cents, 4999 + 1500);
     }

    #[test]
    fn unknown_zone_carries_the_requested_zone() {
        let c = card();
        let err = c.compute(&parcel(100, "antarctic")).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("antarctic".to_string()));
     }

    #[test]
    fn overweight_carries_weight_and_largest_band() {
        let c = card();
        let err = c.compute(&parcel(30_000, "domestic")).unwrap_err();
        assert_eq!(err, QuoteError::Overweight { grams: 30_000, limit: 20_000 });
     }

    #[test]
    fn malformed_line_wrong_field_count_reports_line_number() {
        let contents = "domestic\t500\t599\nbadline\n";
        let err = RateCard::parse(contents).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
     }

    #[test]
    fn malformed_line_non_numeric_reports_line_number() {
        let contents = "domestic\thmm\t599\n";
        let err = RateCard::parse(contents).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
     }

    #[test]
    fn malformed_line_number_counts_every_line_including_comments_and_blanks() {
        let contents = "\n# header\n\n\tdomestic\t599\ttoomany\n";
        let err = RateCard::parse(contents).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
     }

    #[test]
     fn bands_are_sorted_ascending_by_max_grams() {
        let c = RateCard::parse("domestic\t20000\t1799\ndomestic\t500\t599\n").unwrap();
        let q = c.compute(&parcel(750, "domestic")).unwrap();
        assert_eq!(q.band_max_grams, 20000);
        assert_eq!(q.base_cents, 1799);
     }

    #[test]
     fn band_type_is_cloneable_and_compareable() {
        let a = Band { max_grams: 500, cents: 599 };
        assert_eq!(a, a.clone());
     }
}
