#![allow(clippy::unwrap_used, clippy::expect_used)]
use std::io::Write;
use std::sync::Mutex;
use ratecard::{quote, Parcel, QuoteError};
use tempfile::NamedTempFile;

static ENV_LOCK: Mutex<()> = Mutex::new(());

fn with_ratecard(contents: &str, f: impl FnOnce(&NamedTempFile)) {
    let _guard = ENV_LOCK.lock().unwrap();
    let mut file = NamedTempFile::new().expect("temp file");
    file.write_all(contents.as_bytes()).expect("write card");
    std::env::set_var("RATECARD_PATH", file.path());
    f(&file);
    std::env::remove_var("RATECARD_PATH");
}

fn parcel(weight: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams: weight,
        zone: zone.to_string(),
    }
}

#[tracing_test::traced_test]
#[test]
fn quote_reads_ratecard_from_env_and_emits_record() {
    with_ratecard(
        "domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n\
international\t500\t1499\ninternational\t20000\t4999\n",
        |_file| {
            let q = quote(&parcel(750, "domestic")).expect("quote ok");
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 899);
            assert_eq!(q.band_max_grams, 2000);

            let q = quote(&parcel(15_000, "domestic")).expect("quote ok");
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 1799 + 500);

            let q = quote(&parcel(300, "international")).expect("quote ok");
            assert_eq!(q.base_cents, 1499);
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        },
    );

    // The diagnostic record is observable: the zone, weight, and total appear.
    assert!(logs_contain("domestic"));
    assert!(logs_contain("750"));
}

#[test]
fn unknown_zone_is_reported() {
    with_ratecard("domestic\t2000\t899\n", |_file| {
        let err = quote(&parcel(100, "antarctic")).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("antarctic".to_string()));
    });
}

#[test]
fn overweight_is_reported_with_largest_band() {
    with_ratecard("domestic\t2000\t899\ndomestic\t20000\t1799\n", |_file| {
        let err = quote(&parcel(30_000, "domestic")).unwrap_err();
        assert_eq!(err, QuoteError::Overweight { grams: 30_000, limit: 20_000 });
    });
}

#[test]
fn malformed_line_reports_1_based_line_number() {
    with_ratecard(
          "domestic\t500\t599\ndomestic\t2000\t899\nbadline\n",
          |_file| {
            let err = quote(&parcel(100, "domestic")).unwrap_err();
            assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
         },
      );
}

#[test]
fn missing_ratecard_env_var_is_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap();
    std::env::remove_var("RATECARD_PATH");
    let err = quote(&parcel(100, "domestic")).unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn unreadable_ratecard_path_is_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap();
    std::env::set_var("RATECARD_PATH", "/nonexistent/path/does-not-exist.csv");
    let err = quote(&parcel(100, "domestic")).unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);
    std::env::remove_var("RATECARD_PATH");
}
