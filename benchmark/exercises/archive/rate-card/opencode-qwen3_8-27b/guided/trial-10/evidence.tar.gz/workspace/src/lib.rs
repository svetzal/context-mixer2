//! Shipping quotes for the fulfilment service.
//!
//! `quote` turns a [`Parcel`] into a [`Quote`] by pricing it against a rate card
//! that operations maintains in a file and points at via the `RATECARD_PATH`
//! environment variable. The pricing rules themselves live in a private core
//! module and are pure; this module only wires the file read and the diagnostic.
//!
//! # Example
//!
//! ```no_run
//! use ratecard::{quote, Parcel};
//!
//! let parcel = Parcel {
//!     weight_grams: 250,
//!     zone: "domestic".to_string(),
//! };
//! match quote(&parcel) {
//!     Ok(q) => println!("total {} cents", q.total_cents),
//!     Err(e) => eprintln!("{e}"),
//! }
//! ```

pub mod zones;

mod ratecard;
use ratecard::{price, parse};

/// A parcel to be priced.
///
/// `weight_grams` is the gross weight in grams and `zone` names the rate-card
/// zone it ships to (for example `"domestic"` or `"international"`).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The outcome of pricing a parcel.
///
/// `base_cents` is the matched band's price, `surcharge_cents` is the sum of
/// every applicable surcharge, and `total_cents` is their sum. `band_max_grams`
/// is the threshold of the band the parcel fell into.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// A reason a quote could not be produced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` was unset or the file could not be read.
    RateCardUnavailable,
    /// A non-blank, non-comment rate-card line was not three tab-separated
    /// fields with parseable numbers, at the given 1-based line number.
    MalformedRateCard { line: usize },
    /// No band exists for the requested zone.
    UnknownZone(String),
    /// The parcel's weight exceeds the largest band for its zone.
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                f.write_str("rate card is unavailable (RATECARD_PATH unset or unreadable)")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "rate card is malformed at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone {zone:?}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel overweight: {grams}g exceeds {limit}g limit")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Quote a single parcel.
///
/// The rate card is read from the file named by the `RATECARD_PATH` environment
/// variable. Bands for the parcel's zone apply in ascending `band_max_grams`;
/// the matching band is the first whose threshold meets the parcel's weight.
///
/// Every call emits a traced diagnostic carrying the zone, the weight in grams,
/// and the resulting total in cents, so operators can correlate the operation
/// across calls.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_rate_card()?;

    let outcome = price(&parcel.zone, parcel.weight_grams, &bands);

    match &outcome {
        Ok(q) => tracing::info!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            total_cents = q.total_cents,
            "quote computed"
        ),
        Err(e) => tracing::warn!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            error = %e,
            "quote failed"
        ),
     }

     outcome
}

/// Read and parse the rate card from `RATECARD_PATH`.
///
/// This is the crate's only side-effecting boundary: everything downstream of it
/// is pure. A missing, unset, or unreadable path is `RateCardUnavailable`.
fn load_rate_card() -> Result<Vec<ratecard::Band>, QuoteError> {
    let path = match std::env::var("RATECARD_PATH") {
        Ok(path) => path,
        Err(_) => return Err(QuoteError::RateCardUnavailable),
    };
    let text = std::fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse(&text)
}
