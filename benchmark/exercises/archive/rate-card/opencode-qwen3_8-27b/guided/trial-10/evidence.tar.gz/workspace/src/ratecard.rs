use crate::{Quote, QuoteError};

/// Weight surcharge threshold: a parcel strictly heavier than this pays the
/// flat overweight surcharge.
const WEIGHT_SURCHARGE_GRAMS: u32 = 10_000;
const WEIGHT_SURCHARGE_CENTS: u64 = 500;

/// Zone that pays the international percentage surcharge.
const INTERNATIONAL_ZONE: &str = "international";
const INTERNATIONAL_RATE_NUMERATOR: u128 = 20;
const INTERNATIONAL_RATE_DENOMINATOR: u128 = 100;

/// One pricing band taken from the rate card: the heaviest a parcel may be in
/// this band, and the base price in cents for it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Band {
    pub zone: String,
    pub band_max_grams: u32,
    pub cents: u64,
}

/// Parse the rate card text into pricing bands.
///
/// Blank lines and lines beginning with `#` are ignored. Every other line must
/// be exactly three tab-separated fields whose two trailing numbers parse as
/// unsigned integers; otherwise the offending 1-based line number is returned
/// (line numbers count every line, including ignored comments and blanks).
pub fn parse(text: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();

    for (index, raw) in text.split('\n').enumerate() {
        let line = index + 1;
        let text = raw.trim_end_matches(['\r']);

        if text.is_empty() || text.starts_with('#') {
            continue;
         }

        let fields: Vec<&str> = text.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line });
         }

        let band_max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line })?;

        bands.push(Band {
            zone: fields[0].to_string(),
            band_max_grams,
            cents,
        });
    }

    Ok(bands)
}

/// The international surcharge is 20% of the base price, rounded half-up to the
/// cent.
fn international_surcharge(base_cents: u64) -> u64 {
    let numerator = (base_cents as u128) * INTERNATIONAL_RATE_NUMERATOR;
    ((numerator + INTERNATIONAL_RATE_DENOMINATOR / 2) / INTERNATIONAL_RATE_DENOMINATOR) as u64
}

/// Price a parcel against the given bands.
///
/// Returns `UnknownZone` when no band exists for the zone and `Overweight` when
/// the parcel exceeds the zone's largest band. Pure: no I/O, clock, or
/// external state, so it is cheap and deterministic to test.
pub fn price(parcel_zone: &str, weight: u32, bands: &[Band]) -> Result<Quote, QuoteError> {
    let mut zone_bands: Vec<&Band> = bands
        .iter()
        .filter(|band| band.zone == parcel_zone)
        .collect();
    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel_zone.to_string()));
    }

    zone_bands.sort_by_key(|band| band.band_max_grams);

    let band = match zone_bands.iter().find(|band| band.band_max_grams >= weight) {
        Some(band) => *band,
        None => {
            // The parcel is heavier than the largest band for this zone. The
            // largest band's threshold is the limit reported back to callers.
            if let Some(largest) = zone_bands.last() {
                return Err(QuoteError::Overweight {
                    grams: weight,
                    limit: largest.band_max_grams,
                });
            }
            return Err(QuoteError::UnknownZone(parcel_zone.to_string()));
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if weight > WEIGHT_SURCHARGE_GRAMS {
        surcharge_cents += WEIGHT_SURCHARGE_CENTS;
    }

    if parcel_zone == INTERNATIONAL_ZONE {
        surcharge_cents += international_surcharge(base_cents);
    }

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    #![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

    use super::{parse, price, Band};
    use crate::QuoteError;

    fn band(zone: &str, max_grams: u32, cents: u64) -> Band {
        Band {
            zone: zone.to_string(),
            band_max_grams: max_grams,
            cents,
        }
    }

    fn sample() -> Vec<Band> {
        vec![
            band("domestic", 500, 599),
            band("domestic", 2000, 899),
            band("domestic", 20000, 1799),
            band("international", 500, 1499),
            band("international", 20000, 4999),
        ]
    }

    #[test]
    fn parse_reads_three_field_rows_and_skips_comments_and_blanks() {
        let text = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899

# a comment
international\t500\t1499
international\t20000\t4999
";
        let bands = parse(text).unwrap();
        assert_eq!(bands.len(), 4);
        assert_eq!(bands[0].zone, "domestic");
        assert_eq!(bands[0].band_max_grams, 500);
        assert_eq!(bands[0].cents, 599);
        assert_eq!(bands[3].zone, "international");
        assert_eq!(bands[3].cents, 4999);
    }

    #[test]
    fn parse_reports_malformed_row_by_line_number_counting_every_line() {
        let text = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
international\t500
";
        match parse(text) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
            other => panic!("expected malformed at line 3, got {other:?}"),
        }
    }

    #[test]
    fn parse_flags_non_numeric_band_field() {
        let text = "domestic\tabc\t599\n";
        match parse(text) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            other => panic!("expected malformed, got {other:?}"),
        }
    }

    #[test]
    fn price_omits_surcharge_when_light_and_domestic() {
        let q = price("domestic", 400, &sample()).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn price_selects_first_bands_whose_threshold_meets_weight() {
        let q = price("domestic", 501, &sample()).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn price_adds_flat_weight_surcharge_above_threshold() {
        let q = price("domestic", 10_001, &sample()).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn price_omits_weight_surcharge_at_exact_threshold() {
        let q = price("domestic", 10_000, &sample()).unwrap();
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn price_adds_international_percentage_surcharge_rounded_half_up() {
        // 20% of 1499 = 299.8 -> 300 (half-up).
        let q = price("international", 400, &sample()).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn price_combines_weight_and_international_surcharges() {
        // 5000g international, band 20000 @ 4999. weight <= 10000 so only the
        // percentage applies: 20% of 4999 = 999.8 -> 1000.
        let q = price("international", 5000, &sample()).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1000);
        assert_eq!(q.total_cents, 5999);
    }

    #[test]
    fn price_returns_unknown_zone_when_zone_absent() {
        match price("overseas", 100, &sample()) {
            Err(QuoteError::UnknownZone(zone)) => assert_eq!(zone, "overseas"),
            other => panic!("expected UnknownZone, got {other:?}"),
        }
    }

    #[test]
    fn price_returns_overweight_when_above_largest_band() {
        match price("domestic", 99_999, &sample()) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 99_999);
                assert_eq!(limit, 20_000);
            }
            other => panic!("expected Overweight, got {other:?}"),
        }
    }
}
