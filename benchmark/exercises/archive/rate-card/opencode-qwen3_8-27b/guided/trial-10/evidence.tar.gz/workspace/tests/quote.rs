//! Boundary tests for the quote API. Recoverable failures are checked via
//! `matches!`, so panicking on a failed assertion is the correct test idiom;
//! the restriction lints that guard library code are exempted here.
#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

use ratecard::{quote, QuoteError, Parcel};
use std::sync::{Mutex, OnceLock};
use tracing_test::traced_test;

const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

// `RATECARD_PATH` is process-global, so env-mutating tests must not run
// concurrently or one test's file path clobbers another's. A single mutex serial
// them without pulling in an external "serial" crate.
static ENV_LOCK: OnceLock<Mutex<()>> = OnceLock::new();

fn hold_env() -> std::sync::MutexGuard<'static, ()> {
    ENV_LOCK.get_or_init(|| Mutex::new(())).lock().unwrap()
}

fn point_at_ratecard(content: &str) -> Result<tempfile::NamedTempFile, std::io::Error> {
    let mut file = tempfile::Builder::new().suffix(".tsv").tempfile()?;
    std::io::Write::write_all(&mut file, content.as_bytes())?;
    std::env::set_var("RATECARD_PATH", file.path());
    Ok(file)
}

#[test]
fn quote_reads_path_env_and_prices_a_domestic_parcel() {
    let _env = hold_env();
    let _file = point_at_ratecard(SAMPLE).unwrap();
    let parcel = Parcel {
        weight_grams: 400,
        zone: "domestic".to_string(),
      };
    let q = quote(&parcel).expect("quote should succeed");
    assert_eq!(q.base_cents, 599);
    assert_eq!(q.surcharge_cents, 0);
    assert_eq!(q.total_cents, 599);
    assert_eq!(q.band_max_grams, 500);
}

#[test]
fn quote_prices_a_heavy_international_parcel_with_both_surcharges() {
    let _env = hold_env();
    let _file = point_at_ratecard(SAMPLE).unwrap();
    // 12000g is above the 10000g weight surcharge but below the 20000g
    // international band, so no overweight and both surcharges apply.
    let parcel = Parcel {
        weight_grams: 12_000,
        zone: "international".to_string(),
      };
    let q = quote(&parcel).expect("quote should succeed");
    assert_eq!(q.base_cents, 4999);
    // +500 weight surcharge; 20% of 4999 = 999.8 -> 1000 (half-up).
    assert_eq!(q.surcharge_cents, 1500);
    assert_eq!(q.total_cents, 6499);
    assert_eq!(q.band_max_grams, 20000);
}

#[test]
fn quote_returns_unknown_zone_for_a_zone_absent_from_the_card() {
    let _env = hold_env();
    let _file = point_at_ratecard(SAMPLE).unwrap();
    let parcel = Parcel {
        weight_grams: 100,
        zone: "antarctic".to_string(),
      };
    match quote(&parcel) {
        Err(QuoteError::UnknownZone(zone)) => assert_eq!(zone, "antarctic"),
        other => panic!("expected UnknownZone, got {other:?}"),
      }
}

#[test]
fn quote_returns_overweight_when_the_weight_exceeds_the_largest_band() {
    let _env = hold_env();
    let _file = point_at_ratecard(SAMPLE).unwrap();
    let parcel = Parcel {
        weight_grams: 999_999,
        zone: "domestic".to_string(),
      };
    match quote(&parcel) {
        Err(QuoteError::Overweight { grams, limit }) => {
            assert_eq!(grams, 999_999);
            assert_eq!(limit, 20000);
           }
        other => panic!("expected Overweight, got {other:?}"),
       }
}

#[test]
fn quote_returns_rate_card_unavailable_when_path_is_unset() {
    let _env = hold_env();
    std::env::remove_var("RATECARD_PATH");
    let parcel = Parcel {
        weight_grams: 100,
        zone: "domestic".to_string(),
      };
    assert!(matches!(quote(&parcel), Err(QuoteError::RateCardUnavailable)));
}

#[test]
fn quote_returns_rate_card_unavailable_when_path_points_to_a_missing_file() {
    let _env = hold_env();
    std::env::set_var("RATECARD_PATH", "/nonexistent/ratecard/ts/missing.tsv");
    let parcel = Parcel {
        weight_grams: 100,
        zone: "domestic".to_string(),
      };
    assert!(matches!(quote(&parcel), Err(QuoteError::RateCardUnavailable)));
}

#[test]
fn quote_flags_a_malformed_line_with_its_line_number() {
    let _env = hold_env();
    let content = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000
";
    let _file = point_at_ratecard(content).unwrap();
    let parcel = Parcel {
        weight_grams: 100,
        zone: "domestic".to_string(),
      };
    match quote(&parcel) {
        Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
        other => panic!("expected MalformedRateCard at line 3, got {other:?}"),
      }
}

#[traced_test]
#[test]
fn quote_emits_a_diagnostic_with_zone_weight_and_total() {
    let _env = hold_env();
    let _file = point_at_ratecard(SAMPLE).unwrap();
    let parcel = Parcel {
        weight_grams: 250,
        zone: "domestic".to_string(),
      };
    let q = quote(&parcel).expect("quote should succeed");
    assert_eq!(q.total_cents, 599);
    assert!(logs_contain("domestic"));
    assert!(logs_contain("250"));
    assert!(logs_contain("599"));
}
