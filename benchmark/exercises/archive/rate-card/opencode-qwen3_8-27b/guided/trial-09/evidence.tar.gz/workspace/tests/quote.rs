//! Integration tests for [`ratecard::quote`].
//!
//! These exercise the whole flow — environment variable, file read, parse, and
//! the structured tracing record each quote emits — at the boundary, using a real
//! temp file on disk.
//!
//! Two pieces of state are process-global and therefore racy under cargo's
//! default parallel test runner: the `RATECARD_PATH` environment variable and the
//! `tracing-test` capture buffer. `LOCK` serializes the tests so that none of
//! them observe another test's card or another test's diagnostic record.

use ratecard::{quote, Parcel, QuoteError};
use std::path::PathBuf;
use std::sync::Mutex;
use tempfile::TempDir;
use tracing_test::internal::{global_buf, get_subscriber, MockWriter};

const CARD: &str = "# zone\tband_max_grams\tcents\n\
    domestic\t500\t599\n\
    domestic\t2000\t899\n\
    domestic\t20000\t1799\n\
    international\t500\t1499\n\
    international\t20000\t4999\n";

/// Serializes the integration tests: the `RATECARD_PATH` env var and the
/// `tracing-test` buffer are process-global, so tests must not run
/// concurrently.
static LOCK: Mutex<()> = Mutex::new(());

static SUBSCRIBER: std::sync::Once = std::sync::Once::new();

/// Install a tracing subscriber that captures everything the `ratecard` crate
/// emits. The subscriber writes into `tracing-test`'s shared buffer, which the
/// assertions below read.
fn capture() {
    SUBSCRIBER.call_once(|| {
        let writer = MockWriter::new(global_buf());
        let subscriber = get_subscriber(writer, "ratecard=trace");
        let _ = tracing::dispatcher::set_global_default(subscriber);
     });
}

/// Read the shared tracing buffer as a string.
fn captured() -> String {
    String::from_utf8(global_buf().lock().unwrap().to_vec()).unwrap()
}

/// Clear the shared tracing buffer so an assertion only sees the events emitted
/// during the current test.
fn clear_buffer() {
    global_buf().lock().unwrap().clear();
}

/// Write the canonical rate card to a temp file and point `RATECARD_PATH` at it.
/// The returned [`TempDir`] keeps the file alive for the test's duration.
fn with_card() -> (PathBuf, TempDir) {
    let dir = TempDir::new().expect("temp dir");
    let path = dir.path().join("card.tsv");
    std::fs::write(&path, CARD).expect("writes card");
    std::env::set_var("RATECARD_PATH", path.to_str().unwrap());
    (path, dir)
}

#[test]
fn quote_domestic() {
    let _guard = LOCK.lock().unwrap();
    capture();
    clear_buffer();
    let (_path, _dir) = with_card();

    let parcel = Parcel { weight_grams: 750, zone: "domestic".to_string() };
    let q = quote(&parcel).expect("quotes");

    assert_eq!(q.base_cents, 899);
    assert_eq!(q.surcharge_cents, 0);
    assert_eq!(q.total_cents, 899);
    assert_eq!(q.band_max_grams, 2000);

     // The diagnostic record carries the zone, weight in grams, and total in
     // cents as independently queryable fields.
    let logs = captured();
    assert!(logs.contains(r#"zone="domestic""#), "logs: {logs}");
    assert!(logs.contains("weight_g=750"), "logs: {logs}");
    assert!(logs.contains("total_cents=899"), "logs: {logs}");
    assert!(logs.contains("quoted"), "logs: {logs}");
}

#[test]
fn quote_international_with_surcharges() {
    let _guard = LOCK.lock().unwrap();
    capture();
    clear_buffer();
    let (_path, _dir) = with_card();

    let parcel = Parcel { weight_grams: 15_000, zone: "international".to_string() };
    let q = quote(&parcel).expect("quotes");

     // 20% of 4999 = 999.8 -> 1000, plus 500 overweight.
    assert_eq!(q.base_cents, 4999);
    assert_eq!(q.surcharge_cents, 1500);
    assert_eq!(q.total_cents, 6499);
    assert_eq!(q.band_max_grams, 20_000);

    let logs = captured();
    assert!(logs.contains(r#"zone="international""#), "logs: {logs}");
    assert!(logs.contains("weight_g=15000"), "logs: {logs}");
    assert!(logs.contains("total_cents=6499"), "logs: {logs}");
}

#[test]
fn unknown_zone() {
    let _guard = LOCK.lock().unwrap();
    capture();
    clear_buffer();
    let (_path, _dir) = with_card();

    let parcel = Parcel { weight_grams: 11, zone: "atlantic".to_string() };
    assert_eq!(quote(&parcel), Err(QuoteError::UnknownZone("atlantic".to_string())));

    let logs = captured();
    assert!(logs.contains(r#"zone="atlantic""#), "logs: {logs}");
    assert!(logs.contains("quote failed"), "logs: {logs}");
    assert!(logs.contains("unknown zone `atlantic`"), "logs: {logs}");
}

#[test]
fn overweight() {
    let _guard = LOCK.lock().unwrap();
    capture();
    clear_buffer();
    let (_path, _dir) = with_card();

    let parcel = Parcel { weight_grams: 25_000, zone: "domestic".to_string() };
    assert_eq!(
        quote(&parcel),
        Err(QuoteError::Overweight { grams: 25_000, limit: 20_000 })
     );

    let logs = captured();
    assert!(logs.contains("weight_g=25000"), "logs: {logs}");
    assert!(logs.contains("exceeds zone limit"), "logs: {logs}");
}

#[test]
fn malformed_rate_card_reports_line() {
    let _guard = LOCK.lock().unwrap();
    capture();
    clear_buffer();
    let dir = TempDir::new().expect("temp dir");
    let path = dir.path().join("card.tsv");
     // line 1 comment, line 2 blank, line 3 has a non-numeric field
    std::fs::write(&path, "# comment\n\ndomestic\t500\tabc\n").expect("writes card");
    std::env::set_var("RATECARD_PATH", path.to_str().unwrap());

    let parcel = Parcel { weight_grams: 321, zone: "domestic".to_string() };
    assert_eq!(quote(&parcel), Err(QuoteError::MalformedRateCard { line: 3 }));

    let logs = captured();
    assert!(logs.contains("weight_g=321"), "logs: {logs}");
    assert!(logs.contains("malformed rate card"), "logs: {logs}");
}

#[test]
fn rate_card_unavailable() {
    let _guard = LOCK.lock().unwrap();
    capture();
    clear_buffer();
    std::env::set_var("RATECARD_PATH", "no_such_file_xyz.tsv");

    let parcel = Parcel { weight_grams: 13, zone: "domestic".to_string() };
    assert_eq!(quote(&parcel), Err(QuoteError::RateCardUnavailable));

    let logs = captured();
    assert!(logs.contains("weight_g=13"), "logs: {logs}");
    assert!(logs.contains("rate card unavailable"), "logs: {logs}");
}
