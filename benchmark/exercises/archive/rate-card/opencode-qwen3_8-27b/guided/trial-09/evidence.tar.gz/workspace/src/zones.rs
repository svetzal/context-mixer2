/// Human-readable label for a zone key, falling back to the key itself.
pub fn zone_label(zone: &str) -> &str {
    match zone {
         "domestic" => "Domestic ground",
         "international" => "International air",
         other => other,
    }
}
