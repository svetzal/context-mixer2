//! Shipping rate quotes from a zone rate card.
//!
//! [`quote`] turns a [`Parcel`] into a [`Quote`] by reading a tab-separated rate
//! card from the file named by the `RATECARD_PATH` environment variable. The
//! calculation itself lives in the pure, I/O-free [`ratecard`] module so it can
//! be tested without files, networks, or runtime orchestration; this module is
//! the thin shell that performs the environment and filesystem access and
//! correlates each quote with structured tracing.

pub mod ratecard;

pub mod zones;

use std::fmt;
use std::fs;

use tracing::info;
use tracing::span;

/// A parcel to be quoted.
///
/// The `zone` selects the column of bands in the rate card and the
/// `weight_grams` selects which band within that zone applies.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
     /// Gross weight of the parcel in grams.
    pub weight_grams: u32,
     /// Rate-card zone key, e.g. `domestic` or `international`.
    pub zone: String,
}

/// The result of quoting a [`Parcel`].
///
/// `base_cents` is the rate card's price for the matching band; `surcharge_cents`
/// is the sum of every applicable surcharge; and `total_cents` is the total a
/// caller should charge. `band_max_grams` records the threshold of the band that
/// matched, so callers can see how much headroom remains before the next band.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
     /// Base price in cents for the matched band.
    pub base_cents: u64,
     /// Sum of applicable surcharges in cents (weight and international).
    pub surcharge_cents: u64,
     /// `base_cents + surcharge_cents`.
    pub total_cents: u64,
     /// Upper threshold (grams, inclusive) of the band that matched.
    pub band_max_grams: u32,
}

/// An error produced by [`quote`].
///
/// Every variant is recoverable: a library caller can inspect it and decide how
/// to respond (reject the quote, retry with a different card, prompt the user)
/// rather than having the process terminate.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
     /// The `RATECARD_PATH` variable was unset, or the file it names is
     /// missing or unreadable.
    RateCardUnavailable,
     /// A rate-card line was not three tab-separated fields with parseable
     /// numerics. `line` is the 1-based number of the offending line.
    MalformedRateCard {
         /// 1-based line number of the offending line, counting every line in
        /// the file including comments and blanks.
        line: usize,
    },
     /// The requested zone is not present in the rate card.
    UnknownZone(String),
     /// The parcel's weight exceeds the largest band for its zone. `limit` is
     /// that largest `band_max_grams`.
    Overweight {
         /// The parcel weight in grams.
        grams: u32,
         /// The largest band threshold (grams) for the zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone `{zone}`"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "weight {grams} g exceeds zone limit of {limit} g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Quote a [`Parcel`] against the rate card named by `RATECARD_PATH`.
///
/// The rate card is a tab-separated file, one band per line:
///
/// ```text
/// # zone    band_max_grams  cents
/// domestic  500     599
/// domestic  2000    899
/// domestic  20000   1799
/// ```
///
/// Lines that are empty or begin with `#` are ignored. Surcharges add together:
/// a weight strictly above 10000 g adds 500 cents, and the `international` zone
/// adds 20% of the base, rounded half-up to the cent.
///
/// # Errors
///
/// - [`QuoteError::RateCardUnavailable`] if `RATECARD_PATH` is unset or its file
///   is missing or unreadable.
/// - [`QuoteError::MalformedRateCard`] if a non-comment, non-blank line is not
///   three tab-separated fields with parseable numerics.
/// - [`QuoteError::UnknownZone`] if the parcel's zone is absent from the card.
/// - [`QuoteError::Overweight`] if the parcel's weight exceeds the zone's
///   largest band.
///
/// Each call emits a correlated tracing span carrying the zone, the weight in
/// grams, and the resulting total in cents, so an operation can be queried
/// independently of a flat log stream.
///
/// # Example
///
/// ```no_run
/// use ratecard::{Parcel, quote};
///
/// std::env::set_var("RATECARD_PATH", "ratecard.tsv");
///
/// let parcel = Parcel {
///      weight_grams: 750,
///      zone: "domestic".to_string(),
/// };
///
/// match quote(&parcel) {
///      Ok(q) => println!("total {q:?}"),
///      Err(e) => eprintln!("{e}"),
/// }
/// ```
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
     let weight_grams = parcel.weight_grams;
     let zone = parcel.zone.as_str();
     let span = span!(tracing::Level::INFO, "quote", zone, weight_g = weight_grams);
     let _enter = span.enter();

    // Compute the result first, then emit the diagnostic on every path. Returning
    // early via `?` inside this helper (e.g. a missing or malformed card) must
    // still be observable, so the diagnostic cannot live after the `?`.
    let result = quote_core(zone, weight_grams);

    match &result {
        Ok(q) => info!(total_cents = q.total_cents, "quoted"),
        Err(e) => tracing::warn!(error = %e, "quote failed"),
      }

    result
}

/// Compute a quote: read the rate card, then apply the pricing rules.
///
/// Kept separate from [`quote`] so the diagnostic is emitted after this returns,
/// on every path, instead of being skipped when an early `?` unwinds.
fn quote_core(zone: &str, weight_grams: u32) -> Result<Quote, QuoteError> {
    let card = load_rate_card()?;
    ratecard::compute_quote(&card, zone, weight_grams)
}

/// Read and parse the rate card from `RATECARD_PATH`.
///
/// Missing path, missing/unreadable file, and parse failure map onto the
/// [`QuoteError`] variants the public contract promises.
fn load_rate_card() -> Result<ratecard::RateCard, QuoteError> {
     let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    if path.is_empty() {
        return Err(QuoteError::RateCardUnavailable);
    }

    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    ratecard::parse_rate_card(&contents).map_err(|p| QuoteError::MalformedRateCard { line: p.line })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;
    use std::sync::Mutex;
    use tempfile::TempDir;

     static LOCK: Mutex<()> = Mutex::new(());

     fn write_card(dir: &TempDir, name: &str, contents: &str) -> PathBuf {
        let path = dir.path().join(name);
        std::fs::write(&path, contents).expect("writes card");
        path
      }

     struct EnvGuard {
        key: &'static str,
      }

     impl EnvGuard {
        fn set(key: &'static str, value: &str) -> Self {
            std::env::set_var(key, value);
            EnvGuard { key }
          }
      }

     impl Drop for EnvGuard {
        fn drop(&mut self) {
            std::env::remove_var(self.key);
          }
      }

      #[test]
    fn unavailable_when_path_unset() {
        let _l = LOCK.lock().unwrap();
        let _g = EnvGuard::set("RATECARD_PATH", "");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
          };
        assert_eq!(quote(&parcel), Err(QuoteError::RateCardUnavailable));
      }

      #[test]
    fn unavailable_when_file_missing() {
        let _l = LOCK.lock().unwrap();
        let _g = EnvGuard::set("RATECARD_PATH", "no_such_file_xyz.tsv");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
          };
        assert_eq!(quote(&parcel), Err(QuoteError::RateCardUnavailable));
      }

      #[test]
    fn quotes_domestic() {
        let _l = LOCK.lock().unwrap();
        let dir = TempDir::new().expect("temp dir");
        let p = write_card(
             &dir,
             "card.tsv",
             "domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n",
         );
        let _g = EnvGuard::set("RATECARD_PATH", p.to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 750,
            zone: "domestic".to_string(),
          };
        let q = quote(&parcel).expect("quotes");
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
      }

      #[test]
    fn quotes_international_with_surcharge() {
        let _l = LOCK.lock().unwrap();
        let dir = TempDir::new().expect("temp dir");
        let p = write_card(
             &dir,
             "card.tsv",
             "international\t500\t1499\ninternational\t20000\t4999\n",
         );
        let _g = EnvGuard::set("RATECARD_PATH", p.to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 15_000,
            zone: "international".to_string(),
          };
        let q = quote(&parcel).expect("quotes");
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
      }
}
