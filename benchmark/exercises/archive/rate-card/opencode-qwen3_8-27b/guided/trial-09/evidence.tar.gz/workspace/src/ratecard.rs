//! Pure rate-card parsing and quote computation.
//!
//! This module is I/O-free: it parses a rate-card string into a [`RateCard`] and
//! computes a [`crate::Quote`] from a parsed card. Keeping the behaviour here,
//! separate from the environment and filesystem access in the crate-root shell,
//! means the logic can be exercised deterministically without files, networks, or
//! runtime orchestration.

use crate::{Quote, QuoteError};

/// A single pricing band.
///
/// A parcel whose weight in grams is less than or equal to
/// [`Band::band_max_grams`] is charged [`Band::cents`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Band {
    /// Upper weight (inclusive, in grams) this band covers.
    pub band_max_grams: u32,
    /// Base charge in cents for this band.
    pub cents: u64,
}

/// A zone and its pricing bands, kept sorted ascending by `band_max_grams`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Zone {
    /// Zone key, e.g. `domestic` or `international`.
    pub name: String,
    /// This zone's bands, sorted ascending by [`Band::band_max_grams`].
    pub bands: Vec<Band>,
}

/// A parsed rate card: one [`Zone`] per key.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RateCard {
    /// The zones present in the card, in first-seen order.
    pub zones: Vec<Zone>,
}

/// A rate-card line that is not exactly three tab-separated fields, or whose
/// numeric fields do not parse.
///
/// `line` is the 1-based line number of the offending line, counting every line
/// in the file including comments and blanks.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ParseError {
    /// 1-based line number of the offending line.
    pub line: usize,
}

/// Parse a rate card from its tab-separated text.
///
/// Lines that are empty or begin with `#` are ignored. Every other line must be
/// exactly three tab-separated fields: `zone`, `band_max_grams` (a `u32`), and
/// `cents` (a `u64`). Any other shape yields a [`ParseError`] carrying the
/// offending line's 1-based number.
///
/// # Errors
///
/// Returns [`ParseError`] (carrying the 1-based line number) on the first
/// non-comment, non-blank line that is not exactly three tab-separated fields
/// with parseable numerics.
///
/// # Example
///
/// ```
/// use ratecard::ratecard::parse_rate_card;
///
/// let card = parse_rate_card(
///     "# zone\tband_max_grams\tcents\n\
///      domestic\t500\t599\n\
///      domestic\t2000\t899\n",
/// )
/// .expect("rate card parses");
///
/// let domestic = card
///     .zones
///     .iter()
///     .find(|z| z.name == "domestic")
///     .expect("domestic zone present");
/// assert_eq!(domestic.bands.len(), 2);
/// ```
pub fn parse_rate_card(contents: &str) -> Result<RateCard, ParseError> {
    let mut zones: Vec<Zone> = Vec::new();

    for (idx, raw) in contents.lines().enumerate() {
        let line_no = idx + 1;
        // `lines()` splits on line boundaries, but strip a stray CR so a
        // trailing `\r` never lands inside the last tab-separated field.
        let line = raw.strip_suffix('\r').unwrap_or(raw);
        let trimmed = line.trim();

        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(ParseError { line: line_no });
        }

        let zone_name = parts[0].to_string();
        let band_max_grams = parts[1].trim().parse::<u32>().map_err(|_| ParseError { line: line_no })?;
        let cents = parts[2].trim().parse::<u64>().map_err(|_| ParseError { line: line_no })?;

        match zones.iter_mut().find(|z| z.name == zone_name) {
            Some(z) => z.bands.push(Band { band_max_grams, cents }),
            None => zones.push(Zone {
                name: zone_name,
                bands: vec![Band { band_max_grams, cents }],
            }),
        }
    }

    for z in &mut zones {
        z.bands.sort_by_key(|b| b.band_max_grams);
    }

    Ok(RateCard { zones })
}

/// Compute a quote from a parsed [`RateCard`] for a zone and weight.
///
/// This is the pure core of a quote: it selects the matching band, applies the
/// surcharges (weight above 10000 g adds 500 cents; the `international` zone adds
/// 20% of the base, rounded half-up to the cent), and assembles a
/// [`crate::Quote`]. It never touches the filesystem or environment.
///
/// # Errors
///
/// - [`QuoteError::UnknownZone`] if `zone` is not present in the card.
/// - [`QuoteError::Overweight`] if `weight_grams` exceeds the zone's largest
///   band; the error carries that largest `band_max_grams` as `limit`.
pub fn compute_quote(card: &RateCard, zone: &str, weight_grams: u32) -> Result<Quote, QuoteError> {
    let zone = card.zones.iter().find(|z| z.name == zone).ok_or(QuoteError::UnknownZone(zone.to_string()))?;

    let band = zone.bands.iter().find(|b| b.band_max_grams >= weight_grams);

    let (base_cents, band_max_grams) = match band {
        Some(b) => (b.cents, b.band_max_grams),
        None => {
            let limit = zone.bands.iter().map(|b| b.band_max_grams).max().unwrap_or(0);
            return Err(QuoteError::Overweight {
                grams: weight_grams,
                limit,
            });
        }
    };

    let mut surcharge_cents: u64 = 0;

    if weight_grams > 10_000 {
        surcharge_cents = surcharge_cents.saturating_add(500);
    }

    if zone.name == "international" {
        // 20% of the base, rounded half-up to the cent. base * 20 / 100 ==
        // (base * 20 + 50) / 100 under integer division.
        let international = ((base_cents as u128 * 20 + 50) / 100) as u64;
        surcharge_cents = surcharge_cents.saturating_add(international);
    }

    let total_cents = base_cents.saturating_add(surcharge_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    const DOMESTIC: &str = "domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n";
    const CARD: &str = "# zone\tband_max_grams\tcents\n\
        domestic\t500\t599\n\
        domestic\t2000\t899\n\
        domestic\t20000\t1799\n\
        international\t500\t1499\n\
        international\t20000\t4999\n";

    #[test]
    fn parses_full_card() {
        let card = parse_rate_card(CARD).expect("parses");
        assert_eq!(card.zones.len(), 2);
        let domestic = card.zones.iter().find(|z| z.name == "domestic").expect("present");
        assert_eq!(domestic.bands.len(), 3);
        assert_eq!(domestic.bands[0].band_max_grams, 500);
        assert_eq!(domestic.bands[2].cents, 1799);
    }

    #[test]
    fn ignores_comments_and_blanks() {
        let card = parse_rate_card("# header\ndomestic\t500\t599\n\n").expect("parses");
        assert_eq!(card.zones.len(), 1);
    }

    #[test]
    fn sorts_bands_ascending() {
        let card = parse_rate_card("domestic\t20000\t1799\ndomestic\t500\t599\ndomestic\t2000\t899\n").expect("parses");
        let domestic = card.zones.iter().find(|z| z.name == "domestic").unwrap();
        let maxs: Vec<u32> = domestic.bands.iter().map(|b| b.band_max_grams).collect();
        assert_eq!(maxs, vec![500, 2000, 20000]);
    }

    #[test]
    fn malformed_too_few_fields() {
        let err = parse_rate_card("domestic\t500\n").unwrap_err();
        assert_eq!(err.line, 1);
    }

    #[test]
    fn malformed_too_many_fields() {
        let err = parse_rate_card("domestic\t500\t599\textra\n").unwrap_err();
        assert_eq!(err.line, 1);
    }

    #[test]
    fn malformed_bad_number_carries_line_number() {
        // line 1 comment, line 2 blank, line 3 has a non-numeric field
        let err = parse_rate_card("# comment\n\ndomestic\t500\tabc\n").unwrap_err();
        assert_eq!(err.line, 3);
    }

    #[test]
    fn domestic_band_selection() {
        let card = parse_rate_card(DOMESTIC).unwrap();
        let q = compute_quote(&card, "domestic", 750).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 899);
    }

    #[test]
    fn band_boundary_is_inclusive() {
        let card = parse_rate_card("domestic\t500\t599\ndomestic\t2000\t899\n").unwrap();
        let q = compute_quote(&card, "domestic", 500).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn unknown_zone() {
        let card = parse_rate_card(DOMESTIC).unwrap();
        assert_eq!(
            compute_quote(&card, "atlas", 10),
            Err(QuoteError::UnknownZone("atlas".to_string()))
        );
    }

    #[test]
    fn overweight_returns_largest_band_as_limit() {
        let card = parse_rate_card(DOMESTIC).unwrap();
        assert_eq!(
            compute_quote(&card, "domestic", 25_000),
            Err(QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000
            })
        );
    }

    #[test]
    fn overweight_surcharge_above_10000() {
        let card = parse_rate_card("domestic\t20000\t1799\n").unwrap();
        let q = compute_quote(&card, "domestic", 15_000).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn no_surcharge_at_exactly_10000() {
        let card = parse_rate_card("domestic\t20000\t1799\n").unwrap();
        let q = compute_quote(&card, "domestic", 10_000).unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn international_surcharge_rounds_half_up() {
        // 20% of 599 = 119.8 -> round half-up -> 120
        let card = parse_rate_card("international\t500\t599\n").unwrap();
        let q = compute_quote(&card, "international", 100).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 120);
        assert_eq!(q.total_cents, 719);
    }

    #[test]
    fn international_and_overweight_surcharges_add() {
        // 20% of 4999 = 999.8 -> 1000, plus 500 for weight > 10000
        let card = parse_rate_card("international\t20000\t4999\n").unwrap();
        let q = compute_quote(&card, "international", 15_000).unwrap();
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }
}
