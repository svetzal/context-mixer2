/// Project-owned edge contract for emitting a quote diagnostic.
///
/// The pure core depends only on this trait, never on `tracing` or any other
/// concrete logger. A single concrete gateway wraps `tracing` so that each quote
/// call produces a structured, queryable record (see [`emit_diagnostic`]).
pub trait DiagnosticSink {
    fn record(&self, event: &QuoteDiagnostic);
}

#[derive(Clone, PartialEq, Eq, Debug)]
pub struct QuoteDiagnostic {
    pub zone: String,
    pub weight_grams: u32,
    pub total_cents: u64,
}

/// The one concrete gateway in the crate. It wraps `tracing` (the only external
/// logging crate used) and converts a [`QuoteDiagnostic`] into a structured event.
///
/// The body is intentionally thin: the core stays pure and the gateway is the
/// only place that names a third-party crate.
#[derive(Clone, Copy, Debug, Default)]
pub struct TracingSink;

impl DiagnosticSink for TracingSink {
    fn record(&self, event: &QuoteDiagnostic) {
        emit_diagnostic(event);
    }
}

/// Emits a structured diagnostic event through the `tracing` ecosystem.
///
/// Every field (zone, weight in grams, total in cents, and the event name) is
/// emitted as its own structured field, so an operator can query and correlate it
/// by any of them. The record is wrapped in a span carrying the same fields, so
/// it is observable in operation alongside the surrounding call context.
fn emit_diagnostic(event: &QuoteDiagnostic) {
    let span = tracing::info_span!(
        "quote",
        zone = tracing::field::display(&event.zone),
        weight_grams = event.weight_grams,
        total_cents = event.total_cents,
      );
    let _enter = span.enter();
    tracing::info!(
        zone = tracing::field::display(&event.zone),
        weight_grams = event.weight_grams,
        total_cents = event.total_cents,
         "diagnostic",
     );
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sink_records_do_not_panic() {
        // Emits through tracing with no subscriber set up; must not panic.
        let sink = TracingSink;
        sink.record(&QuoteDiagnostic {
            zone: "domestic".into(),
            weight_grams: 300,
            total_cents: 599,
        });
    }
}
