//! Integration tests exercising `quote` end-to-end against a temp-file rate
//! card. These cover cross-module behaviour: reading `RATECARD_PATH`, parsing,
//! band selection, surcharges, and the error contract.
//!
//! `RATECARD_PATH` is process-global, and cargo runs the `lib` unittests and
//! this binary in parallel processes. So every test takes a cross-process
//! file lock (via `fs2`) before touching the variable, which serializes the
//! whole suite deterministically.

use std::fs::File;
use std::io::Write;
use std::path::PathBuf;
use std::sync::Mutex;

use fs2::FileExt;
use ratecard::{quote, Parcel, Quote, QuoteError};

const DEFAULT_CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

// A single, process-global advisory lock file. All env-mutating tests acquire
// it before touching `RATECARD_PATH`, so no two tests race on the variable.
static GATE: Mutex<()> = Mutex::new(());

/// Combines the in-process mutex (serializes threads within one test binary)
/// and the exclusive file lock (serializes distinct test binaries). Both are
/// released when this guard is dropped.
struct Gate {
    _mutex_guard: std::sync::MutexGuard<'static, ()>,
    _file: File,
}

fn lock_path() -> PathBuf {
    let mut path = PathBuf::from(std::env::var("OUT_DIR").unwrap_or_else(|_| ".".into()));
    path.push("ratecard_test_gate.lock");
    path
}

/// Acquires the cross-process gate. Returns a guard that releases the exclusive
/// file lock (and the in-process mutex) when dropped.
fn gate() -> Gate {
    let mutex_guard = GATE.lock().expect("quote gate is not poisoned");
      // Hold a blocking exclusive lock on the shared gate file so other test
      // processes wait their turn. The `File` is kept alive in the guard so the
      // lock is released when the guard (and the test) ends.
    let file = File::create(&lock_path()).expect("create gate lock file");
    file.lock_exclusive().expect("acquire exclusive gate lock");
    Gate {
        _mutex_guard: mutex_guard,
        _file: file,
      }
}

/// Points `RATECARD_PATH` at a fresh temp file holding `contents`. The returned
/// `NamedTempFile` must be kept alive until the test reads its quote.
fn point_ratecard(contents: &str) -> tempfile::NamedTempFile {
    let file = tempfile::NamedTempFile::new().expect("tempfile");
    {
        let mut f = file.reopen().expect("reopen tempfile for write");
        f.write_all(contents.as_bytes()).expect("write temp card");
    }
    std::env::set_var("RATECARD_PATH", file.path());
    file
}

#[test]
fn domestic_base_quote() {
    let _gate = gate();
    let _card = point_ratecard(DEFAULT_CARD);
    let q = quote(&Parcel { weight_grams: 300, zone: "domestic".into() }).expect("quote");
    assert_eq!(q.base_cents, 599);
    assert_eq!(q.surcharge_cents, 0);
    assert_eq!(q.total_cents, 599);
    assert_eq!(q.band_max_grams, 500);
}

#[test]
fn domestic_weight_surcharge() {
    let _gate = gate();
    let _card = point_ratecard(DEFAULT_CARD);
    let q = quote(&Parcel { weight_grams: 12_000, zone: "domestic".into() }).expect("quote");
    assert_eq!(q.base_cents, 1799);
    assert_eq!(q.surcharge_cents, 500);
    assert_eq!(q.total_cents, 2299);
    assert_eq!(q.band_max_grams, 20_000);
}

#[test]
fn international_zone_surcharge_stacks() {
    let _gate = gate();
    let _card = point_ratecard(DEFAULT_CARD);
    let q = quote(&Parcel { weight_grams: 12_000, zone: "international".into() }).expect("quote");
     // base 4999, weight surcharge 500, 20% of 4999 = 999.8 -> 1000 (half-up)
    assert_eq!(q.base_cents, 4999);
    assert_eq!(q.surcharge_cents, 500 + 1000);
    assert_eq!(q.total_cents, 4999 + 500 + 1000);
}

#[test]
fn unknown_zone_reports_the_zone() {
    let _gate = gate();
    let _card = point_ratecard(DEFAULT_CARD);
    let err = quote(&Parcel { weight_grams: 300, zone: "antarctica".into() }).expect_err("unknown");
    assert_eq!(err, QuoteError::UnknownZone("antarctica".into()));
}

#[test]
fn overweight_reports_the_largest_band() {
    let _gate = gate();
    let _card = point_ratecard(DEFAULT_CARD);
    let err = quote(&Parcel { weight_grams: 99_999, zone: "domestic".into() }).expect_err("overweight");
    assert_eq!(err, QuoteError::Overweight { grams: 99_999, limit: 20_000 });
}

#[test]
fn missing_ratecard_path_is_unavailable() {
    let _gate = gate();
    std::env::remove_var("RATECARD_PATH");
    let err = quote(&Parcel { weight_grams: 300, zone: "domestic".into() }).expect_err("no path");
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn unreadable_ratecard_path_is_unavailable() {
    let _gate = gate();
    std::env::set_var("RATECARD_PATH", "/no/such/rate_card_file.tsv");
    let err = quote(&Parcel { weight_grams: 300, zone: "domestic".into() }).expect_err("no file");
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn malformed_line_reports_its_number() {
    let _gate = gate();
     // Line 1 valid, line 2 a comment, line 3 a 2-field (malformed) line.
    let card = "domestic\t500\t599\n# a comment\ndomestic\t2000\n";
    let _file = point_ratecard(card);
    let err = quote(&Parcel { weight_grams: 300, zone: "domestic".into() }).expect_err("malformed");
    assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
}

#[test]
fn quote_is_plain_data_callers_read_directly() {
     // `Quote` is a data struct whose fields callers read directly.
    assert!(std::mem::size_of::<Quote>() > 0);
}
