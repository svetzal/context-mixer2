//! Shipping quotes for the fulfilment service.
//!
//! `quote` turns a [`Parcel`] into a [`Quote`] by reading a zone rate card from
//! the file named in the `RATECARD_PATH` environment variable. The crate is
//! structured with a pure core (parsing + quote math) and a thin imperative shell
//! (this module) that owns the only side effects: reading the file and emitting
//! a structured diagnostic.

mod diagnostic;
mod rate_card;

pub mod zones;

use std::error::Error;
use std::fmt;
use std::fs;

use diagnostic::{DiagnosticSink, QuoteDiagnostic, TracingSink};
use rate_card::{compute_quote, parse, RateCard};

/// A parcel to be quoted: its weight in grams and its destination zone.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A computed quote, with the base price, total surcharge, combined total, and
/// the band threshold that produced the base price.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// The recoverable conditions `quote` can report.
///
/// Every variant is a recoverable failure (not a panic), so a caller embedding
/// this library can handle it without the process terminating.
#[derive(Clone, PartialEq, Eq, Debug)]
pub enum QuoteError {
    /// The rate card could not be located, opened, or read.
    RateCardUnavailable,
    /// A rate card line was not exactly three tab-separated fields, or its
    /// numbers did not parse. Carries the 1-based line number of the offending
    /// line, counting every line including comments and blanks.
    MalformedRateCard { line: usize },
    /// The parcel's zone has no bands in the rate card. Carries the zone.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band. Carries the parcel
    /// weight and that band's `band_max_grams` (the limit).
    Overweight {
        grams: u32,
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                f.write_str("rate card is unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card on line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel of {grams}g exceeds zone limit of {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

/// Quote a parcel against the rate card named by the `RATECARD_PATH`
/// environment variable.
///
 /// This is the thin imperative shell: it reads the file (the only I/O) and
 /// delegates all pricing to the pure core. On success it emits a structured
 /// diagnostic carrying the zone, weight, and total.
///
/// # Errors
///
/// Returns a [`QuoteError`] for any recoverable condition: a missing/unreadable
/// file, a malformed card line, an unknown zone, or an overweight parcel.
///
/// # Examples
///
/// ```rust, no_run
/// use ratecard::{quote, Parcel};
///
/// // Points at a rate card file whose path is in `RATECARD_PATH`.
/// let parcel = Parcel { weight_grams: 300, zone: "domestic".to_string() };
/// let quote = quote(&parcel);
///
/// // On success, read the fields a caller relies on.
/// if let Ok(quote) = quote {
///     println!("{}/{} cents", quote.base_cents, quote.total_cents);
/// }
/// ```
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let text = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let card: RateCard = parse(&text)?;
    let quote = compute_quote(&card, parcel)?;

    let sink = TracingSink;
    sink.record(&QuoteDiagnostic {
        zone: parcel.zone.clone(),
        weight_grams: parcel.weight_grams,
        total_cents: quote.total_cents,
    });

    Ok(quote)
}

#[cfg(test)]
mod tests {
    use super::*;

     #[test]
    fn error_display_is_stable() {
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "rate card is unavailable"
         );
        assert_eq!(
            QuoteError::MalformedRateCard { line: 7 }.to_string(),
            "malformed rate card on line 7"
         );
        assert_eq!(
            QuoteError::UnknownZone("mars".into()).to_string(),
            "unknown zone: mars"
         );
        assert_eq!(
            QuoteError::Overweight { grams: 50_000, limit: 20_000 }.to_string(),
            "parcel of 50000g exceeds zone limit of 20000g"
         );
      }

      #[test]
    fn error_is_a_standard_error() {
         // `QuoteError` must be usable where `std::error::Error` is required.
        let err: Box<dyn std::error::Error> =
            Box::new(QuoteError::RateCardUnavailable);
        assert_eq!(err.to_string(), "rate card is unavailable");
      }

      #[test]
    fn quote_is_plain_data() {
         // `Quote`'s fields are read directly by callers; confirm the struct is
         // non-trivial data and `Debug` is available for diagnostics.
        let q = Quote {
            base_cents: 599,
            surcharge_cents: 0,
            total_cents: 599,
            band_max_grams: 500,
         };
        assert_eq!(q.total_cents, 599);
        assert!(format!("{q:?}").contains("599"));
      }
}
