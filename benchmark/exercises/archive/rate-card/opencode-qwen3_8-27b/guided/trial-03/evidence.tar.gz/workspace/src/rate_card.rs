use std::collections::BTreeMap;

use crate::{Parcel, Quote, QuoteError};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Band {
    pub band_max_grams: u32,
    pub cents: u64,
}

#[derive(Clone, Debug)]
pub struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

impl RateCard {
    pub fn bands_for(&self, zone: &str) -> Option<&[Band]> {
        self.zones
            .get(zone)
            .filter(|bands| !bands.is_empty())
            .map(|bands| bands.as_slice())
    }
}

pub fn parse(text: &str) -> Result<RateCard, QuoteError> {
    let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

    for (index, line) in text.lines().enumerate() {
        let line_no = index + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let Some(zone) = fields.next() else {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        };
        let Some(grams) = fields.next() else {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        };
        let Some(cents) = fields.next() else {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        };
        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }

        let band_max_grams = grams
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents = cents
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;

        zones
            .entry(zone.to_string())
            .or_default()
            .push(Band {
                band_max_grams,
                cents,
            });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(RateCard { zones })
}

pub fn compute_quote(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let Some(bands) = card.bands_for(&parcel.zone) else {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    };

    let base = match bands.iter().position(|band| band.band_max_grams >= parcel.weight_grams) {
        Some(index) => &bands[index],
        None => {
            let limit = bands[bands.len() - 1].band_max_grams;
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
             });
        }
     };

    let base_cents = base.cents;
    let band_max_grams = base.band_max_grams;

    let mut surcharge_cents = 0u64;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{Parcel, QuoteError};

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn card() -> RateCard {
        parse(CARD).expect("example card parses")
    }

    #[test]
    fn picks_first_band_at_or_above_weight() {
        let q = compute_quote(&card(), &Parcel { weight_grams: 300, zone: "domestic".into() })
            .expect("quote");
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
    }

    #[test]
    fn falls_into_next_band() {
        let q = compute_quote(&card(), &Parcel { weight_grams: 1500, zone: "domestic".into() })
            .expect("quote");
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn weight_surcharge_applies_above_10000() {
        let q = compute_quote(&card(), &Parcel { weight_grams: 12_000, zone: "domestic".into() })
            .expect("quote");
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20_000);
    }

    #[test]
    fn weight_surcharge_does_not_apply_at_10000() {
        let q = compute_quote(&card(), &Parcel { weight_grams: 10_000, zone: "domestic".into() })
            .expect("quote");
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_twenty_percent_half_up() {
        let q = compute_quote(&card(), &Parcel { weight_grams: 300, zone: "international".into() })
            .expect("quote");
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_weight_and_zone_surcharges_stack() {
        let q = compute_quote(
            &card(),
            &Parcel { weight_grams: 12_000, zone: "international".into() },
        )
        .expect("quote");
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 500 + 1000);
        assert_eq!(q.total_cents, 4999 + 500 + 1000);
    }

    #[test]
    fn unknown_zone_is_reported() {
        let err = compute_quote(
            &card(),
            &Parcel { weight_grams: 300, zone: "africa".into() },
        )
        .expect_err("unknown zone");
        assert_eq!(err, QuoteError::UnknownZone("africa".into()));
    }

    #[test]
    fn overweight_returns_largest_band_limit() {
        let err = compute_quote(
            &card(),
            &Parcel { weight_grams: 50_000, zone: "domestic".into() },
        )
        .expect_err("overweight");
        assert_eq!(err, QuoteError::Overweight { grams: 50_000, limit: 20_000 });
    }

    #[test]
    fn malformed_line_reports_one_based_number() {
        let text = "# header\n\
domestic\t500\t599\n\
domestic\t500\n";
        let err = parse(text).expect_err("malformed");
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn non_numeric_field_is_malformed() {
        let text = "domestic\thalf\t599\n";
        let err = parse(text).expect_err("malformed");
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn too_many_fields_is_malformed() {
        let text = "domestic\t500\t599\textra\n";
        let err = parse(text).expect_err("malformed");
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn comments_and_blanks_are_ignored_but_counted() {
        // Four physical lines: blank, comment, blank, then a 2-field line.
        // The malformed (2-field) line is line 4, proving blanks/comments count.
        let text = "\n# a comment\n\ndomestic\t500\n";
        let err = parse(text).expect_err("malformed on line 4");
        assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
     }
}
