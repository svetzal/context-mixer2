use crate::{Quote, QuoteError};

#[derive(Debug, Clone)]
pub struct Band {
    pub zone: String,
    pub band_max_grams: u32,
    pub cents: u64,
}

pub fn parse_rate_card(contents: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();
    for (idx, raw) in contents.lines().enumerate() {
        let line = idx + 1;
        if raw.is_empty() || raw.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = raw.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line });
        }
        let band_max_grams = fields[1]
            .trim()
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line })?;
        let cents = fields[2]
            .trim()
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line })?;
        bands.push(Band {
            zone: fields[0].trim().to_string(),
            band_max_grams,
            cents,
        });
    }
    Ok(bands)
}

fn international_surcharge(base_cents: u64) -> u64 {
    (base_cents * 20 + 50) / 100
}

pub fn calculate_quote(
    bands: &[Band],
    zone: &str,
    weight_grams: u32,
) -> Result<Quote, QuoteError> {
    let zone_bands: Vec<&Band> = bands
        .iter()
        .filter(|b| b.zone == zone)
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(zone.to_string()));
    }

    let mut ordered = zone_bands;
    ordered.sort_by_key(|b| b.band_max_grams);

    let band = match ordered.iter().find(|b| b.band_max_grams >= weight_grams) {
        Some(band) => band,
        None => {
            let limit = ordered.last().unwrap().band_max_grams;
            return Err(QuoteError::Overweight {
                grams: weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;
    if weight_grams > 10000 {
        surcharge_cents += 500;
    }
    if zone == "international" {
        surcharge_cents += international_surcharge(base_cents);
    }
    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample() -> Vec<Band> {
        parse_rate_card(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n\
             international\t500\t1499\n\
             international\t20000\t4999\n",
        )
        .unwrap()
    }

    #[test]
    fn picks_first_band_covering_weight() {
        let bands = sample();
        let q = calculate_quote(&bands, "domestic", 300).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn weight_above_10kg_adds_weight_surcharge() {
        let bands = sample();
        let q = calculate_quote(&bands, "domestic", 12000).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn international_adds_20_percent_rounded_half_up() {
        let bands = sample();
        let q = calculate_quote(&bands, "international", 500).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn unknown_zone_rejects() {
        let bands = sample();
        let err = calculate_quote(&bands, "antarctic", 100).unwrap_err();
        assert!(matches!(err, QuoteError::UnknownZone(ref z) if z == "antarctic"));
    }

    #[test]
    fn weight_above_largest_band_is_overweight() {
        let bands = sample();
        let err = calculate_quote(&bands, "domestic", 25000).unwrap_err();
        assert!(matches!(
            err,
            QuoteError::Overweight {
                grams: 25000,
                limit: 20000
            }
        ));
    }

    #[test]
    fn malformed_line_reports_1_based_number() {
        let contents = "# zone\tband_max_grams\tcents\n\
                        domestic\t500\n\
                        domestic\t2000\t899\n";
        let err = parse_rate_card(contents).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn non_numeric_field_is_malformed() {
        let contents = "domestic\t500\tfast\n";
        let err = parse_rate_card(contents).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn comments_and_blanks_are_skipped() {
        let contents = "# header\n\
                        \n\
                        # another comment\n\
                        domestic\t500\t599\n\n";
        let bands = parse_rate_card(contents).unwrap();
        assert_eq!(bands.len(), 1);
    }

    #[test]
    fn international_weight_surcharge_combines() {
        let bands = sample();
        let q = calculate_quote(&bands, "international", 12000).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 500 + 1000);
        assert_eq!(q.total_cents, 4999 + 1500);
        assert_eq!(q.band_max_grams, 20000);
    }
}
