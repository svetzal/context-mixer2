pub mod ratecard;
pub mod zones;

use std::fs;

pub use ratecard::{calculate_quote, parse_rate_card, Band};

/// A parcel to be priced against the rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A computed shipping quote.
///
/// `base_cents` is the matched band's price, `surcharge_cents` is the sum of
/// every applicable surcharge, and `total_cents` is their sum. `band_max_grams`
/// is the threshold of the matched band.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Failures that can occur while producing a [`Quote`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card is unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "weight {grams} grams exceeds limit {limit} grams")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Price a [`Parcel`] against the rate card named by `RATECARD_PATH`.
///
/// The matching band is the first band for the parcel's zone whose
/// `band_max_grams` is greater than or equal to the parcel weight, evaluated in
/// ascending order. Surcharges add a 500-cent weight premium above 10 kg and,
/// for the `international` zone, 20% of `base_cents` rounded half-up.
///
/// # Errors
///
/// Returns [`QuoteError`] when the rate card is missing or unreadable, when a
/// line is malformed, when the zone is unknown, or when the weight exceeds the
/// zone's largest band.
///
/// # Examples
///
/// ```
/// # use ratecard::{Parcel, quote};
/// # std::env::set_var("RATECARD_PATH", "tests/fixture_ratecard.tsv");
/// let parcel = Parcel { weight_grams: 300, zone: "domestic".into() };
/// let q = quote(&parcel).unwrap();
/// assert_eq!(q.base_cents, 599);
/// assert_eq!(q.total_cents, 599);
/// # std::env::remove_var("RATECARD_PATH");
/// ```
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = match std::env::var("RATECARD_PATH") {
        Ok(path) => path,
        Err(_) => return Err(QuoteError::RateCardUnavailable),
    };

    let contents = match fs::read_to_string(&path) {
        Ok(contents) => contents,
        Err(_) => return Err(QuoteError::RateCardUnavailable),
     };

    let bands = parse_rate_card(&contents)?;
    let quote = calculate_quote(&bands, &parcel.zone, parcel.weight_grams)?;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = quote.total_cents,
        "quote"
     );

    Ok(quote)
}
