use std::env;
use std::sync::{Mutex, OnceLock};

use ratecard::{quote, Parcel, QuoteError};
use tempfile::NamedTempFile;

const RATECARD: &str = "# zone\tband_max_grams\tcents\n\
                         domestic\t500\t599\n\
                         domestic\t2000\t899\n\
                         domestic\t20000\t1799\n\
                         international\t500\t1499\n\
                         international\t20000\t4999\n";

static ENV_LOCK: Mutex<()> = Mutex::new(());
static VALID_CARD: OnceLock<NamedTempFile> = OnceLock::new();

fn valid_card_path() -> String {
    let file = VALID_CARD.get_or_init(|| {
        let f = NamedTempFile::new().unwrap();
        std::fs::write(f.path(), RATECARD).unwrap();
        f
      });
    file.path().to_string_lossy().into_owned()
}

fn with_ratecard(contents: &str) -> NamedTempFile {
    let f = NamedTempFile::new().unwrap();
    std::fs::write(f.path(), contents).unwrap();
    env::set_var("RATECARD_PATH", f.path());
    f
}

fn with_valid_card() {
    env::set_var("RATECARD_PATH", valid_card_path());
}

fn quote_at(weight: u32, zone: &str) -> Result<ratecard::Quote, QuoteError> {
    quote(&Parcel { weight_grams: weight, zone: zone.into() })
}

#[test]
fn domestic_band_selection() {
    let _lock = ENV_LOCK.lock().unwrap();
    with_valid_card();
    let q = quote_at(300, "domestic").unwrap();
    assert_eq!(q.base_cents, 599);
    assert_eq!(q.surcharge_cents, 0);
    assert_eq!(q.total_cents, 599);
    assert_eq!(q.band_max_grams, 500);
}

#[test]
fn domestic_mid_band() {
    let _lock = ENV_LOCK.lock().unwrap();
    with_valid_card();
    let q = quote_at(1500, "domestic").unwrap();
    assert_eq!(q.base_cents, 899);
    assert_eq!(q.band_max_grams, 2000);
}

#[test]
fn domestic_top_band_with_weight_surcharge() {
    let _lock = ENV_LOCK.lock().unwrap();
    with_valid_card();
    let q = quote_at(12000, "domestic").unwrap();
    assert_eq!(q.base_cents, 1799);
    assert_eq!(q.surcharge_cents, 500);
    assert_eq!(q.total_cents, 2299);
    assert_eq!(q.band_max_grams, 20000);
}

#[test]
fn weight_exactly_at_band_threshold_matches() {
    let _lock = ENV_LOCK.lock().unwrap();
    with_valid_card();
    let q = quote_at(500, "domestic").unwrap();
    assert_eq!(q.band_max_grams, 500);
}

#[test]
fn international_surcharge_rounds_half_up() {
    let _lock = ENV_LOCK.lock().unwrap();
    with_valid_card();
    let q = quote_at(500, "international").unwrap();
    assert_eq!(q.base_cents, 1499);
    assert_eq!(q.surcharge_cents, 300);
    assert_eq!(q.total_cents, 1799);
}

#[test]
fn international_combines_weight_and_zone_surcharge() {
    let _lock = ENV_LOCK.lock().unwrap();
    with_valid_card();
    let q = quote_at(12000, "international").unwrap();
    assert_eq!(q.base_cents, 4999);
    assert_eq!(q.surcharge_cents, 500 + 1000);
    assert_eq!(q.total_cents, 4999 + 1500);
}

#[test]
fn unknown_zone() {
    let _lock = ENV_LOCK.lock().unwrap();
    with_valid_card();
    let err = quote_at(100, "antarctic").unwrap_err();
    assert_eq!(err, QuoteError::UnknownZone("antarctic".into()));
}

#[test]
fn overweight_beyond_largest_band() {
    let _lock = ENV_LOCK.lock().unwrap();
    with_valid_card();
    let err = quote_at(25000, "domestic").unwrap_err();
    assert_eq!(err, QuoteError::Overweight { grams: 25000, limit: 20000 });
}

#[test]
fn destructive_env_cases() {
    let _lock = ENV_LOCK.lock().unwrap();

    env::remove_var("RATECARD_PATH");
    let err = quote_at(100, "domestic").unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);

    env::set_var("RATECARD_PATH", "/nonexistent/does/not/exist.tsv");
    let err = quote_at(100, "domestic").unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);

    let _card = with_ratecard("# zone\tband_max_grams\tcents\n\
                                domestic\t500\n\
                                domestic\t2000\t899\n");
    let err = quote_at(100, "domestic").unwrap_err();
    assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });

    let _card = with_ratecard("domestic\t500\tfast\n");
    let err = quote_at(100, "domestic").unwrap_err();
    assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });

    env::set_var("RATECARD_PATH", "");
    let err = quote_at(100, "domestic").unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn error_displays_human_readable_message() {
    let err = QuoteError::Overweight { grams: 25000, limit: 20000 };
    assert!(err.to_string().contains("25000"));
    assert!(err.to_string().contains("20000"));
    let err = QuoteError::MalformedRateCard { line: 3 };
    assert!(err.to_string().contains("3"));
    let err = QuoteError::UnknownZone("x".into());
    assert!(err.to_string().contains("x"));
    let err = QuoteError::RateCardUnavailable;
    assert!(err.to_string().contains("unavailable"));
}
