//! Shipping quotes from a zone rate card.
//!
//! The rate card is read from the path named by the `RATECARD_PATH`
//! environment variable. `quote` resolves a single parcel against that card and
//! returns a [`Quote`], or a [`QuoteError`] describing a recoverable failure.
//!
//! The heavy lifting lives in the pure `quotes` module; this module is a thin
//! imperative shell that owns the environment and filesystem effects and emits
//! one tracing diagnostic per call.

mod quotes;

pub mod zones;

use std::fs;
use std::path::PathBuf;

/// A parcel to be quoted.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Weight of the parcel in grams.
    pub weight_grams: u32,
    /// Destination shipping zone.
    pub zone: String,
}

/// The result of quoting a [`Parcel`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Base price for the matched band, in cents.
    pub base_cents: u64,
    /// Total surcharge applied, in cents.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// `band_max_grams` of the matched band.
    pub band_max_grams: u32,
}

/// A recoverable failure while producing a quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The `RATECARD_PATH` environment variable is unset, or the file it
    /// names is missing or unreadable.
    RateCardUnavailable,
    /// A rate-card line is not three tab-separated fields, or a field is not a
    /// number. Carries the 1-based line number of the offending line.
    MalformedRateCard {
        /// 1-based line number in the file counting every line, including
        /// comments and blanks.
        line: usize,
    },
    /// The parcel's zone is not present in the rate card. Carries the zone.
    UnknownZone(String),
    /// The parcel weight exceeds the zone's largest band. Carries the weight
    /// (`grams`) and the largest band threshold (`limit`), both in grams.
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel overweight: {grams}g exceeds band limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Quote a `parcel` against the rate card named by `RATECARD_PATH`.
///
/// Surcharges add together: a weight strictly above 10,000 grams adds 500
/// cents, and the `international` zone adds 20% of the base price rounded
/// half-up to the cent. `total_cents` is the sum of the base and surcharge.
///
/// # Errors
///
/// - [`QuoteError::RateCardUnavailable`] if `RATECARD_PATH` is unset or the
///   file is missing or unreadable.
/// - [`QuoteError::MalformedRateCard { line }`] if a rate-card line is not
///   three tab-separated fields, or a field is not a number; `line` is the
///   1-based line number.
/// - [`QuoteError::UnknownZone`]: if the parcel's `zone` is absent from the card.
/// - [`QuoteError::Overweight`]: if the parcel weight exceeds the zone's
///   largest band (in which case `limit` is that largest band).
#[must_use = "a quote carries the price and may report a recoverable failure that must be handled"]
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let result = resolve_quote(parcel);

    // Exactly one diagnostic is emitted per call, regardless of outcome, so
    // every `quote` is observable in operation. The total is the resulting
    // total on success and 0 for a failed quote, with the outcome label making
    // the result independently queryable.
    let (total_cents, outcome) = match &result {
        Ok(q) => (q.total_cents, "ok"),
        Err(e) => (0, error_label(e)),
        };
    let zone = parcel.zone.clone();
    let weight_grams = parcel.weight_grams;

    tracing::event!(
        tracing::Level::DEBUG,
         message = "quote resolved",
         zone,
         weight_grams,
         total_cents,
         outcome,
          );

    result
}

/// Read the rate card named by `RATECARD_PATH`, parse it, and resolve the
/// parcel against it. This owns all I/O (environment + filesystem) so the pure
/// logic in [`quotes`] remains free of side effects.
fn resolve_quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = resolve_ratecard_path()?;
    let text = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = quotes::parse(&text).map_err(|line| QuoteError::MalformedRateCard { line })?;
    quotes::resolve(&parcel.zone, parcel.weight_grams, &card)
}

/// Resolve the rate-card path from the environment, returning
/// [`QuoteError::RateCardUnavailable`] if it is unset.
fn resolve_ratecard_path() -> Result<PathBuf, QuoteError> {
    std::env::var("RATECARD_PATH")
        .ok()
        .filter(|s| !s.trim().is_empty())
        .map(PathBuf::from)
        .ok_or(QuoteError::RateCardUnavailable)
}

/// A stable, human-readable label for a [`QuoteError`], used as a tracing
/// field so the outcome is a queryable value rather than an interpolated string.
fn error_label(error: &QuoteError) -> &'static str {
    match error {
        QuoteError::RateCardUnavailable => "rate_card_unavailable",
        QuoteError::MalformedRateCard { .. } => "malformed_rate_card",
        QuoteError::UnknownZone(_) => "unknown_zone",
        QuoteError::Overweight { .. } => "overweight",
      }
}

#[cfg(test)]
mod tests {
    use super::{quote, Parcel};

    #[test]
    fn unknown_zone_is_reported_by_shell() {
        let parcel = Parcel {
            weight_grams: 100,
            zone: "nowhere".to_string(),
        };
        // The card cannot be read in this process unless RATECARD_PATH is set,
        // so assert the shell surfaces a recoverable error rather than panicking.
        assert!(quote(&parcel).is_err());
    }
}
