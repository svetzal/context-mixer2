//! Pure rate-card parsing and quote resolution.
//!
//! Nothing here touches the environment, the filesystem, or the clock: the
//! result is a function of the arguments alone, so behaviour can be tested
//! deterministically without I/O or external infrastructure.

use std::collections::BTreeMap;

use crate::{Quote, QuoteError};

#[derive(Debug, Clone, PartialEq)]
pub(crate) struct Band {
    pub max_grams: u32,
    pub cents: u64,
}

#[derive(Debug, Clone, PartialEq)]
pub(crate) struct ZoneRates {
    pub bands: Vec<Band>,
}

pub(crate) type RateCard = BTreeMap<String, ZoneRates>;

const HEAVY_PARCEL_THRESHOLD: u32 = 10_000;
const HEAVY_SURCHARGE: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";

/// Parse `content` into a rate card.
///
/// Blank lines and lines beginning with `#` are ignored but still counted for
/// line numbers. Returns the 1-based line number of the first malformed line,
/// where malformed means not exactly three tab-separated fields, or a field
/// whose number will not parse.
pub(crate) fn parse(content: &str) -> Result<RateCard, usize> {
    let mut card: RateCard = BTreeMap::new();

    for (idx, raw) in content.lines().enumerate() {
        let line = idx + 1;
        let trimmed = raw.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = raw.split('\t').collect();
        if fields.len() != 3 {
            return Err(line);
        }

        let zone = fields[0];
        let max_grams: u32 = fields[1].trim().parse().map_err(|_| line)?;
        let cents: u64 = fields[2].trim().parse().map_err(|_| line)?;

        card
            .entry(zone.to_string())
            .or_insert_with(|| ZoneRates {
                bands: Vec::new(),
            })
            .bands
            .push(Band {
                max_grams,
                cents,
            });
    }

    for zone in card.values_mut() {
        zone.bands.sort_by_key(|b| b.max_grams);
    }

    Ok(card)
}

/// Resolve `weight` (grams) in `zone` against `card`.
///
/// The matched band is the first, in ascending `max_grams` order, whose
/// threshold is greater than or equal to the weight. Surcharges are summed:
///
/// - a weight strictly above [`HEAVY_PARCEL_THRESHOLD`] adds
///   [`HEAVY_SURCHARGE`] cents;
/// - the [`INTERNATIONAL_ZONE`] zone adds 20% of the band's cents, rounded
///   half-up to the cent.
pub(crate) fn resolve(zone: &str, weight: u32, card: &RateCard) -> Result<Quote, QuoteError> {
    let zone_rates = card
        .get(zone)
        .ok_or_else(|| QuoteError::UnknownZone(zone.to_string()))?;

    let band = zone_rates
        .bands
        .iter()
        .find(|b| b.max_grams >= weight)
        .ok_or_else(|| QuoteError::Overweight {
            grams: weight,
            limit: zone_rates.bands.last().map(|b| b.max_grams).unwrap_or(0),
        })?;

    let base_cents = band.cents;

    let mut surcharge_cents = 0u64;
    if weight > HEAVY_PARCEL_THRESHOLD {
        surcharge_cents += HEAVY_SURCHARGE;
    }
    if zone == INTERNATIONAL_ZONE {
        surcharge_cents += round_half_up(base_cents, 20, 100);
    }

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

/// Round `base * num / den` to the nearest whole, half-up.
fn round_half_up(base: u64, num: u64, den: u64) -> u64 {
    (base * num + den / 2) / den
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn card() -> RateCard {
        parse(SAMPLE).expect("sample rate card parses")
    }

    #[test]
    fn parses_zones_and_orders_bands_ascending() {
        let card = card();
        assert_eq!(card.len(), 2);
        let domestic = &card["domestic"];
        assert_eq!(
            domestic.bands.iter().map(|b| b.max_grams).collect::<Vec<_>>(),
            [500u32, 2000, 20000]
        );
        assert_eq!(card["international"].bands.len(), 2);
    }

    #[test]
    fn ignores_comments_and_blanks_but_counts_them() {
        let content = "# a comment\n\n   \nbad line\n";
        // line 4 is the first non-ignored line and is not three tab fields
        assert_eq!(parse(content).err(), Some(4));
    }

    #[test]
    fn rejects_two_field_line() {
        assert_eq!(parse("domestic\t500\n").err(), Some(1));
    }

    #[test]
    fn rejects_non_numeric_fields() {
        assert_eq!(parse("domestic\tnope\t500\n").err(), Some(1));
        assert_eq!(parse("domestic\t500\tnope\n").err(), Some(1));
    }

    #[test]
    fn trims_numeric_fields() {
        let content = "domestic\t  500 \t  599 \n";
        let card = parse(content).expect("trimmed parse ok");
        let band = &card["domestic"].bands[0];
        assert_eq!(band.max_grams, 500);
        assert_eq!(band.cents, 599);
    }

    #[test]
    fn domestic_low_band_no_surcharge() {
        let q = resolve("domestic", 300, &card()).unwrap();
        assert_eq!(
            q,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn domestic_upper_band_boundary() {
        // 500g is the first band whose max (500) is >= 500
        let q = resolve("domestic", 500, &card()).unwrap();
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn heavy_surcharge_kicks_in_above_threshold() {
        let q = resolve("domestic", 12_000, &card()).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn heavy_surcharge_not_applied_at_threshold() {
        let q = resolve("domestic", 10_000, &card()).unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_twenty_percent_rounded_half_up() {
        // 20% of 1499 = 299.8 -> 300
        let q = resolve("international", 300, &card()).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn international_and_heavy_combine() {
        // base 4999; 20% of 4999 = 999.8 -> 1000; plus 500 heavy = 1500
        let q = resolve("international", 15_000, &card()).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone() {
        let err = resolve("mars", 100, &card()).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("mars".to_string()));
    }

    #[test]
    fn overweight_reports_largest_band_limit() {
        let err = resolve("domestic", 30_000, &card()).unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 30_000,
                limit: 20_000,
            }
        );
    }
}
