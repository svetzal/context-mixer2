//! Integration tests exercising `ratecard::quote` end-to-end against a real
//! rate-card file on disk, and asserting the tracing diagnostic per call.
//!
//! All three tests mutate the process-global `RATECARD_PATH` environment
//! variable, so they are serialised by a shared mutex to avoid racing with one
//! another when cargo runs the test harness concurrently.

use std::io::Write;
use std::path::PathBuf;
use std::sync::{Arc, Mutex, MutexGuard};

use ratecard::{quote, Parcel, Quote, QuoteError};
use tracing::field::{Field, Visit};
use tracing_subscriber::layer::{Context, Layer, SubscriberExt};
use tracing_subscriber::registry::Registry;
use tracing::{Event, Subscriber};

/// Serialises the tests that depend on the process-global `RATECARD_PATH`
/// environment variable.
static ENV_LOCK: Mutex<()> = Mutex::new(());

/// Holds [`ENV_LOCK`] for the calling test so the tests run one at a time.
fn hold_env_lock() -> MutexGuard<'static, ()> {
    ENV_LOCK
        .lock()
        .expect("RATECARD_PATH test lock is not poisoned")
}

/// The three fields the task requires to be observable per quote, plus the
/// outcome label so failures are queryable too.
#[derive(Clone, Debug, PartialEq, Eq)]
struct Record {
    zone: String,
    weight_grams: u32,
    total_cents: u64,
    outcome: String,
}

/// A minimal [`Layer`] that appends a [`Record`] for every event. The store is
/// an `Arc<Mutex<Vec<Record>>>` so the same buffer can be handed to the
/// subscriber and inspected by the test without cloning the `Mutex`.
#[derive(Clone)]
struct RecorderLayer {
    records: Arc<Mutex<Vec<Record>>>,
}

impl RecorderLayer {
    fn new() -> Self {
        Self {
            records: Arc::new(Mutex::new(Vec::new())),
          }
     }
}

struct FieldVisitor<'a> {
    map: &'a mut std::collections::HashMap<String, String>,
}

impl Visit for FieldVisitor<'_> {
    fn record_str(&mut self, field: &Field, value: &str) {
        self.map.insert(field.name().to_string(), value.to_string());
       }
    fn record_debug(&mut self, field: &Field, value: &dyn std::fmt::Debug) {
        self
                .map
                .insert(field.name().to_string(), format!("{value:?}"));
       }
}

impl<S: Subscriber> Layer<S> for RecorderLayer {
    fn on_event(&self, event: &Event<'_>, _ctx: Context<'_, S>) {
        let mut map = std::collections::HashMap::new();
        let mut visitor = FieldVisitor { map: &mut map };
        event.record(&mut visitor);

        self.records.lock().unwrap().push(Record {
            zone: map.get("zone").cloned().unwrap_or_default(),
            weight_grams: map
                    .get("weight_grams")
                    .and_then(|v| v.parse::<u32>().ok())
                    .unwrap_or(0),
            total_cents: map
                    .get("total_cents")
                    .and_then(|v| v.parse::<u64>().ok())
                    .unwrap_or(0),
            outcome: map.get("outcome").cloned().unwrap_or_default(),
          });
       }
}

fn write_ratecard(path: &PathBuf, body: &str) {
    let mut f = std::fs::File::create(path).expect("create ratecard file");
    f.write_all(body.as_bytes()).expect("write ratecard body");
    f.flush().expect("flush ratecard");
}

fn set_ratecard(path: &PathBuf) {
    std::env::set_var("RATECARD_PATH", path);
}

const GOOD_CARD: &str = "# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

#[test]
fn end_to_end_quote_behaviour_and_observability() {
    let _lock = hold_env_lock();
    let tmp = tempfile::tempdir().expect("tempdir");
    let ratecard = tmp.path().join("ratecard.tsv");
    write_ratecard(&ratecard, GOOD_CARD);
    set_ratecard(&ratecard);

    let layer = RecorderLayer::new();

      // `with_default` installs the subscriber only on this test thread for the
       // duration of the closure, so it does not conflict with other threads'
       // subscribers and the records are collected deterministically.
    let subscriber = Registry::default().with(layer.clone());
    tracing::subscriber::with_default(subscriber, || {
          // 1. domestic low band, no surcharge.
        let p = Parcel {
            weight_grams: 300,
            zone: "domestic".into(),
          };
        let q = quote(&p).expect("domestic low ok");
        assert_eq!(
            q,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
              }
          );

           // 2. domestic exactly at a band boundary.
        let p = Parcel {
            weight_grams: 500,
            zone: "domestic".into(),
          };
        let q = quote(&p).expect("domestic 500 ok");
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.base_cents, 599);

           // 3. domestic above the heavy threshold -> +500.
        let p = Parcel {
            weight_grams: 12_000,
            zone: "domestic".into(),
          };
        let q = quote(&p).expect("domestic heavy ok");
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20_000);

           // 4. domestic at exactly 10_000 -> no heavy surcharge.
        let p = Parcel {
            weight_grams: 10_000,
            zone: "domestic".into(),
          };
        let q = quote(&p).expect("domestic at 10k ok");
        assert_eq!(q.surcharge_cents, 0);

           // 5. international low band -> +20% of 1499 = 300 (half-up).
        let p = Parcel {
            weight_grams: 300,
            zone: "international".into(),
          };
        let q = quote(&p).expect("international low ok");
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
        assert_eq!(q.band_max_grams, 500);

           // 6. international heavy -> +20% of 4999 = 1000, plus +500 heavy.
        let p = Parcel {
            weight_grams: 15_000,
            zone: "international".into(),
          };
        let q = quote(&p).expect("international heavy ok");
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);

           // 7. unknown zone.
        let p = Parcel {
            weight_grams: 100,
            zone: "atlantis".into(),
          };
        assert_eq!(
            quote(&p).unwrap_err(),
            QuoteError::UnknownZone("atlantis".into())
           );

           // 8. overweight: above the zone's largest band.
        let p = Parcel {
            weight_grams: 30_000,
            zone: "domestic".into(),
          };
        assert_eq!(
            quote(&p).unwrap_err(),
            QuoteError::Overweight {
                grams: 30_000,
                limit: 20_000,
               }
          );
       });

      // Inspect the diagnostic records captured alongside the assertions above.
    let records: Vec<Record> = layer.records.lock().unwrap().clone();

      // Every quote() call above must have emitted exactly one diagnostic record.
    assert_eq!(records.len(), 8, "expected 8 records, got {}", records.len());

       // The zone, weight, and total appear as queryable fields on the record.
    assert_eq!(records[0].zone, "domestic".to_string());
    assert_eq!(records[0].weight_grams, 300);
    assert_eq!(records[0].total_cents, 599);
    assert_eq!(records[0].outcome, "ok".to_string());

    assert_eq!(records[5].zone, "international".to_string());
    assert_eq!(records[5].total_cents, 6499);

    assert_eq!(records[6].zone, "atlantis".to_string());
    assert_eq!(records[6].outcome, "unknown_zone".to_string());

    assert_eq!(records[7].outcome, "overweight".to_string());
}

#[test]
fn malformed_rate_card_reports_one_based_line_number() {
    let _lock = hold_env_lock();
    let tmp = tempfile::tempdir().expect("tempdir");
    let ratecard = tmp.path().join("ratecard.tsv");
       // line 1 is a comment, line 2 is blank, line 3 is the broken line.
    write_ratecard(&ratecard, "# header\n\ndomestic\n");
    set_ratecard(&ratecard);

    let p = Parcel {
        weight_grams: 100,
        zone: "domestic".into(),
      };
    match quote(&p) {
        Err(QuoteError::MalformedRateCard { line }) => {
            assert_eq!(line, 3, "1-based line counting including comments and blanks");
          }
        other => panic!("expected MalformedRateCard, got {other:?}"),
       }
}

#[test]
fn missing_ratecard_is_unavailable() {
    let _lock = hold_env_lock();
    set_ratecard(&PathBuf::from("/nonexistent/ratecard-never-here.tsv"));
    let p = Parcel {
        weight_grams: 100,
        zone: "domestic".into(),
      };
    assert_eq!(
        quote(&p).unwrap_err(),
        QuoteError::RateCardUnavailable
      );
}
