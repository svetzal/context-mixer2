//! Integration tests: boundary wiring and cross-module flow, plus an
//! observability check that a diagnostic is emitted per quote carrying the zone,
//! the weight in grams, and the resulting total in cents.
#![allow(clippy::unwrap_used, clippy::expect_used)]

use std::io;
use std::io::Write;
use std::sync::{Arc, Mutex, Once, OnceLock, MutexGuard};
use tracing_subscriber::fmt::MakeWriter;
/// A writer that appends everything written to it into a shared buffer, so a
/// captured tracing subscriber can hand each field out as queryable text.
struct CapturingWriter {
    buffer: Arc<Mutex<Vec<u8>>>,
}

impl io::Write for CapturingWriter {
    fn write(&mut self, data: &[u8]) -> io::Result<usize> {
        self.buffer.lock().unwrap().extend_from_slice(data);
        Ok(data.len())
     }

    fn flush(&mut self) -> io::Result<()> {
        Ok(())
     }
}

/// `MakeWriter` implementation that hands out a fresh [`CapturingWriter`] per
/// event, all writing into the same shared buffer.
#[derive(Clone)]
struct CapturingMakeWriter {
    buffer: Arc<Mutex<Vec<u8>>>,
}

impl<'a> MakeWriter<'a> for CapturingMakeWriter {
    type Writer = CapturingWriter;

    fn make_writer(&'a self) -> Self::Writer {
        CapturingWriter {
            buffer: self.buffer.clone(),
         }
     }
}

static BUFFER: OnceLock<Arc<Mutex<Vec<u8>>>> = OnceLock::new();
static INSTALL: Once = Once::new();

// Rate cards are persisted in a process-lifetime holder so the underlying file
// is not deleted when the writer drops, and every mutation of the shared
// `RATECARD_PATH` env var serialises on this lock.
static CARD_FILES: OnceLock<Mutex<Vec<tempfile::NamedTempFile>>> = OnceLock::new();
static ENV_LOCK: OnceLock<Mutex<()>> = OnceLock::new();

fn env_guard() -> MutexGuard<'static, ()> {
    ENV_LOCK
          .get_or_init(|| Mutex::new(()))
          .lock()
          .unwrap()
       }

fn shared_buffer() -> Arc<Mutex<Vec<u8>>> {
    BUFFER
          .get_or_init(|| Arc::new(Mutex::new(Vec::new())))
          .clone()
}

/// Install the capturing subscriber exactly once for the whole test binary, so
/// repeated `quote` calls are all recorded into one shared buffer.
fn install_subscriber_once() {
    INSTALL.call_once(|| {
        let make = CapturingMakeWriter {
            buffer: shared_buffer(),
         };
        let subscriber = tracing_subscriber::fmt()
             .with_writer(make)
             .with_ansi(false)
             .without_time()
             .with_target(false)
             .finish();
        let _ = tracing::subscriber::set_global_default(subscriber);
    });
}

fn clear_captured() {
    shared_buffer().lock().unwrap().clear();
}

fn captured() -> String {
    String::from_utf8(shared_buffer().lock().unwrap().to_vec()).unwrap_or_default()
}

fn set_ratecard(contents: &str) -> String {
    let mut card = tempfile::NamedTempFile::new().unwrap();
    card.write_all(contents.as_bytes()).unwrap();
    let path = card.path().to_string_lossy().to_string();
    CARD_FILES
          .get_or_init(|| Mutex::new(Vec::new()))
          .lock()
          .unwrap()
          .push(card);
    std::env::set_var("RATECARD_PATH", &path);
    path
}

fn card() -> &'static str {
    "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
"
}

#[test]
fn quote_emits_a_diagnostic_with_zone_weight_and_total() {
    let _g = env_guard();
    install_subscriber_once();
    clear_captured();

    set_ratecard(card());
    let parcel = ratecard::Parcel {
        weight_grams: 12_000,
        zone: "international".to_string(),
      };

     let q = ratecard::quote(&parcel).unwrap();
    assert_eq!(q.total_cents, 6499);

     // The per-call diagnostic carries the zone, the weight in grams, and the
     // resulting total in cents as independently queryable fields.
    let logged = captured();
    assert!(logged.contains("quote"), "span present: {logged:?}");
    assert!(logged.contains("zone"), "zone field present: {logged:?}");
    assert!(
        logged.contains("international"),
         "zone value present: {logged:?}"
      );
    assert!(
        logged.contains("12000"),
         "weight field present: {logged:?}"
      );
    assert!(
        logged.contains("6499"),
         "total field present: {logged:?}"
      );

    std::env::remove_var("RATECARD_PATH");
}

#[test]
fn full_flow_from_env_to_quote() {
    let _g = env_guard();
    set_ratecard(card());
    let parcel = ratecard::Parcel {
        weight_grams: 1500,
        zone: "domestic".to_string(),
     };
    let q = ratecard::quote(&parcel).unwrap();
    assert_eq!(q.base_cents, 899);
    assert_eq!(q.band_max_grams, 2000);
    std::env::remove_var("RATECARD_PATH");
}
