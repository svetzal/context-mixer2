use crate::{Quote, QuoteError};

/// A single band parsed from the rate card.
#[derive(Clone, Debug)]
pub(crate) struct Band {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

/// Parse the body of a rate card into bands.
///
/// A line is ignored when, after trimming, it is empty or begins with `#`.
/// Every other line must be exactly three tab-separated fields whose second and
/// third fields parse as `u32` and `u64` respectively; otherwise
/// [`QuoteError::MalformedRateCard`] is returned carrying the 1-based line
/// number of the offending line (counting every line, including comments and
/// blanks).
pub(crate) fn parse_ratecard(content: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();
    for (i, line) in content.lines().enumerate() {
        let line_no = i + 1;
        let stripped = line.trim();
        if stripped.is_empty() || stripped.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }
        let zone = fields[0].trim().to_string();
        let band_max_grams = fields[1]
            .trim()
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents = fields[2]
            .trim()
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        bands.push(Band {
            zone,
            band_max_grams,
            cents,
        });
    }
    Ok(bands)
}

/// The 20% international surcharge on `base_cents`, rounded half-up to the cent.
fn international_surcharge(base_cents: u64) -> u64 {
    (base_cents * 20 + 50) / 100
}

/// Compute a quote from an in-memory card without touching the environment or
/// any I/O, returning the appropriate error for a missing zone, an over-weight
/// parcel, or a malformed card.
pub(crate) fn compute_quote(
    bands: &[Band],
    zone: &str,
    weight_grams: u32,
) -> Result<Quote, QuoteError> {
    let mut zone_bands: Vec<&Band> = bands
        .iter()
        .filter(|b| b.zone.as_str() == zone)
        .collect();
    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(zone.to_string()));
    }
    zone_bands.sort_by_key(|b| b.band_max_grams);

    let matched = zone_bands
        .iter()
        .find(|b| b.band_max_grams >= weight_grams)
        .copied();

    let (base_cents, band_max_grams) = match matched {
        Some(b) => (b.cents, b.band_max_grams),
        None => {
            let limit = zone_bands
                .iter()
                .map(|b| b.band_max_grams)
                .max()
                .unwrap_or(0);
            return Err(QuoteError::Overweight {
                grams: weight_grams,
                limit,
            });
        }
    };

    let mut surcharge_cents = 0u64;
    if weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if zone == "international" {
        surcharge_cents += international_surcharge(base_cents);
    }

    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    #![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

    use super::*;
    use crate::QuoteError;

    fn card() -> Vec<Band> {
        parse_ratecard(
            "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
",
        )
        .unwrap()
    }

    #[test]
    fn ignores_comments_and_blank_lines() {
        let bands = card();
        assert_eq!(bands.len(), 5);
        assert_eq!(bands[0].zone, "domestic");
        assert_eq!(bands[0].band_max_grams, 500);
        assert_eq!(bands[0].cents, 599);
    }

    #[test]
    fn reports_the_offending_line_for_a_bad_number() {
        let err = parse_ratecard("# h\ndomestic\t500\t599\ndomestic\tbad\t899\n")
            .unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn reports_the_offending_line_for_a_wrong_field_count() {
        let err = parse_ratecard("domestic\t500\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn matching_band_is_first_with_threshold_at_or_above_weight() {
        let bands = card();
        let q = compute_quote(&bands, "domestic", 600).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn weight_above_largest_band_is_overweight() {
        let bands = card();
        let err = compute_quote(&bands, "domestic", 99_999).unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 99_999,
                limit: 20_000
            }
        );
    }

    #[test]
    fn unknown_zone_is_reported() {
        let bands = card();
        let err = compute_quote(&bands, "antarctic", 100).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("antarctic".into()));
    }

    #[test]
    fn over_ten_kilograms_adds_five_hundred_cents() {
        let bands = card();
        let q = compute_quote(&bands, "domestic", 15_000).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn international_adds_twenty_percent_rounded_half_up() {
        let bands = card();
        let q = compute_quote(&bands, "international", 12_000).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn no_surcharges_below_thresholds_for_domestic() {
        let bands = card();
        let q = compute_quote(&bands, "domestic", 400).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }
}
