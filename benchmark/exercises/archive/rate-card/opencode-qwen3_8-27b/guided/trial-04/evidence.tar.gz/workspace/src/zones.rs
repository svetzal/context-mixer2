//! Human-readable labels for shipping zones.

/// Return the human-readable label for a shipping zone.
///
/// Unknown zones are returned unchanged so callers can still display the
/// operator-provided key.
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
     }
}
