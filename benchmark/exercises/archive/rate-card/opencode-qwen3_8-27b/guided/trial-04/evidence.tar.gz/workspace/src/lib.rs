//! # ratecard
//!
//! Compute shipping quotes for parcels against a zone rate card that operations
//! maintains as a tab-separated file and redeploys without a code change.
//!
//! The rate card is read from the path named by the `RATECARD_PATH`
//! environment variable. Each call to [`quote`] is instrumented with a
//! correlated tracing span so that a quote's zone, weight, and resulting total
//! are independently queryable in logs.
//!
//! Business logic lives in a private module and is pure, so it can be tested
//! without real I/O; [`quote`] is a thin imperative shell that resolves the
//! environment and file system and maps results onto [`QuoteError`].
//!
//! # Example
//!
//! ```
//! use std::io::Write;
//! use tempfile::NamedTempFile;
//!
//! let mut card = NamedTempFile::new().unwrap();
//! writeln!(card, "domestic\t20000\t1799").unwrap();
//! let path = card.path().to_string_lossy().to_string();
//! std::env::set_var("RATECARD_PATH", &path);
//!
//! let parcel = ratecard::Parcel {
//!     weight_grams: 5000,
//!     zone: "domestic".to_string(),
//! };
//! let quote = ratecard::quote(&parcel).unwrap();
//! assert_eq!(quote.total_cents, 1799);
//!
//! std::env::remove_var("RATECARD_PATH");
//! ```
//!
//! [`quote`]: fn.quote.html

mod core;
pub mod zones;

/// A parcel to be quoted.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Weight of the parcel in grams.
    pub weight_grams: u32,
    /// Shipping zone key (for example `domestic` or `international`).
    pub zone: String,
}

/// The result of quoting a [`Parcel`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// The band's base rate in cents.
    pub base_cents: u64,
    /// The sum of all applicable surcharges in cents.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// The `band_max_grams` threshold of the matched band.
    pub band_max_grams: u32,
}

/// Errors that can occur while quoting a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, missing, or the file cannot be read.
    RateCardUnavailable,
    /// A non-comment line is not three tab-separated numeric fields.
    /// Carries the 1-based line number of the offending line.
    MalformedRateCard {
        /// 1-based line number of the malformed line.
        line: usize,
    },
    /// The requested zone is absent from the rate card.
    UnknownZone(String),
    /// The parcel weight exceeds the zone's largest band.
    Overweight {
        /// Weight of the parcel in grams.
        grams: u32,
        /// The largest `band_max_grams` for the zone.
        limit: u32,
    },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                f.write_str("rate card unavailable")
             }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {grams} g exceeds the {limit} g zone limit")
            }
         }
    }
}

impl std::error::Error for QuoteError {}

/// Quote a parcel against the rate card named by `RATECARD_PATH`.
///
/// The rate card is tab-separated, one band per line. Empty lines and lines
/// beginning with `#` are ignored. The matching band is the first (in ascending
/// `band_max_grams`) whose `band_max_grams` is at least the parcel weight.
///
/// Surcharges add to the base rate: 500 cents for a weight strictly above 10000
/// grams, and 20% of the base rate (rounded half-up) for the `international`
/// zone. `total_cents` is `base_cents + surcharge_cents`.
///
/// # Errors
///
/// Returns [`QuoteError::RateCardUnavailable`] if the path is unset, missing, or
/// unreadable; [`QuoteError::MalformedRateCard`] if a non-comment line is not
/// three tab-separated numeric fields; [`QuoteError::UnknownZone`] if the zone is
/// absent from the card; and [`QuoteError::Overweight`] if the weight exceeds
/// the zone's largest band.
///
/// # Examples
///
/// ```
/// use std::io::Write;
/// use std::path::PathBuf;
/// use tempfile::NamedTempFile;
///
/// let mut card = NamedTempFile::new().unwrap();
/// // tab-separated rate card
/// let _ = writeln!(card, "# zone\tband_max_grams\tcents");
/// let _ = writeln!(card, "domestic\t20000\t1799");
///
/// let path = card.path().to_string_lossy().to_string();
/// std::env::set_var("RATECARD_PATH", &path);
///
/// let parcel = ratecard::Parcel {
///     weight_grams: 5000,
///     zone: "domestic".to_string(),
/// };
/// let quote = ratecard::quote(&parcel).unwrap();
/// assert_eq!(quote.total_cents, 1799);
///
/// // clean up so the process-wide env var is not left set
/// std::env::remove_var("RATECARD_PATH");
/// let _ = PathBuf::from(&path);
/// ```
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let zone = parcel.zone.trim().to_string();
    let weight_grams = parcel.weight_grams;

    let span = tracing::info_span!("quote", zone = %zone, weight_grams = weight_grams);
    let _guard = span.enter();

    let path = match std::env::var("RATECARD_PATH") {
        Ok(p) => p,
        Err(_) => {
            tracing::warn!(zone = %zone, weight_grams = weight_grams, "rate card path unset");
            return Err(QuoteError::RateCardUnavailable);
         }
     };

    let content = match std::fs::read_to_string(&path) {
        Ok(c) => c,
        Err(_) => {
            tracing::warn!(
                zone = %zone,
                weight_grams = weight_grams,
                path = %path,
                "rate card unreadable"
             );
            return Err(QuoteError::RateCardUnavailable);
         }
     };

    let bands = match core::parse_ratecard(&content) {
        Ok(b) => b,
        Err(e) => {
            tracing::warn!(zone = %zone, weight_grams = weight_grams, "rate card malformed");
            return Err(e);
         }
     };

    match core::compute_quote(&bands, &zone, weight_grams) {
        Ok(quote) => {
            tracing::info!(
                zone = %zone,
                weight_grams = weight_grams,
                total_cents = quote.total_cents,
                "quote computed"
             );
            Ok(quote)
        }
        Err(e) => {
            tracing::warn!(zone = %zone, weight_grams = weight_grams, "quote failed");
            Err(e)
        }
    }
}

#[cfg(test)]
mod tests {
    #![allow(clippy::unwrap_used, clippy::expect_used)]

    use super::*;
    use std::io::Write;
    use std::path::PathBuf;
    use std::sync::{Mutex, OnceLock};

    // Temp files are kept alive for the life of the process so the rate-card
    // files outlive the `set_ratecard` call that created them.
    static CARD_FILES: OnceLock<Mutex<Vec<tempfile::NamedTempFile>>> = OnceLock::new();

    // The rate card is read from the process-global `RATECARD_PATH` env var, so
    // every test that mutates it takes this lock to avoid racing another test.
    static ENV_LOCK: OnceLock<Mutex<()>> = OnceLock::new();

    fn env_guard() -> std::sync::MutexGuard<'static, ()> {
        ENV_LOCK
             .get_or_init(|| Mutex::new(()))
             .lock()
             .unwrap()
          }

    fn set_ratecard(contents: &str) -> PathBuf {
        let mut card = tempfile::NamedTempFile::new().unwrap();
        card.write_all(contents.as_bytes()).unwrap();
        let path = card.path().to_path_buf();
        CARD_FILES
             .get_or_init(|| Mutex::new(Vec::new()))
             .lock()
             .unwrap()
             .push(card);
        std::env::set_var("RATECARD_PATH", &path);
        path
     }


    fn card() -> &'static str {
        "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
"
     }

     #[test]
    fn unset_ratecard_path_is_unavailable() {
        let _g = env_guard();
        std::env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
         };
        assert_eq!(quote(&parcel), Err(QuoteError::RateCardUnavailable));
      }

     #[test]
    fn missing_file_is_unavailable() {
        let _g = env_guard();
        std::env::set_var(
             "RATECARD_PATH",
             "/nonexistent/path/that/does/not/exist.csv",
         );
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
         };
        assert_eq!(quote(&parcel), Err(QuoteError::RateCardUnavailable));
        std::env::remove_var("RATECARD_PATH");
      }

     #[test]
    fn malformed_line_reports_its_number() {
        let _g = env_guard();
        set_ratecard("domestic\t500\tdollars\n");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
         };
        assert_eq!(
            quote(&parcel),
            Err(QuoteError::MalformedRateCard { line: 1 })
          );
        std::env::remove_var("RATECARD_PATH");
      }

     #[test]
    fn unknown_zone_is_reported() {
        let _g = env_guard();
        set_ratecard(card());
        let parcel = Parcel {
            weight_grams: 100,
            zone: "antarctic".to_string(),
         };
        assert_eq!(
            quote(&parcel),
            Err(QuoteError::UnknownZone("antarctic".into()))
         );
        std::env::remove_var("RATECARD_PATH");
      }

     #[test]
    fn overweight_is_reported_with_largest_band() {
        let _g = env_guard();
        set_ratecard(card());
        let parcel = Parcel {
            weight_grams: 99_999,
            zone: "domestic".to_string(),
         };
        assert_eq!(
            quote(&parcel),
            Err(QuoteError::Overweight {
                grams: 99_999,
                limit: 20_000
             })
          );
        std::env::remove_var("RATECARD_PATH");
      }

     #[test]
    fn domestic_low_weight_has_no_surcharge() {
        let _g = env_guard();
        set_ratecard(card());
        let parcel = Parcel {
            weight_grams: 400,
            zone: "domestic".to_string(),
         };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
        std::env::remove_var("RATECARD_PATH");
      }

     #[test]
    fn over_ten_kilograms_adds_weight_surcharge() {
        let _g = env_guard();
        set_ratecard(card());
        let parcel = Parcel {
            weight_grams: 15_000,
            zone: "domestic".to_string(),
         };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        std::env::remove_var("RATECARD_PATH");
      }

      #[test]
     fn international_rounds_surcharge_half_up() {
         let _g = env_guard();
         set_ratecard(card());
        let parcel = Parcel {
            weight_grams: 12_000,
            zone: "international".to_string(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
        std::env::remove_var("RATECARD_PATH");
     }
}
