pub mod zones;

use std::fmt;
use std::fs;
use std::path::Path;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(
                    f,
                    "parcel weighs {grams}g, above the zone limit of {limit}g"
                )
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

type ZoneBands = (String, Vec<Band>);

fn read_ratecard_from(text: &str) -> Result<Vec<ZoneBands>, QuoteError> {
    let mut zones: Vec<ZoneBands> = Vec::new();

    for (idx, raw) in text.split('\n').enumerate() {
        let line = idx + 1;
        let trimmed = raw.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = raw.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line });
        }

        let zone = fields[0].trim().to_string();
        let max_grams = match fields[1].trim().parse::<u32>() {
            Ok(n) => n,
            Err(_) => return Err(QuoteError::MalformedRateCard { line }),
        };
        let cents = match fields[2].trim().parse::<u64>() {
            Ok(n) => n,
            Err(_) => return Err(QuoteError::MalformedRateCard { line }),
        };

        let band = Band { max_grams, cents };
        if let Some(existing) = zones
            .iter_mut()
            .find(|(z, _)| *z == zone)
        {
            existing.1.push(band);
        } else {
            zones.push((zone, vec![band]));
        }
    }

    Ok(zones)
}

fn bands_for<'a>(zones: &'a [ZoneBands], zone: &str) -> Option<&'a [Band]> {
    for (z, bands) in zones {
        if z == zone {
            return Some(bands);
        }
    }
    None
}

fn round_half_up(numerator: u64, denominator: u64) -> u64 {
    (numerator + denominator / 2) / denominator
}

fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!(
        "[ratecard-diag] zone={zone} weight_grams={weight_grams} total_cents={total_cents}"
    );
}

fn quote_path(path: &Path, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let text = match fs::read_to_string(path) {
        Ok(t) => t,
        Err(_) => {
            emit_diagnostic(&parcel.zone, parcel.weight_grams, 0);
            return Err(QuoteError::RateCardUnavailable);
        }
    };

    let zones = read_ratecard_from(&text)?;
    quote_with_zones(&zones, parcel)
}

fn quote_with_zones(zones: &[ZoneBands], parcel: &Parcel) -> Result<Quote, QuoteError> {
    let band_list = match bands_for(zones, &parcel.zone) {
        Some(bands) => bands,
        None => {
            emit_diagnostic(&parcel.zone, parcel.weight_grams, 0);
            return Err(QuoteError::UnknownZone(parcel.zone.clone()));
        }
    };

    let mut sorted: Vec<&Band> = band_list.iter().collect();
    sorted.sort_by(|a, b| a.max_grams.cmp(&b.max_grams));

    let band = match sorted
        .iter()
         .find(|b| b.max_grams >= parcel.weight_grams)
    {
        Some(b) => *b,
        None => {
            let limit = sorted[sorted.len() - 1].max_grams;
            emit_diagnostic(&parcel.zone, parcel.weight_grams, 0);
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let band_max_grams = band.max_grams;

    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += round_half_up(base_cents * 20, 100);
    }

    let total_cents = base_cents + surcharge_cents;
    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = match std::env::var_os("RATECARD_PATH") {
        Some(p) => p,
        None => {
            emit_diagnostic(&parcel.zone, parcel.weight_grams, 0);
            return Err(QuoteError::RateCardUnavailable);
        }
    };
    quote_path(Path::new(&path), parcel)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    fn temp_ratecard(contents: &str) -> std::path::PathBuf {
        let mut dir = std::env::temp_dir();
        dir.push(format!("ratecard-test-{}", std::process::id()));
        fs::create_dir_all(&dir).unwrap();
        let path = dir.join(format!("card-{}.txt", nanos()));
        let mut f = fs::File::create(&path).unwrap();
        f.write_all(contents.as_bytes()).unwrap();
        path
    }

    fn nanos() -> u128 {
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    }

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn domestic_light_uses_first_band() {
        let p = temp_ratecard(CARD);
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let q = quote_path(&p, &parcel).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_mid_band() {
        let p = temp_ratecard(CARD);
        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };
        let q = quote_path(&p, &parcel).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn domestic_heavy_band_with_weight_surcharge() {
        let p = temp_ratecard(CARD);
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let q = quote_path(&p, &parcel).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn international_adds_twenty_percent_half_up() {
        let p = temp_ratecard(CARD);
        let parcel = Parcel {
            weight_grams: 400,
            zone: "international".to_string(),
        };
        let q = quote_path(&p, &parcel).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn international_heavy_adds_both_surcharges() {
        let p = temp_ratecard(CARD);
        let parcel = Parcel {
            weight_grams: 12000,
            zone: "international".to_string(),
        };
        let q = quote_path(&p, &parcel).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 500 + 1000);
        assert_eq!(q.total_cents, 6499);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn international_rounding_halves_up() {
        let card = "international\t500\t599\n";
        let p = temp_ratecard(card);
        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        };
        let q = quote_path(&p, &parcel).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 120);
        assert_eq!(q.total_cents, 719);
    }

    #[test]
    fn unknown_zone() {
        let p = temp_ratecard(CARD);
        let parcel = Parcel {
            weight_grams: 100,
            zone: "antarctic".to_string(),
        };
        let err = quote_path(&p, &parcel).unwrap_err();
        assert_eq!(
            err,
            QuoteError::UnknownZone("antarctic".to_string())
        );
    }

    #[test]
    fn overweight() {
        let p = temp_ratecard(CARD);
        let parcel = Parcel {
            weight_grams: 30000,
            zone: "domestic".to_string(),
        };
        let err = quote_path(&p, &parcel).unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 30000,
                limit: 20000
            }
        );
    }

    #[test]
    fn malformed_too_few_fields() {
        let card = "domestic\t500\n";
        let p = temp_ratecard(card);
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        assert_eq!(
            quote_path(&p, &parcel).unwrap_err(),
            QuoteError::MalformedRateCard { line: 1 }
        );
    }

    #[test]
    fn malformed_non_numeric_after_comments_and_blanks() {
        let card = "# header\n\ndomestic\tabc\t599\n";
        let p = temp_ratecard(card);
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        assert_eq!(
            quote_path(&p, &parcel).unwrap_err(),
            QuoteError::MalformedRateCard { line: 3 }
        );
    }

    #[test]
    fn ratecard_unavailable_cases() {
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        std::env::remove_var("RATECARD_PATH");
        assert_eq!(
            quote(&parcel).unwrap_err(),
            QuoteError::RateCardUnavailable
        );

        let missing =
            std::path::PathBuf::from("/nonexistent/crate-card/does-not-exist.txt");
        std::env::set_var("RATECARD_PATH", &missing);
        assert_eq!(
            quote(&parcel).unwrap_err(),
            QuoteError::RateCardUnavailable
        );

        std::env::remove_var("RATECARD_PATH");
    }
}
