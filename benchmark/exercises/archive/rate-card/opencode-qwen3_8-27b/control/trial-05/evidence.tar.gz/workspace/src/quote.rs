use std::fmt;
use std::fs;
use std::sync::{Mutex, OnceLock};

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone {zone:?}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {grams}g exceeds limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Diagnostic {
    pub zone: String,
    pub weight_grams: u32,
    pub total_cents: u64,
}

const WEIGHT_SURCHARGE_GRAMS: u32 = 10_000;
const WEIGHT_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_SURCHARGE_NUM: u64 = 20;
const INTERNATIONAL_SURCHARGE_DEN: u64 = 100;

static DIAGNOSTICS: OnceLock<Mutex<Vec<Diagnostic>>> = OnceLock::new();

fn diagnostics() -> &'static Mutex<Vec<Diagnostic>> {
    DIAGNOSTICS.get_or_init(|| Mutex::new(Vec::new()))
}

pub fn recorded_diagnostics() -> Vec<Diagnostic> {
    diagnostics().lock().unwrap().clone()
}

pub fn clear_diagnostics() {
    diagnostics().lock().unwrap().clear();
}

struct Band {
    max_grams: u32,
    cents: u64,
}

fn load_ratecard() -> Result<Vec<(String, Band)>, QuoteError> {
    let path = match std::env::var("RATECARD_PATH") {
        Ok(p) if !p.is_empty() => p,
        _ => return Err(QuoteError::RateCardUnavailable),
    };
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_ratecard(&content)
}

fn parse_ratecard(content: &str) -> Result<Vec<(String, Band)>, QuoteError> {
    let mut bands: Vec<(String, Band)> = Vec::new();
    for (i, raw) in content.lines().enumerate() {
        let line = i + 1;
        let trimmed = raw.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = raw.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line });
        }
        let zone = fields[0].trim();
        if zone.is_empty() {
            return Err(QuoteError::MalformedRateCard { line });
        }
        let max_grams: u32 = fields[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line })?;
        let cents: u64 = fields[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line })?;
        bands.push((
            zone.to_string(),
            Band {
                max_grams,
                cents,
            },
        ));
    }
    Ok(bands)
}

fn surcharge(total_base: u64, zone: &str, weight: u32) -> u64 {
    let mut surcharge = 0u64;
    if weight > WEIGHT_SURCHARGE_GRAMS {
        surcharge += WEIGHT_SURCHARGE_CENTS;
    }
    if zone == "international" {
        surcharge += round_half_up(
            total_base.saturating_mul(INTERNATIONAL_SURCHARGE_NUM),
            INTERNATIONAL_SURCHARGE_DEN,
        );
    }
    surcharge
}

fn round_half_up(numerator: u64, denominator: u64) -> u64 {
    (numerator.saturating_add(denominator / 2)) / denominator
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_ratecard()?;
    let zone = &parcel.zone;
    let weight = parcel.weight_grams;

    let mut zone_bands: Vec<&Band> = bands
        .iter()
        .filter(|(z, _)| z == zone)
        .map(|(_, b)| b)
        .collect();
    zone_bands.sort_by_key(|b| b.max_grams);

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(zone.clone()));
    }

    let band = match zone_bands.iter().find(|b| b.max_grams >= weight) {
        Some(b) => b,
        None => {
            let limit = zone_bands
                .iter()
                .map(|b| b.max_grams)
                .max()
                .unwrap();
            return Err(QuoteError::Overweight {
                grams: weight,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let surcharge_cents = surcharge(base_cents, zone, weight);
    let total_cents = base_cents + surcharge_cents;
    let band_max_grams = band.max_grams;

    emit_diagnostic(Diagnostic {
        zone: zone.clone(),
        weight_grams: weight,
        total_cents,
    });

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

fn emit_diagnostic(diagnostic: Diagnostic) {
    diagnostics()
        .lock()
        .unwrap()
        .push(diagnostic.clone());
    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        diagnostic.zone, diagnostic.weight_grams, diagnostic.total_cents
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn write_ratecard(contents: &str) -> NamedTempFile {
        let mut f = NamedTempFile::new().unwrap();
        f.write_all(contents.as_bytes()).unwrap();
        f.flush().unwrap();
        f
    }

    fn set_ratecard(contents: &str) -> NamedTempFile {
        let f = write_ratecard(contents);
        std::env::set_var("RATECARD_PATH", f.path());
        f
    }

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

     #[test]
    fn domestic_band_selection() {
        let _lock = ENV_LOCK.lock().unwrap();
        let _temp = set_ratecard(SAMPLE);
        let q = quote(&Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
         })
         .unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
     }

     #[test]
    fn domestic_heavier_band() {
        let _lock = ENV_LOCK.lock().unwrap();
        let _temp = set_ratecard(SAMPLE);
        let q = quote(&Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
         })
         .unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
     }

     #[test]
    fn weight_surcharge_applies_above_10000() {
        let _lock = ENV_LOCK.lock().unwrap();
        let _temp = set_ratecard(SAMPLE);
        let q = quote(&Parcel {
            weight_grams: 11000,
            zone: "domestic".to_string(),
         })
         .unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
     }

     #[test]
    fn weight_exactly_10000_has_no_weight_surcharge() {
        let _lock = ENV_LOCK.lock().unwrap();
        let _temp = set_ratecard(SAMPLE);
        let q = quote(&Parcel {
            weight_grams: 10000,
            zone: "domestic".to_string(),
         })
         .unwrap();
        assert_eq!(q.surcharge_cents, 0);
     }

     #[test]
    fn international_adds_twenty_percent_rounded() {
        let _lock = ENV_LOCK.lock().unwrap();
        let _temp = set_ratecard(SAMPLE);
        let q = quote(&Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
         })
         .unwrap();
        assert_eq!(q.base_cents, 1499);
         // 1499 * 20% = 299.8 -> 300
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
     }

     #[test]
    fn international_with_weight_surcharge() {
        let _lock = ENV_LOCK.lock().unwrap();
        let _temp = set_ratecard(SAMPLE);
        let q = quote(&Parcel {
            weight_grams: 12000,
            zone: "international".to_string(),
         })
         .unwrap();
        assert_eq!(q.base_cents, 4999);
         // 4999 * 20% = 999.8 -> 1000, plus 500 weight
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
     }

     #[test]
    fn unknown_zone() {
        let _lock = ENV_LOCK.lock().unwrap();
        let _temp = set_ratecard(SAMPLE);
        let e = quote(&Parcel {
            weight_grams: 100,
            zone: "antarctic".to_string(),
         }).unwrap_err();
        assert_eq!(e, QuoteError::UnknownZone("antarctic".to_string()));
     }

     #[test]
    fn overweight_when_above_largest_band() {
        let _lock = ENV_LOCK.lock().unwrap();
        let _temp = set_ratecard(SAMPLE);
        let e = quote(&Parcel {
            weight_grams: 25000,
            zone: "domestic".to_string(),
         }).unwrap_err();
        assert_eq!(
            e,
            QuoteError::Overweight {
                grams: 25000,
                limit: 20000
             }
         );
     }

     #[test]
    fn overweight_international_limit() {
        let _lock = ENV_LOCK.lock().unwrap();
        let _temp = set_ratecard(SAMPLE);
        let e = quote(&Parcel {
            weight_grams: 30000,
            zone: "international".to_string(),
         }).unwrap_err();
        assert_eq!(
            e,
            QuoteError::Overweight {
                grams: 30000,
                limit: 20000
             }
         );
     }

     #[test]
    fn missing_ratecard_path_is_unavailable() {
        let _lock = ENV_LOCK.lock().unwrap();
        std::env::remove_var("RATECARD_PATH");
        let e = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
         })
         .unwrap_err();
        assert_eq!(e, QuoteError::RateCardUnavailable);
     }

     #[test]
    fn unreadable_ratecard_path_is_unavailable() {
        let _lock = ENV_LOCK.lock().unwrap();
        std::env::set_var("RATECARD_PATH", "/nonexistent/path/does/not/exist.txt");
        let e = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
         })
         .unwrap_err();
        assert_eq!(e, QuoteError::RateCardUnavailable);
     }

     #[test]
    fn malformed_too_few_fields() {
        let _lock = ENV_LOCK.lock().unwrap();
        let _temp = set_ratecard("domestic\t500\n");
        let e = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
         })
         .unwrap_err();
        assert_eq!(e, QuoteError::MalformedRateCard { line: 1 });
     }

     #[test]
    fn malformed_bad_number_carries_line_number() {
        let _lock = ENV_LOCK.lock().unwrap();
        let _temp = set_ratecard("domestic\t500\t599\ndomestic\tabc\t899\n");
        let e = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
         })
         .unwrap_err();
        assert_eq!(e, QuoteError::MalformedRateCard { line: 2 });
     }

     #[test]
    fn malformed_line_number_counts_comments_and_blanks() {
        let _lock = ENV_LOCK.lock().unwrap();
         // line 1: comment, line 2: blank, line 3: a real band, line 4: bad number
        let text = "# header\n\ndomestic\t500\t599\ndomestic\t2000\tnope\n";
        let _temp = set_ratecard(text);
        let e = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
         })
         .unwrap_err();
        assert_eq!(e, QuoteError::MalformedRateCard { line: 4 });
     }

     #[test]
    fn diagnostic_is_emitted_per_call() {
        let _lock = ENV_LOCK.lock().unwrap();
        clear_diagnostics();
        let _temp = set_ratecard(SAMPLE);
        quote(&Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
         })
         .unwrap();
        let recs = recorded_diagnostics();
        assert_eq!(recs.len(), 1);
        assert_eq!(recs[0].zone, "domestic");
        assert_eq!(recs[0].weight_grams, 300);
        assert_eq!(recs[0].total_cents, 599);
     }

     #[test]
    fn quote_error_display_and_error() {
        let e = QuoteError::MalformedRateCard { line: 7 };
        let s = format!("{e}");
        assert!(s.contains("line 7"));
        let _ref: &dyn std::error::Error = &e;
        assert_eq!(e, QuoteError::MalformedRateCard { line: 7 });
     }
}
