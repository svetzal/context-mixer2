pub mod zones;

use std::collections::BTreeMap;
use std::fmt;
use std::fs;
use std::io::Error as IoError;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card is unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card on line {}", line)
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {}", zone)
            }
            QuoteError::Overweight { grams, limit } => {
                write!(
                    f,
                    "weight {} grams exceeds the {} gram limit",
                    grams, limit
                )
            }
        }
    }
}

impl std::error::Error for QuoteError {}

type Bands = Vec<(u32, u64)>;

struct RateCard {
    zones: BTreeMap<String, Bands>,
}

impl RateCard {
    fn from_text(text: &str) -> Result<RateCard, QuoteError> {
        let mut zones: BTreeMap<String, Bands> = BTreeMap::new();

        for (idx, raw) in text.lines().enumerate() {
            let line = idx + 1;
            let trimmed = raw.trim_end_matches(['\r']);
            if trimmed.trim().is_empty() || trimmed.trim_start().starts_with('#') {
                continue;
            }

            let fields: Vec<&str> = trimmed.split('\t').collect();
            if fields.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line });
            }

            let zone = fields[0].to_string();
            let band_max_grams = fields[1]
                .trim()
                .parse::<u32>()
                .map_err(|_| QuoteError::MalformedRateCard { line })?;
            let cents = fields[2]
                .trim()
                .parse::<u64>()
                .map_err(|_| QuoteError::MalformedRateCard { line })?;

            zones
                .entry(zone)
                .or_default()
                .push((band_max_grams, cents));
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|(max, _)| *max);
        }

        Ok(RateCard { zones })
    }

    fn load() -> Result<RateCard, QuoteError> {
        let path = match std::env::var("RATECARD_PATH") {
            Ok(p) if !p.is_empty() => p,
            _ => return Err(QuoteError::RateCardUnavailable),
        };

        let text = fs::read_to_string(&path).map_err(|_e: IoError| {
            QuoteError::RateCardUnavailable
        })?;

        RateCard::from_text(&text)
    }
}

fn round_half_up_20pct(base_cents: u64) -> u64 {
    (base_cents * 20 + 50) / 100
}

fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!(
        "quote{{zone=\"{}\",weight_grams={},total_cents={}}}",
        zone, weight_grams, total_cents
    );
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = RateCard::load()?;

    let bands = match card.zones.get(&parcel.zone) {
        Some(b) => b,
        None => {
            emit_diagnostic(&parcel.zone, parcel.weight_grams, 0);
            return Err(QuoteError::UnknownZone(parcel.zone.clone()));
        }
    };

    let match_band = bands
         .iter()
         .find(|(max, _)| *max >= parcel.weight_grams);

    let (band_max_grams, base_cents) = match match_band {
        Some((max, cents)) => (*max, *cents),
        None => {
            let limit = bands.last().unwrap().0;
            emit_diagnostic(&parcel.zone, parcel.weight_grams, 0);
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
         }
     };

    let mut surcharge_cents = 0u64;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += round_half_up_20pct(base_cents);
    }

    let total_cents = base_cents + surcharge_cents;

    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::env;
    use std::path::PathBuf;
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn test_index() -> u32 {
        use std::sync::atomic::{AtomicU32, Ordering};
        static COUNTER: AtomicU32 = AtomicU32::new(0);
        COUNTER.fetch_add(1, Ordering::Relaxed)
     }

    fn write_ratecard(text: &str) -> PathBuf {
        use std::io::Write;
        let mut path = std::env::temp_dir();
        path.push(format!(
             "ratecard_test_{}_{}.txt",
            std::process::id(),
            test_index()
         ));
        {
            let mut f = std::fs::File::create(&path).expect("create temp ratecard");
            f.write_all(text.as_bytes()).expect("write ratecard");
         }
        path
     }

    fn with_card(text: &str, body: impl FnOnce()) {
        let _guard = ENV_LOCK.lock().unwrap();
        let path = write_ratecard(text);
        env::set_var("RATECARD_PATH", &path);
        body();
        env::remove_var("RATECARD_PATH");
     }

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

      #[test]
    fn domestic_first_band() {
        with_card(CARD, || {
            let q = quote(&Parcel {
                weight_grams: 300,
                zone: "domestic".to_string(),
              })
             .unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
            assert_eq!(q.band_max_grams, 500);
          });
      }

      #[test]
    fn domestic_second_band() {
        with_card(CARD, || {
            let q = quote(&Parcel {
                weight_grams: 1500,
                zone: "domestic".to_string(),
              })
             .unwrap();
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
            assert_eq!(q.total_cents, 899);
          });
      }

      #[test]
    fn domestic_largest_band() {
        with_card(CARD, || {
            let q = quote(&Parcel {
                weight_grams: 20_000,
                zone: "domestic".to_string(),
              })
             .unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.band_max_grams, 20_000);
          });
      }

      #[test]
    fn domestic_overweight() {
        with_card(CARD, || {
            let err = quote(&Parcel {
                weight_grams: 20_001,
                zone: "domestic".to_string(),
              })
             .unwrap_err();
            match err {
                QuoteError::Overweight { grams, limit } => {
                    assert_eq!(grams, 20_001);
                    assert_eq!(limit, 20_000);
                  }
                other => panic!("expected Overweight, got {:?}", other),
              }
          });
      }

      #[test]
    fn weight_over_10kg_adds_500() {
        with_card(CARD, || {
            let q = quote(&Parcel {
                weight_grams: 15_000,
                zone: "domestic".to_string(),
              })
             .unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
            assert_eq!(q.band_max_grams, 20_000);
          });
      }

      #[test]
    fn exactly_10kg_no_surcharge() {
        with_card(CARD, || {
            let q = quote(&Parcel {
                weight_grams: 10_000,
                zone: "domestic".to_string(),
              })
             .unwrap();
            assert_eq!(q.surcharge_cents, 0);
          });
      }

      #[test]
    fn international_surcharges_combine() {
        with_card(CARD, || {
              // 15000g international -> band 20000 cent 4999; +500 overweight, +20% of 4999.
            let q = quote(&Parcel {
                weight_grams: 15_000,
                zone: "international".to_string(),
              })
             .unwrap();
              // 20% of 4999 = 999.8 -> half-up 1000
            assert_eq!(q.base_cents, 4999);
            assert_eq!(q.surcharge_cents, 500 + 1000);
            assert_eq!(q.total_cents, 4999 + 500 + 1000);
          });
      }

      #[test]
    fn international_small_no_weight_surcharge() {
        with_card(CARD, || {
            let q = quote(&Parcel {
                weight_grams: 400,
                zone: "international".to_string(),
              })
             .unwrap();
            assert_eq!(q.base_cents, 1499);
              // 20% of 1499 = 299.8 -> 300
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
          });
      }

      #[test]
    fn unknown_zone() {
        with_card(CARD, || {
            let err = quote(&Parcel {
                weight_grams: 100,
                zone: "mars".to_string(),
              })
             .unwrap_err();
            match err {
                QuoteError::UnknownZone(z) => assert_eq!(z, "mars"),
                other => panic!("expected UnknownZone, got {:?}", other),
              }
          });
      }

      #[test]
    fn unset_path_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap();
        env::remove_var("RATECARD_PATH");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
          })
          .unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
      }

      #[test]
    fn missing_file_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap();
        env::set_var("RATECARD_PATH", "/no/such/file/here.txt");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
          })
          .unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
        env::remove_var("RATECARD_PATH");
      }

      #[test]
    fn malformed_too_few_fields() {
        with_card("# z\tb\tc\ndomestic\t500\n", || {
            let err = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
              })
             .unwrap_err();
            match err {
                QuoteError::MalformedRateCard { line } => assert_eq!(line, 2),
                other => panic!("expected MalformedRateCard, got {:?}", other),
              }
          });
      }

      #[test]
    fn malformed_bad_number_line_number() {
          // comment(1), blank(2), domestic band(3), bad band(4)
        with_card("# header\n\ndomestic\t500\t599\ndomestic\t500\tnope\n", || {
            let err = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
              })
             .unwrap_err();
            match err {
                QuoteError::MalformedRateCard { line } => assert_eq!(line, 4),
                other => panic!("expected MalformedRateCard, got {:?}", other),
              }
          });
      }

      #[test]
    fn display_implementations() {
        let a = QuoteError::RateCardUnavailable.to_string();
        let b = QuoteError::MalformedRateCard { line: 3 }.to_string();
        let c = QuoteError::UnknownZone("x".to_string()).to_string();
        let d = QuoteError::Overweight { grams: 5, limit: 1 }.to_string();
        assert!(!a.is_empty() && !b.is_empty() && !c.is_empty() && !d.is_empty());
      }
 }
