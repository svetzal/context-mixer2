use std::error::Error;
use std::fmt;
use std::path::Path;

#[derive(Clone, Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "the rate card could not be located or read")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "the rate card is malformed at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds the zone's {limit}g cap")
            }
        }
    }
}

impl Error for QuoteError {}

struct Band {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = match std::env::var_os("RATECARD_PATH") {
        Some(p) if !p.is_empty() => p,
        _ => return Err(QuoteError::RateCardUnavailable),
    };

    let path = std::path::PathBuf::from(path);
    quote_with_path(parcel, path.as_path())
}

fn quote_with_path(parcel: &Parcel, path: &Path) -> Result<Quote, QuoteError> {
    let result = compute_quote(parcel, path);
    emit_diagnostic(parcel, &result);
    result
}

fn compute_quote(parcel: &Parcel, path: &Path) -> Result<Quote, QuoteError> {
    let contents =
        std::fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let bands = parse_rate_card(&contents)?;

    let mut zone_bands: Vec<&Band> = bands
        .iter()
        .filter(|b| b.zone == parcel.zone)
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.band_max_grams);

    let matched = zone_bands
         .iter()
         .find(|b| b.band_max_grams >= parcel.weight_grams);

    let (base_cents, band_max_grams) = match matched {
        Some(b) => (b.cents, b.band_max_grams),
        None => {
            let limit = zone_bands.last().unwrap().band_max_grams;
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let surcharge_cents = weight_surcharge(parcel.weight_grams) + zone_surcharge(&parcel.zone, base_cents);
    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

fn parse_rate_card(contents: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();

    for (idx, line) in contents.lines().enumerate() {
        let line_no = idx + 1;

        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }

        let band_max_grams = parts[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents = parts[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;

        bands.push(Band {
            zone: parts[0].to_string(),
            band_max_grams,
            cents,
        });
    }

    Ok(bands)
}

fn weight_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > 10_000 {
        500
    } else {
        0
    }
}

fn zone_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == "international" {
        round_half_up((base_cents as u128) * 20)
     } else {
        0
     }
}

fn round_half_up(numerator: u128) -> u64 {
    let total = (numerator + 50) / 100;
    total as u64
}

fn emit_diagnostic(parcel: &Parcel, result: &Result<Quote, QuoteError>) {
    match result {
        Ok(q) => eprintln!(
            "[ratecard] quote zone={} weight_grams={} total_cents={}",
            parcel.zone,
            parcel.weight_grams,
            q.total_cents
        ),
        Err(e) => eprintln!(
            "[ratecard] quote zone={} weight_grams={} error={}",
            parcel.zone,
            parcel.weight_grams,
            e
        ),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::NamedTempFile;

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn card() -> NamedTempFile {
        let f = NamedTempFile::new().unwrap();
        std::fs::write(f.path(), CARD).unwrap();
        f
    }

    fn quote_card(parcels: &[Parcel]) -> Result<Quote, QuoteError> {
        let f = card();
        quote_with_path(parcels.first().unwrap(), f.path())
    }

    #[test]
    fn domestic_small_parcel_uses_first_band() {
        let p = Parcel {
            weight_grams: 250,
            zone: "domestic".into(),
        };
        let got = quote_card(&[p]).unwrap();
        assert_eq!(got.base_cents, 599);
        assert_eq!(got.surcharge_cents, 0);
        assert_eq!(got.total_cents, 599);
        assert_eq!(got.band_max_grams, 500);
    }

    #[test]
    fn domestic_mid_band() {
        let p = Parcel {
            weight_grams: 1500,
            zone: "domestic".into(),
        };
        let got = quote_card(&[p]).unwrap();
        assert_eq!(got.base_cents, 899);
        assert_eq!(got.band_max_grams, 2000);
        assert_eq!(got.total_cents, 899);
    }

    #[test]
    fn domestic_weight_surcharge_only() {
        let p = Parcel {
            weight_grams: 15_000,
            zone: "domestic".into(),
        };
        let got = quote_card(&[p]).unwrap();
        assert_eq!(got.base_cents, 1799);
        assert_eq!(got.surcharge_cents, 500);
        assert_eq!(got.total_cents, 2299);
        assert_eq!(got.band_max_grams, 20_000);
    }

    #[test]
    fn international_base_and_zone_surcharge() {
        let p = Parcel {
            weight_grams: 300,
            zone: "international".into(),
        };
        let got = quote_card(&[p]).unwrap();
        assert_eq!(got.base_cents, 1499);
        assert_eq!(got.surcharge_cents, 300);
        assert_eq!(got.total_cents, 1799);
        assert_eq!(got.band_max_grams, 500);
    }

    #[test]
    fn international_heavy_parcel_both_surcharges() {
        let p = Parcel {
            weight_grams: 15_000,
            zone: "international".into(),
        };
        let got = quote_card(&[p]).unwrap();
        assert_eq!(got.base_cents, 4999);
        assert_eq!(got.surcharge_cents, 500 + 1000);
        assert_eq!(got.total_cents, 6499);
        assert_eq!(got.band_max_grams, 20_000);
    }

    #[test]
    fn unknown_zone() {
        let p = Parcel {
            weight_grams: 100,
            zone: "atlantic".into(),
        };
        let got = quote_card(&[p]);
        assert_eq!(got, Err(QuoteError::UnknownZone("atlantic".into())));
    }

    #[test]
    fn overweight_beyond_largest_band() {
        let p = Parcel {
            weight_grams: 30_000,
            zone: "domestic".into(),
        };
        let got = quote_card(&[p]);
        assert_eq!(
            got,
            Err(QuoteError::Overweight {
                grams: 30_000,
                limit: 20_000,
            })
        );
    }

    #[test]
    fn malformed_too_few_fields() {
        let bad = "domestic\t500\ninternational\t500\t1499\n";
        let f = NamedTempFile::new().unwrap();
        std::fs::write(f.path(), bad).unwrap();
        let p = Parcel {
            weight_grams: 100,
            zone: "international".into(),
        };
        let got = quote_with_path(&p, f.path());
        assert_eq!(got, Err(QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn malformed_bad_number_with_comment_line_counting() {
        let bad = "\
# header
domestic\t500\t599
domestic\t2000\tnot_a_number
international\t500\t1499
";
        let f = NamedTempFile::new().unwrap();
        std::fs::write(f.path(), bad).unwrap();
        let p = Parcel {
            weight_grams: 100,
            zone: "international".into(),
        };
        let got = quote_with_path(&p, f.path());
        assert_eq!(got, Err(QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn empty_and_comment_lines_are_ignored() {
        let good = "\
# only a comment

domestic\t500\t599
";
        let f = NamedTempFile::new().unwrap();
        std::fs::write(f.path(), good).unwrap();
        let p = Parcel {
            weight_grams: 250,
            zone: "domestic".into(),
        };
        let got = quote_with_path(&p, f.path()).unwrap();
        assert_eq!(got.base_cents, 599);
        assert_eq!(got.total_cents, 599);
    }

    #[test]
    fn missing_file_is_unavailable() {
        let p = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        let got = quote_with_path(&p, Path::new("/nonexistent/ratecard/that/does/not/exist"));
        assert_eq!(got, Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn public_quote_reads_env_var_and_unset_is_unavailable() {
        let f = card();
        let path = f.path().to_str().unwrap().to_string();
        let previous = std::env::var_os("RATECARD_PATH");
        std::env::set_var("RATECARD_PATH", &path);

        let p = Parcel {
            weight_grams: 250,
            zone: "domestic".into(),
        };
        let got = quote(&p);
        assert_eq!(got.unwrap().total_cents, 599);

        let _ = std::env::remove_var("RATECARD_PATH");
        let got_unset = quote(&p);
        assert_eq!(got_unset, Err(QuoteError::RateCardUnavailable));

        if let Some(prev) = previous {
            std::env::set_var("RATECARD_PATH", prev);
        }
    }

    #[test]
    fn half_up_rounding_for_zone_surcharge() {
        let good = "international\t500\t625\n";
        let f = NamedTempFile::new().unwrap();
        std::fs::write(f.path(), good).unwrap();
        let p = Parcel {
            weight_grams: 100,
            zone: "international".into(),
         };
        let got = quote_with_path(&p, f.path()).unwrap();
         // 625 * 20% = 125.0; half-up keeps it 125
        assert_eq!(got.surcharge_cents, 125);
        assert_eq!(got.total_cents, 750);
     }
}
