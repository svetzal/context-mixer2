pub mod zones;

use std::collections::BTreeMap;
use std::fs;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(
                    f,
                    "parcel over the {limit} gram limit for the zone ({grams} g)"
                )
            }
        }
    }
}

impl std::error::Error for QuoteError {}

const WEIGHT_SURCHARGE_THRESHOLD: u32 = 10_000;
const WEIGHT_SURCHARGE_CENTS: u64 = 500;

// one band per zone, ascending by threshold
type RateCard = BTreeMap<String, Vec<(u32, u64)>>;

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| {
        emit(&parcel.zone, parcel.weight_grams, 0);
        QuoteError::RateCardUnavailable
    })?;

    let contents = match fs::read_to_string(&path) {
        Ok(contents) => contents,
        Err(_) => {
            emit(&parcel.zone, parcel.weight_grams, 0);
            return Err(QuoteError::RateCardUnavailable);
        }
    };

    let card = match parse_rate_card(&contents) {
        Ok(card) => card,
        Err(err) => {
            emit(&parcel.zone, parcel.weight_grams, 0);
            return Err(err);
        }
    };

    let bands = match card.get(&parcel.zone) {
        Some(bands) => bands,
        None => {
            emit(&parcel.zone, parcel.weight_grams, 0);
            return Err(QuoteError::UnknownZone(parcel.zone.clone()));
        }
    };

    let band = match bands.iter().find(|(max, _)| *max >= parcel.weight_grams) {
        Some(band) => band,
        None => {
            let limit = bands.last().map(|(max, _)| *max).unwrap_or(0);
            emit(&parcel.zone, parcel.weight_grams, 0);
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.1;
    let band_max_grams = band.0;

    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > WEIGHT_SURCHARGE_THRESHOLD {
        surcharge_cents += WEIGHT_SURCHARGE_CENTS;
    }
    if parcel.zone == "international" {
        // 20% of base, rounded half up to the cent: floor((base*2 + 5)/10).
        surcharge_cents += (base_cents * 2 + 5) / 10;
    }

    let total_cents = base_cents + surcharge_cents;
    emit(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

fn emit(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!("quote zone={zone} weight_grams={weight_grams} total_cents={total_cents}");
}

fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut card: RateCard = BTreeMap::new();

    for (idx, raw_line) in contents.lines().enumerate() {
        let line = idx + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = raw_line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line });
        }

        let band_max = fields[1]
            .trim()
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line })?;
        let cents = fields[2]
            .trim()
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line })?;

        card.entry(fields[0].trim().to_string())
            .or_default()
            .push((band_max, cents));
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|(max, _)| *max);
    }

    Ok(card)
}

#[cfg(test)]
mod tests;
