use super::*;
use std::sync::Mutex;

// All tests that depend on RATECARD_PATH share this lock so the global
// environment variable is only ever set/read by one test at a time.
static ENV_LOCK: Mutex<()> = Mutex::new(());

// A test panicking while holding ENV_LOCK poisons it; recover rather than let
// the poison cascade into every other test.
fn env_guard() -> std::sync::MutexGuard<'static, ()> {
    ENV_LOCK
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
}

/// write the rate card, point RATECARD_PATH at it, run `body`, and restore the
/// previous env state. The ENV_LOCK guard is held across `body` so no other
/// test can touch the env var concurrently.
fn with_ratecard<F>(contents: &str, body: F)
where
    F: FnOnce() + Send,
{
    let _env_guard = env_guard();
    let tmp = tempfile::tempdir().unwrap();
    let path = tmp.path().join("ratecard.tsv");
    std::fs::write(&path, contents).unwrap();
    let previous = std::env::var("RATECARD_PATH").ok();
    std::env::set_var("RATECARD_PATH", path.to_str().unwrap());
    body();
    match previous {
        Some(prev) => std::env::set_var("RATECARD_PATH", prev),
        None => std::env::remove_var("RATECARD_PATH"),
    }
    let _ = std::fs::remove_file(&path);
}

const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_string(),
    }
}

#[test]
fn domestic_low_band() {
    with_ratecard(CARD, || {
        let q = quote(&parcel(250, "domestic")).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    });
}

#[test]
fn domestic_mid_band() {
    with_ratecard(CARD, || {
        let q = quote(&parcel(1500, "domestic")).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
        assert_eq!(q.total_cents, 899);
    });
}

#[test]
fn domestic_high_band() {
    with_ratecard(CARD, || {
        let q = quote(&parcel(12000, "domestic")).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.band_max_grams, 20000);
        // 12000 > 10000 -> +500 weight surcharge; not international.
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    });
}

#[test]
fn weight_at_threshold_gets_no_weight_surcharge() {
    with_ratecard(CARD, || {
        let q = quote(&parcel(10000, "domestic")).unwrap();
        // 10000 g is not strictly above 10000, so no weight surcharge.
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, q.base_cents);
    });
}

#[test]
fn exactly_one_gram_over_threshold_gets_weight_surcharge() {
    with_ratecard(CARD, || {
        let q = quote(&parcel(10001, "domestic")).unwrap();
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, q.base_cents + 500);
    });
}

#[test]
fn international_rounds_half_up() {
    with_ratecard(CARD, || {
        // base 1499 -> 20% = 299.8 -> 300 (half-up to the cent).
        let q = quote(&parcel(250, "international")).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    });
}

#[test]
fn international_high_band_with_weight_surcharge() {
    with_ratecard(CARD, || {
        // base 4999 -> 20% = 999.8 -> 1000; weight 15000 > 10000 -> +500.
        let q = quote(&parcel(15000, "international")).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1000 + 500);
        assert_eq!(q.total_cents, 4999 + 1500);
        assert_eq!(q.band_max_grams, 20000);
    });
}

#[test]
fn unknown_zone() {
    with_ratecard(CARD, || {
        let err = quote(&parcel(100, "antarctica")).unwrap_err();
        match err {
            QuoteError::UnknownZone(zone) => assert_eq!(zone, "antarctica"),
            other => panic!("expected UnknownZone, got {other:?}"),
        }
    });
}

#[test]
fn overweight_uses_largest_band_limit() {
    with_ratecard(CARD, || {
        let err = quote(&parcel(40000, "domestic")).unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 40000);
                assert_eq!(limit, 20000);
            }
            other => panic!("expected Overweight, got {other:?}"),
        }
    });
}

#[test]
fn rate_card_unavailable_when_path_unset() {
    let _env_guard = env_guard();
    let previous = std::env::var("RATECARD_PATH").ok();
    std::env::remove_var("RATECARD_PATH");
    let err = quote(&parcel(100, "domestic")).unwrap_err();
    assert!(matches!(err, QuoteError::RateCardUnavailable));
    match previous {
        Some(prev) => std::env::set_var("RATECARD_PATH", prev),
        None => {}
    }
}

#[test]
fn rate_card_unavailable_when_file_missing() {
    let _env_guard = env_guard();
    let tmp = tempfile::tempdir().unwrap();
    let missing = tmp.path().join("does-not-exist.tsv");
    let previous = std::env::var("RATECARD_PATH").ok();
    std::env::set_var("RATECARD_PATH", missing.to_str().unwrap());
    let err = quote(&parcel(100, "domestic")).unwrap_err();
    assert!(matches!(err, QuoteError::RateCardUnavailable));
    match previous {
        Some(prev) => std::env::set_var("RATECARD_PATH", prev),
        None => std::env::remove_var("RATECARD_PATH"),
    }
}

#[test]
fn malformed_line_not_three_fields_reports_line_number() {
    // blank + comment lines count toward the 1-based line number.
    let card = "\
# header comment
# second comment
domestic\t500\t599
domestic
international\t500\t1499
";
    with_ratecard(card, || {
        let err = quote(&parcel(100, "domestic")).unwrap_err();
        assert!(
            matches!(err, QuoteError::MalformedRateCard { line: 4 }),
            "{err:?}"
        );
    });
}

#[test]
fn malformed_line_bad_number_reports_line_number() {
    let card = "domestic\t500\t599\ndomestic\tnot-a-number\t899\n";
    with_ratecard(card, || {
        let err = quote(&parcel(100, "domestic")).unwrap_err();
        assert!(
            matches!(err, QuoteError::MalformedRateCard { line: 2 }),
            "{err:?}"
        );
    });
}

#[test]
fn comments_and_blanks_are_ignored() {
    let card = "\
# comment line

domestic\t500\t599

# another comment
international\t500\t1499
";
    with_ratecard(card, || {
        let q = quote(&parcel(200, "domestic")).unwrap();
        assert_eq!(q.base_cents, 599);
    });
}

#[test]
fn quote_error_displays() {
    let msgs: Vec<String> = [
        QuoteError::RateCardUnavailable,
        QuoteError::MalformedRateCard { line: 7 },
        QuoteError::UnknownZone("mars".to_string()),
        QuoteError::Overweight {
            grams: 99,
            limit: 50,
        },
    ]
    .iter()
    .map(|e| e.to_string())
    .collect();
    assert!(!msgs.iter().any(|m| m.is_empty()));
    assert!(format!("{}", QuoteError::UnknownZone("x".to_string())).contains("x"));
}
