use std::collections::HashMap;

mod zones;

#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone {zone:?}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {grams}g exceeds limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

struct RateCard {
    zones: HashMap<String, Vec<Band>>,
}

const WEIGHT_SURCHARGE_GRAMS: u32 = 10000;
const WEIGHT_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = load_rate_card()?;
    quote_from_card(parcel, card)
}

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = std::fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn quote_from_card(parcel: &Parcel, card: RateCard) -> Result<Quote, QuoteError> {
    let bands = match card.zones.get(&parcel.zone) {
        Some(bands) => bands,
        None => return Err(QuoteError::UnknownZone(parcel.zone.clone())),
    };

    let band = match bands.iter().find(|b| b.max_grams >= parcel.weight_grams) {
        Some(band) => band,
        None => {
            let limit = bands.iter().map(|b| b.max_grams).max().expect("non-empty band set");
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > WEIGHT_SURCHARGE_GRAMS {
        surcharge_cents = surcharge_cents.saturating_add(WEIGHT_SURCHARGE_CENTS);
    }

    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge_cents = surcharge_cents
            .saturating_add(international_surcharge(base_cents));
    }

    let total_cents = base_cents.saturating_add(surcharge_cents);

    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn international_surcharge(base_cents: u64) -> u64 {
    (base_cents.saturating_mul(20).saturating_add(50)) / 100
}

fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut card = RateCard {
        zones: HashMap::new(),
    };

    for (i, line) in contents.lines().enumerate() {
        let line_no = i + 1;

        if line.trim().is_empty() {
            continue;
        }
        if line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }

        let zone = fields[0].to_string();
        let max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;

        card.zones
            .entry(zone)
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in card.zones.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(card)
}

fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!(
        "quote: zone={zone} weight_grams={weight_grams} total_cents={total_cents}"
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn quote_contents(parcel: &Parcel, contents: &str) -> Result<Quote, QuoteError> {
        let card = parse_rate_card(contents)?;
        quote_from_card(parcel, card)
    }

    fn parcel(zone: &str, grams: u32) -> Parcel {
        Parcel {
            weight_grams: grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn domestic_light_uses_small_band_no_surcharge() {
        let q = quote_contents(&parcel("domestic", 300), CARD).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_mid_weight_uses_mid_band() {
        let q = quote_contents(&parcel("domestic", 1500), CARD).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
        assert_eq!(q.total_cents, 899);
    }

    #[test]
    fn domestic_heavy_uses_top_band_with_weight_surcharge() {
        let q = quote_contents(&parcel("domestic", 15000), CARD).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn international_light_adds_rounded_up_surcharge() {
        let q = quote_contents(&parcel("international", 300), CARD).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn international_heavy_combines_both_surcharges() {
        let q = quote_contents(&parcel("international", 15000), CARD).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 500 + 1000);
        assert_eq!(q.total_cents, 4999 + 500 + 1000);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn international_surcharge_rounds_half_up() {
        assert_eq!(international_surcharge(599), 120);
        assert_eq!(international_surcharge(899), 180);
        assert_eq!(international_surcharge(4999), 1000);
        assert_eq!(international_surcharge(0), 0);
        assert_eq!(international_surcharge(1), 0);
    }

    #[test]
    fn unknown_zone_reports_requested_zone() {
        let err = quote_contents(&parcel("eu", 300), CARD).unwrap_err();
        match err {
            QuoteError::UnknownZone(zone) => assert_eq!(zone, "eu"),
            other => panic!("expected UnknownZone, got {other:?}"),
        }
    }

    #[test]
    fn overweight_reports_largest_band_limit() {
        let err = quote_contents(&parcel("domestic", 25000), CARD).unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 25000);
                assert_eq!(limit, 20000);
            }
            other => panic!("expected Overweight, got {other:?}"),
        }
    }

    #[test]
    fn malformed_line_reports_correct_number() {
        let contents = "
# comment

domestic\t500\t599
domestic\tbad\t599
";
        let err = quote_contents(&parcel("domestic", 300), contents).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 5),
            other => panic!("expected MalformedRateCard, got {other:?}"),
        }
    }

    #[test]
    fn malformed_line_wrong_field_count() {
        let contents = "
domestic\t500
";
        let err = quote_contents(&parcel("domestic", 300), contents).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 2),
            other => panic!("expected MalformedRateCard, got {other:?}"),
        }
    }

    #[test]
    fn bands_sort_by_max_grams() {
        let contents = "
domestic\t20000\t9999
domestic\t500\t11
";
        let q = quote_contents(&parcel("domestic", 600), contents).unwrap();
        assert_eq!(q.band_max_grams, 20000);
        assert_eq!(q.base_cents, 9999);
    }

    #[test]
    fn exact_band_max_inclusive() {
        let q = quote_contents(&parcel("domestic", 500), CARD).unwrap();
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn display_and_error_impl() {
        let e1 = format!("{:?}", QuoteError::MalformedRateCard { line: 3 });
        let e2 = format!("{}", QuoteError::MalformedRateCard { line: 3 });
        assert!(e2.contains("3"));
        let _ = e1;
        fn assert_error<E: std::error::Error>() {}
        assert_error::<QuoteError>();
    }

    #[test]
    fn public_quote_reads_env_path() {
        let _guard = ENV_LOCK.lock().unwrap();
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("ratecard.tsv");
        std::fs::write(&path, CARD).unwrap();

        std::env::set_var("RATECARD_PATH", &path);
        let q = quote(&parcel("domestic", 1500)).unwrap();
        assert_eq!(q.total_cents, 899);

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn public_quote_unavailable_when_unset() {
        let _guard = ENV_LOCK.lock().unwrap();
        std::env::remove_var("RATECARD_PATH");
        let err = quote(&parcel("domestic", 300)).unwrap_err();
        match err {
            QuoteError::RateCardUnavailable => {}
            other => panic!("expected RateCardUnavailable, got {other:?}"),
        }
    }

    #[test]
    fn public_quote_unavailable_when_path_missing() {
        let _guard = ENV_LOCK.lock().unwrap();
        std::env::set_var(
            "RATECARD_PATH",
            "/no/such/ratecard/path/definitely/does/not/exist.tsv",
        );
        let err = quote(&parcel("domestic", 300)).unwrap_err();
        match err {
            QuoteError::RateCardUnavailable => {}
            other => panic!("expected RateCardUnavailable, got {other:?}"),
        }
        std::env::remove_var("RATECARD_PATH");
    }
}
