use std::collections::HashMap;
use std::sync::Mutex;

pub mod zones;

/// A parcel to be priced.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A computed shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Errors that can arise while producing a quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// One priced band for a zone: (threshold_grams, cents).
type Band = (u32, u64);

/// A diagnostic record emitted for every successful quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Diagnostic {
    pub zone: String,
    pub weight_grams: u32,
    pub total_cents: u64,
}

static DIAGNOSTICS: Mutex<Vec<Diagnostic>> = Mutex::new(Vec::new());

/// Compute a quote for `parcel`, reading the rate card from `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = match std::env::var("RATECARD_PATH") {
        Ok(p) => p,
        Err(_) => return Err(QuoteError::RateCardUnavailable),
    };

    let content = match std::fs::read_to_string(&path) {
        Ok(c) => c,
        Err(_) => return Err(QuoteError::RateCardUnavailable),
    };

    let card = parse_ratecard(&content)?;

    let bands = match card.zones.get(&parcel.zone) {
        Some(b) => b,
        None => return Err(QuoteError::UnknownZone(parcel.zone.clone())),
    };

    let mut sorted: Vec<Band> = bands.clone();
    sorted.sort_by_key(|(g, _)| *g);

    let (base, band_max) = match sorted.iter().find(|(g, _)| *g >= parcel.weight_grams) {
        Some((g, c)) => (*c, *g),
        None => {
            let limit = sorted.last().map(|(g, _)| *g).unwrap_or(0);
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let mut surcharge: u64 = 0;
    if parcel.weight_grams > 10000 {
        surcharge += 500;
    }
    if parcel.zone == "international" {
        // 20% of base, rounded half-up to the cent: round(base/5)
        // = floor((2*base + 5) / 10).
        surcharge += (2 * base + 5) / 10;
    }

    let total = base + surcharge;
    let quote_val = Quote {
        base_cents: base,
        surcharge_cents: surcharge,
        total_cents: total,
        band_max_grams: band_max,
    };

    emit_diagnostic(&parcel.zone, parcel.weight_grams, total);
    Ok(quote_val)
}

/// Parse a tab-separated rate card into per-zone band lists.
fn parse_ratecard(content: &str) -> Result<RateCard, QuoteError> {
    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();
    for (i, raw) in content.lines().enumerate() {
        let line = i + 1;
        let t = raw.trim();
        if t.is_empty() || t.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = t.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line });
        }
        let zone = fields[0];
        let max_grams = fields[1].parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line })?;
        let cents = fields[2].parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line })?;
        zones.entry(zone.to_string()).or_default().push((max_grams, cents));
    }
    Ok(RateCard { zones })
}

struct RateCard {
    zones: HashMap<String, Vec<Band>>,
}

fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    let d = Diagnostic {
        zone: zone.to_string(),
        weight_grams,
        total_cents,
    };
    if let Ok(mut guard) = DIAGNOSTICS.lock() {
        guard.push(d);
    }
    eprintln!(
        "ratecard quote zone={zone} weight_grams={weight_grams} total_cents={total_cents}"
    );
}

/// Return every diagnostic recorded since the last [`clear_diagnostics`].
pub fn diagnostics() -> Vec<Diagnostic> {
    DIAGNOSTICS.lock().map(|g| g.clone()).unwrap_or_default()
}

/// Drop all recorded diagnostics.
pub fn clear_diagnostics() {
    if let Ok(mut guard) = DIAGNOSTICS.lock() {
        guard.clear();
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    // Serialize env-mutating tests: RATECARD_PATH is process-global.
    static TEST_LOCK: Mutex<()> = Mutex::new(());

    fn set_ratecard(content: &str) -> tempfile::NamedTempFile {
        let mut file = tempfile::NamedTempFile::new().expect("create temp rate card");
        file.write_all(content.as_bytes()).expect("write rate card");
        std::env::set_var("RATECARD_PATH", file.path());
        file
    }

    const CARD: &str = "# zone\tband_max_grams\tcents\
        \ndomestic\t500\t599\
        \ndomestic\t2000\t899\
        \ndomestic\t20000\t1799\
        \ninternational\t500\t1499\
        \ninternational\t20000\t4999\
        \n";

    #[test]
    fn domestic_lightest_band() {
        let _g = TEST_LOCK.lock().unwrap();
        let _f = set_ratecard(CARD);
        let q = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
    }

    #[test]
    fn domestic_mid_band() {
        let _g = TEST_LOCK.lock().unwrap();
        let _f = set_ratecard(CARD);
        let q = quote(&Parcel {
            weight_grams: 1200,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 899);
    }

    #[test]
    fn domestic_top_band() {
        let _g = TEST_LOCK.lock().unwrap();
        let _f = set_ratecard(CARD);
        let q = quote(&Parcel {
            weight_grams: 15000,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn weight_at_10000_has_no_weight_surcharge() {
        let _g = TEST_LOCK.lock().unwrap();
        let _f = set_ratecard(CARD);
        let q = quote(&Parcel {
            weight_grams: 10000,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn weight_over_10000_adds_500() {
        let _g = TEST_LOCK.lock().unwrap();
        let _f = set_ratecard(CARD);
        let q = quote(&Parcel {
            weight_grams: 10001,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn international_light_surcharge_only() {
        let _g = TEST_LOCK.lock().unwrap();
        let _f = set_ratecard(CARD);
        let q = quote(&Parcel {
            weight_grams: 500,
            zone: "international".into(),
        })
        .unwrap();
        // 20% of 1499 = 299.8 -> 300, rounded half-up.
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_overweight_combines_surcharges() {
        let _g = TEST_LOCK.lock().unwrap();
        let _f = set_ratecard(CARD);
        let q = quote(&Parcel {
            weight_grams: 12000,
            zone: "international".into(),
        })
        .unwrap();
        // base 4999; +500 (over 10000g); +20% of 4999 = 999.8 -> 1000.
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn unknown_zone() {
        let _g = TEST_LOCK.lock().unwrap();
        let _f = set_ratecard(CARD);
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "antarctic".into(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("antarctic".to_string()));
    }

    #[test]
    fn overweight_error() {
        let _g = TEST_LOCK.lock().unwrap();
        let _f = set_ratecard(CARD);
        let err = quote(&Parcel {
            weight_grams: 30000,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 30000,
                limit: 20000
            }
        );
    }

    #[test]
    fn rate_card_unavailable_when_unset() {
        let _g = TEST_LOCK.lock().unwrap();
        std::env::remove_var("RATECARD_PATH");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn rate_card_unavailable_missing_file() {
        let _g = TEST_LOCK.lock().unwrap();
        std::env::set_var("RATECARD_PATH", "/no/such/rate-card/path");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn malformed_wrong_field_count() {
        let _g = TEST_LOCK.lock().unwrap();
        let content = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\nbadline\n";
        let _f = set_ratecard(content);
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        // line 1 comment, line 2 valid, line 3 malformed.
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn malformed_non_numeric_field() {
        let _g = TEST_LOCK.lock().unwrap();
        let content = "domestic\tabc\t599\n";
        let _f = set_ratecard(content);
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn malformed_extra_field() {
        let _g = TEST_LOCK.lock().unwrap();
        let content = "domestic\t500\t599\textra\n";
        let _f = set_ratecard(content);
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn diagnostics_recorded_per_call() {
        let _g = TEST_LOCK.lock().unwrap();
        let _f = set_ratecard(CARD);
        clear_diagnostics();
        let _ = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".into(),
        })
        .unwrap();
        let diags = diagnostics();
        assert_eq!(diags.len(), 1);
        assert_eq!(diags[0].zone, "domestic".to_string());
        assert_eq!(diags[0].weight_grams, 500);
        assert_eq!(diags[0].total_cents, 599);
        clear_diagnostics();
    }

    #[test]
    fn quote_error_display_and_error_trait() {
        let e1 = QuoteError::MalformedRateCard { line: 7 };
        assert_eq!(e1.to_string(), "malformed rate card at line 7");
        let e2 = QuoteError::Overweight {
            grams: 30000,
            limit: 20000,
        };
        assert_eq!(
            e2.to_string(),
            "parcel 30000g exceeds zone limit 20000g"
        );
        let e3 = QuoteError::UnknownZone("x".to_string());
        assert_eq!(e3.to_string(), "unknown zone: x");
        // Ensure it satisfies std::error::Error.
        let _as_box: &dyn std::error::Error = &e1;
    }
}
