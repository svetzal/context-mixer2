pub mod zones;

use std::collections::BTreeMap;
use std::fmt;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                f.write_str("rate card unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(
                    f,
                     "parcel overweight: {grams}g exceeds limit of {limit}g"
                 )
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

type ZoneBands = BTreeMap<String, Vec<Band>>;

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let cards = load_rate_card()?;

    let bands = match cards.get(&parcel.zone) {
        Some(bands) => bands,
        None => return Err(QuoteError::UnknownZone(parcel.zone.clone())),
    };

    let mut sorted: Vec<&Band> = bands.iter().collect();
    sorted.sort_by_key(|b| b.max_grams);

    let band = sorted
         .iter()
         .map(|b| **b)
         .find(|b| b.max_grams >= parcel.weight_grams)
         .ok_or_else(|| {
            let limit = sorted.last().map(|b| b.max_grams).unwrap_or(0);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
             }
         })?;

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        surcharge_cents += round_half_up_20_percent(base_cents);
    }

    let total_cents = base_cents + surcharge_cents;

    record_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn round_half_up_20_percent(base_cents: u64) -> u64 {
    let raw = (base_cents as u128) * 20;
    let rounded = (raw + 50) / 100;
    rounded as u64
}

fn load_rate_card() -> Result<ZoneBands, QuoteError> {
    let path = match std::env::var("RATECARD_PATH") {
        Ok(path) if !path.is_empty() => path,
        _ => return Err(QuoteError::RateCardUnavailable),
    };

    let content = match std::fs::read_to_string(&path) {
        Ok(content) => content,
        Err(_) => return Err(QuoteError::RateCardUnavailable),
    };

    parse_rate_card(&content)
}

fn parse_rate_card(content: &str) -> Result<ZoneBands, QuoteError> {
    let mut cards: ZoneBands = BTreeMap::new();

    for (i, raw) in content.lines().enumerate() {
        let line = i + 1;
        let trimmed = raw.trim();

        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = raw.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line });
        }

        let zone = parts[0].to_string();
        let max_grams = match parts[1].trim().parse::<u32>() {
            Ok(v) => v,
            Err(_) => return Err(QuoteError::MalformedRateCard { line }),
        };
        let cents = match parts[2].trim().parse::<u64>() {
            Ok(v) => v,
            Err(_) => return Err(QuoteError::MalformedRateCard { line }),
        };

        cards
            .entry(zone)
            .or_default()
            .push(Band {
                max_grams,
                cents,
            });
    }

    Ok(cards)
}

fn record_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!(
        "ratecard.diagnostic zone={zone} weight_grams={weight_grams} total_cents={total_cents}"
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn lock_env() -> std::sync::MutexGuard<'static, ()> {
        ENV_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner())
    }

    fn write_card(content: &str) -> (tempfile::NamedTempFile, String) {
        let mut f = tempfile::NamedTempFile::new().unwrap();
        f.write_all(content.as_bytes()).unwrap();
        let path = f.path().to_str().unwrap().to_string();
        (f, path)
     }

    fn set_path(path: &str) {
        std::env::set_var("RATECARD_PATH", path);
    }

    fn clear_path() {
        std::env::remove_var("RATECARD_PATH");
    }

    const CARD: &str = r#"# zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
domestic	20000	1799
international	500	1499
international	20000	4999
"#;

    #[test]
    fn rate_card_unavailable_when_unset() {
        let _lock = lock_env();
        clear_path();
        let r = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        });
        assert_eq!(r, Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn rate_card_unavailable_when_missing() {
        let _lock = lock_env();
        let (_f, _path) = write_card(CARD);
        let missing = format!("{}/nope.txt", std::env::temp_dir().display());
        set_path(&missing);
        let r = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        });
        assert_eq!(r, Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn domestic_band_selection() {
        let _lock = lock_env();
        let (_f, path) = write_card(CARD);
        set_path(&path);

        let q = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);

        let q = quote(&Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn weight_surcharge_over_10kg() {
        let _lock = lock_env();
        let (_f, path) = write_card(CARD);
        set_path(&path);

        let q = quote(&Parcel {
            weight_grams: 15_000,
            zone: "domestic".to_string(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn weight_exactly_10kg_has_no_weight_surcharge() {
        let _lock = lock_env();
        let (_f, path) = write_card(CARD);
        set_path(&path);

        let q = quote(&Parcel {
            weight_grams: 10_000,
            zone: "domestic".to_string(),
        })
        .unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn international_surcharge_rounds_half_up() {
        let _lock = lock_env();
        let (_f, path) = write_card(CARD);
        set_path(&path);

        let q = quote(&Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);

        let q = quote(&Parcel {
            weight_grams: 12_000,
            zone: "international".to_string(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1000 + 500);
        assert_eq!(q.total_cents, 4999 + 1500);
    }

    #[test]
    fn unknown_zone() {
        let _lock = lock_env();
        let (_f, path) = write_card(CARD);
        set_path(&path);
        let r = quote(&Parcel {
            weight_grams: 100,
            zone: "antarctic".to_string(),
        });
        assert_eq!(
            r,
            Err(QuoteError::UnknownZone("antarctic".to_string()))
        );
    }

    #[test]
    fn overweight_over_largest_band() {
        let _lock = lock_env();
        let (_f, path) = write_card(CARD);
        set_path(&path);
        let r = quote(&Parcel {
            weight_grams: 50_000,
            zone: "domestic".to_string(),
        });
        assert_eq!(
            r,
            Err(QuoteError::Overweight {
                grams: 50_000,
                limit: 20_000
            })
        );
    }

    #[test]
    fn malformed_line_wrong_field_count() {
        let _lock = lock_env();
        let (_f, path) = write_card("domestic\t500\n");
        set_path(&path);
        let r = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        });
        assert_eq!(r, Err(QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn malformed_line_unparseable_number() {
        let _lock = lock_env();
        let (_f, path) = write_card("domestic\tnot_a_number\t599\n");
        set_path(&path);
        let r = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        });
        assert_eq!(r, Err(QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn malformed_line_number_counts_comments_and_blanks() {
        let _lock = lock_env();
        let bad = "# comment\n\ndomestic\t500\txn\n";
        let (_f, path) = write_card(bad);
        set_path(&path);
        let r = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        });
        assert_eq!(r, Err(QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn comments_and_blanks_ignored() {
        let _lock = lock_env();
        let card = "# a comment\n\n# another\n\n";
        let (_f, path) = write_card(card);
        set_path(&path);
        let r = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        });
        assert_eq!(
            r,
            Err(QuoteError::UnknownZone("domestic".to_string()))
        );
    }

    #[test]
    fn display_and_error_impl() {
        let e = QuoteError::MalformedRateCard { line: 4 };
        assert_eq!(e.to_string(), "malformed rate card at line 4");
        let _ref: &dyn std::error::Error = &QuoteError::Overweight {
            grams: 1,
            limit: 2,
        };
    }
}
