use std::collections::BTreeMap;
use std::fmt;
use std::fs::File;
use std::io::{BufRead, BufReader};
use std::path::Path;

pub mod zones;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card is unavailable (RATECARD_PATH unset, missing, or unreadable)")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel overweight: {grams}g exceeds zone limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    band_max_grams: u32,
    cents: u64,
}

type RateCard = BTreeMap<String, Vec<Band>>;

fn read_rate_card() -> Result<RateCard, QuoteError> {
    let path =
        std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    if path.trim().is_empty() {
        return Err(QuoteError::RateCardUnavailable);
    }

    let file = File::open(Path::new(&path)).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);

    let mut card: RateCard = BTreeMap::new();

    for (i, line) in reader.lines().enumerate() {
        let line = line.map_err(|_| QuoteError::RateCardUnavailable)?;
        let line_number = i + 1;

        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let band_max = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        card
            .entry(fields[0].to_string())
            .or_default()
            .push(Band {
                band_max_grams: band_max,
                cents,
            });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|b| b.band_max_grams);
    }

    Ok(card)
}

fn half_up_numerator_over_denominator(numerator: u64, denominator: u64) -> u64 {
    let (quotient, remainder) = (numerator / denominator, numerator % denominator);
    if remainder * 2 >= denominator {
        quotient + 1
    } else {
        quotient
    }
}

fn international_surcharge(base_cents: u64) -> u64 {
    half_up_numerator_over_denominator(base_cents * 20, 100)
}

fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!(
        "quote zone=\"{zone}\" weight_grams={weight_grams} total_cents={total_cents}"
    );
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = read_rate_card()?;

    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams);

    let band = match band {
        Some(b) => b,
        None => {
            let limit = bands.last().map(|b| b.band_max_grams).unwrap_or(0);
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        surcharge_cents += international_surcharge(base_cents);
    }

    let total_cents = base_cents + surcharge_cents;

    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn with_rate_card<F>(content: &str, f: F)
    where
        F: FnOnce() -> (),
    {
        let dir = tempfile::TempDir::new().expect("temp dir");
        let path = dir.path().join("ratecard.tsv");
        fs::write(&path, content).expect("write card");
        let path_str = path.to_str().expect("utf8 path").to_string();
        let _guard = ENV_LOCK.lock().expect("env lock poisoned");
        std::env::set_var("RATECARD_PATH", &path_str);
        f();
        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn domestic_small_band() {
        with_rate_card(CARD, || {
            let p = Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            };
            let q = quote(&p).expect("quote");
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_band_boundary_inclusive() {
        with_rate_card(CARD, || {
            let p = Parcel {
                weight_grams: 2000,
                zone: "domestic".to_string(),
            };
            let q = quote(&p).expect("quote");
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
        });
    }

     #[test]
    fn domestic_large_band() {
        with_rate_card(CARD, || {
            let p = Parcel {
                weight_grams: 9_000,
                zone: "domestic".to_string(),
             };
            let q = quote(&p).expect("quote");
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.band_max_grams, 20000);
         });
     }

    #[test]
    fn overweight_above_largest_band() {
        with_rate_card(CARD, || {
            let p = Parcel {
                weight_grams: 30_000,
                zone: "domestic".to_string(),
            };
            match quote(&p) {
                Err(QuoteError::Overweight { grams, limit }) => {
                    assert_eq!(grams, 30_000);
                    assert_eq!(limit, 20_000);
                }
                other => panic!("expected Overweight, got {other:?}"),
            }
        });
    }

    #[test]
    fn weight_surcharge_above_10000() {
        with_rate_card(CARD, || {
            let p = Parcel {
                weight_grams: 11_000,
                zone: "domestic".to_string(),
            };
            let q = quote(&p).expect("quote");
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
        });
    }

    #[test]
    fn weight_surcharge_not_applied_at_10000() {
        with_rate_card(CARD, || {
            let p = Parcel {
                weight_grams: 10_000,
                zone: "domestic".to_string(),
            };
            let q = quote(&p).expect("quote");
            assert_eq!(q.surcharge_cents, 0);
        });
    }

    #[test]
    fn international_weight_and_zone_surcharges() {
        with_rate_card(CARD, || {
            let p = Parcel {
                weight_grams: 12_000,
                zone: "international".to_string(),
            };
            let q = quote(&p).expect("quote");
            // base 4999, weight surcharge 500, international 20% of 4999 = 999.8 -> 1000
            assert_eq!(q.base_cents, 4999);
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
        });
    }

    #[test]
    fn international_small_band_no_weight_surcharge() {
        with_rate_card(CARD, || {
            let p = Parcel {
                weight_grams: 500,
                zone: "international".to_string(),
            };
            let q = quote(&p).expect("quote");
            // 20% of 1499 = 299.8 -> 300
            assert_eq!(q.base_cents, 1499);
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn unknown_zone() {
        with_rate_card(CARD, || {
            let p = Parcel {
                weight_grams: 100,
                zone: "moon".to_string(),
            };
            match quote(&p) {
                Err(QuoteError::UnknownZone(zone)) => assert_eq!(zone, "moon"),
                other => panic!("expected UnknownZone, got {other:?}"),
            }
        });
    }

     #[test]
    fn rate_card_unset() {
        let _guard = ENV_LOCK.lock().expect("env lock poisoned");
        std::env::remove_var("RATECARD_PATH");
        let p = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
         };
        assert_eq!(quote(&p), Err(QuoteError::RateCardUnavailable));
     }

     #[test]
    fn rate_card_missing_file() {
        let _guard = ENV_LOCK.lock().expect("env lock poisoned");
        let dir = tempfile::TempDir::new().expect("temp dir");
        let p = dir.path().join("does-not-exist.tsv");
        std::env::set_var("RATECARD_PATH", p);
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
         };
        assert_eq!(quote(&parcel), Err(QuoteError::RateCardUnavailable));
        std::env::remove_var("RATECARD_PATH");
     }

    #[test]
    fn malformed_too_few_fields() {
        with_rate_card("domestic\t500\n", || {
            let p = Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            };
            match quote(&p) {
                Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
                other => panic!("expected MalformedRateCard, got {other:?}"),
            }
        });
    }

    #[test]
    fn malformed_bad_number_counted_with_comments() {
        let content = "# comment\ndomestic\t500\t599\ndomestic\t500\thello\n";
        with_rate_card(content, || {
            let p = Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            };
            match quote(&p) {
                Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
                other => panic!("expected MalformedRateCard, got {other:?}"),
            }
        });
    }

    #[test]
    fn display_and_error_impls() {
        let e = QuoteError::UnknownZone("mars".to_string());
        let _ = e.to_string();
        let _: &dyn std::error::Error = &e;
    }

    #[test]
    fn diagnostic_emitted() {
        with_rate_card(CARD, || {
            let p = Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            };
            assert!(quote(&p).is_ok());
        });
    }
}
