use crate::QuoteError;

#[derive(Clone)]
pub struct Band {
    pub max_grams: u32,
    pub cents: u64,
}

pub struct RateCard {
    pub zones: std::collections::BTreeMap<String, Vec<Band>>,
}

pub fn load(path: &str) -> Result<RateCard, QuoteError> {
    let raw = std::fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse(&raw)
}

pub fn parse(raw: &str) -> Result<RateCard, QuoteError> {
    let mut zones: std::collections::BTreeMap<String, Vec<Band>> = std::collections::BTreeMap::new();

    for (idx, line) in raw.lines().enumerate() {
        let line_number = idx + 1;
        let trimmed = line.trim_start();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = trimmed.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = fields[0].to_string();
        let max_grams = fields[1].parse::<u32>().map_err(|_| {
            QuoteError::MalformedRateCard { line: line_number }
        })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        zones
            .entry(zone)
            .or_default()
            .push(Band {
                max_grams,
                cents,
            });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(RateCard { zones })
}
