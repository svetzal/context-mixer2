mod cards;

pub mod zones;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card is unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone `{}`", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(
                    f,
                    "parcel of {} grams exceeds zone limit of {} grams",
                    grams, limit
                )
            }
        }
    }
}

impl std::error::Error for QuoteError {}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    quote_from_path(parcel, &path)
}

fn quote_from_path(parcel: &Parcel, path: &str) -> Result<Quote, QuoteError> {
    let card = cards::load(path)?;

    let bands = card
          .zones
          .get(&parcel.zone)
          .ok_or(QuoteError::UnknownZone(parcel.zone.clone()))?;

    let largest = match bands.last() {
        Some(band) => band.max_grams,
        None => 0,
     };

    let matched = bands
         .iter()
         .find(|band| band.max_grams >= parcel.weight_grams);

    if matched.is_none() {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest,
           });
       }

    let band = matched.unwrap();
    let base_cents = band.cents;

    let mut surcharge_cents = 0u64;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
     }
    if parcel.zone == "international" {
         surcharge_cents += round_half_up(base_cents * 20, 100);
      }

    let total_cents = base_cents.saturating_add(surcharge_cents);

    let quote = Quote {
         base_cents,
         surcharge_cents,
         total_cents,
         band_max_grams: band.max_grams,
      };

    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);
    Ok(quote)
}

fn round_half_up(numerator: u64, denominator: u64) -> u64 {
    (numerator + denominator / 2) / denominator
}

fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!(
        "[quote] zone={} weight_grams={} total_cents={}",
        zone, weight_grams, total_cents
    );
}

#[cfg(test)]
mod tests;
