use super::*;
use std::sync::Mutex;

const RATECARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn parcel(weight: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams: weight,
        zone: zone.to_string(),
    }
}

fn write_card() -> std::path::PathBuf {
    let path =
         std::env::temp_dir().join(format!("ratecard-{}-{}.tmp", std::process::id(), rand_suffix()));
    std::fs::write(&path, RATECARD).expect("write rate card");
    path
}

fn rand_suffix() -> u64 {
    static COUNTER: Mutex<u64> = Mutex::new(0);
    let mut c = COUNTER.lock().unwrap();
    *c += 1;
    *c
}

#[test]
fn domestic_first_band() {
    let p = write_card();
    let q = quote_from_path(&parcel(100, "domestic"), p.to_str().unwrap()).unwrap();
    assert_eq!(q.base_cents, 599);
    assert_eq!(q.surcharge_cents, 0);
    assert_eq!(q.total_cents, 599);
    assert_eq!(q.band_max_grams, 500);
}

#[test]
fn domestic_boundary_inclusive() {
    let p = write_card();
    let q = quote_from_path(&parcel(500, "domestic"), p.to_str().unwrap()).unwrap();
    assert_eq!(q.base_cents, 599);
    assert_eq!(q.band_max_grams, 500);
}

#[test]
fn domestic_next_band() {
    let p = write_card();
    let q = quote_from_path(&parcel(501, "domestic"), p.to_str().unwrap()).unwrap();
    assert_eq!(q.base_cents, 899);
    assert_eq!(q.band_max_grams, 2000);
}

#[test]
fn domestic_largest_band() {
    let p = write_card();
    let q = quote_from_path(&parcel(5000, "domestic"), p.to_str().unwrap()).unwrap();
    assert_eq!(q.base_cents, 1799);
    assert_eq!(q.band_max_grams, 20000);
}

#[test]
fn domestic_overweight_returns_limit() {
    let p = write_card();
    let err = quote_from_path(&parcel(20001, "domestic"), p.to_str().unwrap()).unwrap_err();
    assert_eq!(err, QuoteError::Overweight { grams: 20001, limit: 20000 });
}

#[test]
fn international_base_and_surcharge() {
    let p = write_card();
    let q = quote_from_path(&parcel(100, "international"), p.to_str().unwrap()).unwrap();
    assert_eq!(q.base_cents, 1499);
    assert_eq!(q.surcharge_cents, 300);
    assert_eq!(q.total_cents, 1799);
    assert_eq!(q.band_max_grams, 500);
}

#[test]
fn international_20_percent_halves_up() {
    let p = write_card();
    let q = quote_from_path(&parcel(500, "international"), p.to_str().unwrap()).unwrap();
    assert_eq!(q.base_cents, 1499);
    assert_eq!(q.surcharge_cents, 300);
    assert_eq!(q.total_cents, 1799);
}

#[test]
fn weight_surcharge_over_10kg() {
    let p = write_card();
    let q = quote_from_path(&parcel(12000, "domestic"), p.to_str().unwrap()).unwrap();
    assert_eq!(q.base_cents, 1799);
    assert_eq!(q.surcharge_cents, 500);
    assert_eq!(q.total_cents, 2299);
    assert_eq!(q.band_max_grams, 20000);
}

#[test]
fn weight_surcharge_exactly_10kg_is_none() {
    let p = write_card();
    let q = quote_from_path(&parcel(10000, "domestic"), p.to_str().unwrap()).unwrap();
    assert_eq!(q.surcharge_cents, 0);
}

#[test]
fn combined_surcharges_international_heavy() {
    let p = write_card();
    let q = quote_from_path(&parcel(15000, "international"), p.to_str().unwrap()).unwrap();
    assert_eq!(q.base_cents, 4999);
    let intl = round_half_up(4999 * 20, 100);
    assert_eq!(intl, 1000);
    assert_eq!(q.surcharge_cents, 500 + 1000);
    assert_eq!(q.total_cents, 4999 + 500 + 1000);
    assert_eq!(q.band_max_grams, 20000);
}

#[test]
fn unknown_zone_carries_zone() {
    let p = write_card();
    let err = quote_from_path(&parcel(100, "antarctic"), p.to_str().unwrap()).unwrap_err();
    assert_eq!(err, QuoteError::UnknownZone("antarctic".to_string()));
}

#[test]
fn missing_file_is_unavailable() {
    let err = quote_from_path(&parcel(100, "domestic"), "/no/such/file/here").unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn malformed_too_few_fields() {
    let path = std::env::temp_dir().join(format!("rc-bad1-{}", rand_suffix()));
    std::fs::write(&path, "domestic\t500\n").unwrap();
    let err = quote_from_path(&parcel(100, "domestic"), path.to_str().unwrap()).unwrap_err();
    assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
}

#[test]
fn malformed_line_number_counts_all_lines() {
    let path = std::env::temp_dir().join(format!("rc-bad2-{}", rand_suffix()));
    std::fs::write(&path, "# header\ndomestic\t500\t599\n\ndomestic\n").unwrap();
    let err = quote_from_path(&parcel(100, "domestic"), path.to_str().unwrap()).unwrap_err();
    assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
}

#[test]
fn malformed_non_numeric_cents() {
    let path = std::env::temp_dir().join(format!("rc-bad3-{}", rand_suffix()));
    std::fs::write(&path, "domestic\t500\tnot-a-number\n").unwrap();
    let err = quote_from_path(&parcel(100, "domestic"), path.to_str().unwrap()).unwrap_err();
    assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
}

#[test]
fn comments_and_blanks_ignored() {
    let path = std::env::temp_dir().join(format!("rc-ok-{}", rand_suffix()));
    std::fs::write(&path, "# zone\tmax\tcents\n\ndomestic\t500\t599\n\n# note\ndomestic\t2000\t899\n").unwrap();
    let q = quote_from_path(&parcel(100, "domestic"), path.to_str().unwrap()).unwrap();
    assert_eq!(q.base_cents, 599);
}

#[test]
fn bands_not_pre_sorted_are_sorted() {
    let path = std::env::temp_dir().join(format!("rc-sorted-{}", rand_suffix()));
    std::fs::write(&path, "domestic\t2000\t899\ndomestic\t500\t599\n").unwrap();
    let q = quote_from_path(&parcel(400, "domestic"), path.to_str().unwrap()).unwrap();
    assert_eq!(q.base_cents, 599);
    assert_eq!(q.band_max_grams, 500);
}

#[test]
fn display_reports_each_variant() {
    assert!(format!("{}", QuoteError::RateCardUnavailable).len() > 0);
    assert!(format!("{}", QuoteError::MalformedRateCard { line: 7 }).contains("7"));
    assert!(format!("{}", QuoteError::UnknownZone("x".into())).contains("x"));
    assert!(format!("{}", QuoteError::Overweight { grams: 10, limit: 5 }).contains("10"));
}

#[test]
fn error_is_std_error() {
    let e: Box<dyn std::error::Error> = Box::new(QuoteError::RateCardUnavailable);
    assert!(e.to_string().contains("unavailable") || e.to_string().len() > 0);
}

#[test]
fn public_quote_reads_env_path() {
    let path = write_card();
    let key = "RATECARD_PATH";
    static LOCK: Mutex<()> = Mutex::new(());
    let _guard = LOCK.lock().unwrap();
    std::env::set_var(key, &path);
    let q = quote(&parcel(100, "domestic")).unwrap();
    std::env::remove_var(key);
    assert_eq!(q.base_cents, 599);
    assert_eq!(q.total_cents, 599);
}

#[test]
fn public_quote_unset_env_is_unavailable() {
    let key = "RATECARD_PATH";
    static LOCK: Mutex<()> = Mutex::new(());
    let _guard = LOCK.lock().unwrap();
    std::env::remove_var(key);
    let err = quote(&parcel(100, "domestic")).unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);
}
