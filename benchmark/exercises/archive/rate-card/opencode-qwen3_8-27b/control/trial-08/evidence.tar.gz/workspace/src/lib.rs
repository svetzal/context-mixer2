use std::fmt;

pub mod zones;

#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq, Clone)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(
                    f,
                    "overweight: {} grams exceeds limit of {} grams",
                    grams, limit
                )
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

struct RateCard {
    bands: Vec<Band>,
}

const WEIGHT_SURCHARGE_THRESHOLD: u32 = 10000;
const WEIGHT_SURCHARGE_CENTS: u64 = 500;

fn read_rate_card() -> Result<String, QuoteError> {
    let path = match std::env::var("RATECARD_PATH") {
        Ok(p) => p,
        Err(_) => return Err(QuoteError::RateCardUnavailable),
    };
    match std::fs::read_to_string(&path) {
        Ok(text) => Ok(text),
        Err(_) => Err(QuoteError::RateCardUnavailable),
    }
}

fn parse_rate_card(text: &str) -> Result<RateCard, QuoteError> {
    let mut bands = Vec::new();
    for (idx, raw) in text.split('\n').enumerate() {
        let line_no = idx + 1;
        let line = raw.trim_end_matches('\r');
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }
        let max_grams = fields[1]
            .trim()
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents = fields[2]
            .trim()
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        bands.push(Band {
            zone: fields[0].trim().to_string(),
            band_max_grams: max_grams,
            cents,
        });
    }
    Ok(RateCard { bands })
}

fn round_half_up_div20(numerator: u64) -> u64 {
    (numerator * 2 + 5) / 10
}

fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!(
        "ratecard quote: zone={} weight_grams={} total_cents={}",
        zone, weight_grams, total_cents
    );
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let text = read_rate_card()?;
    let card = parse_rate_card(&text)?;

    let zone_bands: Vec<&Band> = card
        .bands
        .iter()
        .filter(|b| b.zone == parcel.zone)
        .collect();

    if zone_bands.is_empty() {
        emit_diagnostic(&parcel.zone, parcel.weight_grams, 0);
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let mut bands = zone_bands;
    bands.sort_by_key(|b| b.band_max_grams);

    let largest = bands[bands.len() - 1].band_max_grams;

    let match_idx = bands
        .iter()
        .position(|b| b.band_max_grams >= parcel.weight_grams);

    match match_idx {
        None => {
            emit_diagnostic(&parcel.zone, parcel.weight_grams, 0);
            Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: largest,
            })
        }
        Some(idx) => {
            let band = bands[idx];
            let base_cents = band.cents;

            let mut surcharge_cents: u64 = 0;
            if parcel.weight_grams > WEIGHT_SURCHARGE_THRESHOLD {
                surcharge_cents += WEIGHT_SURCHARGE_CENTS;
            }
            if parcel.zone == "international" {
                surcharge_cents += round_half_up_div20(base_cents);
            }

            let total_cents = base_cents + surcharge_cents;
            emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

            Ok(Quote {
                base_cents,
                surcharge_cents,
                total_cents,
                band_max_grams: band.band_max_grams,
            })
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn write_card(content: &str) -> tempfile::NamedTempFile {
        let mut f = tempfile::NamedTempFile::new().unwrap();
        f.write_all(content.as_bytes()).unwrap();
        f.flush().unwrap();
        f
    }

    fn set_path(f: &tempfile::NamedTempFile) {
        std::env::set_var("RATECARD_PATH", f.path());
    }

    fn parcel(weight: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams: weight,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn domestic_basic() {
        let _g = ENV_LOCK.lock().unwrap();
        let f = write_card(SAMPLE);
        set_path(&f);
        match quote(&parcel(500, "domestic")) {
            Ok(q) => {
                assert_eq!(q.base_cents, 599);
                assert_eq!(q.surcharge_cents, 0);
                assert_eq!(q.total_cents, 599);
                assert_eq!(q.band_max_grams, 500);
            }
            Err(e) => panic!("unexpected error: {}", e),
        }
    }

    #[test]
    fn domestic_band_selection_ascending() {
        let _g = ENV_LOCK.lock().unwrap();
        let f = write_card(SAMPLE);
        set_path(&f);
        let q = quote(&parcel(2000, "domestic")).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
        assert_eq!(q.total_cents, 899);
    }

    #[test]
    fn domestic_just_over_first_band_picks_second() {
        let _g = ENV_LOCK.lock().unwrap();
        let f = write_card(SAMPLE);
        set_path(&f);
        let q = quote(&parcel(501, "domestic")).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn domestic_overweight() {
        let _g = ENV_LOCK.lock().unwrap();
        let f = write_card(SAMPLE);
        set_path(&f);
        match quote(&parcel(21000, "domestic")) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 21000);
                assert_eq!(limit, 20000);
            }
            other => panic!("expected overweight, got {:?}", other),
        }
    }

    #[test]
    fn international_surcharge_rounded_half_up() {
        let _g = ENV_LOCK.lock().unwrap();
        let f = write_card(SAMPLE);
        set_path(&f);
        let q = quote(&parcel(500, "international")).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn weight_surcharge_only() {
        let _g = ENV_LOCK.lock().unwrap();
        let f = write_card(SAMPLE);
        set_path(&f);
        let q = quote(&parcel(11000, "domestic")).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn both_surcharges_stack() {
        let _g = ENV_LOCK.lock().unwrap();
        let f = write_card(SAMPLE);
        set_path(&f);
        let q = quote(&parcel(11000, "international")).unwrap();
        assert_eq!(q.base_cents, 4999);
        // 20% of 4999 = 999.8 -> 1000, plus 500 weight surcharge
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn weight_above_threshold_adds_surcharge_but_10000_does_not() {
        let _g = ENV_LOCK.lock().unwrap();
        let f = write_card(SAMPLE);
        set_path(&f);
        let q = quote(&parcel(10000, "domestic")).unwrap();
        assert_eq!(q.surcharge_cents, 0, "10000 is not strictly above 10000");
    }

    #[test]
    fn unknown_zone() {
        let _g = ENV_LOCK.lock().unwrap();
        let f = write_card(SAMPLE);
        set_path(&f);
        match quote(&parcel(100, "mars")) {
            Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "mars"),
            other => panic!("expected unknown zone, got {:?}", other),
        }
    }

    #[test]
    fn rate_card_unavailable_when_unset() {
        let _g = ENV_LOCK.lock().unwrap();
        std::env::remove_var("RATECARD_PATH");
        match quote(&parcel(500, "domestic")) {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected unavailable, got {:?}", other),
        }
    }

    #[test]
    fn rate_card_unavailable_when_file_missing() {
        let _g = ENV_LOCK.lock().unwrap();
        std::env::set_var("RATECARD_PATH", "/nonexistent/rate-card-tmp-xyz");
        match quote(&parcel(500, "domestic")) {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected unavailable, got {:?}", other),
        }
    }

    #[test]
    fn malformed_not_three_fields_counts_comment_and_blank_lines() {
        let _g = ENV_LOCK.lock().unwrap();
        // line 1: comment
        // line 2: valid domestic band
        // line 3: blank
        // line 4: malformed (only one field)
        let content = "# header line\ndomestic\t500\t599\n\nbadline\n";
        let f = write_card(content);
        set_path(&f);
        match quote(&parcel(500, "domestic")) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 4),
            other => panic!("expected malformed, got {:?}", other),
        }
    }

    #[test]
    fn malformed_non_parseable_number() {
        let _g = ENV_LOCK.lock().unwrap();
        // line 1: comment
        // line 2: valid
        // line 3: cents field is not a number
        let content = "# comment\ndomestic\t500\t599\ndomestic\t2000\tabc\n";
        let f = write_card(content);
        set_path(&f);
        match quote(&parcel(1500, "domestic")) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
            other => panic!("expected malformed, got {:?}", other),
        }
    }

    #[test]
    fn malformed_with_too_many_fields() {
        let _g = ENV_LOCK.lock().unwrap();
        let content = "domestic\t500\t599\textra\n";
        let f = write_card(content);
        set_path(&f);
        match quote(&parcel(500, "domestic")) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            other => panic!("expected malformed, got {:?}", other),
        }
    }

    #[test]
    fn error_display_and_error_trait() {
        let _g = ENV_LOCK.lock().unwrap();
        let e = QuoteError::Overweight {
            grams: 21000,
            limit: 20000,
        };
        assert!(!e.to_string().is_empty());
        let _as_err: &dyn std::error::Error = &e;
    }
}
