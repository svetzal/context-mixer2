use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

#[derive(Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {} grams exceeds limit {} grams", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Clone)]
struct RateEntry {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

#[derive(Clone)]
struct RateCard {
    entries: Vec<RateEntry>,
}

impl RateCard {
    fn parse(content: &str) -> Result<RateCard, QuoteError> {
        let mut entries = Vec::new();
        let mut rate_entries_by_zone: std::collections::HashMap<String, Vec<(u32, u64)>> =
            std::collections::HashMap::new();

        for (idx, line) in content.lines().enumerate() {
            let line_num = idx + 1;

            if line.trim().is_empty() || line.trim().starts_with('#') {
                continue;
            }

            let fields: Vec<&str> = line.split('\t').collect();

            if fields.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: line_num });
            }

            let zone = fields[0].to_string();
            let band_max_grams: u32 = fields[1]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
            let cents: u64 = fields[2]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

            rate_entries_by_zone
                .entry(zone.clone())
                .or_default()
                .push((band_max_grams, cents));
        }

        for (zone, mut bands) in rate_entries_by_zone {
            bands.sort_by_key(|(max_grams, _)| *max_grams);

            for (band_max_grams, cents) in bands {
                entries.push(RateEntry {
                    zone: zone.clone(),
                    band_max_grams,
                    cents,
                });
            }
        }

        Ok(RateCard { entries })
    }

    fn find_rate(&self, zone: &str, weight_grams: u32) -> Option<&RateEntry> {
        self.entries
            .iter()
            .filter(|e| e.zone == zone)
            .find(|e| e.band_max_grams >= weight_grams)
    }

    fn max_limit_for_zone(&self, zone: &str) -> Option<u32> {
        self.entries
            .iter()
            .filter(|e| e.zone == zone)
            .map(|e| e.band_max_grams)
            .max()
    }

    fn known_zones(&self) -> std::collections::HashSet<String> {
        self.entries
            .iter()
            .map(|e| e.zone.clone())
            .collect()
    }
}

fn ceil_half_div_100(numerator: u64) -> u64 {
    (numerator + 50) / 100
}

fn calculate_surcharge(base_cents: u64, zone: &str, weight_grams: u32) -> u64 {
    let mut surcharge = 0u64;

    if weight_grams > 10_000 {
        surcharge += 500;
    }

    if zone == "international" {
        let twenty_percent = ceil_half_div_100(base_cents * 20);
        surcharge += twenty_percent;
    }

    surcharge
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;

    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let rate_card = RateCard::parse(&content)?;

    if !rate_card.known_zones().contains(&parcel.zone) {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let max_limit = rate_card
        .max_limit_for_zone(&parcel.zone)
        .unwrap_or(0);

    if parcel.weight_grams > max_limit {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: max_limit,
        });
    }

    let entry = rate_card
        .find_rate(&parcel.zone, parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: max_limit,
        })?;

    let base_cents = entry.cents;
    let surcharge_cents = calculate_surcharge(base_cents, &parcel.zone, parcel.weight_grams);
    let total_cents = base_cents + surcharge_cents;

    println!(
        "[opentelemetry.trace] zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: entry.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    struct RateCardGuard {
        _file: NamedTempFile,
    }

    impl RateCardGuard {
        fn new(contents: &str) -> Self {
            let mut file = NamedTempFile::new().unwrap();
            file.write_all(contents.as_bytes()).unwrap();
            let path = file.path().to_str().unwrap().to_string();
            std::env::set_var("RATECARD_PATH", &path);
            Self { _file: file }
        }
    }

    impl Drop for RateCardGuard {
        fn drop(&mut self) {
            std::env::remove_var("RATECARD_PATH");
        }
    }

    #[test]
    fn test_domestic_light_weight() {
        let _guard = RateCardGuard::new("domestic\t500\t599");

        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_medium_weight() {
        let _guard = RateCardGuard::new("domestic\t2000\t899");

        let parcel = Parcel {
            weight_grams: 1001,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_domestic_heavy_weight() {
        let _guard = RateCardGuard::new("domestic\t20000\t1799");

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_domestic_overweight() {
        let _guard = RateCardGuard::new("domestic\t20000\t1799");

        let parcel = Parcel {
            weight_grams: 25000,
            zone: "domestic".to_string(),
        };

        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 25000);
                assert_eq!(limit, 20000);
            }
            _ => panic!("Expected Overweight error"),
        }
    }

    #[test]
    fn test_international_surcharges() {
        let _guard = RateCardGuard::new("international\t20000\t4999");

        let parcel = Parcel {
            weight_grams: 2000,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 4999);
        let expected_surcharge = (4999 * 20 + 50) / 100;
        assert_eq!(quote.surcharge_cents, expected_surcharge);
        assert_eq!(quote.total_cents, 4999 + expected_surcharge);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_international_weight_surcharge() {
        let _guard = RateCardGuard::new("international\t20000\t4999");

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 4999);
        let expected_surcharge = (4999 * 20 + 50) / 100 + 500;
        assert_eq!(quote.surcharge_cents, expected_surcharge);
        assert_eq!(quote.total_cents, 4999 + expected_surcharge);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_unknown_zone() {
        let _guard = RateCardGuard::new("domestic\t5000\t1000");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "arctic".to_string(),
        };

        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::UnknownZone(zone) => assert_eq!(zone, "arctic"),
            _ => panic!("Expected UnknownZone error"),
        }
    }

    #[test]
    fn test_rate_card_unavailable() {
        std::env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        let err = quote(&parcel).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn test_malformed_rate_card_empty_fields() {
        let _guard = RateCardGuard::new("domestic\t500");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_bad_numbers() {
        let _guard = RateCardGuard::new("domestic\tabc\t500");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_rate_card_with_comments_and_blanks() {
        let _guard = RateCardGuard::new("# comment line\ndomestic\t500\t599\n\n# another comment\ndomestic\t2000\t899");

        let parcel = Parcel {
            weight_grams: 1000,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_rate_card_band_selection() {
        let _guard = RateCardGuard::new("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799");

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_rate_card_edge_weight() {
        let _guard = RateCardGuard::new("domestic\t500\t599\ndomestic\t2000\t899");

        let parcel = Parcel {
            weight_grams: 501,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_malformed_rate_card_line_number_with_blanks_and_comments() {
        let _guard = RateCardGuard::new("# header\n\n# rates\ndomestic\tabc\t500");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 4),
            _ => panic!("Expected MalformedRateCard error at line 4"),
        }
    }

    #[test]
    fn test_error_display() {
        let err = QuoteError::RateCardUnavailable;
        assert_eq!(format!("{}", err), "rate card unavailable");

        let err = QuoteError::MalformedRateCard { line: 5 };
        assert_eq!(format!("{}", err), "malformed rate card at line 5");

        let err = QuoteError::UnknownZone("ocean".to_string());
        assert_eq!(format!("{}", err), "unknown zone: ocean");

        let err = QuoteError::Overweight {
            grams: 5000,
            limit: 2000,
        };
        assert_eq!(format!("{}", err), "parcel weight 5000 grams exceeds limit 2000 grams");
    }

    #[test]
    fn test_international_rounding() {
        let _guard = RateCardGuard::new("international\t500\t1001");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1001);
        let expected_surcharge = (1001 * 20 + 50) / 100;
        assert_eq!(quote.surcharge_cents, expected_surcharge);
    }
}
