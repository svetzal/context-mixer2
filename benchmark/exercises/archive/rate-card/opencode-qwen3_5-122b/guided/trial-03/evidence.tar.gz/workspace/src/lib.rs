pub mod zones;

use std::collections::BTreeMap;
use std::error::Error;
use std::fmt;
use std::fs;

/// A parcel to quote.
#[derive(Debug, Clone, PartialEq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A shipping quote.
#[derive(Debug, Clone, PartialEq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Errors that can occur when quoting.
#[derive(Debug, Clone, PartialEq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable: set RATECARD_PATH environment variable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel overweight: {grams}g exceeds limit of {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

/// A parsed rate card entry.
#[derive(Debug, Clone)]
struct RateEntry {
    zone: String,
    band_max_grams: u32,
    base_cents: u64,
}

/// Diagnostic record for observability.
#[derive(Debug, Clone)]
struct QuoteDiagnostic {
    zone: String,
    weight_grams: u32,
    total_cents: u64,
}

impl QuoteDiagnostic {
    fn emit(&self) {
        // In a real system, this would use tracing::info! or similar.
        // For now, we emit to stderr for visibility without dependencies.
        eprintln!(
            "[quote] zone={} weight_grams={} total_cents={}",
            self.zone, self.weight_grams, self.total_cents
        );
    }
}

/// Parse the rate card file.
fn parse_rate_card(content: &str) -> Result<Vec<RateEntry>, QuoteError> {
    let mut entries = Vec::new();

    for (idx, line) in content.lines().enumerate() {
        let line_num = idx + 1; // 1-based line numbers

        // Skip empty lines and comments
        if line.trim().is_empty() || line.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let base_cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        entries.push(RateEntry {
            zone,
            band_max_grams,
            base_cents,
        });
    }

    Ok(entries)
}

/// Group entries by zone, sorted by band_max_grams ascending.
fn group_by_zone(entries: Vec<RateEntry>) -> BTreeMap<String, Vec<RateEntry>> {
    let mut zones: BTreeMap<String, Vec<RateEntry>> = BTreeMap::new();

    for entry in entries {
        zones
            .entry(entry.zone.clone())
            .or_default()
            .push(entry);
    }

    // Sort each zone's bands by band_max_grams ascending
    for bands in zones.values_mut() {
        bands.sort_by_key(|e| e.band_max_grams);
    }

    zones
}

/// Calculate the 20% surcharge using half-up rounding.
fn calculate_international_surcharge(base_cents: u64) -> u64 {
    // 20% = base * 0.2 = base * 20 / 100
    // Half-up: (base * 20 + 50) / 100
    (base_cents * 20 + 50) / 100
}

/// Calculate a shipping quote.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let ratecard_path =
        std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;

    let content = fs::read_to_string(&ratecard_path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let entries = parse_rate_card(&content)?;
    let zones = group_by_zone(entries);

    let zone_entries: Vec<RateEntry> = zones.get(&parcel.zone).cloned().ok_or_else(|| {
        QuoteError::UnknownZone(parcel.zone.clone())
    })?;

    // Find matching band (first band where band_max_grams >= weight)
    // Since bands are sorted ascending, this is the first matching band
    let matching_band = zone_entries
        .iter()
        .find(|e| e.band_max_grams >= parcel.weight_grams);

    // Track the max limit for the overweight error
    let max_limit = zone_entries
        .iter()
        .map(|e| e.band_max_grams)
        .max()
        .unwrap_or(0);

    let band = match matching_band {
        Some(b) => b,
        None => {
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: max_limit,
            });
        }
    };

    let base_cents = band.base_cents;
    let band_max_grams = band.band_max_grams;

    // Calculate surcharges
    let mut surcharge_cents = 0u64;

    // Weight surcharge: +500 cents if weight > 10000g
    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    // International surcharge: 20% of base, half-up
    if parcel.zone == "international" {
        surcharge_cents += calculate_international_surcharge(base_cents);
    }

    let total_cents = base_cents + surcharge_cents;

    let quote = Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    };

    // Emit diagnostic for observability
    QuoteDiagnostic {
        zone: parcel.zone.clone(),
        weight_grams: parcel.weight_grams,
        total_cents,
    }
    .emit();

    Ok(quote)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs::File;
    use std::io::Write;
    use tempfile::TempDir;

    fn setup_ratecard(content: &str) -> (TempDir, String) {
        let temp_dir = TempDir::new().unwrap();
        let ratecard_path = temp_dir.path().join("ratecard.tsv");
        let mut file = File::create(&ratecard_path).unwrap();
        file.write_all(content.as_bytes()).unwrap();
        (temp_dir, ratecard_path.to_string_lossy().to_string())
    }

    #[test]
    fn test_domestic_light() {
        let (_temp_dir, ratecard_path) = setup_ratecard(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n"
        );
        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_medium() {
        let (_temp_dir, ratecard_path) = setup_ratecard(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n"
        );
        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_domestic_heavy_over_10kg() {
        let (_temp_dir, ratecard_path) = setup_ratecard(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n"
        );
        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 12000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500); // over 10kg surcharge
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_international_light() {
        let (_temp_dir, ratecard_path) = setup_ratecard(
            "# zone\tband_max_grams\tcents\n\
             international\t500\t1499\n\
             international\t20000\t4999\n"
        );
        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        // base = 1499, international surcharge = 20% of 1499 = 299.8 -> 300 (half-up)
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_international_heavy() {
        let (_temp_dir, ratecard_path) = setup_ratecard(
            "# zone\tband_max_grams\tcents\n\
             international\t500\t1499\n\
             international\t20000\t4999\n"
        );
        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        // base = 4999, international = 20% of 4999 = 999.8 -> 1000, over 10kg = 500
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500); // 1000 + 500
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_unknown_zone() {
        let (_temp_dir, ratecard_path) = setup_ratecard(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n"
        );
        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "ocean".to_string(),
        };
        let err = quote(&parcel).unwrap_err();

        assert!(matches!(err, QuoteError::UnknownZone(z) if z == "ocean"));
    }

    #[test]
    fn test_overweight() {
        let (_temp_dir, ratecard_path) = setup_ratecard(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n"
        );
        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 5000,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();

        assert!(matches!(err, QuoteError::Overweight { grams, limit } if grams == 5000 && limit == 2000));
    }

    #[test]
    fn test_rate_card_unavailable() {
        std::env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();

        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn test_malformed_rate_card_wrong_fields() {
        let (_temp_dir, ratecard_path) = setup_ratecard(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             badline\n\
             domestic\t2000\t899\n"
        );
        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();

        assert!(matches!(err, QuoteError::MalformedRateCard { line } if line == 3));
    }

    #[test]
    fn test_malformed_rate_card_bad_number() {
        let (_temp_dir, ratecard_path) = setup_ratecard(
            "# zone\tband_max_grams\tcents\n\
             domestic\tabc\t599\n"
        );
        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();

        assert!(matches!(err, QuoteError::MalformedRateCard { line } if line == 2));
    }

    #[test]
    fn test_quote_error_display() {
        assert_eq!(
            format!("{}", QuoteError::RateCardUnavailable),
            "rate card unavailable: set RATECARD_PATH environment variable"
        );
        assert_eq!(
            format!("{}", QuoteError::MalformedRateCard { line: 5 }),
            "malformed rate card at line 5"
        );
        assert_eq!(
            format!("{}", QuoteError::UnknownZone("mars".to_string())),
            "unknown zone: mars"
        );
        assert_eq!(
            format!("{}", QuoteError::Overweight { grams: 30000, limit: 20000 }),
            "parcel overweight: 30000g exceeds limit of 20000g"
        );
    }

    #[test]
    fn test_quote_error_impl_error_trait() {
        let err: Box<dyn Error> = Box::new(QuoteError::UnknownZone("test".into()));
        assert_eq!(err.to_string(), "unknown zone: test");
    }

    #[test]
    fn test_weight_exactly_at_band_boundary() {
        let (_temp_dir, ratecard_path) = setup_ratecard(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n"
        );
        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_weight_just_over_band() {
        let (_temp_dir, ratecard_path) = setup_ratecard(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n"
        );
        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 501,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_empty_and_comment_lines_count_for_malformed() {
        let (_temp_dir, ratecard_path) = setup_ratecard(
            "# zone\tband_max_grams\tcents\n\
             \n\
             domestic\n\
             domestic\t2000\t899\n"
        );
        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();

        // Line 3 is the malformed line (line 1 is comment, line 2 is empty, line 3 is bad)
        assert!(matches!(err, QuoteError::MalformedRateCard { line } if line == 3));
    }
}
