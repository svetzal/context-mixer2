use std::collections::HashMap;

pub mod zones;
use std::error::Error;
use std::fmt;
use std::fs;

#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "RATECARD_PATH environment variable is not set or file is unreadable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug)]
struct RateBand {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

fn parse_rate_card(content: &str) -> Result<Vec<RateBand>, QuoteError> {
    let mut bands = Vec::new();

    for (idx, line) in content.lines().enumerate() {
        let line_num = idx + 1;
        let trimmed = line.trim();

        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = trimmed.split('\t').collect();

        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].to_string();
        let band_max_grams = parts[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = parts[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        bands.push(RateBand {
            zone,
            band_max_grams,
            cents,
        });
    }

    Ok(bands)
}

fn build_rate_index(bands: &[RateBand]) -> Result<HashMap<String, Vec<&RateBand>>, QuoteError> {
    let mut index: HashMap<String, Vec<&RateBand>> = HashMap::new();

    for band in bands {
        index
            .entry(band.zone.clone())
            .or_insert_with(Vec::new)
            .push(band);
    }

    for zone_bands in index.values_mut() {
        zone_bands.sort_by_key(|b| b.band_max_grams);
    }

    Ok(index)
}

fn calculate_surcharges(base_cents: u64, zone: &str, weight_grams: u32) -> u64 {
    let mut surcharge = 0u64;

    if weight_grams > 10000 {
        surcharge += 500;
    }

    if zone == "international" {
        let int_surcharge = ((base_cents as f64) * 0.20).round() as u64;
        surcharge += int_surcharge;
    }

    surcharge
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let content = fs::read_to_string(&path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let bands = parse_rate_card(&content)?;
    let index = build_rate_index(&bands)?;

    let zone_bands = index
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let max_limit = zone_bands.last().unwrap().band_max_grams;

    if parcel.weight_grams > max_limit {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: max_limit,
        });
    }

    let matching_band = zone_bands
        .iter()
        .find(|b| parcel.weight_grams <= b.band_max_grams)
        .expect("should find matching band");

    let base_cents = matching_band.cents;
    let surcharge_cents =
        calculate_surcharges(base_cents, &parcel.zone, parcel.weight_grams);
    let total_cents = base_cents + surcharge_cents;

    emit_quote_diagnostic(
        &parcel.zone,
        parcel.weight_grams,
        total_cents,
        base_cents,
        surcharge_cents,
        matching_band.band_max_grams,
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: matching_band.band_max_grams,
    })
}

fn emit_quote_diagnostic(
    zone: &str,
    weight_grams: u32,
    total_cents: u64,
    base_cents: u64,
    surcharge_cents: u64,
    band_max_grams: u32,
) {
    println!(
        "QUOTE: zone={}, weight_grams={}, base_cents={}, surcharge_cents={}, total_cents={}, band_max_grams={}",
        zone, weight_grams, base_cents, surcharge_cents, total_cents, band_max_grams
    );
}

#[cfg(test)]
mod tests {
    use super::*;

    use tempfile::TempDir;

    fn create_test_ratecard(content: &str) -> (TempDir, String) {
        let tmp = TempDir::new().unwrap();
        let path = tmp.path().join("ratecard.txt");
        fs::write(&path, content).unwrap();
        (tmp, path.to_string_lossy().to_string())
    }

    #[test]
    fn test_domestic_light() {
        let (tmp, _) = create_test_ratecard(
            "
domestic	500	599
domestic	2000	899
domestic	20000	1799
",
        );
        std::env::set_var("RATECARD_PATH", &tmp.path().join("ratecard.txt"));

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);

        let _ = std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_domestic_heavy() {
        let (tmp, _) = create_test_ratecard(
            "
domestic	500	599
domestic	2000	899
domestic	20000	1799
",
        );
        std::env::set_var("RATECARD_PATH", &tmp.path().join("ratecard.txt"));

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);

        let _ = std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_international_light() {
        let (tmp, _) = create_test_ratecard(
            "
international	500	1499
international	20000	4999
",
        );
        std::env::set_var("RATECARD_PATH", &tmp.path().join("ratecard.txt"));

        let parcel = Parcel {
            weight_grams: 200,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        let expected_base = 1499u64;
        let expected_int_surch = 300u64;

        assert_eq!(quote.base_cents, expected_base);
        assert_eq!(quote.surcharge_cents, expected_int_surch);
        assert_eq!(quote.total_cents, expected_base + expected_int_surch);
        assert_eq!(quote.band_max_grams, 500);

        let _ = std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_international_heavy() {
        let (tmp, _) = create_test_ratecard(
            "
international	500	1499
international	20000	4999
",
        );
        std::env::set_var("RATECARD_PATH", &tmp.path().join("ratecard.txt"));

        let parcel = Parcel {
            weight_grams: 12000,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        let expected_base = 4999u64;
        let expected_int_surch = 1000u64;
        let expected_weight_surch = 500u64;

        assert_eq!(quote.base_cents, expected_base);
        assert_eq!(
            quote.surcharge_cents,
            expected_int_surch + expected_weight_surch
        );
        assert_eq!(quote.total_cents, expected_base + expected_int_surch + expected_weight_surch);
        assert_eq!(quote.band_max_grams, 20000);

        let _ = std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_unknown_zone() {
        let (tmp, _) = create_test_ratecard(
            "
domestic	500	599
",
        );
        std::env::set_var("RATECARD_PATH", &tmp.path().join("ratecard.txt"));

        let parcel = Parcel {
            weight_grams: 200,
            zone: "satellite".to_string(),
        };
        let result = quote(&parcel);

        match result {
            Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "satellite"),
            other => panic!("Expected UnknownZone error, got {:?}", other),
        }

        let _ = std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_overweight() {
        let (tmp, _) = create_test_ratecard(
            "
domestic	500	599
domestic	2000	899
",
        );
        std::env::set_var("RATECARD_PATH", &tmp.path().join("ratecard.txt"));

        let parcel = Parcel {
            weight_grams: 3000,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);

        match result {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 3000);
                assert_eq!(limit, 2000);
            }
            other => panic!("Expected Overweight error, got {:?}", other),
        }

        let _ = std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_ratecard_unavailable() {
        let _ = std::env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 200,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);

        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_malformed_ratecard_wrong_fields() {
        let (tmp, _) = create_test_ratecard(
            "domestic\t500
domestic\t2000\t899",
        );
        std::env::set_var("RATECARD_PATH", &tmp.path().join("ratecard.txt"));

        let parcel = Parcel {
            weight_grams: 200,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);

        match result {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            other => panic!("Expected MalformedRateCard at line 1, got {:?}", other),
        }

        let _ = std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_malformed_ratecard_bad_number() {
        let (tmp, _) = create_test_ratecard(
            "domestic\tbad\t899
domestic\t2000\t899",
        );
        std::env::set_var("RATECARD_PATH", &tmp.path().join("ratecard.txt"));

        let parcel = Parcel {
            weight_grams: 200,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);

        match result {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            other => panic!("Expected MalformedRateCard at line 1, got {:?}", other),
        }

        let _ = std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_comments_and_blanks_ignored() {
        let (tmp, _) = create_test_ratecard(
            "
# This is a comment
domestic	500	599

# Another comment
domestic	2000	899

",
        );
        std::env::set_var("RATECARD_PATH", &tmp.path().join("ratecard.txt"));

        let parcel = Parcel {
            weight_grams: 1000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);

        let _ = std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_error_implements_error_trait() {
        fn asserts_error<T: Error>() {}
        asserts_error::<QuoteError>();
    }

    #[test]
    fn test_error_display() {
        assert!(format!("{}", QuoteError::RateCardUnavailable)
            .contains("RATECARD_PATH"));
        assert!(
            format!("{}", QuoteError::MalformedRateCard { line: 5 }).contains("line 5")
        );
        assert_eq!(
            format!("{}", QuoteError::UnknownZone("orbital".to_string())),
            "unknown zone: orbital"
        );
        assert!(format!("{}", QuoteError::Overweight { grams: 5000, limit: 2000 })
            .contains("5000"));
    }
}
