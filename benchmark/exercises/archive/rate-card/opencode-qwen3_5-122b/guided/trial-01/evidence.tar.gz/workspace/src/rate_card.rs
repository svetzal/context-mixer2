use std::collections::BTreeMap;
use std::error::Error;
use std::fmt;
use std::fs;

/// A parcel with weight and destination zone.
#[derive(Debug, Clone, PartialEq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A shipping quote with base price, surcharges, and the applicable band.
#[derive(Debug, Clone, PartialEq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Error types for quote calculation.
#[derive(Debug, Clone, PartialEq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card not available: check RATECARD_PATH environment variable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {}", zone)
            }
            QuoteError::Overweight { grams, limit } => {
                write!(
                    f,
                    "weight {} grams exceeds zone limit {} grams",
                    grams, limit
                )
            }
        }
    }
}

impl Error for QuoteError {}

/// Represents a parsed rate card: zone -> sorted list of (band_max_grams, cents).
#[derive(Debug, Clone)]
struct RateCard {
    zones: BTreeMap<String, Vec<(u32, u64)>>,
}

impl RateCard {
    fn parse(content: &str) -> Result<Self, QuoteError> {
        let mut zones: BTreeMap<String, Vec<(u32, u64)>> = BTreeMap::new();

        for (idx, line) in content.lines().enumerate() {
            let line_num = idx + 1;

            // Skip empty lines and comments
            if line.trim().is_empty() || line.starts_with('#') {
                continue;
            }

            let parts: Vec<&str> = line.split('\t').collect();
            if parts.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: line_num });
            }

            let zone = parts[0].to_string();
            let band_max_grams: u32 = parts[1]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
            let cents: u64 = parts[2]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

            zones
                .entry(zone)
                .or_default()
                .push((band_max_grams, cents));
        }

        // Sort each zone's bands by band_max_grams ascending
        for bands in zones.values_mut() {
            bands.sort_by_key(|(max_grams, _)| *max_grams);
        }

        Ok(RateCard { zones })
    }

    fn quote(&self, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let bands = self
            .zones
            .get(&parcel.zone)
            .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

        // Find the first band whose max_grams >= weight
        let mut matching_band = None;
        let mut max_limit = 0u32;

        for (band_max_grams, cents) in bands {
            if *band_max_grams >= parcel.weight_grams {
                matching_band = Some((*band_max_grams, *cents));
                break;
            }
            max_limit = *band_max_grams;
        }

        let (band_max_grams, base_cents) = matching_band.ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: max_limit,
            }
        })?;

        // Calculate surcharges
        let mut surcharge_cents = 0u64;

        // Weight surcharge: strictly above 10000 grams adds 500 cents
        if parcel.weight_grams > 10000 {
            surcharge_cents += 500;
        }

        // International surcharge: 20% of base_cents, rounded half-up
        if parcel.zone == "international" {
            let int_surcharge = (base_cents as f64 * 0.2).round() as u64;
            surcharge_cents += int_surcharge;
        }

        let total_cents = base_cents + surcharge_cents;

        Ok(Quote {
            base_cents,
            surcharge_cents,
            total_cents,
            band_max_grams,
        })
    }
}

/// Calculate a shipping quote for the given parcel.
///
/// Reads the rate card from the RATECARD_PATH environment variable.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;

    let content = fs::read_to_string(&path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let rate_card = RateCard::parse(&content)?;

    // Emit diagnostic record for observability
    let result = rate_card.quote(&parcel);

    if let Ok(ref q) = result {
        eprintln!(
            "[quote] zone={} weight_grams={} total_cents={}",
            parcel.zone, parcel.weight_grams, q.total_cents
        );
    }

    result
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn setup_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        write!(file, "{}", content).unwrap();
        file
    }

    #[test]
    fn test_domestic_light() {
        let file = setup_ratecard(
            "domestic	500	599
domestic	2000	899
domestic	20000	1799"
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 450,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();

        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_medium_no_weight_surcharge() {
        let file = setup_ratecard(
            "domestic	500	599
domestic	2000	899
domestic	20000	1799"
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 1000,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();

        assert_eq!(q.base_cents, 899);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn test_domestic_heavy_with_surcharge() {
        let file = setup_ratecard(
            "domestic	500	599
domestic	2000	899
domestic	20000	1799"
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();

        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn test_international_base() {
        let file = setup_ratecard(
            "international	500	1499
international	20000	4999"
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };
        let q = quote(&parcel).unwrap();

        // base = 1499, int surcharge = 1499 * 0.2 = 299.8 -> rounds to 300
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn test_international_heavy() {
        let file = setup_ratecard(
            "international	500	1499
international	20000	4999"
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let q = quote(&parcel).unwrap();

        // base = 4999, int surcharge = 4999 * 0.2 = 999.8 -> rounds to 1000
        // weight surcharge = 500
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn test_unknown_zone() {
        let file = setup_ratecard(
            "domestic	500	599"
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "eu".to_string(),
        };
        let err = quote(&parcel).unwrap_err();

        assert_eq!(err, QuoteError::UnknownZone("eu".to_string()));
    }

    #[test]
    fn test_overweight() {
        let file = setup_ratecard(
            "domestic	500	599
domestic	2000	899"
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 5000,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();

        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 5000,
                limit: 2000
            }
        );
    }

    #[test]
    fn test_missing_ratecard_path() {
        std::env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();

        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn test_malformed_ratecard_wrong_fields() {
        let file = setup_ratecard(
            "domestic	500	599
domestic	abc
domestic	2000	899"
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();

        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn test_malformed_ratecard_bad_number() {
        let file = setup_ratecard(
            "domestic	500	599
domestic	abc	899"
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();

        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn test_comments_and_blanks_ignored() {
        let file = setup_ratecard(
            "# Zone rate card

domestic	500	599

# Heavier
domestic	2000	899"
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };
        let q = quote(&parcel).unwrap();

        assert_eq!(q.base_cents, 899);
        assert_eq!(q.total_cents, 899);
    }

    #[test]
    fn test_malformed_counting_comments_and_blanks() {
        // Line 1: comment
        // Line 2: blank
        // Line 3: good
        // Line 4: blank
        // Line 5: malformed (should be line 5)
        let file = setup_ratecard(
            "# Zone rate card

domestic	500	599

domestic"
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();

        assert_eq!(err, QuoteError::MalformedRateCard { line: 5 });
    }

    #[test]
    fn test_error_display() {
        assert_eq!(
            format!("{}", QuoteError::RateCardUnavailable),
            "rate card not available: check RATECARD_PATH environment variable"
        );
        assert_eq!(
            format!("{}", QuoteError::MalformedRateCard { line: 10 }),
            "malformed rate card at line 10"
        );
        assert_eq!(
            format!("{}", QuoteError::UnknownZone("eu".to_string())),
            "unknown zone: eu"
        );
        assert_eq!(
            format!("{}", QuoteError::Overweight { grams: 5000, limit: 2000 }),
            "weight 5000 grams exceeds zone limit 2000 grams"
        );
    }
}
