pub mod zones;

use std::collections::BTreeMap;
use std::error::Error;
use std::fmt;
use std::fs;
use std::sync::OnceLock;

/// A shipping parcel with weight and destination zone.
#[derive(Debug, Clone, PartialEq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A shipping quote with base rate and surcharges.
#[derive(Debug, Clone, PartialEq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Errors that can occur when calculating a quote.
#[derive(Debug, Clone, PartialEq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card path not set or file unreadable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "weight {grams}g exceeds limit of {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

/// A parsed rate card entry.
#[derive(Debug, Clone)]
struct RateEntry {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

/// Parsed rate card: zone -> sorted list of (band_max_grams, cents) entries.
type RateCard = BTreeMap<String, Vec<(u32, u64)>>;

fn parse_rate_card(content: &str) -> Result<RateCard, QuoteError> {
    let mut card: BTreeMap<String, Vec<(u32, u64)>> = BTreeMap::new();

    for (idx, line) in content.lines().enumerate() {
        let line_num = idx + 1; // 1-based line number

        // Skip empty lines and comments
        if line.trim().is_empty() || line.starts_with('#') {
            continue;
        }

        // Parse tab-separated fields
        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = fields[0].trim().to_string();
        let band_max_grams: u32 = fields[1].trim().parse().map_err(|_| {
            QuoteError::MalformedRateCard { line: line_num }
        })?;
        let cents: u64 = fields[2].trim().parse().map_err(|_| {
            QuoteError::MalformedRateCard { line: line_num }
        })?;

        card.entry(zone)
            .or_default()
            .push((band_max_grams, cents));
    }

    // Sort each zone's bands by band_max_grams (ascending)
    for bands in card.values_mut() {
        bands.sort_by_key(|(max_grams, _)| *max_grams);
    }

    Ok(card)
}

fn read_rate_card() -> Result<RateCard, QuoteError> {
    let path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let content = fs::read_to_string(&path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    parse_rate_card(&content)
}

/// Calculate a shipping quote for a parcel.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = read_rate_card()?;

    let bands = card.get(&parcel.zone).ok_or_else(|| {
        QuoteError::UnknownZone(parcel.zone.clone())
    })?;

    if bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    // Find the first band where band_max_grams >= weight
    let mut found: Option<(u32, u64)> = None;
    let mut max_limit: u32 = 0;

    for &(band_max_grams, cents) in bands.iter() {
        max_limit = max_limit.max(band_max_grams);
        if parcel.weight_grams <= band_max_grams {
            found = Some((band_max_grams, cents));
            break;
        }
    }

    let (band_max_grams, base_cents) = found.ok_or_else(|| {
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: max_limit,
        }
    })?;

    // Calculate surcharges
    let mut surcharge_cents: u64 = 0;

    // Weight surcharge: 500 cents if weight > 10000g
    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    // International surcharge: 20% of base_cents, rounded half-up
    if parcel.zone == "international" {
        // Round half-up: (base * 20 + 50) / 100
        let int_surcharge = (base_cents * 20 + 50) / 100;
        surcharge_cents += int_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    // Emit diagnostic record
    emit_quote_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

/// Emit a diagnostic record for quote observability.
fn emit_quote_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    static DIAGNOSTIC: OnceLock<Box<dyn Fn(&str, u32, u64) + Sync + Send>> = OnceLock::new();

    let logger =
        DIAGNOSTIC.get_or_init(|| Box::new(|z: &str, w: u32, t: u64| {
            println!("[QUOTE] zone={z} weight_grams={w} total_cents={t}");
        }));

    logger(zone, weight_grams, total_cents);
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs::File;
    use std::io::Write;

    fn setup_rate_card(content: &str) -> tempfile::TempDir {
        let dir = tempfile::tempdir().unwrap();
        let file_path = dir.path().join("rates.tsv");
        let mut file = File::create(&file_path).unwrap();
        file.write_all(content.as_bytes()).unwrap();
        file.sync_all().unwrap();

        std::env::set_var("RATECARD_PATH", file_path.to_str().unwrap());
        dir
    }

    #[test]
    fn test_domestic_small_parcel() {
        let _guard = setup_rate_card("zone	band_max_grams	cents
domestic	500	599
");
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let quote_result = quote(&parcel).unwrap();
        assert_eq!(quote_result.base_cents, 599);
        assert_eq!(quote_result.surcharge_cents, 0);
        assert_eq!(quote_result.total_cents, 599);
        assert_eq!(quote_result.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_medium_parcel() {
        let _guard = setup_rate_card("zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
");
        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };
        let quote_result = quote(&parcel).unwrap();
        assert_eq!(quote_result.base_cents, 899);
        assert_eq!(quote_result.surcharge_cents, 0);
        assert_eq!(quote_result.total_cents, 899);
        assert_eq!(quote_result.band_max_grams, 2000);
    }

    #[test]
    fn test_domestic_heavy_parcel_no_surcharge() {
        let _guard = setup_rate_card("zone	band_max_grams	cents
domestic	20000	1799
");
        let parcel = Parcel {
            weight_grams: 9000,
            zone: "domestic".to_string(),
        };
        let quote_result = quote(&parcel).unwrap();
        assert_eq!(quote_result.base_cents, 1799);
        assert_eq!(quote_result.surcharge_cents, 0);
        assert_eq!(quote_result.total_cents, 1799);
    }

    #[test]
    fn test_domestic_heavy_parcel_with_surcharge() {
        let _guard = setup_rate_card("zone	band_max_grams	cents
domestic	20000	1799
");
        let parcel = Parcel {
            weight_grams: 12000,
            zone: "domestic".to_string(),
        };
        let quote_result = quote(&parcel).unwrap();
        assert_eq!(quote_result.base_cents, 1799);
        assert_eq!(quote_result.surcharge_cents, 500);
        assert_eq!(quote_result.total_cents, 2299);
    }

    #[test]
    fn test_international_base_rate() {
        let _guard = setup_rate_card("zone	band_max_grams	cents
international	500	1499
international	20000	4999
");
        let parcel = Parcel {
            weight_grams: 500,
            zone: "international".to_string(),
        };
        let quote_result = quote(&parcel).unwrap();
        assert_eq!(quote_result.base_cents, 1499);
        assert_eq!(quote_result.surcharge_cents, 300);
        assert_eq!(quote_result.total_cents, 1799);
        assert_eq!(quote_result.band_max_grams, 500);
    }

    #[test]
    fn test_international_heavy() {
        let _guard = setup_rate_card("zone	band_max_grams	cents
international	20000	4999
");
        let parcel = Parcel {
            weight_grams: 8000,
            zone: "international".to_string(),
        };
        let quote_result = quote(&parcel).unwrap();
        assert_eq!(quote_result.base_cents, 4999);
        assert_eq!(quote_result.surcharge_cents, 1000); // 20% of 4999 = 999.8 -> 1000
        assert_eq!(quote_result.total_cents, 5999);
    }

    #[test]
    fn test_international_overweight_with_both_surcharges() {
        let _guard = setup_rate_card("zone	band_max_grams	cents
international	20000	4999
");
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let quote_result = quote(&parcel).unwrap();
        assert_eq!(quote_result.base_cents, 4999);
        assert_eq!(quote_result.surcharge_cents, 1500); // 1000 intl + 500 weight
        assert_eq!(quote_result.total_cents, 6499);
    }

    #[test]
    fn test_unknown_zone() {
        let _guard = setup_rate_card("zone	band_max_grams	cents
");
        let parcel = Parcel {
            weight_grams: 500,
            zone: "antarctic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(
            err,
            QuoteError::UnknownZone("antarctic".to_string())
        );
    }

    #[test]
    fn test_overweight() {
        let _guard = setup_rate_card("zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
");
        let parcel = Parcel {
            weight_grams: 5000,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 5000,
                limit: 2000
            }
        );
    }

    #[test]
    fn test_rate_card_unavailable_missing_env() {
        std::env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn test_malformed_rate_card_wrong_field_count() {
        let _guard = setup_rate_card("zone	500
");
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn test_malformed_rate_card_bad_number() {
        let _guard = setup_rate_card("zone	abc	500
");
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn test_malformed_rate_card_counts_all_lines() {
        let content = "# comment line 1

# line 3
zone	abc	500
";
        let _guard = setup_rate_card(content);
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn test_quote_error_display() {
        assert_eq!(
            format!("{}", QuoteError::RateCardUnavailable),
            "rate card path not set or file unreadable"
        );
        assert_eq!(
            format!("{}", QuoteError::MalformedRateCard { line: 5 }),
            "malformed rate card at line 5"
        );
        assert_eq!(
            format!("{}", QuoteError::UnknownZone("mars".to_string())),
            "unknown zone: mars"
        );
        assert_eq!(
            format!("{}", QuoteError::Overweight { grams: 50000, limit: 20000 }),
            "weight 50000g exceeds limit of 20000g"
        );
    }

    #[test]
    fn test_empty_weight() {
        let _guard = setup_rate_card("zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
");
        let parcel = Parcel {
            weight_grams: 0,
            zone: "domestic".to_string(),
        };
        let quote_result = quote(&parcel).unwrap();
        assert_eq!(quote_result.base_cents, 599);
        assert_eq!(quote_result.band_max_grams, 500);
    }

    #[test]
    fn test_exact_band_match() {
        let _guard = setup_rate_card("zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
");
        let parcel = Parcel {
            weight_grams: 2000,
            zone: "domestic".to_string(),
        };
        let quote_result = quote(&parcel).unwrap();
        assert_eq!(quote_result.base_cents, 899);
        assert_eq!(quote_result.band_max_grams, 2000);
    }

    #[test]
    fn test_just_over_band() {
        let _guard = setup_rate_card("zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
");
        let parcel = Parcel {
            weight_grams: 501,
            zone: "domestic".to_string(),
        };
        let quote_result = quote(&parcel).unwrap();
        assert_eq!(quote_result.base_cents, 899);
        assert_eq!(quote_result.band_max_grams, 2000);
    }

    #[test]
    fn test_rounding_half_up() {
        let _guard = setup_rate_card("zone	band_max_grams	cents
international	500	1498
");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        };
        let result = quote(&parcel).unwrap();
        // 20% of 1498 = 299.6 -> rounded half-up = 300
        assert_eq!(result.surcharge_cents, 300);

        let _guard2 = setup_rate_card("zone	band_max_grams	cents
international	500	1497
");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        };
        let result2 = quote(&parcel).unwrap();
        // 20% of 1497 = 299.4 -> rounded half-up = 299
        assert_eq!(result2.surcharge_cents, 299);
    }

    #[test]
    fn test_with_comment_lines_and_blanks() {
        let content = "# Header comment
zone	band_max_grams	cents

# A blank above
international	5000	2500
";
        let _guard = setup_rate_card(content);
        let parcel = Parcel {
            weight_grams: 3000,
            zone: "international".to_string(),
        };
        let quote_result = quote(&parcel).unwrap();
        assert_eq!(quote_result.base_cents, 2500);
        assert_eq!(quote_result.band_max_grams, 5000);
    }
}
