use std::collections::HashMap;
use std::env;
use std::fs;
use std::sync::RwLock;

use tracing::{info, span, Level};

#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(
                    f,
                    "rate card unavailable: RATECARD_PATH not set or file unreadable"
                )
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "weight {}g exceeds limit {}g", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Clone)]
struct Rate {
    band_max_grams: u32,
    cents: u64,
}

#[derive(Clone)]
struct RateCard {
    rates_by_zone: HashMap<String, Vec<Rate>>,
}

static RATE_CARD_CACHE: RwLock<Option<(String, RateCard)>> = RwLock::new(None);

fn parse_rate_card(content: &str) -> Result<RateCard, QuoteError> {
    let mut rates_by_zone: HashMap<String, Vec<Rate>> = HashMap::new();

    for (idx, line) in content.lines().enumerate() {
        let line_num = idx + 1;

        if line.trim().is_empty() || line.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1].parse().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2].parse().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        rates_by_zone
            .entry(zone)
            .or_insert_with(Vec::new)
            .push(Rate { band_max_grams, cents });
    }

    for rates in rates_by_zone.values_mut() {
        rates.sort_by_key(|r| r.band_max_grams);
    }

    Ok(RateCard { rates_by_zone })
}

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = match env::var("RATECARD_PATH") {
        Ok(p) => p,
        Err(_) => return Err(QuoteError::RateCardUnavailable),
    };

    {
        let cached = RATE_CARD_CACHE.read().unwrap();
        if let Some((cached_path, card)) = &*cached {
            if cached_path == &path {
                let card = card.clone();
                drop(cached);
                return Ok(card);
            }
        }
        drop(cached);
    }

    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = parse_rate_card(&content)?;

    let mut cache = RATE_CARD_CACHE.write().unwrap();
    *cache = Some((path, card.clone()));
    drop(cache);

    Ok(card)
}

fn round_half_up(n: f64) -> u64 {
    (n + 0.5).floor() as u64
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let _span = span!(Level::INFO, "quote", zone = %parcel.zone, weight_grams = parcel.weight_grams);
    let _guard = _span.enter();

    let card = load_rate_card()?;

    let rates = card
        .rates_by_zone
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    if rates.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let mut matching_rate: Option<&Rate> = None;
    for rate in rates.iter() {
        if parcel.weight_grams <= rate.band_max_grams {
            matching_rate = Some(rate);
            break;
        }
    }

    let rate = match matching_rate {
        Some(r) => r,
        None => {
            let max = rates.last().unwrap().band_max_grams;
            return Err(QuoteError::Overweight { grams: parcel.weight_grams, limit: max });
        }
    };

    let base_cents = rate.cents;
    let band_max_grams = rate.band_max_grams;

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let surcharge = round_half_up(base_cents as f64 * 0.20);
        surcharge_cents += surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    let quote = Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    };

    info!(total_cents = quote.total_cents, "quote calculated");

    Ok(quote)
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::NamedTempFile;
    use std::io::Write;

    fn setup_rate_card(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        file
    }

    fn clear_cache() {
        let mut cache = RATE_CARD_CACHE.write().unwrap();
        *cache = None;
    }

    #[test]
    fn test_domestic_under_500g() {
        clear_cache();
        let content = "domestic\t500\t599\ndomestic\t2000\t899";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let result = quote(&parcel).unwrap();

        assert_eq!(result.base_cents, 599);
        assert_eq!(result.surcharge_cents, 0);
        assert_eq!(result.total_cents, 599);
        assert_eq!(result.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_12000g() {
        clear_cache();
        let content = "domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 12000, zone: "domestic".to_string() };
        let result = quote(&parcel).unwrap();

        assert_eq!(result.base_cents, 1799);
        assert_eq!(result.surcharge_cents, 500);
        assert_eq!(result.total_cents, 2299);
        assert_eq!(result.band_max_grams, 20000);
    }

    #[test]
    fn test_international_500g() {
        clear_cache();
        let content = "domestic\t500\t599\ninternational\t500\t1499";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 500, zone: "international".to_string() };
        let result = quote(&parcel).unwrap();

        assert_eq!(result.base_cents, 1499);
        assert_eq!(result.surcharge_cents, 299);
        assert_eq!(result.total_cents, 1798);
        assert_eq!(result.band_max_grams, 500);
    }

    #[test]
    fn test_unknown_zone() {
        clear_cache();
        let content = "domestic\t500\t599";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 100, zone: "jupiter".to_string() };
        let err = quote(&parcel).unwrap_err();

        assert_eq!(err, QuoteError::UnknownZone("jupiter".to_string()));
    }

    #[test]
    fn test_overweight() {
        clear_cache();
        let content = "domestic\t500\t599\ndomestic\t2000\t899";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 50000, zone: "domestic".to_string() };
        let err = quote(&parcel).unwrap_err();

        assert_eq!(err, QuoteError::Overweight { grams: 50000, limit: 2000 });
    }

    #[test]
    fn test_rate_card_unavailable() {
        clear_cache();
        env::remove_var("RATECARD_PATH");

        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let err = quote(&parcel).unwrap_err();

        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn test_malformed_rate_card() {
        clear_cache();
        let content = "domestic\t500\t599\nbad line here\ndomestic\t2000\t899";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let err = quote(&parcel).unwrap_err();

        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 2),
            _ => panic!("expected MalformedRateCard"),
        }
    }

    #[test]
    fn test_malformed_rate_card_invalid_number() {
        clear_cache();
        let content = "domestic\tabc\t599";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let err = quote(&parcel).unwrap_err();

        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            _ => panic!("expected MalformedRateCard"),
        }
    }

    #[test]
    fn test_comment_and_blank_lines_count() {
        clear_cache();
        let content = "# comment\n\ndomestic\t500\t599\n\n# another\nbad";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let err = quote(&parcel).unwrap_err();

        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 6),
            _ => panic!("expected MalformedRateCard"),
        }
    }

    #[test]
    fn test_weight_exactly_at_band() {
        clear_cache();
        let content = "domestic\t500\t599\ndomestic\t2000\t899";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 2000, zone: "domestic".to_string() };
        let result = quote(&parcel).unwrap();

        assert_eq!(result.base_cents, 899);
        assert_eq!(result.band_max_grams, 2000);
    }

    #[test]
    fn test_international_surcharge_rounding() {
        clear_cache();
        let content = "international\t10000\t500";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 5000, zone: "international".to_string() };
        let result = quote(&parcel).unwrap();

        assert_eq!(result.base_cents, 500);
        assert_eq!(result.surcharge_cents, 100);
        assert_eq!(result.total_cents, 600);
    }

    #[test]
    fn test_multiple_surcharges() {
        clear_cache();
        let content = "international\t200000\t1000";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 15000, zone: "international".to_string() };
        let result = quote(&parcel).unwrap();

        assert_eq!(result.base_cents, 1000);
        assert_eq!(result.surcharge_cents, 700);
        assert_eq!(result.total_cents, 1700);
    }
}
