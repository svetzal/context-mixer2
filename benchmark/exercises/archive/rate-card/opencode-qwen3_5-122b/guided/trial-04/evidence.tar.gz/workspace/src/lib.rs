pub mod zones;

use std::error::Error;
use std::fmt;
use std::fs;
use std::sync::Arc;

/// A parcel with weight and zone.
#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A shipping quote with base cost, surcharges, and the matched band.
#[derive(Debug, Clone)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Errors that can occur when calculating a quote.
#[derive(Debug, Clone)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card is unavailable (check RATECARD_PATH)")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {}", zone)
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "weight {}g exceeds limit {}g", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

/// A rate card entry for a zone band.
#[derive(Debug, Clone)]
struct RateEntry {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

#[derive(Debug, Clone)]
struct RateCard {
    entries: Vec<RateEntry>,
}

impl RateCard {
    /// Parse a zone rate card from tab-separated text.
    fn parse(text: &str) -> Result<Self, QuoteError> {
        let mut entries = Vec::new();

        for (idx, line) in text.lines().enumerate() {
            let line_number = idx + 1;

            // Skip empty lines and comments
            if line.is_empty() || line.trim_start().starts_with('#') {
                continue;
            }

            let fields: Vec<&str> = line.split('\t').collect();
            if fields.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: line_number });
            }

            let zone = fields[0].to_string();
            let band_max_grams: u32 = fields[1].parse().map_err(|_| {
                QuoteError::MalformedRateCard { line: line_number }
            })?;
            let cents: u64 = fields[2].parse().map_err(|_| {
                QuoteError::MalformedRateCard { line: line_number }
            })?;

            entries.push(RateEntry {
                zone,
                band_max_grams,
                cents,
            });
        }

        Ok(RateCard { entries })
    }

    /// Get the maximum weight limit for a zone, if it exists.
    fn max_weight_for_zone(&self, zone: &str) -> Option<u32> {
        self.entries
            .iter()
            .filter(|e| e.zone == zone)
            .map(|e| e.band_max_grams)
            .max()
    }

    /// Find the matching band for a zone and weight.
    fn find_rate(&self, zone: &str, weight_grams: u32) -> Option<&RateEntry> {
        self.entries
            .iter()
            .filter(|e| e.zone == zone)
            .filter(|e| e.band_max_grams >= weight_grams)
            .min_by_key(|e| e.band_max_grams)
    }
}

/// Emit a diagnostic record for a quote operation.
/// In production this would wire to a structured logging system.
fn emit_quote_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    use std::io::{self, Write};

    let _ = writeln!(
        io::stderr(),
        "[quote] zone={} weight_grams={} total_cents={}",
        zone,
        weight_grams,
        total_cents
    );
}

/// Calculate a shipping quote for the given parcel.
///
/// Reads the rate card from the `RATECARD_PATH` environment variable.
/// Returns a quote with base cost, surcharges, and the matched band, or an error.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let ratecard_text = Arc::new(
        fs::read_to_string(
            std::env::var("RATECARD_PATH")
                .map_err(|_| QuoteError::RateCardUnavailable)?,
        )
        .map_err(|_| QuoteError::RateCardUnavailable)?,
    );

    let rate_card = RateCard::parse(&ratecard_text)?;

    // Check if zone exists
    let max_limit = rate_card
        .max_weight_for_zone(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    // Check if parcel exceeds the zone's maximum weight
    if parcel.weight_grams > max_limit {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: max_limit,
        });
    }

    // Find the matching rate band
    let entry = rate_card
        .find_rate(&parcel.zone, parcel.weight_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: max_limit,
        })?;

    let base_cents = entry.cents;
    let mut surcharge_cents: u64 = 0;

    // Weight surcharge: 500 cents if weight > 10000 grams
    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    // International surcharge: 20% of base cents, rounded half-up
    if parcel.zone == "international" {
        // Using half-up rounding: (base * 20 + 50) / 100
        let international_surcharge = (base_cents * 20 + 50) / 100;
        surcharge_cents += international_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    let quote = Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: entry.band_max_grams,
    };

    emit_quote_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(quote)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    /// Helper to create a temporary file and return its path.
    fn create_temp_file(content: &str) -> NamedTempFile {
        let mut tmp = NamedTempFile::new().unwrap();
        tmp.write_all(content.as_bytes()).unwrap();
        tmp.flush().unwrap();
        tmp
    }

    #[test]
    fn test_domestic_light_parcel() {
        let content = r#"# zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
domestic	20000	1799
international	500	1499
international	20000	4999
"#;
        let tmp = create_temp_file(content);
        std::env::set_var("RATECARD_PATH", tmp.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".into(),
        };
        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 599);
        assert_eq!(result.surcharge_cents, 0);
        assert_eq!(result.total_cents, 599);
        assert_eq!(result.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_medium_parcel() {
        let content = r#"# zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
domestic	20000	1799
international	500	1499
international	20000	4999
"#;
        let tmp = create_temp_file(content);
        std::env::set_var("RATECARD_PATH", tmp.path());

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".into(),
        };
        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 899);
        assert_eq!(result.surcharge_cents, 0);
        assert_eq!(result.total_cents, 899);
        assert_eq!(result.band_max_grams, 2000);
    }

    #[test]
    fn test_domestic_heavy_parcel_with_weight_surcharge() {
        let content = r#"# zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
domestic	20000	1799
international	500	1499
international	20000	4999
"#;
        let tmp = create_temp_file(content);
        std::env::set_var("RATECARD_PATH", tmp.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".into(),
        };
        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 1799);
        assert_eq!(result.surcharge_cents, 500);
        assert_eq!(result.total_cents, 2299);
        assert_eq!(result.band_max_grams, 20000);
    }

    #[test]
    fn test_international_parcel_with_20_percent_surcharge() {
        let content = r#"# zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
domestic	20000	1799
international	500	1499
international	20000	4999
"#;
        let tmp = create_temp_file(content);
        std::env::set_var("RATECARD_PATH", tmp.path());

        let parcel = Parcel {
            weight_grams: 500,
            zone: "international".into(),
        };
        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 1499);
        // 1499 * 0.2 = 299.8, rounded half-up = 300
        assert_eq!(result.surcharge_cents, 300);
        assert_eq!(result.total_cents, 1799);
        assert_eq!(result.band_max_grams, 500);
    }

    #[test]
    fn test_international_heavy_parcel_with_both_surcharges() {
        let content = r#"# zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
domestic	20000	1799
international	500	1499
international	20000	4999
"#;
        let tmp = create_temp_file(content);
        std::env::set_var("RATECARD_PATH", tmp.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".into(),
        };
        let result = quote(&parcel).unwrap();
        assert_eq!(result.base_cents, 4999);
        // 4999 * 0.2 = 999.8, rounded half-up = 1000
        // Plus 500 for weight > 10000
        assert_eq!(result.surcharge_cents, 1000 + 500);
        assert_eq!(result.total_cents, 4999 + 1500);
        assert_eq!(result.band_max_grams, 20000);
    }

    #[test]
    fn test_unknown_zone() {
        let content = r#"# zone	band_max_grams	cents
domestic	500	599
"#;
        let tmp = create_temp_file(content);
        std::env::set_var("RATECARD_PATH", tmp.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "mars".into(),
        };
        let result = quote(&parcel);
        match result {
            Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "mars"),
            _ => panic!("Expected UnknownZone error"),
        }
    }

    #[test]
    fn test_overweight() {
        let content = r#"# zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
"#;
        let tmp = create_temp_file(content);
        std::env::set_var("RATECARD_PATH", tmp.path());

        let parcel = Parcel {
            weight_grams: 3000,
            zone: "domestic".into(),
        };
        let result = quote(&parcel);
        match result {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 3000);
                assert_eq!(limit, 2000);
            }
            _ => panic!("Expected Overweight error"),
        }
    }

    #[test]
    fn test_rate_card_unavailable() {
        std::env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".into(),
        };
        let result = quote(&parcel);
        match result {
            Err(QuoteError::RateCardUnavailable) => {}
            _ => panic!("Expected RateCardUnavailable error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_wrong_field_count() {
        let content = "domestic\t500\n";
        let tmp = create_temp_file(content);
        std::env::set_var("RATECARD_PATH", tmp.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".into(),
        };
        let result = quote(&parcel);
        match result {
            Err(QuoteError::MalformedRateCard { line }) => {
                assert_eq!(line, 1);
            }
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_malformed_rate_card_invalid_number() {
        let content = "domestic\tabc\t599\n";
        let tmp = create_temp_file(content);
        std::env::set_var("RATECARD_PATH", tmp.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".into(),
        };
        let result = quote(&parcel);
        match result {
            Err(QuoteError::MalformedRateCard { line }) => {
                assert_eq!(line, 1);
            }
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_parse_all_lines_counted_for_malformed() {
        let content = r#"# header comment
domestic	500	599
# another comment

domestic	bad	899
"#;
        let tmp = create_temp_file(content);
        std::env::set_var("RATECARD_PATH", tmp.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".into(),
        };
        let result = quote(&parcel);
        match result {
            Err(QuoteError::MalformedRateCard { line }) => {
                // Line 1: comment, Line 2: valid, Line 3: comment, Line 4: empty, Line 5: bad
                assert_eq!(line, 5);
            }
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_quote_error_display() {
        let err = QuoteError::RateCardUnavailable;
        assert!(!format!("{}", err).is_empty());

        let err = QuoteError::MalformedRateCard { line: 5 };
        assert!(format!("{}", err).contains("5"));

        let err = QuoteError::UnknownZone("mars".into());
        assert!(format!("{}", err).contains("mars"));

        let err = QuoteError::Overweight {
            grams: 5000,
            limit: 2000,
        };
        let msg = format!("{}", err);
        assert!(msg.contains("5000"));
        assert!(msg.contains("2000"));
    }
}
