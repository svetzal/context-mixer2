pub mod zones;

use std::error::Error;
use std::fs;
use std::str::FromStr;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card file unavailable (check RATECARD_PATH env var)")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {}", zone)
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {}g exceeds limit {}g", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

fn parse_rate_card(content: &str) -> Result<Vec<(String, u32, u64)>, QuoteError> {
    let mut rates = Vec::new();

    for (idx, line) in content.lines().enumerate() {
        let line_num = idx + 1;
        let trimmed = line.trim();

        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = trimmed.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].to_string();
        let band_max_grams = u32::from_str(parts[1]).map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = u64::from_str(parts[2]).map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        rates.push((zone, band_max_grams, cents));
    }

    Ok(rates)
}

fn round_half_up(n: f64) -> u64 {
    (n + 0.5).floor() as u64
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let content = fs::read_to_string(&path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let rates = parse_rate_card(&content)?;

    let zone_rates: Vec<&(String, u32, u64)> = rates
        .iter()
        .filter(|(z, _, _)| z == &parcel.zone)
        .collect();

    if zone_rates.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let weight_limit = zone_rates.iter().map(|(_, limit, _)| *limit).max().unwrap_or(0);
    if parcel.weight_grams > weight_limit {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: weight_limit,
        });
    }

    let mut selected_rate: Option<(u32, u64)> = None;
    for (zone, band_max, cents) in &zone_rates {
        if zone != &parcel.zone {
            continue;
        }
        if parcel.weight_grams <= *band_max {
            selected_rate = Some((*band_max, *cents));
            break;
        }
    }

    let (band_max_grams, base_cents) = selected_rate.ok_or_else(|| {
        QuoteError::UnknownZone(parcel.zone.clone())
    })?;

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let twenty_percent = round_half_up(base_cents as f64 * 0.2);
        surcharge_cents += twenty_percent;
    }

    let total_cents = base_cents + surcharge_cents;

    tracing::info!(
        zone = parcel.zone,
        weight = parcel.weight_grams,
        total = total_cents,
        "quote generated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::env;
    use std::fs;
    use tempfile::NamedTempFile;

    fn setup_rate_card(content: &str) -> NamedTempFile {
        let file = NamedTempFile::new().unwrap();
        fs::write(&file, content).unwrap();
        file
    }

    #[test]
    fn test_basic_quote() {
        let content = "domestic\t1000\t500\n";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(result.is_ok());
        let quote = result.unwrap();
        assert_eq!(quote.base_cents, 500);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 500);
        assert_eq!(quote.band_max_grams, 1000);
    }

    #[test]
    fn test_weight_boundary_low() {
        let content = "domestic\t1000\t500\n";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 1,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(result.is_ok());
        assert_eq!(result.unwrap().base_cents, 500);
    }

    #[test]
    fn test_weight_boundary_exact_max() {
        let content = "domestic\t1000\t500\n";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 1000,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(result.is_ok());
        assert_eq!(result.unwrap().base_cents, 500);
    }

    #[test]
    fn test_weight_multiple_bands() {
        let content = "domestic\t500\t300\ndomestic\t1000\t500\ndomestic\t2000\t800\n";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 750,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(result.is_ok());
        let quote = result.unwrap();
        assert_eq!(quote.base_cents, 500);
        assert_eq!(quote.band_max_grams, 1000);
    }

    #[test]
    fn test_heavy_surcharge() {
        let content = "domestic\t20000\t1000\n";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(result.is_ok());
        let quote = result.unwrap();
        assert_eq!(quote.base_cents, 1000);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 1500);
    }

    #[test]
    fn test_heavy_surcharge_exactly_10000() {
        let content = "domestic\t10000\t500\n";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 10000,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(result.is_ok());
        assert_eq!(result.unwrap().surcharge_cents, 0);
    }

    #[test]
    fn test_heavy_surcharge_over_10000() {
        let content = "domestic\t15000\t500\n";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 10001,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(result.is_ok());
        assert_eq!(result.unwrap().surcharge_cents, 500);
    }

    #[test]
    fn test_international_surcharge() {
        let content = "international\t1000\t1000\n";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 500,
            zone: "international".to_string(),
        };

        let result = quote(&parcel);
        assert!(result.is_ok());
        let quote = result.unwrap();
        assert_eq!(quote.base_cents, 1000);
        assert_eq!(quote.surcharge_cents, 200);
        assert_eq!(quote.total_cents, 1200);
    }

    #[test]
    fn test_international_surcharge_rounding_half_up() {
        let content = "international\t1000\t1005\n";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 500,
            zone: "international".to_string(),
        };

        let result = quote(&parcel);
        assert!(result.is_ok());
        let quote = result.unwrap();
        assert_eq!(quote.base_cents, 1005);
        assert_eq!(quote.surcharge_cents, 201);
        assert_eq!(quote.total_cents, 1206);
    }

    #[test]
    fn test_both_surcharges() {
        let content = "international\t20000\t1000\n";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };

        let result = quote(&parcel);
        assert!(result.is_ok());
        let quote = result.unwrap();
        assert_eq!(quote.base_cents, 1000);
        assert_eq!(quote.surcharge_cents, 700);
        assert_eq!(quote.total_cents, 1700);
    }

    #[test]
    fn test_unknown_zone() {
        let content = "domestic\t1000\t500\n";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 500,
            zone: "unknown".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::UnknownZone(z)) if z == "unknown"));
    }

    #[test]
    fn test_overweight() {
        let content = "domestic\t500\t300\n";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 600,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::Overweight { grams, limit }) if grams == 600 && limit == 500));
    }

    #[test]
    fn test_malformed_rate_card_missing_fields() {
        let content = "domestic\t1000\n";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line }) if line == 1));
    }

    #[test]
    fn test_malformed_rate_card_invalid_number() {
        let content = "domestic\tabc\t500\n";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line }) if line == 1));
    }

    #[test]
    fn test_malformed_rate_card_multiple_lines() {
        let content = "domestic\t1000\t500\nbad line\ninternational\t2000\t800\n";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line }) if line == 2));
    }

    #[test]
    fn test_comments_and_empty_lines() {
        let content = "# comment line\ndomestic\t1000\t500\n\n# another comment\n";
        let file = setup_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(result.is_ok());
        assert_eq!(result.unwrap().base_cents, 500);
    }

    #[test]
    fn test_missing_ratecard_file() {
        env::set_var("RATECARD_PATH", "/nonexistent/path/ratecard.txt");

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_missing_ratecard_path_env() {
        env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }
}
