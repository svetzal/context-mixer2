pub mod zones;

use std::collections::BTreeMap;
use std::error::Error;
use std::fmt;
use std::fs;
use std::path::Path;

#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "RATECARD_PATH environment variable not set or unreadable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card line {}", line)
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {}", zone)
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "weight {} grams exceeds limit {} grams", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone)]
struct RateEntry {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

fn parse_ratecard(path: &Path) -> Result<Vec<RateEntry>, QuoteError> {
    let content = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let mut entries = Vec::new();

    for (idx, line) in content.lines().enumerate() {
        let line_number = idx + 1;
        let trimmed = line.trim();

        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = trimmed.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        entries.push(RateEntry {
            zone,
            band_max_grams,
            cents,
        });
    }

    Ok(entries)
}

fn find_rate<'a>(zone: &str, weight: u32, entries: &'a [RateEntry]) -> Result<&'a RateEntry, QuoteError> {
    let zone_entries: Vec<&RateEntry> = entries
        .iter()
        .filter(|e| e.zone == zone)
        .collect();

    if zone_entries.is_empty() {
        return Err(QuoteError::UnknownZone(zone.to_string()));
    }

    let limit = zone_entries.iter().map(|e| e.band_max_grams).max().unwrap();
    if weight > limit {
        return Err(QuoteError::Overweight { grams: weight, limit });
    }

    for entry in zone_entries {
        if weight <= entry.band_max_grams {
            return Ok(entry);
        }
    }

    Err(QuoteError::Overweight { grams: weight, limit })
}

fn calculate_surcharges(base_cents: u64, weight: u32, zone: &str) -> u64 {
    let mut surcharge = 0u64;

    if weight > 10000 {
        surcharge += 500;
    }

    if zone == "international" {
        let twenty_percent = (base_cents as f64 * 0.20).round() as u64;
        surcharge += twenty_percent;
    }

    surcharge
}

fn emit_diagnostic(zone: &str, weight: u32, total: u64) {
    eprintln!("[quote] zone={}, weight_grams={}, total_cents={}", zone, weight, total);
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path_str = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let path = Path::new(&path_str);

    let entries = parse_ratecard(path)?;
    let rate = find_rate(&parcel.zone, parcel.weight_grams, &entries)?;

    let base_cents = rate.cents;
    let surcharge_cents = calculate_surcharges(base_cents, parcel.weight_grams, &parcel.zone);
    let total_cents = base_cents + surcharge_cents;

    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: rate.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs::File;
    use std::io::Write;
    use tempfile::TempDir;

    fn setup_ratecard() -> (TempDir, File) {
        let tmp = TempDir::new().unwrap();
        let path = tmp.path().join("ratecard.tsv");
        let file = File::create(&path).unwrap();
        (tmp, file)
    }

    fn write_ratecard_content(mut file: File, content: &str) -> String {
        write!(file, "{}", content).unwrap();
        drop(file);
        let tmp = TempDir::new().unwrap();
        let path = tmp.path().join("ratecard.tsv");
        File::create(&path).unwrap().write_all(content.as_bytes()).unwrap();
        path.to_string_lossy().to_string()
    }

    #[test]
    fn test_domestic_light() {
        let ratecard_content = "zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\t";
        let path = write_ratecard_content(File::create("/tmp/test_ratecard.tsv").unwrap(), ratecard_content);
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel { weight_grams: 300, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_heavy_surcharges() {
        let ratecard_content = "zone\tband_max_grams\tcents\ndomestic\t20000\t1799\ndomestic\t50000\t2500\t";
        let path = write_ratecard_content(File::create("/tmp/test_ratecard2.tsv").unwrap(), ratecard_content);
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel { weight_grams: 15000, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_international_surcharges() {
        let ratecard_content = "zone\tband_max_grams\tcents\tinternational\t500\t1499\t";
        let path = write_ratecard_content(File::create("/tmp/test_ratecard3.tsv").unwrap(), ratecard_content);
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel { weight_grams: 300, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_unknown_zone() {
        let ratecard_content = "zone\tband_max_grams\tcents\ndomestic\t500\t599\t";
        let path = write_ratecard_content(File::create("/tmp/test_ratecard4.tsv").unwrap(), ratecard_content);
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel { weight_grams: 300, zone: "air".to_string() };
        let result = quote(&parcel);

        assert!(matches!(result, Err(QuoteError::UnknownZone(z)) if z == "air"));
    }

    #[test]
    fn test_overweight() {
        let ratecard_content = "zone\tband_max_grams\tcents\ndomestic\t2000\t899\t";
        let path = write_ratecard_content(File::create("/tmp/test_ratecard5.tsv").unwrap(), ratecard_content);
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel { weight_grams: 5000, zone: "domestic".to_string() };
        let result = quote(&parcel);

        assert!(matches!(result, Err(QuoteError::Overweight { grams: 5000, limit: 2000 })));
    }

    #[test]
    fn test_ratecard_unavailable() {
        std::env::remove_var("RATECARD_PATH");
        let parcel = Parcel { weight_grams: 300, zone: "domestic".to_string() };
        let result = quote(&parcel);

        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_malformed_ratecard() {
        let content = "zone\tband_max_grams\tcents\nbad_line\n";
        let path = write_ratecard_content(File::create("/tmp/test_ratecard6.tsv").unwrap(), content);
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel { weight_grams: 300, zone: "domestic".to_string() };
        let result = quote(&parcel);

        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 2 })));
    }

    #[test]
    fn test_quote_error_display() {
        assert_eq!(format!("{}", QuoteError::RateCardUnavailable), "RATECARD_PATH environment variable not set or unreadable");
        assert_eq!(format!("{}", QuoteError::MalformedRateCard { line: 5 }), "malformed rate card line 5");
        assert_eq!(format!("{}", QuoteError::UnknownZone("test".to_string())), "unknown zone: test");
        assert_eq!(format!("{}", QuoteError::Overweight { grams: 100, limit: 50 }), "weight 100 grams exceeds limit 50 grams");
    }
}
