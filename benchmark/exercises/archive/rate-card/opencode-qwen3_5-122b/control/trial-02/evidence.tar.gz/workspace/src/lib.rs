pub mod zones;

use std::collections::HashMap;
use std::fmt;
use std::fs;
use std::path::Path;

/// A shipping parcel with weight and destination zone.
#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A shipping quote with breakdown of costs.
#[derive(Debug, Clone)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Error types for quote calculation.
#[derive(Debug, Clone)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card not available: check RATECARD_PATH environment variable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Internal representation of a rate card entry.
#[derive(Debug, Clone)]
struct RateEntry {
    band_max_grams: u32,
    cents: u64,
}

/// A parsed rate card mapping zone -> sorted list of (band_max_grams, cents).
#[derive(Debug, Clone)]
struct RateCard(Vec<(String, Vec<RateEntry>)>);

impl RateCard {
    fn from_path(path: &Path) -> Result<Self, QuoteError> {
        let content = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

        let mut zone_entries: HashMap<String, Vec<RateEntry>> = HashMap::new();
        let mut line_number = 0;

        for line in content.lines() {
            line_number += 1;

            // Skip empty lines and comments
            if line.trim().is_empty() || line.starts_with('#') {
                continue;
            }

            // Split by tab
            let parts: Vec<&str> = line.split('\t').collect();
            if parts.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: line_number });
            }

            let zone = parts[0].to_string();
            let band_max_grams: u32 = parts[1]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
            let cents: u64 = parts[2]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

            zone_entries
                .entry(zone)
                .or_default()
                .push(RateEntry {
                    band_max_grams,
                    cents,
                });
        }

        // Sort entries by band_max_grams in ascending order
        for entries in zone_entries.values_mut() {
            entries.sort_by_key(|e| e.band_max_grams);
        }

        Ok(RateCard(
            zone_entries
                .into_iter()
                .map(|(zone, entries)| (zone, entries))
                .collect(),
        ))
    }

    fn find_rate(&self, zone: &str, weight: u32) -> Option<&RateEntry> {
        let zone_entries = self.0.iter().find(|(z, _)| z == zone)?;
        let entries = &zone_entries.1;

        // Find first entry where band_max_grams >= weight
        entries.iter().find(|e| e.band_max_grams >= weight)
    }

    fn max_limit_for_zone(&self, zone: &str) -> Option<u32> {
        let zone_entries = self.0.iter().find(|(z, _)| z == zone)?;
        zone_entries.1.last().map(|e| e.band_max_grams)
    }

    fn zones(&self) -> impl Iterator<Item = &String> {
        self.0.iter().map(|(z, _)| z)
    }
}

/// Diagnostic record emitted for each quote operation.
#[derive(Debug, Clone)]
pub struct QuoteDiagnostic {
    pub zone: String,
    pub weight_grams: u32,
    pub total_cents: u64,
}

/// Calculate a shipping quote for the given parcel.
///
/// Reads the rate card from the path in the RATECARD_PATH environment variable.
/// Returns a quote with base cost, surcharges, and total, or an error if the
/// rate card is unavailable, malformed, the zone is unknown, or the parcel is overweight.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    // Load rate card
    let ratecard_path_str =
        std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let ratecard_path = Path::new(&ratecard_path_str);

    let rate_card = RateCard::from_path(ratecard_path)?;

    // Check if zone exists
    let valid_zones: Vec<_> = rate_card.zones().cloned().collect();
    if !valid_zones.iter().any(|z| z == &parcel.zone) {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    // Find matching rate band
    let entry = rate_card
        .find_rate(&parcel.zone, parcel.weight_grams)
        .ok_or_else(|| {
            let limit = rate_card.max_limit_for_zone(&parcel.zone).unwrap_or(0);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    // Calculate surcharges
    let base_cents = entry.cents;
    let mut surcharge_cents: u64 = 0;

    // Weight surcharge: 500 cents if weight > 10000g
    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    // International surcharge: 20% of base, rounded half-up
    if parcel.zone == "international" {
        let surcharge = (base_cents as f64 * 0.2).round() as u64;
        surcharge_cents += surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    // Emit diagnostic record
    let _diag = QuoteDiagnostic {
        zone: parcel.zone.clone(),
        weight_grams: parcel.weight_grams,
        total_cents,
    };

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: entry.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn create_ratecard_file(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        file
    }

    #[test]
    fn test_domestic_small_parcel() {
        let file = create_ratecard_file(
            "# zone\tband_max_grams\tcents\ndomestic\t500\t599\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_medium_parcel() {
        let file = create_ratecard_file(
            "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_international_surcharge() {
        let file = create_ratecard_file(
            "# zone\tband_max_grams\tcents\n\tinternational\t500\t1499\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 1499);
        // 20% of 1499 = 299.8, rounds to 300
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_weight_surcharge() {
        let file = create_ratecard_file(
            "# zone\tband_max_grams\tcents\n\tdomestic\t20000\t1799\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_combined_surcharges() {
        let file = create_ratecard_file(
            "# zone\tband_max_grams\tcents\n\tinternational\t20000\t4999\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 4999);
        // International: 20% of 4999 = 999.8, rounds to 1000
        // Weight > 10000: 500
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_unknown_zone() {
        let file = create_ratecard_file(
            "# zone\tband_max_grams\tcents\n\tdomestic\t500\t599\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "mars".to_string(),
        };
        let result = quote(&parcel);

        assert!(matches!(result, Err(QuoteError::UnknownZone(z)) if z == "mars"));
    }

    #[test]
    fn test_overweight() {
        let file = create_ratecard_file(
            "# zone\tband_max_grams\tcents\n\tdomestic\t500\t599\n\tdomestic\t2000\t899\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 5000,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);

        assert!(matches!(result, Err(QuoteError::Overweight { grams, limit }) 
            if grams == 5000 && limit == 2000));
    }

    #[test]
    fn test_rate_card_unavailable() {
        std::env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);

        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_malformed_rate_card_wrong_fields() {
        let file = create_ratecard_file(
            "# Comments and empty lines included\n\n\nzone\tband_max_grams\tcents\nbadline\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);

        // "badline" is on line 4 (counting comments and blanks): 1=comment, 2=blank, 3=blank, 4=valid, 5=badline
        // line 1: "# Comments..."
        // line 2: ""
        // line 3: ""
        // line 4: "zone\tband_max_grams\tcents"
        // line 5: "badline"
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line }) if line == 5));
    }

    #[test]
    fn test_malformed_rate_card_bad_number() {
        let file = create_ratecard_file(
            "domestic\tabc\t599\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);

        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line }) if line == 1));
    }

    #[test]
    fn test_zone_label_from_zones_module() {
        assert_eq!(zones::zone_label("domestic"), "Domestic ground");
        assert_eq!(zones::zone_label("international"), "International air");
        assert_eq!(zones::zone_label("mars"), "mars");
    }

    #[test]
    fn test_exact_band_boundary() {
        let file = create_ratecard_file(
            "domestic\t500\t599\n\tdomestic\t2000\t899\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        // Exactly 500g should match the first band
        let parcel_500 = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let quote_500 = quote(&parcel_500).unwrap();
        assert_eq!(quote_500.base_cents, 599);
        assert_eq!(quote_500.band_max_grams, 500);

        // Exactly 2000g should match the second band
        let parcel_2000 = Parcel {
            weight_grams: 2000,
            zone: "domestic".to_string(),
        };
        let quote_2000 = quote(&parcel_2000).unwrap();
        assert_eq!(quote_2000.base_cents, 899);
        assert_eq!(quote_2000.band_max_grams, 2000);
    }

    #[test]
    fn test_weight_at_threshold_boundaries() {
        let file = create_ratecard_file(
            "domestic\t20000\t1799\n",
        );
        std::env::set_var("RATECARD_PATH", file.path());

        // Exactly at 10000g should NOT trigger weight surcharge
        let parcel_at = Parcel {
            weight_grams: 10000,
            zone: "domestic".to_string(),
        };
        let quote_at = quote(&parcel_at).unwrap();
        assert_eq!(quote_at.surcharge_cents, 0);

        // Just over 10000g should trigger weight surcharge
        let parcel_over = Parcel {
            weight_grams: 10001,
            zone: "domestic".to_string(),
        };
        let quote_over = quote(&parcel_over).unwrap();
        assert_eq!(quote_over.surcharge_cents, 500);
    }

    #[test]
    fn test_international_rounding() {
        // Test cases for half-up rounding
        let test_cases = vec![
            (1000u64, 200u64), // 20% of 1000 = 200
            (1005u64, 201u64), // 20% of 1005 = 201
            (1499u64, 300u64), // 20% of 1499 = 299.8 rounds to 300
            (1001u64, 200u64), // 20% of 1001 = 200.2 rounds to 200
        ];

        for (base, expected_surcharge) in test_cases {
            let file = create_ratecard_file(format!(
                "international\t2000\t{}\n",
                base
            ).as_str());
            std::env::set_var("RATECARD_PATH", file.path());

            let parcel = Parcel {
                weight_grams: 1000,
                zone: "international".to_string(),
            };
            let quote = quote(&parcel).unwrap();
            assert_eq!(
                quote.surcharge_cents,
                expected_surcharge,
                "For base {} expected surcharge {} got {}",
                base,
                expected_surcharge,
                quote.surcharge_cents
            );
        }
    }
}
