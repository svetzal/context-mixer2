pub mod zones;

use std::error::Error;
use std::fmt;
use std::fs;

#[derive(Debug)]
pub struct RateEntry {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

#[derive(Debug)]
pub struct RateCard {
    entries: Vec<RateEntry>,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

#[derive(Debug)]
pub struct QuoteDiagnostic {
    pub zone: String,
    pub weight_grams: u32,
    pub total_cents: u64,
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "RATECARD_PATH environment variable not set or rate card unreadable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "Malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "Unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "Weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

fn load_rate_card(path: &str) -> Result<RateCard, QuoteError> {
    let content = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut entries = Vec::new();

    for (idx, line) in content.lines().enumerate() {
        let line_num = idx + 1;

        if line.trim().is_empty() || line.trim().starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].to_string();
        let band_max_grams = parts[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = parts[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        entries.push(RateEntry {
            zone,
            band_max_grams,
            cents,
        });
    }

    Ok(RateCard { entries })
}

fn get_rate_entries<'a>(entries: &'a [RateEntry], zone: &str) -> Vec<&'a RateEntry> {
    entries
        .iter()
        .filter(|e| e.zone == zone)
        .collect()
}



pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;

    let rate_card = load_rate_card(&path)?;

    let zone_entries = get_rate_entries(&rate_card.entries, &parcel.zone);

    if zone_entries.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let mut sorted_entries: Vec<_> = zone_entries;
    sorted_entries.sort_by_key(|e| e.band_max_grams);

    let max_limit = sorted_entries.last().unwrap().band_max_grams;

    if parcel.weight_grams > max_limit {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: max_limit,
        });
    }

    let matching_entry = sorted_entries
        .iter()
        .find(|e| e.band_max_grams >= parcel.weight_grams)
        .unwrap();

    let base_cents = matching_entry.cents;

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let int_surcharge = (base_cents as f64 * 0.20).round() as u64;
        surcharge_cents += int_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    let diagnostic = QuoteDiagnostic {
        zone: parcel.zone.clone(),
        weight_grams: parcel.weight_grams,
        total_cents,
    };
    tracing_diagnostic(&diagnostic);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: matching_entry.band_max_grams,
    })
}

fn tracing_diagnostic(diagnostic: &QuoteDiagnostic) {
    println!(
        "Quote: zone={}, weight_grams={}, total_cents={}",
        diagnostic.zone, diagnostic.weight_grams, diagnostic.total_cents
    );
}

#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs::File;
    use std::io::Write;
    use tempfile::TempDir;

    fn setup_rate_card_file(dir: &TempDir, content: &str) -> String {
        let path = dir.path().join("ratecard.tsv");
        let mut file = File::create(&path).unwrap();
        file.write_all(content.as_bytes()).unwrap();
        path.to_string_lossy().to_string()
    }

    #[test]
    fn test_domestic_light_weight() {
        let dir = TempDir::new().unwrap();
        let path = setup_rate_card_file(
            &dir,
            "# header
domestic\t500\t599
domestic\t2000\t899
",
        );

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        std::env::set_var("RATECARD_PATH", &path);
        let result = quote(&parcel);
        std::env::remove_var("RATECARD_PATH");

        assert!(result.is_ok());
    }

    #[test]
    fn test_quote_basic() {
        let dir = TempDir::new().unwrap();
        let ratecard_path = setup_rate_card_file(
            &dir,
            "# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
",
        );

        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_quote_international_surcharge() {
        let dir = TempDir::new().unwrap();
        let ratecard_path = setup_rate_card_file(
            &dir,
            "# zone\tband_max_grams\tcents
international\t500\t1499
international\t20000\t4999
",
        );

        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_quote_heavy_weight_surcharge() {
        let dir = TempDir::new().unwrap();
        let ratecard_path = setup_rate_card_file(
            &dir,
            "# header comment
domestic\t50000\t2000
",
        );

        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 2000);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2500);

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_quote_overweight() {
        let dir = TempDir::new().unwrap();
        let ratecard_path = setup_rate_card_file(
            &dir,
            "# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
",
        );

        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 5000,
            zone: "domestic".to_string(),
        };

        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 5000);
                assert_eq!(limit, 2000);
            }
            _ => panic!("Expected Overweight error"),
        }

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_quote_unknown_zone() {
        let dir = TempDir::new().unwrap();
        let ratecard_path = setup_rate_card_file(
            &dir,
            "# zone\tband_max_grams\tcents
domestic\t500\t599
",
        );

        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "mystery".to_string(),
        };

        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::UnknownZone(zone) => {
                assert_eq!(zone, "mystery");
            }
            _ => panic!("Expected UnknownZone error"),
        }

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_quote_no_ratecard_path() {
        std::env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let err = quote(&parcel).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn test_quote_malformed_rate_card() {
        let dir = TempDir::new().unwrap();
        let ratecard_path = setup_rate_card_file(
            &dir,
            "# zone\tband_max_grams\tcents
domestic\t500
domestic\t2000\t899
",
        );

        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => {
                assert_eq!(line, 2);
            }
            _ => panic!("Expected MalformedRateCard error"),
        }

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_quote_malformed_rate_card_unparseable_number() {
        let dir = TempDir::new().unwrap();
        let ratecard_path = setup_rate_card_file(
            &dir,
            "# zone\tband_max_grams\tcents
domestic\tabs\t599
",
        );

        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => {
                assert_eq!(line, 2);
            }
            _ => panic!("Expected MalformedRateCard error"),
        }

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_zone_matching_cumulative() {
        let dir = TempDir::new().unwrap();
        let ratecard_path = setup_rate_card_file(
            &dir,
            "# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
",
        );

        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel1 = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let quote1 = quote(&parcel1).unwrap();
        assert_eq!(quote1.base_cents, 599);
        assert_eq!(quote1.band_max_grams, 500);

        let parcel2 = Parcel {
            weight_grams: 501,
            zone: "domestic".to_string(),
        };
        let quote2 = quote(&parcel2).unwrap();
        assert_eq!(quote2.base_cents, 899);
        assert_eq!(quote2.band_max_grams, 2000);

        let parcel3 = Parcel {
            weight_grams: 2000,
            zone: "domestic".to_string(),
        };
        let quote3 = quote(&parcel3).unwrap();
        assert_eq!(quote3.base_cents, 899);
        assert_eq!(quote3.band_max_grams, 2000);

        let parcel4 = Parcel {
            weight_grams: 2001,
            zone: "domestic".to_string(),
        };
        let quote4 = quote(&parcel4).unwrap();
        assert_eq!(quote4.base_cents, 1799);
        assert_eq!(quote4.band_max_grams, 20000);

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_quote_combined_surcharges() {
        let dir = TempDir::new().unwrap();
        let ratecard_path = setup_rate_card_file(
            &dir,
            "# zone\tband_max_grams\tcents
international\t50000\t1000
",
        );

        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1000);
        assert_eq!(quote.surcharge_cents, 700);
        assert_eq!(quote.total_cents, 1700);

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_round_half_up() {
        let dir = TempDir::new().unwrap();
        let ratecard_path = setup_rate_card_file(
            &dir,
            "# zone\tband_max_grams\tcents
international\t500\t15
",
        );

        std::env::set_var("RATECARD_PATH", &ratecard_path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 15);
        assert_eq!(quote.surcharge_cents, 3);

        std::env::remove_var("RATECARD_PATH");
    }
}
