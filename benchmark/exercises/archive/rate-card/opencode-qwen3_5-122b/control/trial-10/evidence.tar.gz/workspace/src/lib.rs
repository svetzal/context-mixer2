mod zones;

use std::error::Error;
use std::fmt;
use std::fs;

#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct RateBand {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

#[derive(Debug)]
pub struct RateCard {
    bands: Vec<RateBand>,
}

#[derive(Debug, Clone)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

struct QuoteDiagnostic {
    zone: String,
    weight_grams: u32,
    total_cents: u64,
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "RATECARD_PATH environment variable is not set or unreadable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "Malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "Unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "Weight {grams}g exceeds maximum {limit}g for this zone")
            }
        }
    }
}

impl Error for QuoteError {}

impl RateCard {
    fn from_path(path: &str) -> Result<Self, QuoteError> {
        let content = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

        let mut bands = Vec::new();

        for (idx, line) in content.lines().enumerate() {
            let line_num = idx + 1;

            if line.trim().is_empty() || line.starts_with('#') {
                continue;
            }

            let parts: Vec<&str> = line.split('\t').collect();

            if parts.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: line_num });
            }

            let zone = parts[0].to_string();
            let band_max_grams: u32 = parts[1]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
            let cents: u64 = parts[2]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

            bands.push(RateBand {
                zone,
                band_max_grams,
                cents,
            });
        }

        if bands.is_empty() {
            return Err(QuoteError::RateCardUnavailable);
        }

        Ok(RateCard { bands })
    }

    fn quote(&self, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let zone_bands: Vec<&RateBand> = self
            .bands
            .iter()
            .filter(|b| b.zone == parcel.zone)
            .collect();

        if zone_bands.is_empty() {
            return Err(QuoteError::UnknownZone(parcel.zone.clone()));
        }

        let mut sorted_bands = zone_bands;
        sorted_bands.sort_by_key(|b| b.band_max_grams);

        let max_limit = sorted_bands
            .last()
            .map(|b| b.band_max_grams)
            .unwrap_or(0);

        if parcel.weight_grams > max_limit {
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: max_limit,
            });
        }

        let base_band = sorted_bands
            .iter()
            .find(|b| parcel.weight_grams <= b.band_max_grams)
            .unwrap();

        let base_cents = base_band.cents;
        let band_max_grams = base_band.band_max_grams;

        let mut surcharge_cents: u64 = 0;

        if parcel.weight_grams > 10000 {
            surcharge_cents += 500;
        }

        if parcel.zone == "international" {
            let int_surcharge = (base_cents as f64 * 0.2).round() as u64;
            surcharge_cents += int_surcharge;
        }

        let total_cents = base_cents + surcharge_cents;

        emit_diagnostic(QuoteDiagnostic {
            zone: parcel.zone.clone(),
            weight_grams: parcel.weight_grams,
            total_cents,
        });

        Ok(Quote {
            base_cents,
            surcharge_cents,
            total_cents,
            band_max_grams,
        })
    }
}

fn emit_diagnostic(diagnostic: QuoteDiagnostic) {
    eprintln!(
        "[quote] zone={} weight={}g total={}c",
        diagnostic.zone, diagnostic.weight_grams, diagnostic.total_cents
    );
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let rate_card = RateCard::from_path(&path)?;
    rate_card.quote(parcel)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn setup_ratecard(content: &str) -> (NamedTempFile, String) {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        let path = file.path().to_str().unwrap().to_string();
        (file, path)
    }

    #[test]
    fn test_domestic_light() {
        let content = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n";
        let (_file, ratecard_path) = setup_ratecard(content);

        std::env::set_var("RATECARD_PATH", &ratecard_path);
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_medium() {
        let content = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n";
        let (_file, ratecard_path) = setup_ratecard(content);

        std::env::set_var("RATECARD_PATH", &ratecard_path);
        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_domestic_heavy_over_10kg() {
        let content = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n";
        let (_file, ratecard_path) = setup_ratecard(content);

        std::env::set_var("RATECARD_PATH", &ratecard_path);
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_international_light() {
        let content = "# zone\tband_max_grams\tcents\ninternational\t500\t1499\ninternational\t20000\t4999\n";
        let (_file, ratecard_path) = setup_ratecard(content);

        std::env::set_var("RATECARD_PATH", &ratecard_path);
        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_international_heavy_over_10kg() {
        let content = "# zone\tband_max_grams\tcents\ninternational\t500\t1499\ninternational\t20000\t4999\n";
        let (_file, ratecard_path) = setup_ratecard(content);

        std::env::set_var("RATECARD_PATH", &ratecard_path);
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_unknown_zone() {
        let content = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\n";
        let (_file, ratecard_path) = setup_ratecard(content);

        std::env::set_var("RATECARD_PATH", &ratecard_path);
        let parcel = Parcel {
            weight_grams: 300,
            zone: "unknown".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::UnknownZone(z)) if z == "unknown"));
    }

    #[test]
    fn test_overweight() {
        let content = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\n";
        let (_file, ratecard_path) = setup_ratecard(content);

        std::env::set_var("RATECARD_PATH", &ratecard_path);
        let parcel = Parcel {
            weight_grams: 5000,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::Overweight { grams: 5000, limit: 2000 })));
    }

    #[test]
    fn test_malformed_ratecard_wrong_fields() {
        let content = "# zone\tband_max_grams\tcents\ndomestic\t500\ndomestic\t2000\t899\n";
        let (_file, ratecard_path) = setup_ratecard(content);

        std::env::set_var("RATECARD_PATH", &ratecard_path);
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 2 })));
    }

    #[test]
    fn test_malformed_ratecard_bad_numbers() {
        let content = "# zone\tband_max_grams\tcents\ndomestic\tabc\t899\n";
        let (_file, ratecard_path) = setup_ratecard(content);

        std::env::set_var("RATECARD_PATH", &ratecard_path);
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 2 })));
    }

    #[test]
    fn test_weight_at_exact_band_boundary() {
        let content = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\n";
        let (_file, ratecard_path) = setup_ratecard(content);

        std::env::set_var("RATECARD_PATH", &ratecard_path);
        let parcel = Parcel {
            weight_grams: 2000,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_empty_lines_and_comments_ignored_for_malform_count() {
        let content = "# Header comment line 1\n\ndomestic\t500\t599\n\ndomestic\tinvalid\t899\n";
        let (_file, ratecard_path) = setup_ratecard(content);

        std::env::set_var("RATECARD_PATH", &ratecard_path);
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line: 5 })));
    }

    #[test]
    fn test_ratecard_unavailable() {
        std::env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_error_display() {
        let error = QuoteError::UnknownZone("mars".to_string());
        assert!(error.to_string().contains("mars"));

        let error = QuoteError::Overweight {
            grams: 50000,
            limit: 20000,
        };
        assert!(error.to_string().contains("50000"));

        let error = QuoteError::MalformedRateCard { line: 10 };
        assert!(error.to_string().contains("10"));
    }
}
