pub mod zones;

use std::error::Error;
use std::fmt;
use std::path::Path;
use std::sync::OnceLock;

#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card path not configured or unreadable"),
            QuoteError::MalformedRateCard { line } => write!(f, "malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "weight {}g exceeds limit {}g", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone)]
struct RateEntry {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

fn parse_rate_card(content: &str) -> Result<Vec<RateEntry>, QuoteError> {
    let mut entries = Vec::new();
    for (idx, line) in content.lines().enumerate() {
        let line_num = idx + 1;
        if line.trim().is_empty() || line.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1].parse().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2].parse().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        entries.push(RateEntry { zone, band_max_grams, cents });
    }
    Ok(entries)
}

fn compute_quote(entries: &[RateEntry], parcel: &Parcel) -> Result<Quote, QuoteError> {
    let mut zone_entries: Vec<&RateEntry> = entries
        .iter()
        .filter(|e| e.zone == parcel.zone)
        .collect();

    if zone_entries.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_entries.sort_by_key(|e| e.band_max_grams);

    let max_band = zone_entries.last().unwrap();
    if parcel.weight_grams > max_band.band_max_grams {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: max_band.band_max_grams,
        });
    }

    let matching = zone_entries
        .iter()
        .find(|e| e.band_max_grams >= parcel.weight_grams)
        .unwrap();

    let mut base_cents = matching.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let intl_surcharge = (base_cents as f64 * 0.2).round() as u64;
        surcharge_cents += intl_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: matching.band_max_grams,
    })
}

fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    DIAGNOSTIC_LOG
        .set()
        .ok()
        .and_then(|log| log.lock().ok())
        .map(|mut guard| guard.push((zone.to_string(), weight_grams, total_cents)));
}

static DIAGNOSTIC_LOG: OnceLock<std::sync::Mutex<Vec<(String, u32, u64)>>> = OnceLock::new();

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = std::fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let entries = parse_rate_card(&content)?;
    compute_quote(&entries, parcel)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use tempfile::NamedTempFile;
    use std::io::Write;

    fn setup() -> NamedTempFile {
        let content = r#"# zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
domestic	20000	1799
international	500	1499
international	20000	4999
"#;
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        file
    }

    #[test]
    fn test_domestic_under_500g() {
        let file = setup();
        std::env::set_var("RATECARD_PATH", file.path());
        let parcel = Parcel {
            weight_grams: 400,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_at_500g() {
        let file = setup();
        std::env::set_var("RATECARD_PATH", file.path());
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_between_bands() {
        let file = setup();
        std::env::set_var("RATECARD_PATH", file.path());
        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_domestic_over_10000g_surcharged() {
        let file = setup();
        std::env::set_var("RATECARD_PATH", file.path());
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_international_under_500g() {
        let file = setup();
        std::env::set_var("RATECARD_PATH", file.path());
        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1499);
        let expected_surcharge = (1499 as f64 * 0.2).round() as u64;
        assert_eq!(quote.surcharge_cents, expected_surcharge);
        assert_eq!(quote.total_cents, 1499 + expected_surcharge);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_international_over_10000g_double_surcharge() {
        let file = setup();
        std::env::set_var("RATECARD_PATH", file.path());
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 4999);
        let intl_surcharge = (4999 as f64 * 0.2).round() as u64;
        assert_eq!(quote.surcharge_cents, intl_surcharge + 500);
        assert_eq!(quote.total_cents, 4999 + intl_surcharge + 500);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_unknown_zone() {
        let file = setup();
        std::env::set_var("RATECARD_PATH", file.path());
        let parcel = Parcel {
            weight_grams: 300,
            zone: "moon".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::UnknownZone(z) => assert_eq!(z, "moon"),
            _ => panic!("Expected UnknownZone"),
        }
    }

    #[test]
    fn test_overweight() {
        let file = setup();
        std::env::set_var("RATECARD_PATH", file.path());
        let parcel = Parcel {
            weight_grams: 50000,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 50000);
                assert_eq!(limit, 20000);
            }
            _ => panic!("Expected Overweight"),
        }
    }

    #[test]
    fn test_missing_env() {
        std::env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::RateCardUnavailable => {}
            _ => panic!("Expected RateCardUnavailable"),
        }
    }

    #[test]
    fn test_malformed_rate_card_too_few_fields() {
        let content = "zone\t500\n";
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        std::env::set_var("RATECARD_PATH", file.path());
        let parcel = Parcel {
            weight_grams: 300,
            zone: "zone".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            _ => panic!("Expected MalformedRateCard"),
        }
    }

    #[test]
    fn test_malformed_rate_card_bad_number() {
        let content = "zone\tabc\t500\n";
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        std::env::set_var("RATECARD_PATH", file.path());
        let parcel = Parcel {
            weight_grams: 300,
            zone: "zone".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            _ => panic!("Expected MalformedRateCard"),
        }
    }

    #[test]
    fn test_malformed_rate_card_line_counting() {
        let content = "# comment\n\n# another\nzone\tabc\t500\n";
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        std::env::set_var("RATECARD_PATH", file.path());
        let parcel = Parcel {
            weight_grams: 300,
            zone: "zone".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 4),
            _ => panic!("Expected MalformedRateCard"),
        }
    }

    #[test]
    fn test_diagnostic_log() {
        let file = setup();
        std::env::set_var("RATECARD_PATH", file.path());
        DIAGNOSTIC_LOG.get_or_init(|| std::sync::Mutex::new(Vec::new()));
        
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        quote(&parcel).unwrap();

        let log = DIAGNOSTIC_LOG.get().unwrap().lock().unwrap();
        assert_eq!(log.len(), 1);
        assert_eq!(log[0].0, "domestic");
        assert_eq!(log[0].1, 500);
        assert_eq!(log[0].2, 599);
    }
}
