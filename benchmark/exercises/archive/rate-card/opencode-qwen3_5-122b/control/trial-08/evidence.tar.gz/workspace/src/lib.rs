use std::collections::BTreeMap;
use std::fmt;

/// A shipping package.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A shipping quote.
#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Errors that can occur when calculating a quote.
#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable (set RATECARD_PATH)")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "weight {grams}g exceeds limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// A single rate card entry.
struct RateEntry {
    band_max_grams: u32,
    cents: u64,
}

/// Parse the rate card file.
fn parse_ratecard(content: &str) -> Result<BTreeMap<String, Vec<RateEntry>>, QuoteError> {
    let mut rates: BTreeMap<String, Vec<RateEntry>> = BTreeMap::new();

    for (idx, line) in content.lines().enumerate() {
        let line_num = idx + 1; // 1-based line numbers

        // Skip empty lines and comments
        if line.trim().is_empty() || line.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        rates
            .entry(zone)
            .or_insert_with(Vec::new)
            .push(RateEntry { band_max_grams, cents });
    }

    // Sort each zone's rates by band_max_grams
    for entries in rates.values_mut() {
        entries.sort_by_key(|e| e.band_max_grams);
    }

    Ok(rates)
}

/// Emit a diagnostic record for the quote operation.
fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    println!(
        "[QUOTE] zone={} weight_grams={} total_cents={}",
        zone, weight_grams, total_cents
    );
}

/// Calculate a shipping quote for a parcel.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let ratecard_path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let content = std::fs::read_to_string(&ratecard_path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let rates = parse_ratecard(&content)?;

    let zone_entries = rates
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    // Find the matching band (first whose band_max_grams >= weight)
    let mut matching_entry: Option<&RateEntry> = None;
    let mut max_limit = 0u32;

    for entry in zone_entries {
        max_limit = max_limit.max(entry.band_max_grams);
        if entry.band_max_grams >= parcel.weight_grams {
            matching_entry = Some(entry);
            break;
        }
    }

    let entry = matching_entry.ok_or_else(|| QuoteError::Overweight {
        grams: parcel.weight_grams,
        limit: max_limit,
    })?;

    let base_cents = entry.cents;
    let mut surcharge_cents: u64 = 0;

    // Weight surcharge: +500 cents if weight > 10000g
    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    // International surcharge: 20% of base, rounded half-up
    if parcel.zone == "international" {
        // 20% rounded half-up: (base * 20 + 50) / 100
        let intl_surcharge = (base_cents * 20 + 50) / 100;
        surcharge_cents += intl_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    // Emit diagnostic
    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: entry.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use tempfile::NamedTempFile;

    fn create_test_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        fs::write(&file, content).unwrap();
        file
    }

    #[test]
    fn test_domestic_light() {
        let ratecard = create_test_ratecard(
            "# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799",
        );

        std::env::set_var("RATECARD_PATH", ratecard.path());
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_medium() {
        let ratecard = create_test_ratecard(
            "domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799",
        );

        std::env::set_var("RATECARD_PATH", ratecard.path());
        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_domestic_heavy() {
        let ratecard = create_test_ratecard(
            "domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799",
        );

        std::env::set_var("RATECARD_PATH", ratecard.path());
        let parcel = Parcel {
            weight_grams: 10000,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 1799);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_domestic_overweight() {
        let ratecard = create_test_ratecard(
            "domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799",
        );

        std::env::set_var("RATECARD_PATH", ratecard.path());
        let parcel = Parcel {
            weight_grams: 25000,
            zone: "domestic".to_string(),
        };

        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 25000);
                assert_eq!(limit, 20000);
            }
            _ => panic!("Expected Overweight error"),
        }
    }

    #[test]
    fn test_international_light() {
        let ratecard = create_test_ratecard(
            "international\t500\t1499
international\t20000\t4999",
        );

        std::env::set_var("RATECARD_PATH", ratecard.path());
        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        // base: 1499, 20% = 299.8 -> 300 (rounded half-up)
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_international_heavy_with_weight_surcharge() {
        let ratecard = create_test_ratecard(
            "international\t500\t1499
international\t20000\t4999",
        );

        std::env::set_var("RATECARD_PATH", ratecard.path());
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        // base: 4999, 20% = 999.8 -> 1000, weight surcharge: 500
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_unknown_zone() {
        let ratecard = create_test_ratecard(
            "domestic\t500\t599
domestic\t20000\t1799",
        );

        std::env::set_var("RATECARD_PATH", ratecard.path());
        let parcel = Parcel {
            weight_grams: 300,
            zone: "mars".to_string(),
        };

        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::UnknownZone(zone) => assert_eq!(zone, "mars"),
            _ => panic!("Expected UnknownZone error"),
        }
    }

    #[test]
    fn test_missing_ratecard_path() {
        std::env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let err = quote(&parcel).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn test_malformed_ratecard_wrong_fields() {
        let ratecard = create_test_ratecard(
            "domestic\t500\t599
bad_line\ttoo
domestic\t2000\t899",
        );

        std::env::set_var("RATECARD_PATH", ratecard.path());
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 2),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_malformed_ratecard_bad_number() {
        let ratecard = create_test_ratecard(
            "domestic\t500\t599
domestic\tabc\t899",
        );

        std::env::set_var("RATECARD_PATH", ratecard.path());
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 2),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_comments_and_blanks_ignored() {
        let ratecard = create_test_ratecard(
            "# comment line
domestic\t500\t599

domestic\t2000\t899
# another comment",
        );

        std::env::set_var("RATECARD_PATH", ratecard.path());
        let parcel = Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
    }

    #[test]
    fn test_malformed_line_number_counts_comments_and_blanks() {
        let ratecard = create_test_ratecard(
            "# comment line 1
# comment line 2

bad_line
domestic\t500\t599",
        );

        std::env::set_var("RATECARD_PATH", ratecard.path());
        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let err = quote(&parcel).unwrap_err();
        // Line 4 is the malformed line (1-based, counting all lines)
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 4),
            _ => panic!("Expected MalformedRateCard error"),
        }
    }

    #[test]
    fn test_overweight_domestic() {
        let ratecard = create_test_ratecard(
            "domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799",
        );

        std::env::set_var("RATECARD_PATH", ratecard.path());
        let parcel = Parcel {
            weight_grams: 30000,
            zone: "domestic".to_string(),
        };

        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 30000);
                assert_eq!(limit, 20000);
            }
            _ => panic!("Expected Overweight error"),
        }
    }

    #[test]
    fn test_weight_surcharge_threshold() {
        // Exactly at threshold - no surcharge
        let ratecard = create_test_ratecard(
            "domestic\t500\t599
domestic\t10000\t1799",
        );

        std::env::set_var("RATECARD_PATH", ratecard.path());
        let parcel = Parcel {
            weight_grams: 10000,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.surcharge_cents, 0);

        // Just over threshold - surcharge applies
        let parcel2 = Parcel {
            weight_grams: 10001,
            zone: "domestic".to_string(),
        };

        let quote2 = quote(&parcel2).unwrap();
        assert_eq!(quote2.surcharge_cents, 500);
    }

    #[test]
    fn test_display_and_error_trait() {
        let err = QuoteError::RateCardUnavailable;
        assert!(!format!("{}", err).is_empty());
        assert!(std::error::Error::source(&err).is_none());

        let err = QuoteError::UnknownZone("moon".to_string());
        assert!(format!("{}", err).contains("moon"));

        let err = QuoteError::MalformedRateCard { line: 42 };
        assert!(format!("{}", err).contains("42"));

        let err = QuoteError::Overweight {
            grams: 5000,
            limit: 3000,
        };
        assert!(format!("{}", err).contains("5000"));
        assert!(format!("{}", err).contains("3000"));
    }
}
