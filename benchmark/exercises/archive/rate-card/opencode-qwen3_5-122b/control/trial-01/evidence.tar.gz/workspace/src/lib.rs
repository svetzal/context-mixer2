mod zones;

use std::error::Error;
use std::fmt::{self, Display};
use std::fs;
use std::path::Path;

#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {}g exceeds limit {}g", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone)]
struct RateEntry {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

#[derive(Debug, Clone)]
struct RateCard {
    entries: Vec<RateEntry>,
}

impl RateCard {
    fn from_path(path: &Path) -> Result<Self, QuoteError> {
        let content = fs::read_to_string(path)
            .map_err(|_| QuoteError::RateCardUnavailable)?;

        let mut entries = Vec::new();

        for (line_idx, line) in content.lines().enumerate() {
            let line_num = line_idx + 1;

            let trimmed = line.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }

            let parts: Vec<&str> = trimmed.split('\t').collect();
            if parts.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: line_num });
            }

            let zone = parts[0].to_string();
            let band_max_grams: u32 = parts[1]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
            let cents: u64 = parts[2]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

            entries.push(RateEntry {
                zone,
                band_max_grams,
                cents,
            });
        }

        Ok(RateCard { entries })
    }

    fn find_quote(&self, zone: &str, weight_grams: u32) -> Result<Quote, QuoteError> {
        let zone_entries: Vec<_> = self
            .entries
            .iter()
            .filter(|e| e.zone == zone)
            .collect();

        if zone_entries.is_empty() {
            return Err(QuoteError::UnknownZone(zone.to_string()));
        }

        let mut sorted_entries: Vec<_> = zone_entries;
        sorted_entries.sort_by_key(|e| e.band_max_grams);

        let max_limit = sorted_entries
            .last()
            .map(|e| e.band_max_grams)
            .unwrap_or(0);

        if weight_grams > max_limit {
            return Err(QuoteError::Overweight {
                grams: weight_grams,
                limit: max_limit,
            });
        }

        let mut base_cents: u64 = 0;
        let mut band_max_grams: u32 = 0;

        for entry in sorted_entries {
            if entry.band_max_grams >= weight_grams {
                base_cents = entry.cents;
                band_max_grams = entry.band_max_grams;
                break;
            }
        }

        let mut surcharge_cents: u64 = 0;

        if weight_grams > 10000 {
            surcharge_cents += 500;
        }

        if zone == "international" {
            let intl_surcharge: u64 =
                ((base_cents as f64 * 0.2).round() as u64);
            surcharge_cents += intl_surcharge;
        }

        let total_cents = base_cents + surcharge_cents;

        Ok(Quote {
            base_cents,
            surcharge_cents,
            total_cents,
            band_max_grams,
        })
    }
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)
        .and_then(|p| std::path::PathBuf::from(p).canonicalize().map_err(|_| QuoteError::RateCardUnavailable))?;

    let ratecard = RateCard::from_path(&path)?;
    let quote = ratecard.find_quote(&parcel.zone, parcel.weight_grams)?;

    emit_diagnostic(&parcel.zone, parcel.weight_grams, quote.total_cents);

    Ok(quote)
}

fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    let label = zones::zone_label(zone);
    eprintln!(
        "[quote] zone={} label=\"{}\" weight_grams={} total_cents={}",
        zone, label, weight_grams, total_cents
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs::File;
    use std::io::Write;
    use tempfile::TempDir;

    fn create_ratecard_file(dir: &TempDir, content: &str) -> File {
        let path = dir.path().join("ratecard.tsv");
        File::create(&path).unwrap();
        let mut file = File::create(&path).unwrap();
        file.write_all(content.as_bytes()).unwrap();
        path
    }

    const SAMPLE_RATECARD: &str = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\ninternational\t500\t1499\ninternational\t20000\t4999\n";

    #[test]
    fn test_domestic_under_500g() {
        let (path, _tmp) = write_temp_ratecard("# zone\tband_max_grams\tcents\ndomestic\t500\t599\n");

        set_env(&path);
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
    }

    #[test]
    fn test_domestic_501g() {
        let (path, _tmp) = write_temp_ratecard(SAMPLE_RATECARD);

        set_env(&path);
        let parcel = Parcel {
            weight_grams: 501,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
        assert_eq!(quote.total_cents, 899);
    }

    #[test]
    fn test_international_base() {
        let (path, _tmp) = write_temp_ratecard(SAMPLE_RATECARD);

        set_env(&path);
        let parcel = Parcel {
            weight_grams: 500,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn test_international_over_10000g() {
        let (path, _tmp) = write_temp_ratecard(SAMPLE_RATECARD);

        set_env(&path);
        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1499);
        assert_eq!(quote.total_cents, 6498);
    }

    #[test]
    fn test_overweight() {
        let (path, _tmp) = write_temp_ratecard(SAMPLE_RATECARD);

        set_env(&path);
        let parcel = Parcel {
            weight_grams: 25000,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 25000);
                assert_eq!(limit, 20000);
            }
            _ => panic!("expected Overweight error"),
        }
    }

    #[test]
    fn test_unknown_zone() {
        let (path, _tmp) = write_temp_ratecard(SAMPLE_RATECARD);

        set_env(&path);
        let parcel = Parcel {
            weight_grams: 500,
            zone: "antarctic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::UnknownZone(zone) => {
                assert_eq!(zone, "antarctic");
            }
            _ => panic!("expected UnknownZone error"),
        }
    }

    #[test]
    fn test_ratecard_unavailable() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn test_malformed_ratecard() {
        let (path, _tmp) = write_temp_ratecard(
            "# zone\tband_max_grams\tcents\ndomestic\t500\n",
        );

        set_env(&path);
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };
        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => {
                assert_eq!(line, 2);
            }
            _ => panic!("expected MalformedRateCard error"),
        }
    }

    fn write_temp_ratecard(content: &str) -> (String, TempDir) {
        let tmp = TempDir::new().unwrap();
        let path = tmp.path().join("ratecard.tsv");
        File::create(&path).unwrap();
        let mut file = File::create(&path).unwrap();
        file.write_all(content.as_bytes()).unwrap();
        (path.to_string_lossy().to_string(), tmp)
    }

    fn set_env(path: &String) {
        env::set_var("RATECARD_PATH", path);
    }
}
