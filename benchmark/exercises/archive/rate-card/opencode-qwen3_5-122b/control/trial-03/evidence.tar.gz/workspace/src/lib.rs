mod zones;

use std::collections::BTreeMap;
use std::env;
use std::fmt;
use std::fs;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "RATECARD_PATH environment variable not set or unreadable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "Malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "Unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "Parcel weight {grams}g exceeds limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct RateEntry {
    band_max_grams: u32,
    cents: u64,
}

fn parse_ratecard(path: &str) -> Result<BTreeMap<String, Vec<RateEntry>>, QuoteError> {
    let content = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut map: BTreeMap<String, Vec<RateEntry>> = BTreeMap::new();

    for (idx, line) in content.lines().enumerate() {
        let line_num = idx + 1;

        if line.trim().is_empty() || line.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].to_string();
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        map.entry(zone)
            .or_insert_with(Vec::new)
            .push(RateEntry {
                band_max_grams,
                cents,
            });
    }

    for entries in map.values_mut() {
        entries.sort_by_key(|e| e.band_max_grams);
    }

    Ok(map)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let ratecard = parse_ratecard(&path)?;

    let entries = ratecard.get(&parcel.zone).ok_or_else(|| {
        QuoteError::UnknownZone(parcel.zone.clone())
    })?;

    let mut matching: Option<&RateEntry> = None;
    let mut max_limit: u32 = 0;

    for entry in entries.iter() {
        max_limit = max_limit.max(entry.band_max_grams);
        if entry.band_max_grams >= parcel.weight_grams {
            matching = Some(entry);
            break;
        }
    }

    let entry = matching.ok_or_else(|| QuoteError::Overweight {
        grams: parcel.weight_grams,
        limit: max_limit,
    })?;

    let base_cents = entry.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let cents_times_10: u64 = base_cents * 20;
        let int_cents = (cents_times_10 + 5) / 10;
        surcharge_cents += int_cents;
    }

    let total_cents = base_cents + surcharge_cents;

    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: entry.band_max_grams,
    })
}

fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!("[quote] zone={zone} weight_grams={weight_grams} total_cents={total_cents}");
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn create_ratecard_file(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        file.flush().unwrap();
        file
    }

    #[test]
    fn test_domestic_under_500g() {
        let file = create_ratecard_file(
            "# zone\tband_max_grams\tcents\ndomestic\t500\t599\n"
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 400,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_over_10000g() {
        let file = create_ratecard_file(
            "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t10000\t1299\ndomestic\t20000\t1799\n"
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_international_with_surcharge() {
        let file = create_ratecard_file(
            "# zone\tband_max_grams\tcents\ninternational\t500\t1499\n"
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 299);
        assert_eq!(quote.total_cents, 1798);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_international_over_10000g() {
        let file = create_ratecard_file(
            "# zone\tband_max_grams\tcents\ninternational\t5000\t4000\ninternational\t20000\t4999\n"
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };
        let quote = quote(&parcel).unwrap();

        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1499);
        assert_eq!(quote.total_cents, 6498);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn test_unknown_zone() {
        let file = create_ratecard_file(
            "# zone\tband_max_grams\tcents\ndomestic\t500\t599\n"
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "mars".to_string(),
        };
        let result = quote(&parcel);

        assert!(matches!(result, Err(QuoteError::UnknownZone(z)) if z == "mars"));
    }

    #[test]
    fn test_overweight() {
        let file = create_ratecard_file(
            "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t8000\t999\n"
        );
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 12000,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);

        assert!(matches!(result, Err(QuoteError::Overweight { grams, limit })
            if grams == 12000 && limit == 8000));
    }

    #[test]
    fn test_rate_card_unavailable() {
        env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);

        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_malformed_rate_card_line_count() {
        let content = "# comment line\n\ndomestic\t500\tbad\n";
        let file = create_ratecard_file(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);

        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line }) if line == 3));
    }

    #[test]
    fn test_malformed_rate_card_wrong_field_count() {
        let content = "domestic extra\t500\t599\textra\n";
        let file = create_ratecard_file(content);
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };
        let result = quote(&parcel);

        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line }) if line == 1));
    }
}
