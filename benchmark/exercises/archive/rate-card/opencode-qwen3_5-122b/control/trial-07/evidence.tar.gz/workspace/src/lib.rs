pub mod zones;

use std::collections::HashMap;
use std::error::Error;
use std::fmt;
use std::fs;
use std::path::Path;

/// A shipping parcel with weight and destination zone.
#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A shipping quote with pricing details.
#[derive(Debug, Clone)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Errors that can occur during quote calculation.
#[derive(Debug, Clone)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable: RATECARD_PATH not set or unreadable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {}", zone)
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {}g exceeds limit {}g", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

/// Diagnostic record emitted for each quote calculation.
#[derive(Debug)]
pub struct QuoteDiagnostic {
    pub zone: String,
    pub weight_grams: u32,
    pub total_cents: u64,
}

/// Rate card entry for a zone band.
#[derive(Debug, Clone)]
struct RateEntry {
    band_max_grams: u32,
    cents: u64,
}

/// Parse the rate card file and return zone → sorted (band_max_grams, cents) map.
fn parse_rate_card(path: &Path) -> Result<HashMap<String, Vec<RateEntry>>, QuoteError> {
    let content = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let mut zones: HashMap<String, Vec<RateEntry>> = HashMap::new();

    for (line_idx, line) in content.lines().enumerate() {
        let line_num = line_idx + 1;

        // Skip empty lines and comments
        if line.trim().is_empty() || line.trim().starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].trim().to_string();
        let band_max_grams: u32 = parts[1].trim().parse::<u32>().map_err(|_| {
            QuoteError::MalformedRateCard { line: line_num }
        })?;
        let cents: u64 = parts[2].trim().parse::<u64>().map_err(|_| {
            QuoteError::MalformedRateCard { line: line_num }
        })?;

        let entry = RateEntry {
            band_max_grams,
            cents,
        };

        zones
            .entry(zone)
            .and_modify(|entries: &mut Vec<RateEntry>| entries.push(entry.clone()))
            .or_insert_with(|| vec![entry]);
    }

    // Sort each zone's bands by band_max_grams ascending
    for entries in zones.values_mut() {
        entries.sort_by_key(|e| e.band_max_grams);
    }

    Ok(zones)
}

/// Calculate the 20% surcharge for international, rounded half-up.
fn round_half_up(numerator: u64, denominator: u64) -> u64 {
    (numerator + denominator / 2) / denominator
}

/// Calculate a shipping quote for a parcel.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path_str = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let path = Path::new(&path_str);

    let zones = parse_rate_card(path)?;

    let zone_entries = zones.get(&parcel.zone).ok_or_else(|| {
        QuoteError::UnknownZone(parcel.zone.clone())
    })?;

    if zone_entries.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    // Find the first band where weight <= band_max_grams
    let mut matching_entry: Option<&RateEntry> = None;
    let mut max_limit = 0u32;

    for entry in zone_entries.iter() {
        max_limit = entry.band_max_grams;
        if parcel.weight_grams <= entry.band_max_grams {
            matching_entry = Some(entry);
            break;
        }
    }

    let entry = matching_entry.ok_or_else(|| QuoteError::Overweight {
        grams: parcel.weight_grams,
        limit: max_limit,
    })?;

    let base_cents = entry.cents;
    let mut surcharge_cents: u64 = 0;

    // Weight surcharge: 500 cents if weight > 10000 grams
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    // International surcharge: 20% of base_cents, rounded half-up
    if parcel.zone == "international" {
        surcharge_cents += round_half_up(base_cents * 20, 100);
    }

    let total_cents = base_cents + surcharge_cents;

    let quote = Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: entry.band_max_grams,
    };

    // Emit diagnostic record
    let _diag = QuoteDiagnostic {
        zone: parcel.zone.clone(),
        weight_grams: parcel.weight_grams,
        total_cents,
    };

    Ok(quote)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use tempfile::tempdir;

    fn create_test_rate_card(content: &str) -> (String, tempfile::TempDir) {
        let dir = tempdir().unwrap();
        let file_path = dir.path().join("ratecard.txt");
        fs::write(&file_path, content).unwrap();
        (file_path.to_str().unwrap().to_string(), dir)
    }

    #[test]
    fn test_domestic_light_parcel() {
        let (path, _temp) = create_test_rate_card("domestic\t500\t599");
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_domestic_heavy_parcel() {
        let (path, _temp) = create_test_rate_card("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799");
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20000);

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_international_with_surcharges() {
        let (path, _temp) = create_test_rate_card("international\t500\t1499\ninternational\t20000\t4999");
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 15000,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20000);

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_international_small_parcel() {
        let (path, _temp) = create_test_rate_card("international\t500\t1499");
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
        assert_eq!(quote.band_max_grams, 500);

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_unknown_zone() {
        let (path, _temp) = create_test_rate_card("domestic\t500\t599");
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "antarctic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::UnknownZone(z)) if z == "antarctic"));

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_overweight() {
        let (path, _temp) = create_test_rate_card("domestic\t500\t599\ndomestic\t2000\t899");
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 5000,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::Overweight { grams, limit })
            if grams == 5000 && limit == 2000));

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_rate_card_unavailable() {
        std::env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::RateCardUnavailable)));
    }

    #[test]
    fn test_malformed_rate_card_wrong_fields() {
        let (path, _temp) = create_test_rate_card("domestic\t500\ninternational\t20000\t4999");
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line }) if line == 1));

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_malformed_rate_card_bad_number() {
        let (path, _temp) = create_test_rate_card("domestic\tabc\t599");
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        };

        let result = quote(&parcel);
        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line }) if line == 1));

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_comments_and_blank_lines_skipped() {
        let (path, _temp) = create_test_rate_card("# comment line\ndomestic\t500\t599\n\n# another\ndomestic\t2000\t899\n");
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 1000,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_malformed_line_count_includes_comments_and_blanks() {
        let (path, _temp) = create_test_rate_card("# a\ndomestic\t500\t599\n\ndomestic\t2000\t899\nbad line");
        std::env::set_var("RATECARD_PATH", &path);

        let result = quote(&Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        });

        assert!(matches!(result, Err(QuoteError::MalformedRateCard { line }) if line == 5));

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_exact_band_border() {
        let (path, _temp) = create_test_rate_card("domestic\t500\t599\ndomestic\t2000\t899");
        std::env::set_var("RATECARD_PATH", &path);

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn test_round_half_up() {
        assert_eq!(round_half_up(1499 * 20, 100), 300);
        assert_eq!(round_half_up(599 * 20, 100), 120);
        assert_eq!(round_half_up(100 * 20, 100), 20);
    }
}
