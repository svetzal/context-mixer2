pub mod zones;

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

#[derive(Debug, Clone, Copy)]
struct Band {
    max_grams: u32,
    cents: u64,
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card is unavailable"),
            Self::MalformedRateCard { line } => write!(f, "malformed rate card at line {line}"),
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let largest = bands.last().expect("rate card zones are only inserted with at least one band");

    let band = bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest.max_grams,
        },
    )?;

    let base_cents = band.cents;
    let surcharge_cents = surcharge_cents(parcel, base_cents);
    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        r#"{{"event":"quote","zone":"{}","weight_grams":{},"total_cents":{}}}"#,
        escape_json_string(&parcel.zone),
        parcel.weight_grams,
        total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&content)
}

fn parse_rate_card(content: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, raw_line) in content.lines().enumerate() {
        let line = raw_line.strip_suffix('\r').unwrap_or(raw_line);
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        }

        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;

        zones.entry(fields[0].to_string()).or_default().push(Band { max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(zones)
}

fn surcharge_cents(parcel: &Parcel, base_cents: u64) -> u64 {
    let overweight_surcharge = if parcel.weight_grams > 10_000 { 500 } else { 0 };
    let international_surcharge = if parcel.zone == "international" {
        percentage_rounded_half_up(base_cents, 20)
    } else {
        0
    };

    overweight_surcharge + international_surcharge
}

fn percentage_rounded_half_up(value: u64, percent: u64) -> u64 {
    (value * percent + 50) / 100
}

fn escape_json_string(value: &str) -> String {
    value
        .chars()
        .flat_map(|ch| match ch {
            '"' => "\\\"".chars().collect::<Vec<_>>(),
            '\\' => "\\\\".chars().collect(),
            '\n' => "\\n".chars().collect(),
            '\r' => "\\r".chars().collect(),
            '\t' => "\\t".chars().collect(),
            other => vec![other],
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;
    use std::sync::{Mutex, OnceLock};
    use std::time::{SystemTime, UNIX_EPOCH};

    fn env_lock() -> std::sync::MutexGuard<'static, ()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(())).lock().unwrap()
    }

    struct TempRateCard {
        path: PathBuf,
    }

    impl TempRateCard {
        fn new(contents: &str) -> Self {
            let nanos = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos();
            let path = env::temp_dir().join(format!("ratecard-{}-{nanos}.tsv", std::process::id()));
            fs::write(&path, contents).unwrap();
            Self { path }
        }
    }

    impl Drop for TempRateCard {
        fn drop(&mut self) {
            let _ = fs::remove_file(&self.path);
        }
    }

    fn with_rate_card<T>(contents: &str, f: impl FnOnce() -> T) -> T {
        let _guard = env_lock();
        let file = TempRateCard::new(contents);
        env::set_var("RATECARD_PATH", &file.path);
        let result = f();
        env::remove_var("RATECARD_PATH");
        result
    }

    #[test]
    fn quotes_first_matching_band() {
        with_rate_card("domestic\t20000\t1799\ndomestic\t500\t599\ndomestic\t2000\t899\n", || {
            let quote = quote(&Parcel {
                weight_grams: 501,
                zone: "domestic".to_string(),
            })
            .unwrap();

            assert_eq!(quote.base_cents, 899);
            assert_eq!(quote.surcharge_cents, 0);
            assert_eq!(quote.total_cents, 899);
            assert_eq!(quote.band_max_grams, 2000);
        });
    }

    #[test]
    fn adds_weight_and_international_surcharges() {
        with_rate_card("international\t20000\t4999\n", || {
            let quote = quote(&Parcel {
                weight_grams: 12_000,
                zone: "international".to_string(),
            })
            .unwrap();

            assert_eq!(quote.base_cents, 4999);
            assert_eq!(quote.surcharge_cents, 1500);
            assert_eq!(quote.total_cents, 6499);
            assert_eq!(quote.band_max_grams, 20_000);
        });
    }

    #[test]
    fn reports_unknown_zone() {
        with_rate_card("domestic\t500\t599\n", || {
            let error = quote(&Parcel {
                weight_grams: 100,
                zone: "remote".to_string(),
            })
            .unwrap_err();

            assert_eq!(error, QuoteError::UnknownZone("remote".to_string()));
        });
    }

    #[test]
    fn reports_overweight_with_zone_limit() {
        with_rate_card("domestic\t500\t599\ndomestic\t2000\t899\n", || {
            let error = quote(&Parcel {
                weight_grams: 2001,
                zone: "domestic".to_string(),
            })
            .unwrap_err();

            assert_eq!(
                error,
                QuoteError::Overweight {
                    grams: 2001,
                    limit: 2000
                }
            );
        });
    }

    #[test]
    fn reports_unavailable_rate_card() {
        let _guard = env_lock();
        env::remove_var("RATECARD_PATH");

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .unwrap_err();

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn reports_malformed_line_number_counting_ignored_lines() {
        with_rate_card("# header\n\ndomestic\t500\t599\ndomestic\twat\t899\n", || {
            let error = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            })
            .unwrap_err();

            assert_eq!(error, QuoteError::MalformedRateCard { line: 4 });
        });
    }
}
