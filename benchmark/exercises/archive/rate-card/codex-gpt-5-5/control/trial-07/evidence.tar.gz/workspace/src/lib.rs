pub mod zones;

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

/// A parcel to be quoted against the configured rate card.
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Requested shipping zone.
    pub zone: String,
}

/// A calculated shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Base price selected from the matching rate-card band.
    pub base_cents: u64,
    /// Total surcharge applied to the base price.
    pub surcharge_cents: u64,
    /// Final quoted price.
    pub total_cents: u64,
    /// The maximum weight of the matched rate-card band.
    pub band_max_grams: u32,
}

/// Errors returned while reading or applying the rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card path was unset, unreadable, or unavailable.
    RateCardUnavailable,
    /// A non-ignored line in the rate card could not be parsed.
    MalformedRateCard { line: usize },
    /// The requested zone does not exist in the rate card.
    UnknownZone(String),
    /// The parcel exceeds the largest available band for its zone.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown shipping zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculate a shipping quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = read_rate_card()?;
    let bands = card
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band =
        bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands.last().map(|band| band.max_grams).unwrap_or(0),
            }
        })?;

    let base_cents = band.cents;
    let surcharge_cents = weight_surcharge(parcel.weight_grams)
        + international_surcharge(parcel.zone.as_str(), base_cents);
    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn read_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut card: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;

        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        let [zone, max_grams, cents] = fields.as_slice() else {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        };

        let max_grams = max_grams
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = cents
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        card.entry((*zone).to_string()).or_default().push(Band { max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(card)
}

fn weight_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > 10_000 {
        500
    } else {
        0
    }
}

fn international_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == "international" {
        // 20%, rounded half-up: floor((base * 20 + 50) / 100).
        (base_cents * 20 + 50) / 100
    } else {
        0
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::path::{Path, PathBuf};
    use std::sync::Mutex;
    use std::time::{SystemTime, UNIX_EPOCH};

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    #[test]
    fn quotes_domestic_band_without_surcharge() {
        let _guard = ENV_LOCK.lock().unwrap();
        let card = rate_card(
            "# zone\tband_max_grams\tcents\n\
             domestic\t2000\t899\n\
             domestic\t500\t599\n\
             domestic\t20000\t1799\n",
        );
        env::set_var("RATECARD_PATH", card.path());

        let quote = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        })
        .unwrap();

        assert_eq!(
            quote,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn adds_weight_and_international_surcharges() {
        let _guard = ENV_LOCK.lock().unwrap();
        let card = rate_card(
            "international\t500\t1499\n\
             international\t20000\t4999\n",
        );
        env::set_var("RATECARD_PATH", card.path());

        let quote = quote(&Parcel {
            weight_grams: 12_000,
            zone: "international".to_string(),
        })
        .unwrap();

        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20_000);
    }

    #[test]
    fn reports_unknown_zone() {
        let _guard = ENV_LOCK.lock().unwrap();
        let card = rate_card("domestic\t500\t599\n");
        env::set_var("RATECARD_PATH", card.path());

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "express".to_string(),
        })
        .unwrap_err();

        assert_eq!(error, QuoteError::UnknownZone("express".to_string()));
    }

    #[test]
    fn reports_overweight_with_zone_limit() {
        let _guard = ENV_LOCK.lock().unwrap();
        let card = rate_card("domestic\t500\t599\ndomestic\t2000\t899\n");
        env::set_var("RATECARD_PATH", card.path());

        let error = quote(&Parcel {
            weight_grams: 2_001,
            zone: "domestic".to_string(),
        })
        .unwrap_err();

        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 2_001,
                limit: 2_000
            }
        );
    }

    #[test]
    fn reports_unavailable_rate_card() {
        let _guard = ENV_LOCK.lock().unwrap();
        env::remove_var("RATECARD_PATH");

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .unwrap_err();

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn reports_malformed_line_number_counting_ignored_lines() {
        let _guard = ENV_LOCK.lock().unwrap();
        let card = rate_card("# comment\n\n domestic\t500\t599\nbroken\n");
        env::set_var("RATECARD_PATH", card.path());

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .unwrap_err();

        assert_eq!(error, QuoteError::MalformedRateCard { line: 4 });
    }

    fn rate_card(contents: &str) -> TestRateCard {
        let nanos = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos();
        let path =
            env::temp_dir().join(format!("ratecard-test-{}-{}.tsv", std::process::id(), nanos));
        fs::write(&path, contents).unwrap();
        TestRateCard { path }
    }

    struct TestRateCard {
        path: PathBuf,
    }

    impl TestRateCard {
        fn path(&self) -> &Path {
            &self.path
        }
    }

    impl Drop for TestRateCard {
        fn drop(&mut self) {
            let _ = fs::remove_file(&self.path);
        }
    }
}
