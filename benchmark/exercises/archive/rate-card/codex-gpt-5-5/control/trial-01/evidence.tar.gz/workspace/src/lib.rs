use std::collections::BTreeMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "rate card is malformed at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown shipping zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit of {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

type RateCard = BTreeMap<String, Vec<Band>>;

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band =
        bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands
                    .last()
                    .expect("rate card parser never stores empty zone bands")
                    .max_grams,
            }
        })?;

    let base_cents = band.cents;
    let surcharge_cents =
        weight_surcharge(parcel.weight_grams) + international_surcharge(&parcel.zone, base_cents);
    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "ratecard quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut card: RateCard = BTreeMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        if line.trim().is_empty() || line.trim_start().starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        let [zone, max_grams, cents]: [&str; 3] = fields
            .try_into()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        let max_grams = max_grams
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = cents
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        card.entry(zone.to_string()).or_default().push(Band { max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(card)
}

fn weight_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > 10_000 {
        500
    } else {
        0
    }
}

fn international_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == "international" {
        (base_cents * 20 + 50) / 100
    } else {
        0
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;
    use std::sync::{Mutex, MutexGuard};
    use std::time::{SystemTime, UNIX_EPOCH};

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    struct TestRateCard {
        path: PathBuf,
    }

    impl Drop for TestRateCard {
        fn drop(&mut self) {
            let _ = std::fs::remove_file(&self.path);
        }
    }

    fn write_rate_card(contents: &str) -> TestRateCard {
        let nanos = SystemTime::now().duration_since(UNIX_EPOCH).expect("time").as_nanos();
        let path =
            std::env::temp_dir().join(format!("ratecard-test-{}-{nanos}.tsv", std::process::id()));
        std::fs::write(&path, contents).expect("write rate card");
        TestRateCard { path }
    }

    fn with_rate_card(contents: &str) -> (MutexGuard<'static, ()>, TestRateCard) {
        let guard = ENV_LOCK.lock().expect("env lock");
        let file = write_rate_card(contents);
        std::env::set_var("RATECARD_PATH", &file.path);
        (guard, file)
    }

    #[test]
    fn quotes_first_matching_band_with_surcharges() {
        let (_guard, _file) = with_rate_card(
            "# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
",
        );

        let quote = quote(&Parcel {
            weight_grams: 15_000,
            zone: "international".to_string(),
        })
        .expect("quote");

        assert_eq!(quote.base_cents, 4_999);
        assert_eq!(quote.surcharge_cents, 1_500);
        assert_eq!(quote.total_cents, 6_499);
        assert_eq!(quote.band_max_grams, 20_000);
    }

    #[test]
    fn sorts_bands_before_matching() {
        let (_guard, _file) = with_rate_card(
            "domestic\t20000\t1799
domestic\t500\t599
domestic\t2000\t899
",
        );

        let quote = quote(&Parcel {
            weight_grams: 600,
            zone: "domestic".to_string(),
        })
        .expect("quote");

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2_000);
    }

    #[test]
    fn reports_unknown_zone() {
        let (_guard, _file) = with_rate_card("domestic\t500\t599\n");

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "lunar".to_string(),
        })
        .expect_err("unknown zone");

        assert_eq!(error, QuoteError::UnknownZone("lunar".to_string()));
    }

    #[test]
    fn reports_overweight_with_zone_limit() {
        let (_guard, _file) = with_rate_card("domestic\t500\t599\ndomestic\t2000\t899\n");

        let error = quote(&Parcel {
            weight_grams: 2_001,
            zone: "domestic".to_string(),
        })
        .expect_err("overweight");

        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 2_001,
                limit: 2_000
            }
        );
    }

    #[test]
    fn reports_unavailable_rate_card() {
        let guard = ENV_LOCK.lock().expect("env lock");
        std::env::remove_var("RATECARD_PATH");

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("missing rate card");

        assert_eq!(error, QuoteError::RateCardUnavailable);
        drop(guard);
    }

    #[test]
    fn reports_malformed_line_number_including_comments_and_blanks() {
        let (_guard, _file) = with_rate_card(
            "# comment

domestic\t500\t599
domestic\tbad\t899
",
        );

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("malformed");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 4 });
    }
}
