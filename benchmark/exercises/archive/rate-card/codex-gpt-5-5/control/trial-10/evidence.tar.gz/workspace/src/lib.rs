pub mod zones;

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

/// A parcel to quote against the configured rate card.
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Shipping zone name.
    pub zone: String,
}

/// A calculated shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Base band price in cents.
    pub base_cents: u64,
    /// Combined surcharge amount in cents.
    pub surcharge_cents: u64,
    /// Base plus surcharges in cents.
    pub total_cents: u64,
    /// Maximum weight for the matched band.
    pub band_max_grams: u32,
}

/// Errors returned while reading a rate card or calculating a quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate-card path is unset or the file could not be read.
    RateCardUnavailable,
    /// A non-comment rate-card line is invalid.
    MalformedRateCard { line: usize },
    /// The requested zone does not appear in the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest configured band.
    Overweight { grams: u32, limit: u32 },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculate a shipping quote for `parcel`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let largest_band = bands.last().expect("rate-card parser only inserts non-empty zone bands");

    let band = bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest_band.max_grams,
        },
    )?;

    let surcharge_cents = weight_surcharge(parcel.weight_grams)
        + international_surcharge(parcel.zone.as_str(), band.cents);
    let total_cents = band.cents + surcharge_cents;

    eprintln!(
        "ratecard_quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut rate_card: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields = line.split('\t').collect::<Vec<_>>();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        }

        let zone = fields[0].to_owned();
        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;

        rate_card.entry(zone).or_default().push(Band { max_grams, cents });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(rate_card)
}

fn weight_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > 10_000 {
        500
    } else {
        0
    }
}

fn international_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == "international" {
        (base_cents * 20 + 50) / 100
    } else {
        0
    }
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::path::{Path, PathBuf};
    use std::sync::atomic::{AtomicU64, Ordering};
    use std::sync::{Mutex, OnceLock};

    fn env_lock() -> std::sync::MutexGuard<'static, ()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(())).lock().unwrap()
    }

    struct TestRateCard {
        path: PathBuf,
    }

    impl TestRateCard {
        fn path(&self) -> &Path {
            &self.path
        }
    }

    impl Drop for TestRateCard {
        fn drop(&mut self) {
            let _ = fs::remove_file(&self.path);
        }
    }

    fn rate_card(contents: &str) -> TestRateCard {
        static NEXT_ID: AtomicU64 = AtomicU64::new(0);

        let path = env::temp_dir().join(format!(
            "ratecard-test-{}-{}.tsv",
            std::process::id(),
            NEXT_ID.fetch_add(1, Ordering::Relaxed)
        ));
        let mut file = fs::File::create(&path).unwrap();
        file.write_all(contents.as_bytes()).unwrap();
        TestRateCard { path }
    }

    fn sample_card() -> TestRateCard {
        rate_card(
            "\
# zone\tband_max_grams\tcents
domestic\t20000\t1799
domestic\t500\t599
domestic\t2000\t899
international\t500\t1499
international\t20000\t4999
",
        )
    }

    #[test]
    fn quotes_first_matching_band_after_sorting() {
        let _guard = env_lock();
        let file = sample_card();
        env::set_var("RATECARD_PATH", file.path());

        let actual = quote(&Parcel {
            weight_grams: 1_750,
            zone: "domestic".to_owned(),
        })
        .unwrap();

        assert_eq!(
            actual,
            Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2_000,
            }
        );
    }

    #[test]
    fn adds_weight_and_international_surcharges() {
        let _guard = env_lock();
        let file = sample_card();
        env::set_var("RATECARD_PATH", file.path());

        let actual = quote(&Parcel {
            weight_grams: 12_000,
            zone: "international".to_owned(),
        })
        .unwrap();

        assert_eq!(
            actual,
            Quote {
                base_cents: 4_999,
                surcharge_cents: 1_500,
                total_cents: 6_499,
                band_max_grams: 20_000,
            }
        );
    }

    #[test]
    fn rounds_international_surcharge_half_up() {
        let _guard = env_lock();
        let file = rate_card("international\t500\t1\n");
        env::set_var("RATECARD_PATH", file.path());

        let actual = quote(&Parcel {
            weight_grams: 100,
            zone: "international".to_owned(),
        })
        .unwrap();

        assert_eq!(actual.surcharge_cents, 0);

        let file = rate_card("international\t500\t3\n");
        env::set_var("RATECARD_PATH", file.path());

        let actual = quote(&Parcel {
            weight_grams: 100,
            zone: "international".to_owned(),
        })
        .unwrap();

        assert_eq!(actual.surcharge_cents, 1);
    }

    #[test]
    fn returns_unknown_zone() {
        let _guard = env_lock();
        let file = sample_card();
        env::set_var("RATECARD_PATH", file.path());

        let actual = quote(&Parcel {
            weight_grams: 100,
            zone: "express".to_owned(),
        });

        assert_eq!(actual, Err(QuoteError::UnknownZone("express".to_owned())));
    }

    #[test]
    fn returns_overweight_with_zone_limit() {
        let _guard = env_lock();
        let file = sample_card();
        env::set_var("RATECARD_PATH", file.path());

        let actual = quote(&Parcel {
            weight_grams: 20_001,
            zone: "domestic".to_owned(),
        });

        assert_eq!(
            actual,
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            })
        );
    }

    #[test]
    fn returns_unavailable_when_env_is_missing_or_file_unreadable() {
        let _guard = env_lock();
        env::remove_var("RATECARD_PATH");

        let actual = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        });

        assert_eq!(actual, Err(QuoteError::RateCardUnavailable));

        env::set_var("RATECARD_PATH", "/path/that/does/not/exist");
        let actual = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        });

        assert_eq!(actual, Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn returns_malformed_with_one_based_physical_line_number() {
        let _guard = env_lock();
        let file = rate_card("# comment\n\n domestic\t500\t599\ninternational\tbad\t4999\n");
        env::set_var("RATECARD_PATH", file.path());

        let actual = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        });

        assert_eq!(actual, Err(QuoteError::MalformedRateCard { line: 4 }));
    }

    #[test]
    fn quote_error_implements_error() {
        fn assert_error<T: Error>() {}

        assert_error::<QuoteError>();
        assert_eq!(
            QuoteError::MalformedRateCard { line: 7 }.to_string(),
            "malformed rate card at line 7"
        );
    }
}
