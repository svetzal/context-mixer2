use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

/// A parcel to quote against the configured rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A calculated shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Errors returned while loading a rate card or calculating a quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    band_max_grams: u32,
    cents: u64,
}

type RateCard = HashMap<String, Vec<Band>>;

/// Calculate a quote for `parcel` using the tab-separated rate card at `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let largest_band =
        bands.last().expect("rate card parser only stores zones with at least one band");
    let band = bands.iter().find(|band| parcel.weight_grams <= band.band_max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest_band.band_max_grams,
        },
    )?;

    let base_cents = band.cents;
    let surcharge_cents =
        weight_surcharge(parcel.weight_grams) + international_surcharge(&parcel.zone, base_cents);
    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut rate_card: RateCard = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        }

        let band_max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;

        rate_card.entry(fields[0].to_string()).or_default().push(Band {
            band_max_grams,
            cents,
        });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(rate_card)
}

fn weight_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > 10_000 {
        500
    } else {
        0
    }
}

fn international_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == "international" {
        (base_cents * 20 + 50) / 100
    } else {
        0
    }
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::sync::{Mutex, OnceLock};

    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    fn write_rate_card(contents: &str) -> PathBuf {
        static NEXT_ID: AtomicUsize = AtomicUsize::new(0);
        let path = env::temp_dir().join(format!(
            "ratecard-test-{}-{}.tsv",
            std::process::id(),
            NEXT_ID.fetch_add(1, Ordering::Relaxed)
        ));
        fs::write(&path, contents).expect("write temporary rate card");
        path
    }

    fn sample_rate_card() -> &'static str {
        "# zone\tband_max_grams\tcents\n\
         domestic\t500\t599\n\
         domestic\t2000\t899\n\
         domestic\t20000\t1799\n\
         international\t500\t1499\n\
         international\t20000\t4999\n"
    }

    #[test]
    fn quotes_first_matching_band() {
        let _guard = env_lock().lock().expect("lock RATECARD_PATH");
        let file = write_rate_card(sample_rate_card());
        env::set_var("RATECARD_PATH", &file);

        let quote = quote(&Parcel {
            weight_grams: 501,
            zone: "domestic".to_string(),
        })
        .expect("quote domestic parcel");

        assert_eq!(
            quote,
            Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2000,
            }
        );
    }

    #[test]
    fn adds_weight_and_international_surcharges() {
        let _guard = env_lock().lock().expect("lock RATECARD_PATH");
        let file = write_rate_card(sample_rate_card());
        env::set_var("RATECARD_PATH", &file);

        let quote = quote(&Parcel {
            weight_grams: 10_001,
            zone: "international".to_string(),
        })
        .expect("quote international parcel");

        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn sorts_bands_before_matching() {
        let _guard = env_lock().lock().expect("lock RATECARD_PATH");
        let file = write_rate_card("domestic\t20000\t1799\ndomestic\t500\t599\n");
        env::set_var("RATECARD_PATH", &file);

        let quote = quote(&Parcel {
            weight_grams: 400,
            zone: "domestic".to_string(),
        })
        .expect("quote sorted band");

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn reports_unknown_zone() {
        let _guard = env_lock().lock().expect("lock RATECARD_PATH");
        let file = write_rate_card(sample_rate_card());
        env::set_var("RATECARD_PATH", &file);

        let error = quote(&Parcel {
            weight_grams: 200,
            zone: "remote".to_string(),
        })
        .expect_err("unknown zone should fail");

        assert_eq!(error, QuoteError::UnknownZone("remote".to_string()));
    }

    #[test]
    fn reports_overweight_with_zone_limit() {
        let _guard = env_lock().lock().expect("lock RATECARD_PATH");
        let file = write_rate_card(sample_rate_card());
        env::set_var("RATECARD_PATH", &file);

        let error = quote(&Parcel {
            weight_grams: 20_001,
            zone: "domestic".to_string(),
        })
        .expect_err("overweight parcel should fail");

        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            }
        );
    }

    #[test]
    fn reports_malformed_line_number_counting_comments_and_blanks() {
        let _guard = env_lock().lock().expect("lock RATECARD_PATH");
        let file = write_rate_card("# header\n\ndomestic\t500\t599\ndomestic\tnope\t899\n");
        env::set_var("RATECARD_PATH", &file);

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("malformed card should fail");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn reports_unavailable_rate_card() {
        let _guard = env_lock().lock().expect("lock RATECARD_PATH");
        env::remove_var("RATECARD_PATH");

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("missing RATECARD_PATH should fail");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }
}
