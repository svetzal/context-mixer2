pub mod zones;

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;
use std::path::PathBuf;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band =
        bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands
                    .last()
                    .expect("zones are only inserted with at least one band")
                    .max_grams,
            }
        })?;

    let surcharge_cents = surcharge_cents(parcel, band.cents);
    let total_cents = band.cents + surcharge_cents;

    eprintln!(
        "ratecard_quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var_os("RATECARD_PATH")
        .map(PathBuf::from)
        .ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut rate_card: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        }

        let band_max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;

        rate_card.entry(fields[0].to_string()).or_default().push(Band {
            max_grams: band_max_grams,
            cents,
        });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(rate_card)
}

fn surcharge_cents(parcel: &Parcel, base_cents: u64) -> u64 {
    let overweight_surcharge = if parcel.weight_grams > 10_000 { 500 } else { 0 };
    let zone_surcharge = if parcel.zone == "international" {
        (base_cents * 20 + 50) / 100
    } else {
        0
    };

    overweight_surcharge + zone_surcharge
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::path::PathBuf;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn rate_card_path() -> PathBuf {
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("system time after epoch")
            .as_nanos();
        env::temp_dir().join(format!("ratecard-{}-{nanos}.tsv", std::process::id()))
    }

    fn write_rate_card(contents: &str) -> PathBuf {
        let path = rate_card_path();
        let mut file = fs::File::create(&path).expect("create temp rate card");
        file.write_all(contents.as_bytes()).expect("write temp rate card");
        path
    }

    fn with_rate_card<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        let path = write_rate_card(contents);
        env::set_var("RATECARD_PATH", &path);
        let result = test();
        env::remove_var("RATECARD_PATH");
        fs::remove_file(path).expect("remove temp rate card");
        result
    }

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    #[test]
    fn quotes_first_matching_band() {
        with_rate_card(SAMPLE, || {
            let quote = quote(&Parcel {
                weight_grams: 501,
                zone: "domestic".to_string(),
            })
            .expect("quote parcel");

            assert_eq!(
                quote,
                Quote {
                    base_cents: 899,
                    surcharge_cents: 0,
                    total_cents: 899,
                    band_max_grams: 2000,
                }
            );
        });
    }

    #[test]
    fn adds_weight_and_international_surcharges() {
        with_rate_card(SAMPLE, || {
            let quote = quote(&Parcel {
                weight_grams: 12_000,
                zone: "international".to_string(),
            })
            .expect("quote parcel");

            assert_eq!(quote.base_cents, 4999);
            assert_eq!(quote.surcharge_cents, 1500);
            assert_eq!(quote.total_cents, 6499);
            assert_eq!(quote.band_max_grams, 20_000);
        });
    }

    #[test]
    fn sorts_bands_before_matching() {
        with_rate_card("domestic\t2000\t899\ndomestic\t500\t599\n", || {
            let quote = quote(&Parcel {
                weight_grams: 400,
                zone: "domestic".to_string(),
            })
            .expect("quote parcel");

            assert_eq!(quote.base_cents, 599);
            assert_eq!(quote.band_max_grams, 500);
        });
    }

    #[test]
    fn unknown_zone_reports_requested_zone() {
        with_rate_card(SAMPLE, || {
            let error = quote(&Parcel {
                weight_grams: 100,
                zone: "express".to_string(),
            })
            .expect_err("unknown zone");

            assert_eq!(error, QuoteError::UnknownZone("express".to_string()));
        });
    }

    #[test]
    fn overweight_reports_weight_and_zone_limit() {
        with_rate_card(SAMPLE, || {
            let error = quote(&Parcel {
                weight_grams: 20_001,
                zone: "domestic".to_string(),
            })
            .expect_err("overweight");

            assert_eq!(
                error,
                QuoteError::Overweight {
                    grams: 20_001,
                    limit: 20_000,
                }
            );
        });
    }

    #[test]
    fn missing_rate_card_path_is_unavailable() {
        env::remove_var("RATECARD_PATH");

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("missing rate card");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn malformed_line_reports_one_based_physical_line() {
        with_rate_card("# comment\n\nbad line\n", || {
            let error = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            })
            .expect_err("malformed rate card");

            assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
        });
    }

    #[test]
    fn malformed_number_reports_line() {
        with_rate_card("domestic\tlots\t599\n", || {
            let error = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            })
            .expect_err("malformed rate card");

            assert_eq!(error, QuoteError::MalformedRateCard { line: 1 });
        });
    }

    #[test]
    fn quote_error_implements_error() {
        fn assert_error<T: Error>() {}

        assert_error::<QuoteError>();
    }
}
