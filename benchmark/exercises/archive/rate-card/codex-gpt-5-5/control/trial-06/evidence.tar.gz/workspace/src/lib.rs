pub mod zones;

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed on line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct RateBand {
    max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = read_rate_card()?;
    let bands = rate_card
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band =
        bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or_else(|| {
            let limit =
                bands.last().expect("zone entries are never stored without a band").max_grams;
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = band.cents;
    let surcharge_cents = surcharge_cents(parcel, base_cents);
    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "ratecard_quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn read_rate_card() -> Result<HashMap<String, Vec<RateBand>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<RateBand>>, QuoteError> {
    let mut zones: HashMap<String, Vec<RateBand>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;

        if line.trim().is_empty() || line.starts_with('#') {
            continue;
        }

        let fields = line.split('\t').collect::<Vec<_>>();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        zones
            .entry(fields[0].to_owned())
            .or_default()
            .push(RateBand { max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(zones)
}

fn surcharge_cents(parcel: &Parcel, base_cents: u64) -> u64 {
    let overweight_surcharge = if parcel.weight_grams > 10_000 { 500 } else { 0 };
    let international_surcharge = if parcel.zone == "international" {
        (base_cents * 20 + 50) / 100
    } else {
        0
    };

    overweight_surcharge + international_surcharge
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::path::PathBuf;
    use std::sync::{Mutex, OnceLock};
    use std::time::{SystemTime, UNIX_EPOCH};

    static ENV_LOCK: OnceLock<Mutex<()>> = OnceLock::new();

    fn env_lock() -> &'static Mutex<()> {
        ENV_LOCK.get_or_init(|| Mutex::new(()))
    }

    fn with_rate_card(contents: &str, test: impl FnOnce()) {
        let _guard = env_lock().lock().expect("env lock poisoned");
        let path = rate_card_path();
        fs::write(&path, contents).expect("write rate card");

        env::set_var("RATECARD_PATH", &path);
        test();
        env::remove_var("RATECARD_PATH");
        fs::remove_file(path).expect("remove rate card");
    }

    fn rate_card_path() -> PathBuf {
        let unique = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock after epoch")
            .as_nanos();
        env::temp_dir().join(format!("ratecard-test-{unique}.tsv"))
    }

    fn sample_card() -> &'static str {
        "# zone\tband_max_grams\tcents\n\
         domestic\t2000\t899\n\
         domestic\t500\t599\n\
         domestic\t20000\t1799\n\
         international\t500\t1499\n\
         international\t20000\t4999\n"
    }

    #[test]
    fn selects_first_matching_band_after_sorting() {
        with_rate_card(sample_card(), || {
            let result = quote(&Parcel {
                weight_grams: 500,
                zone: "domestic".to_owned(),
            })
            .expect("quote");

            assert_eq!(
                result,
                Quote {
                    base_cents: 599,
                    surcharge_cents: 0,
                    total_cents: 599,
                    band_max_grams: 500,
                }
            );
        });
    }

    #[test]
    fn adds_weight_and_international_surcharges() {
        with_rate_card(sample_card(), || {
            let result = quote(&Parcel {
                weight_grams: 15_000,
                zone: "international".to_owned(),
            })
            .expect("quote");

            assert_eq!(result.base_cents, 4999);
            assert_eq!(result.surcharge_cents, 1500);
            assert_eq!(result.total_cents, 6499);
            assert_eq!(result.band_max_grams, 20_000);
        });
    }

    #[test]
    fn reports_unknown_zone() {
        with_rate_card(sample_card(), || {
            let error = quote(&Parcel {
                weight_grams: 100,
                zone: "express".to_owned(),
            })
            .expect_err("unknown zone");

            assert_eq!(error, QuoteError::UnknownZone("express".to_owned()));
        });
    }

    #[test]
    fn reports_overweight_with_largest_zone_band() {
        with_rate_card(sample_card(), || {
            let error = quote(&Parcel {
                weight_grams: 20_001,
                zone: "domestic".to_owned(),
            })
            .expect_err("overweight");

            assert_eq!(
                error,
                QuoteError::Overweight {
                    grams: 20_001,
                    limit: 20_000
                }
            );
        });
    }

    #[test]
    fn reports_unavailable_rate_card_when_env_is_unset() {
        let _guard = env_lock().lock().expect("env lock poisoned");
        env::remove_var("RATECARD_PATH");

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        })
        .expect_err("missing card");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn reports_unavailable_rate_card_when_file_cannot_be_read() {
        let _guard = env_lock().lock().expect("env lock poisoned");
        env::set_var("RATECARD_PATH", "/path/that/does/not/exist");

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        })
        .expect_err("missing card");

        env::remove_var("RATECARD_PATH");
        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn reports_malformed_rate_card_with_original_line_number() {
        with_rate_card("# header\n\n domestic\t500\t599\nbad-line\n", || {
            let error = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".to_owned(),
            })
            .expect_err("malformed card");

            assert_eq!(error, QuoteError::MalformedRateCard { line: 4 });
        });
    }

    #[test]
    fn reports_malformed_rate_card_when_numbers_do_not_parse() {
        with_rate_card("domestic\tlots\t599\n", || {
            let error = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".to_owned(),
            })
            .expect_err("malformed card");

            assert_eq!(error, QuoteError::MalformedRateCard { line: 1 });
        });
    }
}
