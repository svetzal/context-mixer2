use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct RateBand {
    band_max_grams: u32,
    cents: u64,
}

type RateCard = HashMap<String, Vec<RateBand>>;

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let rate_card = parse_rate_card(&contents)?;
    let quote = quote_from_rate_card(parcel, &rate_card)?;

    eprintln!(
        "ratecard quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, quote.total_cents
    );

    Ok(quote)
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed on line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut rate_card = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        if line.trim().is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        }

        let band = RateBand {
            band_max_grams: fields[1]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?,
            cents: fields[2]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?,
        };

        rate_card.entry(fields[0].to_owned()).or_insert_with(Vec::new).push(band);
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(rate_card)
}

fn quote_from_rate_card(parcel: &Parcel, rate_card: &RateCard) -> Result<Quote, QuoteError> {
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let Some(largest_band) = bands.last() else {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    };

    let band = bands.iter().find(|band| parcel.weight_grams <= band.band_max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest_band.band_max_grams,
        },
    )?;

    let surcharge_cents = surcharge_cents(parcel, band.cents);
    let total_cents = band.cents + surcharge_cents;

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

fn surcharge_cents(parcel: &Parcel, base_cents: u64) -> u64 {
    let weight_surcharge = if parcel.weight_grams > 10_000 { 500 } else { 0 };
    let international_surcharge = if parcel.zone == "international" {
        rounded_twenty_percent(base_cents)
    } else {
        0
    };

    weight_surcharge + international_surcharge
}

fn rounded_twenty_percent(cents: u64) -> u64 {
    cents / 5 + u64::from(cents % 5 >= 3)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::Path;
    use std::path::PathBuf;
    use std::sync::{Mutex, OnceLock};

    fn sample_rate_card() -> &'static str {
        "# zone\tband_max_grams\tcents\n\
         \n\
         domestic\t500\t599\n\
         domestic\t2000\t899\n\
         domestic\t20000\t1799\n\
         international\t500\t1499\n\
         international\t20000\t4999\n"
    }

    fn parcel(zone: &str, weight_grams: u32) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_owned(),
        }
    }

    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    fn write_rate_card(contents: &str) -> PathBuf {
        let path = env::temp_dir().join(format!(
            "ratecard-test-{}-{}.tsv",
            std::process::id(),
            unique_test_id()
        ));
        fs::write(&path, contents).expect("write temporary rate card");
        path
    }

    fn unique_test_id() -> u64 {
        use std::sync::atomic::{AtomicU64, Ordering};

        static NEXT_ID: AtomicU64 = AtomicU64::new(0);
        NEXT_ID.fetch_add(1, Ordering::Relaxed)
    }

    fn with_ratecard_path<T>(path: &Path, action: impl FnOnce() -> T) -> T {
        let _guard = env_lock().lock().expect("rate card env lock");
        let previous = env::var_os("RATECARD_PATH");
        env::set_var("RATECARD_PATH", path);
        let result = action();

        if let Some(previous) = previous {
            env::set_var("RATECARD_PATH", previous);
        } else {
            env::remove_var("RATECARD_PATH");
        }

        result
    }

    fn without_ratecard_path<T>(action: impl FnOnce() -> T) -> T {
        let _guard = env_lock().lock().expect("rate card env lock");
        let previous = env::var_os("RATECARD_PATH");
        env::remove_var("RATECARD_PATH");
        let result = action();

        if let Some(previous) = previous {
            env::set_var("RATECARD_PATH", previous);
        }

        result
    }

    #[test]
    fn selects_the_first_band_at_or_above_the_weight() {
        let rate_card = parse_rate_card(sample_rate_card()).expect("parse sample rate card");

        let quote = quote_from_rate_card(&parcel("domestic", 501), &rate_card).expect("quote");

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn adds_weight_and_international_surcharges() {
        let rate_card = parse_rate_card(sample_rate_card()).expect("parse sample rate card");

        let quote =
            quote_from_rate_card(&parcel("international", 12_000), &rate_card).expect("quote");

        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn rounds_international_surcharge_half_up_to_the_cent() {
        assert_eq!(rounded_twenty_percent(1499), 300);
        assert_eq!(rounded_twenty_percent(1497), 299);
    }

    #[test]
    fn rejects_malformed_lines_with_one_based_file_line_number() {
        let error = parse_rate_card("# ok\n\ninternational\t500\tnope\n")
            .expect_err("line three is malformed");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn reports_unknown_zone() {
        let rate_card = parse_rate_card(sample_rate_card()).expect("parse sample rate card");

        let error = quote_from_rate_card(&parcel("express", 100), &rate_card)
            .expect_err("express is absent");

        assert_eq!(error, QuoteError::UnknownZone("express".to_owned()));
    }

    #[test]
    fn reports_overweight_with_zone_limit() {
        let rate_card = parse_rate_card(sample_rate_card()).expect("parse sample rate card");

        let error = quote_from_rate_card(&parcel("domestic", 20_001), &rate_card)
            .expect_err("parcel exceeds largest domestic band");

        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            }
        );
    }

    #[test]
    fn reads_rate_card_from_environment() {
        let path = write_rate_card(sample_rate_card());

        let quote =
            with_ratecard_path(&path, || quote(&parcel("domestic", 500))).expect("quote from file");

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.total_cents, 599);

        fs::remove_file(path).expect("remove temporary rate card");
    }

    #[test]
    fn unavailable_when_environment_path_is_unset() {
        let error = without_ratecard_path(|| quote(&parcel("domestic", 100)))
            .expect_err("missing RATECARD_PATH is unavailable");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }
}
