use std::collections::HashMap;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

#[derive(Clone, Debug)]
struct Band {
    max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = load_rate_card()?;
    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band =
        bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands.last().map(|band| band.max_grams).unwrap_or(0),
            }
        })?;

    let base_cents = band.cents;
    let surcharge_cents =
        weight_surcharge(parcel.weight_grams) + international_surcharge(&parcel.zone, base_cents);
    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut card: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let band_max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        card.entry(fields[0].to_string()).or_default().push(Band {
            max_grams: band_max_grams,
            cents,
        });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(card)
}

fn weight_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > 10_000 {
        500
    } else {
        0
    }
}

fn international_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == "international" {
        let whole = base_cents / 5;
        let remainder = base_cents % 5;
        whole + u64::from(remainder >= 3)
    } else {
        0
    }
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;
    use std::sync::{Mutex, MutexGuard, OnceLock};

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn quotes_first_matching_band() {
        let _guard = test_env_lock();
        let _rate_card = rate_card(CARD);
        let parcel = Parcel {
            weight_grams: 501,
            zone: "domestic".to_string(),
        };

        let quote = quote(&parcel).expect("quote should succeed");

        assert_eq!(
            quote,
            Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2000,
            }
        );
    }

    #[test]
    fn adds_weight_and_international_surcharges() {
        let _guard = test_env_lock();
        let _rate_card = rate_card(CARD);
        let parcel = Parcel {
            weight_grams: 12_000,
            zone: "international".to_string(),
        };

        let quote = quote(&parcel).expect("quote should succeed");

        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20_000);
    }

    #[test]
    fn reports_unknown_zone() {
        let _guard = test_env_lock();
        let _rate_card = rate_card(CARD);
        let parcel = Parcel {
            weight_grams: 100,
            zone: "lunar".to_string(),
        };

        assert_eq!(quote(&parcel), Err(QuoteError::UnknownZone("lunar".to_string())));
    }

    #[test]
    fn reports_overweight_with_largest_zone_band() {
        let _guard = test_env_lock();
        let _rate_card = rate_card(CARD);
        let parcel = Parcel {
            weight_grams: 20_001,
            zone: "domestic".to_string(),
        };

        assert_eq!(
            quote(&parcel),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            })
        );
    }

    #[test]
    fn reports_unavailable_rate_card() {
        let _guard = test_env_lock();
        std::env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        assert_eq!(quote(&parcel), Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn reports_malformed_rate_card_line_number() {
        let _guard = test_env_lock();
        let _rate_card = rate_card("\n# ignored\ndomestic\t500\n");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        assert_eq!(quote(&parcel), Err(QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn reports_malformed_numbers() {
        let _guard = test_env_lock();
        let _rate_card = rate_card("domestic\tmany\t599\n");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        assert_eq!(quote(&parcel), Err(QuoteError::MalformedRateCard { line: 1 }));
    }

    struct TestRateCard {
        path: PathBuf,
    }

    impl Drop for TestRateCard {
        fn drop(&mut self) {
            let _ = fs::remove_file(&self.path);
        }
    }

    fn rate_card(contents: &str) -> TestRateCard {
        let path = std::env::temp_dir().join(format!(
            "ratecard-test-{}-{}.tsv",
            std::process::id(),
            unique_id()
        ));
        fs::write(&path, contents).expect("write rate card");
        std::env::set_var("RATECARD_PATH", &path);
        TestRateCard { path }
    }

    fn test_env_lock() -> MutexGuard<'static, ()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(())).lock().expect("env lock")
    }

    fn unique_id() -> u128 {
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("system time")
            .as_nanos()
    }
}
