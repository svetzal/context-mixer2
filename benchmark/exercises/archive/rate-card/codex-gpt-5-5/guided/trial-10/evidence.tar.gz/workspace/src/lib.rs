use std::collections::BTreeMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

/// Zone labels for display-oriented callers.
pub mod zones;

/// A parcel to quote against the configured rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Rate-card zone name.
    pub zone: String,
}

/// A calculated shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// The matching rate-card band's price in cents.
    pub base_cents: u64,
    /// The sum of all surcharges in cents.
    pub surcharge_cents: u64,
    /// The final quoted price in cents.
    pub total_cents: u64,
    /// The maximum parcel weight for the matching rate-card band.
    pub band_max_grams: u32,
}

/// Errors that can occur while loading a rate card or quoting a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The `RATECARD_PATH` environment variable was unset or could not be read.
    RateCardUnavailable,
    /// A rate-card line did not have exactly three tab-separated fields, or a numeric field failed to parse.
    MalformedRateCard { line: usize },
    /// The requested zone did not appear in the rate card.
    UnknownZone(String),
    /// The parcel exceeded the largest band configured for the requested zone.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(formatter, "unknown rate card zone '{zone}'"),
            QuoteError::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone)]
struct RateBand {
    band_max_grams: u32,
    cents: u64,
}

type RateCard = BTreeMap<String, Vec<RateBand>>;

/// Quote a parcel using the rate card at `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let Some(largest_band) = bands.last() else {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    };
    let band = bands.iter().find(|band| parcel.weight_grams <= band.band_max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest_band.band_max_grams,
        },
    )?;

    let base_cents = band.cents;
    let surcharge_cents =
        weight_surcharge(parcel.weight_grams) + international_surcharge(&parcel.zone, base_cents);
    let total_cents = base_cents + surcharge_cents;
    emit_quote_diagnostic(parcel, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut rate_card: RateCard = BTreeMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let zone = fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let band_max_grams = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        rate_card.entry(zone.to_owned()).or_default().push(RateBand {
            band_max_grams,
            cents,
        });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(rate_card)
}

fn weight_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > 10_000 {
        500
    } else {
        0
    }
}

fn international_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == "international" {
        (base_cents * 20 + 50) / 100
    } else {
        0
    }
}

fn emit_quote_diagnostic(parcel: &Parcel, total_cents: u64) {
    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;
    use std::sync::atomic::{AtomicU64, Ordering};
    use std::sync::{Mutex, OnceLock};

    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    fn rate_card(contents: &str) -> PathBuf {
        static NEXT_ID: AtomicU64 = AtomicU64::new(0);

        let filename = format!(
            "ratecard-test-{}-{}.tsv",
            std::process::id(),
            NEXT_ID.fetch_add(1, Ordering::Relaxed)
        );
        let path = env::temp_dir().join(filename);
        fs::write(&path, contents).expect("write rate card");
        path
    }

    fn quote_with_card(contents: &str, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let _guard = env_lock().lock().expect("lock RATECARD_PATH");
        let path = rate_card(contents);
        env::set_var("RATECARD_PATH", &path);
        let result = quote(parcel);
        env::remove_var("RATECARD_PATH");
        fs::remove_file(path).expect("remove rate card");
        result
    }

    #[test]
    fn quotes_first_matching_sorted_band() {
        let parcel = Parcel {
            weight_grams: 750,
            zone: "domestic".to_owned(),
        };

        let result = quote_with_card(
            "domestic\t20000\t1799\ndomestic\t500\t599\ndomestic\t2000\t899\n",
            &parcel,
        )
        .expect("quote");

        assert_eq!(
            result,
            Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2000,
            }
        );
    }

    #[test]
    fn adds_weight_and_international_surcharges() {
        let parcel = Parcel {
            weight_grams: 15_000,
            zone: "international".to_owned(),
        };

        let result = quote_with_card("international\t20000\t4999\n", &parcel).expect("quote");

        assert_eq!(
            result,
            Quote {
                base_cents: 4999,
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20000,
            }
        );
    }

    #[test]
    fn reports_unknown_zone() {
        let parcel = Parcel {
            weight_grams: 100,
            zone: "remote".to_owned(),
        };

        let error = quote_with_card("domestic\t500\t599\n", &parcel).expect_err("unknown zone");

        assert_eq!(error, QuoteError::UnknownZone("remote".to_owned()));
    }

    #[test]
    fn reports_overweight_with_largest_zone_limit() {
        let parcel = Parcel {
            weight_grams: 2_001,
            zone: "domestic".to_owned(),
        };

        let error = quote_with_card("domestic\t500\t599\ndomestic\t2000\t899\n", &parcel)
            .expect_err("overweight");

        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 2_001,
                limit: 2_000,
            }
        );
    }

    #[test]
    fn reports_malformed_line_number_counting_comments_and_blanks() {
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        };

        let error =
            quote_with_card("# header\n\ndomestic\tbad\t599\n", &parcel).expect_err("malformed");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn reports_unavailable_rate_card_for_missing_env() {
        let _guard = env_lock().lock().expect("lock RATECARD_PATH");
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        };

        let error = quote(&parcel).expect_err("unavailable");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn quote_error_implements_error() {
        fn assert_error<T: Error>() {}

        assert_error::<QuoteError>();
    }
}
