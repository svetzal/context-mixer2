//! Shipping quotes from a tab-separated rate card.

use std::collections::HashMap;
use std::error::Error;
use std::fmt::{self, Display};
use std::fs;

/// Zone display helpers.
pub mod zones;

/// A parcel to quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Shipping zone requested by the caller.
    pub zone: String,
}

/// A calculated shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Base price for the matched rate-card band.
    pub base_cents: u64,
    /// Total additive surcharges.
    pub surcharge_cents: u64,
    /// Final quote total.
    pub total_cents: u64,
    /// Maximum weight of the matched rate-card band.
    pub band_max_grams: u32,
}

/// Errors that can prevent a quote from being calculated.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card path was unset, unreadable, or otherwise unavailable.
    RateCardUnavailable,
    /// A non-comment, non-blank rate-card line could not be parsed.
    MalformedRateCard {
        /// The 1-based line number in the rate-card file.
        line: usize,
    },
    /// The requested zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the requested zone's largest band.
    Overweight {
        /// The requested parcel weight.
        grams: u32,
        /// The largest supported weight for the requested zone.
        limit: u32,
    },
}

impl Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculate a quote for `parcel` using the `RATECARD_PATH` TSV rate card.
///
/// A diagnostic record is emitted to standard error for each successful quote.
///
/// # Errors
///
/// Returns [`QuoteError::RateCardUnavailable`] when the rate card path is not
/// set or cannot be read, [`QuoteError::MalformedRateCard`] for invalid TSV
/// rows, [`QuoteError::UnknownZone`] for zones absent from the file, and
/// [`QuoteError::Overweight`] when no band can carry the parcel.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = load_rate_card()?;
    let bands = card
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let Some(matched_band) = bands.iter().find(|band| parcel.weight_grams <= band.max_grams) else {
        let limit = bands.last().map_or(parcel.weight_grams, |band| band.max_grams);
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        });
    };

    let base_cents = matched_band.cents;
    let surcharge_cents = surcharge_cents(parcel.weight_grams, &parcel.zone, base_cents);
    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: matched_band.max_grams,
    })
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&content)
}

fn parse_rate_card(content: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut card: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, line) in content.lines().enumerate() {
        let line_number = index + 1;
        if line.trim().is_empty() || line.starts_with('#') {
            continue;
        }

        let fields = line.split('\t').collect::<Vec<_>>();
        let [zone, max_grams, cents] = fields.as_slice() else {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        };

        let max_grams = max_grams
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = cents
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        card.entry((*zone).to_owned()).or_default().push(Band { max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(card)
}

fn surcharge_cents(weight_grams: u32, zone: &str, base_cents: u64) -> u64 {
    let overweight = u64::from(weight_grams > 10_000) * 500;
    let international = if zone == "international" {
        (base_cents * 20 + 50) / 100
    } else {
        0
    };
    overweight + international
}

#[cfg(test)]
mod tests {
    use super::{parse_rate_card, quote, Parcel, Quote, QuoteError};
    use std::fs;
    use std::path::PathBuf;
    use std::sync::{Mutex, MutexGuard};
    use std::time::{SystemTime, UNIX_EPOCH};

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn env_lock() -> MutexGuard<'static, ()> {
        ENV_LOCK.lock().expect("environment lock should not be poisoned")
    }

    fn write_rate_card(content: &str) -> PathBuf {
        let file = std::env::temp_dir().join(format!(
            "ratecard-test-{}-{}.tsv",
            std::process::id(),
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .expect("system clock should be after Unix epoch")
                .as_nanos()
        ));
        fs::write(&file, content).expect("temp rate card should be writable");
        file
    }

    fn sample_rate_card() -> &'static str {
        "# zone\tband_max_grams\tcents\n\
         domestic\t500\t599\n\
         domestic\t2000\t899\n\
         domestic\t20000\t1799\n\
         international\t500\t1499\n\
         international\t20000\t4999\n"
    }

    #[test]
    fn quotes_first_band_at_or_above_weight() {
        let _lock = env_lock();
        let file = write_rate_card(sample_rate_card());
        std::env::set_var("RATECARD_PATH", &file);

        let actual = quote(&Parcel {
            weight_grams: 501,
            zone: "domestic".to_owned(),
        })
        .expect("quote should succeed");

        assert_eq!(
            actual,
            Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2000,
            }
        );
    }

    #[test]
    fn adds_weight_and_international_surcharges() {
        let _lock = env_lock();
        let file = write_rate_card(sample_rate_card());
        std::env::set_var("RATECARD_PATH", &file);

        let actual = quote(&Parcel {
            weight_grams: 10_001,
            zone: "international".to_owned(),
        })
        .expect("quote should succeed");

        assert_eq!(actual.base_cents, 4999);
        assert_eq!(actual.surcharge_cents, 1500);
        assert_eq!(actual.total_cents, 6499);
        assert_eq!(actual.band_max_grams, 20_000);
    }

    #[test]
    fn rounds_international_surcharge_half_up() {
        let _lock = env_lock();
        let file = write_rate_card("international\t500\t1498\n");
        std::env::set_var("RATECARD_PATH", &file);

        let actual = quote(&Parcel {
            weight_grams: 100,
            zone: "international".to_owned(),
        })
        .expect("quote should succeed");

        assert_eq!(actual.surcharge_cents, 300);
    }

    #[test]
    fn reports_unknown_zone() {
        let _lock = env_lock();
        let file = write_rate_card(sample_rate_card());
        std::env::set_var("RATECARD_PATH", &file);

        let actual = quote(&Parcel {
            weight_grams: 100,
            zone: "express".to_owned(),
        });

        assert_eq!(actual, Err(QuoteError::UnknownZone("express".to_owned())));
    }

    #[test]
    fn reports_overweight_with_zone_limit() {
        let _lock = env_lock();
        let file = write_rate_card(sample_rate_card());
        std::env::set_var("RATECARD_PATH", &file);

        let actual = quote(&Parcel {
            weight_grams: 20_001,
            zone: "domestic".to_owned(),
        });

        assert_eq!(
            actual,
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            })
        );
    }

    #[test]
    fn reports_unavailable_rate_card() {
        let _lock = env_lock();
        std::env::remove_var("RATECARD_PATH");

        let actual = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        });

        assert_eq!(actual, Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn malformed_lines_report_original_line_number() {
        let actual = parse_rate_card("# heading\n\ndomestic\t500\n");

        assert_eq!(actual, Err(QuoteError::MalformedRateCard { line: 3 }));
    }
}
