//! Shipping quote calculation from a tab-separated rate card.

pub mod zones;

use std::collections::BTreeMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

/// A parcel to quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Requested shipping zone.
    pub zone: String,
}

/// A calculated shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Base rate selected from the matching weight band.
    pub base_cents: u64,
    /// Sum of all applied surcharges.
    pub surcharge_cents: u64,
    /// Final quote total.
    pub total_cents: u64,
    /// Maximum weight for the selected band.
    pub band_max_grams: u32,
}

/// Errors returned while calculating a quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, unreadable, or points to a missing file.
    RateCardUnavailable,
    /// A rate-card line could not be parsed.
    MalformedRateCard {
        /// One-based line number in the original file.
        line: usize,
    },
    /// The requested zone is not present in the rate card.
    UnknownZone(String),
    /// The parcel exceeds the largest configured band for its zone.
    Overweight {
        /// Requested parcel weight.
        grams: u32,
        /// Largest configured band threshold for the zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighs {grams}g, above zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct RateBand {
    max_grams: u32,
    cents: u64,
}

type RateCard = BTreeMap<String, Vec<RateBand>>;

/// Calculate a quote for a parcel using the file named by `RATECARD_PATH`.
///
/// A successful quote emits one diagnostic record to standard error containing
/// the zone, parcel weight, and resulting total.
///
/// # Errors
///
/// Returns [`QuoteError::RateCardUnavailable`] when the environment variable is
/// unset or the file cannot be read, [`QuoteError::MalformedRateCard`] when a
/// non-comment line cannot be parsed, [`QuoteError::UnknownZone`] when the
/// requested zone is absent, and [`QuoteError::Overweight`] when the parcel is
/// above that zone's largest configured band.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let contents = read_rate_card()?;
    let rate_card = parse_rate_card(&contents)?;
    let quote = calculate_quote(parcel, &rate_card)?;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, quote.total_cents
    );

    Ok(quote)
}

fn read_rate_card() -> Result<String, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)
}

fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut rate_card = BTreeMap::<String, Vec<RateBand>>::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        if line.trim().is_empty() || line.trim_start().starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let zone = fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let max_grams = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        rate_card
            .entry(zone.to_owned())
            .or_default()
            .push(RateBand { max_grams, cents });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(rate_card)
}

fn calculate_quote(parcel: &Parcel, rate_card: &RateCard) -> Result<Quote, QuoteError> {
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let Some(selected_band) = bands.iter().find(|band| parcel.weight_grams <= band.max_grams)
    else {
        let limit = bands.last().map_or(0, |band| band.max_grams);
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        });
    };

    let surcharge_cents = surcharge_cents(parcel, selected_band.cents);
    Ok(Quote {
        base_cents: selected_band.cents,
        surcharge_cents,
        total_cents: selected_band.cents + surcharge_cents,
        band_max_grams: selected_band.max_grams,
    })
}

fn surcharge_cents(parcel: &Parcel, base_cents: u64) -> u64 {
    let heavy_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        rounded_twenty_percent(base_cents)
    } else {
        0
    };

    heavy_surcharge + international_surcharge
}

fn rounded_twenty_percent(cents: u64) -> u64 {
    let quotient = cents / 5;
    let remainder = cents % 5;
    quotient + u64::from(remainder >= 3)
}

#[cfg(test)]
mod tests {
    use super::{quote, Parcel, Quote, QuoteError};
    use std::env;
    use std::fs::{self, File};
    use std::io::Write;
    use std::path::PathBuf;
    use std::sync::atomic::{AtomicU64, Ordering};
    use std::sync::{Mutex, MutexGuard};

    const SAMPLE_RATE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    struct TempRateCard {
        path: PathBuf,
    }

    impl Drop for TempRateCard {
        fn drop(&mut self) {
            let _ = fs::remove_file(&self.path);
            env::remove_var("RATECARD_PATH");
        }
    }

    fn test_lock() -> MutexGuard<'static, ()> {
        static LOCK: Mutex<()> = Mutex::new(());
        LOCK.lock().expect("test lock should not be poisoned")
    }

    fn with_rate_card(contents: &str) -> TempRateCard {
        static NEXT_ID: AtomicU64 = AtomicU64::new(0);

        let path = env::temp_dir().join(format!(
            "ratecard-test-{}-{}.tsv",
            std::process::id(),
            NEXT_ID.fetch_add(1, Ordering::Relaxed)
        ));
        let mut file = File::create(&path).expect("create temp rate card");
        file.write_all(contents.as_bytes()).expect("write temp rate card");
        env::set_var("RATECARD_PATH", &path);
        TempRateCard { path }
    }

    #[test]
    fn selects_first_band_at_or_above_weight() {
        let _guard = test_lock();
        let _rate_card = with_rate_card(SAMPLE_RATE_CARD);

        let actual = quote(&Parcel {
            weight_grams: 501,
            zone: "domestic".to_owned(),
        })
        .expect("quote should succeed");

        assert_eq!(
            actual,
            Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2000,
            }
        );
    }

    #[test]
    fn sorts_bands_before_matching() {
        let _guard = test_lock();
        let _rate_card = with_rate_card("domestic\t2000\t899\ndomestic\t500\t599\n");

        let actual = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".to_owned(),
        })
        .expect("quote should succeed");

        assert_eq!(actual.base_cents, 599);
        assert_eq!(actual.band_max_grams, 500);
    }

    #[test]
    fn adds_heavy_and_international_surcharges() {
        let _guard = test_lock();
        let _rate_card = with_rate_card(SAMPLE_RATE_CARD);

        let actual = quote(&Parcel {
            weight_grams: 12_000,
            zone: "international".to_owned(),
        })
        .expect("quote should succeed");

        assert_eq!(actual.base_cents, 4999);
        assert_eq!(actual.surcharge_cents, 1500);
        assert_eq!(actual.total_cents, 6499);
    }

    #[test]
    fn rounds_international_surcharge_half_up() {
        let _guard = test_lock();
        let _rate_card = with_rate_card("international\t500\t1498\n");

        let actual = quote(&Parcel {
            weight_grams: 100,
            zone: "international".to_owned(),
        })
        .expect("quote should succeed");

        assert_eq!(actual.surcharge_cents, 300);
    }

    #[test]
    fn reports_unknown_zone() {
        let _guard = test_lock();
        let _rate_card = with_rate_card(SAMPLE_RATE_CARD);

        let actual = quote(&Parcel {
            weight_grams: 100,
            zone: "express".to_owned(),
        });

        assert_eq!(actual, Err(QuoteError::UnknownZone("express".to_owned())));
    }

    #[test]
    fn reports_overweight_with_zone_limit() {
        let _guard = test_lock();
        let _rate_card = with_rate_card(SAMPLE_RATE_CARD);

        let actual = quote(&Parcel {
            weight_grams: 20_001,
            zone: "domestic".to_owned(),
        });

        assert_eq!(
            actual,
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            })
        );
    }

    #[test]
    fn reports_unavailable_rate_card() {
        let _guard = test_lock();
        env::remove_var("RATECARD_PATH");

        let actual = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        });

        assert_eq!(actual, Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn reports_malformed_rate_card_line_number() {
        let _guard = test_lock();
        let _rate_card = with_rate_card("# header\n\n domestic-ish\ninternational\t500\t1499\n");

        let actual = quote(&Parcel {
            weight_grams: 100,
            zone: "international".to_owned(),
        });

        assert_eq!(actual, Err(QuoteError::MalformedRateCard { line: 3 }));
    }
}
