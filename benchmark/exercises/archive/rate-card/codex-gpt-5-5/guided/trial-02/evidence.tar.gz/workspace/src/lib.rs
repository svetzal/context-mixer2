//! Shipping quotes from a tab-separated rate card.

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

/// A parcel to quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Shipping zone requested by the caller.
    pub zone: String,
}

/// A successful shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Base price selected from the matching rate band.
    pub base_cents: u64,
    /// Sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// Final price in cents.
    pub total_cents: u64,
    /// Upper weight threshold of the selected rate band.
    pub band_max_grams: u32,
}

/// Failure modes for quote calculation.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The `RATECARD_PATH` environment variable was unset or the file could not
    /// be read.
    RateCardUnavailable,
    /// The rate card contains a non-comment line that is not valid.
    MalformedRateCard {
        /// One-based line number in the original file.
        line: usize,
    },
    /// The requested zone does not exist in the rate card.
    UnknownZone(String),
    /// The parcel exceeds the largest band for its zone.
    Overweight {
        /// Requested parcel weight.
        grams: u32,
        /// Largest supported band for the requested zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct RateBand {
    max_grams: u32,
    cents: u64,
}

type RateCard = HashMap<String, Vec<RateBand>>;

/// Calculate a quote from the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_error| QuoteError::RateCardUnavailable)?;
    let rate_card = parse_rate_card(&contents)?;
    let result = quote_from_rate_card(parcel, &rate_card)?;

    eprintln!(
        "shipping_quote_calculated zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, result.total_cents
    );

    Ok(result)
}

fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut rate_card = RateCard::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = line.trim();

        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields = parse_fields(line, line_number)?;
        rate_card.entry(fields.zone).or_default().push(RateBand {
            max_grams: fields.max_grams,
            cents: fields.cents,
        });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(rate_card)
}

fn parse_fields(line: &str, line_number: usize) -> Result<ParsedLine, QuoteError> {
    let mut fields = line.split('\t');
    let zone = fields.next().ok_or(malformed(line_number))?;
    let max_grams = fields.next().ok_or(malformed(line_number))?;
    let cents = fields.next().ok_or(malformed(line_number))?;

    if fields.next().is_some() {
        return Err(malformed(line_number));
    }

    Ok(ParsedLine {
        zone: zone.to_owned(),
        max_grams: max_grams.parse().map_err(|_error| malformed(line_number))?,
        cents: cents.parse().map_err(|_error| malformed(line_number))?,
    })
}

fn quote_from_rate_card(parcel: &Parcel, rate_card: &RateCard) -> Result<Quote, QuoteError> {
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let largest_band = bands.last().ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest_band.max_grams,
        },
    )?;

    let surcharge_cents = surcharge_cents(parcel, band.cents);
    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

fn surcharge_cents(parcel: &Parcel, base_cents: u64) -> u64 {
    let overweight_surcharge = if parcel.weight_grams > 10_000 { 500 } else { 0 };
    let international_surcharge = if parcel.zone == "international" {
        rounded_percentage(base_cents, 20)
    } else {
        0
    };

    overweight_surcharge + international_surcharge
}

fn rounded_percentage(cents: u64, percentage: u64) -> u64 {
    (cents * percentage + 50) / 100
}

fn malformed(line: usize) -> QuoteError {
    QuoteError::MalformedRateCard { line }
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct ParsedLine {
    zone: String,
    max_grams: u32,
    cents: u64,
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::ffi::OsString;
    use std::fs::File;
    use std::io::{self, Write};
    use std::path::PathBuf;
    use std::sync::{Mutex, OnceLock};
    use std::time::{SystemTime, UNIX_EPOCH};

    static ENV_LOCK: OnceLock<Mutex<()>> = OnceLock::new();

    fn env_lock() -> &'static Mutex<()> {
        ENV_LOCK.get_or_init(|| Mutex::new(()))
    }

    fn sample_rate_card() -> &'static str {
        "# zone\tband_max_grams\tcents\n\
         domestic\t500\t599\n\
         domestic\t2000\t899\n\
         domestic\t20000\t1799\n\
         international\t500\t1499\n\
         international\t20000\t4999\n"
    }

    #[test]
    fn selects_first_band_at_or_above_weight() -> Result<(), Box<dyn Error>> {
        let rate_card = parse_rate_card(sample_rate_card())?;
        let quote = quote_from_rate_card(
            &Parcel {
                weight_grams: 501,
                zone: "domestic".to_owned(),
            },
            &rate_card,
        )?;

        assert_eq!(
            quote,
            Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2000,
            }
        );
        Ok(())
    }

    #[test]
    fn adds_weight_and_international_surcharges() -> Result<(), Box<dyn Error>> {
        let rate_card = parse_rate_card(sample_rate_card())?;
        let quote = quote_from_rate_card(
            &Parcel {
                weight_grams: 15_000,
                zone: "international".to_owned(),
            },
            &rate_card,
        )?;

        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20_000);
        Ok(())
    }

    #[test]
    fn rounds_international_surcharge_half_up() -> Result<(), Box<dyn Error>> {
        let rate_card = parse_rate_card("international\t500\t108\n")?;
        let quote = quote_from_rate_card(
            &Parcel {
                weight_grams: 100,
                zone: "international".to_owned(),
            },
            &rate_card,
        )?;

        assert_eq!(quote.surcharge_cents, 22);
        assert_eq!(quote.total_cents, 130);
        Ok(())
    }

    #[test]
    fn reports_unknown_zone() -> Result<(), Box<dyn Error>> {
        let rate_card = parse_rate_card(sample_rate_card())?;
        let error = quote_from_rate_card(
            &Parcel {
                weight_grams: 100,
                zone: "express".to_owned(),
            },
            &rate_card,
        )
        .err()
        .ok_or_else(|| io::Error::other("expected unknown zone"))?;

        assert_eq!(error, QuoteError::UnknownZone("express".to_owned()));
        Ok(())
    }

    #[test]
    fn reports_overweight_with_zone_limit() -> Result<(), Box<dyn Error>> {
        let rate_card = parse_rate_card(sample_rate_card())?;
        let error = quote_from_rate_card(
            &Parcel {
                weight_grams: 20_001,
                zone: "domestic".to_owned(),
            },
            &rate_card,
        )
        .err()
        .ok_or_else(|| io::Error::other("expected overweight"))?;

        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            }
        );
        Ok(())
    }

    #[test]
    fn reports_malformed_line_number() -> Result<(), Box<dyn Error>> {
        let error = parse_rate_card("# ignored\n\n domestic\t500\t599\nbad\n")
            .err()
            .ok_or_else(|| io::Error::other("expected malformed line"))?;

        assert_eq!(error, QuoteError::MalformedRateCard { line: 4 });
        Ok(())
    }

    #[test]
    fn quote_reads_ratecard_path() -> Result<(), Box<dyn Error>> {
        let _guard = env_lock().lock().map_err(|_error| io::Error::other("env lock poisoned"))?;
        let old_path = env::var_os("RATECARD_PATH");
        let path = temp_ratecard_path()?;
        let mut file = File::create(&path)?;
        file.write_all(sample_rate_card().as_bytes())?;
        env::set_var("RATECARD_PATH", &path);

        let result = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".to_owned(),
        });

        restore_ratecard_path(old_path);
        fs::remove_file(path)?;
        assert_eq!(result?.total_cents, 599);
        Ok(())
    }

    #[test]
    fn missing_ratecard_path_is_unavailable() -> Result<(), Box<dyn Error>> {
        let _guard = env_lock().lock().map_err(|_error| io::Error::other("env lock poisoned"))?;
        let old_path = env::var_os("RATECARD_PATH");
        env::remove_var("RATECARD_PATH");

        let result = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".to_owned(),
        });

        restore_ratecard_path(old_path);
        assert_eq!(result, Err(QuoteError::RateCardUnavailable));
        Ok(())
    }

    fn restore_ratecard_path(old_path: Option<OsString>) {
        match old_path {
            Some(path) => env::set_var("RATECARD_PATH", path),
            None => env::remove_var("RATECARD_PATH"),
        }
    }

    fn temp_ratecard_path() -> Result<PathBuf, Box<dyn Error>> {
        let stamp = SystemTime::now().duration_since(UNIX_EPOCH)?;
        Ok(env::temp_dir().join(format!(
            "ratecard-{}-{}.tsv",
            std::process::id(),
            stamp.as_nanos()
        )))
    }
}
