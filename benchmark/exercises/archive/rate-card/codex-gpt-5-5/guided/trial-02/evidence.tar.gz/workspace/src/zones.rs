//! Human-readable labels for known shipping zones.

/// Return the display label for a shipping zone.
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}
