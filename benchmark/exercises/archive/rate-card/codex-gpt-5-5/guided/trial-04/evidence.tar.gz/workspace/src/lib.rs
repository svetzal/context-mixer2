use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band =
        bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands.last().map(|band| band.max_grams).unwrap_or(0),
            }
        })?;

    let base_cents = band.cents;
    let surcharge_cents = surcharge_cents(parcel, base_cents);
    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "ratecard_quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut card: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields = line.split('\t').collect::<Vec<_>>();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        }

        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;

        card.entry(fields[0].to_owned()).or_default().push(Band { max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(card)
}

fn surcharge_cents(parcel: &Parcel, base_cents: u64) -> u64 {
    let weight_surcharge = if parcel.weight_grams > 10_000 { 500 } else { 0 };
    let zone_surcharge = if parcel.zone == "international" {
        (base_cents * 20 + 50) / 100
    } else {
        0
    };

    weight_surcharge + zone_surcharge
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(formatter, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::sync::{Mutex, OnceLock};

    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    fn with_rate_card<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        let _guard = env_lock().lock().unwrap();
        let path = temp_rate_card_path();
        fs::write(&path, contents).unwrap();
        env::set_var("RATECARD_PATH", &path);
        let result = test();
        env::remove_var("RATECARD_PATH");
        fs::remove_file(path).unwrap();
        result
    }

    fn temp_rate_card_path() -> PathBuf {
        static NEXT_ID: AtomicUsize = AtomicUsize::new(0);
        env::temp_dir().join(format!(
            "ratecard-test-{}-{}.tsv",
            std::process::id(),
            NEXT_ID.fetch_add(1, Ordering::Relaxed)
        ))
    }

    fn sample_card() -> &'static str {
        "# zone\tband_max_grams\tcents\n\
         domestic\t500\t599\n\
         domestic\t2000\t899\n\
         domestic\t20000\t1799\n\
         international\t500\t1499\n\
         international\t20000\t4999\n"
    }

    #[test]
    fn quotes_first_matching_band() {
        with_rate_card(sample_card(), || {
            let parcel = Parcel {
                weight_grams: 501,
                zone: "domestic".to_owned(),
            };

            assert_eq!(
                quote(&parcel).unwrap(),
                Quote {
                    base_cents: 899,
                    surcharge_cents: 0,
                    total_cents: 899,
                    band_max_grams: 2000,
                }
            );
        });
    }

    #[test]
    fn adds_weight_and_international_surcharges() {
        with_rate_card(sample_card(), || {
            let parcel = Parcel {
                weight_grams: 10_001,
                zone: "international".to_owned(),
            };

            assert_eq!(
                quote(&parcel).unwrap(),
                Quote {
                    base_cents: 4999,
                    surcharge_cents: 1500,
                    total_cents: 6499,
                    band_max_grams: 20000,
                }
            );
        });
    }

    #[test]
    fn reports_unknown_zone() {
        with_rate_card(sample_card(), || {
            let parcel = Parcel {
                weight_grams: 100,
                zone: "lunar".to_owned(),
            };

            assert_eq!(quote(&parcel), Err(QuoteError::UnknownZone("lunar".to_owned())));
        });
    }

    #[test]
    fn reports_overweight_with_largest_zone_band() {
        with_rate_card(sample_card(), || {
            let parcel = Parcel {
                weight_grams: 20_001,
                zone: "domestic".to_owned(),
            };

            assert_eq!(
                quote(&parcel),
                Err(QuoteError::Overweight {
                    grams: 20_001,
                    limit: 20_000,
                })
            );
        });
    }

    #[test]
    fn reports_malformed_line_number_counting_comments_and_blanks() {
        with_rate_card("# comment\n\nbad line\n", || {
            let parcel = Parcel {
                weight_grams: 100,
                zone: "domestic".to_owned(),
            };

            assert_eq!(quote(&parcel), Err(QuoteError::MalformedRateCard { line: 3 }));
        });
    }

    #[test]
    fn unavailable_when_environment_is_unset() {
        let _guard = env_lock().lock().unwrap();
        env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        };

        assert_eq!(quote(&parcel), Err(QuoteError::RateCardUnavailable));
    }
}
