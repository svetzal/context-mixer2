//! Shipping quotes from an operations-managed rate card.

use std::collections::BTreeMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

/// Parcel details required to price a shipment.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Requested rate-card zone.
    pub zone: String,
}

/// A calculated shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Matched rate-card band price.
    pub base_cents: u64,
    /// Total surcharge amount added to the base price.
    pub surcharge_cents: u64,
    /// Final quote amount.
    pub total_cents: u64,
    /// Maximum weight for the matched band.
    pub band_max_grams: u32,
}

/// Errors returned when a quote cannot be calculated.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card path is unset, unreadable, or otherwise unavailable.
    RateCardUnavailable,
    /// A rate-card line has the wrong shape or contains invalid numbers.
    MalformedRateCard {
        /// One-based line number in the rate card.
        line: usize,
    },
    /// The requested zone does not appear in the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the largest band for its zone.
    Overweight {
        /// Requested parcel weight in grams.
        grams: u32,
        /// Largest configured band for the requested zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown zone {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

type RateCard = BTreeMap<String, Vec<Band>>;

/// Calculate a quote for a parcel using the rate card at `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let Some(band) = bands.iter().find(|band| parcel.weight_grams <= band.max_grams) else {
        let limit = bands.last().map_or(0, |band| band.max_grams);
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        });
    };

    let surcharge_cents = surcharge_cents(parcel, band.cents);
    let total_cents = band.cents + surcharge_cents;
    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut rate_card: RateCard = BTreeMap::new();

    for (index, line) in contents.lines().enumerate() {
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        }

        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;

        rate_card
            .entry(fields[0].to_owned())
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(rate_card)
}

fn surcharge_cents(parcel: &Parcel, base_cents: u64) -> u64 {
    let heavy_surcharge = if parcel.weight_grams > 10_000 { 500 } else { 0 };
    let international_surcharge = if parcel.zone == "international" {
        (base_cents * 20 + 50) / 100
    } else {
        0
    };

    heavy_surcharge + international_surcharge
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::io::Write;
    use std::path::PathBuf;
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::sync::{Mutex, MutexGuard, OnceLock};

    const RATE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn quotes_matching_band_for_zone() {
        let _rate_card = rate_card_env(RATE_CARD);
        let quote = quote(&Parcel {
            weight_grams: 1_500,
            zone: "domestic".to_owned(),
        })
        .expect("quote should be calculated");

        assert_eq!(
            quote,
            Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2_000,
            }
        );
    }

    #[test]
    fn adds_weight_and_international_surcharges() {
        let _rate_card = rate_card_env(RATE_CARD);
        let quote = quote(&Parcel {
            weight_grams: 12_000,
            zone: "international".to_owned(),
        })
        .expect("quote should be calculated");

        assert_eq!(quote.base_cents, 4_999);
        assert_eq!(quote.surcharge_cents, 1_500);
        assert_eq!(quote.total_cents, 6_499);
        assert_eq!(quote.band_max_grams, 20_000);
    }

    #[test]
    fn sorts_bands_before_matching() {
        let _rate_card = rate_card_env("domestic\t2000\t899\ndomestic\t500\t599\n");
        let quote = quote(&Parcel {
            weight_grams: 400,
            zone: "domestic".to_owned(),
        })
        .expect("quote should be calculated");

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn reports_unknown_zone() {
        let _rate_card = rate_card_env(RATE_CARD);
        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "lunar".to_owned(),
        })
        .expect_err("unknown zone should fail");

        assert_eq!(error, QuoteError::UnknownZone("lunar".to_owned()));
    }

    #[test]
    fn reports_overweight_with_largest_zone_band() {
        let _rate_card = rate_card_env(RATE_CARD);
        let error = quote(&Parcel {
            weight_grams: 25_000,
            zone: "domestic".to_owned(),
        })
        .expect_err("overweight parcel should fail");

        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000,
            }
        );
    }

    #[test]
    fn reports_unavailable_rate_card_when_env_is_unset() {
        let _guard = env_lock().lock().expect("env lock should not be poisoned");
        env::remove_var("RATECARD_PATH");
        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        })
        .expect_err("missing rate card should fail");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn reports_malformed_line_number_counting_comments_and_blanks() {
        let _rate_card = rate_card_env("# header\n\ndomestic\t500\t599\ndomestic\tbad\t899\n");
        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        })
        .expect_err("malformed rate card should fail");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn display_and_error_are_implemented() {
        let error = QuoteError::Overweight {
            grams: 10,
            limit: 5,
        };
        let as_error: &dyn Error = &error;

        assert_eq!(error.to_string(), "parcel weight 10g exceeds zone limit 5g");
        assert_eq!(as_error.to_string(), "parcel weight 10g exceeds zone limit 5g");
    }

    struct RateCardEnv {
        path: PathBuf,
        _guard: MutexGuard<'static, ()>,
    }

    impl Drop for RateCardEnv {
        fn drop(&mut self) {
            let _ = fs::remove_file(&self.path);
        }
    }

    fn rate_card_env(contents: &str) -> RateCardEnv {
        let guard = env_lock().lock().expect("env lock should not be poisoned");
        let path = temp_rate_card_path();
        let mut file = fs::File::create(&path).expect("temp file should be created");
        file.write_all(contents.as_bytes()).expect("rate card should be written");
        env::set_var("RATECARD_PATH", &path);
        RateCardEnv {
            path,
            _guard: guard,
        }
    }

    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    fn temp_rate_card_path() -> PathBuf {
        static NEXT_ID: AtomicUsize = AtomicUsize::new(0);
        env::temp_dir().join(format!(
            "ratecard-test-{}-{}.tsv",
            std::process::id(),
            NEXT_ID.fetch_add(1, Ordering::Relaxed)
        ))
    }
}
