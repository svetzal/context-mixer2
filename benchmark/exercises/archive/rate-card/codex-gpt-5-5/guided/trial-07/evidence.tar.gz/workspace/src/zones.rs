//! Display labels for known shipping zones.

/// Return a human-readable label for a zone.
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}
