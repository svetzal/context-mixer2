use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown shipping zone {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy)]
struct Band {
    max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let selected =
        bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands.last().map_or(0, |band| band.max_grams),
            }
        })?;

    let surcharge_cents = weight_surcharge(parcel.weight_grams)
        + international_surcharge(parcel.zone.as_str(), selected.cents);
    let total_cents = selected.cents + surcharge_cents;

    emit_diagnostic(parcel, total_cents);

    Ok(Quote {
        base_cents: selected.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: selected.max_grams,
    })
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut rate_card: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        if line.trim().is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        }

        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;

        rate_card
            .entry(fields[0].to_string())
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(rate_card)
}

fn weight_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > 10_000 {
        500
    } else {
        0
    }
}

fn international_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == "international" {
        (base_cents * 20 + 50) / 100
    } else {
        0
    }
}

fn emit_diagnostic(parcel: &Parcel, total_cents: u64) {
    eprintln!(
        "ratecard_quote\tzone={}\tweight_grams={}\ttotal_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::{Path, PathBuf};
    use std::sync::atomic::{AtomicU64, Ordering};
    use std::sync::{Mutex, OnceLock};

    static ENV_LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    static TEMP_FILE_COUNTER: AtomicU64 = AtomicU64::new(0);

    struct TestRateCard {
        path: PathBuf,
    }

    impl TestRateCard {
        fn path(&self) -> &Path {
            &self.path
        }
    }

    impl Drop for TestRateCard {
        fn drop(&mut self) {
            let _ = fs::remove_file(&self.path);
        }
    }

    fn env_lock() -> &'static Mutex<()> {
        ENV_LOCK.get_or_init(|| Mutex::new(()))
    }

    fn write_rate_card(contents: &str) -> TestRateCard {
        let counter = TEMP_FILE_COUNTER.fetch_add(1, Ordering::Relaxed);
        let path =
            env::temp_dir().join(format!("ratecard-test-{}-{counter}.tsv", std::process::id()));
        fs::write(&path, contents).expect("write temp rate card");
        TestRateCard { path }
    }

    fn sample_card() -> TestRateCard {
        write_rate_card(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n\
             international\t500\t1499\n\
             international\t20000\t4999\n",
        )
    }

    #[test]
    fn quotes_domestic_parcel_from_matching_band() {
        let _guard = env_lock().lock().expect("lock env");
        let card = sample_card();
        env::set_var("RATECARD_PATH", card.path());

        let quote = quote(&Parcel {
            weight_grams: 501,
            zone: "domestic".to_string(),
        })
        .expect("quote");

        assert_eq!(
            quote,
            Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2000,
            }
        );
    }

    #[test]
    fn adds_weight_and_international_surcharges() {
        let _guard = env_lock().lock().expect("lock env");
        let card = sample_card();
        env::set_var("RATECARD_PATH", card.path());

        let quote = quote(&Parcel {
            weight_grams: 12_000,
            zone: "international".to_string(),
        })
        .expect("quote");

        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20_000);
    }

    #[test]
    fn sorts_bands_before_matching() {
        let _guard = env_lock().lock().expect("lock env");
        let card = write_rate_card("domestic\t2000\t899\ndomestic\t500\t599\n");
        env::set_var("RATECARD_PATH", card.path());

        let quote = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        })
        .expect("quote");

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn reports_unknown_zone() {
        let _guard = env_lock().lock().expect("lock env");
        let card = sample_card();
        env::set_var("RATECARD_PATH", card.path());

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "express".to_string(),
        })
        .expect_err("unknown zone");

        assert_eq!(error, QuoteError::UnknownZone("express".to_string()));
    }

    #[test]
    fn reports_overweight_with_zone_limit() {
        let _guard = env_lock().lock().expect("lock env");
        let card = sample_card();
        env::set_var("RATECARD_PATH", card.path());

        let error = quote(&Parcel {
            weight_grams: 20_001,
            zone: "domestic".to_string(),
        })
        .expect_err("overweight");

        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            }
        );
    }

    #[test]
    fn reports_missing_rate_card() {
        let _guard = env_lock().lock().expect("lock env");
        env::remove_var("RATECARD_PATH");

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("missing rate card");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn reports_malformed_line_number_including_comments_and_blanks() {
        let _guard = env_lock().lock().expect("lock env");
        let card = write_rate_card("# header\n\n domestic 500 599\n");
        env::set_var("RATECARD_PATH", card.path());

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("malformed card");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
    }
}
