//! Shipping quotes from a tab-separated rate card.

use std::collections::BTreeMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

/// A parcel to quote against the configured rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Requested destination zone.
    pub zone: String,
}

/// A successful shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// The matched rate-card band's price in cents before surcharges.
    pub base_cents: u64,
    /// The sum of all surcharges in cents.
    pub surcharge_cents: u64,
    /// The final quote price in cents.
    pub total_cents: u64,
    /// The maximum weight threshold for the matched band.
    pub band_max_grams: u32,
}

/// Errors returned while loading a rate card or calculating a quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset or the referenced file cannot be read.
    RateCardUnavailable,
    /// A rate-card row is not three tab-separated fields or has invalid numbers.
    MalformedRateCard {
        /// The 1-based line number in the input file.
        line: usize,
    },
    /// The requested zone does not exist in the rate card.
    UnknownZone(String),
    /// The parcel exceeds the largest configured band for its zone.
    Overweight {
        /// The requested parcel weight.
        grams: u32,
        /// The largest configured band for the requested zone.
        limit: u32,
    },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct RateBand {
    max_grams: u32,
    cents: u64,
}

type RateCard = BTreeMap<String, Vec<RateBand>>;

/// Calculate a quote for `parcel` using the file named by `RATECARD_PATH`.
///
/// A diagnostic record is emitted to stderr for each successful quote.
///
/// # Errors
///
/// Returns [`QuoteError`] when the rate card cannot be loaded, parsed, or does
/// not contain a usable band for the requested parcel.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band =
        bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: largest_band_limit(bands),
            }
        })?;

    let base_cents = band.cents;
    let surcharge_cents = surcharge_cents(base_cents, parcel);
    let total_cents = base_cents + surcharge_cents;
    let quote = Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    };

    emit_quote_diagnostic(parcel, total_cents);
    Ok(quote)
}

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut rate_card = BTreeMap::<String, Vec<RateBand>>::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        if line.trim().is_empty() || line.trim_start().starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let zone = fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let max_grams = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        rate_card
            .entry(zone.to_owned())
            .or_default()
            .push(RateBand { max_grams, cents });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(rate_card)
}

fn largest_band_limit(bands: &[RateBand]) -> u32 {
    bands
        .iter()
        .map(|band| band.max_grams)
        .max()
        .expect("zone entries are created only with at least one band")
}

fn surcharge_cents(base_cents: u64, parcel: &Parcel) -> u64 {
    let overweight_surcharge = if parcel.weight_grams > 10_000 { 500 } else { 0 };
    let international_surcharge = if parcel.zone == "international" {
        percent_rounded_half_up(base_cents, 20)
    } else {
        0
    };

    overweight_surcharge + international_surcharge
}

fn percent_rounded_half_up(cents: u64, percent: u64) -> u64 {
    (cents * percent + 50) / 100
}

fn emit_quote_diagnostic(parcel: &Parcel, total_cents: u64) {
    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[cfg(test)]
mod tests {
    use super::{quote, Parcel, Quote, QuoteError};
    use std::env;
    use std::fs;
    use std::path::PathBuf;
    use std::sync::atomic::{AtomicU64, Ordering};
    use std::sync::{Mutex, MutexGuard};

    static NEXT_RATE_CARD_ID: AtomicU64 = AtomicU64::new(0);
    static RATECARD_ENV_LOCK: Mutex<()> = Mutex::new(());

    const SAMPLE_RATE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    struct RateCardEnv {
        previous_path: Option<String>,
        path: PathBuf,
        _guard: MutexGuard<'static, ()>,
    }

    impl RateCardEnv {
        fn with_contents(contents: &str) -> Self {
            let guard = RATECARD_ENV_LOCK.lock().expect("lock rate card env");
            let path = env::temp_dir().join(format!(
                "ratecard-test-{}-{}.tsv",
                std::process::id(),
                NEXT_RATE_CARD_ID.fetch_add(1, Ordering::Relaxed)
            ));
            fs::write(&path, contents).expect("write temporary rate card");
            let previous_path = env::var("RATECARD_PATH").ok();
            env::set_var("RATECARD_PATH", &path);
            Self {
                previous_path,
                path,
                _guard: guard,
            }
        }
    }

    impl Drop for RateCardEnv {
        fn drop(&mut self) {
            if let Some(path) = &self.previous_path {
                env::set_var("RATECARD_PATH", path);
            } else {
                env::remove_var("RATECARD_PATH");
            }
            let _ = fs::remove_file(&self.path);
        }
    }

    #[test]
    fn quotes_first_matching_band() {
        let _env = RateCardEnv::with_contents(SAMPLE_RATE_CARD);

        let result = quote(&Parcel {
            weight_grams: 501,
            zone: "domestic".to_owned(),
        });

        assert_eq!(
            result,
            Ok(Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2000,
            })
        );
    }

    #[test]
    fn quotes_summed_surcharges() {
        let _env = RateCardEnv::with_contents(SAMPLE_RATE_CARD);

        let result = quote(&Parcel {
            weight_grams: 15_000,
            zone: "international".to_owned(),
        });

        assert_eq!(
            result,
            Ok(Quote {
                base_cents: 4999,
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20000,
            })
        );
    }

    #[test]
    fn rejects_unknown_zone() {
        let _env = RateCardEnv::with_contents(SAMPLE_RATE_CARD);

        let result = quote(&Parcel {
            weight_grams: 100,
            zone: "orbital".to_owned(),
        });

        assert_eq!(result, Err(QuoteError::UnknownZone("orbital".to_owned())));
    }

    #[test]
    fn rejects_overweight_parcels_with_zone_limit() {
        let _env = RateCardEnv::with_contents(SAMPLE_RATE_CARD);

        let result = quote(&Parcel {
            weight_grams: 20_001,
            zone: "domestic".to_owned(),
        });

        assert_eq!(
            result,
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            })
        );
    }

    #[test]
    fn rejects_missing_rate_card_path() {
        let _guard = RATECARD_ENV_LOCK.lock().expect("lock rate card env");
        let previous_path = env::var("RATECARD_PATH").ok();
        env::remove_var("RATECARD_PATH");

        let result = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        });

        if let Some(path) = previous_path {
            env::set_var("RATECARD_PATH", path);
        }

        assert_eq!(result, Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn rejects_malformed_rows_with_physical_line_number() {
        let _env = RateCardEnv::with_contents("\n# comment\ndomestic\tnope\t599\n");

        let result = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        });

        assert_eq!(result, Err(QuoteError::MalformedRateCard { line: 3 }));
    }
}
