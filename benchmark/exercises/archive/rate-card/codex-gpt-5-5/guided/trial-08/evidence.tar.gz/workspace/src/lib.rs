//! Shipping quote calculation from a tab-separated zone rate card.

pub mod zones;

use std::collections::BTreeMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

/// A parcel to quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Shipping zone requested by the caller.
    pub zone: String,
}

/// A calculated shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Base rate selected from the matching rate-card band.
    pub base_cents: u64,
    /// Sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// Base rate plus surcharges.
    pub total_cents: u64,
    /// Maximum weight for the selected rate-card band.
    pub band_max_grams: u32,
}

/// Errors returned while loading the rate card or calculating a quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` was unset or the pointed-to file could not be read.
    RateCardUnavailable,
    /// A rate-card line was not three tab-separated fields or had invalid numbers.
    MalformedRateCard { line: usize },
    /// The requested zone does not appear in the loaded rate card.
    UnknownZone(String),
    /// The parcel is heavier than the largest band for its zone.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown shipping zone {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

type RateCard = BTreeMap<String, Vec<Band>>;

/// Calculate a quote for `parcel` using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let selected =
        bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands.last().map_or(0, |band| band.max_grams),
            }
        })?;

    let base_cents = selected.cents;
    let surcharge_cents =
        weight_surcharge(parcel.weight_grams) + international_surcharge(&parcel.zone, base_cents);
    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: selected.max_grams,
    })
}

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut rate_card: RateCard = BTreeMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        if line.trim().is_empty() || line.trim_start().starts_with('#') {
            continue;
        }

        let fields = line.split('\t').collect::<Vec<_>>();
        let [zone, max_grams, cents] = fields.as_slice() else {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        };

        let max_grams = max_grams
            .trim()
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = cents
            .trim()
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        rate_card
            .entry(zone.trim().to_owned())
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(rate_card)
}

fn weight_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > 10_000 {
        500
    } else {
        0
    }
}

fn international_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == "international" {
        (base_cents * 20 + 50) / 100
    } else {
        0
    }
}

#[cfg(test)]
mod tests {
    use super::{quote, Parcel, Quote, QuoteError};
    use std::env;
    use std::fs;
    use std::path::PathBuf;
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::sync::{Mutex, MutexGuard};

    static ENV_LOCK: Mutex<()> = Mutex::new(());
    static FILE_COUNTER: AtomicUsize = AtomicUsize::new(0);

    fn env_lock() -> MutexGuard<'static, ()> {
        ENV_LOCK.lock().expect("environment lock should not be poisoned")
    }

    fn rate_card_file(contents: &str) -> PathBuf {
        let counter = FILE_COUNTER.fetch_add(1, Ordering::Relaxed);
        let path =
            env::temp_dir().join(format!("ratecard-test-{}-{counter}.tsv", std::process::id()));
        fs::write(&path, contents).expect("write rate card");
        path
    }

    fn with_rate_card<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        let _guard = env_lock();
        let previous = env::var_os("RATECARD_PATH");
        let file = rate_card_file(contents);
        env::set_var("RATECARD_PATH", &file);

        let result = test();

        if let Some(path) = previous {
            env::set_var("RATECARD_PATH", path);
        } else {
            env::remove_var("RATECARD_PATH");
        }
        let _ = fs::remove_file(file);

        result
    }

    #[test]
    fn quotes_first_band_that_can_carry_weight() {
        with_rate_card(
            "# zone\tband_max_grams\tcents\n\
             domestic\t20000\t1799\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n",
            || {
                let parcel = Parcel {
                    weight_grams: 1_200,
                    zone: "domestic".to_owned(),
                };

                assert_eq!(
                    quote(&parcel),
                    Ok(Quote {
                        base_cents: 899,
                        surcharge_cents: 0,
                        total_cents: 899,
                        band_max_grams: 2_000,
                    })
                );
            },
        );
    }

    #[test]
    fn adds_weight_and_international_surcharges() {
        with_rate_card("international\t20000\t4999\n", || {
            let parcel = Parcel {
                weight_grams: 15_000,
                zone: "international".to_owned(),
            };

            assert_eq!(
                quote(&parcel),
                Ok(Quote {
                    base_cents: 4_999,
                    surcharge_cents: 1_500,
                    total_cents: 6_499,
                    band_max_grams: 20_000,
                })
            );
        });
    }

    #[test]
    fn reports_unknown_zone() {
        with_rate_card("domestic\t500\t599\n", || {
            let parcel = Parcel {
                weight_grams: 100,
                zone: "regional".to_owned(),
            };

            assert_eq!(quote(&parcel), Err(QuoteError::UnknownZone("regional".to_owned())));
        });
    }

    #[test]
    fn reports_overweight_with_largest_zone_limit() {
        with_rate_card("domestic\t500\t599\ndomestic\t2000\t899\n", || {
            let parcel = Parcel {
                weight_grams: 2_001,
                zone: "domestic".to_owned(),
            };

            assert_eq!(
                quote(&parcel),
                Err(QuoteError::Overweight {
                    grams: 2_001,
                    limit: 2_000,
                })
            );
        });
    }

    #[test]
    fn reports_unavailable_card_when_env_is_unset() {
        let _guard = env_lock();
        let previous = env::var_os("RATECARD_PATH");
        env::remove_var("RATECARD_PATH");

        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        };
        assert_eq!(quote(&parcel), Err(QuoteError::RateCardUnavailable));

        if let Some(path) = previous {
            env::set_var("RATECARD_PATH", path);
        }
    }

    #[test]
    fn reports_malformed_line_number_counting_comments_and_blanks() {
        with_rate_card("# header\n\ndomestic\t500\t599\nbad\tline\n", || {
            let parcel = Parcel {
                weight_grams: 100,
                zone: "domestic".to_owned(),
            };

            assert_eq!(quote(&parcel), Err(QuoteError::MalformedRateCard { line: 4 }));
        });
    }
}
