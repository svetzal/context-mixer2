//! Shipping quote calculation from a tab-separated rate card.

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

/// Parcel details used to calculate a shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Requested shipping zone.
    pub zone: String,
}

/// Calculated shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Base rate selected from the matching rate-card band.
    pub base_cents: u64,
    /// Sum of all surcharges applied to the base rate.
    pub surcharge_cents: u64,
    /// Final payable total.
    pub total_cents: u64,
    /// Upper weight threshold of the selected band.
    pub band_max_grams: u32,
}

/// Errors returned while loading the rate card or calculating a quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card path is unset or the file cannot be read.
    RateCardUnavailable,
    /// A rate-card line does not match the expected tab-separated format.
    MalformedRateCard { line: usize },
    /// The requested zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the largest band for its zone.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card is malformed on line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

type RateCard = HashMap<String, Vec<Band>>;

/// Calculate a shipping quote for a parcel.
///
/// The rate card is loaded from the file named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band =
        bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands.last().map_or(0, |band| band.max_grams),
            }
        })?;

    let base_cents = band.cents;
    let surcharge_cents = surcharge_cents(parcel, base_cents);
    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "ratecard_quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut rate_card: RateCard = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields = line.split('\t').collect::<Vec<_>>();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: index + 1 });
        }

        let band = Band {
            max_grams: fields[1]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?,
            cents: fields[2]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?,
        };

        rate_card.entry(fields[0].to_owned()).or_default().push(band);
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(rate_card)
}

fn surcharge_cents(parcel: &Parcel, base_cents: u64) -> u64 {
    let weight_surcharge = if parcel.weight_grams > 10_000 { 500 } else { 0 };
    let zone_surcharge = if parcel.zone == "international" {
        rounded_percentage(base_cents, 20)
    } else {
        0
    };

    weight_surcharge + zone_surcharge
}

fn rounded_percentage(cents: u64, percent: u64) -> u64 {
    (cents * percent + 50) / 100
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::path::PathBuf;
    use std::process;
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::sync::{Mutex, OnceLock};

    static ENV_LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    static TEMP_FILE_COUNTER: AtomicUsize = AtomicUsize::new(0);

    fn with_rate_card<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        let _guard = ENV_LOCK
            .get_or_init(|| Mutex::new(()))
            .lock()
            .expect("environment lock should not be poisoned");
        let path = temp_rate_card_path();
        fs::write(&path, contents).expect("rate card temp file should be written");
        env::set_var("RATECARD_PATH", &path);

        let result = test();

        env::remove_var("RATECARD_PATH");
        fs::remove_file(path).expect("rate card temp file should be removed");
        result
    }

    fn temp_rate_card_path() -> PathBuf {
        let id = TEMP_FILE_COUNTER.fetch_add(1, Ordering::Relaxed);
        env::temp_dir().join(format!("ratecard-test-{}-{id}.tsv", process::id()))
    }

    fn sample_rate_card() -> &'static str {
        "# zone\tband_max_grams\tcents\n\
         domestic\t500\t599\n\
         domestic\t2000\t899\n\
         domestic\t20000\t1799\n\
         international\t500\t1499\n\
         international\t20000\t4999\n"
    }

    #[test]
    fn quotes_first_matching_band_for_zone() {
        with_rate_card(sample_rate_card(), || {
            let quote = quote(&Parcel {
                weight_grams: 501,
                zone: "domestic".to_owned(),
            })
            .expect("domestic parcel should be quoted");

            assert_eq!(
                quote,
                Quote {
                    base_cents: 899,
                    surcharge_cents: 0,
                    total_cents: 899,
                    band_max_grams: 2000,
                }
            );
        });
    }

    #[test]
    fn combines_weight_and_international_surcharges() {
        with_rate_card(sample_rate_card(), || {
            let quote = quote(&Parcel {
                weight_grams: 10_001,
                zone: "international".to_owned(),
            })
            .expect("international parcel should be quoted");

            assert_eq!(quote.base_cents, 4999);
            assert_eq!(quote.surcharge_cents, 1500);
            assert_eq!(quote.total_cents, 6499);
            assert_eq!(quote.band_max_grams, 20000);
        });
    }

    #[test]
    fn sorts_bands_before_matching() {
        with_rate_card("domestic\t20000\t1799\ndomestic\t500\t599\n", || {
            let quote = quote(&Parcel {
                weight_grams: 300,
                zone: "domestic".to_owned(),
            })
            .expect("domestic parcel should be quoted");

            assert_eq!(quote.base_cents, 599);
            assert_eq!(quote.band_max_grams, 500);
        });
    }

    #[test]
    fn reports_unknown_zone() {
        with_rate_card(sample_rate_card(), || {
            let error = quote(&Parcel {
                weight_grams: 100,
                zone: "express".to_owned(),
            })
            .expect_err("unknown zone should fail");

            assert_eq!(error, QuoteError::UnknownZone("express".to_owned()));
        });
    }

    #[test]
    fn reports_overweight_with_zone_limit() {
        with_rate_card(sample_rate_card(), || {
            let error = quote(&Parcel {
                weight_grams: 20_001,
                zone: "domestic".to_owned(),
            })
            .expect_err("overweight parcel should fail");

            assert_eq!(
                error,
                QuoteError::Overweight {
                    grams: 20_001,
                    limit: 20_000,
                }
            );
        });
    }

    #[test]
    fn reports_unavailable_rate_card() {
        let _guard = ENV_LOCK
            .get_or_init(|| Mutex::new(()))
            .lock()
            .expect("environment lock should not be poisoned");
        env::remove_var("RATECARD_PATH");

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        })
        .expect_err("missing RATECARD_PATH should fail");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn reports_malformed_line_number_including_comments_and_blanks() {
        with_rate_card("# heading\n\ndomestic\t500\t599\nbroken\n", || {
            let error = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".to_owned(),
            })
            .expect_err("malformed line should fail");

            assert_eq!(error, QuoteError::MalformedRateCard { line: 4 });
        });
    }

    #[test]
    fn reports_malformed_numbers() {
        with_rate_card("domestic\tmany\t599\n", || {
            let error = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".to_owned(),
            })
            .expect_err("malformed number should fail");

            assert_eq!(error, QuoteError::MalformedRateCard { line: 1 });
        });
    }
}
