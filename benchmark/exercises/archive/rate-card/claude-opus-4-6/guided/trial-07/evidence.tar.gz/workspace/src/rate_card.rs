use crate::{Quote, QuoteError};
use std::collections::HashMap;

pub(crate) struct Band {
    max_grams: u32,
    cents: u64,
}

pub fn parse(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut bands: HashMap<String, Vec<Band>> = HashMap::new();

    for (i, line) in contents.lines().enumerate() {
        let line_number = i + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        bands
            .entry(parts[0].to_owned())
            .or_default()
            .push(Band { max_grams, cents });
    }

    for zone_bands in bands.values_mut() {
        zone_bands.sort_by_key(|b| b.max_grams);
    }

    Ok(bands)
}

pub fn calculate(
    bands: &HashMap<String, Vec<Band>>,
    zone: &str,
    weight_grams: u32,
) -> Result<Quote, QuoteError> {
    let zone_bands = bands
        .get(zone)
        .ok_or_else(|| QuoteError::UnknownZone(zone.to_owned()))?;

    let band = zone_bands
        .iter()
        .find(|b| weight_grams <= b.max_grams)
        .ok_or_else(|| {
            let limit = zone_bands.last().map_or(0, |b| b.max_grams);
            QuoteError::Overweight {
                grams: weight_grams,
                limit,
            }
        })?;

    let base_cents = band.cents;

    let mut surcharge_cents: u64 = 0;
    if weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if zone == "international" {
        // 20% of base_cents, rounded half-up
        surcharge_cents += (u128::from(base_cents) * 20 + 50) as u64 / 100;
    }

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_sorts_bands() {
        let input = "domestic\t2000\t899\ndomestic\t500\t599\n";
        let bands = parse(input).unwrap();
        let domestic = &bands["domestic"];
        assert_eq!(domestic[0].max_grams, 500);
        assert_eq!(domestic[1].max_grams, 2000);
    }

    #[test]
    fn international_rounding_half_up() {
        let input = "international\t10000\t1499\n";
        let bands = parse(input).unwrap();
        let q = calculate(&bands, "international", 100).unwrap();
        // 1499 * 20 / 100 = 299.8 -> 300
        assert_eq!(q.surcharge_cents, 300);
    }

    #[test]
    fn international_exact_20_percent() {
        let input = "international\t10000\t1000\n";
        let bands = parse(input).unwrap();
        let q = calculate(&bands, "international", 100).unwrap();
        // 1000 * 20 / 100 = 200.0 -> 200
        assert_eq!(q.surcharge_cents, 200);
    }
}
