mod rate_card;

use std::env;
use std::fmt;
use std::fs;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "overweight: {grams}g exceeds limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = rate_card::parse(&contents)?;
    let result = rate_card::calculate(&bands, &parcel.zone, parcel.weight_grams)?;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = result.total_cents,
        "quote calculated"
    );

    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn quote_from_str(card: &str, zone: &str, weight: u32) -> Result<Quote, QuoteError> {
        let bands = rate_card::parse(card)?;
        rate_card::calculate(&bands, zone, weight)
    }

    #[test]
    fn domestic_light_parcel() {
        let q = quote_from_str(SAMPLE_CARD, "domestic", 200).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_exact_band_boundary() {
        let q = quote_from_str(SAMPLE_CARD, "domestic", 500).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_second_band() {
        let q = quote_from_str(SAMPLE_CARD, "domestic", 501).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn domestic_heavy_surcharge() {
        let q = quote_from_str(SAMPLE_CARD, "domestic", 15000).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn international_surcharge_rounding() {
        let q = quote_from_str(SAMPLE_CARD, "international", 300).unwrap();
        assert_eq!(q.base_cents, 1499);
        // 20% of 1499 = 299.8 -> rounded half-up = 300
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_heavy_both_surcharges() {
        let q = quote_from_str(SAMPLE_CARD, "international", 15000).unwrap();
        assert_eq!(q.base_cents, 4999);
        // 20% of 4999 = 999.8 -> 1000, plus 500 for heavy
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone() {
        let err = quote_from_str(SAMPLE_CARD, "mars", 100).unwrap_err();
        assert!(matches!(err, QuoteError::UnknownZone(z) if z == "mars"));
    }

    #[test]
    fn overweight() {
        let err = quote_from_str(SAMPLE_CARD, "domestic", 25000).unwrap_err();
        assert!(matches!(err, QuoteError::Overweight { grams: 25000, limit: 20000 }));
    }

    #[test]
    fn missing_env_var() {
        env::remove_var("RATECARD_PATH");
        let p = Parcel { weight_grams: 100, zone: "domestic".into() };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn unreadable_path() {
        env::set_var("RATECARD_PATH", "/no/such/file");
        let p = Parcel { weight_grams: 100, zone: "domestic".into() };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn malformed_line() {
        let card = "domestic\t500\t599\nbad line\ndomestic\t2000\t899\n";
        let err = quote_from_str(card, "domestic", 100).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 2 }));
    }

    #[test]
    fn malformed_number() {
        let card = "domestic\tabc\t599\n";
        let err = quote_from_str(card, "domestic", 100).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn comments_and_blanks_skipped() {
        let card = "# header\n\ndomestic\t1000\t599\n";
        let q = quote_from_str(card, "domestic", 500).unwrap();
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn malformed_after_comment_reports_correct_line() {
        let card = "# header\n\nbad\n";
        let err = quote_from_str(card, "domestic", 100).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn error_display() {
        let e = QuoteError::RateCardUnavailable;
        assert!(!e.to_string().is_empty());
        let e = QuoteError::MalformedRateCard { line: 5 };
        assert!(e.to_string().contains('5'));
        let e = QuoteError::UnknownZone("mars".into());
        assert!(e.to_string().contains("mars"));
        let e = QuoteError::Overweight { grams: 100, limit: 50 };
        assert!(e.to_string().contains("100"));
    }

    #[test]
    fn error_is_std_error() {
        let e: Box<dyn std::error::Error> = Box::new(QuoteError::RateCardUnavailable);
        let _ = e.to_string();
    }
}
