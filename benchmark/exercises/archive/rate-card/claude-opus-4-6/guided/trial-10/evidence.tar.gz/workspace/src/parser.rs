use crate::QuoteError;

#[derive(Debug)]
pub struct Band {
    pub zone: String,
    pub band_max_grams: u32,
    pub cents: u64,
}

pub fn parse_rate_card(content: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();
    for (i, line) in content.lines().enumerate() {
        let line_number = i + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let band_max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        bands.push(Band {
            zone: fields[0].to_string(),
            band_max_grams,
            cents,
        });
    }
    Ok(bands)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_valid_card() {
        let input = "# header\ndomestic\t500\t599\ndomestic\t2000\t899\n";
        let bands = parse_rate_card(input).unwrap();
        assert_eq!(bands.len(), 2);
        assert_eq!(bands[0].zone, "domestic");
        assert_eq!(bands[0].band_max_grams, 500);
        assert_eq!(bands[0].cents, 599);
        assert_eq!(bands[1].band_max_grams, 2000);
    }

    #[test]
    fn skips_blank_and_comment_lines() {
        let input = "\n# comment\n\ndomestic\t500\t599\n\n";
        let bands = parse_rate_card(input).unwrap();
        assert_eq!(bands.len(), 1);
    }

    #[test]
    fn wrong_field_count_is_malformed() {
        let input = "domestic\t500\n";
        let err = parse_rate_card(input).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            _ => panic!("expected MalformedRateCard"),
        }
    }

    #[test]
    fn non_numeric_grams_is_malformed() {
        let input = "domestic\tabc\t599\n";
        let err = parse_rate_card(input).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            _ => panic!("expected MalformedRateCard"),
        }
    }

    #[test]
    fn non_numeric_cents_is_malformed() {
        let input = "domestic\t500\txyz\n";
        let err = parse_rate_card(input).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            _ => panic!("expected MalformedRateCard"),
        }
    }

    #[test]
    fn malformed_line_number_accounts_for_comments_and_blanks() {
        let input = "# comment\n\ndomestic\t500\t599\nbad line\n";
        let err = parse_rate_card(input).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 4),
            _ => panic!("expected MalformedRateCard"),
        }
    }
}
