use std::io::Write;

use ratecard::{Parcel, QuoteError, quote};

fn rate_card_content() -> &'static str {
    "# zone\tband_max_grams\tcents\n\
     domestic\t500\t599\n\
     domestic\t2000\t899\n\
     domestic\t20000\t1799\n\
     international\t500\t1499\n\
     international\t20000\t4999\n"
}

fn with_rate_card<F: FnOnce()>(content: &str, f: F) {
    let mut tmp = tempfile::NamedTempFile::new().unwrap();
    tmp.write_all(content.as_bytes()).unwrap();
    tmp.flush().unwrap();
    std::env::set_var("RATECARD_PATH", tmp.path());
    f();
    std::env::remove_var("RATECARD_PATH");
}

#[test]
fn domestic_small_parcel() {
    with_rate_card(rate_card_content(), || {
        let parcel = Parcel { weight_grams: 200, zone: "domestic".into() };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    });
}

#[test]
fn international_with_surcharge() {
    with_rate_card(rate_card_content(), || {
        let parcel = Parcel { weight_grams: 300, zone: "international".into() };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    });
}

#[test]
fn missing_env_var_is_unavailable() {
    std::env::remove_var("RATECARD_PATH");
    let parcel = Parcel { weight_grams: 100, zone: "domestic".into() };
    let err = quote(&parcel).unwrap_err();
    assert!(matches!(err, QuoteError::RateCardUnavailable));
}

#[test]
fn nonexistent_file_is_unavailable() {
    std::env::set_var("RATECARD_PATH", "/nonexistent/path/to/ratecard.tsv");
    let parcel = Parcel { weight_grams: 100, zone: "domestic".into() };
    let err = quote(&parcel).unwrap_err();
    assert!(matches!(err, QuoteError::RateCardUnavailable));
    std::env::remove_var("RATECARD_PATH");
}

#[test]
fn unknown_zone_error() {
    with_rate_card(rate_card_content(), || {
        let parcel = Parcel { weight_grams: 100, zone: "mars".into() };
        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::UnknownZone(z) => assert_eq!(z, "mars"),
            _ => panic!("expected UnknownZone"),
        }
    });
}

#[test]
fn overweight_error() {
    with_rate_card(rate_card_content(), || {
        let parcel = Parcel { weight_grams: 25000, zone: "domestic".into() };
        let err = quote(&parcel).unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 25000);
                assert_eq!(limit, 20000);
            }
            _ => panic!("expected Overweight"),
        }
    });
}

#[test]
fn malformed_rate_card() {
    with_rate_card("bad\tdata\n", || {
        let parcel = Parcel { weight_grams: 100, zone: "domestic".into() };
        let err = quote(&parcel).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    });
}

#[test]
fn error_display_messages() {
    assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
    assert_eq!(
        QuoteError::MalformedRateCard { line: 5 }.to_string(),
        "malformed rate card at line 5"
    );
    assert_eq!(
        QuoteError::UnknownZone("mars".into()).to_string(),
        "unknown zone: mars"
    );
    assert_eq!(
        QuoteError::Overweight { grams: 25000, limit: 20000 }.to_string(),
        "parcel weighs 25000g, exceeds limit of 20000g"
    );
}

#[test]
fn error_is_std_error() {
    fn assert_error<E: std::error::Error>() {}
    assert_error::<QuoteError>();
}
