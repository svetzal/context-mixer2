use crate::parser::Band;
use crate::{Parcel, Quote, QuoteError};

pub fn compute_quote(parcel: &Parcel, bands: &[Band]) -> Result<Quote, QuoteError> {
    let mut zone_bands: Vec<&Band> = bands.iter().filter(|b| b.zone == parcel.zone).collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.band_max_grams);

    let Some(matching) = zone_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
    else {
        let limit = zone_bands[zone_bands.len() - 1].band_max_grams;
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        });
    };

    let base_cents = matching.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        surcharge_cents += round_half_up(base_cents * 20, 100);
    }

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: matching.band_max_grams,
    })
}

fn round_half_up(numerator: u64, denominator: u64) -> u64 {
    let quotient = numerator / denominator;
    let remainder = numerator % denominator;
    if remainder * 2 >= denominator {
        quotient + 1
    } else {
        quotient
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn domestic_bands() -> Vec<Band> {
        vec![
            Band { zone: "domestic".into(), band_max_grams: 500, cents: 599 },
            Band { zone: "domestic".into(), band_max_grams: 2000, cents: 899 },
            Band { zone: "domestic".into(), band_max_grams: 20000, cents: 1799 },
        ]
    }

    fn international_bands() -> Vec<Band> {
        vec![
            Band { zone: "international".into(), band_max_grams: 500, cents: 1499 },
            Band { zone: "international".into(), band_max_grams: 20000, cents: 4999 },
        ]
    }

    #[test]
    fn domestic_first_band() {
        let parcel = Parcel { weight_grams: 200, zone: "domestic".into() };
        let q = compute_quote(&parcel, &domestic_bands()).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_exact_boundary() {
        let parcel = Parcel { weight_grams: 500, zone: "domestic".into() };
        let q = compute_quote(&parcel, &domestic_bands()).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_second_band() {
        let parcel = Parcel { weight_grams: 501, zone: "domestic".into() };
        let q = compute_quote(&parcel, &domestic_bands()).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn heavy_domestic_surcharge() {
        let parcel = Parcel { weight_grams: 15000, zone: "domestic".into() };
        let q = compute_quote(&parcel, &domestic_bands()).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn international_surcharge() {
        let parcel = Parcel { weight_grams: 300, zone: "international".into() };
        let q = compute_quote(&parcel, &international_bands()).unwrap();
        assert_eq!(q.base_cents, 1499);
        // 20% of 1499 = 299.8 → 300 (half-up)
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_heavy_both_surcharges() {
        let parcel = Parcel { weight_grams: 15000, zone: "international".into() };
        let q = compute_quote(&parcel, &international_bands()).unwrap();
        assert_eq!(q.base_cents, 4999);
        // 20% of 4999 = 999.8 → 1000 (half-up) + 500 heavy = 1500
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone() {
        let parcel = Parcel { weight_grams: 100, zone: "mars".into() };
        let err = compute_quote(&parcel, &domestic_bands()).unwrap_err();
        match err {
            QuoteError::UnknownZone(z) => assert_eq!(z, "mars"),
            _ => panic!("expected UnknownZone"),
        }
    }

    #[test]
    fn overweight() {
        let parcel = Parcel { weight_grams: 25000, zone: "domestic".into() };
        let err = compute_quote(&parcel, &domestic_bands()).unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 25000);
                assert_eq!(limit, 20000);
            }
            _ => panic!("expected Overweight"),
        }
    }

    #[test]
    fn weight_at_10000_no_heavy_surcharge() {
        let parcel = Parcel { weight_grams: 10000, zone: "domestic".into() };
        let q = compute_quote(&parcel, &domestic_bands()).unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn weight_at_10001_gets_heavy_surcharge() {
        let parcel = Parcel { weight_grams: 10001, zone: "domestic".into() };
        let q = compute_quote(&parcel, &domestic_bands()).unwrap();
        assert_eq!(q.surcharge_cents, 500);
    }

    #[test]
    fn round_half_up_exact() {
        assert_eq!(round_half_up(1000, 100), 10);
    }

    #[test]
    fn round_half_up_rounds_up() {
        assert_eq!(round_half_up(1050, 100), 11);
    }

    #[test]
    fn round_half_up_below_half() {
        assert_eq!(round_half_up(1049, 100), 10);
    }
}
