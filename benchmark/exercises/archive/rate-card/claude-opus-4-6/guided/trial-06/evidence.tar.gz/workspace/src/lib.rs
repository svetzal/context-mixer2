use std::collections::HashMap;
use std::fmt;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "overweight: {grams}g exceeds limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug)]
struct Band {
    max_grams: u32,
    cents: u64,
}

fn parse_rate_card(content: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

    for (line_idx, line) in content.lines().enumerate() {
        let line_number = line_idx + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = trimmed.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        zones
            .entry(fields[0].to_string())
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(zones)
}

fn calculate_quote(
    zones: &HashMap<String, Vec<Band>>,
    parcel: &Parcel,
) -> Result<Quote, QuoteError> {
    let bands = zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = bands.last().map(|b| b.max_grams).unwrap_or(0);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = std::fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let zones = parse_rate_card(&content)?;
    let result = calculate_quote(&zones, parcel)?;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = result.total_cents,
        "quote calculated"
    );

    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;

    const RATE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn parse_valid_rate_card() {
        let zones = parse_rate_card(RATE_CARD).unwrap();
        assert_eq!(zones["domestic"].len(), 3);
        assert_eq!(zones["international"].len(), 2);
        assert_eq!(zones["domestic"][0].max_grams, 500);
        assert_eq!(zones["domestic"][0].cents, 599);
    }

    #[test]
    fn parse_malformed_field_count() {
        let card = "domestic\t500\n";
        let err = parse_rate_card(card).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn parse_malformed_number() {
        let card = "domestic\tabc\t500\n";
        let err = parse_rate_card(card).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn parse_skips_comments_and_blanks() {
        let card = "# header\n\ndomestic\t500\t599\n";
        let zones = parse_rate_card(card).unwrap();
        assert_eq!(zones["domestic"].len(), 1);
    }

    #[test]
    fn malformed_line_number_counts_all_lines() {
        let card = "# comment\n\ndomestic\t500\n";
        let err = parse_rate_card(card).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn domestic_light_parcel() {
        let zones = parse_rate_card(RATE_CARD).unwrap();
        let parcel = Parcel {
            weight_grams: 250,
            zone: "domestic".into(),
        };
        let q = calculate_quote(&zones, &parcel).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_exact_band_boundary() {
        let zones = parse_rate_card(RATE_CARD).unwrap();
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".into(),
        };
        let q = calculate_quote(&zones, &parcel).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_second_band() {
        let zones = parse_rate_card(RATE_CARD).unwrap();
        let parcel = Parcel {
            weight_grams: 501,
            zone: "domestic".into(),
        };
        let q = calculate_quote(&zones, &parcel).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn domestic_heavy_surcharge() {
        let zones = parse_rate_card(RATE_CARD).unwrap();
        let parcel = Parcel {
            weight_grams: 15_000,
            zone: "domestic".into(),
        };
        let q = calculate_quote(&zones, &parcel).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn international_light_surcharge() {
        let zones = parse_rate_card(RATE_CARD).unwrap();
        let parcel = Parcel {
            weight_grams: 250,
            zone: "international".into(),
        };
        let q = calculate_quote(&zones, &parcel).unwrap();
        assert_eq!(q.base_cents, 1499);
        let intl_surcharge = (1499 * 20 + 50) / 100; // 300
        assert_eq!(q.surcharge_cents, intl_surcharge);
        assert_eq!(q.total_cents, 1499 + intl_surcharge);
    }

    #[test]
    fn international_heavy_both_surcharges() {
        let zones = parse_rate_card(RATE_CARD).unwrap();
        let parcel = Parcel {
            weight_grams: 15_000,
            zone: "international".into(),
        };
        let q = calculate_quote(&zones, &parcel).unwrap();
        assert_eq!(q.base_cents, 4999);
        let intl_surcharge = (4999 * 20 + 50) / 100; // 1000
        assert_eq!(q.surcharge_cents, 500 + intl_surcharge);
        assert_eq!(q.total_cents, 4999 + 500 + intl_surcharge);
    }

    #[test]
    fn unknown_zone() {
        let zones = parse_rate_card(RATE_CARD).unwrap();
        let parcel = Parcel {
            weight_grams: 100,
            zone: "mars".into(),
        };
        let err = calculate_quote(&zones, &parcel).unwrap_err();
        assert!(matches!(err, QuoteError::UnknownZone(z) if z == "mars"));
    }

    #[test]
    fn overweight() {
        let zones = parse_rate_card(RATE_CARD).unwrap();
        let parcel = Parcel {
            weight_grams: 25_000,
            zone: "domestic".into(),
        };
        let err = calculate_quote(&zones, &parcel).unwrap_err();
        assert!(
            matches!(err, QuoteError::Overweight { grams: 25_000, limit: 20_000 })
        );
    }

    #[test]
    fn weight_at_10000_no_heavy_surcharge() {
        let zones = parse_rate_card(RATE_CARD).unwrap();
        let parcel = Parcel {
            weight_grams: 10_000,
            zone: "domestic".into(),
        };
        let q = calculate_quote(&zones, &parcel).unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn weight_at_10001_has_heavy_surcharge() {
        let zones = parse_rate_card(RATE_CARD).unwrap();
        let parcel = Parcel {
            weight_grams: 10_001,
            zone: "domestic".into(),
        };
        let q = calculate_quote(&zones, &parcel).unwrap();
        assert_eq!(q.surcharge_cents, 500);
    }

    #[test]
    fn quote_error_display() {
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "rate card unavailable"
        );
        assert_eq!(
            QuoteError::MalformedRateCard { line: 5 }.to_string(),
            "malformed rate card at line 5"
        );
        assert_eq!(
            QuoteError::UnknownZone("mars".into()).to_string(),
            "unknown zone: mars"
        );
        assert_eq!(
            QuoteError::Overweight {
                grams: 100,
                limit: 50
            }
            .to_string(),
            "overweight: 100g exceeds limit of 50g"
        );
    }

    fn quote_error_is_std_error<E: std::error::Error>(_: &E) {}

    #[test]
    fn quote_error_implements_error_trait() {
        quote_error_is_std_error(&QuoteError::RateCardUnavailable);
    }

    #[test]
    fn quote_missing_env_var() {
        std::env::remove_var("RATECARD_PATH");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        let err = quote(&parcel).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn quote_unreadable_path() {
        std::env::set_var("RATECARD_PATH", "/nonexistent/path/ratecard.tsv");
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        let err = quote(&parcel).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn quote_integration() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("rates.tsv");
        std::fs::write(&path, RATE_CARD).unwrap();
        std::env::set_var("RATECARD_PATH", path.to_str().unwrap());

        let parcel = Parcel {
            weight_grams: 1000,
            zone: "domestic".into(),
        };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.total_cents, 899);
    }
}
