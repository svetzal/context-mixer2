use std::fmt;

#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "overweight: {grams}g exceeds limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<Vec<(String, Band)>, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = std::fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut entries = Vec::new();
    for (idx, raw_line) in content.lines().enumerate() {
        let line_number = idx + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = raw_line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let zone = fields[0].to_string();
        let max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        entries.push((zone, Band { max_grams, cents }));
    }
    Ok(entries)
}

#[allow(clippy::cast_possible_truncation, clippy::cast_sign_loss)]
fn round_half_up(value: f64) -> u64 {
    (value + 0.5).floor() as u64
}

#[allow(clippy::missing_errors_doc, clippy::missing_panics_doc)]
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let entries = load_rate_card()?;

    let mut zone_bands: Vec<&Band> = entries
        .iter()
        .filter(|(z, _)| z == &parcel.zone)
        .map(|(_, b)| b)
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.max_grams);

    let largest = zone_bands.last().expect("non-empty checked above");
    if parcel.weight_grams > largest.max_grams {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest.max_grams,
        });
    }

    let band = zone_bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .expect("weight within limit implies a matching band");

    let base_cents = band.cents;
    let band_max_grams = band.max_grams;

    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        #[allow(clippy::cast_precision_loss)]
        let international_surcharge = round_half_up(base_cents as f64 * 0.2);
        surcharge_cents += international_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write as _;
    use std::sync::{Mutex, MutexGuard};
    use tempfile::NamedTempFile;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn set_rate_card(content: &str) -> (MutexGuard<'static, ()>, NamedTempFile) {
        let guard = ENV_LOCK.lock().unwrap();
        let mut f = NamedTempFile::new().unwrap();
        f.write_all(content.as_bytes()).unwrap();
        f.flush().unwrap();
        std::env::set_var("RATECARD_PATH", f.path());
        (guard, f)
    }

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn domestic_light_parcel() {
        let _g = set_rate_card(SAMPLE_CARD);
        let result = quote(&Parcel {
            weight_grams: 200,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(result.base_cents, 599);
        assert_eq!(result.surcharge_cents, 0);
        assert_eq!(result.total_cents, 599);
        assert_eq!(result.band_max_grams, 500);
    }

    #[test]
    fn domestic_mid_band() {
        let _g = set_rate_card(SAMPLE_CARD);
        let result = quote(&Parcel {
            weight_grams: 1000,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(result.base_cents, 899);
        assert_eq!(result.band_max_grams, 2000);
    }

    #[test]
    fn domestic_exact_boundary() {
        let _g = set_rate_card(SAMPLE_CARD);
        let result = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(result.base_cents, 599);
        assert_eq!(result.band_max_grams, 500);
    }

    #[test]
    fn domestic_heavy_surcharge() {
        let _g = set_rate_card(SAMPLE_CARD);
        let result = quote(&Parcel {
            weight_grams: 15000,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(result.base_cents, 1799);
        assert_eq!(result.surcharge_cents, 500);
        assert_eq!(result.total_cents, 2299);
    }

    #[test]
    fn international_light() {
        let _g = set_rate_card(SAMPLE_CARD);
        let result = quote(&Parcel {
            weight_grams: 300,
            zone: "international".into(),
        })
        .unwrap();
        assert_eq!(result.base_cents, 1499);
        // 20% of 1499 = 299.8 → rounded half-up = 300
        assert_eq!(result.surcharge_cents, 300);
        assert_eq!(result.total_cents, 1799);
    }

    #[test]
    fn international_heavy_both_surcharges() {
        let _g = set_rate_card(SAMPLE_CARD);
        let result = quote(&Parcel {
            weight_grams: 15000,
            zone: "international".into(),
        })
        .unwrap();
        assert_eq!(result.base_cents, 4999);
        // 20% of 4999 = 999.8 → 1000; plus 500 for heavy
        assert_eq!(result.surcharge_cents, 1500);
        assert_eq!(result.total_cents, 6499);
    }

    #[test]
    fn unknown_zone() {
        let _g = set_rate_card(SAMPLE_CARD);
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "mars".into(),
        })
        .unwrap_err();
        match err {
            QuoteError::UnknownZone(z) => assert_eq!(z, "mars"),
            other => panic!("expected UnknownZone, got: {other}"),
        }
    }

    #[test]
    fn overweight() {
        let _g = set_rate_card(SAMPLE_CARD);
        let err = quote(&Parcel {
            weight_grams: 25000,
            zone: "domestic".into(),
        })
        .unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 25000);
                assert_eq!(limit, 20000);
            }
            other => panic!("expected Overweight, got: {other}"),
        }
    }

    #[test]
    fn missing_env_var() {
        let _g = ENV_LOCK.lock().unwrap();
        std::env::remove_var("RATECARD_PATH");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn unreadable_path() {
        let _g = ENV_LOCK.lock().unwrap();
        std::env::set_var("RATECARD_PATH", "/no/such/file");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn malformed_line_wrong_fields() {
        let _g = set_rate_card("domestic\t500\n");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            other => panic!("expected MalformedRateCard, got: {other}"),
        }
    }

    #[test]
    fn malformed_line_bad_number() {
        let _g = set_rate_card("domestic\tabc\t500\n");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            other => panic!("expected MalformedRateCard, got: {other}"),
        }
    }

    #[test]
    fn malformed_preserves_1based_line_number() {
        let _g = set_rate_card("# comment\n\ndomestic\t500\t599\nbad line\n");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 4),
            other => panic!("expected MalformedRateCard, got: {other}"),
        }
    }

    #[test]
    fn comments_and_blanks_ignored() {
        let _g = set_rate_card("# header\n\ndomestic\t1000\t500\n");
        let result = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(result.base_cents, 500);
    }

    #[test]
    fn display_impls() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 3 }.to_string(),
            "malformed rate card at line 3"
        );
        assert_eq!(
            QuoteError::UnknownZone("mars".into()).to_string(),
            "unknown zone: mars"
        );
        assert_eq!(
            QuoteError::Overweight {
                grams: 25000,
                limit: 20000
            }
            .to_string(),
            "overweight: 25000g exceeds limit 20000g"
        );
    }

    #[test]
    fn error_trait() {
        let err: &dyn std::error::Error = &QuoteError::RateCardUnavailable;
        assert!(err.source().is_none());
    }
}
