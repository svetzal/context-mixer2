mod rate_card;

use std::fmt;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "overweight: {grams}g exceeds limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

const HEAVY_THRESHOLD: u32 = 10_000;
const HEAVY_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";

fn round_half_up(value: f64) -> u64 {
    (value + 0.5).floor() as u64
}

fn calculate_quote(
    parcel: &Parcel,
    card: &rate_card::RateCard,
) -> Result<Quote, QuoteError> {
    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|b| parcel.weight_grams <= b.max_grams)
        .ok_or_else(|| {
            let limit = bands.last().map_or(0, |b| b.max_grams);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > HEAVY_THRESHOLD {
        surcharge_cents += HEAVY_SURCHARGE_CENTS;
    }

    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge_cents += round_half_up(base_cents as f64 * 0.20);
    }

    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = std::fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = rate_card::parse(&content)?;
    let result = calculate_quote(parcel, &card)?;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = result.total_cents,
        "quote calculated"
    );

    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn setup_card(content: &str) -> tempfile::NamedTempFile {
        let mut f = tempfile::NamedTempFile::new().unwrap();
        f.write_all(content.as_bytes()).unwrap();
        std::env::set_var("RATECARD_PATH", f.path());
        f
    }

    #[test]
    fn domestic_light_parcel() {
        let _f = setup_card(SAMPLE_CARD);
        let p = Parcel { weight_grams: 400, zone: "domestic".into() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_exact_band_boundary() {
        let _f = setup_card(SAMPLE_CARD);
        let p = Parcel { weight_grams: 500, zone: "domestic".into() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_second_band() {
        let _f = setup_card(SAMPLE_CARD);
        let p = Parcel { weight_grams: 501, zone: "domestic".into() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn domestic_heavy_surcharge() {
        let _f = setup_card(SAMPLE_CARD);
        let p = Parcel { weight_grams: 15000, zone: "domestic".into() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn international_surcharge() {
        let _f = setup_card(SAMPLE_CARD);
        let p = Parcel { weight_grams: 400, zone: "international".into() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 1499);
        // 20% of 1499 = 299.8 -> rounded half-up = 300
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_heavy_both_surcharges() {
        let _f = setup_card(SAMPLE_CARD);
        let p = Parcel { weight_grams: 15000, zone: "international".into() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 4999);
        // 500 (heavy) + round_half_up(4999 * 0.20 = 999.8) = 500 + 1000 = 1500
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone() {
        let _f = setup_card(SAMPLE_CARD);
        let p = Parcel { weight_grams: 100, zone: "lunar".into() };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::UnknownZone(z) if z == "lunar"));
    }

    #[test]
    fn overweight() {
        let _f = setup_card(SAMPLE_CARD);
        let p = Parcel { weight_grams: 30000, zone: "domestic".into() };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::Overweight { grams: 30000, limit: 20000 }));
    }

    #[test]
    fn missing_env_var() {
        std::env::remove_var("RATECARD_PATH");
        let p = Parcel { weight_grams: 100, zone: "domestic".into() };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn unreadable_path() {
        std::env::set_var("RATECARD_PATH", "/nonexistent/path/ratecard.tsv");
        let p = Parcel { weight_grams: 100, zone: "domestic".into() };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn malformed_rate_card() {
        let _f = setup_card("bad line\n");
        let p = Parcel { weight_grams: 100, zone: "domestic".into() };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn display_impls() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 5 }.to_string(),
            "malformed rate card at line 5"
        );
        assert_eq!(QuoteError::UnknownZone("mars".into()).to_string(), "unknown zone: mars");
        assert_eq!(
            QuoteError::Overweight { grams: 100, limit: 50 }.to_string(),
            "overweight: 100g exceeds limit of 50g"
        );
    }

    #[test]
    fn error_trait_impl() {
        let err: &dyn std::error::Error = &QuoteError::RateCardUnavailable;
        let _ = err.to_string();
    }

    #[test]
    fn round_half_up_cases() {
        assert_eq!(round_half_up(299.5), 300);
        assert_eq!(round_half_up(299.4), 299);
        assert_eq!(round_half_up(299.8), 300);
        assert_eq!(round_half_up(300.0), 300);
    }
}
