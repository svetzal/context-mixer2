use std::collections::HashMap;

use crate::QuoteError;

#[derive(Debug, Clone)]
pub struct Band {
    pub max_grams: u32,
    pub cents: u64,
}

pub type RateCard = HashMap<String, Vec<Band>>;

pub fn parse(content: &str) -> Result<RateCard, QuoteError> {
    let mut card: RateCard = HashMap::new();

    for (line_idx, raw) in content.lines().enumerate() {
        let line = raw.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_idx + 1 });
        }

        let zone = parts[0].to_string();
        let max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_idx + 1 })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_idx + 1 })?;

        card.entry(zone).or_default().push(Band { max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(card)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_valid_card() {
        let content = "# header\ndomestic\t500\t599\ndomestic\t2000\t899\n";
        let card = parse(content).unwrap();
        assert_eq!(card["domestic"].len(), 2);
        assert_eq!(card["domestic"][0].max_grams, 500);
        assert_eq!(card["domestic"][0].cents, 599);
        assert_eq!(card["domestic"][1].max_grams, 2000);
    }

    #[test]
    fn skips_blank_and_comment_lines() {
        let content = "\n# comment\n\ndomestic\t500\t599\n";
        let card = parse(content).unwrap();
        assert_eq!(card["domestic"].len(), 1);
    }

    #[test]
    fn sorts_bands_ascending() {
        let content = "domestic\t2000\t899\ndomestic\t500\t599\n";
        let card = parse(content).unwrap();
        assert_eq!(card["domestic"][0].max_grams, 500);
        assert_eq!(card["domestic"][1].max_grams, 2000);
    }

    #[test]
    fn rejects_malformed_line_wrong_field_count() {
        let content = "domestic\t500\n";
        let err = parse(content).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn rejects_malformed_line_bad_number() {
        let content = "domestic\tabc\t599\n";
        let err = parse(content).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn malformed_line_number_counts_all_lines() {
        let content = "# comment\n\ndomestic\t500\n";
        let err = parse(content).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 3 }));
    }
}
