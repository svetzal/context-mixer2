use std::collections::HashMap;
use std::fmt;
use std::fs;

#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel {grams}g exceeds zone limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

    for (line_idx, line) in content.lines().enumerate() {
        let line_number = line_idx + 1;

        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = fields[0].to_string();
        let max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        zones.entry(zone).or_default().push(Band { max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(zones)
}

fn round_half_up(value: f64) -> u64 {
    (value + 0.5).floor() as u64
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let zones = load_rate_card()?;

    let bands = zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|b| parcel.weight_grams <= b.max_grams)
        .ok_or_else(|| {
            let limit = bands.last().map(|b| b.max_grams).unwrap_or(0);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = band.cents;
    let band_max_grams = band.max_grams;

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        surcharge_cents += round_half_up(base_cents as f64 * 0.20);
    }

    let total_cents = base_cents + surcharge_cents;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn write_rate_card(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(content.as_bytes()).unwrap();
        file
    }

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn domestic_first_band() {
        let f = write_rate_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", f.path());
        let q = quote(&Parcel {
            weight_grams: 250,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_second_band() {
        let f = write_rate_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", f.path());
        let q = quote(&Parcel {
            weight_grams: 501,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn domestic_exact_band_boundary() {
        let f = write_rate_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", f.path());
        let q = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_heavy_surcharge() {
        let f = write_rate_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", f.path());
        let q = quote(&Parcel {
            weight_grams: 15000,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn international_surcharge() {
        let f = write_rate_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", f.path());
        let q = quote(&Parcel {
            weight_grams: 300,
            zone: "international".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 1499);
        // 20% of 1499 = 299.8 -> rounded half-up = 300
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_heavy_both_surcharges() {
        let f = write_rate_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", f.path());
        let q = quote(&Parcel {
            weight_grams: 15000,
            zone: "international".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 4999);
        // 20% of 4999 = 999.8 -> 1000, plus 500 for heavy
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone() {
        let f = write_rate_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", f.path());
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "mars".into(),
        })
        .unwrap_err();
        match err {
            QuoteError::UnknownZone(z) => assert_eq!(z, "mars"),
            other => panic!("expected UnknownZone, got {other}"),
        }
    }

    #[test]
    fn overweight() {
        let f = write_rate_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", f.path());
        let err = quote(&Parcel {
            weight_grams: 25000,
            zone: "domestic".into(),
        })
        .unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 25000);
                assert_eq!(limit, 20000);
            }
            other => panic!("expected Overweight, got {other}"),
        }
    }

    #[test]
    fn missing_env_var() {
        std::env::remove_var("RATECARD_PATH");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn unreadable_path() {
        std::env::set_var("RATECARD_PATH", "/nonexistent/path/to/card.tsv");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn malformed_line() {
        let f = write_rate_card("domestic\t500\n");
        std::env::set_var("RATECARD_PATH", f.path());
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            other => panic!("expected MalformedRateCard, got {other}"),
        }
    }

    #[test]
    fn malformed_number() {
        let f = write_rate_card("domestic\tabc\t599\n");
        std::env::set_var("RATECARD_PATH", f.path());
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { .. }));
    }

    #[test]
    fn comments_and_blanks_skipped() {
        let card = "# header\n\ndomestic\t1000\t500\n";
        let f = write_rate_card(card);
        std::env::set_var("RATECARD_PATH", f.path());
        let q = quote(&Parcel {
            weight_grams: 800,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 500);
    }

    #[test]
    fn malformed_after_comment_reports_correct_line() {
        let card = "# header\n\nbad line\n";
        let f = write_rate_card(card);
        std::env::set_var("RATECARD_PATH", f.path());
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 3),
            other => panic!("expected MalformedRateCard, got {other}"),
        }
    }

    #[test]
    fn display_impls() {
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "rate card unavailable"
        );
        assert_eq!(
            QuoteError::MalformedRateCard { line: 5 }.to_string(),
            "malformed rate card at line 5"
        );
        assert_eq!(
            QuoteError::UnknownZone("mars".into()).to_string(),
            "unknown zone: mars"
        );
        assert_eq!(
            QuoteError::Overweight {
                grams: 30000,
                limit: 20000
            }
            .to_string(),
            "parcel 30000g exceeds zone limit of 20000g"
        );
    }

    #[test]
    fn error_trait_implemented() {
        let err: Box<dyn std::error::Error> =
            Box::new(QuoteError::UnknownZone("test".into()));
        assert!(!err.to_string().is_empty());
    }
}
