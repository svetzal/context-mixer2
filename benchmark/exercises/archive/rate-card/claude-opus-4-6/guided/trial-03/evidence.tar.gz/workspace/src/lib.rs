use std::collections::HashMap;
use std::fmt;
use std::fs;

#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "overweight: {grams}g exceeds limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug)]
struct Band {
    max_grams: u32,
    cents: u64,
}

fn parse_rate_card(content: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

    for (line_idx, line) in content.lines().enumerate() {
        let line_number = line_idx + 1;
        let trimmed = line.trim();

        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = trimmed.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        zones
            .entry(fields[0].to_string())
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(zones)
}

fn calculate_quote(
    parcel: &Parcel,
    zones: &HashMap<String, Vec<Band>>,
) -> Result<Quote, QuoteError> {
    let bands = zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let Some(band) = bands.iter().find(|b| b.max_grams >= parcel.weight_grams) else {
        let limit = bands.last().map_or(0, |b| b.max_grams);
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        });
    };

    let base_cents = band.cents;
    let band_max_grams = band.max_grams;

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let zones = parse_rate_card(&content)?;
    let result = calculate_quote(parcel, &zones)?;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = result.total_cents,
        "quote calculated"
    );

    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;

    const RATE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn parsed() -> HashMap<String, Vec<Band>> {
        parse_rate_card(RATE_CARD).unwrap()
    }

    fn domestic(grams: u32) -> Parcel {
        Parcel {
            weight_grams: grams,
            zone: "domestic".into(),
        }
    }

    fn international(grams: u32) -> Parcel {
        Parcel {
            weight_grams: grams,
            zone: "international".into(),
        }
    }

    #[test]
    fn parse_skips_comments_and_blanks() {
        let input = "# header\n\ndomestic\t500\t100\n\n# another\n";
        let zones = parse_rate_card(input).unwrap();
        assert_eq!(zones.len(), 1);
        assert_eq!(zones["domestic"].len(), 1);
    }

    #[test]
    fn parse_sorts_bands_ascending() {
        let input = "z\t2000\t200\nz\t500\t100\nz\t1000\t150\n";
        let zones = parse_rate_card(input).unwrap();
        let maxes: Vec<u32> = zones["z"].iter().map(|b| b.max_grams).collect();
        assert_eq!(maxes, vec![500, 1000, 2000]);
    }

    #[test]
    fn parse_malformed_wrong_field_count() {
        let input = "domestic\t500\n";
        let err = parse_rate_card(input).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn parse_malformed_bad_number() {
        let input = "domestic\tabc\t500\n";
        let err = parse_rate_card(input).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn parse_malformed_line_number_counts_all_lines() {
        let input = "# comment\n\ndomestic\t500\t100\nbad line\n";
        let err = parse_rate_card(input).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 4 }));
    }

    #[test]
    fn domestic_first_band() {
        let zones = parsed();
        let q = calculate_quote(&domestic(250), &zones).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_exact_band_boundary() {
        let zones = parsed();
        let q = calculate_quote(&domestic(500), &zones).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_second_band() {
        let zones = parsed();
        let q = calculate_quote(&domestic(501), &zones).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn domestic_heavy_surcharge() {
        let zones = parsed();
        let q = calculate_quote(&domestic(15000), &zones).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn domestic_at_10000_no_surcharge() {
        let zones = parsed();
        let q = calculate_quote(&domestic(10000), &zones).unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn domestic_at_10001_gets_surcharge() {
        let zones = parsed();
        let q = calculate_quote(&domestic(10001), &zones).unwrap();
        assert_eq!(q.surcharge_cents, 500);
    }

    #[test]
    fn international_surcharge_includes_zone_and_weight() {
        let zones = parsed();
        let q = calculate_quote(&international(15000), &zones).unwrap();
        // base = 4999, international = round_half_up(4999 * 0.20) = 1000, heavy = 500
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn international_zone_surcharge_rounds_half_up() {
        let zones = parsed();
        let q = calculate_quote(&international(250), &zones).unwrap();
        // base = 1499, 20% = 299.8 → rounds to 300
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn unknown_zone() {
        let zones = parsed();
        let parcel = Parcel {
            weight_grams: 100,
            zone: "mars".into(),
        };
        let err = calculate_quote(&parcel, &zones).unwrap_err();
        assert!(matches!(err, QuoteError::UnknownZone(z) if z == "mars"));
    }

    #[test]
    fn overweight() {
        let zones = parsed();
        let err = calculate_quote(&domestic(20001), &zones).unwrap_err();
        assert!(
            matches!(err, QuoteError::Overweight { grams: 20001, limit: 20000 })
        );
    }

    #[test]
    fn quote_error_display() {
        assert!(!QuoteError::RateCardUnavailable.to_string().is_empty());
        assert!(!QuoteError::MalformedRateCard { line: 3 }.to_string().is_empty());
        assert!(!QuoteError::UnknownZone("x".into()).to_string().is_empty());
        assert!(
            !QuoteError::Overweight {
                grams: 1,
                limit: 2
            }
            .to_string()
            .is_empty()
        );
    }

    #[test]
    fn quote_error_is_std_error() {
        fn assert_error<E: std::error::Error>() {}
        assert_error::<QuoteError>();
    }

    #[test]
    fn quote_with_file() {
        use std::io::Write;
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("rates.tsv");
        {
            let mut f = fs::File::create(&path).unwrap();
            write!(f, "{RATE_CARD}").unwrap();
        }

        unsafe {
            std::env::set_var("RATECARD_PATH", &path);
        }

        let q = quote(&domestic(1000)).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.total_cents, 899);

        unsafe {
            std::env::remove_var("RATECARD_PATH");
        }
    }

    #[test]
    fn quote_missing_env_var() {
        unsafe {
            std::env::remove_var("RATECARD_PATH");
        }
        let err = quote(&domestic(100)).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn quote_unreadable_path() {
        unsafe {
            std::env::set_var("RATECARD_PATH", "/no/such/file.tsv");
        }
        let err = quote(&domestic(100)).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));

        unsafe {
            std::env::remove_var("RATECARD_PATH");
        }
    }
}
