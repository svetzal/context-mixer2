mod rate_card;

use std::env;
use std::fs;

pub use rate_card::{Band, RateCard};

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "overweight: {grams}g exceeds {limit}g limit")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

const HEAVY_THRESHOLD: u32 = 10_000;
const HEAVY_SURCHARGE_CENTS: u64 = 500;

#[allow(
    clippy::cast_possible_truncation,
    clippy::cast_sign_loss
)]
fn round_half_up(value: f64) -> u64 {
    (value + 0.5).floor() as u64
}

fn compute_surcharges(parcel: &Parcel, base_cents: u64) -> u64 {
    let mut surcharge: u64 = 0;

    if parcel.weight_grams > HEAVY_THRESHOLD {
        surcharge += HEAVY_SURCHARGE_CENTS;
    }

    if parcel.zone == "international" {
        #[allow(clippy::cast_precision_loss)]
        let international = round_half_up(base_cents as f64 * 0.2);
        surcharge += international;
    }

    surcharge
}

/// # Errors
///
/// Returns a `QuoteError` variant when the rate card is missing, malformed,
/// the zone is unknown, or the parcel is overweight.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = RateCard::parse(&content)?;

    let band = card.lookup(&parcel.zone, parcel.weight_grams)?;
    let base_cents = band.cents;
    let surcharge_cents = compute_surcharges(parcel, base_cents);
    let total_cents = base_cents + surcharge_cents;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write as _;
    use tempfile::NamedTempFile;

    fn set_rate_card(content: &str) -> NamedTempFile {
        let mut f = NamedTempFile::new().unwrap();
        f.write_all(content.as_bytes()).unwrap();
        env::set_var("RATECARD_PATH", f.path());
        f
    }

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn domestic_light_parcel() {
        let _f = set_rate_card(CARD);
        let p = Parcel { weight_grams: 250, zone: "domestic".into() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_exact_band_boundary() {
        let _f = set_rate_card(CARD);
        let p = Parcel { weight_grams: 500, zone: "domestic".into() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_second_band() {
        let _f = set_rate_card(CARD);
        let p = Parcel { weight_grams: 501, zone: "domestic".into() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn domestic_heavy_surcharge() {
        let _f = set_rate_card(CARD);
        let p = Parcel { weight_grams: 15000, zone: "domestic".into() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn international_surcharge() {
        let _f = set_rate_card(CARD);
        let p = Parcel { weight_grams: 300, zone: "international".into() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 1499);
        // 1499 * 0.2 = 299.8, round half-up = 300
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_heavy_both_surcharges() {
        let _f = set_rate_card(CARD);
        let p = Parcel { weight_grams: 15000, zone: "international".into() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 4999);
        // 4999 * 0.2 = 999.8, round half-up = 1000; plus 500 heavy
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone() {
        let _f = set_rate_card(CARD);
        let p = Parcel { weight_grams: 100, zone: "mars".into() };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::UnknownZone(z) if z == "mars"));
    }

    #[test]
    fn overweight() {
        let _f = set_rate_card(CARD);
        let p = Parcel { weight_grams: 25000, zone: "domestic".into() };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::Overweight { grams: 25000, limit: 20000 }));
    }

    #[test]
    fn missing_env_var() {
        env::remove_var("RATECARD_PATH");
        let p = Parcel { weight_grams: 100, zone: "domestic".into() };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn unreadable_path() {
        env::set_var("RATECARD_PATH", "/nonexistent/path/to/file.tsv");
        let p = Parcel { weight_grams: 100, zone: "domestic".into() };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn malformed_line() {
        let bad = "domestic\t500\ndomestic\t2000\t899\n";
        let _f = set_rate_card(bad);
        let p = Parcel { weight_grams: 100, zone: "domestic".into() };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn malformed_number() {
        let bad = "domestic\tabc\t899\n";
        let _f = set_rate_card(bad);
        let p = Parcel { weight_grams: 100, zone: "domestic".into() };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn comments_and_blank_lines_skipped() {
        let card = "# header\n\ndomestic\t1000\t599\n";
        let _f = set_rate_card(card);
        let p = Parcel { weight_grams: 500, zone: "domestic".into() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn malformed_line_number_accounts_for_comments() {
        let card = "# header\n\ndomestic\tbad\t599\n";
        let _f = set_rate_card(card);
        let p = Parcel { weight_grams: 100, zone: "domestic".into() };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn display_impls() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 5 }.to_string(),
            "malformed rate card at line 5"
        );
        assert_eq!(
            QuoteError::UnknownZone("mars".into()).to_string(),
            "unknown zone: mars"
        );
        assert_eq!(
            QuoteError::Overweight { grams: 100, limit: 50 }.to_string(),
            "overweight: 100g exceeds 50g limit"
        );
    }

    #[test]
    fn error_trait() {
        let err: &dyn std::error::Error = &QuoteError::RateCardUnavailable;
        assert!(err.source().is_none());
    }

    #[test]
    fn weight_at_heavy_threshold_no_surcharge() {
        let _f = set_rate_card(CARD);
        let p = Parcel { weight_grams: 10000, zone: "domestic".into() };
        let q = quote(&p).unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn weight_above_heavy_threshold() {
        let _f = set_rate_card(CARD);
        let p = Parcel { weight_grams: 10001, zone: "domestic".into() };
        let q = quote(&p).unwrap();
        assert_eq!(q.surcharge_cents, 500);
    }
}
