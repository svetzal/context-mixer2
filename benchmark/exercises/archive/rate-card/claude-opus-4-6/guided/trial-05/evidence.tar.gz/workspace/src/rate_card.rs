use crate::QuoteError;

#[derive(Debug, Clone)]
pub struct Band {
    pub max_grams: u32,
    pub cents: u64,
}

pub struct RateCard {
    bands: Vec<(String, Band)>,
}

impl RateCard {
    /// # Errors
    ///
    /// Returns `MalformedRateCard` for lines that are not three tab-separated
    /// fields or contain unparseable numbers.
    pub fn parse(content: &str) -> Result<Self, QuoteError> {
        let mut bands = Vec::new();

        for (idx, raw_line) in content.lines().enumerate() {
            let line = raw_line.trim();
            if line.is_empty() || line.starts_with('#') {
                continue;
            }

            let parts: Vec<&str> = line.split('\t').collect();
            if parts.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: idx + 1 });
            }

            let max_grams: u32 = parts[1]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: idx + 1 })?;
            let cents: u64 = parts[2]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: idx + 1 })?;

            bands.push((parts[0].to_owned(), Band { max_grams, cents }));
        }

        bands.sort_by(|a, b| a.0.cmp(&b.0).then(a.1.max_grams.cmp(&b.1.max_grams)));

        Ok(Self { bands })
    }

    /// # Errors
    ///
    /// Returns `UnknownZone` if the zone has no bands, or `Overweight` if the
    /// weight exceeds the zone's largest band.
    pub fn lookup(&self, zone: &str, weight_grams: u32) -> Result<Band, QuoteError> {
        let zone_bands: Vec<&Band> = self
            .bands
            .iter()
            .filter(|(z, _)| z == zone)
            .map(|(_, b)| b)
            .collect();

        if zone_bands.is_empty() {
            return Err(QuoteError::UnknownZone(zone.to_owned()));
        }

        let mut last_max = 0;
        for band in &zone_bands {
            last_max = band.max_grams;
            if weight_grams <= band.max_grams {
                return Ok((*band).clone());
            }
        }

        Err(QuoteError::Overweight {
            grams: weight_grams,
            limit: last_max,
        })
    }
}
