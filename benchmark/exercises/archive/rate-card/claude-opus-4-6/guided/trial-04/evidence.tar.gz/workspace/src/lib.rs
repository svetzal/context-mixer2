use std::collections::HashMap;
use std::fmt;
use std::fs;

#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel {grams}g exceeds zone limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

fn parse_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

    for (idx, raw_line) in content.lines().enumerate() {
        let line_number = idx + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = trimmed.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        zones
            .entry(parts[0].to_string())
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(zones)
}

const HEAVY_THRESHOLD: u32 = 10_000;
const HEAVY_SURCHARGE: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let zones = parse_rate_card()?;

    let bands = zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = bands.last().map_or(0, |b| b.max_grams);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = band.cents;
    let band_max_grams = band.max_grams;

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > HEAVY_THRESHOLD {
        surcharge_cents += HEAVY_SURCHARGE;
    }

    if parcel.zone == INTERNATIONAL_ZONE {
        // 20% of base_cents, rounded half-up
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write as _;
    use tempfile::NamedTempFile;

    fn rate_card_file(content: &str) -> NamedTempFile {
        let mut f = NamedTempFile::new().unwrap();
        f.write_all(content.as_bytes()).unwrap();
        f
    }

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn with_card<F: FnOnce()>(content: &str, f: F) {
        let file = rate_card_file(content);
        std::env::set_var("RATECARD_PATH", file.path());
        f();
    }

    #[test]
    fn domestic_light_parcel() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 200,
                zone: "domestic".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_exact_band_boundary() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_second_band() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
        });
    }

    #[test]
    fn domestic_heavy_surcharge() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 15000,
                zone: "domestic".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
            assert_eq!(q.band_max_grams, 20000);
        });
    }

    #[test]
    fn domestic_at_heavy_threshold_no_surcharge() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 10000,
                zone: "domestic".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.surcharge_cents, 0);
        });
    }

    #[test]
    fn international_light_parcel() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 300,
                zone: "international".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 1499);
            // 20% of 1499 = 299.8, rounded half-up = 300
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_heavy_parcel() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 15000,
                zone: "international".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 4999);
            // 20% of 4999 = 999.8, rounded = 1000; plus 500 heavy
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
        });
    }

    #[test]
    fn unknown_zone() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 100,
                zone: "mars".into(),
            };
            let err = quote(&p).unwrap_err();
            assert_eq!(err, QuoteError::UnknownZone("mars".into()));
        });
    }

    #[test]
    fn overweight() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 25000,
                zone: "domestic".into(),
            };
            let err = quote(&p).unwrap_err();
            assert_eq!(
                err,
                QuoteError::Overweight {
                    grams: 25000,
                    limit: 20000,
                }
            );
        });
    }

    #[test]
    fn missing_env_var() {
        std::env::remove_var("RATECARD_PATH");
        let p = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        assert_eq!(quote(&p).unwrap_err(), QuoteError::RateCardUnavailable);
    }

    #[test]
    fn unreadable_path() {
        std::env::set_var("RATECARD_PATH", "/nonexistent/path/to/rates.tsv");
        let p = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        assert_eq!(quote(&p).unwrap_err(), QuoteError::RateCardUnavailable);
    }

    #[test]
    fn malformed_line_wrong_columns() {
        with_card("domestic\t500\n", || {
            let p = Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            };
            assert_eq!(
                quote(&p).unwrap_err(),
                QuoteError::MalformedRateCard { line: 1 }
            );
        });
    }

    #[test]
    fn malformed_line_bad_number() {
        with_card("domestic\tabc\t599\n", || {
            let p = Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            };
            assert_eq!(
                quote(&p).unwrap_err(),
                QuoteError::MalformedRateCard { line: 1 }
            );
        });
    }

    #[test]
    fn malformed_line_preserves_1_based_line_number() {
        with_card("# header\n\ndomestic\t500\t599\nbad line\n", || {
            let p = Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            };
            assert_eq!(
                quote(&p).unwrap_err(),
                QuoteError::MalformedRateCard { line: 4 }
            );
        });
    }

    #[test]
    fn comments_and_blanks_skipped() {
        with_card("# comment\n\ndomestic\t1000\t500\n", || {
            let p = Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 500);
        });
    }

    #[test]
    fn display_and_error_impls() {
        let err = QuoteError::RateCardUnavailable;
        assert_eq!(err.to_string(), "rate card unavailable");
        let _: &dyn std::error::Error = &err;

        let err = QuoteError::MalformedRateCard { line: 5 };
        assert_eq!(err.to_string(), "malformed rate card at line 5");

        let err = QuoteError::UnknownZone("mars".into());
        assert_eq!(err.to_string(), "unknown zone: mars");

        let err = QuoteError::Overweight {
            grams: 30000,
            limit: 20000,
        };
        assert_eq!(err.to_string(), "parcel 30000g exceeds zone limit of 20000g");
    }
}
