use std::collections::HashMap;
use std::fmt;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel {grams}g exceeds zone limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug)]
struct Band {
    max_grams: u32,
    cents: u64,
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

    for (idx, raw_line) in contents.lines().enumerate() {
        let line = raw_line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: idx + 1 });
        }

        let max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: idx + 1 })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: idx + 1 })?;

        zones
            .entry(parts[0].to_string())
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(zones)
}

fn round_half_up(value: f64) -> u64 {
    (value + 0.5).floor() as u64
}

fn compute_quote(parcel: &Parcel, zones: &HashMap<String, Vec<Band>>) -> Result<Quote, QuoteError> {
    let bands = zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|b| parcel.weight_grams <= b.max_grams)
        .ok_or_else(|| {
            let limit = bands.last().map_or(0, |b| b.max_grams);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += round_half_up(base_cents as f64 * 0.20);
    }

    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = std::fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let zones = parse_rate_card(&contents)?;
    let result = compute_quote(parcel, &zones)?;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = result.total_cents,
        "quote calculated"
    );

    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write as _;
    use tempfile::NamedTempFile;

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn zones() -> HashMap<String, Vec<Band>> {
        parse_rate_card(CARD).unwrap()
    }

    fn q(weight: u32, zone: &str) -> Result<Quote, QuoteError> {
        let p = Parcel { weight_grams: weight, zone: zone.into() };
        compute_quote(&p, &zones())
    }

    #[test]
    fn domestic_first_band() {
        let r = q(250, "domestic").unwrap();
        assert_eq!(r.base_cents, 599);
        assert_eq!(r.surcharge_cents, 0);
        assert_eq!(r.total_cents, 599);
        assert_eq!(r.band_max_grams, 500);
    }

    #[test]
    fn domestic_exact_boundary() {
        let r = q(500, "domestic").unwrap();
        assert_eq!(r.base_cents, 599);
        assert_eq!(r.band_max_grams, 500);
    }

    #[test]
    fn domestic_second_band() {
        let r = q(501, "domestic").unwrap();
        assert_eq!(r.base_cents, 899);
        assert_eq!(r.band_max_grams, 2000);
    }

    #[test]
    fn heavy_domestic_surcharge() {
        let r = q(15000, "domestic").unwrap();
        assert_eq!(r.base_cents, 1799);
        assert_eq!(r.surcharge_cents, 500);
        assert_eq!(r.total_cents, 2299);
    }

    #[test]
    fn international_surcharge() {
        let r = q(400, "international").unwrap();
        assert_eq!(r.base_cents, 1499);
        assert_eq!(r.surcharge_cents, 300);
        assert_eq!(r.total_cents, 1799);
    }

    #[test]
    fn international_heavy_both_surcharges() {
        let r = q(15000, "international").unwrap();
        assert_eq!(r.base_cents, 4999);
        assert_eq!(r.surcharge_cents, 1500);
        assert_eq!(r.total_cents, 6499);
    }

    #[test]
    fn overweight_error() {
        let err = q(25000, "domestic").unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 25000);
                assert_eq!(limit, 20000);
            }
            other => panic!("expected Overweight, got {other}"),
        }
    }

    #[test]
    fn unknown_zone_error() {
        let err = q(100, "lunar").unwrap_err();
        match err {
            QuoteError::UnknownZone(z) => assert_eq!(z, "lunar"),
            other => panic!("expected UnknownZone, got {other}"),
        }
    }

    #[test]
    fn weight_exactly_10000_no_heavy_surcharge() {
        let r = q(10000, "domestic").unwrap();
        assert_eq!(r.surcharge_cents, 0);
    }

    #[test]
    fn weight_10001_gets_heavy_surcharge() {
        let r = q(10001, "domestic").unwrap();
        assert_eq!(r.surcharge_cents, 500);
    }

    #[test]
    fn malformed_line_wrong_field_count() {
        let err = parse_rate_card("domestic\t500\n").unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn malformed_line_bad_number() {
        let err = parse_rate_card("domestic\tabc\t599\n").unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn comments_and_blanks_skipped_but_counted() {
        let err = parse_rate_card("# header\n\ndomestic\t500\t599\nbad line\n").unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 4 }));
    }

    #[test]
    fn quote_reads_from_env_var() {
        let mut f = NamedTempFile::new().unwrap();
        f.write_all(CARD.as_bytes()).unwrap();
        std::env::set_var("RATECARD_PATH", f.path());
        let p = Parcel { weight_grams: 250, zone: "domestic".into() };
        let r = quote(&p).unwrap();
        assert_eq!(r.total_cents, 599);
    }

    #[test]
    fn quote_unavailable_when_path_missing() {
        std::env::set_var("RATECARD_PATH", "/nonexistent/path/ratecard.tsv");
        let p = Parcel { weight_grams: 100, zone: "domestic".into() };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn display_implementations() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 5 }.to_string(),
            "malformed rate card at line 5"
        );
        assert_eq!(QuoteError::UnknownZone("mars".into()).to_string(), "unknown zone: mars");
        assert_eq!(
            QuoteError::Overweight { grams: 100, limit: 50 }.to_string(),
            "parcel 100g exceeds zone limit of 50g"
        );
    }

    #[test]
    fn error_trait() {
        let err: Box<dyn std::error::Error> = Box::new(QuoteError::RateCardUnavailable);
        assert_eq!(err.to_string(), "rate card unavailable");
    }
}
