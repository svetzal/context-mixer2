use std::collections::HashMap;
use std::fmt;
use std::fs;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {grams}g exceeds limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

    for (i, raw_line) in contents.lines().enumerate() {
        let line_number = i + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = raw_line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let zone = fields[0].trim().to_string();
        let max_grams: u32 = fields[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        zones
            .entry(zone)
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(zones)
}

fn round_half_up(value: f64) -> u64 {
    (value + 0.5).floor() as u64
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let zones = load_rate_card()?;

    let bands = zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = bands.last().map(|b| b.max_grams).unwrap_or(0);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = band.cents;
    let band_max_grams = band.max_grams;

    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += round_half_up(base_cents as f64 * 0.2);
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote: zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn write_rate_card(content: &str) -> tempfile::NamedTempFile {
        let mut f = tempfile::NamedTempFile::new().unwrap();
        f.write_all(content.as_bytes()).unwrap();
        f
    }

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn with_card<F: FnOnce()>(content: &str, f: F) {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let file = write_rate_card(content);
        std::env::set_var("RATECARD_PATH", file.path());
        f();
        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn domestic_light_parcel() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 250,
                zone: "domestic".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_exact_band_boundary() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_second_band() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
        });
    }

    #[test]
    fn domestic_heavy_surcharge() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 15000,
                zone: "domestic".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
        });
    }

    #[test]
    fn international_light() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 300,
                zone: "international".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 1499);
            // 20% of 1499 = 299.8, rounded half-up = 300
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_heavy_both_surcharges() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 15000,
                zone: "international".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 4999);
            // 20% of 4999 = 999.8, half-up = 1000; plus 500 heavy
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
        });
    }

    #[test]
    fn unknown_zone() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 100,
                zone: "mars".into(),
            };
            let err = quote(&p).unwrap_err();
            match err {
                QuoteError::UnknownZone(z) => assert_eq!(z, "mars"),
                other => panic!("expected UnknownZone, got {other}"),
            }
        });
    }

    #[test]
    fn overweight() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 30000,
                zone: "domestic".into(),
            };
            let err = quote(&p).unwrap_err();
            match err {
                QuoteError::Overweight { grams, limit } => {
                    assert_eq!(grams, 30000);
                    assert_eq!(limit, 20000);
                }
                other => panic!("expected Overweight, got {other}"),
            }
        });
    }

    #[test]
    fn missing_env_var() {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        std::env::remove_var("RATECARD_PATH");
        let p = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        match quote(&p).unwrap_err() {
            QuoteError::RateCardUnavailable => {}
            other => panic!("expected RateCardUnavailable, got {other}"),
        }
    }

    #[test]
    fn unreadable_path() {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        std::env::set_var("RATECARD_PATH", "/no/such/file");
        let p = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        match quote(&p).unwrap_err() {
            QuoteError::RateCardUnavailable => {}
            other => panic!("expected RateCardUnavailable, got {other}"),
        }
        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn malformed_line() {
        let bad = "domestic\t500\n";
        with_card(bad, || {
            let p = Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            };
            match quote(&p).unwrap_err() {
                QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
                other => panic!("expected MalformedRateCard, got {other}"),
            }
        });
    }

    #[test]
    fn malformed_number() {
        let bad = "domestic\tabc\t500\n";
        with_card(bad, || {
            let p = Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            };
            match quote(&p).unwrap_err() {
                QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
                other => panic!("expected MalformedRateCard, got {other}"),
            }
        });
    }

    #[test]
    fn comments_and_blanks_skipped() {
        let card = "# header\n\ndomestic\t1000\t500\n";
        with_card(card, || {
            let p = Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 500);
        });
    }

    #[test]
    fn malformed_after_comment_reports_correct_line() {
        let card = "# header\n\ndomestic\tbad\n";
        with_card(card, || {
            let p = Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            };
            match quote(&p).unwrap_err() {
                QuoteError::MalformedRateCard { line } => assert_eq!(line, 3),
                other => panic!("expected MalformedRateCard, got {other}"),
            }
        });
    }

    #[test]
    fn display_impls() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 5 }.to_string(),
            "malformed rate card at line 5"
        );
        assert_eq!(
            QuoteError::UnknownZone("mars".into()).to_string(),
            "unknown zone: mars"
        );
        assert_eq!(
            QuoteError::Overweight { grams: 100, limit: 50 }.to_string(),
            "overweight: 100g exceeds limit of 50g"
        );
    }

    #[test]
    fn error_trait() {
        let e: Box<dyn std::error::Error> =
            Box::new(QuoteError::RateCardUnavailable);
        let _ = e.to_string();
    }

    #[test]
    fn weight_exactly_10000_no_heavy_surcharge() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 10000,
                zone: "domestic".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.surcharge_cents, 0);
        });
    }

    #[test]
    fn weight_10001_gets_heavy_surcharge() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 10001,
                zone: "domestic".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.surcharge_cents, 500);
        });
    }
}
