use std::fmt;
use std::fs;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {grams}g exceeds limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<Vec<(String, Band)>, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut entries = Vec::new();
    for (i, raw_line) in content.lines().enumerate() {
        let line_number = i + 1;
        let line = raw_line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = raw_line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let zone = parts[0].to_string();
        let max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        entries.push((zone, Band { max_grams, cents }));
    }
    Ok(entries)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let entries = load_rate_card()?;

    let mut bands: Vec<Band> = entries
        .into_iter()
        .filter(|(z, _)| z == &parcel.zone)
        .map(|(_, b)| b)
        .collect();

    if bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    bands.sort_by_key(|b| b.max_grams);

    let largest = bands.last().unwrap().max_grams;
    if parcel.weight_grams > largest {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest,
        });
    }

    let band = bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .unwrap();

    let base_cents = band.cents;
    let band_max_grams = band.max_grams;

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let intl_surcharge = (base_cents as f64 * 0.2).round() as u64;
        surcharge_cents += intl_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote: zone={} weight={}g total={}c",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write as _;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn set_rate_card(content: &str) -> (NamedTempFile, std::sync::MutexGuard<'static, ()>) {
        let guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let mut f = NamedTempFile::new().unwrap();
        f.write_all(content.as_bytes()).unwrap();
        f.flush().unwrap();
        std::env::set_var("RATECARD_PATH", f.path());
        (f, guard)
    }

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999";

    #[test]
    fn domestic_light_parcel() {
        let _f = set_rate_card(SAMPLE_CARD);
        let q = quote(&Parcel {
            weight_grams: 200,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_exact_band_boundary() {
        let _f = set_rate_card(SAMPLE_CARD);
        let q = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_second_band() {
        let _f = set_rate_card(SAMPLE_CARD);
        let q = quote(&Parcel {
            weight_grams: 501,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn domestic_heavy_surcharge() {
        let _f = set_rate_card(SAMPLE_CARD);
        let q = quote(&Parcel {
            weight_grams: 15000,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn international_light() {
        let _f = set_rate_card(SAMPLE_CARD);
        let q = quote(&Parcel {
            weight_grams: 300,
            zone: "international".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 1499);
        let intl_surcharge = (1499.0 * 0.2_f64).round() as u64;
        assert_eq!(q.surcharge_cents, intl_surcharge);
        assert_eq!(q.total_cents, 1499 + intl_surcharge);
    }

    #[test]
    fn international_heavy_both_surcharges() {
        let _f = set_rate_card(SAMPLE_CARD);
        let q = quote(&Parcel {
            weight_grams: 15000,
            zone: "international".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 4999);
        let intl_surcharge = (4999.0 * 0.2_f64).round() as u64;
        assert_eq!(q.surcharge_cents, 500 + intl_surcharge);
        assert_eq!(q.total_cents, 4999 + 500 + intl_surcharge);
    }

    #[test]
    fn unknown_zone() {
        let _f = set_rate_card(SAMPLE_CARD);
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "mars".into(),
        })
        .unwrap_err();
        match err {
            QuoteError::UnknownZone(z) => assert_eq!(z, "mars"),
            other => panic!("expected UnknownZone, got: {other}"),
        }
    }

    #[test]
    fn overweight() {
        let _f = set_rate_card(SAMPLE_CARD);
        let err = quote(&Parcel {
            weight_grams: 25000,
            zone: "domestic".into(),
        })
        .unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 25000);
                assert_eq!(limit, 20000);
            }
            other => panic!("expected Overweight, got: {other}"),
        }
    }

    #[test]
    fn rate_card_unavailable_no_env() {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        std::env::remove_var("RATECARD_PATH");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn rate_card_unavailable_bad_path() {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        std::env::set_var("RATECARD_PATH", "/nonexistent/path.tsv");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn malformed_rate_card_bad_columns() {
        let _f = set_rate_card("domestic\t500\ndomestic\t2000\t899");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            other => panic!("expected MalformedRateCard, got: {other}"),
        }
    }

    #[test]
    fn malformed_rate_card_bad_number() {
        let _f = set_rate_card("domestic\tabc\t599");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            other => panic!("expected MalformedRateCard, got: {other}"),
        }
    }

    #[test]
    fn comments_and_blanks_skipped() {
        let card = "# header\n\ndomestic\t1000\t500\n";
        let _f = set_rate_card(card);
        let q = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 500);
    }

    #[test]
    fn malformed_line_number_counts_comments() {
        let card = "# header\n\ndomestic\tbad\t500\n";
        let _f = set_rate_card(card);
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 3),
            other => panic!("expected MalformedRateCard, got: {other}"),
        }
    }

    #[test]
    fn display_impl() {
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "rate card unavailable"
        );
        assert_eq!(
            QuoteError::MalformedRateCard { line: 5 }.to_string(),
            "malformed rate card at line 5"
        );
        assert_eq!(
            QuoteError::UnknownZone("mars".into()).to_string(),
            "unknown zone: mars"
        );
        assert_eq!(
            QuoteError::Overweight {
                grams: 100,
                limit: 50
            }
            .to_string(),
            "overweight: 100g exceeds limit of 50g"
        );
    }

    #[test]
    fn error_trait() {
        let err: Box<dyn std::error::Error> =
            Box::new(QuoteError::UnknownZone("test".into()));
        assert!(err.source().is_none());
    }
}
