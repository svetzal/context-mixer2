mod zones;

use std::fmt;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {grams}g exceeds limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<Vec<(String, Band)>, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = std::fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut entries = Vec::new();
    for (i, raw_line) in contents.lines().enumerate() {
        let line_number = i + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = trimmed.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        entries.push((parts[0].to_string(), Band { max_grams, cents }));
    }
    Ok(entries)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let entries = load_rate_card()?;

    let mut zone_bands: Vec<&Band> = entries
        .iter()
        .filter(|(z, _)| z == &parcel.zone)
        .map(|(_, b)| b)
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.max_grams);

    let largest = zone_bands.last().unwrap().max_grams;
    if parcel.weight_grams > largest {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest,
        });
    }

    let band = zone_bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .unwrap();

    let base_cents = band.cents;
    let band_max_grams = band.max_grams;

    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote: zone={} weight={}g total={}c",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write as _;

    fn write_rate_card(content: &str) -> tempfile::NamedTempFile {
        let mut f = tempfile::NamedTempFile::new().unwrap();
        f.write_all(content.as_bytes()).unwrap();
        f
    }

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn with_card<F: FnOnce()>(content: &str, f: F) {
        let tmp = write_rate_card(content);
        std::env::set_var("RATECARD_PATH", tmp.path());
        f();
    }

    #[test]
    fn domestic_light_parcel() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 200,
                zone: "domestic".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_mid_band() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
        });
    }

    #[test]
    fn domestic_heavy_surcharge() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 15000,
                zone: "domestic".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
        });
    }

    #[test]
    fn international_surcharge() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 300,
                zone: "international".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 1499);
            // 20% of 1499 = 299.8 → rounded half-up = 300
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_heavy_both_surcharges() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 15000,
                zone: "international".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 4999);
            // 500 (heavy) + 20% of 4999 = 999.8 → 1000
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
        });
    }

    #[test]
    fn exact_band_boundary() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn unknown_zone() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 100,
                zone: "mars".into(),
            };
            let err = quote(&p).unwrap_err();
            match err {
                QuoteError::UnknownZone(z) => assert_eq!(z, "mars"),
                other => panic!("expected UnknownZone, got {other}"),
            }
        });
    }

    #[test]
    fn overweight() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel {
                weight_grams: 30000,
                zone: "domestic".into(),
            };
            let err = quote(&p).unwrap_err();
            match err {
                QuoteError::Overweight { grams, limit } => {
                    assert_eq!(grams, 30000);
                    assert_eq!(limit, 20000);
                }
                other => panic!("expected Overweight, got {other}"),
            }
        });
    }

    #[test]
    fn missing_env_var() {
        std::env::remove_var("RATECARD_PATH");
        let p = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn unreadable_path() {
        std::env::set_var("RATECARD_PATH", "/nonexistent/path/ratecard.tsv");
        let p = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn malformed_line() {
        let bad = "# header\ndomestic\t500\t599\nbad line here\n";
        with_card(bad, || {
            let p = Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            };
            let err = quote(&p).unwrap_err();
            match err {
                QuoteError::MalformedRateCard { line } => assert_eq!(line, 3),
                other => panic!("expected MalformedRateCard, got {other}"),
            }
        });
    }

    #[test]
    fn malformed_number() {
        let bad = "domestic\tabc\t599\n";
        with_card(bad, || {
            let p = Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            };
            let err = quote(&p).unwrap_err();
            assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
        });
    }

    #[test]
    fn display_and_error_traits() {
        let err = QuoteError::RateCardUnavailable;
        let _msg = format!("{err}");
        let _source = std::error::Error::source(&err);
    }
}
