use std::collections::HashMap;
use std::fmt;
use std::fs;

#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {grams}g exceeds limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

    for (idx, raw_line) in content.lines().enumerate() {
        let line_number = idx + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = raw_line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let zone = fields[0].trim().to_string();
        let max_grams: u32 = fields[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        zones
            .entry(zone)
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(zones)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let zones = load_rate_card()?;

    let bands = zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|b| parcel.weight_grams <= b.max_grams)
        .ok_or_else(|| {
            let limit = bands.last().map(|b| b.max_grams).unwrap_or(0);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = band.cents;
    let band_max_grams = band.max_grams;

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up
        let intl_surcharge = (base_cents * 20 + 50) / 100;
        surcharge_cents += intl_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote: zone={} weight={}g total={}c",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write as IoWrite;

    fn write_rate_card(content: &str) -> tempfile::NamedTempFile {
        let mut f = tempfile::NamedTempFile::new().unwrap();
        f.write_all(content.as_bytes()).unwrap();
        f.flush().unwrap();
        f
    }

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn domestic_light_parcel() {
        let f = write_rate_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", f.path());
        let q = quote(&Parcel {
            weight_grams: 250,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_exact_boundary() {
        let f = write_rate_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", f.path());
        let q = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_second_band() {
        let f = write_rate_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", f.path());
        let q = quote(&Parcel {
            weight_grams: 501,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn domestic_heavy_surcharge() {
        let f = write_rate_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", f.path());
        let q = quote(&Parcel {
            weight_grams: 15000,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn international_light() {
        let f = write_rate_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", f.path());
        let q = quote(&Parcel {
            weight_grams: 300,
            zone: "international".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 1499);
        // 20% of 1499 = 299.8 → rounded half-up = 300
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_heavy_both_surcharges() {
        let f = write_rate_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", f.path());
        let q = quote(&Parcel {
            weight_grams: 15000,
            zone: "international".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 4999);
        // 20% of 4999 = 999.8 → 1000, plus 500 heavy
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn overweight_error() {
        let f = write_rate_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", f.path());
        let err = quote(&Parcel {
            weight_grams: 25000,
            zone: "domestic".into(),
        })
        .unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 25000);
                assert_eq!(limit, 20000);
            }
            _ => panic!("expected Overweight"),
        }
    }

    #[test]
    fn unknown_zone_error() {
        let f = write_rate_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", f.path());
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "mars".into(),
        })
        .unwrap_err();
        match err {
            QuoteError::UnknownZone(z) => assert_eq!(z, "mars"),
            _ => panic!("expected UnknownZone"),
        }
    }

    #[test]
    fn rate_card_unavailable_no_env() {
        std::env::remove_var("RATECARD_PATH");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn rate_card_unavailable_bad_path() {
        std::env::set_var("RATECARD_PATH", "/nonexistent/path/to/card.tsv");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn malformed_rate_card_bad_fields() {
        let f = write_rate_card("# header\ndomestic\t500\n");
        std::env::set_var("RATECARD_PATH", f.path());
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 2),
            _ => panic!("expected MalformedRateCard"),
        }
    }

    #[test]
    fn malformed_rate_card_bad_number() {
        let f = write_rate_card("domestic\tabc\t599\n");
        std::env::set_var("RATECARD_PATH", f.path());
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            _ => panic!("expected MalformedRateCard"),
        }
    }

    #[test]
    fn display_and_error_traits() {
        let err = QuoteError::RateCardUnavailable;
        let _ = format!("{err}");
        let _: &dyn std::error::Error = &err;
    }

    #[test]
    fn weight_exactly_10000_no_heavy_surcharge() {
        let f = write_rate_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", f.path());
        let q = quote(&Parcel {
            weight_grams: 10000,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn weight_10001_gets_heavy_surcharge() {
        let f = write_rate_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", f.path());
        let q = quote(&Parcel {
            weight_grams: 10001,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.surcharge_cents, 500);
    }
}
