use std::collections::HashMap;
use std::fmt;
use std::fs;
use std::path::Path;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {grams}g exceeds limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

fn parse_rate_card(content: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

    for (i, raw_line) in content.lines().enumerate() {
        let line_num = i + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = raw_line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }
        let zone = parts[0].trim().to_string();
        let max_grams: u32 = parts[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = parts[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        zones
            .entry(zone)
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(zones)
}

fn load_rate_card(path: &Path) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let content = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&content)
}

fn compute_quote(
    parcel: &Parcel,
    zones: &HashMap<String, Vec<Band>>,
) -> Result<Quote, QuoteError> {
    let bands = zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = bands.last().map(|b| b.max_grams).unwrap_or(0);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = band.cents;
    let band_max_grams = band.max_grams;

    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let zones = load_rate_card(Path::new(&path))?;
    let result = compute_quote(parcel, &zones)?;

    eprintln!(
        "quote: zone={} weight={}g total={}c",
        parcel.zone, parcel.weight_grams, result.total_cents
    );

    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write as _;
    use tempfile::NamedTempFile;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn write_card(content: &str) -> NamedTempFile {
        let mut f = NamedTempFile::new().unwrap();
        f.write_all(content.as_bytes()).unwrap();
        f.flush().unwrap();
        f
    }

    fn quote_from(parcel: &Parcel, card: &str) -> Result<Quote, QuoteError> {
        let zones = parse_rate_card(card)?;
        compute_quote(parcel, &zones)
    }

    #[test]
    fn domestic_light_parcel() {
        let q = quote_from(
            &Parcel { weight_grams: 250, zone: "domestic".into() },
            SAMPLE,
        ).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_mid_band() {
        let q = quote_from(
            &Parcel { weight_grams: 1000, zone: "domestic".into() },
            SAMPLE,
        ).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.total_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn domestic_heavy_surcharge() {
        let q = quote_from(
            &Parcel { weight_grams: 15000, zone: "domestic".into() },
            SAMPLE,
        ).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn international_light() {
        let q = quote_from(
            &Parcel { weight_grams: 300, zone: "international".into() },
            SAMPLE,
        ).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_heavy_both_surcharges() {
        let q = quote_from(
            &Parcel { weight_grams: 15000, zone: "international".into() },
            SAMPLE,
        ).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn exact_band_boundary() {
        let q = quote_from(
            &Parcel { weight_grams: 500, zone: "domestic".into() },
            SAMPLE,
        ).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn unknown_zone() {
        let err = quote_from(
            &Parcel { weight_grams: 100, zone: "mars".into() },
            SAMPLE,
        ).unwrap_err();
        match err {
            QuoteError::UnknownZone(z) => assert_eq!(z, "mars"),
            other => panic!("expected UnknownZone, got: {other}"),
        }
    }

    #[test]
    fn overweight() {
        let err = quote_from(
            &Parcel { weight_grams: 25000, zone: "domestic".into() },
            SAMPLE,
        ).unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 25000);
                assert_eq!(limit, 20000);
            }
            other => panic!("expected Overweight, got: {other}"),
        }
    }

    #[test]
    fn missing_env_var() {
        std::env::remove_var("RATECARD_PATH");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        }).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn unreadable_path() {
        std::env::set_var("RATECARD_PATH", "/no/such/file");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        }).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn reads_from_env_path() {
        let f = write_card(SAMPLE);
        std::env::set_var("RATECARD_PATH", f.path());
        let q = quote(&Parcel {
            weight_grams: 250,
            zone: "domestic".into(),
        }).unwrap();
        assert_eq!(q.total_cents, 599);
    }

    #[test]
    fn malformed_line() {
        let err = quote_from(
            &Parcel { weight_grams: 100, zone: "domestic".into() },
            "# header\ndomestic\t500\ndomestic\t2000\t899\n",
        ).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 2),
            other => panic!("expected MalformedRateCard, got: {other}"),
        }
    }

    #[test]
    fn malformed_number() {
        let err = quote_from(
            &Parcel { weight_grams: 100, zone: "domestic".into() },
            "domestic\tabc\t500\n",
        ).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            other => panic!("expected MalformedRateCard, got: {other}"),
        }
    }

    #[test]
    fn weight_at_10000_no_heavy_surcharge() {
        let q = quote_from(
            &Parcel { weight_grams: 10000, zone: "domestic".into() },
            SAMPLE,
        ).unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn weight_at_10001_has_heavy_surcharge() {
        let q = quote_from(
            &Parcel { weight_grams: 10001, zone: "domestic".into() },
            SAMPLE,
        ).unwrap();
        assert_eq!(q.surcharge_cents, 500);
    }

    #[test]
    fn display_and_error_impls() {
        let err = QuoteError::RateCardUnavailable;
        let _msg = format!("{err}");
        let _src = std::error::Error::source(&err);
    }
}
