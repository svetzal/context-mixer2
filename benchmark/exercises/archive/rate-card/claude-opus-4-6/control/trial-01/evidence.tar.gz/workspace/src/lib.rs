use std::collections::HashMap;
use std::fmt;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {grams}g exceeds limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug)]
struct Band {
    max_grams: u32,
    cents: u64,
}

fn parse_rate_card(content: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

    for (i, line) in content.lines().enumerate() {
        let line_num = i + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = fields[0].to_string();
        let max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        zones
            .entry(zone)
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(zones)
}

fn compute_quote(parcel: &Parcel, rate_card: &HashMap<String, Vec<Band>>) -> Result<Quote, QuoteError> {
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = match bands.iter().find(|b| b.max_grams >= parcel.weight_grams) {
        Some(b) => b,
        None => {
            let limit = bands.last().map(|b| b.max_grams).unwrap_or(0);
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let band_max_grams = band.max_grams;

    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content =
        std::fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let rate_card = parse_rate_card(&content)?;
    let result = compute_quote(parcel, &rate_card)?;

    eprintln!(
        "quote: zone={} weight={}g total={}c",
        parcel.zone, parcel.weight_grams, result.total_cents
    );

    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write as _;
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn sample_rate_card() -> HashMap<String, Vec<Band>> {
        parse_rate_card(SAMPLE_CARD).unwrap()
    }

    fn write_rate_card(content: &str) -> tempfile::NamedTempFile {
        let mut f = tempfile::NamedTempFile::new().unwrap();
        f.write_all(content.as_bytes()).unwrap();
        f.flush().unwrap();
        f
    }

    #[test]
    fn domestic_light_parcel() {
        let rc = sample_rate_card();
        let p = Parcel { weight_grams: 300, zone: "domestic".into() };
        let q = compute_quote(&p, &rc).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_exact_band_boundary() {
        let rc = sample_rate_card();
        let p = Parcel { weight_grams: 500, zone: "domestic".into() };
        let q = compute_quote(&p, &rc).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_second_band() {
        let rc = sample_rate_card();
        let p = Parcel { weight_grams: 501, zone: "domestic".into() };
        let q = compute_quote(&p, &rc).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn domestic_heavy_surcharge() {
        let rc = sample_rate_card();
        let p = Parcel { weight_grams: 15000, zone: "domestic".into() };
        let q = compute_quote(&p, &rc).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn domestic_at_10000_no_surcharge() {
        let rc = sample_rate_card();
        let p = Parcel { weight_grams: 10000, zone: "domestic".into() };
        let q = compute_quote(&p, &rc).unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn domestic_at_10001_gets_surcharge() {
        let rc = sample_rate_card();
        let p = Parcel { weight_grams: 10001, zone: "domestic".into() };
        let q = compute_quote(&p, &rc).unwrap();
        assert_eq!(q.surcharge_cents, 500);
    }

    #[test]
    fn international_light_parcel() {
        let rc = sample_rate_card();
        let p = Parcel { weight_grams: 300, zone: "international".into() };
        let q = compute_quote(&p, &rc).unwrap();
        assert_eq!(q.base_cents, 1499);
        // 20% of 1499 = 299.8, rounded half-up = 300
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_heavy_both_surcharges() {
        let rc = sample_rate_card();
        let p = Parcel { weight_grams: 15000, zone: "international".into() };
        let q = compute_quote(&p, &rc).unwrap();
        assert_eq!(q.base_cents, 4999);
        // 20% of 4999 = 999.8, rounded half-up = 1000; + 500 heavy
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone() {
        let rc = sample_rate_card();
        let p = Parcel { weight_grams: 100, zone: "mars".into() };
        let err = compute_quote(&p, &rc).unwrap_err();
        match err {
            QuoteError::UnknownZone(z) => assert_eq!(z, "mars"),
            other => panic!("expected UnknownZone, got: {other}"),
        }
    }

    #[test]
    fn overweight() {
        let rc = sample_rate_card();
        let p = Parcel { weight_grams: 20001, zone: "domestic".into() };
        let err = compute_quote(&p, &rc).unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 20001);
                assert_eq!(limit, 20000);
            }
            other => panic!("expected Overweight, got: {other}"),
        }
    }

    #[test]
    fn malformed_bad_field_count() {
        let content = "domestic\t500\n";
        let err = parse_rate_card(content).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            other => panic!("expected MalformedRateCard, got: {other}"),
        }
    }

    #[test]
    fn malformed_bad_number() {
        let content = "domestic\tabc\t599\n";
        let err = parse_rate_card(content).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 1),
            other => panic!("expected MalformedRateCard, got: {other}"),
        }
    }

    #[test]
    fn malformed_line_number_counts_comments() {
        let content = "# header\n\ndomestic\tbad\t599\n";
        let err = parse_rate_card(content).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 3),
            other => panic!("expected MalformedRateCard, got: {other}"),
        }
    }

    #[test]
    fn skips_comments_and_blanks() {
        let content = "# comment\n\ndomestic\t500\t599\n";
        let rc = parse_rate_card(content).unwrap();
        assert_eq!(rc.len(), 1);
        assert_eq!(rc["domestic"].len(), 1);
    }

    #[test]
    fn quote_reads_env_var() {
        let _lock = ENV_LOCK.lock().unwrap();
        let f = write_rate_card(SAMPLE_CARD);
        std::env::set_var("RATECARD_PATH", f.path());
        let p = Parcel { weight_grams: 300, zone: "domestic".into() };
        let q = quote(&p).unwrap();
        assert_eq!(q.total_cents, 599);
    }

    #[test]
    fn quote_missing_env_var() {
        let _lock = ENV_LOCK.lock().unwrap();
        std::env::remove_var("RATECARD_PATH");
        let p = Parcel { weight_grams: 300, zone: "domestic".into() };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn quote_missing_file() {
        let _lock = ENV_LOCK.lock().unwrap();
        std::env::set_var("RATECARD_PATH", "/nonexistent/path/ratecard.tsv");
        let p = Parcel { weight_grams: 300, zone: "domestic".into() };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn error_display() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 5 }.to_string(),
            "malformed rate card at line 5"
        );
        assert_eq!(
            QuoteError::UnknownZone("mars".into()).to_string(),
            "unknown zone: mars"
        );
        assert_eq!(
            QuoteError::Overweight { grams: 25000, limit: 20000 }.to_string(),
            "overweight: 25000g exceeds limit of 20000g"
        );
    }

    #[test]
    fn error_is_std_error() {
        let err: Box<dyn std::error::Error> = Box::new(QuoteError::RateCardUnavailable);
        assert!(!err.to_string().is_empty());
    }
}
