mod zones;

use std::env;
use std::fmt;
use std::fs;

#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {grams}g exceeds limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<Vec<(String, Band)>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut entries = Vec::new();
    for (line_idx, raw) in content.lines().enumerate() {
        let line_number = line_idx + 1;
        let trimmed = raw.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = raw.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let zone = fields[0].to_string();
        let max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        entries.push((zone, Band { max_grams, cents }));
    }
    Ok(entries)
}

fn round_half_up(value: f64) -> u64 {
    (value + 0.5).floor() as u64
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let entries = load_rate_card()?;

    let mut bands: Vec<&Band> = entries
        .iter()
        .filter(|(z, _)| z == &parcel.zone)
        .map(|(_, b)| b)
        .collect();

    if bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    bands.sort_by_key(|b| b.max_grams);

    let largest = bands.last().unwrap().max_grams;
    if parcel.weight_grams > largest {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest,
        });
    }

    let band = bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .unwrap();

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += round_half_up(base_cents as f64 * 0.20);
    }

    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote: zone={} weight={}g total={}c",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write as _;

    fn write_rate_card(content: &str) -> tempfile::NamedTempFile {
        let mut f = tempfile::NamedTempFile::new().unwrap();
        f.write_all(content.as_bytes()).unwrap();
        f.flush().unwrap();
        f
    }

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn with_card<F: FnOnce()>(content: &str, f: F) {
        let file = write_rate_card(content);
        env::set_var("RATECARD_PATH", file.path());
        f();
        env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn domestic_light_parcel() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel { weight_grams: 250, zone: "domestic".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_exact_band_boundary() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel { weight_grams: 500, zone: "domestic".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_second_band() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel { weight_grams: 501, zone: "domestic".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
        });
    }

    #[test]
    fn domestic_heavy_surcharge() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel { weight_grams: 15000, zone: "domestic".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
        });
    }

    #[test]
    fn international_light() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel { weight_grams: 300, zone: "international".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 1499);
            // 20% of 1499 = 299.8, rounded half-up = 300
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_heavy_both_surcharges() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel { weight_grams: 15000, zone: "international".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 4999);
            // 20% of 4999 = 999.8 -> 1000, plus 500 for heavy
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
        });
    }

    #[test]
    fn unknown_zone() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel { weight_grams: 100, zone: "mars".into() };
            let err = quote(&p).unwrap_err();
            assert!(matches!(err, QuoteError::UnknownZone(z) if z == "mars"));
        });
    }

    #[test]
    fn overweight() {
        with_card(SAMPLE_CARD, || {
            let p = Parcel { weight_grams: 25000, zone: "domestic".into() };
            let err = quote(&p).unwrap_err();
            assert!(matches!(err, QuoteError::Overweight { grams: 25000, limit: 20000 }));
        });
    }

    #[test]
    fn missing_env_var() {
        env::remove_var("RATECARD_PATH");
        let p = Parcel { weight_grams: 100, zone: "domestic".into() };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn unreadable_file() {
        env::set_var("RATECARD_PATH", "/nonexistent/path/to/ratecard.tsv");
        let p = Parcel { weight_grams: 100, zone: "domestic".into() };
        let err = quote(&p).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
        env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn malformed_line() {
        let bad = "domestic\t500\n";
        with_card(bad, || {
            let p = Parcel { weight_grams: 100, zone: "domestic".into() };
            let err = quote(&p).unwrap_err();
            assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
        });
    }

    #[test]
    fn malformed_number() {
        let bad = "domestic\tabc\t500\n";
        with_card(bad, || {
            let p = Parcel { weight_grams: 100, zone: "domestic".into() };
            let err = quote(&p).unwrap_err();
            assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
        });
    }

    #[test]
    fn comments_and_blanks_skipped() {
        let card = "# header\n\ndomestic\t1000\t500\n";
        with_card(card, || {
            let p = Parcel { weight_grams: 500, zone: "domestic".into() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 500);
        });
    }

    #[test]
    fn malformed_line_number_counts_blanks_and_comments() {
        let card = "# comment\n\ndomestic\tbad\t500\n";
        with_card(card, || {
            let p = Parcel { weight_grams: 100, zone: "domestic".into() };
            let err = quote(&p).unwrap_err();
            assert!(matches!(err, QuoteError::MalformedRateCard { line: 3 }));
        });
    }

    #[test]
    fn display_impl() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 5 }.to_string(),
            "malformed rate card at line 5"
        );
        assert_eq!(
            QuoteError::UnknownZone("mars".into()).to_string(),
            "unknown zone: mars"
        );
        assert_eq!(
            QuoteError::Overweight { grams: 30000, limit: 20000 }.to_string(),
            "overweight: 30000g exceeds limit 20000g"
        );
    }

    #[test]
    fn error_trait() {
        let err: Box<dyn std::error::Error> =
            Box::new(QuoteError::RateCardUnavailable);
        assert!(err.source().is_none());
    }
}
