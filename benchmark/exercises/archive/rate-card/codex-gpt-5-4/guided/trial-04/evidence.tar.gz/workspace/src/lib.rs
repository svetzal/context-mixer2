pub mod zones;

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

const RATECARD_PATH_ENV: &str = "RATECARD_PATH";
const HEAVY_PARCEL_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_PARCEL_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams} exceeds limit {limit}")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct RateBand {
    band_max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let limit = bands.last().map(|band| band.band_max_grams).unwrap_or(0);
    let band = bands.iter().find(|band| parcel.weight_grams <= band.band_max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        },
    )?;

    let base_cents = band.cents;
    let surcharge_cents = heavy_parcel_surcharge(parcel.weight_grams)
        + international_surcharge(&parcel.zone, base_cents);
    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

fn load_rate_card() -> Result<HashMap<String, Vec<RateBand>>, QuoteError> {
    let path = env::var(RATECARD_PATH_ENV).map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<RateBand>>, QuoteError> {
    let mut bands_by_zone: HashMap<String, Vec<RateBand>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let zone = fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let band_max_grams =
            fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let band_max_grams = band_max_grams
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = cents
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        bands_by_zone.entry(zone.to_string()).or_default().push(RateBand {
            band_max_grams,
            cents,
        });
    }

    for bands in bands_by_zone.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(bands_by_zone)
}

fn heavy_parcel_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > HEAVY_PARCEL_THRESHOLD_GRAMS {
        HEAVY_PARCEL_SURCHARGE_CENTS
    } else {
        0
    }
}

fn international_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == INTERNATIONAL_ZONE {
        (base_cents + 2) / 5
    } else {
        0
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::ffi::OsString;
    use std::path::Path;
    use std::sync::atomic::{AtomicU64, Ordering};
    use std::sync::{Mutex, OnceLock};

    struct TestEnvGuard {
        original: Option<OsString>,
    }

    impl Drop for TestEnvGuard {
        fn drop(&mut self) {
            match &self.original {
                Some(value) => env::set_var(RATECARD_PATH_ENV, value),
                None => env::remove_var(RATECARD_PATH_ENV),
            }
        }
    }

    struct TempRateCard {
        path: std::path::PathBuf,
    }

    impl TempRateCard {
        fn path(&self) -> &Path {
            &self.path
        }
    }

    impl Drop for TempRateCard {
        fn drop(&mut self) {
            let _ = fs::remove_file(&self.path);
        }
    }

    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    fn write_rate_card(contents: &str) -> TempRateCard {
        static NEXT_ID: AtomicU64 = AtomicU64::new(0);

        let path = env::temp_dir().join(format!(
            "ratecard-test-{}-{}.tsv",
            std::process::id(),
            NEXT_ID.fetch_add(1, Ordering::Relaxed)
        ));
        fs::write(&path, contents).expect("write rate card");
        TempRateCard { path }
    }

    fn with_rate_card<T>(path: &Path, f: impl FnOnce() -> T) -> T {
        let _lock = env_lock().lock().expect("env lock");
        let guard = TestEnvGuard {
            original: env::var_os(RATECARD_PATH_ENV),
        };
        env::set_var(RATECARD_PATH_ENV, path);
        let result = f();
        drop(guard);
        result
    }

    #[test]
    fn quotes_domestic_without_surcharge() {
        let rate_card = write_rate_card(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             international\t500\t1499\n",
        );

        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };

        let quote = with_rate_card(rate_card.path(), || quote(&parcel)).expect("quote");

        assert_eq!(
            quote,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn sorts_bands_before_matching() {
        let rate_card = write_rate_card(
            "domestic\t2000\t899\n\
             domestic\t500\t599\n\
             domestic\t20000\t1799\n",
        );

        let parcel = Parcel {
            weight_grams: 400,
            zone: "domestic".to_string(),
        };

        let quote = with_rate_card(rate_card.path(), || quote(&parcel)).expect("quote");

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn adds_both_surcharges_for_heavy_international_parcels() {
        let rate_card = write_rate_card(
            "international\t500\t1499\n\
             international\t20000\t4999\n",
        );

        let parcel = Parcel {
            weight_grams: 15_000,
            zone: "international".to_string(),
        };

        let quote = with_rate_card(rate_card.path(), || quote(&parcel)).expect("quote");

        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1_500);
        assert_eq!(quote.total_cents, 6_499);
    }

    #[test]
    fn rounds_international_surcharge_half_up() {
        assert_eq!(international_surcharge("international", 1499), 300);
        assert_eq!(international_surcharge("international", 1501), 300);
    }

    #[test]
    fn rejects_unknown_zone() {
        let rate_card = write_rate_card("domestic\t500\t599\n");
        let parcel = Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        };

        let error = with_rate_card(rate_card.path(), || quote(&parcel)).expect_err("unknown zone");

        assert_eq!(error, QuoteError::UnknownZone("international".to_string()));
    }

    #[test]
    fn rejects_overweight_parcels() {
        let rate_card = write_rate_card("domestic\t500\t599\ndomestic\t2000\t899\n");
        let parcel = Parcel {
            weight_grams: 2001,
            zone: "domestic".to_string(),
        };

        let error = with_rate_card(rate_card.path(), || quote(&parcel)).expect_err("overweight");

        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 2001,
                limit: 2000,
            }
        );
    }

    #[test]
    fn reports_unavailable_rate_card_when_env_is_missing() {
        let _lock = env_lock().lock().expect("env lock");
        let _guard = TestEnvGuard {
            original: env::var_os(RATECARD_PATH_ENV),
        };
        env::remove_var(RATECARD_PATH_ENV);

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("missing env should fail");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn reports_unavailable_rate_card_when_file_is_unreadable() {
        let error = with_rate_card(Path::new("/definitely/missing/ratecard.tsv"), || {
            quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            })
        })
        .expect_err("missing file should fail");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn reports_malformed_line_for_wrong_field_count() {
        let rate_card = write_rate_card(
            "# header\n\
             domestic\t500\t599\n\
             international\t20000\n",
        );

        let error = with_rate_card(rate_card.path(), || {
            quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            })
        })
        .expect_err("malformed file should fail");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn reports_malformed_line_for_bad_number() {
        let rate_card = write_rate_card(
            "\n\
             domestic\t500\t599\n\
             international\tnope\t4999\n",
        );

        let error = with_rate_card(rate_card.path(), || {
            quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            })
        })
        .expect_err("malformed file should fail");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
    }
}
