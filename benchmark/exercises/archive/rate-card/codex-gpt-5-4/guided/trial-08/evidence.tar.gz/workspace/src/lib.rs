pub mod zones;

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams} exceeds limit {limit}")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    band_max_grams: u32,
    cents: u64,
}

type RateCard = HashMap<String, Vec<Band>>;

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let limit = bands.last().map(|band| band.band_max_grams).unwrap_or(0);
    let band = bands
        .iter()
        .find(|band| parcel.weight_grams <= band.band_max_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let surcharge_cents = surcharge_cents(parcel, band.cents);
    let total_cents = band.cents + surcharge_cents;
    let quote = Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    };

    emit_quote_diagnostic(parcel, &quote);

    Ok(quote)
}

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut rate_card: RateCard = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let zone = fields
            .next()
            .filter(|field| !field.is_empty())
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let band_max_grams = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        rate_card
            .entry(zone.to_owned())
            .or_default()
            .push(Band { band_max_grams, cents });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(rate_card)
}

fn surcharge_cents(parcel: &Parcel, base_cents: u64) -> u64 {
    let overweight_surcharge = if parcel.weight_grams > 10_000 { 500 } else { 0 };
    let international_surcharge = if parcel.zone == "international" {
        (base_cents * 20 + 50) / 100
    } else {
        0
    };

    overweight_surcharge + international_surcharge
}

fn emit_quote_diagnostic(parcel: &Parcel, quote: &Quote) {
    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, quote.total_cents
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::path::PathBuf;
    use std::process;
    use std::sync::atomic::{AtomicU64, Ordering};
    use std::time::{SystemTime, UNIX_EPOCH};

    #[test]
    fn quotes_domestic_in_first_matching_band() {
        let _guard = RateCardEnvGuard::set(sample_rate_card());

        let quote = quote(&Parcel {
            weight_grams: 450,
            zone: "domestic".to_owned(),
        })
        .expect("quote should succeed");

        assert_eq!(
            quote,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn international_quote_adds_percentage_surcharge_with_half_up_rounding() {
        let _guard = RateCardEnvGuard::set(concat!(
            "international\t500\t1499\n",
            "international\t20000\t4999\n"
        ));

        let quote = quote(&Parcel {
            weight_grams: 500,
            zone: "international".to_owned(),
        })
        .expect("quote should succeed");

        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn heavy_international_quote_adds_both_surcharges() {
        let _guard = RateCardEnvGuard::set(sample_rate_card());

        let quote = quote(&Parcel {
            weight_grams: 15_000,
            zone: "international".to_owned(),
        })
        .expect("quote should succeed");

        assert_eq!(
            quote,
            Quote {
                base_cents: 4999,
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20_000,
            }
        );
    }

    #[test]
    fn unknown_zone_returns_requested_zone() {
        let _guard = RateCardEnvGuard::set(sample_rate_card());

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "express".to_owned(),
        })
        .expect_err("quote should fail");

        assert_eq!(error, QuoteError::UnknownZone("express".to_owned()));
    }

    #[test]
    fn overweight_uses_largest_band_for_zone() {
        let _guard = RateCardEnvGuard::set(sample_rate_card());

        let error = quote(&Parcel {
            weight_grams: 20_001,
            zone: "international".to_owned(),
        })
        .expect_err("quote should fail");

        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            }
        );
    }

    #[test]
    fn missing_ratecard_path_is_unavailable() {
        let _guard = RateCardEnvGuard::unset();

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        })
        .expect_err("quote should fail");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn unreadable_ratecard_path_is_unavailable() {
        let _guard = RateCardEnvGuard::path("/definitely/missing/ratecard.tsv");

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        })
        .expect_err("quote should fail");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn malformed_ratecard_reports_line_for_bad_field_count() {
        let _guard = RateCardEnvGuard::set("domestic\t500\n");

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        })
        .expect_err("quote should fail");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn malformed_ratecard_reports_line_for_bad_number() {
        let _guard = RateCardEnvGuard::set(concat!(
            "# comment\n",
            "\n",
            "domestic\tfive-hundred\t599\n"
        ));

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        })
        .expect_err("quote should fail");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn quote_error_implements_error_trait() {
        let err: &dyn Error = &QuoteError::RateCardUnavailable;
        assert_eq!(err.to_string(), "rate card unavailable");
    }

    #[test]
    fn bands_are_applied_in_ascending_order_even_if_file_is_unsorted() {
        let _guard = RateCardEnvGuard::set(concat!(
            "domestic\t2000\t899\n",
            "domestic\t500\t599\n",
            "domestic\t20000\t1799\n"
        ));

        let quote = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".to_owned(),
        })
        .expect("quote should succeed");

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    fn sample_rate_card() -> &'static str {
        concat!(
            "# zone\tband_max_grams\tcents\n",
            "domestic\t500\t599\n",
            "domestic\t2000\t899\n",
            "domestic\t20000\t1799\n",
            "international\t500\t1499\n",
            "international\t20000\t4999\n"
        )
    }

    struct RateCardEnvGuard {
        previous: Option<String>,
        temp_path: Option<PathBuf>,
    }

    impl RateCardEnvGuard {
        fn set(contents: &str) -> Self {
            let path = unique_temp_path();
            fs::write(&path, contents).expect("temp rate card should be written");
            Self::path_with_temp(path)
        }

        fn path(path: &str) -> Self {
            let previous = env::var("RATECARD_PATH").ok();
            env::set_var("RATECARD_PATH", path);
            Self {
                previous,
                temp_path: None,
            }
        }

        fn unset() -> Self {
            let previous = env::var("RATECARD_PATH").ok();
            env::remove_var("RATECARD_PATH");
            Self {
                previous,
                temp_path: None,
            }
        }

        fn path_with_temp(path: PathBuf) -> Self {
            let previous = env::var("RATECARD_PATH").ok();
            env::set_var("RATECARD_PATH", &path);
            Self {
                previous,
                temp_path: Some(path),
            }
        }
    }

    impl Drop for RateCardEnvGuard {
        fn drop(&mut self) {
            match &self.previous {
                Some(path) => {
                    env::set_var("RATECARD_PATH", path);
                }
                None => {
                    env::remove_var("RATECARD_PATH");
                }
            }

            if let Some(path) = &self.temp_path {
                let _ = fs::remove_file(path);
            }
        }
    }

    fn unique_temp_path() -> PathBuf {
        static COUNTER: AtomicU64 = AtomicU64::new(0);

        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("system time should be after unix epoch")
            .as_nanos();
        let sequence = COUNTER.fetch_add(1, Ordering::Relaxed);

        env::temp_dir().join(format!(
            "ratecard-test-{}-{}-{sequence}.tsv",
            process::id(),
            nanos
        ))
    }
}
