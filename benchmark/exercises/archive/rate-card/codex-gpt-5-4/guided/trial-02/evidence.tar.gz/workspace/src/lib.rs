use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

const RATECARD_PATH_ENV: &str = "RATECARD_PATH";
const INTERNATIONAL_ZONE: &str = "international";
const HEAVY_SURCHARGE_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_SURCHARGE_CENTS: u64 = 500;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams} exceeds limit {limit}")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct RateBand {
    band_max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let largest_band = bands
        .last()
        .copied()
        .expect("zones are only recorded when at least one band exists");

    let matched_band = bands
        .iter()
        .find(|band| parcel.weight_grams <= band.band_max_grams)
        .copied()
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest_band.band_max_grams,
        })?;

    let surcharge_cents = surcharge_cents(parcel, matched_band.cents);
    let total_cents = matched_band.cents + surcharge_cents;
    emit_quote_diagnostic(parcel, total_cents);

    Ok(Quote {
        base_cents: matched_band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: matched_band.band_max_grams,
    })
}

fn load_rate_card() -> Result<HashMap<String, Vec<RateBand>>, QuoteError> {
    let path = env::var(RATECARD_PATH_ENV).map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<RateBand>>, QuoteError> {
    let mut by_zone: HashMap<String, Vec<RateBand>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let zone = fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let band_max_grams = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        by_zone.entry(zone.to_owned()).or_default().push(RateBand {
            band_max_grams,
            cents,
        });
    }

    for bands in by_zone.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(by_zone)
}

fn surcharge_cents(parcel: &Parcel, base_cents: u64) -> u64 {
    let heavy_surcharge = if parcel.weight_grams > HEAVY_SURCHARGE_THRESHOLD_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    };

    let international_surcharge = if parcel.zone == INTERNATIONAL_ZONE {
        (base_cents + 2) / 5
    } else {
        0
    };

    heavy_surcharge + international_surcharge
}

fn emit_quote_diagnostic(parcel: &Parcel, total_cents: u64) {
    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::path::{Path, PathBuf};
    use std::sync::{Mutex, MutexGuard};
    use std::time::{SystemTime, UNIX_EPOCH};

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    #[test]
    fn quotes_domestic_band_without_surcharge() {
        let _guard = env_guard();
        with_rate_card(
            concat!(
                "# zone\tband_max_grams\tcents\n",
                "domestic\t500\t599\n",
                "domestic\t2000\t899\n",
            ),
            || {
                let parcel = Parcel {
                    weight_grams: 500,
                    zone: "domestic".to_string(),
                };

                let quoted = quote(&parcel).expect("quote should succeed");

                assert_eq!(
                    quoted,
                    Quote {
                        base_cents: 599,
                        surcharge_cents: 0,
                        total_cents: 599,
                        band_max_grams: 500,
                    }
                );
            },
        );
    }

    #[test]
    fn quotes_international_with_half_up_and_heavy_surcharges() {
        let _guard = env_guard();
        with_rate_card(
            concat!("international\t500\t1499\n", "international\t20000\t4999\n",),
            || {
                let parcel = Parcel {
                    weight_grams: 15_000,
                    zone: "international".to_string(),
                };

                let quoted = quote(&parcel).expect("quote should succeed");

                assert_eq!(quoted.base_cents, 4999);
                assert_eq!(quoted.surcharge_cents, 1500);
                assert_eq!(quoted.total_cents, 6499);
                assert_eq!(quoted.band_max_grams, 20_000);
            },
        );
    }

    #[test]
    fn reports_unknown_zone() {
        let _guard = env_guard();
        with_rate_card("domestic\t500\t599\n", || {
            let err = quote(&Parcel {
                weight_grams: 100,
                zone: "remote".to_string(),
            })
            .expect_err("quote should fail");

            assert_eq!(err, QuoteError::UnknownZone("remote".to_string()));
        });
    }

    #[test]
    fn reports_overweight_with_zone_limit() {
        let _guard = env_guard();
        with_rate_card(concat!("domestic\t500\t599\n", "domestic\t2000\t899\n"), || {
            let err = quote(&Parcel {
                weight_grams: 2001,
                zone: "domestic".to_string(),
            })
            .expect_err("quote should fail");

            assert_eq!(
                err,
                QuoteError::Overweight {
                    grams: 2001,
                    limit: 2000
                }
            );
        });
    }

    #[test]
    fn treats_missing_env_as_unavailable() {
        let _guard = env_guard();
        env::remove_var(RATECARD_PATH_ENV);

        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("quote should fail");

        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn treats_unreadable_path_as_unavailable() {
        let _guard = env_guard();
        env::set_var(RATECARD_PATH_ENV, "/definitely/missing/ratecard.tsv");

        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("quote should fail");

        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn reports_malformed_line_number_for_wrong_field_count() {
        let _guard = env_guard();
        with_rate_card(concat!("# comment\n", "\n", "domestic\t500\n"), || {
            let err = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            })
            .expect_err("quote should fail");

            assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
        });
    }

    #[test]
    fn reports_malformed_line_number_for_bad_number() {
        let _guard = env_guard();
        with_rate_card(concat!("domestic\t500\t599\n", "international\tbad\t1499\n"), || {
            let err = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            })
            .expect_err("quote should fail");

            assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
        });
    }

    #[test]
    fn uses_ascending_band_order_even_if_file_is_unsorted() {
        let _guard = env_guard();
        with_rate_card(concat!("domestic\t2000\t899\n", "domestic\t500\t599\n"), || {
            let quoted = quote(&Parcel {
                weight_grams: 400,
                zone: "domestic".to_string(),
            })
            .expect("quote should succeed");

            assert_eq!(quoted.base_cents, 599);
            assert_eq!(quoted.band_max_grams, 500);
        });
    }

    fn env_guard() -> MutexGuard<'static, ()> {
        ENV_LOCK.lock().expect("env mutex should not be poisoned")
    }

    fn with_rate_card<F>(contents: &str, run: F)
    where
        F: FnOnce(),
    {
        let path = unique_rate_card_path();
        fs::write(&path, contents).expect("rate card should be written");
        env::set_var(RATECARD_PATH_ENV, &path);
        run();
        env::remove_var(RATECARD_PATH_ENV);
        remove_if_present(&path);
    }

    fn unique_rate_card_path() -> PathBuf {
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock should be after epoch")
            .as_nanos();
        env::temp_dir().join(format!("ratecard-test-{nanos}.tsv"))
    }

    fn remove_if_present(path: &Path) {
        match fs::remove_file(path) {
            Ok(()) => {}
            Err(err) if err.kind() == std::io::ErrorKind::NotFound => {}
            Err(err) => panic!("failed to remove temp rate card: {err}"),
        }
    }
}
