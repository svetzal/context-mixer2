use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;
use std::path::PathBuf;

pub mod zones;

const RATECARD_PATH_ENV: &str = "RATECARD_PATH";
const INTERNATIONAL_ZONE: &str = "international";
const OVERWEIGHT_SURCHARGE_CENTS: u64 = 500;
const OVERWEIGHT_THRESHOLD_GRAMS: u32 = 10_000;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => f.write_str("rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams} exceeds zone limit {limit}")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    band_max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let ratecard = load_ratecard()?;
    let bands = ratecard
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let limit = bands.last().map(|band| band.band_max_grams).unwrap_or(0);
    let band = bands
        .iter()
        .find(|band| parcel.weight_grams <= band.band_max_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let base_cents = band.cents;
    let surcharge_cents = surcharge_for(parcel, base_cents);
    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

fn load_ratecard() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var_os(RATECARD_PATH_ENV)
        .filter(|value| !value.is_empty())
        .map(PathBuf::from)
        .ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_ratecard(&contents)
}

fn parse_ratecard(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut ratecard: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, raw_line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let line = raw_line.trim();

        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let mut fields = raw_line.split('\t');
        let zone = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let band_max_grams = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        ratecard.entry(zone.to_string()).or_default().push(Band {
            band_max_grams,
            cents,
        });
    }

    for bands in ratecard.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(ratecard)
}

fn surcharge_for(parcel: &Parcel, base_cents: u64) -> u64 {
    let overweight = if parcel.weight_grams > OVERWEIGHT_THRESHOLD_GRAMS {
        OVERWEIGHT_SURCHARGE_CENTS
    } else {
        0
    };
    let international = if parcel.zone == INTERNATIONAL_ZONE {
        (base_cents + 2) / 5
    } else {
        0
    };

    overweight + international
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicU64, Ordering};
    use std::sync::{Mutex, OnceLock};
    use std::time::{SystemTime, UNIX_EPOCH};

    struct TestDir {
        path: PathBuf,
    }

    impl TestDir {
        fn new() -> Self {
            static NEXT_ID: AtomicU64 = AtomicU64::new(0);

            let unique = NEXT_ID.fetch_add(1, Ordering::Relaxed);
            let timestamp = SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .expect("system time")
                .as_nanos();
            let path = env::temp_dir().join(format!(
                "ratecard-tests-{}-{}-{}",
                std::process::id(),
                timestamp,
                unique
            ));
            fs::create_dir(&path).expect("create temp dir");
            Self { path }
        }

        fn path(&self) -> &std::path::Path {
            &self.path
        }
    }

    impl Drop for TestDir {
        fn drop(&mut self) {
            let _ = fs::remove_dir_all(&self.path);
        }
    }

    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    fn write_ratecard(dir: &TestDir, contents: &str) -> PathBuf {
        let path = dir.path().join("rates.tsv");
        fs::write(&path, contents).expect("write ratecard");
        path
    }

    fn with_ratecard<T>(contents: &str, f: impl FnOnce() -> T) -> T {
        let _guard = env_lock().lock().expect("lock env");
        let dir = TestDir::new();
        let path = write_ratecard(&dir, contents);
        env::set_var(RATECARD_PATH_ENV, &path);
        let result = f();
        env::remove_var(RATECARD_PATH_ENV);
        result
    }

    fn sample_ratecard() -> &'static str {
        "# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
"
    }

    #[test]
    fn quotes_domestic_in_matching_band_without_surcharge() {
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        };

        let quote = with_ratecard(sample_ratecard(), || quote(&parcel)).expect("quote");

        assert_eq!(
            quote,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn quotes_international_with_combined_surcharges() {
        let parcel = Parcel {
            weight_grams: 15_000,
            zone: "international".to_string(),
        };

        let quote = with_ratecard(sample_ratecard(), || quote(&parcel)).expect("quote");

        assert_eq!(
            quote,
            Quote {
                base_cents: 4_999,
                surcharge_cents: 1_500,
                total_cents: 6_499,
                band_max_grams: 20_000,
            }
        );
    }

    #[test]
    fn rounds_international_surcharge_half_up() {
        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        };

        let quote = with_ratecard("international\t500\t1498\n", || quote(&parcel)).expect("quote");

        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1_798);
    }

    #[test]
    fn reports_unknown_zone() {
        let parcel = Parcel {
            weight_grams: 100,
            zone: "express".to_string(),
        };

        let error = with_ratecard(sample_ratecard(), || quote(&parcel)).expect_err("unknown zone");

        assert_eq!(error, QuoteError::UnknownZone("express".to_string()));
    }

    #[test]
    fn reports_overweight_with_zone_limit() {
        let parcel = Parcel {
            weight_grams: 20_001,
            zone: "domestic".to_string(),
        };

        let error = with_ratecard(sample_ratecard(), || quote(&parcel)).expect_err("overweight");

        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            }
        );
    }

    #[test]
    fn reports_unavailable_when_env_is_unset() {
        let _guard = env_lock().lock().expect("lock env");
        env::remove_var(RATECARD_PATH_ENV);

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("missing env");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn reports_unavailable_when_file_cannot_be_read() {
        let _guard = env_lock().lock().expect("lock env");
        env::set_var(RATECARD_PATH_ENV, "does/not/exist.tsv");

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("missing file");

        env::remove_var(RATECARD_PATH_ENV);
        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn reports_malformed_ratecard_line_numbers_for_bad_field_count() {
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        let error = with_ratecard(
            "# comment\n\n domestic\t500\n",
            || quote(&parcel),
        )
        .expect_err("malformed");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn reports_malformed_ratecard_line_numbers_for_bad_numbers() {
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        };

        let error = with_ratecard(
            "# comment\n\ndomestic\tfive-hundred\t599\n",
            || quote(&parcel),
        )
        .expect_err("malformed");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn sorts_bands_before_matching() {
        let parcel = Parcel {
            weight_grams: 600,
            zone: "domestic".to_string(),
        };

        let quote = with_ratecard(
            "domestic\t2000\t899\ndomestic\t500\t599\ndomestic\t20000\t1799\n",
            || quote(&parcel),
        )
        .expect("quote");

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2_000);
    }
}
