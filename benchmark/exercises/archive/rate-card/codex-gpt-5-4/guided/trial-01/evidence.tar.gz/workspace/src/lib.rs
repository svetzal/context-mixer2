use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

const RATECARD_PATH_ENV: &str = "RATECARD_PATH";
const HEAVY_SURCHARGE_GRAMS: u32 = 10_000;
const HEAVY_SURCHARGE_CENTS: u64 = 500;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    band_max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|band| parcel.weight_grams <= band.band_max_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: bands.last().map(|band| band.band_max_grams).unwrap_or(0),
        })?;

    let heavy_surcharge = if parcel.weight_grams > HEAVY_SURCHARGE_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    };
    let international_surcharge = if parcel.zone == "international" {
        round_half_up_divisor_100(band.cents.saturating_mul(20))
    } else {
        0
    };
    let surcharge_cents = heavy_surcharge + international_surcharge;
    let total_cents = band.cents + surcharge_cents;

    emit_quote_diagnostic(parcel, total_cents);

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var(RATECARD_PATH_ENV).map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut by_zone: HashMap<String, Vec<Band>> = HashMap::new();
    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let zone = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let band_max_grams = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        by_zone.entry(zone.to_string()).or_default().push(Band {
            band_max_grams,
            cents,
        });
    }

    for bands in by_zone.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(by_zone)
}

fn round_half_up_divisor_100(numerator: u64) -> u64 {
    (numerator + 50) / 100
}

fn emit_quote_diagnostic(parcel: &Parcel, total_cents: u64) {
    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );
}

#[cfg(test)]
mod tests {
    use super::{quote, Parcel, Quote, QuoteError};
    use std::env;
    use std::fs;
    use std::path::{Path, PathBuf};
    use std::sync::atomic::{AtomicU64, Ordering};

    const SAMPLE_RATECARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn quotes_domestic_first_matching_band_without_surcharge() {
        let _guard = RatecardEnvGuard::new(SAMPLE_RATECARD);

        let result = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        });

        assert_eq!(
            result,
            Ok(Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            })
        );
    }

    #[test]
    fn quotes_international_with_half_up_percent_surcharge() {
        let _guard = RatecardEnvGuard::new(SAMPLE_RATECARD);

        let result = quote(&Parcel {
            weight_grams: 300,
            zone: "international".to_string(),
        });

        assert_eq!(
            result,
            Ok(Quote {
                base_cents: 1499,
                surcharge_cents: 300,
                total_cents: 1799,
                band_max_grams: 500,
            })
        );
    }

    #[test]
    fn adds_both_surcharges_when_applicable() {
        let _guard = RatecardEnvGuard::new(SAMPLE_RATECARD);

        let result = quote(&Parcel {
            weight_grams: 15_000,
            zone: "international".to_string(),
        });

        assert_eq!(
            result,
            Ok(Quote {
                base_cents: 4999,
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20000,
            })
        );
    }

    #[test]
    fn reports_unknown_zone() {
        let _guard = RatecardEnvGuard::new(SAMPLE_RATECARD);

        let result = quote(&Parcel {
            weight_grams: 100,
            zone: "express".to_string(),
        });

        assert_eq!(result, Err(QuoteError::UnknownZone("express".to_string())));
    }

    #[test]
    fn reports_overweight_with_zone_limit() {
        let _guard = RatecardEnvGuard::new(SAMPLE_RATECARD);

        let result = quote(&Parcel {
            weight_grams: 25_000,
            zone: "international".to_string(),
        });

        assert_eq!(
            result,
            Err(QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000,
            })
        );
    }

    #[test]
    fn missing_ratecard_env_is_unavailable() {
        let _guard = EnvRestore::unset();

        let result = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        });

        assert_eq!(result, Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn unreadable_ratecard_is_unavailable() {
        let temp_dir = TestDir::new();
        let missing_path = temp_dir.path().join("missing.tsv");
        let _guard = EnvRestore::set(missing_path.to_string_lossy().into_owned());

        let result = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        });

        assert_eq!(result, Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn malformed_line_reports_full_line_number_for_wrong_field_count() {
        let _guard = RatecardEnvGuard::new("\n# comment\ndomestic\t500\t599\tunexpected\n");

        let result = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        });

        assert_eq!(result, Err(QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn malformed_line_reports_full_line_number_for_bad_number() {
        let _guard = RatecardEnvGuard::new("# comment\ndomestic\tfive-hundred\t599\n");

        let result = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        });

        assert_eq!(result, Err(QuoteError::MalformedRateCard { line: 2 }));
    }

    #[test]
    fn sorts_bands_before_matching() {
        let _guard =
            RatecardEnvGuard::new("domestic\t2000\t899\ndomestic\t500\t599\ndomestic\t20000\t1799\n");

        let result = quote(&Parcel {
            weight_grams: 400,
            zone: "domestic".to_string(),
        });

        assert_eq!(
            result,
            Ok(Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            })
        );
    }

    struct RatecardEnvGuard {
        _temp_dir: TestDir,
        _restore: EnvRestore,
    }

    impl RatecardEnvGuard {
        fn new(contents: &str) -> Self {
            let temp_dir = TestDir::new();
            let path = temp_dir.path().join("ratecard.tsv");
            fs::write(&path, contents).expect("write rate card");

            Self {
                _temp_dir: temp_dir,
                _restore: EnvRestore::set(path.to_string_lossy().into_owned()),
            }
        }
    }

    struct TestDir {
        path: PathBuf,
    }

    impl TestDir {
        fn new() -> Self {
            static NEXT_ID: AtomicU64 = AtomicU64::new(0);

            let unique = format!(
                "ratecard-test-{}-{}",
                std::process::id(),
                NEXT_ID.fetch_add(1, Ordering::Relaxed)
            );
            let path = env::temp_dir().join(unique);
            fs::create_dir(&path).expect("create temp dir");
            Self { path }
        }

        fn path(&self) -> &Path {
            &self.path
        }
    }

    impl Drop for TestDir {
        fn drop(&mut self) {
            let _ = fs::remove_dir_all(&self.path);
        }
    }

    struct EnvRestore {
        previous: Option<String>,
    }

    impl EnvRestore {
        fn set(value: String) -> Self {
            let previous = env::var(super::RATECARD_PATH_ENV).ok();
            // SAFETY: tests in this crate mutate one process-wide environment variable and
            // rely on cargo's default per-test-thread isolation for this crate run.
            unsafe { env::set_var(super::RATECARD_PATH_ENV, value) };
            Self { previous }
        }

        fn unset() -> Self {
            let previous = env::var(super::RATECARD_PATH_ENV).ok();
            // SAFETY: see the note in `set`; this test helper restores the prior value on drop.
            unsafe { env::remove_var(super::RATECARD_PATH_ENV) };
            Self { previous }
        }
    }

    impl Drop for EnvRestore {
        fn drop(&mut self) {
            match &self.previous {
                Some(value) => {
                    // SAFETY: restores the single environment variable this helper manages.
                    unsafe { env::set_var(super::RATECARD_PATH_ENV, value) };
                }
                None => {
                    // SAFETY: restores the process environment to the pre-test state.
                    unsafe { env::remove_var(super::RATECARD_PATH_ENV) };
                }
            }
        }
    }
}
