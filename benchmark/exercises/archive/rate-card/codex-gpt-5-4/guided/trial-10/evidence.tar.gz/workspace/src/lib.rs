use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams} exceeds zone limit {limit}")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    band_max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let limit = bands.last().map(|band| band.band_max_grams).unwrap_or(0);
    let band = bands
        .iter()
        .find(|band| parcel.weight_grams <= band.band_max_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let weight_surcharge = if parcel.weight_grams > 10_000 { 500 } else { 0 };
    let international_surcharge = if parcel.zone == "international" {
        (band.cents + 2) / 5
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;
    let total_cents = band.cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, raw_line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let line = raw_line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let mut fields = raw_line.split('\t');
        let zone = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let band_max_grams = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?;

        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let band_max_grams = band_max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = cents
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        zones
            .entry(zone.to_string())
            .or_default()
            .push(Band { band_max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(zones)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::path::{Path, PathBuf};
    use std::sync::atomic::{AtomicU64, Ordering};

    static NEXT_ID: AtomicU64 = AtomicU64::new(0);

    struct TempRateCard {
        path: PathBuf,
    }

    impl TempRateCard {
        fn path(&self) -> &Path {
            &self.path
        }
    }

    impl Drop for TempRateCard {
        fn drop(&mut self) {
            let _ = fs::remove_file(&self.path);
        }
    }

    fn with_rate_card(contents: &str) -> TempRateCard {
        let path = env::temp_dir().join(format!(
            "ratecard-test-{}-{}.tsv",
            std::process::id(),
            NEXT_ID.fetch_add(1, Ordering::Relaxed)
        ));
        fs::write(&path, contents).expect("write rate card");
        TempRateCard { path }
    }

    #[test]
    fn quotes_domestic_band_without_surcharge() {
        let rate_card = with_rate_card(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             international\t500\t1499\n",
        );
        env::set_var("RATECARD_PATH", rate_card.path());

        let quote = quote(&Parcel {
            weight_grams: 400,
            zone: "domestic".to_string(),
        })
        .expect("quote should succeed");

        assert_eq!(
            quote,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn quotes_international_with_half_up_rounding_and_weight_surcharge() {
        let rate_card = with_rate_card(
            "international\t20000\t1499\n\
             domestic\t20000\t999\n",
        );
        env::set_var("RATECARD_PATH", rate_card.path());

        let quote = quote(&Parcel {
            weight_grams: 15_000,
            zone: "international".to_string(),
        })
        .expect("quote should succeed");

        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 800);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20_000);
    }

    #[test]
    fn rejects_unknown_zone() {
        let rate_card = with_rate_card("domestic\t500\t599\n");
        env::set_var("RATECARD_PATH", rate_card.path());

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "regional".to_string(),
        })
        .expect_err("zone should be rejected");

        assert_eq!(error, QuoteError::UnknownZone("regional".to_string()));
    }

    #[test]
    fn rejects_overweight_with_zone_limit() {
        let rate_card = with_rate_card("domestic\t500\t599\ndomestic\t2000\t899\n");
        env::set_var("RATECARD_PATH", rate_card.path());

        let error = quote(&Parcel {
            weight_grams: 2001,
            zone: "domestic".to_string(),
        })
        .expect_err("weight should be rejected");

        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 2001,
                limit: 2000,
            }
        );
    }

    #[test]
    fn reports_malformed_rate_card_line_numbers_including_comments_and_blanks() {
        let rate_card = with_rate_card(
            "# header\n\
             \n\
             domestic\t500\t599\n\
             international\tbad\t1499\n",
        );
        env::set_var("RATECARD_PATH", rate_card.path());

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("bad card should fail");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn unavailable_rate_card_when_env_missing() {
        env::remove_var("RATECARD_PATH");

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("missing env should fail");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn unavailable_rate_card_when_file_unreadable() {
        env::set_var("RATECARD_PATH", "/definitely/missing/rate-card.tsv");

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("missing file should fail");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn parses_bands_in_ascending_threshold_order() {
        let rate_card = with_rate_card(
            "domestic\t2000\t899\n\
             domestic\t500\t599\n\
             domestic\t20000\t1799\n",
        );
        env::set_var("RATECARD_PATH", rate_card.path());

        let quote = quote(&Parcel {
            weight_grams: 450,
            zone: "domestic".to_string(),
        })
        .expect("quote should succeed");

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }
}
