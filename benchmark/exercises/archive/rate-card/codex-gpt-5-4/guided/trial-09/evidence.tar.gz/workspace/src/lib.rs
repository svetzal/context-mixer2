use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => write!(f, "malformed rate card at line {line}"),
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams} exceeds limit {limit}")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    band_max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let zones = load_rate_card()?;
    let bands = zones
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let largest_band = bands
        .last()
        .copied()
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|band| parcel.weight_grams <= band.band_max_grams)
        .copied()
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest_band.band_max_grams,
        })?;

    let mut surcharge_cents = 0_u64;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += round_half_up(band.cents * 20, 100);
    }

    let result = Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.band_max_grams,
    };

    emit_quote_diagnostic(parcel, &result);

    Ok(result)
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();
    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let zone = fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let band_max_grams = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        zones.entry(zone.to_string()).or_default().push(Band {
            band_max_grams,
            cents,
        });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(zones)
}

fn round_half_up(numerator: u64, denominator: u64) -> u64 {
    (numerator + (denominator / 2)) / denominator
}

fn emit_quote_diagnostic(parcel: &Parcel, quote: &Quote) {
    eprintln!(
        "ratecard.quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, quote.total_cents
    );
}

#[cfg(test)]
mod tests {
    use super::{quote, Parcel, Quote, QuoteError};
    use std::env;
    use std::fs;
    use std::marker::PhantomData;
    use std::path::Path;
    use std::sync::{Mutex, MutexGuard, OnceLock};
    use std::time::{SystemTime, UNIX_EPOCH};

    const SAMPLE_RATE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn quotes_first_matching_band() {
        let _guard = RateCardGuard::new(SAMPLE_RATE_CARD);

        let result = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        })
        .unwrap();

        assert_eq!(
            result,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn applies_international_percentage_with_half_up_rounding() {
        let _guard = RateCardGuard::new(
            "\
international\t500\t1499
",
        );

        let result = quote(&Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        })
        .unwrap();

        assert_eq!(result.surcharge_cents, 300);
        assert_eq!(result.total_cents, 1799);
    }

    #[test]
    fn combines_weight_and_international_surcharges() {
        let _guard = RateCardGuard::new(SAMPLE_RATE_CARD);

        let result = quote(&Parcel {
            weight_grams: 15_000,
            zone: "international".to_string(),
        })
        .unwrap();

        assert_eq!(
            result,
            Quote {
                base_cents: 4999,
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20000,
            }
        );
    }

    #[test]
    fn returns_unknown_zone_when_missing() {
        let _guard = RateCardGuard::new(SAMPLE_RATE_CARD);

        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "express".to_string(),
        })
        .unwrap_err();

        assert_eq!(err, QuoteError::UnknownZone("express".to_string()));
    }

    #[test]
    fn returns_overweight_with_largest_band_limit() {
        let _guard = RateCardGuard::new(SAMPLE_RATE_CARD);

        let err = quote(&Parcel {
            weight_grams: 20_001,
            zone: "domestic".to_string(),
        })
        .unwrap_err();

        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            }
        );
    }

    #[test]
    fn missing_ratecard_path_is_unavailable() {
        let _guard = EnvGuard::unset();
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .unwrap_err();

        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn unreadable_ratecard_is_unavailable() {
        let _guard = EnvGuard::set_to("/path/that/does/not/exist");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .unwrap_err();

        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn malformed_line_reports_original_line_number() {
        let _guard = RateCardGuard::new(
            "\
# comment

domestic\t500\t599
domestic\toops\t899
",
        );

        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .unwrap_err();

        assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn malformed_field_count_is_rejected() {
        let _guard = RateCardGuard::new("domestic\t500\t599\textra\n");

        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .unwrap_err();

        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    struct RateCardGuard {
        path: std::path::PathBuf,
        env_guard: EnvGuard,
    }

    impl RateCardGuard {
        fn new(contents: &str) -> Self {
            let path = unique_temp_path();
            write_file(&path, contents);
            Self {
                path: path.clone(),
                env_guard: EnvGuard::set_to(path.to_str().unwrap()),
            }
        }
    }

    impl Drop for RateCardGuard {
        fn drop(&mut self) {
            let _ = fs::remove_file(&self.path);
            let _ = &self.env_guard;
        }
    }

    struct EnvGuard {
        previous: Option<String>,
        _lock: MutexGuard<'static, ()>,
        _not_send_or_sync: PhantomData<*mut ()>,
    }

    impl EnvGuard {
        fn set_to(value: &str) -> Self {
            let lock = env_lock().lock().unwrap();
            let previous = env::var("RATECARD_PATH").ok();
            // Tests mutate process env; keep each mutation scoped to its guard.
            unsafe { env::set_var("RATECARD_PATH", value) };
            Self {
                previous,
                _lock: lock,
                _not_send_or_sync: PhantomData,
            }
        }

        fn unset() -> Self {
            let lock = env_lock().lock().unwrap();
            let previous = env::var("RATECARD_PATH").ok();
            unsafe { env::remove_var("RATECARD_PATH") };
            Self {
                previous,
                _lock: lock,
                _not_send_or_sync: PhantomData,
            }
        }
    }

    impl Drop for EnvGuard {
        fn drop(&mut self) {
            match &self.previous {
                Some(value) => unsafe { env::set_var("RATECARD_PATH", value) },
                None => unsafe { env::remove_var("RATECARD_PATH") },
            }
        }
    }

    fn write_file(path: &Path, contents: &str) {
        fs::write(path, contents).unwrap();
    }

    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    fn unique_temp_path() -> std::path::PathBuf {
        let unique = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos();
        env::temp_dir().join(format!("ratecard-test-{unique}.tsv"))
    }
}
