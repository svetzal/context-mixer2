use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

const RATECARD_ENV: &str = "RATECARD_PATH";
const HEAVY_PARCEL_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_PARCEL_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    band_max_grams: u32,
    cents: u64,
}

type RateCard = HashMap<String, Vec<Band>>;

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let limit = bands.last().map(|band| band.band_max_grams).unwrap_or_default();
    let band = bands.iter().find(|band| parcel.weight_grams <= band.band_max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        },
    )?;

    let base_cents = band.cents;
    let surcharge_cents =
        heavy_surcharge(parcel.weight_grams) + international_surcharge(&parcel.zone, base_cents);
    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = env::var_os(RATECARD_ENV).ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut zones = HashMap::<String, Vec<Band>>::new();

    for (index, raw_line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let line = raw_line.trim_end_matches('\r');

        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let zone = fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let band_max_grams = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        zones.entry(zone.to_owned()).or_default().push(Band {
            band_max_grams,
            cents,
        });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(zones)
}

fn heavy_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > HEAVY_PARCEL_THRESHOLD_GRAMS {
        HEAVY_PARCEL_SURCHARGE_CENTS
    } else {
        0
    }
}

fn international_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == INTERNATIONAL_ZONE {
        ((base_cents * INTERNATIONAL_SURCHARGE_PERCENT) + 50) / 100
    } else {
        0
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::{Path, PathBuf};
    use std::sync::{Mutex, OnceLock};
    use std::time::{SystemTime, UNIX_EPOCH};

    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    fn with_rate_card<T>(contents: &str, f: impl FnOnce() -> T) -> T {
        let _guard = env_lock().lock().expect("env lock poisoned");
        let path = unique_temp_path();
        fs::write(&path, contents).expect("write rate card");
        env::set_var(RATECARD_ENV, &path);
        let result = f();
        env::remove_var(RATECARD_ENV);
        let _ = fs::remove_file(path);
        result
    }

    fn unique_temp_path() -> PathBuf {
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("system time before epoch")
            .as_nanos();
        std::env::temp_dir().join(format!("ratecard-test-{}-{nanos}.tsv", std::process::id()))
    }

    #[test]
    fn quotes_domestic_band_without_surcharges() {
        with_rate_card(sample_rate_card(), || {
            let quote = quote(&Parcel {
                weight_grams: 500,
                zone: "domestic".to_owned(),
            })
            .expect("quote");

            assert_eq!(
                quote,
                Quote {
                    base_cents: 599,
                    surcharge_cents: 0,
                    total_cents: 599,
                    band_max_grams: 500,
                }
            );
        });
    }

    #[test]
    fn sorts_bands_before_matching() {
        with_rate_card("domestic\t20000\t1799\ndomestic\t500\t599\ndomestic\t2000\t899\n", || {
            let quote = quote(&Parcel {
                weight_grams: 501,
                zone: "domestic".to_owned(),
            })
            .expect("quote");

            assert_eq!(quote.base_cents, 899);
            assert_eq!(quote.band_max_grams, 2000);
        });
    }

    #[test]
    fn adds_international_and_heavy_surcharges() {
        with_rate_card(sample_rate_card(), || {
            let quote = quote(&Parcel {
                weight_grams: 15_000,
                zone: "international".to_owned(),
            })
            .expect("quote");

            assert_eq!(
                quote,
                Quote {
                    base_cents: 4_999,
                    surcharge_cents: 1_500,
                    total_cents: 6_499,
                    band_max_grams: 20_000,
                }
            );
        });
    }

    #[test]
    fn rounds_international_surcharge_half_up() {
        with_rate_card("international\t500\t1498\n", || {
            let quote = quote(&Parcel {
                weight_grams: 100,
                zone: "international".to_owned(),
            })
            .expect("quote");

            assert_eq!(quote.surcharge_cents, 300);
            assert_eq!(quote.total_cents, 1_798);
        });
    }

    #[test]
    fn errors_for_unknown_zone() {
        with_rate_card(sample_rate_card(), || {
            let error = quote(&Parcel {
                weight_grams: 100,
                zone: "express".to_owned(),
            })
            .expect_err("unknown zone");

            assert_eq!(error, QuoteError::UnknownZone("express".to_owned()));
        });
    }

    #[test]
    fn errors_for_overweight_parcel() {
        with_rate_card(sample_rate_card(), || {
            let error = quote(&Parcel {
                weight_grams: 20_001,
                zone: "international".to_owned(),
            })
            .expect_err("overweight");

            assert_eq!(
                error,
                QuoteError::Overweight {
                    grams: 20_001,
                    limit: 20_000,
                }
            );
        });
    }

    #[test]
    fn errors_when_env_var_is_unset() {
        let _guard = env_lock().lock().expect("env lock poisoned");
        env::remove_var(RATECARD_ENV);

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        })
        .expect_err("missing env var");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn errors_when_file_cannot_be_read() {
        let _guard = env_lock().lock().expect("env lock poisoned");
        env::set_var(RATECARD_ENV, Path::new("/definitely/missing/ratecard.tsv"));

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        })
        .expect_err("missing file");

        env::remove_var(RATECARD_ENV);
        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn reports_malformed_line_numbers_for_field_count() {
        with_rate_card(
            "# comment\n\ndomestic\t500\t599\nbad line\ninternational\t500\t1499\n",
            || {
                let error = quote(&Parcel {
                    weight_grams: 100,
                    zone: "domestic".to_owned(),
                })
                .expect_err("malformed rate card");

                assert_eq!(error, QuoteError::MalformedRateCard { line: 4 });
            },
        );
    }

    #[test]
    fn reports_malformed_line_numbers_for_bad_numbers() {
        with_rate_card("domestic\tfive_hundred\t599\n", || {
            let error = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".to_owned(),
            })
            .expect_err("malformed rate card");

            assert_eq!(error, QuoteError::MalformedRateCard { line: 1 });
        });
    }

    fn sample_rate_card() -> &'static str {
        "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n"
    }
}
