use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

const INTERNATIONAL_ZONE: &str = "international";
const HEAVY_SURCHARGE_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_SURCHARGE_CENTS: u64 = 500;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    band_max_grams: u32,
    cents: u64,
}

type RateCard = HashMap<String, Vec<Band>>;

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let selected_band =
        bands.iter().find(|band| parcel.weight_grams <= band.band_max_grams).copied();

    let band = match selected_band {
        Some(band) => band,
        None => {
            let limit = bands.last().map(|band| band.band_max_grams).unwrap_or(0);
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let surcharge_cents = weight_surcharge(parcel.weight_grams)
        + international_surcharge(parcel.zone.as_str(), band.cents);
    let total_cents = band.cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&content)
}

fn parse_rate_card(content: &str) -> Result<RateCard, QuoteError> {
    let mut rate_card = HashMap::<String, Vec<Band>>::new();

    for (index, raw_line) in content.lines().enumerate() {
        let line_number = index + 1;
        let line = raw_line.trim();

        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let mut fields = raw_line.split('\t');
        let zone = fields
            .next()
            .filter(|field| !field.is_empty())
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let band_max_grams = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        rate_card.entry(zone.to_owned()).or_default().push(Band {
            band_max_grams,
            cents,
        });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(rate_card)
}

fn weight_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > HEAVY_SURCHARGE_THRESHOLD_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    }
}

fn international_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == INTERNATIONAL_ZONE {
        (base_cents * 20 + 50) / 100
    } else {
        0
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::path::{Path, PathBuf};
    use std::sync::atomic::{AtomicU64, Ordering};

    static NEXT_TEMP_ID: AtomicU64 = AtomicU64::new(0);

    struct TempRateCard {
        path: PathBuf,
    }

    impl TempRateCard {
        fn new(contents: &str) -> Self {
            let unique = format!(
                "ratecard-test-{}-{}.tsv",
                std::process::id(),
                NEXT_TEMP_ID.fetch_add(1, Ordering::Relaxed)
            );
            let path = env::temp_dir().join(unique);
            fs::write(&path, contents).expect("write rate card");
            Self { path }
        }

        fn path(&self) -> &Path {
            &self.path
        }
    }

    impl Drop for TempRateCard {
        fn drop(&mut self) {
            let _ = fs::remove_file(&self.path);
        }
    }

    fn with_rate_card<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        let file = TempRateCard::new(contents);
        let previous = env::var_os("RATECARD_PATH");
        env::set_var("RATECARD_PATH", file.path());
        let result = test();
        match previous {
            Some(value) => env::set_var("RATECARD_PATH", value),
            None => env::remove_var("RATECARD_PATH"),
        }
        result
    }

    fn sample_rate_card() -> &'static str {
        "# zone\tband_max_grams\tcents\n\
         domestic\t500\t599\n\
         domestic\t2000\t899\n\
         domestic\t20000\t1799\n\
         international\t500\t1499\n\
         international\t20000\t4999\n"
    }

    #[test]
    fn quotes_domestic_without_surcharge() {
        let quote = with_rate_card(sample_rate_card(), || {
            quote(&Parcel {
                weight_grams: 500,
                zone: "domestic".to_owned(),
            })
        })
        .expect("quote");

        assert_eq!(
            quote,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn quotes_international_with_rounded_surcharge() {
        let quote = with_rate_card(sample_rate_card(), || {
            quote(&Parcel {
                weight_grams: 500,
                zone: "international".to_owned(),
            })
        })
        .expect("quote");

        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn adds_weight_and_international_surcharges_together() {
        let quote = with_rate_card(sample_rate_card(), || {
            quote(&Parcel {
                weight_grams: 15000,
                zone: "international".to_owned(),
            })
        })
        .expect("quote");

        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn returns_unknown_zone_when_zone_missing() {
        let error = with_rate_card(sample_rate_card(), || {
            quote(&Parcel {
                weight_grams: 500,
                zone: "express".to_owned(),
            })
        })
        .expect_err("unknown zone");

        assert_eq!(error, QuoteError::UnknownZone("express".to_owned()));
    }

    #[test]
    fn returns_overweight_with_largest_limit() {
        let error = with_rate_card(sample_rate_card(), || {
            quote(&Parcel {
                weight_grams: 20001,
                zone: "domestic".to_owned(),
            })
        })
        .expect_err("overweight");

        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 20001,
                limit: 20000,
            }
        );
    }

    #[test]
    fn rejects_unset_rate_card_path() {
        let previous = env::var_os("RATECARD_PATH");
        env::remove_var("RATECARD_PATH");

        let result = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        });

        match previous {
            Some(value) => env::set_var("RATECARD_PATH", value),
            None => env::remove_var("RATECARD_PATH"),
        }

        assert_eq!(result, Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn rejects_unreadable_rate_card_path() {
        let previous = env::var_os("RATECARD_PATH");
        env::set_var("RATECARD_PATH", "/definitely/missing/ratecard.tsv");

        let result = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_owned(),
        });

        match previous {
            Some(value) => env::set_var("RATECARD_PATH", value),
            None => env::remove_var("RATECARD_PATH"),
        }

        assert_eq!(result, Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn reports_malformed_rate_card_line_numbers_for_bad_field_count() {
        let error = with_rate_card(
            "# comment\n\n\
domestic\t500\t599\tunexpected\n",
            || {
                quote(&Parcel {
                    weight_grams: 100,
                    zone: "domestic".to_owned(),
                })
            },
        )
        .expect_err("malformed");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn reports_malformed_rate_card_line_numbers_for_bad_numbers() {
        let error = with_rate_card(
            "# comment\n\
domestic\tfive_hundred\t599\n",
            || {
                quote(&Parcel {
                    weight_grams: 100,
                    zone: "domestic".to_owned(),
                })
            },
        )
        .expect_err("malformed");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn sorts_bands_before_matching() {
        let quote = with_rate_card(
            "domestic\t20000\t1799\n\
domestic\t500\t599\n\
domestic\t2000\t899\n",
            || {
                quote(&Parcel {
                    weight_grams: 1000,
                    zone: "domestic".to_owned(),
                })
            },
        )
        .expect("quote");

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }
}
