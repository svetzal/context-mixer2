//! Shipping quote calculation backed by a tab-separated rate card.

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

const RATECARD_PATH_ENV: &str = "RATECARD_PATH";
const INTERNATIONAL_ZONE: &str = "international";
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;
const HEAVY_PARCEL_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_PARCEL_SURCHARGE_CENTS: u64 = 500;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct RateBand {
    band_max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let ratecard = load_ratecard()?;
    let bands = ratecard
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let largest_band = bands.last().expect("parsed rate card stores at least one band per zone");

    let matched_band = bands.iter().find(|band| parcel.weight_grams <= band.band_max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest_band.band_max_grams,
        },
    )?;

    let surcharge_cents = heavy_parcel_surcharge(parcel.weight_grams)
        + international_surcharge(parcel.zone.as_str(), matched_band.cents);
    let total_cents = matched_band.cents + surcharge_cents;

    emit_quote_diagnostic(parcel, total_cents);

    Ok(Quote {
        base_cents: matched_band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: matched_band.band_max_grams,
    })
}

fn load_ratecard() -> Result<HashMap<String, Vec<RateBand>>, QuoteError> {
    let path = env::var(RATECARD_PATH_ENV).map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_ratecard(&contents)
}

fn parse_ratecard(contents: &str) -> Result<HashMap<String, Vec<RateBand>>, QuoteError> {
    let mut ratecard: HashMap<String, Vec<RateBand>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = line.trim();

        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let zone = fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let band_max_grams =
            fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;

        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let band_max_grams = band_max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents =
            cents.parse().map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        ratecard.entry(zone.to_string()).or_default().push(RateBand {
            band_max_grams,
            cents,
        });
    }

    for bands in ratecard.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(ratecard)
}

fn heavy_parcel_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > HEAVY_PARCEL_THRESHOLD_GRAMS {
        HEAVY_PARCEL_SURCHARGE_CENTS
    } else {
        0
    }
}

fn international_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == INTERNATIONAL_ZONE {
        round_half_up(base_cents * INTERNATIONAL_SURCHARGE_PERCENT, 100)
    } else {
        0
    }
}

fn round_half_up(numerator: u64, denominator: u64) -> u64 {
    (numerator + (denominator / 2)) / denominator
}

fn emit_quote_diagnostic(parcel: &Parcel, total_cents: u64) {
    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::path::{Path, PathBuf};
    use std::sync::{Mutex, MutexGuard, OnceLock};
    use std::time::{SystemTime, UNIX_EPOCH};

    fn env_lock() -> MutexGuard<'static, ()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(())).lock().expect("env lock")
    }

    struct TestRatecard {
        _env_guard: MutexGuard<'static, ()>,
        dir: PathBuf,
    }

    impl Drop for TestRatecard {
        fn drop(&mut self) {
            // SAFETY: tests in this crate mutate process env while holding the global env lock.
            unsafe { env::remove_var(RATECARD_PATH_ENV) };
            let _ = fs::remove_dir_all(&self.dir);
        }
    }

    fn unique_test_dir() -> PathBuf {
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("system time before unix epoch")
            .as_nanos();
        env::temp_dir().join(format!("ratecard-tests-{}-{nanos}", std::process::id()))
    }

    fn write_ratecard(contents: &str) -> TestRatecard {
        let env_guard = env_lock();
        let dir = unique_test_dir();
        fs::create_dir_all(&dir).expect("create tempdir");
        let path = dir.join("ratecard.tsv");
        fs::write(&path, contents).expect("write ratecard");
        // SAFETY: tests in this crate mutate process env while holding the global env lock.
        unsafe { env::set_var(RATECARD_PATH_ENV, path) };
        TestRatecard {
            _env_guard: env_guard,
            dir,
        }
    }

    fn with_locked_env_removed() -> MutexGuard<'static, ()> {
        let env_guard = env_lock();
        // SAFETY: tests in this crate mutate process env while holding the global env lock.
        unsafe { env::remove_var(RATECARD_PATH_ENV) };
        env_guard
    }

    fn with_locked_env_path(path: &Path) -> MutexGuard<'static, ()> {
        let env_guard = env_lock();
        // SAFETY: tests in this crate mutate process env while holding the global env lock.
        unsafe { env::set_var(RATECARD_PATH_ENV, path) };
        env_guard
    }

    fn sample_ratecard() -> &'static str {
        "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n"
    }

    #[test]
    fn quotes_domestic_without_surcharge() {
        let _dir = write_ratecard(sample_ratecard());

        let quote = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        })
        .expect("quote");

        assert_eq!(
            quote,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn quotes_international_with_half_up_percentage_surcharge() {
        let _dir = write_ratecard(sample_ratecard());

        let quote = quote(&Parcel {
            weight_grams: 500,
            zone: "international".to_string(),
        })
        .expect("quote");

        assert_eq!(
            quote,
            Quote {
                base_cents: 1499,
                surcharge_cents: 300,
                total_cents: 1799,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn adds_heavy_and_international_surcharges_together() {
        let _dir = write_ratecard(sample_ratecard());

        let quote = quote(&Parcel {
            weight_grams: 15_000,
            zone: "international".to_string(),
        })
        .expect("quote");

        assert_eq!(
            quote,
            Quote {
                base_cents: 4999,
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20000,
            }
        );
    }

    #[test]
    fn unknown_zone_returns_error_with_requested_zone() {
        let _dir = write_ratecard(sample_ratecard());

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "express".to_string(),
        })
        .expect_err("unknown zone");

        assert_eq!(error, QuoteError::UnknownZone("express".to_string()));
    }

    #[test]
    fn overweight_uses_largest_band_limit_for_zone() {
        let _dir = write_ratecard(sample_ratecard());

        let error = quote(&Parcel {
            weight_grams: 20_001,
            zone: "domestic".to_string(),
        })
        .expect_err("overweight");

        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            }
        );
    }

    #[test]
    fn missing_ratecard_path_is_unavailable() {
        let _env_guard = with_locked_env_removed();

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("missing ratecard path");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn unreadable_ratecard_is_unavailable() {
        let _env_guard = with_locked_env_path(Path::new("/definitely/missing/ratecard.tsv"));

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("unreadable ratecard path");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn malformed_ratecard_reports_three_field_shape_errors() {
        let _dir = write_ratecard(
            "# comment\n\
\n\
domestic\t500\n",
        );

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("malformed ratecard");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn malformed_ratecard_reports_number_parse_errors_with_full_line_counting() {
        let _dir = write_ratecard(
            "# comment\n\
\n\
domestic\tfive_hundred\t599\n",
        );

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("malformed ratecard");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn uses_smallest_matching_band_after_sorting_zone_bands() {
        let _dir = write_ratecard(
            "domestic\t20000\t1799\n\
domestic\t500\t599\n\
domestic\t2000\t899\n",
        );

        let quote = quote(&Parcel {
            weight_grams: 1500,
            zone: "domestic".to_string(),
        })
        .expect("quote");

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }
}
