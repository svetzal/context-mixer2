use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;
use std::io::{self, Write};

pub mod zones;

const RATECARD_ENV: &str = "RATECARD_PATH";
const INTERNATIONAL_ZONE: &str = "international";
const HEAVY_PARCEL_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_PARCEL_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => write!(f, "malformed rate card at line {line}"),
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams} exceeds zone limit {limit}")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

type RateCard = HashMap<String, Vec<Band>>;

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let quote = quote_from_rate_card(parcel, &rate_card)?;
    let _ = emit_quote_diagnostic(parcel, &quote);
    Ok(quote)
}

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = env::var(RATECARD_ENV).map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut rate_card: RateCard = HashMap::new();

    for (index, raw_line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let line = raw_line.trim();

        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let mut fields = raw_line.split('\t');
        let zone = fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let max_grams = fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;

        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let max_grams = max_grams
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = cents
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        rate_card.entry(zone.to_string()).or_default().push(Band { max_grams, cents });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(rate_card)
}

fn quote_from_rate_card(parcel: &Parcel, rate_card: &RateCard) -> Result<Quote, QuoteError> {
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band =
        bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands.last().map(|band| band.max_grams).unwrap_or(0),
            }
        })?;

    let surcharge_cents = heavy_parcel_surcharge(parcel.weight_grams)
        + international_surcharge(&parcel.zone, band.cents);
    let total_cents = band.cents + surcharge_cents;

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn heavy_parcel_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > HEAVY_PARCEL_THRESHOLD_GRAMS {
        HEAVY_PARCEL_SURCHARGE_CENTS
    } else {
        0
    }
}

fn international_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == INTERNATIONAL_ZONE {
        round_half_up(base_cents * INTERNATIONAL_SURCHARGE_PERCENT, 100)
    } else {
        0
    }
}

fn round_half_up(numerator: u64, denominator: u64) -> u64 {
    (numerator + (denominator / 2)) / denominator
}

fn emit_quote_diagnostic(parcel: &Parcel, quote: &Quote) -> io::Result<()> {
    emit_quote_diagnostic_to(io::stderr(), parcel, quote)
}

fn emit_quote_diagnostic_to(
    mut writer: impl Write,
    parcel: &Parcel,
    quote: &Quote,
) -> io::Result<()> {
    writeln!(
        writer,
        "ratecard.quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, quote.total_cents
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs::{self, File};
    use std::path::{Path, PathBuf};
    use std::sync::{Mutex, OnceLock};
    use std::time::{SystemTime, UNIX_EPOCH};

    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    struct TestDir {
        path: PathBuf,
    }

    impl TestDir {
        fn path(&self) -> &Path {
            &self.path
        }
    }

    impl Drop for TestDir {
        fn drop(&mut self) {
            let _ = fs::remove_dir_all(&self.path);
        }
    }

    fn make_test_dir() -> TestDir {
        let unique = SystemTime::now().duration_since(UNIX_EPOCH).expect("time").as_nanos();
        let path =
            env::temp_dir().join(format!("ratecard-tests-{}-{}", std::process::id(), unique));
        fs::create_dir(&path).expect("create temp dir");
        TestDir { path }
    }

    fn write_rate_card(contents: &str) -> TestDir {
        let dir = make_test_dir();
        let path = dir.path().join("rates.tsv");
        let mut file = File::create(&path).expect("create rate card");
        std::io::Write::write_all(&mut file, contents.as_bytes()).expect("write rate card");
        dir
    }

    fn set_rate_card(dir: &TestDir) {
        env::set_var(RATECARD_ENV, dir.path().join("rates.tsv"));
    }

    #[test]
    fn quotes_domestic_parcel_from_first_matching_band() {
        let _guard = env_lock().lock().expect("env lock");
        let dir = write_rate_card(
            "# zone\tband_max_grams\tcents\n\
             domestic\t2000\t899\n\
             domestic\t500\t599\n\
             domestic\t20000\t1799\n",
        );
        set_rate_card(&dir);

        let quote = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        })
        .expect("quote");

        assert_eq!(
            quote,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn applies_international_and_heavy_surcharges() {
        let _guard = env_lock().lock().expect("env lock");
        let dir = write_rate_card(
            "international\t500\t1499\n\
             international\t20000\t4999\n",
        );
        set_rate_card(&dir);

        let quote = quote(&Parcel {
            weight_grams: 12_000,
            zone: "international".to_string(),
        })
        .expect("quote");

        assert_eq!(
            quote,
            Quote {
                base_cents: 4999,
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20000,
            }
        );
    }

    #[test]
    fn returns_unknown_zone_when_zone_absent() {
        let _guard = env_lock().lock().expect("env lock");
        let dir = write_rate_card("domestic\t500\t599\n");
        set_rate_card(&dir);

        let error = quote(&Parcel {
            weight_grams: 200,
            zone: "antarctica".to_string(),
        })
        .expect_err("unknown zone");

        assert_eq!(error, QuoteError::UnknownZone("antarctica".to_string()));
    }

    #[test]
    fn returns_overweight_with_largest_zone_limit() {
        let _guard = env_lock().lock().expect("env lock");
        let dir = write_rate_card(
            "domestic\t500\t599\n\
             domestic\t2000\t899\n",
        );
        set_rate_card(&dir);

        let error = quote(&Parcel {
            weight_grams: 2_001,
            zone: "domestic".to_string(),
        })
        .expect_err("overweight");

        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 2_001,
                limit: 2_000,
            }
        );
    }

    #[test]
    fn returns_rate_card_unavailable_when_env_missing() {
        let _guard = env_lock().lock().expect("env lock");
        env::remove_var(RATECARD_ENV);

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("missing env");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn returns_rate_card_unavailable_when_file_missing() {
        let _guard = env_lock().lock().expect("env lock");
        env::set_var(RATECARD_ENV, "/definitely/missing/rates.tsv");

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("missing file");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn reports_malformed_rate_card_with_original_line_number() {
        let _guard = env_lock().lock().expect("env lock");
        let dir = write_rate_card(
            "# comment\n\
             \n\
             domestic\t500\n",
        );
        set_rate_card(&dir);

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("malformed");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn reports_malformed_rate_card_when_number_does_not_parse() {
        let _guard = env_lock().lock().expect("env lock");
        let dir = write_rate_card("domestic\tfive_hundred\t599\n");
        set_rate_card(&dir);

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("malformed");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn diagnostic_record_contains_zone_weight_and_total() {
        let mut sink = Vec::new();
        let parcel = Parcel {
            weight_grams: 400,
            zone: "domestic".to_string(),
        };
        let quote = Quote {
            base_cents: 599,
            surcharge_cents: 0,
            total_cents: 599,
            band_max_grams: 500,
        };

        emit_quote_diagnostic_to(&mut sink, &parcel, &quote).expect("diagnostic");

        assert_eq!(
            String::from_utf8(sink).expect("utf8"),
            "ratecard.quote zone=domestic weight_grams=400 total_cents=599\n"
        );
    }
}
