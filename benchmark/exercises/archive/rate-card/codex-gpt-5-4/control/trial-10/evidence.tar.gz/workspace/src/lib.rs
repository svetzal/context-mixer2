use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {} exceeds limit {}", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct RateBand {
    band_max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let largest_band = bands.last().expect("zones are only inserted with at least one rate band");

    let band = bands.iter().find(|band| parcel.weight_grams <= band.band_max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest_band.band_max_grams,
        },
    )?;

    let mut surcharge_cents = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += (band.cents * 20 + 50) / 100;
    }

    let total_cents = band.cents + surcharge_cents;
    emit_diagnostic(parcel, total_cents);

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

fn load_rate_card() -> Result<HashMap<String, Vec<RateBand>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<RateBand>>, QuoteError> {
    let mut by_zone: HashMap<String, Vec<RateBand>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let zone = fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let band_max_grams =
            fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;

        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let band_max_grams = band_max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents =
            cents.parse().map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        by_zone.entry(zone.to_string()).or_default().push(RateBand {
            band_max_grams,
            cents,
        });
    }

    for bands in by_zone.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(by_zone)
}

fn emit_diagnostic(parcel: &Parcel, total_cents: u64) {
    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::{Path, PathBuf};
    use std::sync::atomic::{AtomicU64, Ordering};
    use std::sync::{Mutex, OnceLock};

    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    fn unique_ratecard_path() -> PathBuf {
        static COUNTER: AtomicU64 = AtomicU64::new(0);
        let suffix = COUNTER.fetch_add(1, Ordering::Relaxed);
        env::temp_dir().join(format!("ratecard-test-{}-{}.tsv", std::process::id(), suffix))
    }

    fn write_ratecard(contents: &str) -> PathBuf {
        let path = unique_ratecard_path();
        fs::write(&path, contents).expect("write rate card");
        path
    }

    fn set_ratecard_path(path: &Path) {
        env::set_var("RATECARD_PATH", path);
    }

    fn cleanup_ratecard(path: &Path) {
        let _ = fs::remove_file(path);
    }

    #[test]
    fn quotes_domestic_without_surcharge() {
        let _guard = env_lock().lock().expect("env lock");
        let ratecard = write_ratecard(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n\
             international\t500\t1499\n\
             international\t20000\t4999\n",
        );
        set_ratecard_path(&ratecard);

        let quote = quote(&Parcel {
            weight_grams: 450,
            zone: "domestic".to_string(),
        })
        .expect("quote");

        assert_eq!(
            quote,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );

        cleanup_ratecard(&ratecard);
    }

    #[test]
    fn quotes_international_with_half_up_percentage_and_weight_surcharge() {
        let _guard = env_lock().lock().expect("env lock");
        let ratecard = write_ratecard(
            "international\t20000\t1497\n\
             domestic\t20000\t1000\n",
        );
        set_ratecard_path(&ratecard);

        let quote = quote(&Parcel {
            weight_grams: 15_000,
            zone: "international".to_string(),
        })
        .expect("quote");

        assert_eq!(
            quote,
            Quote {
                base_cents: 1497,
                surcharge_cents: 799,
                total_cents: 2296,
                band_max_grams: 20000,
            }
        );

        cleanup_ratecard(&ratecard);
    }

    #[test]
    fn returns_unknown_zone_when_zone_missing() {
        let _guard = env_lock().lock().expect("env lock");
        let ratecard = write_ratecard("domestic\t500\t599\n");
        set_ratecard_path(&ratecard);

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "express".to_string(),
        })
        .expect_err("unknown zone");

        assert_eq!(error, QuoteError::UnknownZone("express".to_string()));
        cleanup_ratecard(&ratecard);
    }

    #[test]
    fn returns_overweight_with_zone_limit() {
        let _guard = env_lock().lock().expect("env lock");
        let ratecard = write_ratecard(
            "domestic\t2000\t899\n\
             domestic\t500\t599\n",
        );
        set_ratecard_path(&ratecard);

        let error = quote(&Parcel {
            weight_grams: 2001,
            zone: "domestic".to_string(),
        })
        .expect_err("overweight");

        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 2001,
                limit: 2000,
            }
        );
        cleanup_ratecard(&ratecard);
    }

    #[test]
    fn missing_env_var_is_rate_card_unavailable() {
        let _guard = env_lock().lock().expect("env lock");
        env::remove_var("RATECARD_PATH");

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("missing env");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn unreadable_file_is_rate_card_unavailable() {
        let _guard = env_lock().lock().expect("env lock");
        env::set_var("RATECARD_PATH", "/definitely/missing/ratecard.tsv");

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("missing file");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn malformed_rate_card_reports_actual_line_number_for_wrong_field_count() {
        let _guard = env_lock().lock().expect("env lock");
        let ratecard = write_ratecard(
            "# header\n\
             \n\
             domestic\t500\n",
        );
        set_ratecard_path(&ratecard);

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("malformed");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
        cleanup_ratecard(&ratecard);
    }

    #[test]
    fn malformed_rate_card_reports_actual_line_number_for_bad_number() {
        let _guard = env_lock().lock().expect("env lock");
        let ratecard = write_ratecard(
            "domestic\t500\t599\n\
             international\tbig\t1499\n",
        );
        set_ratecard_path(&ratecard);

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("malformed");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 2 });
        cleanup_ratecard(&ratecard);
    }
}
