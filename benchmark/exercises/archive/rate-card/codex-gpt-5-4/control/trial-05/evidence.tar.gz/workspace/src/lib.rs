pub mod zones;

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

const RATECARD_PATH_ENV: &str = "RATECARD_PATH";
const HEAVY_PARCEL_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_PARCEL_SURCHARGE_CENTS: u64 = 500;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct RateBand {
    band_max_grams: u32,
    cents: u64,
}

type RateCard = HashMap<String, Vec<RateBand>>;

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let limit = bands.last().map(|band| band.band_max_grams).unwrap_or(0);
    let band = bands.iter().find(|band| parcel.weight_grams <= band.band_max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        },
    )?;

    let surcharge_cents = heavy_parcel_surcharge(parcel.weight_grams)
        + international_surcharge(&parcel.zone, band.cents);
    let total_cents = band.cents + surcharge_cents;

    emit_quote_diagnostic(parcel, total_cents);

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = env::var(RATECARD_PATH_ENV).map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut rate_card: RateCard = HashMap::new();

    for (idx, line) in contents.lines().enumerate() {
        let line_number = idx + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let zone = fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let band_max_grams = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        rate_card.entry(zone.to_string()).or_default().push(RateBand {
            band_max_grams,
            cents,
        });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(rate_card)
}

fn heavy_parcel_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > HEAVY_PARCEL_THRESHOLD_GRAMS {
        HEAVY_PARCEL_SURCHARGE_CENTS
    } else {
        0
    }
}

fn international_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == "international" {
        (base_cents + 2) / 5
    } else {
        0
    }
}

fn emit_quote_diagnostic(parcel: &Parcel, total_cents: u64) {
    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::{Path, PathBuf};
    use std::sync::atomic::{AtomicU64, Ordering};
    use std::sync::{Mutex, MutexGuard};
    use std::time::{SystemTime, UNIX_EPOCH};

    static UNIQUE_ID: AtomicU64 = AtomicU64::new(0);
    static ENV_LOCK: Mutex<()> = Mutex::new(());

    #[test]
    fn quotes_domestic_band_without_surcharge() {
        let _guard = RateCardEnvGuard::new(sample_rate_card());
        let quote = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        })
        .unwrap();

        assert_eq!(
            quote,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn quotes_international_with_half_up_surcharge() {
        let _guard = RateCardEnvGuard::new(sample_rate_card());
        let quote = quote(&Parcel {
            weight_grams: 500,
            zone: "international".to_string(),
        })
        .unwrap();

        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn adds_both_surcharges_for_heavy_international_parcel() {
        let _guard = RateCardEnvGuard::new(sample_rate_card());
        let quote = quote(&Parcel {
            weight_grams: 15_000,
            zone: "international".to_string(),
        })
        .unwrap();

        assert_eq!(quote.base_cents, 4_999);
        assert_eq!(quote.surcharge_cents, 1_500);
        assert_eq!(quote.total_cents, 6_499);
        assert_eq!(quote.band_max_grams, 20_000);
    }

    #[test]
    fn unknown_zone_returns_requested_zone() {
        let _guard = RateCardEnvGuard::new(sample_rate_card());
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "express".to_string(),
        })
        .unwrap_err();

        assert_eq!(err, QuoteError::UnknownZone("express".to_string()));
    }

    #[test]
    fn overweight_returns_zone_limit() {
        let _guard = RateCardEnvGuard::new(sample_rate_card());
        let err = quote(&Parcel {
            weight_grams: 20_001,
            zone: "domestic".to_string(),
        })
        .unwrap_err();

        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            }
        );
    }

    #[test]
    fn missing_ratecard_path_is_unavailable() {
        let _guard = RateCardEnvGuard::unset();
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .unwrap_err();

        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn unreadable_ratecard_is_unavailable() {
        let _guard = RateCardEnvGuard::from_missing_path();
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .unwrap_err();

        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn malformed_line_reports_physical_line_number() {
        let _guard = RateCardEnvGuard::new(
            "# comment\n\ndomestic\t500\t599\ninternational\tbad\t1499\n".to_string(),
        );
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .unwrap_err();

        assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn malformed_line_reports_extra_fields() {
        let _guard = RateCardEnvGuard::new("domestic\t500\t599\textra\n".to_string());
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .unwrap_err();

        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn bands_are_applied_in_ascending_order() {
        let _guard = RateCardEnvGuard::new(
            "domestic\t2000\t899\ndomestic\t500\t599\ndomestic\t20000\t1799\n".to_string(),
        );
        let quote = quote(&Parcel {
            weight_grams: 450,
            zone: "domestic".to_string(),
        })
        .unwrap();

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn quote_error_implements_error() {
        fn assert_error<E: Error>() {}
        assert_error::<QuoteError>();
    }

    fn sample_rate_card() -> String {
        [
            "# zone\tband_max_grams\tcents",
            "domestic\t500\t599",
            "domestic\t2000\t899",
            "domestic\t20000\t1799",
            "international\t500\t1499",
            "international\t20000\t4999",
        ]
        .join("\n")
            + "\n"
    }

    struct RateCardEnvGuard {
        _lock: MutexGuard<'static, ()>,
        previous: Option<String>,
        temp_path: Option<PathBuf>,
    }

    impl RateCardEnvGuard {
        fn new(contents: String) -> Self {
            let lock = ENV_LOCK.lock().unwrap();
            let previous = env::var(RATECARD_PATH_ENV).ok();
            let temp_path = unique_temp_path("ratecard.tsv");
            fs::write(&temp_path, contents).unwrap();
            env::set_var(RATECARD_PATH_ENV, &temp_path);
            Self {
                _lock: lock,
                previous,
                temp_path: Some(temp_path),
            }
        }

        fn unset() -> Self {
            let lock = ENV_LOCK.lock().unwrap();
            let previous = env::var(RATECARD_PATH_ENV).ok();
            env::remove_var(RATECARD_PATH_ENV);
            Self {
                _lock: lock,
                previous,
                temp_path: None,
            }
        }

        fn from_missing_path() -> Self {
            let lock = ENV_LOCK.lock().unwrap();
            let previous = env::var(RATECARD_PATH_ENV).ok();
            let missing_path = unique_temp_path("missing-ratecard.tsv");
            env::set_var(RATECARD_PATH_ENV, &missing_path);
            Self {
                _lock: lock,
                previous,
                temp_path: None,
            }
        }
    }

    impl Drop for RateCardEnvGuard {
        fn drop(&mut self) {
            match &self.previous {
                Some(previous) => env::set_var(RATECARD_PATH_ENV, previous),
                None => env::remove_var(RATECARD_PATH_ENV),
            }

            if let Some(path) = &self.temp_path {
                let _ = fs::remove_file(path);
                if let Some(parent) = path.parent() {
                    let _ = fs::remove_dir(parent);
                }
            }
        }
    }

    fn unique_temp_path(file_name: &str) -> PathBuf {
        let millis = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis();
        let sequence = UNIQUE_ID.fetch_add(1, Ordering::Relaxed);
        let dir = env::temp_dir().join(format!("ratecard-test-{millis}-{sequence}"));
        fs::create_dir_all(&dir).unwrap();
        Path::new(&dir).join(file_name)
    }
}
