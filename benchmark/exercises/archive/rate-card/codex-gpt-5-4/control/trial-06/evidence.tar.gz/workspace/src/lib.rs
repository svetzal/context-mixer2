pub mod zones;

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

const RATECARD_PATH_ENV: &str = "RATECARD_PATH";
const INTERNATIONAL_ZONE: &str = "international";
const HEAVY_PARCEL_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_PARCEL_SURCHARGE_CENTS: u64 = 500;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => write!(f, "malformed rate card at line {line}"),
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    band_max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let ratecard = load_ratecard()?;
    let bands = ratecard
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band = bands
        .iter()
        .find(|band| parcel.weight_grams <= band.band_max_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: bands.last().map(|band| band.band_max_grams).unwrap_or(0),
        })?;

    let surcharge_cents = surcharge_cents(parcel, band.cents);
    let quote = Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.band_max_grams,
    };

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, quote.total_cents
    );

    Ok(quote)
}

fn load_ratecard() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var(RATECARD_PATH_ENV).map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_ratecard(&contents)
}

fn parse_ratecard(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut zones = HashMap::<String, Vec<Band>>::new();

    for (idx, line) in contents.lines().enumerate() {
        let line_number = idx + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let zone = fields
            .next()
            .filter(|value| !value.is_empty())
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let band_max_grams = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        zones.entry(zone.to_string()).or_default().push(Band {
            band_max_grams,
            cents,
        });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(zones)
}

fn surcharge_cents(parcel: &Parcel, base_cents: u64) -> u64 {
    let heavy_surcharge = if parcel.weight_grams > HEAVY_PARCEL_THRESHOLD_GRAMS {
        HEAVY_PARCEL_SURCHARGE_CENTS
    } else {
        0
    };

    let international_surcharge = if parcel.zone == INTERNATIONAL_ZONE {
        percent_round_half_up(base_cents, 20)
    } else {
        0
    };

    heavy_surcharge + international_surcharge
}

fn percent_round_half_up(amount: u64, percent: u64) -> u64 {
    let numerator = amount.saturating_mul(percent);
    (numerator + 50) / 100
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::path::{Path, PathBuf};
    use std::sync::{Mutex, OnceLock};
    use std::time::{SystemTime, UNIX_EPOCH};

    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    struct TestDir {
        path: PathBuf,
    }

    impl TestDir {
        fn path(&self) -> &Path {
            &self.path
        }
    }

    impl Drop for TestDir {
        fn drop(&mut self) {
            let _ = fs::remove_dir_all(&self.path);
        }
    }

    fn unique_temp_path() -> PathBuf {
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("time went backwards")
            .as_nanos();
        env::temp_dir().join(format!("ratecard-test-{nanos}-{}", std::process::id()))
    }

    fn write_ratecard(contents: &str) -> TestDir {
        let path = unique_temp_path();
        fs::create_dir_all(&path).expect("create tempdir");
        fs::write(path.join("rates.tsv"), contents).expect("write ratecard");
        TestDir { path }
    }

    fn with_ratecard<T>(contents: &str, test: impl FnOnce() -> T) -> T {
        let _guard = env_lock().lock().expect("lock env");
        let dir = write_ratecard(contents);
        env::set_var(RATECARD_PATH_ENV, dir.path().join("rates.tsv"));
        let result = test();
        env::remove_var(RATECARD_PATH_ENV);
        result
    }

    #[test]
    fn quotes_domestic_band_without_surcharge() {
        with_ratecard(
            "# zone\tband_max_grams\tcents\n\
             domestic\t2000\t899\n\
             domestic\t500\t599\n\
             international\t500\t1499\n",
            || {
                let quote = quote(&Parcel {
                    weight_grams: 450,
                    zone: "domestic".to_string(),
                })
                .expect("quote succeeds");

                assert_eq!(
                    quote,
                    Quote {
                        base_cents: 599,
                        surcharge_cents: 0,
                        total_cents: 599,
                        band_max_grams: 500,
                    }
                );
            },
        );
    }

    #[test]
    fn quotes_international_with_combined_surcharges() {
        with_ratecard(
            "international\t500\t1499\n\
             international\t20000\t4999\n",
            || {
                let quote = quote(&Parcel {
                    weight_grams: 15_000,
                    zone: "international".to_string(),
                })
                .expect("quote succeeds");

                assert_eq!(quote.base_cents, 4999);
                assert_eq!(quote.surcharge_cents, 1500);
                assert_eq!(quote.total_cents, 6499);
                assert_eq!(quote.band_max_grams, 20_000);
            },
        );
    }

    #[test]
    fn missing_ratecard_path_is_unavailable() {
        let _guard = env_lock().lock().expect("lock env");
        env::remove_var(RATECARD_PATH_ENV);

        assert_eq!(
            quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            }),
            Err(QuoteError::RateCardUnavailable)
        );
    }

    #[test]
    fn unknown_zone_returns_requested_zone() {
        with_ratecard("domestic\t500\t599\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 100,
                    zone: "express".to_string(),
                }),
                Err(QuoteError::UnknownZone("express".to_string()))
            );
        });
    }

    #[test]
    fn overweight_uses_largest_band_limit() {
        with_ratecard("domestic\t500\t599\ndomestic\t2000\t899\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 2001,
                    zone: "domestic".to_string(),
                }),
                Err(QuoteError::Overweight {
                    grams: 2001,
                    limit: 2000,
                })
            );
        });
    }

    #[test]
    fn malformed_ratecard_reports_original_line_number() {
        with_ratecard(
            "# comment\n\
            \n\
             domestic\t500\t599\n\
             international\tnope\t1499\n",
            || {
                assert_eq!(
                    quote(&Parcel {
                        weight_grams: 100,
                        zone: "domestic".to_string(),
                    }),
                    Err(QuoteError::MalformedRateCard { line: 4 })
                );
            },
        );
    }

    #[test]
    fn malformed_ratecard_rejects_wrong_field_count() {
        with_ratecard("domestic\t500\t599\textra\n", || {
            assert_eq!(
                quote(&Parcel {
                    weight_grams: 100,
                    zone: "domestic".to_string(),
                }),
                Err(QuoteError::MalformedRateCard { line: 1 })
            );
        });
    }
}
