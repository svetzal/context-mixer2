use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

const RATECARD_ENV: &str = "RATECARD_PATH";
const HEAVY_SURCHARGE_CENTS: u64 = 500;
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams} exceeds limit {limit}")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

type RateCard = HashMap<String, Vec<Band>>;

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|band| parcel.weight_grams <= band.max_grams)
        .copied()
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: bands.last().map(|band| band.max_grams).unwrap_or(0),
        })?;

    let surcharge_cents = heavy_surcharge(parcel.weight_grams)
        + international_surcharge(parcel.zone.as_str(), band.cents);
    let total_cents = band.cents + surcharge_cents;

    emit_quote_diagnostic(parcel, total_cents);

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = env::var(RATECARD_ENV).map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut by_zone: RateCard = HashMap::new();

    for (index, raw_line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let mut fields = raw_line.split('\t');
        let zone = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let max_grams = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        by_zone
            .entry(zone.to_string())
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in by_zone.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(by_zone)
}

fn heavy_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > HEAVY_THRESHOLD_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    }
}

fn international_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == "international" {
        (base_cents + 2) / 5
    } else {
        0
    }
}

fn emit_quote_diagnostic(parcel: &Parcel, total_cents: u64) {
    eprintln!(
        "ratecard_quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::path::{Path, PathBuf};
    use std::sync::atomic::{AtomicU64, Ordering};

    static NEXT_FILE_ID: AtomicU64 = AtomicU64::new(0);

    struct TempRatecard {
        path: PathBuf,
    }

    impl TempRatecard {
        fn new(contents: &str) -> Self {
            let path = std::env::temp_dir().join(format!(
                "ratecard-test-{}-{}.tsv",
                std::process::id(),
                NEXT_FILE_ID.fetch_add(1, Ordering::Relaxed)
            ));
            fs::write(&path, contents).expect("write rate card");
            Self { path }
        }

        fn path(&self) -> &Path {
            &self.path
        }
    }

    impl Drop for TempRatecard {
        fn drop(&mut self) {
            let _ = fs::remove_file(&self.path);
        }
    }

    fn with_ratecard(contents: &str) -> TempRatecard {
        TempRatecard::new(contents)
    }

    fn set_ratecard_env(path: &std::path::Path) {
        unsafe {
            env::set_var(RATECARD_ENV, path);
        }
    }

    fn clear_ratecard_env() {
        unsafe {
            env::remove_var(RATECARD_ENV);
        }
    }

    fn sample_ratecard() -> &'static str {
        "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n"
    }

    #[test]
    fn quotes_domestic_from_first_matching_band() {
        let file = with_ratecard(sample_ratecard());
        set_ratecard_env(file.path());

        let quote = quote(&Parcel {
            weight_grams: 501,
            zone: "domestic".to_string(),
        })
        .expect("quote");

        assert_eq!(
            quote,
            Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2000,
            }
        );
    }

    #[test]
    fn quotes_international_with_half_up_percentage_surcharge() {
        let file = with_ratecard(sample_ratecard());
        set_ratecard_env(file.path());

        let quote = quote(&Parcel {
            weight_grams: 500,
            zone: "international".to_string(),
        })
        .expect("quote");

        assert_eq!(
            quote,
            Quote {
                base_cents: 1499,
                surcharge_cents: 300,
                total_cents: 1799,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn adds_both_surcharges_when_applicable() {
        let file = with_ratecard(sample_ratecard());
        set_ratecard_env(file.path());

        let quote = quote(&Parcel {
            weight_grams: 10001,
            zone: "international".to_string(),
        })
        .expect("quote");

        assert_eq!(
            quote,
            Quote {
                base_cents: 4999,
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20000,
            }
        );
    }

    #[test]
    fn reports_unknown_zone() {
        let file = with_ratecard(sample_ratecard());
        set_ratecard_env(file.path());

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "express".to_string(),
        })
        .expect_err("unknown zone");

        assert_eq!(error, QuoteError::UnknownZone("express".to_string()));
    }

    #[test]
    fn reports_overweight_with_zone_limit() {
        let file = with_ratecard(sample_ratecard());
        set_ratecard_env(file.path());

        let error = quote(&Parcel {
            weight_grams: 20001,
            zone: "domestic".to_string(),
        })
        .expect_err("overweight");

        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 20001,
                limit: 20000,
            }
        );
    }

    #[test]
    fn missing_env_is_unavailable() {
        clear_ratecard_env();

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("missing env");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn unreadable_file_is_unavailable() {
        unsafe {
            env::set_var(RATECARD_ENV, "/definitely/missing/ratecard.tsv");
        }

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("missing file");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn malformed_line_reports_its_original_line_number() {
        let file = with_ratecard(
            "# comment\n\
\n\
domestic\t500\t599\n\
domestic\tbad\t899\n",
        );
        set_ratecard_env(file.path());

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("malformed");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn malformed_field_count_is_rejected() {
        let file = with_ratecard("domestic\t500\n");
        set_ratecard_env(file.path());

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("malformed");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn bands_are_applied_in_ascending_threshold_order() {
        let file = with_ratecard(
            "domestic\t20000\t1799\n\
domestic\t500\t599\n\
domestic\t2000\t899\n",
        );
        set_ratecard_env(file.path());

        let quote = quote(&Parcel {
            weight_grams: 450,
            zone: "domestic".to_string(),
        })
        .expect("quote");

        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.base_cents, 599);
    }
}
