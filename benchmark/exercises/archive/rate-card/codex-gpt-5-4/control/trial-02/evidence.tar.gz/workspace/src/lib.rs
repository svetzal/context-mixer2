use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {} exceeds limit {}", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    band_max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = read_rate_card()?;
    let bands = rate_card
        .iter()
        .find(|(zone, _)| zone == &parcel.zone)
        .map(|(_, bands)| bands)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|band| parcel.weight_grams <= band.band_max_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: bands.last().map(|band| band.band_max_grams).unwrap_or(0),
        })?;

    let mut surcharge_cents = 0_u64;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += (band.cents * 20 + 50) / 100;
    }

    let result = Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.band_max_grams,
    };

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, result.total_cents
    );

    Ok(result)
}

fn read_rate_card() -> Result<Vec<(String, Vec<Band>)>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<Vec<(String, Vec<Band>)>, QuoteError> {
    let mut zones: Vec<(String, Vec<Band>)> = Vec::new();

    for (idx, raw_line) in contents.lines().enumerate() {
        let line_number = idx + 1;
        let line = raw_line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let mut fields = raw_line.split('\t');
        let zone = fields
            .next()
            .filter(|value| !value.is_empty())
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let band_max_grams = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        match zones.iter_mut().find(|(existing_zone, _)| existing_zone == zone) {
            Some((_, bands)) => bands.push(Band {
                band_max_grams,
                cents,
            }),
            None => zones.push((
                zone.to_string(),
                vec![Band {
                    band_max_grams,
                    cents,
                }],
            )),
        }
    }

    for (_, bands) in &mut zones {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(zones)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::io;
    use std::path::Path;
    use std::sync::{Mutex, MutexGuard, OnceLock};
    use std::time::{SystemTime, UNIX_EPOCH};

    const SAMPLE_RATE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn quotes_domestic_using_first_matching_band() {
        let _guard = TestEnv::new(SAMPLE_RATE_CARD);

        let quote = super::quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        })
        .unwrap();

        assert_eq!(
            quote,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn adds_weight_and_international_surcharges() {
        let _guard = TestEnv::new(SAMPLE_RATE_CARD);

        let quote = super::quote(&Parcel {
            weight_grams: 12_000,
            zone: "international".to_string(),
        })
        .unwrap();

        assert_eq!(
            quote,
            Quote {
                base_cents: 4999,
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20000,
            }
        );
    }

    #[test]
    fn rounds_international_surcharge_half_up() {
        {
            let _guard = TestEnv::new("international\t500\t1\n");
            let quote = super::quote(&Parcel {
                weight_grams: 1,
                zone: "international".to_string(),
            })
            .unwrap();

            assert_eq!(quote.surcharge_cents, 0);
        }

        {
            let _guard = TestEnv::new("international\t500\t3\n");
            let quote = super::quote(&Parcel {
                weight_grams: 1,
                zone: "international".to_string(),
            })
            .unwrap();
            assert_eq!(quote.surcharge_cents, 1);
        }
    }

    #[test]
    fn returns_unknown_zone_when_zone_absent() {
        let _guard = TestEnv::new(SAMPLE_RATE_CARD);

        let error = super::quote(&Parcel {
            weight_grams: 100,
            zone: "express".to_string(),
        })
        .unwrap_err();

        assert_eq!(error, QuoteError::UnknownZone("express".to_string()));
    }

    #[test]
    fn returns_overweight_with_zone_limit() {
        let _guard = TestEnv::new(SAMPLE_RATE_CARD);

        let error = super::quote(&Parcel {
            weight_grams: 20_001,
            zone: "domestic".to_string(),
        })
        .unwrap_err();

        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            }
        );
    }

    #[test]
    fn returns_unavailable_when_env_var_missing() {
        let _guard = MissingEnvGuard::remove();

        let error = super::quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .unwrap_err();

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn returns_unavailable_when_file_is_unreadable() {
        let temp_dir = TempDir::new().unwrap();
        let path = temp_dir.path().join("missing.tsv");
        let _guard = EnvVarGuard::set(&path);

        let error = super::quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .unwrap_err();

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn rejects_non_tab_separated_lines() {
        let error = parse_rate_card("domestic,500,599\n").unwrap_err();
        assert_eq!(error, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn reports_line_numbers_including_comments_and_blanks() {
        let error = parse_rate_card("# comment\n\nbad\tnope\t100\n").unwrap_err();
        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn sorts_bands_before_matching() {
        let _guard = TestEnv::new("domestic\t2000\t899\ndomestic\t500\t599\n");

        let quote = super::quote(&Parcel {
            weight_grams: 400,
            zone: "domestic".to_string(),
        })
        .unwrap();

        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.base_cents, 599);
    }

    struct TestEnv {
        _dir: TempDir,
        _guard: EnvVarGuard,
    }

    impl TestEnv {
        fn new(contents: &str) -> Self {
            let dir = TempDir::new().unwrap();
            let path = dir.path().join("ratecard.tsv");
            fs::write(&path, contents).unwrap();
            Self {
                _dir: dir,
                _guard: EnvVarGuard::set(&path),
            }
        }
    }

    struct TempDir {
        path: std::path::PathBuf,
    }

    impl TempDir {
        fn new() -> io::Result<Self> {
            let unique = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos();
            let path = env::temp_dir().join(format!("ratecard-tests-{}", unique));
            fs::create_dir(&path)?;
            Ok(Self { path })
        }

        fn path(&self) -> &Path {
            &self.path
        }
    }

    impl Drop for TempDir {
        fn drop(&mut self) {
            let _ = fs::remove_dir_all(&self.path);
        }
    }

    struct EnvVarGuard {
        _lock: MutexGuard<'static, ()>,
        previous: Option<String>,
    }

    impl EnvVarGuard {
        fn set(path: &Path) -> Self {
            let lock = env_lock().lock().unwrap();
            let previous = env::var("RATECARD_PATH").ok();
            env::set_var("RATECARD_PATH", path);
            Self {
                _lock: lock,
                previous,
            }
        }
    }

    impl Drop for EnvVarGuard {
        fn drop(&mut self) {
            match &self.previous {
                Some(value) => env::set_var("RATECARD_PATH", value),
                None => env::remove_var("RATECARD_PATH"),
            }
        }
    }

    struct MissingEnvGuard {
        _lock: MutexGuard<'static, ()>,
        previous: Option<String>,
    }

    impl MissingEnvGuard {
        fn remove() -> Self {
            let lock = env_lock().lock().unwrap();
            let previous = env::var("RATECARD_PATH").ok();
            env::remove_var("RATECARD_PATH");
            Self {
                _lock: lock,
                previous,
            }
        }
    }

    impl Drop for MissingEnvGuard {
        fn drop(&mut self) {
            match &self.previous {
                Some(value) => env::set_var("RATECARD_PATH", value),
                None => env::remove_var("RATECARD_PATH"),
            }
        }
    }

    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }
}
