use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams} exceeds limit {limit}")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    band_max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let zone_bands = rate_card
        .iter()
        .filter(|(zone, _)| zone == &parcel.zone)
        .map(|(_, band)| *band)
        .collect::<Vec<_>>();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let largest_band = zone_bands
        .iter()
        .map(|band| band.band_max_grams)
        .max()
        .expect("zone_bands is not empty");

    let band = zone_bands
        .iter()
        .copied()
        .find(|band| parcel.weight_grams <= band.band_max_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest_band,
        })?;

    let mut surcharge_cents = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += (band.cents + 2) / 5;
    }

    let total_cents = band.cents + surcharge_cents;
    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

fn load_rate_card() -> Result<Vec<(String, Band)>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<Vec<(String, Band)>, QuoteError> {
    let mut entries = Vec::new();

    for (index, raw_line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let line = raw_line.trim();

        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let mut fields = raw_line.split('\t');
        let zone = fields.next();
        let band_max_grams = fields.next();
        let cents = fields.next();

        if zone.is_none() || band_max_grams.is_none() || cents.is_none() || fields.next().is_some()
        {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let band_max_grams = band_max_grams
            .expect("checked above")
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = cents
            .expect("checked above")
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        entries.push((
            zone.expect("checked above").to_string(),
            Band {
                band_max_grams,
                cents,
            },
        ));
    }

    entries.sort_by(|(zone_a, band_a), (zone_b, band_b)| {
        zone_a.cmp(zone_b).then(band_a.band_max_grams.cmp(&band_b.band_max_grams))
    });

    Ok(entries)
}

#[cfg(test)]
mod tests {
    use super::{quote, Parcel, Quote, QuoteError};
    use std::env;
    use std::fs;
    use std::path::{Path, PathBuf};
    use std::sync::{Mutex, OnceLock};
    use std::time::{SystemTime, UNIX_EPOCH};

    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    struct TempRateCard {
        path: PathBuf,
    }

    impl TempRateCard {
        fn path(&self) -> &Path {
            &self.path
        }
    }

    impl Drop for TempRateCard {
        fn drop(&mut self) {
            let _ = fs::remove_file(&self.path);
        }
    }

    fn write_rate_card(contents: &str) -> TempRateCard {
        let unique = SystemTime::now().duration_since(UNIX_EPOCH).expect("clock").as_nanos();
        let path = env::temp_dir().join(format!("ratecard-test-{unique}.tsv"));
        fs::write(&path, contents).expect("write rate card");
        TempRateCard { path }
    }

    #[test]
    fn quotes_domestic_band_without_surcharge() {
        let _guard = env_lock().lock().expect("env lock");
        let file = write_rate_card(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             international\t500\t1499\n",
        );
        env::set_var("RATECARD_PATH", file.path());

        let quoted = quote(&Parcel {
            weight_grams: 501,
            zone: "domestic".to_string(),
        })
        .expect("quote");

        assert_eq!(
            quoted,
            Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2000,
            }
        );
    }

    #[test]
    fn quotes_international_with_both_surcharges() {
        let _guard = env_lock().lock().expect("env lock");
        let file = write_rate_card(
            "international\t500\t1499\n\
             international\t20000\t4999\n",
        );
        env::set_var("RATECARD_PATH", file.path());

        let quoted = quote(&Parcel {
            weight_grams: 12_000,
            zone: "international".to_string(),
        })
        .expect("quote");

        assert_eq!(
            quoted,
            Quote {
                base_cents: 4999,
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20000,
            }
        );
    }

    #[test]
    fn rounds_international_surcharge_half_up() {
        let _guard = env_lock().lock().expect("env lock");
        let file = write_rate_card("international\t500\t3\n");
        env::set_var("RATECARD_PATH", file.path());

        let quoted = quote(&Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        })
        .expect("quote");

        assert_eq!(quoted.surcharge_cents, 1);
        assert_eq!(quoted.total_cents, 4);
    }

    #[test]
    fn rejects_unknown_zone() {
        let _guard = env_lock().lock().expect("env lock");
        let file = write_rate_card("domestic\t500\t599\n");
        env::set_var("RATECARD_PATH", file.path());

        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "express".to_string(),
        })
        .expect_err("unknown zone");

        assert_eq!(err, QuoteError::UnknownZone("express".to_string()));
    }

    #[test]
    fn rejects_overweight_parcel() {
        let _guard = env_lock().lock().expect("env lock");
        let file = write_rate_card("domestic\t500\t599\ndomestic\t2000\t899\n");
        env::set_var("RATECARD_PATH", file.path());

        let err = quote(&Parcel {
            weight_grams: 2001,
            zone: "domestic".to_string(),
        })
        .expect_err("overweight");

        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 2001,
                limit: 2000
            }
        );
    }

    #[test]
    fn reports_unavailable_rate_card_when_env_missing() {
        let _guard = env_lock().lock().expect("env lock");
        env::remove_var("RATECARD_PATH");

        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("missing env");

        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn reports_malformed_rate_card_line_numbers_for_bad_shape() {
        let _guard = env_lock().lock().expect("env lock");
        let file = write_rate_card(
            "# comment\n\
             \n\
             domestic\t500\n",
        );
        env::set_var("RATECARD_PATH", file.path());

        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("malformed");

        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn reports_malformed_rate_card_line_numbers_for_bad_numbers() {
        let _guard = env_lock().lock().expect("env lock");
        let file = write_rate_card("domestic\tfive-hundred\t599\n");
        env::set_var("RATECARD_PATH", file.path());

        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("malformed");

        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }
}
