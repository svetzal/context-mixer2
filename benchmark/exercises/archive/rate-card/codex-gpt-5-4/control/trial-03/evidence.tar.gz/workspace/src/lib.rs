pub mod zones;

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

const RATECARD_PATH_ENV: &str = "RATECARD_PATH";
const HEAVY_SURCHARGE_GRAMS: u32 = 10_000;
const HEAVY_SURCHARGE_CENTS: u64 = 500;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct RateBand {
    band_max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let largest_limit = bands.last().map(|band| band.band_max_grams).unwrap_or(0);
    let band = bands.iter().find(|band| parcel.weight_grams <= band.band_max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest_limit,
        },
    )?;

    let base_cents = band.cents;
    let surcharge_cents =
        heavy_surcharge(parcel.weight_grams) + zone_surcharge(&parcel.zone, base_cents);
    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

fn load_rate_card() -> Result<HashMap<String, Vec<RateBand>>, QuoteError> {
    let path = env::var(RATECARD_PATH_ENV).map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<RateBand>>, QuoteError> {
    let mut rate_card: HashMap<String, Vec<RateBand>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let zone = fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let band_max_grams = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        rate_card.entry(zone.to_string()).or_default().push(RateBand {
            band_max_grams,
            cents,
        });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(rate_card)
}

fn heavy_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > HEAVY_SURCHARGE_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    }
}

fn zone_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == "international" {
        (base_cents + 2) / 5
    } else {
        0
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::path::{Path, PathBuf};
    use std::sync::{Mutex, MutexGuard, OnceLock};
    use std::time::{SystemTime, UNIX_EPOCH};

    struct TestDir {
        path: PathBuf,
    }

    impl TestDir {
        fn new() -> Self {
            let unique = SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .expect("clock before epoch")
                .as_nanos();
            let path = env::temp_dir().join(format!("ratecard-tests-{unique}"));
            fs::create_dir_all(&path).expect("create temp dir");
            Self { path }
        }

        fn path(&self) -> &Path {
            &self.path
        }
    }

    impl Drop for TestDir {
        fn drop(&mut self) {
            let _ = fs::remove_dir_all(&self.path);
        }
    }

    fn test_guard() -> MutexGuard<'static, ()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(())).lock().expect("test lock poisoned")
    }

    fn with_ratecard(contents: &str) -> TestDir {
        let dir = TestDir::new();
        let path = dir.path().join("ratecard.tsv");
        fs::write(&path, contents).expect("write ratecard");
        // SAFETY: tests in this crate control RATECARD_PATH and do not spawn threads.
        unsafe { env::set_var(RATECARD_PATH_ENV, &path) };
        dir
    }

    #[test]
    fn quotes_domestic_without_surcharge() {
        let _guard = test_guard();
        let _dir = with_ratecard(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n\
             domestic\t20000\t1799\n\
             international\t500\t1499\n\
             international\t20000\t4999\n",
        );

        let quote = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".to_string(),
        })
        .expect("quote");

        assert_eq!(
            quote,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn quotes_international_with_combined_surcharges() {
        let _guard = test_guard();
        let _dir = with_ratecard(
            "international\t500\t1499\n\
             international\t20000\t4999\n",
        );

        let quote = quote(&Parcel {
            weight_grams: 15_000,
            zone: "international".to_string(),
        })
        .expect("quote");

        assert_eq!(quote.base_cents, 4_999);
        assert_eq!(quote.band_max_grams, 20_000);
        assert_eq!(quote.surcharge_cents, 1_500);
        assert_eq!(quote.total_cents, 6_499);
    }

    #[test]
    fn rounds_international_surcharge_half_up() {
        let _guard = test_guard();
        let _dir = with_ratecard("international\t500\t3\n");

        let quote = quote(&Parcel {
            weight_grams: 1,
            zone: "international".to_string(),
        })
        .expect("quote");

        assert_eq!(quote.surcharge_cents, 1);
        assert_eq!(quote.total_cents, 4);
    }

    #[test]
    fn reports_unknown_zone() {
        let _guard = test_guard();
        let _dir = with_ratecard("domestic\t500\t599\n");

        let err = quote(&Parcel {
            weight_grams: 10,
            zone: "overnight".to_string(),
        })
        .expect_err("unknown zone");

        assert_eq!(err, QuoteError::UnknownZone("overnight".to_string()));
    }

    #[test]
    fn reports_overweight_with_largest_band() {
        let _guard = test_guard();
        let _dir = with_ratecard("domestic\t500\t599\n\ndomestic\t2000\t899\n");

        let err = quote(&Parcel {
            weight_grams: 2_001,
            zone: "domestic".to_string(),
        })
        .expect_err("overweight");

        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 2_001,
                limit: 2_000
            }
        );
    }

    #[test]
    fn reports_unavailable_when_env_missing() {
        let _guard = test_guard();
        // SAFETY: tests in this crate control RATECARD_PATH and do not spawn threads.
        unsafe { env::remove_var(RATECARD_PATH_ENV) };

        let err = quote(&Parcel {
            weight_grams: 10,
            zone: "domestic".to_string(),
        })
        .expect_err("missing env");

        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn reports_unavailable_when_file_missing() {
        let _guard = test_guard();
        let dir = TestDir::new();
        let path = dir.path().join("missing.tsv");
        // SAFETY: tests in this crate control RATECARD_PATH and do not spawn threads.
        unsafe { env::set_var(RATECARD_PATH_ENV, &path) };

        let err = quote(&Parcel {
            weight_grams: 10,
            zone: "domestic".to_string(),
        })
        .expect_err("missing file");

        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn reports_malformed_rate_card_line_numbers_for_bad_shape() {
        let _guard = test_guard();
        let _dir = with_ratecard(
            "# comment\n\
             \n\
             domestic\t500\n",
        );

        let err = quote(&Parcel {
            weight_grams: 10,
            zone: "domestic".to_string(),
        })
        .expect_err("malformed");

        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn reports_malformed_rate_card_line_numbers_for_bad_number() {
        let _guard = test_guard();
        let _dir = with_ratecard(
            "# comment\n\
             domestic\tfive-hundred\t599\n",
        );

        let err = quote(&Parcel {
            weight_grams: 10,
            zone: "domestic".to_string(),
        })
        .expect_err("malformed");

        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }
}
