use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

const RATECARD_ENV: &str = "RATECARD_PATH";
const HEAVY_SURCHARGE_CENTS: u64 = 500;
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => write!(f, "malformed rate card at line {line}"),
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams} exceeds limit {limit}")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    band_max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .iter()
        .filter_map(|entry| (entry.zone == parcel.zone).then_some(entry.band));

    let mut matched = None;
    let mut largest_band = None;

    for band in bands {
        largest_band = Some(band.band_max_grams);
        if parcel.weight_grams <= band.band_max_grams {
            matched = Some(band);
            break;
        }
    }

    let matched = match (matched, largest_band) {
        (Some(band), _) => band,
        (None, Some(limit)) => {
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
        (None, None) => return Err(QuoteError::UnknownZone(parcel.zone.clone())),
    };

    let surcharge_cents = surcharge_cents(parcel, matched.cents);
    let total_cents = matched.cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents: matched.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: matched.band_max_grams,
    })
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct RateCardEntry {
    zone: String,
    band: Band,
}

fn load_rate_card() -> Result<Vec<RateCardEntry>, QuoteError> {
    let path = env::var(RATECARD_ENV).map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<Vec<RateCardEntry>, QuoteError> {
    let mut entries = Vec::new();

    for (index, raw_line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let line = raw_line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let mut fields = raw_line.split('\t');
        let zone = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let band_max_grams = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?;

        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let band_max_grams = band_max_grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = cents
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        entries.push(RateCardEntry {
            zone: zone.to_string(),
            band: Band {
                band_max_grams,
                cents,
            },
        });
    }

    entries.sort_by(|left, right| {
        left.zone
            .cmp(&right.zone)
            .then(left.band.band_max_grams.cmp(&right.band.band_max_grams))
    });

    Ok(entries)
}

fn surcharge_cents(parcel: &Parcel, base_cents: u64) -> u64 {
    let mut surcharge = 0;

    if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        surcharge += HEAVY_SURCHARGE_CENTS;
    }

    if parcel.zone == "international" {
        surcharge += (base_cents + 2) / 5;
    }

    surcharge
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::{Path, PathBuf};
    use std::sync::{Mutex, OnceLock};
    use std::time::{SystemTime, UNIX_EPOCH};

    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    struct TempRateCard {
        path: PathBuf,
    }

    impl TempRateCard {
        fn path(&self) -> &Path {
            &self.path
        }
    }

    impl Drop for TempRateCard {
        fn drop(&mut self) {
            let _ = fs::remove_file(&self.path);
        }
    }

    fn write_rate_card(contents: &str) -> TempRateCard {
        let mut path = env::temp_dir();
        let unique = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock")
            .as_nanos();
        path.push(format!("ratecard-test-{}-{unique}.tsv", std::process::id()));
        fs::write(&path, contents).expect("write rate card");
        TempRateCard { path }
    }

    fn with_rate_card<T>(contents: &str, f: impl FnOnce() -> T) -> T {
        let _guard = env_lock().lock().expect("env lock");
        let file = write_rate_card(contents);
        env::set_var(RATECARD_ENV, file.path());
        let result = f();
        env::remove_var(RATECARD_ENV);
        result
    }

    fn sample_rate_card() -> &'static str {
        "# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
"
    }

    #[test]
    fn quotes_domestic_band_without_surcharge() {
        let quote = with_rate_card(sample_rate_card(), || {
            quote(&Parcel {
                weight_grams: 500,
                zone: "domestic".to_string(),
            })
        })
        .expect("quote");

        assert_eq!(
            quote,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn adds_both_international_and_heavy_surcharges() {
        let quote = with_rate_card(sample_rate_card(), || {
            quote(&Parcel {
                weight_grams: 15_000,
                zone: "international".to_string(),
            })
        })
        .expect("quote");

        assert_eq!(quote.base_cents, 4_999);
        assert_eq!(quote.surcharge_cents, 1_500);
        assert_eq!(quote.total_cents, 6_499);
        assert_eq!(quote.band_max_grams, 20_000);
    }

    #[test]
    fn rounds_international_surcharge_half_up() {
        let quote = with_rate_card("international\t500\t3\n", || {
            quote(&Parcel {
                weight_grams: 10,
                zone: "international".to_string(),
            })
        })
        .expect("quote");

        assert_eq!(quote.surcharge_cents, 1);
        assert_eq!(quote.total_cents, 4);
    }

    #[test]
    fn returns_unknown_zone_when_zone_missing() {
        let error = with_rate_card(sample_rate_card(), || {
            quote(&Parcel {
                weight_grams: 100,
                zone: "express".to_string(),
            })
        })
        .expect_err("unknown zone");

        assert_eq!(error, QuoteError::UnknownZone("express".to_string()));
    }

    #[test]
    fn returns_overweight_when_above_largest_band() {
        let error = with_rate_card(sample_rate_card(), || {
            quote(&Parcel {
                weight_grams: 20_001,
                zone: "domestic".to_string(),
            })
        })
        .expect_err("overweight");

        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            }
        );
    }

    #[test]
    fn missing_environment_variable_is_unavailable() {
        let _guard = env_lock().lock().expect("env lock");
        env::remove_var(RATECARD_ENV);

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("missing env");

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn unreadable_rate_card_is_unavailable() {
        let _guard = env_lock().lock().expect("env lock");
        env::set_var(RATECARD_ENV, "/definitely/missing/ratecard.tsv");

        let error = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("missing file");

        env::remove_var(RATECARD_ENV);
        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn malformed_rate_card_reports_1_based_line_numbers() {
        let error = with_rate_card(
            "# comment\n\n\
domestic\t500\t599\n\
domestic\tbad\t899\n",
            || {
                quote(&Parcel {
                    weight_grams: 100,
                    zone: "domestic".to_string(),
                })
            },
        )
        .expect_err("malformed line");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn malformed_rate_card_reports_wrong_field_count() {
        let error = with_rate_card("domestic\t500\n", || {
            quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".to_string(),
            })
        })
        .expect_err("malformed field count");

        assert_eq!(error, QuoteError::MalformedRateCard { line: 1 });
    }
}
