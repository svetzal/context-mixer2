pub mod zones;

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;
use std::path::PathBuf;

const RATECARD_PATH_ENV: &str = "RATECARD_PATH";
const HEAVY_PARCEL_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_PARCEL_SURCHARGE_CENTS: u64 = 500;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => {
                write!(f, "rate card unavailable")
            }
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {} exceeds zone limit {}", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    band_max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let rate_card = load_rate_card()?;
    let bands = rate_card
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band = bands
        .iter()
        .find(|band| parcel.weight_grams <= band.band_max_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: bands.last().map(|band| band.band_max_grams).unwrap_or(0),
        })?;

    let base_cents = band.cents;
    let surcharge_cents = heavy_parcel_surcharge(parcel.weight_grams)
        + international_surcharge(parcel.zone.as_str(), base_cents);
    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "ratecard.quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var_os(RATECARD_PATH_ENV)
        .filter(|value| !value.is_empty())
        .map(PathBuf::from)
        .ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut rate_card: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let zone = fields.next().ok_or(QuoteError::MalformedRateCard { line: line_number })?;
        let band_max_grams = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields
            .next()
            .ok_or(QuoteError::MalformedRateCard { line: line_number })?
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        rate_card.entry(zone.to_string()).or_default().push(Band {
            band_max_grams,
            cents,
        });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.band_max_grams);
    }

    Ok(rate_card)
}

fn heavy_parcel_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > HEAVY_PARCEL_THRESHOLD_GRAMS {
        HEAVY_PARCEL_SURCHARGE_CENTS
    } else {
        0
    }
}

fn international_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == "international" {
        (base_cents + 2) / 5
    } else {
        0
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::{Path, PathBuf};
    use std::sync::{Mutex, MutexGuard, OnceLock};
    use std::time::{SystemTime, UNIX_EPOCH};

    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    fn lock_env() -> MutexGuard<'static, ()> {
        match env_lock().lock() {
            Ok(guard) => guard,
            Err(poisoned) => poisoned.into_inner(),
        }
    }

    struct TestRateCard {
        path: PathBuf,
    }

    impl TestRateCard {
        fn path(&self) -> &Path {
            &self.path
        }
    }

    impl Drop for TestRateCard {
        fn drop(&mut self) {
            let _ = fs::remove_file(&self.path);
        }
    }

    fn write_rate_card(contents: &str) -> TestRateCard {
        let unique = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock should be after epoch")
            .as_nanos();
        let path = env::temp_dir().join(format!("ratecard-test-{}.tsv", unique));
        fs::write(&path, contents).expect("write rate card");
        TestRateCard { path }
    }

    #[test]
    fn quotes_domestic_band_without_surcharge() {
        let _guard = lock_env();
        let file = write_rate_card(
            "# zone\tband_max_grams\tcents\n\
             domestic\t500\t599\n\
             domestic\t2000\t899\n",
        );
        env::set_var(RATECARD_PATH_ENV, file.path());

        let result = quote(&Parcel {
            weight_grams: 450,
            zone: "domestic".to_string(),
        })
        .expect("quote should succeed");

        assert_eq!(
            result,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn quotes_international_with_both_surcharges() {
        let _guard = lock_env();
        let file = write_rate_card(
            "international\t500\t1499\n\
             international\t20000\t4999\n",
        );
        env::set_var(RATECARD_PATH_ENV, file.path());

        let result = quote(&Parcel {
            weight_grams: 15_000,
            zone: "international".to_string(),
        })
        .expect("quote should succeed");

        assert_eq!(
            result,
            Quote {
                base_cents: 4999,
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20_000,
            }
        );
    }

    #[test]
    fn sorts_bands_before_matching() {
        let _guard = lock_env();
        let file = write_rate_card(
            "domestic\t2000\t899\n\
             domestic\t500\t599\n\
             domestic\t20000\t1799\n",
        );
        env::set_var(RATECARD_PATH_ENV, file.path());

        let result = quote(&Parcel {
            weight_grams: 499,
            zone: "domestic".to_string(),
        })
        .expect("quote should succeed");

        assert_eq!(result.band_max_grams, 500);
        assert_eq!(result.base_cents, 599);
    }

    #[test]
    fn reports_unknown_zone() {
        let _guard = lock_env();
        let file = write_rate_card("domestic\t500\t599\n");
        env::set_var(RATECARD_PATH_ENV, file.path());

        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "express".to_string(),
        })
        .expect_err("quote should fail");

        assert_eq!(err, QuoteError::UnknownZone("express".to_string()));
    }

    #[test]
    fn reports_overweight_with_zone_limit() {
        let _guard = lock_env();
        let file = write_rate_card("domestic\t500\t599\ndomestic\t2000\t899\n");
        env::set_var(RATECARD_PATH_ENV, file.path());

        let err = quote(&Parcel {
            weight_grams: 2500,
            zone: "domestic".to_string(),
        })
        .expect_err("quote should fail");

        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 2500,
                limit: 2000,
            }
        );
    }

    #[test]
    fn missing_ratecard_path_is_unavailable() {
        let _guard = lock_env();
        env::remove_var(RATECARD_PATH_ENV);

        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("quote should fail");

        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn unreadable_ratecard_path_is_unavailable() {
        let _guard = lock_env();
        env::set_var(RATECARD_PATH_ENV, "/definitely/missing/ratecard.tsv");

        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("quote should fail");

        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn malformed_line_reports_physical_line_number() {
        let _guard = lock_env();
        let file = write_rate_card(
            "# header\n\
             \n\
             domestic\t500\t599\n\
             bad-line\n",
        );
        env::set_var(RATECARD_PATH_ENV, file.path());

        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("quote should fail");

        assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn malformed_number_reports_line_number() {
        let _guard = lock_env();
        let file = write_rate_card("domestic\tfive-hundred\t599\n");
        env::set_var(RATECARD_PATH_ENV, file.path());

        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
        .expect_err("quote should fail");

        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }
}
