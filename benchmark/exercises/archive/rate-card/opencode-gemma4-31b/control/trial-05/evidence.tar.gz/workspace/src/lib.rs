pub mod zones;

use std::fmt;
use std::error::Error;
use std::env;
use std::fs::File;
use std::io::{BufRead, BufReader};

#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => write!(f, "Overweight: {}g, limit {}g", grams, limit),
        }
    }
}

impl Error for QuoteError {}

struct RateBand {
    max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let file = File::open(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);

    let mut bands_for_zone: Vec<RateBand> = Vec::new();
    let mut zone_exists = false;

    for (index, line_result) in reader.lines().enumerate() {
        let line_num = index + 1;
        let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
        
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0];
        let max_grams = parts[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = parts[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        if zone == parcel.zone {
            zone_exists = true;
            bands_for_zone.push(RateBand { max_grams, cents });
        }
    }

    if !zone_exists {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    bands_for_zone.sort_by_key(|b| b.max_grams);

    let band = bands_for_zone.iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = bands_for_zone.iter().map(|b| b.max_grams).max().unwrap_or(0);
            QuoteError::Overweight { grams: parcel.weight_grams, limit }
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let int_surcharge = (base_cents as f64 * 0.2).round() as u64;
        surcharge_cents += int_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    println!("zone={},weight={},total={}", parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    #[test]
    fn test_domestic_quote() {
        let _lock = ENV_LOCK.lock().unwrap();
        let content = "domestic\t500\t599\ndomestic\t2000\t899";
        let file = NamedTempFile::new().unwrap();
        fs::write(file.path(), content).unwrap();
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_international_quote() {
        let _lock = ENV_LOCK.lock().unwrap();
        let content = "international\t500\t1499";
        let file = NamedTempFile::new().unwrap();
        fs::write(file.path(), content).unwrap();
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 400, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300); // 1499 * 0.2 = 299.8 -> 300
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn test_overweight_surcharge() {
        let _lock = ENV_LOCK.lock().unwrap();
        let content = "domestic\t20000\t1799";
        let file = NamedTempFile::new().unwrap();
        fs::write(file.path(), content).unwrap();
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 11000, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn test_international_overweight() {
        let _lock = ENV_LOCK.lock().unwrap();
        let content = "international\t20000\t4999";
        let file = NamedTempFile::new().unwrap();
        fs::write(file.path(), content).unwrap();
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 11000, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();
        // base: 4999
        // surcharge: 500 (weight) + 1000 (4999 * 0.2 = 999.8 -> 1000) = 1500
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn test_unknown_zone() {
        let _lock = ENV_LOCK.lock().unwrap();
        let content = "domestic\t500\t599";
        let file = NamedTempFile::new().unwrap();
        fs::write(file.path(), content).unwrap();
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 400, zone: "mars".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::UnknownZone("mars".to_string()));
    }

    #[test]
    fn test_overweight_error() {
        let _lock = ENV_LOCK.lock().unwrap();
        let content = "domestic\t500\t599";
        let file = NamedTempFile::new().unwrap();
        fs::write(file.path(), content).unwrap();
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::Overweight { grams: 600, limit: 500 });
    }

    #[test]
    fn test_malformed_ratecard() {
        let _lock = ENV_LOCK.lock().unwrap();
        let content = "domestic\t500\t599\ninvalid line\ndomestic\t2000\t899";
        let file = NamedTempFile::new().unwrap();
        fs::write(file.path(), content).unwrap();
        env::set_var("RATECARD_PATH", file.path());

        let parcel = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn test_ratecard_unavailable() {
        let _lock = ENV_LOCK.lock().unwrap();
        env::set_var("RATECARD_PATH", "/tmp/non_existent_file_12345");

        let parcel = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::RateCardUnavailable);
    }
}
