pub mod zones;

use std::env;
use std::fs;
use std::error::Error;
use std::fmt;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => write!(f, "Overweight: {}g, limit {}g", grams, limit),
        }
    }
}

impl Error for QuoteError {}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut zone_bands: Vec<(u32, u64)> = Vec::new();
    let mut zone_found = false;

    for (i, line) in content.lines().enumerate() {
        let line_num = i + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = fields[0];
        let max_grams = fields[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = fields[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        if zone == parcel.zone {
            zone_found = true;
            zone_bands.push((max_grams, cents));
        }
    }

    if !zone_found {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.0);

    let (band_max_grams, base_cents) = zone_bands
        .iter()
        .find(|&&(max, _)| max >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = zone_bands.last().map(|b| b.0).unwrap_or(0);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let mut surcharge_cents = 0u64;
    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += (*base_cents as f64 * 0.2).round() as u64;
    }

    let total_cents = base_cents + surcharge_cents;
    
    println!("zone={}, weight={}, total={}", parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents: *base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: *band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn setup_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        write!(file, "{}", content).unwrap();
        file
    }

    #[test]
    fn test_domestic_small() {
        let _lock = ENV_LOCK.lock().unwrap();
        let file = setup_ratecard("domestic\t500\t599\ndomestic\t2000\t899");
        env::set_var("RATECARD_PATH", file.path());

        let p = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_medium() {
        let _lock = ENV_LOCK.lock().unwrap();
        let file = setup_ratecard("domestic\t500\t599\ndomestic\t2000\t899");
        env::set_var("RATECARD_PATH", file.path());

        let p = Parcel { weight_grams: 1200, zone: "domestic".to_string() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn test_international_small() {
        let _lock = ENV_LOCK.lock().unwrap();
        let file = setup_ratecard("international\t500\t1499");
        env::set_var("RATECARD_PATH", file.path());

        let p = Parcel { weight_grams: 400, zone: "international".to_string() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 1499);
        // 1499 * 0.2 = 299.8 -> rounded to 300
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn test_overweight_surcharge() {
        let _lock = ENV_LOCK.lock().unwrap();
        let file = setup_ratecard("domestic\t20000\t1799");
        env::set_var("RATECARD_PATH", file.path());

        let p = Parcel { weight_grams: 10001, zone: "domestic".to_string() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn test_international_overweight_surcharge() {
        let _lock = ENV_LOCK.lock().unwrap();
        let file = setup_ratecard("international\t20000\t4999");
        env::set_var("RATECARD_PATH", file.path());

        let p = Parcel { weight_grams: 10001, zone: "international".to_string() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 4999);
        // 4999 * 0.2 = 999.8 -> 1000
        // 1000 + 500 = 1500
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn test_unknown_zone() {
        let _lock = ENV_LOCK.lock().unwrap();
        let file = setup_ratecard("domestic\t500\t599");
        env::set_var("RATECARD_PATH", file.path());

        let p = Parcel { weight_grams: 100, zone: "mars".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::UnknownZone("mars".to_string()));
    }

    #[test]
    fn test_overweight_error() {
        let _lock = ENV_LOCK.lock().unwrap();
        let file = setup_ratecard("domestic\t500\t599");
        env::set_var("RATECARD_PATH", file.path());

        let p = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::Overweight { grams: 600, limit: 500 });
    }

    #[test]
    fn test_ratecard_unavailable() {
        let _lock = ENV_LOCK.lock().unwrap();
        env::set_var("RATECARD_PATH", "/tmp/nonexistent_ratecard_12345");

        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::RateCardUnavailable);
    }

    #[test]
    fn test_malformed_ratecard_fields() {
        let _lock = ENV_LOCK.lock().unwrap();
        let file = setup_ratecard("domestic\t500"); // missing cents
        env::set_var("RATECARD_PATH", file.path());

        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn test_malformed_ratecard_parse() {
        let _lock = ENV_LOCK.lock().unwrap();
        let file = setup_ratecard("domestic\t500\tabc"); // invalid cents
        env::set_var("RATECARD_PATH", file.path());

        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn test_malformed_ratecard_line_numbering() {
        let _lock = ENV_LOCK.lock().unwrap();
        let file_bad = setup_ratecard("# comment\n\nwrong\tline\n");
        env::set_var("RATECARD_PATH", file_bad.path());

        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 3 });
    }
}
