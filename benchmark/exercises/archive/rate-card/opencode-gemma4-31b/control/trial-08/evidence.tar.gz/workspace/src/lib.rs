pub mod zones;

use std::env;
use std::fs::File;
use std::io::{BufRead, BufReader};
use std::fmt;
use std::collections::HashMap;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, PartialEq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => write!(f, "Overweight: {}g (limit {}g)", grams, limit),
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Clone)]
struct Band {
    max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let file = File::open(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);

    let mut zones_rates: HashMap<String, Vec<Band>> = HashMap::new();

    for (idx, line_result) in reader.lines().enumerate() {
        let line_num = idx + 1;
        let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
        
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = fields[0].to_string();
        let max_grams = fields[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = fields[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        zones_rates.entry(zone).or_default().push(Band { max_grams, cents });
    }

    let bands = zones_rates.get(&parcel.zone).ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    
    let mut sorted_bands = bands.clone();
    sorted_bands.sort_by_key(|b| b.max_grams);
    
    let band = sorted_bands.iter().find(|b| b.max_grams >= parcel.weight_grams).ok_or_else(|| {
        let limit = sorted_bands.last().map(|b| b.max_grams).unwrap_or(0);
        QuoteError::Overweight { grams: parcel.weight_grams, limit }
    })?;

    let base_cents = band.cents;
    let band_max_grams = band.max_grams;

    let mut surcharge_cents = 0u64;
    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    println!("zone={},weight_grams={},total_cents={}", parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn setup_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        writeln!(file, "{}", content).unwrap();
        file
    }

    #[test]
    fn test_quote_domestic_small() {
        let file = setup_ratecard("domestic\t500\t599\ndomestic\t2000\t899");
        env::set_var("RATECARD_PATH", file.path());
        
        let parcel = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_quote_domestic_medium() {
        let file = setup_ratecard("domestic\t500\t599\ndomestic\t2000\t899");
        env::set_var("RATECARD_PATH", file.path());
        
        let parcel = Parcel { weight_grams: 1200, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_quote_international_small() {
        let file = setup_ratecard("international\t500\t1499");
        env::set_var("RATECARD_PATH", file.path());
        
        let parcel = Parcel { weight_grams: 400, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();
        
        assert_eq!(quote.base_cents, 1499);
        // 1499 * 0.2 = 299.8 -> 300
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_quote_heavy_surcharge() {
        let file = setup_ratecard("domestic\t20000\t1799");
        env::set_var("RATECARD_PATH", file.path());
        
        let parcel = Parcel { weight_grams: 12000, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn test_quote_international_heavy_surcharge() {
        let file = setup_ratecard("international\t20000\t4999");
        env::set_var("RATECARD_PATH", file.path());
        
        let parcel = Parcel { weight_grams: 12000, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();
        
        assert_eq!(quote.base_cents, 4999);
        // 4999 * 0.2 = 999.8 -> 1000
        // 1000 + 500 = 1500
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn test_quote_unknown_zone() {
        let file = setup_ratecard("domestic\t500\t599");
        env::set_var("RATECARD_PATH", file.path());
        
        let parcel = Parcel { weight_grams: 400, zone: "mars".to_string() };
        let result = quote(&parcel);
        
        assert_eq!(result.unwrap_err(), QuoteError::UnknownZone("mars".to_string()));
    }

    #[test]
    fn test_quote_overweight() {
        let file = setup_ratecard("domestic\t500\t599");
        env::set_var("RATECARD_PATH", file.path());
        
        let parcel = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        let result = quote(&parcel);
        
        assert_eq!(result.unwrap_err(), QuoteError::Overweight { grams: 600, limit: 500 });
    }

    #[test]
    fn test_quote_malformed_line_fields() {
        let file = setup_ratecard("domestic\t500");
        env::set_var("RATECARD_PATH", file.path());
        
        let parcel = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let result = quote(&parcel);
        
        assert_eq!(result.unwrap_err(), QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn test_quote_malformed_number() {
        let file = setup_ratecard("domestic\tfivehundred\t599");
        env::set_var("RATECARD_PATH", file.path());
        
        let parcel = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let result = quote(&parcel);
        
        assert_eq!(result.unwrap_err(), QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn test_quote_malformed_line_counting() {
        let content = "# comment\n\n\n domestic\t500\t599\ndomestic\tinvalid\t899";
        let file = setup_ratecard(content);
        env::set_var("RATECARD_PATH", file.path());
        
        let parcel = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        // The 5th line is "domestic\tinvalid\t899"
        let result = quote(&parcel);
        
        assert_eq!(result.unwrap_err(), QuoteError::MalformedRateCard { line: 5 });
    }

    #[test]
    fn test_quote_unavailable() {
        env::set_var("RATECARD_PATH", "/non/existent/path");
        
        let parcel = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let result = quote(&parcel);
        
        assert_eq!(result.unwrap_err(), QuoteError::RateCardUnavailable);
    }
}

