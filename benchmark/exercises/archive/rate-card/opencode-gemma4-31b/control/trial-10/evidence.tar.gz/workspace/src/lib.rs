pub mod zones;

use std::env;
use std::fmt;
use std::error::Error;
use std::fs::File;
use std::io::{BufRead, BufReader};
use std::path::Path;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, PartialEq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => write!(f, "Overweight: {}g exceeds limit of {}g", grams, limit),
        }
    }
}

impl Error for QuoteError {}

struct RateBand {
    zone: String,
    max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path_str = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let path = Path::new(&path_str);
    let file = File::open(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);

    let mut bands = Vec::new();
    for (index, line_result) in reader.lines().enumerate() {
        let line_num = index + 1;
        let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
        let trimmed = line.trim_end();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = trimmed.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = fields[0].to_string();
        let max_grams = fields[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = fields[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        bands.push(RateBand { zone, max_grams, cents });
    }

    let mut zone_bands: Vec<&RateBand> = bands.iter()
        .filter(|b| b.zone == parcel.zone)
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.max_grams);

    let matching_band = zone_bands.iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: zone_bands.last().unwrap().max_grams,
        })?;

    let base_cents = matching_band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up
        // rounded half-up: (base_cents * 20 + 50) / 100
        // No, it's 20% = base_cents / 5.
        // For rounding half-up to cent: (base_cents * 20 + 50) / 100
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    // Diagnostic record: zone, weight, total
    println!("zone={},weight_grams={},total_cents={}", parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: matching_band.max_grams,

    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;
    use std::sync::Mutex;

    static LOCK: Mutex<()> = Mutex::new(());

    fn setup_ratecard(content: &str) -> (NamedTempFile, std::sync::MutexGuard<'static, ()>) {
        let lock = LOCK.lock().unwrap();
        let mut file = NamedTempFile::new().unwrap();
        write!(file, "{}", content).unwrap();
        let path = file.path().to_str().unwrap().to_string();
        env::set_var("RATECARD_PATH", &path);
        (file, lock)
    }

    #[test]
    fn test_domestic_quote() {
        let (_file, _lock) = setup_ratecard("domestic\t500\t599\ndomestic\t2000\t899\n");
        let parcel = Parcel { weight_grams: 200, zone: "domestic".to_string() };
        let q1 = quote(&parcel).unwrap();
        assert_eq!(q1.base_cents, 599);
        assert_eq!(q1.total_cents, 599);
        assert_eq!(q1.band_max_grams, 500);

        let parcel2 = Parcel { weight_grams: 1000, zone: "domestic".to_string() };
        let q2 = quote(&parcel2).unwrap();
        assert_eq!(q2.base_cents, 899);
        assert_eq!(q2.total_cents, 899);
        assert_eq!(q2.band_max_grams, 2000);
    }

    #[test]
    fn test_international_quote_and_surcharge() {
        let (_file, _lock) = setup_ratecard("international\t500\t1499\n");
        let parcel = Parcel { weight_grams: 200, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();
        // base: 1499; surcharge: 1499 * 0.2 = 299.8 -> 300
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn test_weight_surcharge() {
        let (_file, _lock) = setup_ratecard("domestic\t20000\t1799\n");
        let parcel = Parcel { weight_grams: 10001, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn test_combined_surcharges() {
        let (_file, _lock) = setup_ratecard("international\t20000\t4999\n");
        let parcel = Parcel { weight_grams: 10001, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();
        // base: 4999
        // weight surcharge: 500
        // int surcharge: 4999 * 0.2 = 999.8 -> 1000
        // total surcharge: 1500
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn test_unknown_zone() {
        let (_file, _lock) = setup_ratecard("domestic\t500\t599\n");
        let parcel = Parcel { weight_grams: 200, zone: "mars".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::UnknownZone("mars".to_string()));
    }

    #[test]
    fn test_overweight() {
        let (_file, _lock) = setup_ratecard("domestic\t500\t599\n");
        let parcel = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::Overweight { grams: 600, limit: 500 });
    }

    #[test]
    fn test_rate_card_unavailable() {
        let _lock = LOCK.lock().unwrap();
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel { weight_grams: 200, zone: "domestic".to_string() };
        assert_eq!(quote(&parcel).unwrap_err(), QuoteError::RateCardUnavailable);

        env::set_var("RATECARD_PATH", "/non/existent/path");
        assert_eq!(quote(&parcel).unwrap_err(), QuoteError::RateCardUnavailable);
    }

    #[test]
    fn test_malformed_rate_card() {
        // Line 1: Comment, Line 2: Empty, Line 3: Malformed (2 fields), Line 4: Malformed (non-numeric)
        let content = "# comment\n\nzone\t500\nzone\tabc\t599\n";
        let (_file, _lock) = setup_ratecard(content);
        let parcel = Parcel { weight_grams: 200, zone: "zone".to_string() };
        
        // The current implementation returns the FIRST malformed line it encounters.
        // Line 3 is "zone\t500" -> 2 fields -> Error
        assert_eq!(quote(&parcel).unwrap_err(), QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn test_malformed_rate_card_numeric() {
        let content = "domestic\tabc\t599\n";
        let (_file, _lock) = setup_ratecard(content);
        let parcel = Parcel { weight_grams: 200, zone: "domestic".to_string() };
        assert_eq!(quote(&parcel).unwrap_err(), QuoteError::MalformedRateCard { line: 1 });
    }
}


