pub mod zones;

use std::error::Error;
use std::fmt;
use std::fs::File;
use std::io::{BufRead, BufReader};
use std::env;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, PartialEq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => write!(f, "Overweight: {}g exceeds limit of {}g", grams, limit),
        }
    }
}

impl Error for QuoteError {}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let file = File::open(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);

    let mut bands = Vec::new();
    for (index, line_result) in reader.lines().enumerate() {
        let line_number = index + 1;
        let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
        
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = fields[0].to_string();
        let max_grams = fields[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        bands.push((zone, max_grams, cents));
    }

    let mut zone_bands: Vec<(u32, u64)> = bands.iter()
        .filter(|(z, _, _)| z == &parcel.zone)
        .map(|(_, m, c)| (*m, *c))
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|(m, _)| *m);

    let matching_band = zone_bands.iter()
        .find(|(m, _)| *m >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = zone_bands.last().unwrap().0;
            QuoteError::Overweight { grams: parcel.weight_grams, limit }
        })?;

    let (band_max_grams, base_cents) = *matching_band;
    
    let mut surcharge_cents = 0u64;
    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    println!("diagnostic: zone={}, weight={}, total={}", parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn setup_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        write!(file, "{}", content).unwrap();
        let path = file.path().to_str().unwrap().to_string();
        env::set_var("RATECARD_PATH", &path);
        file
    }

    #[test]
    fn test_quote_domestic_small() {
        let _file = setup_ratecard("domestic\t500\t599\ndomestic\t2000\t899");
        let parcel = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_quote_domestic_large_with_surcharge() {
        let _file = setup_ratecard("domestic\t20000\t1799");
        let parcel = Parcel { weight_grams: 11000, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn test_quote_international_small_with_surcharge() {
        let _file = setup_ratecard("international\t500\t1499");
        let parcel = Parcel { weight_grams: 400, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();
        // 1499 * 0.2 = 299.8 -> 300
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn test_quote_international_large_both_surcharges() {
        let _file = setup_ratecard("international\t20000\t4999");
        let parcel = Parcel { weight_grams: 11000, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();
        // base: 4999
        // weight > 10kg: 500
        // international: 4999 * 0.2 = 999.8 -> 1000
        // total surcharge: 1500
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn test_half_up_rounding() {
        let content = "international\t100\t100\n\
                       international\t200\t105\n\
                       international\t300\t102\n\
                       international\t400\t103";
        let _file = setup_ratecard(content);

        // Case: 100 cents * 0.2 = 20 (exact)
        let p1 = Parcel { weight_grams: 50, zone: "international".to_string() };
        assert_eq!(quote(&p1).unwrap().surcharge_cents, 20);

        // Case: 105 cents * 0.2 = 21.0 (exact)
        let p2 = Parcel { weight_grams: 150, zone: "international".to_string() };
        assert_eq!(quote(&p2).unwrap().surcharge_cents, 21);

        // Case: 102 cents * 0.2 = 20.4 -> 20
        let p3 = Parcel { weight_grams: 250, zone: "international".to_string() };
        assert_eq!(quote(&p3).unwrap().surcharge_cents, 20);

        // Case: 103 cents * 0.2 = 20.6 -> 21
        let p4 = Parcel { weight_grams: 350, zone: "international".to_string() };
        assert_eq!(quote(&p4).unwrap().surcharge_cents, 21);
    }

    #[test]
    fn test_error_ratecard_unavailable() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        assert_eq!(quote(&parcel), Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn test_error_malformed_line_cols() {
        let _file = setup_ratecard("domestic\t500");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        assert_eq!(quote(&parcel), Err(QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn test_error_malformed_number() {
        let _file = setup_ratecard("domestic\t500\tabc");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        assert_eq!(quote(&parcel), Err(QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn test_error_unknown_zone() {
        let _file = setup_ratecard("domestic\t500\t599");
        let parcel = Parcel { weight_grams: 100, zone: "mars".to_string() };
        assert_eq!(quote(&parcel), Err(QuoteError::UnknownZone("mars".to_string())));
    }

    #[test]
    fn test_error_overweight() {
        let _file = setup_ratecard("domestic\t500\t599");
        let parcel = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        assert_eq!(quote(&parcel), Err(QuoteError::Overweight { grams: 600, limit: 500 }));
    }
}
