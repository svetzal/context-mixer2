pub mod zones;

use std::env;
use std::fmt;
use std::fs::File;
use std::io::{BufRead, BufReader};
use std::error::Error;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => write!(f, "Overweight: {}g exceeds limit of {}g", grams, limit),
        }
    }
}

impl Error for QuoteError {}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let file = File::open(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);

    let mut bands = Vec::new();
    for (index, line_result) in reader.lines().enumerate() {
        let line_num = index + 1;
        let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
        
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = fields[0].to_string();
        let band_max_grams = fields[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = fields[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        bands.push((zone, band_max_grams, cents));
    }

    let mut all_zones = std::collections::HashSet::new();
    for (zone, _, _) in &bands {
        all_zones.insert(zone);
    }

    if !all_zones.contains(&parcel.zone) {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let mut zone_bands: Vec<(u32, u64)> = bands
        .into_iter()
        .filter(|(zone, _, _)| zone == &parcel.zone)
        .map(|(_, max, cents)| (max, cents))
        .collect();

    zone_bands.sort_by_key(|(max, _)| *max);

    let matching_band = zone_bands
        .iter()
        .find(|(max, _)| *max >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = zone_bands.last().unwrap().0;
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = matching_band.1;
    let band_max_grams = matching_band.0;

    let mut surcharge_cents = 0u64;
    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    println!("zone={}, weight={}, total={}", parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn setup_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        writeln!(file, "{}", content).unwrap();
        env::set_var("RATECARD_PATH", file.path());
        file
    }

    #[test]
    fn test_quote_domestic_small() {
        let _file = setup_ratecard("# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_quote_domestic_large() {
        let _file = setup_ratecard("# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899");
        let parcel = Parcel { weight_grams: 1500, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_quote_international_surcharge() {
        let _file = setup_ratecard("international\t500\t1499");
        let parcel = Parcel { weight_grams: 100, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();
        // 1499 * 0.2 = 299.8 -> 300
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn test_quote_overweight_surcharge() {
        let _file = setup_ratecard("domestic\t20000\t1799");
        let parcel = Parcel { weight_grams: 11000, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn test_quote_overweight_error() {
        let _file = setup_ratecard("domestic\t500\t599");
        let parcel = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        let result = quote(&parcel);
        assert_eq!(result.unwrap_err(), QuoteError::Overweight { grams: 600, limit: 500 });
    }

    #[test]
    fn test_quote_unknown_zone() {
        let _file = setup_ratecard("domestic\t500\t599");
        let parcel = Parcel { weight_grams: 100, zone: "mars".to_string() };
        let result = quote(&parcel);
        assert_eq!(result.unwrap_err(), QuoteError::UnknownZone("mars".to_string()));
    }

    #[test]
    fn test_quote_malformed_line() {
        let _file = setup_ratecard("domestic\t500\t599\ndomestic\tbad\t899");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let result = quote(&parcel);
        assert_eq!(result.unwrap_err(), QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn test_quote_malformed_tabs() {
        let _file = setup_ratecard("domestic,500,599");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let result = quote(&parcel);
        assert_eq!(result.unwrap_err(), QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn test_quote_unavailable() {
        env::set_var("RATECARD_PATH", "/non/existent/path");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let result = quote(&parcel);
        assert_eq!(result.unwrap_err(), QuoteError::RateCardUnavailable);
    }
}
