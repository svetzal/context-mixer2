pub mod zones;
use std::env;
use std::fmt;
use std::fs::File;
use std::io::{BufRead, BufReader};
use std::path::Path;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => write!(f, "Overweight: {}g exceeds limit {}g", grams, limit),
        }
    }
}

impl std::error::Error for QuoteError {}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path_str = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let path = Path::new(&path_str);
    let file = File::open(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);

    let mut zone_bands: Vec<(u32, u64)> = Vec::new();
    let mut zone_exists = false;

    for (index, line_result) in reader.lines().enumerate() {
        let line_num = index + 1;
        let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = fields[0];
        let band_max = fields[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = fields[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        if zone == parcel.zone {
            zone_bands.push((band_max, cents));
            zone_exists = true;
        } else if zone != "" {
            // Just to track if other zones exist, but we only care if the requested one does.
            // Actually, the requested zone being absent means it's not in the file at all.
        }
    }

    if !zone_exists {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.0);

    let matching_band = zone_bands
        .iter()
        .find(|&&(max, _)| max >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = zone_bands.last().map(|b| b.0).unwrap_or(0);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = matching_band.1;
    let band_max_grams = matching_band.0;

    let mut surcharge_cents = 0;
    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += (base_cents * 2 + 5) / 10;
    }

    let total_cents = base_cents + surcharge_cents;

    println!("zone={}, weight={}, total={}", parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn setup_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        write!(file, "{}", content).unwrap();
        let path = file.path().to_str().unwrap().to_string();
        env::set_var("RATECARD_PATH", path);
        file
    }

    #[test]
    fn test_domestic_quote() {
        let _file = setup_ratecard("domestic\t500\t599\ndomestic\t2000\t899");
        let parcel = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_international_quote() {
        let _file = setup_ratecard("international\t500\t1499");
        let parcel = Parcel { weight_grams: 400, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();
        // base: 1499, surcharge: 1499 * 0.2 = 299.8 -> 300
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn test_overweight() {
        let _file = setup_ratecard("domestic\t500\t599");
        let parcel = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::Overweight { grams: 600, limit: 500 });
    }

    #[test]
    fn test_unknown_zone() {
        let _file = setup_ratecard("domestic\t500\t599");
        let parcel = Parcel { weight_grams: 100, zone: "international".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::UnknownZone("international".to_string()));
    }

    #[test]
    fn test_heavy_weight_surcharge() {
        let _file = setup_ratecard("domestic\t20000\t1799");
        let parcel = Parcel { weight_grams: 10001, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 1799 + 500);
    }

    #[test]
    fn test_international_heavy_weight() {
        let _file = setup_ratecard("international\t20000\t4999");
        let parcel = Parcel { weight_grams: 10001, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();
        // base: 4999, surcharge: 4999 * 0.2 = 999.8 -> 1000, plus heavy: 500 = 1500
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 4999 + 1500);
    }

    #[test]
    fn test_malformed_ratecard_fields() {
        let _file = setup_ratecard("domestic\t500");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn test_malformed_ratecard_parsing() {
        let _file = setup_ratecard("domestic\t500\tabc");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn test_malformed_ratecard_line_counting() {
        let _file = setup_ratecard("# comment\n\ninvalid\tline");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn test_unavailable_ratecard_path() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::RateCardUnavailable);
    }

    #[test]
    fn test_unavailable_ratecard_file() {
        env::set_var("RATECARD_PATH", "/non/existent/path");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::RateCardUnavailable);
    }

    #[test]
    fn test_rounding_half_up() {
        // 20% of 603 is 120.6 -> 121
        let _file = setup_ratecard("international\t1000\t603");
        let parcel = Parcel { weight_grams: 100, zone: "international".to_string() };
        let quote_res = quote(&parcel).unwrap();
        assert_eq!(quote_res.surcharge_cents, 121);

        // 20% of 602 is 120.4 -> 120
        let _file2 = setup_ratecard("international\t1000\t602");
        let parcel2 = Parcel { weight_grams: 100, zone: "international".to_string() };
        let quote_res2 = quote(&parcel2).unwrap();
        assert_eq!(quote_res2.surcharge_cents, 120);
    }
}
