#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "Overweight: {}g exceeds limit of {}g", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

struct Band {
    max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = std::fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut zone_bands: Vec<Band> = Vec::new();
    let mut zone_found = false;

    for (i, line) in content.lines().enumerate() {
        let line_num = i + 1;
        let trimmed = line.trim_end();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = trimmed.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = fields[0];
        let max_grams = fields[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = fields[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        if zone == parcel.zone {
            zone_found = true;
            zone_bands.push(Band { max_grams, cents });
        }
    }

    if !zone_found {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.max_grams);

    let band = zone_bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = zone_bands.iter().map(|b| b.max_grams).max().unwrap_or(0);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    println!("zone={}, weight={}, total={}", parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn setup_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        write!(file, "{}", content).unwrap();
        std::env::set_var("RATECARD_PATH", file.path());
        file
    }

    #[test]
    fn test_all_quotes() {
        let _lock = ENV_LOCK.lock().unwrap();

        {
            let _file = setup_ratecard(
                "# zone\tband_max_grams\tcents\n\
                 domestic\t500\t599\n\
                 domestic\t2000\t899\n\
                 domestic\t20000\t1799\n",
            );
            let p = Parcel { weight_grams: 400, zone: "domestic".to_string() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.total_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        }

        {
            let _file = setup_ratecard(
                "# zone\tband_max_grams\tcents\n\
                 domestic\t20000\t1799\n",
            );
            let p = Parcel { weight_grams: 11000, zone: "domestic".to_string() };
            let q = quote(&p).unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
        }

        {
            let _file = setup_ratecard(
                "# zone\tband_max_grams\tcents\n\
                 international\t500\t1499\n",
            );
            let p = Parcel { weight_grams: 400, zone: "international".to_string() };
            let q = quote(&p).unwrap();
            // 1499 * 0.2 = 299.8 -> 300
            assert_eq!(q.base_cents, 1499);
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        }

        {
            let _file = setup_ratecard("domestic\t500\t599\n");
            let p = Parcel { weight_grams: 100, zone: "mars".to_string() };
            let res = quote(&p);
            assert_eq!(res.unwrap_err(), QuoteError::UnknownZone("mars".to_string()));
        }

        {
            let _file = setup_ratecard("domestic\t500\t599\n");
            let p = Parcel { weight_grams: 600, zone: "domestic".to_string() };
            let res = quote(&p);
            assert_eq!(res.unwrap_err(), QuoteError::Overweight { grams: 600, limit: 500 });
        }

        {
            let _file = setup_ratecard("domestic\t500\t599\nmalformed_line_without_tabs\n");
            let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
            let res = quote(&p);
            assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 2 });
        }

        {
            std::env::remove_var("RATECARD_PATH");
            let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
            let res = quote(&p);
            assert_eq!(res.unwrap_err(), QuoteError::RateCardUnavailable);
        }
    }
}

