pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "Rate card unavailable"),
            Self::MalformedRateCard { line } => write!(f, "Malformed rate card at line {line}"),
            Self::UnknownZone(zone) => write!(f, "Unknown zone: {zone}"),
            Self::Overweight { grams, limit } => write!(f, "Weight {grams}g exceeds limit {limit}g"),
        }
    }
}

impl std::error::Error for QuoteError {}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = std::fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut zone_bands = Vec::new();
    for (i, line) in content.lines().enumerate() {
        let line_num = i + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = fields[0].to_string();
        let max_grams = fields[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = fields[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        zone_bands.push((zone, max_grams, cents));
    }

    let mut matches: Vec<_> = zone_bands
        .into_iter()
        .filter(|(z, _, _)| z == &parcel.zone)
        .collect();

    if matches.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    matches.sort_by_key(|(_, max, _)| *max);

    let (zone, band_max_grams, base_cents) = matches
        .iter()
        .find(|(_, max, _)| *max >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = matches.last().unwrap().1;
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let mut surcharge_cents = 0;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if zone == "international" {
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    println!("zone={},weight={},total={}", parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents: *base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: *band_max_grams,
    })
}


#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn setup_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        write!(file, "{}", content).unwrap();
        std::env::set_var("RATECARD_PATH", file.path());
        file
    }

    #[test]
    fn test_quote_domestic_small() {
        let _file = setup_ratecard("domestic\t500\t599\ndomestic\t2000\t899\n");
        let parcel = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_quote_domestic_medium() {
        let _file = setup_ratecard("domestic\t500\t599\ndomestic\t2000\t899\n");
        let parcel = Parcel { weight_grams: 1500, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_quote_international_small() {
        let _file = setup_ratecard("international\t500\t1499\n");
        let parcel = Parcel { weight_grams: 400, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();
        // 1499 * 0.2 = 299.8 -> 300
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn test_quote_overweight_surcharge() {
        let _file = setup_ratecard("domestic\t20000\t1799\n");
        let parcel = Parcel { weight_grams: 11000, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 1799 + 500);
    }

    #[test]
    fn test_quote_international_overweight() {
        let _file = setup_ratecard("international\t20000\t4999\n");
        let parcel = Parcel { weight_grams: 11000, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();
        // base: 4999
        // international: 4999 * 0.2 = 999.8 -> 1000
        // overweight: 500
        // total surcharge: 1500
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 4999 + 1500);
    }

    #[test]
    fn test_quote_unknown_zone() {
        let _file = setup_ratecard("domestic\t500\t599\n");
        let parcel = Parcel { weight_grams: 400, zone: "mars".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::UnknownZone("mars".to_string()));
    }

    #[test]
    fn test_quote_overweight_error() {
        let _file = setup_ratecard("domestic\t500\t599\n");
        let parcel = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::Overweight { grams: 600, limit: 500 });
    }

    #[test]
    fn test_quote_malformed_ratecard() {
        let _file = setup_ratecard("# header\n\ndomestic\t500\t599\ndomestic\tinvalid\t899\n");
        let parcel = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn test_quote_malformed_tabs() {
        let _file = setup_ratecard("domestic 500 599\n");
        let parcel = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn test_quote_ratecard_unavailable() {
        std::env::set_var("RATECARD_PATH", "/non/existent/path");
        let parcel = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::RateCardUnavailable);
    }
}


