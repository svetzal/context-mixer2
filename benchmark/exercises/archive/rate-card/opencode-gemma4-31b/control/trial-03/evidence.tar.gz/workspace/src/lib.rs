pub mod zones;

use std::collections::HashMap;
use std::error::Error;
use std::fmt;
use std::fs::File;
use std::io::{self, BufRead, BufReader};
use std::env;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => write!(f, "Overweight: {}g exceeds limit of {}g", grams, limit),
        }
    }
}

impl Error for QuoteError {}

#[derive(Clone)]
struct RateBand {
    max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let file = File::open(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);

    let mut zone_rates: HashMap<String, Vec<RateBand>> = HashMap::new();

    for (index, line_result) in reader.lines().enumerate() {
        let line_num = index + 1;
        let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
        
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = parts[0].to_string();
        let max_grams = parts[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = parts[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        zone_rates.entry(zone).or_default().push(RateBand { max_grams, cents });
    }

    let mut bands = zone_rates.get(&parcel.zone).ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?.clone();
    
    // Bands for a zone apply in ascending band_max_grams.
    bands.sort_by_key(|b| b.max_grams);

    let matching_band = bands.iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = bands.last().map(|b| b.max_grams).unwrap_or(0);
            QuoteError::Overweight { grams: parcel.weight_grams, limit }
        })?;

    let base_cents = matching_band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up to the cent
        // Rounded half-up: (base_cents * 0.2).round()
        // Integer arithmetic for rounded half-up: (base_cents * 20 + 50) / 100
        // No, that's not quite right for 20%. 20% is base * 20 / 100.
        // For rounded half-up: (base_cents * 20 + 50) / 100 is correct.
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    // Observability: emit a diagnostic record per call
    println!("zone={}, weight={}, total={}", parcel.zone, parcel.weight_grams, total_cents);

// ... existing code ...
    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: matching_band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;
    use std::sync::Mutex;
    use lazy_static::lazy_static;

    lazy_static! {
        static ref ENV_LOCK: Mutex<()> = Mutex::new(());
    }

    fn setup_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        writeln!(file, "{}", content).unwrap();
        file
    }

    #[test]
    fn test_domestic_quotes() {
        let _lock = ENV_LOCK.lock().unwrap();
        let file = setup_ratecard("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799");
        env::set_var("RATECARD_PATH", file.path());

        let q = quote(&Parcel { weight_grams: 100, zone: "domestic".to_string() }).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);

        let q = quote(&Parcel { weight_grams: 1000, zone: "domestic".to_string() }).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.total_cents, 899);
        assert_eq!(q.band_max_grams, 2000);

        let q = quote(&Parcel { weight_grams: 15000, zone: "domestic".to_string() }).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn test_international_quotes() {
        let _lock = ENV_LOCK.lock().unwrap();
        let file = setup_ratecard("international\t500\t1499\ninternational\t20000\t4999");
        env::set_var("RATECARD_PATH", file.path());

        let q = quote(&Parcel { weight_grams: 100, zone: "international".to_string() }).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);

        let q = quote(&Parcel { weight_grams: 15000, zone: "international".to_string() }).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn test_unknown_zone() {
        let _lock = ENV_LOCK.lock().unwrap();
        let file = setup_ratecard("domestic\t500\t599");
        env::set_var("RATECARD_PATH", file.path());

        let res = quote(&Parcel { weight_grams: 100, zone: "mars".to_string() });
        assert_eq!(res.unwrap_err(), QuoteError::UnknownZone("mars".to_string()));
    }

    #[test]
    fn test_overweight() {
        let _lock = ENV_LOCK.lock().unwrap();
        let file = setup_ratecard("domestic\t500\t599");
        env::set_var("RATECARD_PATH", file.path());

        let res = quote(&Parcel { weight_grams: 600, zone: "domestic".to_string() });
        assert_eq!(res.unwrap_err(), QuoteError::Overweight { grams: 600, limit: 500 });
    }

    #[test]
    fn test_ratecard_unavailable() {
        let _lock = ENV_LOCK.lock().unwrap();
        env::remove_var("RATECARD_PATH");
        let res = quote(&Parcel { weight_grams: 100, zone: "domestic".to_string() });
        assert_eq!(res.unwrap_err(), QuoteError::RateCardUnavailable);

        env::set_var("RATECARD_PATH", "/tmp/non_existent_ratecard_12345");
        let res = quote(&Parcel { weight_grams: 100, zone: "domestic".to_string() });
        assert_eq!(res.unwrap_err(), QuoteError::RateCardUnavailable);
    }

    #[test]
    fn test_malformed_ratecard() {
        let _lock = ENV_LOCK.lock().unwrap();
        
        let file1 = setup_ratecard("# header\ndomestic\t500");
        env::set_var("RATECARD_PATH", file1.path());
        let res = quote(&Parcel { weight_grams: 100, zone: "domestic".to_string() });
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 2 });

        let file2 = setup_ratecard("# header\n\ndomestic\tabc\t599");
        env::set_var("RATECARD_PATH", file2.path());
        let res = quote(&Parcel { weight_grams: 100, zone: "domestic".to_string() });
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn test_comments_and_blanks() {
        let _lock = ENV_LOCK.lock().unwrap();
        let file = setup_ratecard("# comment\n\ndomestic\t500\t599\n\n# another\ndomestic\t1000\t899");
        env::set_var("RATECARD_PATH", file.path());

        let q = quote(&Parcel { weight_grams: 600, zone: "domestic".to_string() }).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 1000);
    }
}
