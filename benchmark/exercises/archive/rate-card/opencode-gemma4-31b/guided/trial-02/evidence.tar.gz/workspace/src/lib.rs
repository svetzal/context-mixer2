pub mod zones;

use std::env;
use std::error::Error;
use std::fmt;
use std::fs::File;
use std::io::{BufRead, BufReader};
use tracing::info;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => write!(f, "malformed rate card at line {line}"),
            Self::UnknownZone(zone) => write!(f, "unknown zone {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel overweight: {grams}g exceeds limit of {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let file = File::open(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);

    let mut zone_bands: Vec<Band> = Vec::new();
    let mut zone_found = false;

    for (index, line_result) in reader.lines().enumerate() {
        let line_num = index + 1;
        let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
        let trimmed = line.trim_end();

        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = trimmed.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = fields[0];
        if zone == parcel.zone {
            zone_found = true;
            let max_grams = fields[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
            let cents = fields[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
            zone_bands.push(Band { max_grams, cents });
        }
    }

    if !zone_found {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.max_grams);

    let band = zone_bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = zone_bands.last().map(|b| b.max_grams).unwrap_or(0);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up
        // (base_cents * 20 + 50) / 100
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    info!(
        zone = %parcel.zone,
        weight = parcel.weight_grams,
        total = total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn setup_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        writeln!(file, "{}", content).unwrap();
        env::set_var("RATECARD_PATH", file.path());
        file
    }

    #[test]
    fn test_domestic_small() {
        let _f = setup_ratecard("# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899");
        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_medium() {
        let _f = setup_ratecard("# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899");
        let p = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.total_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn test_domestic_overweight() {
        let _f = setup_ratecard("# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899");
        let p = Parcel { weight_grams: 3000, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::Overweight { grams: 3000, limit: 2000 });
    }

    #[test]
    fn test_international_small() {
        let _f = setup_ratecard("# zone\tband_max_grams\tcents\ninternational\t500\t1499");
        let p = Parcel { weight_grams: 100, zone: "international".to_string() };
        let q = quote(&p).unwrap();
        
        // base: 1499, surcharge: 1499 * 0.2 = 299.8 -> 300
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn test_heavy_international() {
        let _f = setup_ratecard("# zone\tband_max_grams\tcents\ninternational\t20000\t4999");
        let p = Parcel { weight_grams: 11000, zone: "international".to_string() };
        let q = quote(&p).unwrap();
        
        // base: 4999
        // weight surcharge: 500
        // intl surcharge: 4999 * 0.2 = 999.8 -> 1000
        // total surcharge: 1500
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn test_unknown_zone() {
        let _f = setup_ratecard("domestic\t500\t599");
        let p = Parcel { weight_grams: 100, zone: "mars".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::UnknownZone("mars".to_string()));
    }

    #[test]
    fn test_malformed_line() {
        let _f = setup_ratecard("# comment\n\ndomestic\t500\t599\nbad\tline\ninternational\t500\t1499");
        let p = Parcel { weight_grams: 100, zone: "international".to_string() };
        let res = quote(&p);
        // Line 1: #, Line 2: empty, Line 3: ok, Line 4: bad
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn test_malformed_number() {
        let _f = setup_ratecard("domestic\tnot_a_number\t599");
        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn test_unavailable_path() {
        env::remove_var("RATECARD_PATH");
        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::RateCardUnavailable);
    }
}
