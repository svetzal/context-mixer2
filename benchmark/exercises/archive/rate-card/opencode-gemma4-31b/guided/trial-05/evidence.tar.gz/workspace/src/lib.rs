pub mod zones;

use std::env;
use std::fs::File;
use std::io::{BufRead, BufReader};
use std::fmt;
use tracing::info;

#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "Overweight: {}g, limit {}g", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let file = File::open(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);

    let mut zone_bands: Vec<Band> = Vec::new();
    let mut zone_exists = false;

    for (index, line_result) in reader.lines().enumerate() {
        let line_num = index + 1;
        let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
        let trimmed = line.trim_end();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = trimmed.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        if fields[0] == parcel.zone {
            zone_exists = true;
            let max_grams = fields[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
            let cents = fields[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
            zone_bands.push(Band { max_grams, cents });
        }
    }

    if !zone_exists {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.max_grams);

    let band = zone_bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = zone_bands.last().map(|b| b.max_grams).unwrap_or(0);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let international_surcharge = if base_cents % 5 >= 3 {
            (base_cents / 5) + 1
        } else {
            base_cents / 5
        };
        surcharge_cents += international_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    info!(
        zone = %parcel.zone,
        weight = parcel.weight_grams,
        total = total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn setup_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        writeln!(file, "{}", content).unwrap();
        env::set_var("RATECARD_PATH", file.path());
        file
    }

    #[test]
    fn test_domestic_quote() {
        let _file = setup_ratecard("domestic\t500\t599\ndomestic\t2000\t899");
        let parcel = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_international_quote() {
        let _file = setup_ratecard("international\t500\t1499");
        let parcel = Parcel { weight_grams: 400, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();
        // 1499 * 0.2 = 299.8 -> 300
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn test_overweight_surcharge() {
        let _file = setup_ratecard("domestic\t20000\t1799");
        let parcel = Parcel { weight_grams: 12000, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 1799 + 500);
    }

    #[test]
    fn test_overweight_error() {
        let _file = setup_ratecard("domestic\t500\t599");
        let parcel = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::Overweight { grams: 600, limit: 500 });
    }

    #[test]
    fn test_unknown_zone() {
        let _file = setup_ratecard("domestic\t500\t599");
        let parcel = Parcel { weight_grams: 100, zone: "mars".to_string() };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("mars".to_string()));
    }

    #[test]
    fn test_malformed_ratecard() {
        let _file = setup_ratecard("domestic\t500\t599\ndomestic\tbad\t899");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn test_malformed_fields() {
        let _file = setup_ratecard("domestic\t500");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn test_ratecard_unavailable() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn test_comments_and_blanks() {
        let _file = setup_ratecard("# comment\n\ndomestic\t500\t599\n# another\ndomestic\t1000\t799");
        let parcel = Parcel { weight_grams: 800, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 799);
        assert_eq!(quote.band_max_grams, 1000);
    }

    #[test]
    fn test_half_up_rounding() {
        // 100 * 0.2 = 20.0 -> 20
        let _f1 = setup_ratecard("international\t500\t100");
        let p1 = Parcel { weight_grams: 100, zone: "international".to_string() };
        assert_eq!(quote(&p1).unwrap().surcharge_cents, 20);

        // 102 * 0.2 = 20.4 -> 20
        let _f2 = setup_ratecard("international\t500\t102");
        let p2 = Parcel { weight_grams: 100, zone: "international".to_string() };
        assert_eq!(quote(&p2).unwrap().surcharge_cents, 20);

        // 103 * 0.2 = 20.6 -> 21
        let _f3 = setup_ratecard("international\t500\t103");
        let p3 = Parcel { weight_grams: 100, zone: "international".to_string() };
        assert_eq!(quote(&p3).unwrap().surcharge_cents, 21);
    }
}
