pub mod zones;

use std::env;
use std::error::Error;
use std::fmt;
use std::fs;
use tracing::info;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "malformed rate card at line {line}"),
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {grams}g exceeds limit of {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let content = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands = Vec::new();
    for (i, line) in content.lines().enumerate() {
        let line_num = i + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = fields[0].to_string();
        let band_max = fields[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = fields[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        bands.push((zone, band_max, cents));
    }

    let mut zone_bands: Vec<(u32, u64)> = bands
        .into_iter()
        .filter(|(z, _, _)| z == &parcel.zone)
        .map(|(_, max, cents)| (max, cents))
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|(max, _)| *max);

    let matching_band = zone_bands
        .iter()
        .find(|(max, _)| *max >= parcel.weight_grams);

    let (band_max_grams, base_cents) = match matching_band {
        Some(band) => *band,
        None => {
            let limit = zone_bands.last().unwrap().0;
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let mut surcharge_cents = 0u64;
    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    info!(
        zone = %parcel.zone,
        weight_grams = %parcel.weight_grams,
        total_cents = %total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn setup_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        writeln!(file, "{}", content).unwrap();
        env::set_var("RATECARD_PATH", file.path());
        file
    }

    #[test]
    fn test_domestic_standard() {
        let _file = setup_ratecard("domestic\t500\t599\ndomestic\t2000\t899");
        let p = Parcel { weight_grams: 300, zone: "domestic".to_string() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_heavy() {
        let _file = setup_ratecard("domestic\t500\t599\ndomestic\t2000\t899");
        let p = Parcel { weight_grams: 1500, zone: "domestic".to_string() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.total_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn test_international_surcharge() {
        let _file = setup_ratecard("international\t500\t1499");
        let p = Parcel { weight_grams: 300, zone: "international".to_string() };
        let q = quote(&p).unwrap();
        // 1499 * 0.2 = 299.8 -> 300
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn test_overweight_surcharge() {
        let _file = setup_ratecard("domestic\t20000\t1799");
        let p = Parcel { weight_grams: 15000, zone: "domestic".to_string() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn test_international_and_overweight() {
        let _file = setup_ratecard("international\t20000\t4999");
        let p = Parcel { weight_grams: 15000, zone: "international".to_string() };
        let q = quote(&p).unwrap();
        // 4999 * 0.2 = 999.8 -> 1000
        // 15000 > 10000 -> 500
        // total surcharge = 1500
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn test_unknown_zone() {
        let _file = setup_ratecard("domestic\t500\t599");
        let p = Parcel { weight_grams: 100, zone: "mars".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::UnknownZone("mars".to_string()));
    }

    #[test]
    fn test_overweight_error() {
        let _file = setup_ratecard("domestic\t500\t599");
        let p = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::Overweight { grams: 600, limit: 500 });
    }

    #[test]
    fn test_malformed_ratecard() {
        let _file = setup_ratecard("domestic\t500\t599\nmalformed\tline\n# comment\ndomestic\t1000\t899");
        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn test_invalid_numbers() {
        let _file = setup_ratecard("domestic\tabc\t599");
        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn test_empty_lines_and_comments() {
        let _file = setup_ratecard("# header\n\ndomestic\t500\t599");
        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn test_ratecard_unavailable() {
        env::remove_var("RATECARD_PATH");
        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::RateCardUnavailable);
    }
}
