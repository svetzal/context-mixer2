pub mod zones;

use std::error::Error;
use std::fmt;
use std::fs::File;
use std::io::{BufRead, BufReader};
use std::env;
use tracing::info;

#[derive(Debug, PartialEq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, PartialEq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {line}"),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => write!(f, "Overweight: {grams}g exceeds limit of {limit}g"),
        }
    }
}

impl Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let file = File::open(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);

    let mut zone_bands: Vec<Band> = Vec::new();
    let mut zone_found = false;
    
    for (index, line_result) in reader.lines().enumerate() {
        let line_num = index + 1;
        let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
        
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = fields[0];
        let max_grams = fields[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = fields[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        if zone == parcel.zone {
            zone_found = true;
            zone_bands.push(Band { max_grams, cents });
        }
    }

    if !zone_found {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.max_grams);

    let band = zone_bands.iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = zone_bands.iter().map(|b| b.max_grams).max().unwrap_or(0);
            QuoteError::Overweight { grams: parcel.weight_grams, limit }
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up.
        // (base * 20 + 50) / 100 is a way to do half-up for integers if we use 100 as base.
        // Or just use floats and round.
        let surcharge = (base_cents as f64 * 0.2).round() as u64;
        surcharge_cents += surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    info!(
        zone = %parcel.zone,
        weight = %parcel.weight_grams,
        total = %total_cents,
        "calculated shipping quote"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn setup_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        writeln!(file, "{}", content).unwrap();
        let path = file.path().to_str().unwrap().to_string();
        env::set_var("RATECARD_PATH", path);
        file
    }

    #[test]
    fn test_domestic_small() {
        let _file = setup_ratecard("# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899");
        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_large_surcharge() {
        let _file = setup_ratecard("domestic\t20000\t1799");
        let p = Parcel { weight_grams: 15000, zone: "domestic".to_string() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn test_international_surcharge() {
        let _file = setup_ratecard("international\t500\t1499");
        let p = Parcel { weight_grams: 100, zone: "international".to_string() };
        let q = quote(&p).unwrap();
        // 1499 * 0.2 = 299.8 -> 300
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn test_international_both_surcharges() {
        let _file = setup_ratecard("international\t20000\t4999");
        let p = Parcel { weight_grams: 15000, zone: "international".to_string() };
        let q = quote(&p).unwrap();
        // 4999 * 0.2 = 999.8 -> 1000
        // 1000 + 500 = 1500
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn test_unknown_zone() {
        let _file = setup_ratecard("domestic\t500\t599");
        let p = Parcel { weight_grams: 100, zone: "mars".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::UnknownZone("mars".to_string()));
    }

    #[test]
    fn test_overweight() {
        let _file = setup_ratecard("domestic\t500\t599");
        let p = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::Overweight { grams: 600, limit: 500 });
    }

    #[test]
    fn test_malformed_ratecard_fields() {
        let _file = setup_ratecard("domestic\t500");
        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn test_malformed_ratecard_parse() {
        let _file = setup_ratecard("domestic\t500\tabc");
        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn test_malformed_line_numbering() {
        let _file = setup_ratecard("# comment\n\n  wrong  \tdomestic\t500");
        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&p);
        // Line 1: # comment (ignored)
        // Line 2: empty (ignored)
        // Line 3: "  wrong  \tdomestic\t500" (3 fields - valid format, but maybe different zone)
        // Wait, the test is for malformed.
        let _file2 = setup_ratecard("# comment\n\n  wrong\t500");
        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn test_ratecard_unavailable() {
        env::remove_var("RATECARD_PATH");
        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::RateCardUnavailable);
    }
}
