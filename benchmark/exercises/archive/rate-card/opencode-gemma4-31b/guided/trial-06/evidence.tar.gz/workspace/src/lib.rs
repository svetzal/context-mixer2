pub mod zones;

use std::env;
use std::fs::File;
use std::io::{BufRead, BufReader};
use std::fmt;
use std::error::Error;
use tracing::info;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => write!(f, "Overweight: {}g exceeds limit of {}g", grams, limit),
        }
    }
}

impl Error for QuoteError {}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let file = File::open(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);

    let mut bands = Vec::new();
    for (idx, line_result) in reader.lines().enumerate() {
        let line_num = idx + 1;
        let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = fields[0].to_string();
        let max_grams = fields[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = fields[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        bands.push((zone, max_grams, cents));
    }

    let mut zone_bands: Vec<(u32, u64)> = bands
        .into_iter()
        .filter(|(zone, _, _)| zone == &parcel.zone)
        .map(|(_, max, cents)| (max, cents))
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|(max, _)| *max);

    let band = zone_bands
        .iter()
        .find(|(max, _)| *max >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = zone_bands.last().unwrap().0;
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = band.1;
    let band_max_grams = band.0;

    let mut surcharge_cents = 0u64;
    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let international_surcharge = (base_cents as f64 * 0.2).round() as u64;
        surcharge_cents += international_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;

    info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total_cents,
        "Quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn setup_card(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        writeln!(file, "{}", content).unwrap();
        file
    }

    #[test]
    fn test_domestic_quote() {
        let card = setup_card("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799");
        env::set_var("RATECARD_PATH", card.path());

        let p1 = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let q1 = quote(&p1).unwrap();
        assert_eq!(q1.base_cents, 599);
        assert_eq!(q1.total_cents, 599);
        assert_eq!(q1.band_max_grams, 500);

        let p2 = Parcel { weight_grams: 11000, zone: "domestic".to_string() };
        let q2 = quote(&p2).unwrap();
        assert_eq!(q2.base_cents, 1799);
        assert_eq!(q2.surcharge_cents, 500);
        assert_eq!(q2.total_cents, 2299);
    }

    #[test]
    fn test_international_quote() {
        let card = setup_card("international\t500\t1499\ninternational\t20000\t4999");
        env::set_var("RATECARD_PATH", card.path());

        let p1 = Parcel { weight_grams: 400, zone: "international".to_string() };
        let q1 = quote(&p1).unwrap();
        assert_eq!(q1.base_cents, 1499);
        // 1499 * 0.2 = 299.8 -> 300
        assert_eq!(q1.surcharge_cents, 300);
        assert_eq!(q1.total_cents, 1799);

        let p2 = Parcel { weight_grams: 11000, zone: "international".to_string() };
        let q2 = quote(&p2).unwrap();
        assert_eq!(q2.base_cents, 4999);
        // (4999 * 0.2).round() = 999.8 -> 1000
        // 1000 + 500 = 1500
        assert_eq!(q2.surcharge_cents, 1500);
        assert_eq!(q2.total_cents, 6499);
    }

    #[test]
    fn test_unknown_zone() {
        let card = setup_card("domestic\t500\t599");
        env::set_var("RATECARD_PATH", card.path());

        let p = Parcel { weight_grams: 400, zone: "mars".to_string() };
        let res = quote(&p);
        match res {
            Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "mars"),
            _ => panic!("Expected UnknownZone"),
        }
    }

    #[test]
    fn test_overweight() {
        let card = setup_card("domestic\t500\t599");
        env::set_var("RATECARD_PATH", card.path());

        let p = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        let res = quote(&p);
        match res {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 600);
                assert_eq!(limit, 500);
            }
            _ => panic!("Expected Overweight"),
        }
    }

    #[test]
    fn test_malformed_card() {
        let card = setup_card("domestic\t500\t599\ninvalid line\ndomestic\t2000\t899");
        env::set_var("RATECARD_PATH", card.path());

        let p = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let res = quote(&p);
        match res {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 2),
            _ => panic!("Expected MalformedRateCard"),
        }
    }

    #[test]
    fn test_ratecard_unavailable() {
        env::set_var("RATECARD_PATH", "/non/existent/path");
        let p = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let res = quote(&p);
        match res {
            Err(QuoteError::RateCardUnavailable) => (),
            _ => panic!("Expected RateCardUnavailable"),
        }
    }
}
