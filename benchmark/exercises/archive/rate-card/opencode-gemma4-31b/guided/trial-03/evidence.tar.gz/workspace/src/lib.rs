pub mod zones;

use std::env;
use std::error::Error;
use std::fmt;
use std::fs::File;
use std::io::{self, BufRead, BufReader};
use tracing::info;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "Overweight: {}g exceeds limit of {}g", grams, limit)
            }
        }
    }
}

impl Error for QuoteError {}

struct RateBand {
    zone: String,
    max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let file = File::open(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);

    let mut bands = Vec::new();
    for (index, line_result) in reader.lines().enumerate() {
        let line_num = index + 1;
        let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
        
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = fields[0].to_string();
        let max_grams = fields[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = fields[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        bands.push(RateBand { zone, max_grams, cents });
    }

    let zone_bands: Vec<&RateBand> = bands
        .iter()
        .filter(|b| b.zone == parcel.zone)
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let mut sorted_bands = zone_bands;
    sorted_bands.sort_by_key(|b| b.max_grams);

    let band = sorted_bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = sorted_bands.last().map(|b| b.max_grams).unwrap_or(0);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    info!(
        zone = %parcel.zone,
        weight = parcel.weight_grams,
        total = total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn setup_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        write!(file, "{}", content).unwrap();
        let path = file.path().to_str().unwrap().to_string();
        std::env::set_var("RATECARD_PATH", path);
        file
    }

    #[test]
    fn test_quote_domestic_small() {
        let _file = setup_ratecard("# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_quote_domestic_medium() {
        let _file = setup_ratecard("# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899");
        let parcel = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn test_quote_international_surcharge() {
        let _file = setup_ratecard("international\t500\t1499");
        let parcel = Parcel { weight_grams: 100, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn test_quote_weight_surcharge() {
        let _file = setup_ratecard("domestic\t20000\t1799");
        let parcel = Parcel { weight_grams: 10001, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn test_quote_combined_surcharges() {
        let _file = setup_ratecard("international\t20000\t4999");
        let parcel = Parcel { weight_grams: 10001, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn test_quote_unknown_zone() {
        let _file = setup_ratecard("domestic\t500\t599");
        let parcel = Parcel { weight_grams: 100, zone: "mars".to_string() };
        let result = quote(&parcel);
        assert_eq!(result.unwrap_err(), QuoteError::UnknownZone("mars".to_string()));
    }

    #[test]
    fn test_quote_overweight() {
        let _file = setup_ratecard("domestic\t500\t599");
        let parcel = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        let result = quote(&parcel);
        assert_eq!(result.unwrap_err(), QuoteError::Overweight { grams: 600, limit: 500 });
    }

    #[test]
    fn test_quote_malformed_line() {
        let _file = setup_ratecard("domestic\t500\t599\nbad-line\t100");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let result = quote(&parcel);
        assert_eq!(result.unwrap_err(), QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn test_quote_malformed_number() {
        let _file = setup_ratecard("domestic\t500\tnot-a-number");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let result = quote(&parcel);
        assert_eq!(result.unwrap_err(), QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn test_quote_unavailable() {
        std::env::set_var("RATECARD_PATH", "/tmp/non-existent-ratecard-12345");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let result = quote(&parcel);
        assert_eq!(result.unwrap_err(), QuoteError::RateCardUnavailable);
    }

    #[test]
    fn test_quote_empty_and_comments() {
        let _file = setup_ratecard("# Comment\n\ndomestic\t500\t599\n# Another\n\ndomestic\t1000\t799");
        let parcel = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 799);
        assert_eq!(quote.band_max_grams, 1000);
    }

    #[test]
    fn test_quote_half_up_rounding() {
        let _file = setup_ratecard("international\t500\t10");
        let parcel = Parcel { weight_grams: 100, zone: "international".to_string() };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.surcharge_cents, 2);

        let _file2 = setup_ratecard("international\t500\t12");
        let parcel = Parcel { weight_grams: 100, zone: "international".to_string() };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.surcharge_cents, 2);

        let _file3 = setup_ratecard("international\t500\t13");
        let parcel = Parcel { weight_grams: 100, zone: "international".to_string() };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.surcharge_cents, 3);
    }
}
