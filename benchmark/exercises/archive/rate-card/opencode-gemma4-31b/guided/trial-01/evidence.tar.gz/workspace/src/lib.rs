pub mod zones;

use std::fmt;
use std::error::Error;
use std::env;
use std::fs::File;
use std::io::{BufRead, BufReader};
use tracing::info;

#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {line}"),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => write!(f, "Overweight: {grams}g exceeds limit of {limit}g"),
        }
    }
}

impl Error for QuoteError {}

struct RateBand {
    max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let file = File::open(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);

    let mut bands = Vec::new();
    let mut zone_found = false;

    for (idx, line_result) in reader.lines().enumerate() {
        let line_num = idx + 1;
        let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
        
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = fields[0];
        if zone == parcel.zone {
            zone_found = true;
            let max_grams = fields[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
            let cents = fields[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
            bands.push(RateBand { max_grams, cents });
        }
    }

    if !zone_found {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    bands.sort_by_key(|b| b.max_grams);

    let band = bands.iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = bands.last().map(|b| b.max_grams).unwrap_or(0);
            QuoteError::Overweight { grams: parcel.weight_grams, limit }
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up
        // (base_cents * 20 + 50) / 100 is not quite right for 20% additive.
        // 20% of base_cents is base_cents * 0.2.
        // To round half-up: (base_cents * 20 + 50) / 100
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    info!(
        zone = %parcel.zone,
        weight = parcel.weight_grams,
        total = total_cents,
        "Quote calculated"
    );

// (all existing code)
// ...
    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn setup_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        write!(file, "{}", content).unwrap();
        env::set_var("RATECARD_PATH", file.path());
        file
    }

    #[test]
    fn test_domestic_quote() {
        let _file = setup_ratecard("domestic\t500\t599\ndomestic\t2000\t899\n");
        let parcel = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn test_domestic_quote_next_band() {
        let _file = setup_ratecard("domestic\t500\t599\ndomestic\t2000\t899\n");
        let parcel = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.total_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn test_international_surcharge() {
        let _file = setup_ratecard("international\t5000\t1000\n");
        let parcel = Parcel { weight_grams: 100, zone: "international".to_string() };
        let q = quote(&parcel).unwrap();
        // base: 1000, international: 20% of 1000 = 200. total = 1200
        assert_eq!(q.base_cents, 1000);
        assert_eq!(q.surcharge_cents, 200);
        assert_eq!(q.total_cents, 1200);
    }

    #[test]
    fn test_international_rounding() {
        let _file = setup_ratecard("international\t5000\t1005\n");
        let parcel = Parcel { weight_grams: 100, zone: "international".to_string() };
        let q = quote(&parcel).unwrap();
        // 1005 * 0.2 = 201.0 -> 201
        assert_eq!(q.surcharge_cents, 201);
    }
    
    #[test]
    fn test_international_rounding_half_up() {
        let _file = setup_ratecard("international\t5000\t1002\n");
        let parcel = Parcel { weight_grams: 100, zone: "international".to_string() };
        let q = quote(&parcel).unwrap();
        // 1002 * 0.2 = 200.4 -> 200
        assert_eq!(q.surcharge_cents, 200);
    }

    #[test]
    fn test_international_rounding_half_up_edge() {
        let _file = setup_ratecard("international\t5000\t1003\n");
        let parcel = Parcel { weight_grams: 100, zone: "international".to_string() };
        let q = quote(&parcel).unwrap();
        // 1003 * 0.2 = 200.6 -> 201
        assert_eq!(q.surcharge_cents, 201);
    }

    #[test]
    fn test_heavy_surcharge() {
        let _file = setup_ratecard("domestic\t20000\t1000\n");
        let parcel = Parcel { weight_grams: 10001, zone: "domestic".to_string() };
        let q = quote(&parcel).unwrap();
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 1500);
    }

    #[test]
    fn test_combined_surcharges() {
        let _file = setup_ratecard("international\t20000\t1000\n");
        let parcel = Parcel { weight_grams: 15000, zone: "international".to_string() };
        let q = quote(&parcel).unwrap();
        // base: 1000
        // weight: 500
        // international: 200
        // total surcharge: 700
        assert_eq!(q.surcharge_cents, 700);
        assert_eq!(q.total_cents, 1700);
    }

    #[test]
    fn test_unknown_zone() {
        let _file = setup_ratecard("domestic\t500\t599\n");
        let parcel = Parcel { weight_grams: 100, zone: "mars".to_string() };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("mars".to_string()));
    }

    #[test]
    fn test_overweight() {
        let _file = setup_ratecard("domestic\t500\t599\n");
        let parcel = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::Overweight { grams: 600, limit: 500 });
    }

    #[test]
    fn test_ratecard_unavailable() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn test_malformed_ratecard_fields() {
        let _file = setup_ratecard("domestic\t500\n"); // only 2 fields
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn test_malformed_ratecard_numbers() {
        let _file = setup_ratecard("domestic\tabc\t599\n");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn test_malformed_ratecard_line_numbering() {
        let _file = setup_ratecard("# comment\n\ndomestic\tabc\t599\n");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let err = quote(&parcel).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }
}
