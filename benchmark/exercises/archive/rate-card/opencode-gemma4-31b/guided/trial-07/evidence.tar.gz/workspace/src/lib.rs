pub mod zones;

use std::env;
use std::fs::File;
use std::io::{BufRead, BufReader};
use std::fmt;
use std::error::Error;
use tracing::info;

#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "Rate card unavailable"),
            Self::MalformedRateCard { line } => write!(f, "Malformed rate card at line {}", line),
            Self::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            Self::Overweight { grams, limit } => write!(f, "Overweight: {}g exceeds limit of {}g", grams, limit),
        }
    }
}

impl Error for QuoteError {}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let file = File::open(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);

    let lines = reader.lines();
    let mut all_zones = std::collections::HashSet::new();
    let mut zone_bands = Vec::new();

    for (idx, line_result) in lines.enumerate() {
        let line_num = idx + 1;
        let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
        
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = fields[0].to_string();
        let max_grams = fields[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = fields[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        all_zones.insert(zone.clone());
        if zone == parcel.zone {
            zone_bands.push((max_grams, cents));
        }
    }

    if !all_zones.contains(&parcel.zone) {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.0);

    let (band_max_grams, base_cents) = zone_bands
        .iter()
        .find(|(max, _)| *max >= parcel.weight_grams)
        .copied()
        .ok_or_else(|| {
            let limit = zone_bands.last().map(|b| b.0).unwrap_or(0);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let mut surcharge_cents = 0u64;
    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += (base_cents as f64 * 0.2).round() as u64;
    }

    let total_cents = base_cents + surcharge_cents;
    
    info!(
        zone = %parcel.zone,
        weight = parcel.weight_grams,
        total = total_cents,
        "Quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn setup_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        writeln!(file, "{}", content).unwrap();
        let path = file.path().to_string_lossy().into_owned();
        env::set_var("RATECARD_PATH", path);
        file
    }

    #[test]
    fn test_quote_success_domestic() {
        let _file = setup_ratecard("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799");
        let p = Parcel { weight_grams: 1000, zone: "domestic".to_string() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.total_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn test_quote_success_international() {
        let _file = setup_ratecard("international\t500\t1499\ninternational\t20000\t4999");
        let p = Parcel { weight_grams: 400, zone: "international".to_string() };
        let q = quote(&p).unwrap();
        // base: 1499, surcharge: 1499 * 0.2 = 299.8 -> 300
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn test_quote_overweight_surcharge() {
        let _file = setup_ratecard("domestic\t20000\t1799");
        let p = Parcel { weight_grams: 12000, zone: "domestic".to_string() };
        let q = quote(&p).unwrap();
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 1799 + 500);
    }

    #[test]
    fn test_quote_international_overweight_surcharge() {
        let _file = setup_ratecard("international\t20000\t4999");
        let p = Parcel { weight_grams: 12000, zone: "international".to_string() };
        let q = quote(&p).unwrap();
        // base: 4999, weight surcharge: 500, int surcharge: 4999 * 0.2 = 999.8 -> 1000
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 4999 + 1500);
    }

    #[test]
    fn test_unknown_zone() {
        let _file = setup_ratecard("domestic\t500\t599");
        let p = Parcel { weight_grams: 100, zone: "mars".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::UnknownZone("mars".to_string()));
    }

    #[test]
    fn test_overweight() {
        let _file = setup_ratecard("domestic\t500\t599");
        let p = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::Overweight { grams: 600, limit: 500 });
    }

    #[test]
    fn test_malformed_ratecard() {
        let _file = setup_ratecard("domestic\t500\t599\ninvalid line\ndomestic\t2000\t899");
        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn test_ratecard_unavailable() {
        env::remove_var("RATECARD_PATH");
        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::RateCardUnavailable);
    }
}
