pub mod zones;

use std::env;
use std::fs::File;
use std::io::{BufRead, BufReader};
use std::fmt;
use std::error::Error;
use tracing::info;

#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "Rate card unavailable"),
            QuoteError::MalformedRateCard { line } => write!(f, "Malformed rate card at line {}", line),
            QuoteError::UnknownZone(zone) => write!(f, "Unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => write!(f, "Overweight: {}g exceeds limit of {}g", grams, limit),
        }
    }
}

impl Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let file = File::open(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);

    let mut bands_for_zone: Vec<Band> = Vec::new();
    let mut zone_found = false;

    for (idx, line_result) in reader.lines().enumerate() {
        let line_num = idx + 1;
        let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = fields[0];
        let max_grams = fields[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = fields[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        if zone == parcel.zone {
            zone_found = true;
            bands_for_zone.push(Band { max_grams, cents });
        }
    }

    if !zone_found {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    bands_for_zone.sort_by_key(|b| b.max_grams);

    let matching_band = bands_for_zone
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = bands_for_zone.iter().map(|b| b.max_grams).max().unwrap_or(0);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = matching_band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        let international_surcharge = (base_cents as f64 * 0.2).round() as u64;
        surcharge_cents += international_surcharge;
    }

    let total_cents = base_cents + surcharge_cents;
    
    info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total_cents,
        "Quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: matching_band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn setup_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        writeln!(file, "{}", content).unwrap();
        env::set_var("RATECARD_PATH", file.path());
        file
    }

    #[test]
    fn test_domestic_quote() {
        let file = setup_ratecard("# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\t899");
        let p = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.total_cents, 599);
        drop(file);
    }

    #[test]
    fn test_international_surcharge() {
        let file = setup_ratecard("international\t500\t1000");
        let p = Parcel { weight_grams: 400, zone: "international".to_string() };
        let q = quote(&p).unwrap();
        assert_eq!(q.base_cents, 1000);
        assert_eq!(q.surcharge_cents, 200);
        assert_eq!(q.total_cents, 1200);
        drop(file);
    }

    #[test]
    fn test_overweight_surcharge() {
        let file = setup_ratecard("domestic\t20000\t2000");
        let p = Parcel { weight_grams: 11000, zone: "domestic".to_string() };
        let q = quote(&p).unwrap();
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2500);
        drop(file);
    }

    #[test]
    fn test_overweight_error() {
        let file = setup_ratecard("domestic\t500\t500");
        let p = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::Overweight { grams: 600, limit: 500 });
        drop(file);
    }

    #[test]
    fn test_unknown_zone() {
        let file = setup_ratecard("domestic\t500\t500");
        let p = Parcel { weight_grams: 100, zone: "mars".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::UnknownZone("mars".to_string()));
        drop(file);
    }

    #[test]
    fn test_malformed_card() {
        let file = setup_ratecard("domestic\t500\t500\nbad line");
        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 2 });
        drop(file);
    }

    #[test]
    fn test_unavailable_card() {
        env::remove_var("RATECARD_PATH");
        let p = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&p);
        assert_eq!(res.unwrap_err(), QuoteError::RateCardUnavailable);
    }

    #[test]
    fn test_half_up_rounding() {
        let file = setup_ratecard("international\t500\t599");
        let p = Parcel { weight_grams: 100, zone: "international".to_string() };
        let q = quote(&p).unwrap();
        // 599 * 0.2 = 119.8 -> 120
        assert_eq!(q.surcharge_cents, 120);
        drop(file);
    }
}

