pub mod zones;

use std::env;
use std::fs::File;
use std::io::{self, BufRead, BufReader};
use std::error::Error;
use std::fmt;
use tracing::info;
use std::collections::HashMap;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => write!(f, "malformed rate card at line {}", line),
            Self::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            Self::Overweight { grams, limit } => write!(f, "parcel weight {}g exceeds limit {}g", grams, limit),
        }
    }
}

impl Error for QuoteError {}

#[derive(Clone, Copy)]
struct Band {
    max_grams: u32,
    cents: u64,
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let file = File::open(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let reader = BufReader::new(file);

    let mut bands_by_zone: HashMap<String, Vec<Band>> = HashMap::new();

    for (idx, line_result) in reader.lines().enumerate() {
        let line_num = idx + 1;
        let line = line_result.map_err(|_| QuoteError::RateCardUnavailable)?;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_num });
        }

        let zone = fields[0].to_string();
        let max_grams = fields[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;
        let cents = fields[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line: line_num })?;

        bands_by_zone.entry(zone).or_default().push(Band { max_grams, cents });
    }

    let zone_bands = bands_by_zone.get(&parcel.zone).ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    
    let mut sorted_bands = zone_bands.clone();
    sorted_bands.sort_by_key(|b| b.max_grams);

    let band = sorted_bands.iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .ok_or_else(|| {
            let limit = sorted_bands.last().map(|b| b.max_grams).unwrap_or(0);
            QuoteError::Overweight { grams: parcel.weight_grams, limit }
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up to the cent.
        // (base_cents * 20 + 50) / 100 is a common way to do half-up for integer division of percentages.
        // Wait, 20% is 0.2. (base_cents * 20) / 100.
        // For half-up: (base_cents * 20 + 50) / 100.
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    fn setup_ratecard(content: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().unwrap();
        write!(file, "{}", content).unwrap();
        env::set_var("RATECARD_PATH", file.path());
        file
    }

    #[test]
    fn test_domestic_quote() {
        let _file = setup_ratecard("domestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\n");
        let parcel = Parcel { weight_grams: 400, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn test_international_quote() {
        let _file = setup_ratecard("international\t500\t1499\ninternational\t20000\t4999\n");
        let parcel = Parcel { weight_grams: 400, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();
        // base: 1499. surcharge: 1499 * 0.2 = 299.8 -> 300. total: 1799.
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn test_overweight() {
        let _file = setup_ratecard("domestic\t500\t599\n");
        let parcel = Parcel { weight_grams: 600, zone: "domestic".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::Overweight { grams: 600, limit: 500 });
    }

    #[test]
    fn test_unknown_zone() {
        let _file = setup_ratecard("domestic\t500\t599\n");
        let parcel = Parcel { weight_grams: 100, zone: "mars".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::UnknownZone("mars".to_string()));
    }

    #[test]
    fn test_malformed_ratecard() {
        let _file = setup_ratecard("# header\ndomestic\t500\t599\nbad line\n");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        let res = quote(&parcel);
        assert_eq!(res.unwrap_err(), QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn test_surcharge_weight() {
        let _file = setup_ratecard("domestic\t20000\t1799\n");
        let parcel = Parcel { weight_grams: 11000, zone: "domestic".to_string() };
        let quote = quote(&parcel).unwrap();
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 1799 + 500);
    }

    #[test]
    fn test_both_surcharges() {
        let _file = setup_ratecard("international\t20000\t4999\n");
        let parcel = Parcel { weight_grams: 11000, zone: "international".to_string() };
        let quote = quote(&parcel).unwrap();
        // base: 4999. weight surcharge: 500. international: 4999 * 0.2 = 999.8 -> 1000.
        // total surcharge: 1500.
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 4999 + 1500);
    }

    #[test]
    fn test_ratecard_unavailable() {
        env::remove_var("RATECARD_PATH");
        let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
        assert_eq!(quote(&parcel).unwrap_err(), QuoteError::RateCardUnavailable);
    }
}
