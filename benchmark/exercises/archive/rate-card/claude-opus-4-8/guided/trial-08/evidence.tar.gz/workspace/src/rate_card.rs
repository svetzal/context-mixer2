//! The pure core: parse rate-card text into bands, and price a parcel against
//! them.
//!
//! Nothing here touches the filesystem, the environment, or the clock. Every
//! function is a total mapping from its inputs to a `Result`, so the whole
//! module is exercised by ordinary in-process unit tests.

use crate::model::{Parcel, Quote, QuoteError};

/// The gram weight above which the heavy-parcel surcharge applies.
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
/// The flat surcharge, in cents, for parcels above [`HEAVY_THRESHOLD_GRAMS`].
const HEAVY_SURCHARGE_CENTS: u64 = 500;
/// The zone whose base price attracts a percentage surcharge.
const INTERNATIONAL_ZONE: &str = "international";
/// The international surcharge percentage of `base_cents`.
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

/// One priced weight band for a single zone.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct Band {
    /// The zone this band belongs to.
    pub zone: String,
    /// The inclusive upper weight bound of the band, in grams.
    pub max_grams: u32,
    /// The band's base price, in cents.
    pub cents: u64,
}

/// Parse tab-separated rate-card text into bands.
///
/// Empty lines and lines beginning with `#` are ignored. Every other line must
/// be exactly three tab-separated fields whose second and third fields parse as
/// unsigned integers; otherwise a [`QuoteError::MalformedRateCard`] carrying the
/// 1-based line number is returned. Line numbers count every line in the input,
/// including the ignored comments and blanks.
pub(crate) fn parse_bands(text: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();

    for (index, line) in text.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        bands.push(Band {
            zone: fields[0].to_string(),
            max_grams,
            cents,
        });
    }

    Ok(bands)
}

/// Price a parcel against a set of bands.
///
/// The matching band is the first, in ascending `max_grams`, whose `max_grams`
/// is greater than or equal to the parcel weight. Surcharges (heavy-parcel and
/// international) are added on top of the band's base price.
pub(crate) fn price(bands: &[Band], parcel: &Parcel) -> Result<Quote, QuoteError> {
    let mut zone_bands: Vec<&Band> = bands.iter().filter(|b| b.zone == parcel.zone).collect();
    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }
    zone_bands.sort_by_key(|b| b.max_grams);

    // Safe: `zone_bands` is non-empty by the check above.
    let limit = zone_bands.last().map_or(0, |b| b.max_grams);

    let band = match zone_bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
    {
        Some(band) => band,
        None => {
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            })
        }
    };

    let base_cents = band.cents;
    let surcharge_cents = heavy_surcharge(parcel.weight_grams)
        + international_surcharge(&parcel.zone, base_cents);
    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

/// The flat surcharge for parcels strictly above the heavy threshold.
fn heavy_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > HEAVY_THRESHOLD_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    }
}

/// The percentage surcharge for the international zone, rounded half-up to the
/// nearest cent.
fn international_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone != INTERNATIONAL_ZONE {
        return 0;
    }
    // Half-up rounding of `base_cents * percent / 100` using integer maths:
    // add half the divisor before dividing.
    (base_cents * INTERNATIONAL_SURCHARGE_PERCENT + 50) / 100
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used)]
mod tests {
    use super::*;

    fn card() -> Vec<Band> {
        parse_bands(concat!(
            "# zone\tband_max_grams\tcents\n",
            "domestic\t500\t599\n",
            "domestic\t2000\t899\n",
            "domestic\t20000\t1799\n",
            "international\t500\t1499\n",
            "international\t20000\t4999\n",
        ))
        .unwrap()
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn parses_only_data_lines() {
        let bands = card();
        assert_eq!(bands.len(), 5);
        assert_eq!(bands[0].zone, "domestic");
        assert_eq!(bands[0].max_grams, 500);
        assert_eq!(bands[0].cents, 599);
    }

    #[test]
    fn ignores_blank_and_comment_lines() {
        let bands = parse_bands("\n# a comment\n\ndomestic\t500\t599\n").unwrap();
        assert_eq!(bands.len(), 1);
    }

    #[test]
    fn wrong_field_count_reports_line_number() {
        let err = parse_bands("domestic\t500\t599\ndomestic\t500\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn unparseable_number_reports_line_number() {
        // Line 1 is a comment, line 2 blank, so the bad line is 3.
        let err = parse_bands("# header\n\ndomestic\theavy\t599\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn matches_first_band_at_or_above_weight() {
        let quote = price(&card(), &parcel(500, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
    }

    #[test]
    fn weight_just_over_a_band_falls_to_the_next() {
        let quote = price(&card(), &parcel(501, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn heavy_parcel_adds_flat_surcharge() {
        let quote = price(&card(), &parcel(15_000, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn exactly_ten_kilos_is_not_heavy() {
        let quote = price(&card(), &parcel(10_000, "domestic")).unwrap();
        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_twenty_percent_rounded_half_up() {
        // base 1499 -> 20% = 299.8 -> 300
        let quote = price(&card(), &parcel(400, "international")).unwrap();
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn international_and_heavy_surcharges_stack() {
        // base 4999 -> 20% = 999.8 -> 1000, plus 500 heavy.
        let quote = price(&card(), &parcel(15_000, "international")).unwrap();
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_carries_the_request() {
        let err = price(&card(), &parcel(100, "lunar")).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".to_string()));
    }

    #[test]
    fn overweight_carries_grams_and_limit() {
        let err = price(&card(), &parcel(25_000, "domestic")).unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000,
            }
        );
    }
}
