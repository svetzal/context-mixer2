//! Shipping quotes from a zone rate card.
//!
//! Operations maintains a tab-separated rate card and redeploys it without a
//! code change; this crate reads that card and turns a [`Parcel`] into a
//! [`Quote`]. The card's location is taken from the `RATECARD_PATH` environment
//! variable at quote time.
//!
//! The crate is organised as a pure core wrapped in a thin imperative shell:
//!
//! - a pure core parses the card and prices a parcel — no I/O.
//! - a gateway fetches the card text from `RATECARD_PATH`.
//! - [`quote`] wires the two together and emits a diagnostic record per call.
//!
//! ```no_run
//! use ratecard::{quote, Parcel, QuoteError};
//!
//! let parcel = Parcel { weight_grams: 750, zone: "domestic".to_string() };
//! match quote(&parcel) {
//!     Ok(q) => println!("total: {} cents", q.total_cents),
//!     Err(QuoteError::UnknownZone(z)) => eprintln!("no such zone: {z}"),
//!     Err(e) => eprintln!("could not quote: {e}"),
//! }
//! ```

mod model;
mod rate_card;
mod source;
pub mod zones;

pub use model::{Parcel, Quote, QuoteError};

use source::{EnvFileSource, RateCardSource};

/// Quote the given parcel against the current rate card.
///
/// The rate card is read from the file named by the `RATECARD_PATH` environment
/// variable. See the crate documentation for the pricing rules and
/// [`QuoteError`] for the failure modes.
///
/// # Errors
///
/// Returns [`QuoteError`] when the card cannot be read, is malformed, does not
/// list the parcel's zone, or does not have a band heavy enough for the parcel.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_with(parcel, &EnvFileSource)
}

/// Quote a parcel against a card obtained from an arbitrary source.
///
/// This is the seam the pure core is driven through: production passes
/// [`EnvFileSource`], tests pass an in-memory fake. It also carries the
/// observability, so every path through the shell is instrumented identically.
fn quote_with(parcel: &Parcel, source: &dyn RateCardSource) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "quote",
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
    );
    let _guard = span.enter();

    let text = source.read()?;
    let bands = rate_card::parse_bands(&text)?;
    let quote = rate_card::price(&bands, parcel)?;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = quote.total_cents,
        "quote computed",
    );

    Ok(quote)
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used)]
mod tests {
    use super::*;

    /// An in-memory rate-card source for driving the shell without touching the
    /// filesystem or the environment.
    enum FakeSource {
        Text(&'static str),
        Unavailable,
    }

    impl RateCardSource for FakeSource {
        fn read(&self) -> Result<String, QuoteError> {
            match self {
                FakeSource::Text(text) => Ok((*text).to_string()),
                FakeSource::Unavailable => Err(QuoteError::RateCardUnavailable),
            }
        }
    }

    const CARD: &str = concat!(
        "# zone\tband_max_grams\tcents\n",
        "domestic\t500\t599\n",
        "domestic\t2000\t899\n",
        "domestic\t20000\t1799\n",
        "international\t500\t1499\n",
        "international\t20000\t4999\n",
    );

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn quotes_a_domestic_parcel_end_to_end() {
        let quote = quote_with(&parcel(750, "domestic"), &FakeSource::Text(CARD)).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
        assert_eq!(quote.total_cents, 899);
    }

    #[test]
    fn unavailable_source_surfaces_as_error() {
        let err = quote_with(&parcel(750, "domestic"), &FakeSource::Unavailable).unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn malformed_card_surfaces_with_line_number() {
        let err = quote_with(
            &parcel(750, "domestic"),
            &FakeSource::Text("domestic\t500\t599\nbroken line\n"),
        )
        .unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn error_display_is_human_readable() {
        let err = QuoteError::Overweight {
            grams: 25_000,
            limit: 20_000,
        };
        assert_eq!(
            err.to_string(),
            "parcel weight 25000g exceeds zone limit of 20000g"
        );
    }

    #[test]
    fn error_is_std_error() {
        fn assert_error<E: std::error::Error>(_: &E) {}
        assert_error(&QuoteError::RateCardUnavailable);
    }
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used)]
mod observability_tests {
    use super::*;
    use std::collections::HashMap;
    use std::sync::{Arc, Mutex};
    use tracing::field::{Field, Visit};
    use tracing_subscriber::layer::{Context, Layer};
    use tracing_subscriber::prelude::*;
    use tracing_subscriber::Registry;

    /// Records every event's fields as strings, keyed by field name.
    #[derive(Default)]
    struct Captured(HashMap<String, String>);

    impl Visit for Captured {
        fn record_str(&mut self, field: &Field, value: &str) {
            self.0.insert(field.name().to_string(), value.to_string());
        }
        fn record_u64(&mut self, field: &Field, value: u64) {
            self.0.insert(field.name().to_string(), value.to_string());
        }
        fn record_i64(&mut self, field: &Field, value: i64) {
            self.0.insert(field.name().to_string(), value.to_string());
        }
        fn record_debug(&mut self, field: &Field, value: &dyn std::fmt::Debug) {
            self.0
                .entry(field.name().to_string())
                .or_insert_with(|| format!("{value:?}"));
        }
    }

    #[derive(Clone, Default)]
    struct CaptureLayer {
        events: Arc<Mutex<Vec<HashMap<String, String>>>>,
    }

    impl<S: tracing::Subscriber> Layer<S> for CaptureLayer {
        fn on_event(&self, event: &tracing::Event<'_>, _ctx: Context<'_, S>) {
            let mut captured = Captured::default();
            event.record(&mut captured);
            if let Ok(mut events) = self.events.lock() {
                events.push(captured.0);
            }
        }
    }

    #[test]
    fn each_call_emits_a_diagnostic_record_with_zone_weight_and_total() {
        let layer = CaptureLayer::default();
        let events = layer.events.clone();
        let subscriber = Registry::default().with(layer);

        tracing::subscriber::with_default(subscriber, || {
            let parcel = Parcel {
                weight_grams: 750,
                zone: "domestic".to_string(),
            };
            let card = "domestic\t2000\t899\n";
            let quote = quote_with(&parcel, &FakeText(card)).unwrap();
            assert_eq!(quote.total_cents, 899);
        });

        let events = events.lock().unwrap();
        let record = events
            .iter()
            .find(|fields| fields.contains_key("total_cents"))
            .expect("a diagnostic record carrying the total should be emitted");

        assert_eq!(record.get("zone").map(String::as_str), Some("domestic"));
        assert_eq!(record.get("weight_grams").map(String::as_str), Some("750"));
        assert_eq!(record.get("total_cents").map(String::as_str), Some("899"));
    }

    /// A trivial in-memory source used only by this module's test.
    struct FakeText(&'static str);
    impl RateCardSource for FakeText {
        fn read(&self) -> Result<String, QuoteError> {
            Ok(self.0.to_string())
        }
    }
}
