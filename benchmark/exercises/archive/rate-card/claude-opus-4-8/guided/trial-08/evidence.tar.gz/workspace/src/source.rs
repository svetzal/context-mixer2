//! The rate-card gateway: a project-owned contract for obtaining rate-card
//! text, and the concrete adapter that reads it from the environment and the
//! filesystem.
//!
//! Keeping the effect behind [`RateCardSource`] lets the pure core in
//! [`crate::rate_card`] be driven by an in-memory fake in tests, with no
//! coupling to `std::env` or `std::fs`.

use crate::model::QuoteError;

/// A source of raw rate-card text.
///
/// Implementors own whatever effect is needed to obtain the text (reading a
/// file, querying a service, or returning a canned string in tests) and map any
/// failure to obtain it onto [`QuoteError::RateCardUnavailable`].
pub(crate) trait RateCardSource {
    /// Return the rate-card text, or [`QuoteError::RateCardUnavailable`] if it
    /// cannot be obtained.
    fn read(&self) -> Result<String, QuoteError>;
}

/// The environment variable naming the rate-card file.
const RATECARD_PATH_VAR: &str = "RATECARD_PATH";

/// The production adapter: read the file named by the `RATECARD_PATH`
/// environment variable.
pub(crate) struct EnvFileSource;

impl RateCardSource for EnvFileSource {
    fn read(&self) -> Result<String, QuoteError> {
        let path = std::env::var_os(RATECARD_PATH_VAR).ok_or(QuoteError::RateCardUnavailable)?;
        std::fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}
