//! The public value types of the crate: the [`Parcel`] input, the [`Quote`]
//! output, and the [`QuoteError`] failure modes.
//!
//! These types are plain data with no behaviour beyond formatting an error.
//! The pricing rules that turn a `Parcel` into a `Quote` live in
//! [`crate::rate_card`]; reading the rate card lives in [`crate::source`].

use std::fmt;

/// A parcel to be priced: its weight and the shipping zone it travels to.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Destination zone, matched against the rate card's zone column.
    pub zone: String,
}

/// A priced quote for a parcel.
///
/// `total_cents` is always `base_cents + surcharge_cents`, and
/// `band_max_grams` is the upper bound of the weight band that produced
/// `base_cents`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// The band's price before surcharges, in cents.
    pub base_cents: u64,
    /// The sum of all applicable surcharges, in cents.
    pub surcharge_cents: u64,
    /// The amount payable, in cents: `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// The upper weight bound, in grams, of the band that was applied.
    pub band_max_grams: u32,
}

/// The ways a quote can fail.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card could not be located or read: `RATECARD_PATH` is unset,
    /// or points at a file that is missing or unreadable.
    RateCardUnavailable,
    /// A rate-card line was not three tab-separated fields, or its numbers did
    /// not parse. Carries the 1-based line number, counting every line in the
    /// file including comments and blanks.
    MalformedRateCard {
        /// The 1-based number of the offending line.
        line: usize,
    },
    /// The requested zone has no bands in the rate card. Carries the requested
    /// zone.
    UnknownZone(String),
    /// The parcel weighs more than the zone's largest band allows.
    Overweight {
        /// The parcel's weight in grams.
        grams: u32,
        /// The largest `band_max_grams` available for the zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => f.write_str("rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}
