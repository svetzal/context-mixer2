//! Human-facing labels for shipping zones.

/// Return a display label for a zone identifier, falling back to the identifier
/// itself for zones without a friendly name.
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}
