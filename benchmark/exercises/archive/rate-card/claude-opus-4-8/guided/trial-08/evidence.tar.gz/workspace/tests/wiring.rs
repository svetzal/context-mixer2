//! Wiring tests: exercise the public [`ratecard::quote`] through the real
//! `RATECARD_PATH` environment variable and filesystem shell.
//!
//! `RATECARD_PATH` is process-global, so all env-dependent assertions live in a
//! single `#[test]` that runs them sequentially; this avoids races with the
//! parallel test runner.

#![allow(clippy::unwrap_used, clippy::expect_used)]

use ratecard::{quote, Parcel, QuoteError};
use std::io::Write;

const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_string(),
    }
}

#[test]
fn quote_reads_the_card_from_the_environment() {
    let mut file = tempfile::NamedTempFile::new().unwrap();
    file.write_all(CARD.as_bytes()).unwrap();
    let path = file.path().to_owned();

    // Safe here: this is the only test that touches RATECARD_PATH.
    std::env::set_var("RATECARD_PATH", &path);

    let domestic = quote(&parcel(750, "domestic")).unwrap();
    assert_eq!(domestic.base_cents, 899);
    assert_eq!(domestic.band_max_grams, 2000);
    assert_eq!(domestic.total_cents, 899);

    let heavy = quote(&parcel(15_000, "international")).unwrap();
    assert_eq!(heavy.base_cents, 4999);
    assert_eq!(heavy.surcharge_cents, 1500);
    assert_eq!(heavy.total_cents, 6499);

    let unknown = quote(&parcel(100, "lunar")).unwrap_err();
    assert_eq!(unknown, QuoteError::UnknownZone("lunar".to_string()));

    let overweight = quote(&parcel(25_000, "domestic")).unwrap_err();
    assert_eq!(
        overweight,
        QuoteError::Overweight {
            grams: 25_000,
            limit: 20_000,
        }
    );

    std::env::set_var("RATECARD_PATH", "/no/such/rate/card/file");
    let missing = quote(&parcel(750, "domestic")).unwrap_err();
    assert_eq!(missing, QuoteError::RateCardUnavailable);

    std::env::remove_var("RATECARD_PATH");
    let unset = quote(&parcel(750, "domestic")).unwrap_err();
    assert_eq!(unset, QuoteError::RateCardUnavailable);
}
