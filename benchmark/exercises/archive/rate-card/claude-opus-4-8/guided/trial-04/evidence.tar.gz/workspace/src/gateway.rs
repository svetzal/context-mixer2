//! The rate-card source gateway: a project-owned contract over the
//! environment and filesystem effects the pricing core must not touch.
//!
//! The core depends on [`RateCardSource`], not on `std::env` or `std::fs`
//! directly, so tests can supply an in-memory fake instead of a real file.

use std::path::PathBuf;

use crate::model::QuoteError;

/// The environment variable naming the rate-card file.
pub const RATECARD_PATH_VAR: &str = "RATECARD_PATH";

/// A source of raw rate-card text.
///
/// Any failure to obtain the text collapses to
/// [`QuoteError::RateCardUnavailable`]; parsing is the caller's concern.
pub trait RateCardSource {
    /// Load the rate card's raw text, or report it unavailable.
    fn load(&self) -> Result<String, QuoteError>;
}

/// Reads the rate card from the file named by `RATECARD_PATH`.
#[derive(Debug, Default, Clone)]
pub struct EnvFileRateCard;

impl EnvFileRateCard {
    /// Construct a source that resolves the path from the environment on each
    /// [`load`](RateCardSource::load).
    pub fn new() -> Self {
        EnvFileRateCard
    }
}

impl RateCardSource for EnvFileRateCard {
    fn load(&self) -> Result<String, QuoteError> {
        let path: PathBuf = std::env::var_os(RATECARD_PATH_VAR)
            .ok_or(QuoteError::RateCardUnavailable)?
            .into();
        std::fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// An in-memory fake standing in for a real file, used by tests to
    /// exercise the core without I/O.
    struct InMemory(Result<String, QuoteError>);

    impl RateCardSource for InMemory {
        fn load(&self) -> Result<String, QuoteError> {
            self.0.clone()
        }
    }

    #[test]
    fn fake_yields_its_text() {
        let source = InMemory(Ok("domestic\t500\t599".to_owned()));
        assert_eq!(source.load().unwrap(), "domestic\t500\t599");
    }

    #[test]
    fn fake_can_report_unavailable() {
        let source = InMemory(Err(QuoteError::RateCardUnavailable));
        assert_eq!(source.load().unwrap_err(), QuoteError::RateCardUnavailable);
    }
}
