//! Human-friendly labels for the zones the rate card recognises.

/// A display label for a zone, falling back to the zone's own name.
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}
