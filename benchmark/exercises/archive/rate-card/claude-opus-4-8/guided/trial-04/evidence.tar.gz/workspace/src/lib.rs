//! `ratecard` prices shipping parcels against a zone-based rate card.
//!
//! The public entry point is [`quote`]. It reads a tab-separated rate card
//! from the file named by the `RATECARD_PATH` environment variable, selects
//! the matching band for the parcel's weight, applies surcharges, and
//! returns a [`Quote`].
//!
//! The design keeps the pricing rules pure ([`pricing`]) and confines the
//! environment and filesystem effects to a [`gateway`] that the core talks to
//! through the [`gateway::RateCardSource`] contract.
//!
//! ```no_run
//! use ratecard::{quote, Parcel};
//!
//! let parcel = Parcel { weight_grams: 750, zone: "domestic".to_owned() };
//! match quote(&parcel) {
//!     Ok(q) => println!("total: {} cents", q.total_cents),
//!     Err(e) => eprintln!("no quote: {e}"),
//! }
//! ```

pub mod gateway;
pub mod pricing;
pub mod zones;

mod model;

pub use model::{Parcel, Quote, QuoteError};

use gateway::{EnvFileRateCard, RateCardSource};
use pricing::RateCard;

/// Price a parcel using the rate card named by `RATECARD_PATH`.
///
/// # Errors
///
/// Returns [`QuoteError`] when the rate card is unavailable or malformed, the
/// zone is unknown, or the parcel is overweight for its zone. See the crate
/// docs for the full behaviour.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_with(parcel, &EnvFileRateCard::new())
}

/// Price a parcel against an explicit rate-card source.
///
/// This is the seam the pure core is wired through: production calls it with
/// [`EnvFileRateCard`], tests with an in-memory fake. It performs the load,
/// delegates pricing to [`RateCard`], and emits the per-call diagnostic.
///
/// # Errors
///
/// Propagates any [`QuoteError`] from loading, parsing, or pricing.
pub fn quote_with(parcel: &Parcel, source: &dyn RateCardSource) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "quote",
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
    );
    let _guard = span.enter();

    let result = source
        .load()
        .and_then(|text| RateCard::parse(&text))
        .and_then(|card| card.quote(parcel));

    match &result {
        Ok(quote) => tracing::info!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            total_cents = quote.total_cents,
            "quoted parcel",
        ),
        Err(error) => tracing::warn!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            error = %error,
            "quote failed",
        ),
    }

    result
}
