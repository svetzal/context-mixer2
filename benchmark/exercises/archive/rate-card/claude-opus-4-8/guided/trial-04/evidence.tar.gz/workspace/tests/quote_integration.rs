//! Cross-module wiring tests: drive `quote_with` end to end against a real
//! temporary rate-card file, and check the `RATECARD_PATH` gateway.
//!
//! These cover the imperative shell (env + filesystem) that the inline unit
//! tests in `pricing` deliberately avoid.

use std::io::Write;
use std::sync::Mutex;

use ratecard::gateway::{EnvFileRateCard, RateCardSource};
use ratecard::{quote_with, Parcel, QuoteError};

/// Serializes tests that mutate the shared `RATECARD_PATH` environment
/// variable, since Rust runs tests in parallel by default.
static ENV_LOCK: Mutex<()> = Mutex::new(());

const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

/// A test double implementing the project-owned edge contract, not any
/// library internal.
struct FixedText(String);

impl RateCardSource for FixedText {
    fn load(&self) -> Result<String, QuoteError> {
        Ok(self.0.clone())
    }
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_owned(),
    }
}

#[test]
fn prices_a_domestic_parcel_through_the_shell() {
    let source = FixedText(SAMPLE.to_owned());
    let quote = quote_with(&parcel(750, "domestic"), &source).unwrap();
    assert_eq!(quote.base_cents, 899);
    assert_eq!(quote.total_cents, 899);
    assert_eq!(quote.band_max_grams, 2000);
}

#[test]
fn reads_the_card_from_the_ratecard_path_file() {
    let _lock = ENV_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());

    let mut file = tempfile::NamedTempFile::new().unwrap();
    file.write_all(SAMPLE.as_bytes()).unwrap();

    let previous = std::env::var_os("RATECARD_PATH");
    std::env::set_var("RATECARD_PATH", file.path());

    let quote = quote_with(&parcel(500, "international"), &EnvFileRateCard::new());

    match previous {
        Some(value) => std::env::set_var("RATECARD_PATH", value),
        None => std::env::remove_var("RATECARD_PATH"),
    }

    let quote = quote.unwrap();
    assert_eq!(quote.base_cents, 1499);
    assert_eq!(quote.surcharge_cents, 300);
    assert_eq!(quote.total_cents, 1799);
}

#[test]
fn missing_file_is_rate_card_unavailable() {
    let _lock = ENV_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());

    let source = EnvFileRateCard::new();

    let previous = std::env::var_os("RATECARD_PATH");
    std::env::set_var("RATECARD_PATH", "/no/such/rate/card/file.tsv");

    let result = quote_with(&parcel(100, "domestic"), &source);

    match previous {
        Some(value) => std::env::set_var("RATECARD_PATH", value),
        None => std::env::remove_var("RATECARD_PATH"),
    }

    assert_eq!(result.unwrap_err(), QuoteError::RateCardUnavailable);
}

#[test]
fn overweight_propagates_through_the_shell() {
    let source = FixedText(SAMPLE.to_owned());
    let err = quote_with(&parcel(25_000, "international"), &source).unwrap_err();
    assert_eq!(
        err,
        QuoteError::Overweight {
            grams: 25_000,
            limit: 20_000,
        }
    );
}
