//! Pure pricing logic: parse a rate card from text and price a parcel.
//!
//! Nothing in this module touches the filesystem, the environment, or the
//! clock, so every rule can be exercised deterministically from a string.

use crate::model::{Parcel, Quote, QuoteError};

/// Weight strictly above this many grams attracts the heavy surcharge.
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
/// The flat surcharge, in cents, for a heavy parcel.
const HEAVY_SURCHARGE_CENTS: u64 = 500;
/// The zone whose base price attracts a proportional surcharge.
const SURCHARGED_ZONE: &str = "international";

/// One priced band: everything up to `max_grams` costs `cents`.
#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// A parsed rate card: bands grouped by zone, each group sorted ascending.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RateCard {
    zones: Vec<(String, Vec<Band>)>,
}

impl RateCard {
    /// Parse a tab-separated rate card.
    ///
    /// Empty lines and lines beginning with `#` are ignored. Every other
    /// line must be exactly three tab-separated fields
    /// (`zone`, `band_max_grams`, `cents`) with parseable numbers, else the
    /// 1-based line number is reported as [`QuoteError::MalformedRateCard`].
    ///
    /// ```
    /// use ratecard::pricing::RateCard;
    /// use ratecard::Parcel;
    /// let card = RateCard::parse("domestic\t500\t599").unwrap();
    /// let parcel = Parcel { weight_grams: 400, zone: "domestic".to_owned() };
    /// assert_eq!(card.quote(&parcel).unwrap().base_cents, 599);
    /// ```
    pub fn parse(text: &str) -> Result<Self, QuoteError> {
        let mut zones: Vec<(String, Vec<Band>)> = Vec::new();

        for (index, raw) in text.lines().enumerate() {
            let line_no = index + 1;
            let trimmed = raw.trim_end_matches(['\r', '\n']);
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }

            let mut fields = trimmed.split('\t');
            let (Some(zone), Some(max), Some(cents), None) =
                (fields.next(), fields.next(), fields.next(), fields.next())
            else {
                return Err(QuoteError::MalformedRateCard { line: line_no });
            };

            let max_grams: u32 = max
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
            let cents: u64 = cents
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;

            let band = Band { max_grams, cents };
            match zones.iter_mut().find(|(name, _)| name == zone) {
                Some((_, bands)) => bands.push(band),
                None => zones.push((zone.to_owned(), vec![band])),
            }
        }

        for (_, bands) in &mut zones {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(RateCard { zones })
    }

    /// The bands for a zone, ascending by `max_grams`, if the zone exists.
    fn zone(&self, zone: &str) -> Option<&[Band]> {
        self.zones
            .iter()
            .find(|(name, _)| name == zone)
            .map(|(_, bands)| bands.as_slice())
    }

    /// Price a parcel against this rate card.
    ///
    /// See the crate-level rules for band selection and surcharges.
    pub fn quote(&self, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let bands = self
            .zone(&parcel.zone)
            .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

        // A parsed zone always has at least one band, but guard rather than
        // index blindly so the function stays panic-free.
        let limit = match bands.last() {
            Some(band) => band.max_grams,
            None => return Err(QuoteError::UnknownZone(parcel.zone.clone())),
        };

        let band = bands
            .iter()
            .find(|band| band.max_grams >= parcel.weight_grams)
            .ok_or(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            })?;

        let base_cents = band.cents;
        let surcharge_cents =
            heavy_surcharge(parcel.weight_grams) + zone_surcharge(&parcel.zone, base_cents);

        Ok(Quote {
            base_cents,
            surcharge_cents,
            total_cents: base_cents + surcharge_cents,
            band_max_grams: band.max_grams,
        })
    }
}

/// The flat surcharge for parcels heavier than the threshold.
fn heavy_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > HEAVY_THRESHOLD_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    }
}

/// 20% of the base price for the surcharged zone, rounded half-up to the cent.
fn zone_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == SURCHARGED_ZONE {
        // 20% is base_cents * 20 / 100; adding 50 before the integer divide
        // rounds halves up.
        (base_cents * 20 + 50) / 100
    } else {
        0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999";

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_owned(),
        }
    }

    #[test]
    fn matches_first_band_at_or_above_weight() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let quote = card.quote(&parcel(500, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
    }

    #[test]
    fn selects_next_band_when_over_lower_threshold() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let quote = card.quote(&parcel(501, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn heavy_parcel_adds_flat_surcharge() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let quote = card.quote(&parcel(10_001, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn ten_thousand_grams_is_not_heavy() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let quote = card.quote(&parcel(10_000, "domestic")).unwrap();
        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_percentage_rounded_half_up() {
        let card = RateCard::parse(SAMPLE).unwrap();
        // 20% of 1499 = 299.8 -> 300.
        let quote = card.quote(&parcel(500, "international")).unwrap();
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn international_and_heavy_surcharges_add() {
        let card = RateCard::parse(SAMPLE).unwrap();
        // base 4999, heavy 500, zone 20% of 4999 = 999.8 -> 1000.
        let quote = card.quote(&parcel(15_000, "international")).unwrap();
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_carries_requested_zone() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let err = card.quote(&parcel(100, "lunar")).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".to_owned()));
    }

    #[test]
    fn overweight_reports_largest_band_as_limit() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let err = card.quote(&parcel(20_001, "domestic")).unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            }
        );
    }

    #[test]
    fn comments_and_blanks_are_ignored_but_counted() {
        let text = "# header\n\ndomestic\t500\t599\n\n# note\nbad line here";
        // "bad line here" is line 6.
        let err = RateCard::parse(text).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 6 });
    }

    #[test]
    fn wrong_field_count_is_malformed() {
        let err = RateCard::parse("domestic\t500").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn non_numeric_field_is_malformed() {
        let err = RateCard::parse("domestic\theavy\t599").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn bands_out_of_order_are_still_sorted() {
        let card = RateCard::parse("z\t2000\t899\nz\t500\t599").unwrap();
        let quote = card.quote(&parcel(400, "z")).unwrap();
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.base_cents, 599);
    }
}
