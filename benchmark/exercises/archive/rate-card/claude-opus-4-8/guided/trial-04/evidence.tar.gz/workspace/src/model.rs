//! Public data types for the shipping-quote contract.
//!
//! These types are pure values with no behaviour beyond formatting; the
//! pricing rules live in [`crate::pricing`] and the I/O shell in
//! [`crate`].

use std::fmt;

/// A parcel to be quoted: its billed weight and destination zone.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Billed weight in grams.
    pub weight_grams: u32,
    /// Destination zone, matched against the rate card's zone column.
    pub zone: String,
}

/// The priced result of a successful [`quote`](crate::quote).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// The matching band's price, before surcharges.
    pub base_cents: u64,
    /// The sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// The `band_max_grams` threshold of the matching band.
    pub band_max_grams: u32,
}

/// Every way a quote can fail.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card path was unset, missing, or unreadable.
    RateCardUnavailable,
    /// A rate-card line was not three tab-separated fields, or its numbers
    /// did not parse. Carries the 1-based line number of the offending line.
    MalformedRateCard {
        /// 1-based line number, counting comments and blank lines.
        line: usize,
    },
    /// The requested zone is absent from the rate card. Carries that zone.
    UnknownZone(String),
    /// The weight exceeds the zone's largest band.
    Overweight {
        /// The requested weight, in grams.
        grams: u32,
        /// The largest `band_max_grams` available for the zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => f.write_str("rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}
