//! Human-facing labels for delivery zones.

/// Map a rate-card zone name to a human-readable label.
///
/// Unknown zones are returned unchanged, so display never fails.
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}
