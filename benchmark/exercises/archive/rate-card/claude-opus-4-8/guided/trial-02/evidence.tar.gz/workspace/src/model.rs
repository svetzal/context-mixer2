//! Public data types for shipping quotes.
//!
//! These types are the crate's stable contract. They carry no behaviour of
//! their own beyond error formatting, keeping the domain vocabulary free of
//! I/O and orchestration concerns.

use std::fmt;

/// A parcel awaiting a shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Gross weight of the parcel, in grams.
    pub weight_grams: u32,
    /// Delivery zone name, matched against the rate card verbatim.
    pub zone: String,
}

/// The priced result of quoting a [`Parcel`] against the rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// The matched band's price, in cents.
    pub base_cents: u64,
    /// Additional charges applied on top of the base, in cents.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`, in cents.
    pub total_cents: u64,
    /// The upper weight threshold of the matched band, in grams.
    pub band_max_grams: u32,
}

/// The ways quoting can fail.
///
/// Every variant is a recoverable condition surfaced to the caller rather than
/// a panic, so embedding applications choose their own recovery policy.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card could not be located or read (missing, unreadable, or an
    /// unset `RATECARD_PATH`).
    RateCardUnavailable,
    /// A rate-card line was not three tab-separated fields, or its numbers did
    /// not parse. Carries the 1-based line number of the offending line.
    MalformedRateCard {
        /// 1-based line number, counting comments and blanks.
        line: usize,
    },
    /// The requested zone is absent from the rate card. Carries the requested
    /// zone name.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight {
        /// The parcel's weight, in grams.
        grams: u32,
        /// The largest band's upper threshold for the zone, in grams.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}
