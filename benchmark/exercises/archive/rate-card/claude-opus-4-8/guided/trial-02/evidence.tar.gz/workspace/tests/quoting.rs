//! Integration tests: the shell wiring, the gateway seam, and the real
//! `RATECARD_PATH` adapter, exercised through the crate's public surface.

// Test code deliberately uses unwrap/panic to assert.
#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

use std::io::Write;
use std::sync::{Mutex, MutexGuard, OnceLock};

use ratecard::{
    quote, quote_with_source, Parcel, QuoteError, RateCardSource, SourceUnavailable,
};
use tempfile::NamedTempFile;

const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999";

/// An in-memory rate-card source for driving the shell without any I/O.
struct FixedSource(Result<String, SourceUnavailable>);

impl RateCardSource for FixedSource {
    fn load(&self) -> Result<String, SourceUnavailable> {
        self.0.clone()
    }
}

fn text_source(text: &str) -> FixedSource {
    FixedSource(Ok(text.to_string()))
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_string(),
    }
}

// `RATECARD_PATH` is process-global; serialize the env-touching tests.
fn env_lock() -> MutexGuard<'static, ()> {
    static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    match LOCK.get_or_init(|| Mutex::new(())).lock() {
        Ok(guard) => guard,
        Err(poisoned) => poisoned.into_inner(),
    }
}

#[test]
fn shell_prices_a_domestic_parcel() {
    let quote = quote_with_source(&text_source(CARD), &parcel(1500, "domestic")).unwrap();
    assert_eq!(quote.base_cents, 899);
    assert_eq!(quote.band_max_grams, 2000);
    assert_eq!(quote.surcharge_cents, 0);
    assert_eq!(quote.total_cents, 899);
}

#[test]
fn shell_prices_an_international_parcel_with_surcharge() {
    let quote = quote_with_source(&text_source(CARD), &parcel(400, "international")).unwrap();
    assert_eq!(quote.base_cents, 1499);
    assert_eq!(quote.surcharge_cents, 300);
    assert_eq!(quote.total_cents, 1799);
}

#[test]
fn unavailable_source_maps_to_rate_card_unavailable() {
    let source = FixedSource(Err(SourceUnavailable));
    let err = quote_with_source(&source, &parcel(100, "domestic")).unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn malformed_line_propagates_through_the_shell() {
    let err = quote_with_source(&text_source("domestic\t500\n"), &parcel(100, "domestic"))
        .unwrap_err();
    assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
}

#[test]
fn error_type_is_std_error_and_displays() {
    let err = quote_with_source(&text_source(CARD), &parcel(100, "lunar")).unwrap_err();
    // Usable as a boxed std::error::Error.
    let boxed: Box<dyn std::error::Error> = Box::new(err);
    assert_eq!(boxed.to_string(), "unknown zone: lunar");
}

#[test]
fn real_adapter_reads_ratecard_path() {
    let _guard = env_lock();
    let mut file = NamedTempFile::new().unwrap();
    file.write_all(CARD.as_bytes()).unwrap();

    std::env::set_var("RATECARD_PATH", file.path());
    let result = quote(&parcel(100, "domestic"));
    std::env::remove_var("RATECARD_PATH");

    let quote = result.unwrap();
    assert_eq!(quote.base_cents, 599);
    assert_eq!(quote.total_cents, 599);
}

#[test]
fn unset_ratecard_path_is_unavailable() {
    let _guard = env_lock();
    std::env::remove_var("RATECARD_PATH");
    let err = quote(&parcel(100, "domestic")).unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn missing_ratecard_file_is_unavailable() {
    let _guard = env_lock();
    std::env::set_var("RATECARD_PATH", "/no/such/ratecard/file.tsv");
    let err = quote(&parcel(100, "domestic")).unwrap_err();
    std::env::remove_var("RATECARD_PATH");
    assert_eq!(err, QuoteError::RateCardUnavailable);
}
