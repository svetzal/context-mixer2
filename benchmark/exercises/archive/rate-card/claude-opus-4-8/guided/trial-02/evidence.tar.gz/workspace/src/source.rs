//! The rate-card source gateway.
//!
//! The pure core prices parsed text; something must fetch that text. This
//! gateway trait is the project-owned contract for that fetch, so the core and
//! its tests depend on an interface rather than on concrete filesystem and
//! environment access. The real adapter reads a file named by `RATECARD_PATH`;
//! tests supply an in-memory implementation.

/// The rate-card text could not be obtained.
///
/// Distinct from [`crate::QuoteError`] so the gateway owns its own edge
/// vocabulary; the shell maps this to [`crate::QuoteError::RateCardUnavailable`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SourceUnavailable;

/// A source of rate-card text.
pub trait RateCardSource {
    /// Fetch the full rate-card text, or report that it is unavailable.
    fn load(&self) -> Result<String, SourceUnavailable>;
}

/// The production adapter: reads the file named by the `RATECARD_PATH`
/// environment variable.
///
/// An unset variable, a missing file, or any read error all map to
/// [`SourceUnavailable`]; the shell surfaces them uniformly as
/// [`crate::QuoteError::RateCardUnavailable`].
#[derive(Debug, Default, Clone, Copy)]
pub struct EnvRateCardSource;

impl RateCardSource for EnvRateCardSource {
    fn load(&self) -> Result<String, SourceUnavailable> {
        let path = std::env::var_os("RATECARD_PATH").ok_or(SourceUnavailable)?;
        std::fs::read_to_string(path).map_err(|_| SourceUnavailable)
    }
}
