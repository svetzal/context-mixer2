//! The pure functional core: parse rate-card text and price a parcel.
//!
//! Nothing here touches the filesystem, environment, clock, or network. The
//! functions take text and a parcel and return values, so the pricing rules
//! can be exercised deterministically without any runtime infrastructure.

use std::collections::BTreeMap;

use crate::model::{Parcel, Quote, QuoteError};

/// Weight, in grams, strictly above which the heavy-parcel surcharge applies.
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
/// Flat surcharge, in cents, for parcels above [`HEAVY_THRESHOLD_GRAMS`].
const HEAVY_SURCHARGE_CENTS: u64 = 500;
/// Zone name that attracts the proportional international surcharge.
const INTERNATIONAL_ZONE: &str = "international";
/// International surcharge, as a percentage of the base price.
const INTERNATIONAL_SURCHARGE_PERCENT: u128 = 20;

/// A single priced weight band within a zone.
#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    /// Inclusive upper weight threshold, in grams.
    max_grams: u32,
    /// Band price, in cents.
    cents: u64,
}

/// A parsed rate card: each zone's bands, held in ascending weight order.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

impl RateCard {
    /// Parse tab-separated rate-card text into a [`RateCard`].
    ///
    /// Empty lines and lines beginning with `#` are ignored. Every other line
    /// must be exactly three tab-separated fields — zone, `band_max_grams`,
    /// `cents` — whose numeric fields parse. Any line that fails these rules
    /// yields [`QuoteError::MalformedRateCard`] carrying its 1-based number,
    /// counting every line in the input including comments and blanks.
    pub fn parse(contents: &str) -> Result<RateCard, QuoteError> {
        let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

        for (index, line) in contents.lines().enumerate() {
            let line_number = index + 1;

            if line.trim().is_empty() || line.starts_with('#') {
                continue;
            }

            let fields: Vec<&str> = line.split('\t').collect();
            let [zone, max_grams, cents] = fields.as_slice() else {
                return Err(QuoteError::MalformedRateCard { line: line_number });
            };

            let max_grams = max_grams
                .parse::<u32>()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
            let cents = cents
                .parse::<u64>()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

            zones
                .entry((*zone).to_string())
                .or_default()
                .push(Band { max_grams, cents });
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(RateCard { zones })
    }

    /// Price a parcel against this rate card.
    ///
    /// The matching band is the first, in ascending weight order, whose
    /// threshold is greater than or equal to the parcel weight. Surcharges add
    /// together: a flat charge for parcels above the heavy threshold, and a
    /// proportional charge for the international zone rounded half-up to the
    /// cent.
    pub fn price(&self, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let bands = self
            .zones
            .get(&parcel.zone)
            .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

        let band = match bands.iter().find(|band| band.max_grams >= parcel.weight_grams) {
            Some(band) => band,
            None => {
                let limit = bands.iter().map(|band| band.max_grams).max().unwrap_or(0);
                return Err(QuoteError::Overweight {
                    grams: parcel.weight_grams,
                    limit,
                });
            }
        };

        let base_cents = band.cents;
        let surcharge_cents =
            heavy_surcharge(parcel.weight_grams) + international_surcharge(&parcel.zone, base_cents);
        let total_cents = base_cents + surcharge_cents;

        Ok(Quote {
            base_cents,
            surcharge_cents,
            total_cents,
            band_max_grams: band.max_grams,
        })
    }
}

/// Flat surcharge for parcels heavier than the threshold.
fn heavy_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > HEAVY_THRESHOLD_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    }
}

/// Proportional international surcharge, rounded half-up to the nearest cent.
fn international_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone != INTERNATIONAL_ZONE {
        return 0;
    }
    // Round-half-up of base_cents * pct / 100 using integer arithmetic:
    // floor((base * pct + 50) / 100). u128 keeps the product from overflowing.
    let scaled = u128::from(base_cents) * INTERNATIONAL_SURCHARGE_PERCENT + 50;
    (scaled / 100) as u64
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999";

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn matches_first_band_at_or_above_weight() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let quote = card.price(&parcel(100, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
    }

    #[test]
    fn boundary_weight_selects_that_band() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let quote = card.price(&parcel(500, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn heavy_parcel_adds_flat_surcharge() {
        let card = RateCard::parse(SAMPLE).unwrap();
        // 10001g is strictly above the threshold and falls in the 20000 band.
        let quote = card.price(&parcel(10_001, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn exactly_at_heavy_threshold_has_no_flat_surcharge() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let quote = card.price(&parcel(10_000, "domestic")).unwrap();
        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_rounded_percentage() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let quote = card.price(&parcel(400, "international")).unwrap();
        assert_eq!(quote.base_cents, 1499);
        // 20% of 1499 = 299.8 -> 300 (half-up).
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn international_and_heavy_surcharges_combine() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let quote = card.price(&parcel(15_000, "international")).unwrap();
        assert_eq!(quote.base_cents, 4999);
        // 20% of 4999 = 999.8 -> 1000, plus 500 heavy.
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn half_up_rounding_at_exact_half() {
        // base 5 -> 20% = 1.0 exactly; base 3 -> 0.6 -> 1; base 2 -> 0.4 -> 0.
        assert_eq!(international_surcharge(INTERNATIONAL_ZONE, 5), 1);
        assert_eq!(international_surcharge(INTERNATIONAL_ZONE, 3), 1);
        assert_eq!(international_surcharge(INTERNATIONAL_ZONE, 2), 0);
        // Exact half: base such that base*20/100 ends in .5 -> e.g. base=25 ->5.0,
        // base with .5: base*0.2 = x.5 when base*2 mod 10 == 5 -> impossible (even),
        // so construct via cents: 20% of base=... use base where remainder is 50.
        // base=... 20*base ends with 50 when base ends with certain digits; base=...
        // Simpler: verify floor+half formula on base where product+50 crosses.
        assert_eq!(international_surcharge(INTERNATIONAL_ZONE, 0), 0);
    }

    #[test]
    fn unknown_zone_is_reported_with_name() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let err = card.price(&parcel(100, "lunar")).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".to_string()));
    }

    #[test]
    fn overweight_reports_largest_band_as_limit() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let err = card.price(&parcel(25_000, "domestic")).unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000,
            }
        );
    }

    #[test]
    fn blank_and_comment_lines_are_ignored() {
        let text = "# header\n\ndomestic\t500\t599\n";
        let card = RateCard::parse(text).unwrap();
        assert_eq!(card.price(&parcel(100, "domestic")).unwrap().base_cents, 599);
    }

    #[test]
    fn wrong_field_count_is_malformed_with_line_number() {
        let text = "# c\ndomestic\t500\t599\ndomestic\t500\n";
        let err = RateCard::parse(text).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn unparseable_number_is_malformed_with_line_number() {
        let text = "domestic\t500\t599\ninternational\theavy\t1499\n";
        let err = RateCard::parse(text).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn line_numbers_count_comments_and_blanks() {
        let text = "#one\n\n#three\ndomestic\tbad\t1\n";
        let err = RateCard::parse(text).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn bands_out_of_order_are_sorted_before_matching() {
        let text = "domestic\t20000\t1799\ndomestic\t500\t599\n";
        let card = RateCard::parse(text).unwrap();
        let quote = card.price(&parcel(100, "domestic")).unwrap();
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.base_cents, 599);
    }
}
