//! Shipping-rate quotes from a zone rate card.
//!
//! The crate is split into a pure functional core and a thin imperative shell.
//! [`RateCard`] parses rate-card text and prices a [`Parcel`] with no I/O; the
//! [`RateCardSource`] gateway fetches that text; and [`quote`] wires them
//! together, mapping gateway failures and emitting one diagnostic record per
//! call.
//!
//! # Example
//!
//! Pricing against an in-memory source, without touching the filesystem:
//!
//! ```
//! use ratecard::{quote_with_source, Parcel, RateCardSource, SourceUnavailable};
//!
//! struct InMemory(&'static str);
//! impl RateCardSource for InMemory {
//!     fn load(&self) -> Result<String, SourceUnavailable> {
//!         Ok(self.0.to_string())
//!     }
//! }
//!
//! let card = "domestic\t500\t599\ndomestic\t20000\t1799";
//! let parcel = Parcel { weight_grams: 100, zone: "domestic".to_string() };
//! let q = quote_with_source(&InMemory(card), &parcel).unwrap();
//! assert_eq!(q.base_cents, 599);
//! assert_eq!(q.total_cents, 599);
//! ```

// Test code deliberately uses unwrap/panic to assert; the restriction lints
// target recoverable paths in production code only.
#![cfg_attr(test, allow(clippy::unwrap_used, clippy::expect_used, clippy::panic))]

mod model;
mod rate_card;
mod source;
pub mod zones;

pub use model::{Parcel, Quote, QuoteError};
pub use rate_card::RateCard;
pub use source::{EnvRateCardSource, RateCardSource, SourceUnavailable};

/// Quote a parcel against the rate card named by `RATECARD_PATH`.
///
/// Reads the rate card from the file path in the `RATECARD_PATH` environment
/// variable, parses it, and prices `parcel`. A missing, unreadable, or unset
/// path yields [`QuoteError::RateCardUnavailable`].
///
/// See the [crate-level documentation](crate) for the full pricing rules and an
/// example that avoids the filesystem.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_with_source(&EnvRateCardSource, parcel)
}

/// Quote a parcel against a rate card obtained from an explicit source.
///
/// This is the shell's testable seam: it maps [`SourceUnavailable`] to
/// [`QuoteError::RateCardUnavailable`], delegates parsing and pricing to the
/// pure core, and emits one structured diagnostic record per call carrying the
/// zone, weight, and resulting total.
pub fn quote_with_source<S: RateCardSource>(
    source: &S,
    parcel: &Parcel,
) -> Result<Quote, QuoteError> {
    let contents = source
        .load()
        .map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = RateCard::parse(&contents)?;
    let result = card.price(parcel);

    match &result {
        Ok(quote) => tracing::info!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            total_cents = quote.total_cents,
            "quote calculated"
        ),
        Err(error) => tracing::warn!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            error = %error,
            "quote failed"
        ),
    }

    result
}
