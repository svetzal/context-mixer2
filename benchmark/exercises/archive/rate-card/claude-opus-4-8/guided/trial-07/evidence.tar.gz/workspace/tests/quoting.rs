//! Cross-module behaviour: driving the whole quote flow through the
//! [`RateCardSource`] gateway with an in-memory card, and observing the
//! diagnostic each call emits.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

use ratecard::{Parcel, QuoteError, RateCardSource};
use tracing::field::{Field, Visit};
use tracing::subscriber::with_default;
use tracing_subscriber::layer::{Context, Layer};
use tracing_subscriber::prelude::*;

const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

/// An in-memory rate-card source: a project-owned fake at the gateway edge, so
/// the flow is exercised with no filesystem or environment.
struct InMemorySource {
    text: Result<String, QuoteError>,
}

impl InMemorySource {
    fn with(text: &str) -> Self {
        Self {
            text: Ok(text.to_owned()),
        }
    }

    fn unavailable() -> Self {
        Self {
            text: Err(QuoteError::RateCardUnavailable),
        }
    }
}

impl RateCardSource for InMemorySource {
    fn load(&self) -> Result<String, QuoteError> {
        self.text.clone()
    }
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_owned(),
    }
}

#[test]
fn prices_end_to_end_through_the_gateway() {
    let source = InMemorySource::with(SAMPLE);
    let quote = ratecard::quote_with(&source, &parcel(1500, "domestic")).unwrap();
    assert_eq!(quote.base_cents, 899);
    assert_eq!(quote.band_max_grams, 2000);
    assert_eq!(quote.total_cents, 899);
}

#[test]
fn source_failure_surfaces_as_unavailable() {
    let source = InMemorySource::unavailable();
    let err = ratecard::quote_with(&source, &parcel(100, "domestic")).unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn malformed_card_from_source_surfaces_with_line() {
    let source = InMemorySource::with("domestic\t500\t599\nbroken line\n");
    let err = ratecard::quote_with(&source, &parcel(100, "domestic")).unwrap_err();
    assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
}

/// Captures the structured fields of every event a subscriber sees.
#[derive(Clone, Default)]
struct FieldCapture {
    events: Arc<Mutex<Vec<HashMap<String, String>>>>,
}

struct FieldVisitor(HashMap<String, String>);

impl Visit for FieldVisitor {
    fn record_debug(&mut self, field: &Field, value: &dyn std::fmt::Debug) {
        self.0.insert(field.name().to_owned(), format!("{value:?}"));
    }

    fn record_u64(&mut self, field: &Field, value: u64) {
        self.0.insert(field.name().to_owned(), value.to_string());
    }

    fn record_str(&mut self, field: &Field, value: &str) {
        self.0.insert(field.name().to_owned(), value.to_owned());
    }
}

impl<S: tracing::Subscriber> Layer<S> for FieldCapture {
    fn on_event(&self, event: &tracing::Event<'_>, _ctx: Context<'_, S>) {
        let mut visitor = FieldVisitor(HashMap::new());
        event.record(&mut visitor);
        if let Ok(mut events) = self.events.lock() {
            events.push(visitor.0);
        }
    }
}

#[test]
fn each_call_emits_a_queryable_diagnostic() {
    let capture = FieldCapture::default();
    let subscriber = tracing_subscriber::registry().with(capture.clone());

    with_default(subscriber, || {
        let source = InMemorySource::with(SAMPLE);
        let _ = ratecard::quote_with(&source, &parcel(400, "international")).unwrap();
    });

    let events = capture.events.lock().unwrap();
    let record = events
        .iter()
        .find(|fields| fields.contains_key("zone"))
        .expect("a diagnostic record carrying the zone");

    // The fields are independently queryable, not baked into one string.
    assert_eq!(record.get("zone").map(String::as_str), Some("international"));
    assert_eq!(record.get("weight_grams").map(String::as_str), Some("400"));
    // international, band 500 -> 1499 base; 1499 * 0.20 = 299.8 -> 300; total 1799.
    assert_eq!(record.get("total_cents").map(String::as_str), Some("1799"));
}
