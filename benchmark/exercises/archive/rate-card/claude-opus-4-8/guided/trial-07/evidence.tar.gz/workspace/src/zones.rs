//! Human-readable labels for zone identifiers.

/// The operator-facing label for a zone identifier.
///
/// Unknown zones are returned unchanged, so callers always get a printable
/// name.
///
/// # Examples
///
/// ```
/// assert_eq!(ratecard::zones::zone_label("domestic"), "Domestic ground");
/// assert_eq!(ratecard::zones::zone_label("lunar"), "lunar");
/// ```
#[must_use]
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}
