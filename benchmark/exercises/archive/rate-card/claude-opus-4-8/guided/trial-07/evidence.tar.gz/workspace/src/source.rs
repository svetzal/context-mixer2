//! The rate-card source gateway.
//!
//! Reading the rate card is the crate's one real side effect. It is expressed
//! behind the [`RateCardSource`] trait — a project-owned contract — so the pure
//! pricing core never depends on the environment or the filesystem, and tests
//! can substitute an in-memory source.

use crate::model::QuoteError;

/// A source of rate-card text.
///
/// Implementors own the decision of where the text comes from. The only failure
/// they may report is [`QuoteError::RateCardUnavailable`]: the loaded text is
/// handed to the parser, which owns malformed-content errors.
pub trait RateCardSource {
    /// Load the raw rate-card text, or report that it is unavailable.
    ///
    /// # Errors
    ///
    /// Returns [`QuoteError::RateCardUnavailable`] when the card cannot be
    /// located or read.
    fn load(&self) -> Result<String, QuoteError>;
}

/// The production source: reads the file named by the `RATECARD_PATH`
/// environment variable.
///
/// An unset variable, or a path that cannot be read, both surface as
/// [`QuoteError::RateCardUnavailable`].
#[derive(Debug, Clone, Copy, Default)]
pub struct EnvFileSource;

impl RateCardSource for EnvFileSource {
    fn load(&self) -> Result<String, QuoteError> {
        let path = std::env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
        std::fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}
