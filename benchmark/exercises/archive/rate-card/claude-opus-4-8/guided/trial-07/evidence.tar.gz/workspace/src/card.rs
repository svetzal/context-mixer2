//! Pure rate-card parsing and pricing.
//!
//! Nothing in this module touches the environment, the filesystem, or any
//! clock. A [`RateCard`] is parsed from text and prices a [`Parcel`] by pure
//! computation, so the whole of the pricing policy is testable in memory.

use std::collections::BTreeMap;

use crate::model::{Parcel, Quote, QuoteError};

/// Weight strictly above this many grams attracts the heavy surcharge.
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
/// The flat surcharge, in cents, for a heavy parcel.
const HEAVY_SURCHARGE_CENTS: u64 = 500;
/// The zone whose base price attracts a proportional surcharge.
const INTERNATIONAL_ZONE: &str = "international";
/// Numerator of the international surcharge fraction (20%).
const INTERNATIONAL_NUMERATOR: u64 = 20;
/// Denominator of the international surcharge fraction (20%).
const INTERNATIONAL_DENOMINATOR: u64 = 100;

/// One priced band within a zone.
#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    /// Inclusive upper weight threshold, in grams.
    max_grams: u32,
    /// Base price for parcels falling in this band, in cents.
    cents: u64,
}

/// A parsed rate card: for each zone, its bands in ascending threshold order.
#[derive(Debug, Clone, Default)]
pub struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

impl RateCard {
    /// Parse a tab-separated rate card from text.
    ///
    /// Empty lines and lines beginning with `#` are ignored. Every other line
    /// must be exactly three tab-separated fields — zone, `band_max_grams`,
    /// `cents` — whose numeric fields parse. Any other line yields
    /// [`QuoteError::MalformedRateCard`] carrying its 1-based number, counting
    /// every line in the file including comments and blanks.
    ///
    /// # Errors
    ///
    /// Returns [`QuoteError::MalformedRateCard`] for the first line that is not
    /// three tab-separated fields or whose numbers do not parse.
    ///
    /// # Examples
    ///
    /// ```
    /// use ratecard::RateCard;
    ///
    /// let card = RateCard::parse("domestic\t500\t599\n").unwrap();
    /// assert!(card.has_zone("domestic"));
    /// ```
    pub fn parse(text: &str) -> Result<Self, QuoteError> {
        let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

        for (index, raw) in text.lines().enumerate() {
            let line_number = index + 1;
            let trimmed = raw.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }

            let band = parse_line(raw).ok_or(QuoteError::MalformedRateCard { line: line_number })?;
            zones.entry(band.0).or_default().push(band.1);
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(Self { zones })
    }

    /// Whether the card carries any band for `zone`.
    #[must_use]
    pub fn has_zone(&self, zone: &str) -> bool {
        self.zones.contains_key(zone)
    }

    /// Price a parcel against this card.
    ///
    /// Selects the first band (in ascending threshold order) whose
    /// `band_max_grams` is greater than or equal to the parcel weight, then
    /// applies the heavy and international surcharges.
    ///
    /// # Errors
    ///
    /// Returns [`QuoteError::UnknownZone`] when the parcel's zone is absent, and
    /// [`QuoteError::Overweight`] when the parcel is heavier than the zone's
    /// largest band.
    pub fn price(&self, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let bands = self
            .zones
            .get(&parcel.zone)
            .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

        let band = bands
            .iter()
            .find(|band| band.max_grams >= parcel.weight_grams)
            .ok_or_else(|| QuoteError::Overweight {
                grams: parcel.weight_grams,
                // A parsed zone always has at least one band, so the maximum is
                // well defined.
                limit: bands.iter().map(|band| band.max_grams).max().unwrap_or(0),
            })?;

        let base_cents = band.cents;
        let mut surcharge_cents = 0_u64;

        if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
            surcharge_cents += HEAVY_SURCHARGE_CENTS;
        }

        if parcel.zone == INTERNATIONAL_ZONE {
            surcharge_cents += proportional_surcharge(base_cents);
        }

        Ok(Quote {
            base_cents,
            surcharge_cents,
            total_cents: base_cents + surcharge_cents,
            band_max_grams: band.max_grams,
        })
    }
}

/// Parse a single data line into `(zone, band)`, returning `None` if it is not
/// three tab-separated fields or its numbers do not parse.
fn parse_line(raw: &str) -> Option<(String, Band)> {
    let mut fields = raw.split('\t');
    let zone = fields.next()?;
    let max_grams = fields.next()?;
    let cents = fields.next()?;
    if fields.next().is_some() {
        return None;
    }

    Some((
        zone.to_owned(),
        Band {
            max_grams: max_grams.parse().ok()?,
            cents: cents.parse().ok()?,
        },
    ))
}

/// The international surcharge: 20% of `base_cents`, rounded half-up to the cent.
fn proportional_surcharge(base_cents: u64) -> u64 {
    (base_cents * INTERNATIONAL_NUMERATOR + INTERNATIONAL_DENOMINATOR / 2) / INTERNATIONAL_DENOMINATOR
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_owned(),
        }
    }

    #[test]
    fn matches_first_band_at_or_above_weight() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let quote = card.price(&parcel(500, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
    }

    #[test]
    fn selects_the_next_band_up() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let quote = card.price(&parcel(501, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn heavy_parcel_adds_flat_surcharge() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let quote = card.price(&parcel(10_001, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn exactly_ten_kilos_is_not_heavy() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let quote = card.price(&parcel(10_000, "domestic")).unwrap();
        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_twenty_percent_rounded_half_up() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let quote = card.price(&parcel(500, "international")).unwrap();
        assert_eq!(quote.base_cents, 1499);
        // 1499 * 0.20 = 299.8 -> 300
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn international_and_heavy_surcharges_add_together() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let quote = card.price(&parcel(15_000, "international")).unwrap();
        assert_eq!(quote.base_cents, 4999);
        // 4999 * 0.20 = 999.8 -> 1000, plus 500 heavy.
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_carries_requested_zone() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let err = card.price(&parcel(100, "lunar")).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".to_owned()));
    }

    #[test]
    fn overweight_carries_largest_band_as_limit() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let err = card.price(&parcel(20_001, "domestic")).unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            }
        );
    }

    #[test]
    fn wrong_field_count_is_malformed_with_line_number() {
        let text = "domestic\t500\t599\ndomestic\t2000\n";
        let err = RateCard::parse(text).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn nonnumeric_field_is_malformed() {
        let text = "domestic\theavy\t599\n";
        let err = RateCard::parse(text).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn comments_and_blanks_count_toward_line_numbers() {
        let text = "# header\n\ndomestic\tnope\t599\n";
        let err = RateCard::parse(text).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn bands_out_of_order_are_still_priced_ascending() {
        let text = "domestic\t2000\t899\ndomestic\t500\t599\n";
        let card = RateCard::parse(text).unwrap();
        let quote = card.price(&parcel(400, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }
}
