//! Boundary wiring for the production path: [`ratecard::quote`] reading the
//! file named by `RATECARD_PATH`.
//!
//! These tests mutate a process-global environment variable, so they serialize
//! through a shared lock rather than racing under the test runner's threads.

use std::io::Write;
use std::sync::Mutex;

use ratecard::{Parcel, QuoteError};

static ENV_LOCK: Mutex<()> = Mutex::new(());

const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
international\t20000\t4999
";

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_owned(),
    }
}

#[test]
fn reads_the_card_from_the_env_path() {
    let _guard = ENV_LOCK.lock().unwrap();

    let mut file = tempfile::NamedTempFile::new().unwrap();
    file.write_all(SAMPLE.as_bytes()).unwrap();

    std::env::set_var("RATECARD_PATH", file.path());
    let quote = ratecard::quote(&parcel(400, "domestic"));
    std::env::remove_var("RATECARD_PATH");

    let quote = quote.unwrap();
    assert_eq!(quote.base_cents, 599);
    assert_eq!(quote.total_cents, 599);
}

#[test]
fn unset_path_is_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap();

    std::env::remove_var("RATECARD_PATH");
    let err = ratecard::quote(&parcel(400, "domestic")).unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn missing_file_is_unavailable() {
    let _guard = ENV_LOCK.lock().unwrap();

    std::env::set_var("RATECARD_PATH", "/no/such/rate/card/at/this/path.tsv");
    let err = ratecard::quote(&parcel(400, "domestic")).unwrap_err();
    std::env::remove_var("RATECARD_PATH");

    assert_eq!(err, QuoteError::RateCardUnavailable);
}
