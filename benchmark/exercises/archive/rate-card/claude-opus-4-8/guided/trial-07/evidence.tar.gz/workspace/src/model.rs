//! Public data types for the quoting contract.
//!
//! These are pure value types with no I/O. They form the stable surface the
//! external test suite matches against, so their field names and variants are
//! fixed by [the task contract](crate).

use std::error::Error;
use std::fmt;

/// A parcel to be priced: its weight and the destination zone.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Destination zone name, matched against the rate card.
    pub zone: String,
}

/// A computed shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// The matching band's price, in cents.
    pub base_cents: u64,
    /// Surcharges applied on top of the base, in cents.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// The matching band's upper weight threshold, in grams.
    pub band_max_grams: u32,
}

/// The ways a quote can fail.
///
/// Every variant is a recoverable condition surfaced to the caller rather than
/// a panic, so an embedding application can decide its own recovery policy.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card could not be located or read.
    ///
    /// Covers an unset, missing, or unreadable `RATECARD_PATH`.
    RateCardUnavailable,
    /// A rate-card line was not three tab-separated fields, or its numbers did
    /// not parse.
    ///
    /// `line` is the 1-based number of the offending line, counting every line
    /// in the file including comments and blanks.
    MalformedRateCard {
        /// 1-based line number of the offending line.
        line: usize,
    },
    /// The requested zone is absent from the rate card.
    ///
    /// Carries the zone that was requested.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight {
        /// The parcel's weight in grams.
        grams: u32,
        /// The zone's largest `band_max_grams`.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => f.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl Error for QuoteError {}
