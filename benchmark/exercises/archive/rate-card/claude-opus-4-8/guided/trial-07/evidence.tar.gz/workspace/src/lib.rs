//! Shipping quotes from a zone rate card.
//!
//! [`quote`] prices a [`Parcel`] against a tab-separated rate card read from the
//! path in the `RATECARD_PATH` environment variable. Reading that card is the
//! crate's only side effect; it lives behind the [`RateCardSource`] gateway so
//! the pricing policy in [`RateCard`] stays pure and testable in memory.
//!
//! # Examples
//!
//! ```
//! use ratecard::{Parcel, RateCard};
//!
//! // The pure core prices a parcel without any I/O.
//! let card = RateCard::parse("domestic\t500\t599\n").unwrap();
//! let quote = card
//!     .price(&Parcel { weight_grams: 400, zone: "domestic".to_owned() })
//!     .unwrap();
//! assert_eq!(quote.total_cents, 599);
//! ```

mod card;
mod model;
mod source;
pub mod zones;

pub use card::RateCard;
pub use model::{Parcel, Quote, QuoteError};
pub use source::{EnvFileSource, RateCardSource};

/// Price a parcel against the rate card named by `RATECARD_PATH`.
///
/// Reads the card, parses it, and applies the zone's bands and surcharges. Each
/// successful call emits a `tracing` event carrying the zone, weight, and total
/// as structured fields.
///
/// # Errors
///
/// - [`QuoteError::RateCardUnavailable`] — `RATECARD_PATH` is unset, missing, or
///   unreadable.
/// - [`QuoteError::MalformedRateCard`] — a card line is malformed.
/// - [`QuoteError::UnknownZone`] — the parcel's zone is absent from the card.
/// - [`QuoteError::Overweight`] — the parcel exceeds the zone's largest band.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_with(&EnvFileSource, parcel)
}

/// Price a parcel against a caller-supplied source.
///
/// This is the seam the production [`quote`] is built on: it takes any
/// [`RateCardSource`], so tests drive the whole flow with an in-memory card and
/// no environment or filesystem dependency.
///
/// # Errors
///
/// The same conditions as [`quote`].
pub fn quote_with<S: RateCardSource>(source: &S, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let text = source.load()?;
    let card = RateCard::parse(&text)?;
    let quote = card.price(parcel)?;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = quote.total_cents,
        "priced parcel"
    );

    Ok(quote)
}
