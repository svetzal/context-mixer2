//! Pure pricing logic: parse a rate card and compute a quote.
//!
//! Nothing here performs I/O, reads the environment, or mutates global state,
//! so the whole module is exercisable with plain in-memory strings.

use std::collections::BTreeMap;

use crate::model::{Parcel, Quote, QuoteError};

/// Weight above which the heavy-parcel surcharge applies (strictly greater).
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
/// Flat surcharge, in cents, for parcels above [`HEAVY_THRESHOLD_GRAMS`].
const HEAVY_SURCHARGE_CENTS: u64 = 500;
/// Zone name that attracts the proportional international surcharge.
const INTERNATIONAL_ZONE: &str = "international";
/// International surcharge, as a percentage of the base price.
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

/// One priced weight band within a zone.
#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// A parsed rate card: each zone maps to its bands, sorted ascending by
/// `max_grams`. A zone key is present only if the card named it at least once,
/// so every band list is non-empty.
#[derive(Debug, Clone)]
pub(crate) struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

/// Parse tab-separated rate-card text into a [`RateCard`].
///
/// Lines that are empty (after trimming) or that begin with `#` are ignored.
/// Every other line must be exactly three tab-separated fields — zone,
/// `band_max_grams`, `cents` — whose numeric fields parse.
///
/// # Errors
///
/// Returns [`QuoteError::MalformedRateCard`] carrying the 1-based line number
/// of the first line that is not three tab-separated fields or whose numbers
/// do not parse. Line numbers count every line, including comments and blanks.
pub(crate) fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

    for (index, raw_line) in contents.lines().enumerate() {
        let line_number = index + 1;

        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = raw_line.split('\t').collect();
        let [zone, max_grams, cents] = fields.as_slice() else {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        };

        let max_grams = max_grams
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = cents
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        zones
            .entry((*zone).to_string())
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(RateCard { zones })
}

/// Compute a quote for `parcel` against a parsed rate card.
///
/// The matching band is the first whose `max_grams` is greater than or equal
/// to the parcel weight. Surcharges are additive: a flat charge for weight
/// strictly above [`HEAVY_THRESHOLD_GRAMS`], plus 20% of the base price
/// (rounded half-up) for the international zone.
///
/// # Errors
///
/// - [`QuoteError::UnknownZone`] if the parcel's zone is absent from the card.
/// - [`QuoteError::Overweight`] if the parcel is heavier than the zone's
///   largest band.
pub(crate) fn compute_quote(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = card
        .zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let Some(band) = bands.iter().find(|band| band.max_grams >= parcel.weight_grams) else {
        // `bands` is non-empty by construction, so `last` always yields a limit.
        let limit = bands.last().map_or(0, |band| band.max_grams);
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        });
    };

    let base_cents = band.cents;
    let mut surcharge_cents = 0_u64;

    if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        surcharge_cents += HEAVY_SURCHARGE_CENTS;
    }

    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge_cents += percent_of_cents_half_up(base_cents, INTERNATIONAL_SURCHARGE_PERCENT);
    }

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

/// `percent`% of `cents`, rounded half-up to the nearest whole cent.
fn percent_of_cents_half_up(cents: u64, percent: u64) -> u64 {
    (cents * percent + 50) / 100
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn parse(card: &str) -> RateCard {
        parse_rate_card(card).expect("sample card parses")
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn matches_first_band_at_or_above_weight() {
        let card = parse(SAMPLE);
        let quote = compute_quote(&card, &parcel(300, "domestic")).expect("quote");
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
    }

    #[test]
    fn weight_equal_to_threshold_matches_that_band() {
        let card = parse(SAMPLE);
        let quote = compute_quote(&card, &parcel(500, "domestic")).expect("quote");
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.base_cents, 599);
    }

    #[test]
    fn heavy_surcharge_applies_strictly_above_ten_kilograms() {
        let card = parse(SAMPLE);

        let at_limit = compute_quote(&card, &parcel(10_000, "domestic")).expect("quote");
        assert_eq!(at_limit.surcharge_cents, 0, "10000g is not strictly above");

        let over = compute_quote(&card, &parcel(10_001, "domestic")).expect("quote");
        assert_eq!(over.base_cents, 1799);
        assert_eq!(over.surcharge_cents, 500);
        assert_eq!(over.total_cents, 2299);
        assert_eq!(over.band_max_grams, 20_000);
    }

    #[test]
    fn international_adds_twenty_percent_rounded_half_up() {
        let card = parse(SAMPLE);
        let quote = compute_quote(&card, &parcel(300, "international")).expect("quote");
        assert_eq!(quote.base_cents, 1499);
        // 20% of 1499 = 299.8 -> 300
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn surcharges_stack() {
        let card = parse(SAMPLE);
        let quote = compute_quote(&card, &parcel(15_000, "international")).expect("quote");
        assert_eq!(quote.base_cents, 4999);
        // 500 heavy + round(999.8) = 500 + 1000
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_carries_the_requested_zone() {
        let card = parse(SAMPLE);
        let err = compute_quote(&card, &parcel(100, "lunar")).expect_err("unknown");
        assert_eq!(err, QuoteError::UnknownZone("lunar".to_string()));
    }

    #[test]
    fn overweight_reports_the_largest_band_as_limit() {
        let card = parse(SAMPLE);
        let err = compute_quote(&card, &parcel(25_000, "domestic")).expect_err("overweight");
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000
            }
        );
    }

    #[test]
    fn bands_are_matched_in_ascending_order_regardless_of_file_order() {
        let scrambled = "z\t20000\t300\nz\t500\t100\nz\t2000\t200\n";
        let card = parse(scrambled);
        let quote = compute_quote(&card, &parcel(600, "z")).expect("quote");
        assert_eq!(quote.base_cents, 200);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn malformed_line_reports_one_based_number_counting_comments_and_blanks() {
        // line 1 comment, line 2 blank, line 3 good, line 4 has two fields.
        let card = "# header\n\ndomestic\t500\t599\ndomestic\t2000\n";
        let err = parse_rate_card(card).expect_err("malformed");
        assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn non_numeric_field_is_malformed() {
        let card = "domestic\theavy\t599\n";
        let err = parse_rate_card(card).expect_err("malformed");
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn comments_and_blank_lines_are_ignored() {
        let card = parse(SAMPLE);
        // Five data lines across two zones parsed without error.
        assert!(compute_quote(&card, &parcel(100, "domestic")).is_ok());
        assert!(compute_quote(&card, &parcel(100, "international")).is_ok());
    }

    #[test]
    fn half_up_rounding_is_exact_at_the_boundary() {
        // 20% of 5 cents = 1.0 -> 1; of 3 cents = 0.6 -> 1; of 2 cents = 0.4 -> 0.
        assert_eq!(percent_of_cents_half_up(5, 20), 1);
        assert_eq!(percent_of_cents_half_up(3, 20), 1);
        assert_eq!(percent_of_cents_half_up(2, 20), 0);
    }
}
