//! Integration coverage for the crate's boundary wiring: the `RATECARD_PATH`
//! filesystem adapter, and the in-memory gateway seam that the pure core is
//! driven through.

// Test code uses `expect`/`unwrap` deliberately for terse assertions.
#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

use std::io::Write;

use ratecard::{quote, quote_with_source, Parcel, QuoteError, RateCardSource};

const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

/// An in-memory rate-card source for driving the core without touching disk.
struct InMemory(String);

impl RateCardSource for InMemory {
    fn load(&self) -> Result<String, QuoteError> {
        Ok(self.0.clone())
    }
}

/// A source that always reports the card as unavailable.
struct Unavailable;

impl RateCardSource for Unavailable {
    fn load(&self) -> Result<String, QuoteError> {
        Err(QuoteError::RateCardUnavailable)
    }
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_string(),
    }
}

#[test]
fn end_to_end_quote_through_in_memory_source() {
    let source = InMemory(SAMPLE.to_string());
    // 1500g international: the first band >= 1500 is the 20000g band at 4999.
    let q = quote_with_source(&source, &parcel(1_500, "international")).expect("quote");
    assert_eq!(q.base_cents, 4_999);
    // 20% of 4999 = 999.8 -> 1000
    assert_eq!(q.surcharge_cents, 1_000);
    assert_eq!(q.total_cents, 5_999);
    assert_eq!(q.band_max_grams, 20_000);
}

#[test]
fn source_failure_surfaces_as_rate_card_unavailable() {
    let err = quote_with_source(&Unavailable, &parcel(100, "domestic")).expect_err("unavailable");
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn env_backed_quote_reads_and_reports_ratecard_path() {
    // Both halves live in one test because `RATECARD_PATH` is process-global;
    // keeping them serial here avoids racing the parallel test runner.

    // Unset: the card is unavailable.
    std::env::remove_var("RATECARD_PATH");
    let unset = quote(&parcel(100, "domestic")).expect_err("unavailable");
    assert_eq!(unset, QuoteError::RateCardUnavailable);

    // Set: the card is read from the named file.
    let mut file = tempfile::NamedTempFile::new().expect("temp file");
    file.write_all(SAMPLE.as_bytes()).expect("write card");
    std::env::set_var("RATECARD_PATH", file.path());
    let q = quote(&parcel(300, "domestic")).expect("quote");
    std::env::remove_var("RATECARD_PATH");

    assert_eq!(q.base_cents, 599);
    assert_eq!(q.total_cents, 599);
    assert_eq!(q.band_max_grams, 500);
}

#[test]
fn error_types_are_std_error_and_display() {
    // The contract requires QuoteError to be a std::error::Error with Display.
    fn assert_is_error<E: std::error::Error>(_: &E) {}

    let err = QuoteError::Overweight {
        grams: 25_000,
        limit: 20_000,
    };
    assert_is_error(&err);
    assert!(!err.to_string().is_empty());
}
