//! `ratecard` computes shipping quotes from a zone rate card.
//!
//! The public surface is small: build a [`Parcel`], call [`quote`], and match
//! on the [`Quote`] or [`QuoteError`]. The rate card itself is read from the
//! file named by the `RATECARD_PATH` environment variable.
//!
//! Internally the crate is a pure pricing core (parsing and arithmetic) behind
//! a thin imperative shell that reads the environment and the filesystem and
//! emits tracing. The [`RateCardSource`] gateway lets the core be driven by an
//! in-memory source without touching real I/O:
//!
//! ```
//! use ratecard::{Parcel, QuoteError, RateCardSource, quote_with_source};
//!
//! struct InMemory(&'static str);
//! impl RateCardSource for InMemory {
//!     fn load(&self) -> Result<String, QuoteError> {
//!         Ok(self.0.to_string())
//!     }
//! }
//!
//! let card = "domestic\t500\t599\ndomestic\t2000\t899\n";
//! let parcel = Parcel { weight_grams: 300, zone: "domestic".to_string() };
//! let q = quote_with_source(&InMemory(card), &parcel).expect("quote");
//! assert_eq!(q.base_cents, 599);
//! assert_eq!(q.total_cents, 599);
//! assert_eq!(q.band_max_grams, 500);
//! ```

// The `unwrap`/`expect`/`panic` restriction lints target recoverable paths in
// production code; test code uses them deliberately for terse assertions.
#![cfg_attr(
    test,
    allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)
)]

mod model;
mod pricing;
mod source;
pub mod zones;

pub use model::{Parcel, Quote, QuoteError};
pub use source::{EnvFileRateCardSource, RateCardSource};

/// Compute a shipping quote for `parcel`, reading the rate card from the file
/// named by the `RATECARD_PATH` environment variable.
///
/// # Errors
///
/// - [`QuoteError::RateCardUnavailable`] if `RATECARD_PATH` is unset, or the
///   file is missing or unreadable.
/// - [`QuoteError::MalformedRateCard`] if a rate-card line is malformed.
/// - [`QuoteError::UnknownZone`] if the parcel's zone is not in the card.
/// - [`QuoteError::Overweight`] if the parcel exceeds the zone's largest band.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_with_source(&EnvFileRateCardSource, parcel)
}

/// Compute a shipping quote for `parcel` using an explicit rate-card source.
///
/// This is the seam the pure core is wired through: [`quote`] supplies the
/// filesystem-backed [`EnvFileRateCardSource`], while tests supply in-memory
/// fakes. Every call emits a diagnostic tracing record carrying the zone, the
/// weight in grams, and the resulting total in cents.
///
/// # Errors
///
/// Propagates the same [`QuoteError`] variants as [`quote`]; the
/// unavailability variant is whatever the supplied `source` reports.
pub fn quote_with_source(source: &impl RateCardSource, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "quote",
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
    );
    let _entered = span.enter();

    let contents = source.load()?;
    let card = pricing::parse_rate_card(&contents)?;
    let quote = pricing::compute_quote(&card, parcel)?;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = quote.total_cents,
        "quote computed",
    );

    Ok(quote)
}
