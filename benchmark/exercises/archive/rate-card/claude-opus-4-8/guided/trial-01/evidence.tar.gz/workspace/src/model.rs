//! Domain types for the shipping-quote contract.
//!
//! These are plain data with no behaviour beyond the error-reporting traits
//! required of [`QuoteError`]. They carry no I/O and are safe to construct and
//! inspect in pure code and tests.

/// A parcel awaiting a quote: its billable weight and destination zone.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Billable weight in grams.
    pub weight_grams: u32,
    /// Destination zone, matched by name against the rate card.
    pub zone: String,
}

/// A computed shipping quote, in whole cents.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// The matched band's price before surcharges.
    pub base_cents: u64,
    /// The sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// The matched band's upper weight threshold, in grams.
    pub band_max_grams: u32,
}

/// The reasons a quote cannot be produced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card could not be located or read (unset, missing, or
    /// unreadable `RATECARD_PATH`).
    RateCardUnavailable,
    /// A line in the rate card was not three tab-separated fields, or its
    /// numeric fields did not parse. Carries the 1-based line number,
    /// counting every line including comments and blanks.
    MalformedRateCard {
        /// 1-based line number of the offending line.
        line: usize,
    },
    /// The requested zone is absent from the rate card. Carries the zone.
    UnknownZone(String),
    /// The parcel weighs more than the zone's largest band allows.
    Overweight {
        /// The parcel's weight in grams.
        grams: u32,
        /// The zone's largest band threshold, in grams.
        limit: u32,
    },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel of {grams} g exceeds the zone limit of {limit} g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}
