//! Human-readable labels for the shipping zones understood by the crate.

/// Return a display label for a zone name, falling back to the name itself
/// for zones this crate does not have a friendly label for.
#[must_use]
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}
