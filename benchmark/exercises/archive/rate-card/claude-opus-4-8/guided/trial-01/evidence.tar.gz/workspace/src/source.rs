//! The rate-card gateway: a project-owned contract for obtaining rate-card
//! text, plus the production adapter that reads it from the filesystem.
//!
//! Keeping the effect behind a trait lets the pure pricing core be driven by
//! in-memory fakes in tests, without coupling to `std::fs` or the environment.

use crate::model::QuoteError;

/// A source of raw rate-card text.
///
/// Implementors own where the bytes come from (a file, an embedded string, a
/// test fake). Any failure to produce the text is reported as
/// [`QuoteError::RateCardUnavailable`].
pub trait RateCardSource {
    /// Load the full rate-card text.
    ///
    /// # Errors
    ///
    /// Returns [`QuoteError::RateCardUnavailable`] when the text cannot be
    /// obtained.
    fn load(&self) -> Result<String, QuoteError>;
}

/// The production adapter: reads the rate card from the file named by the
/// `RATECARD_PATH` environment variable.
#[derive(Debug, Default, Clone, Copy)]
pub struct EnvFileRateCardSource;

impl RateCardSource for EnvFileRateCardSource {
    fn load(&self) -> Result<String, QuoteError> {
        let path = std::env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
        std::fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}
