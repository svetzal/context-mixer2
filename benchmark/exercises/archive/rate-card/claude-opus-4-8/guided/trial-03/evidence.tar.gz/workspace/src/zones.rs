//! Human-friendly labels for delivery zones.

/// Return a display label for a zone name, falling back to the name itself.
#[must_use]
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}
