//! Public data types for the quoting contract.
//!
//! These types are the crate's stable surface: callers read [`Parcel`] and
//! [`Quote`] fields directly and match [`QuoteError`] variants directly.

use std::fmt;

/// A parcel to be priced against the rate card.
///
/// ```
/// use ratecard::Parcel;
/// let parcel = Parcel { weight_grams: 750, zone: "domestic".to_string() };
/// assert_eq!(parcel.weight_grams, 750);
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Delivery zone name, matched against the rate card.
    pub zone: String,
}

/// A priced quote for a parcel.
///
/// `total_cents` always equals `base_cents + surcharge_cents`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// The matching band's price, before surcharges.
    pub base_cents: u64,
    /// Surcharges applied on top of the base price.
    pub surcharge_cents: u64,
    /// The billed total: `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// The threshold of the matching band.
    pub band_max_grams: u32,
}

/// The ways a quote can fail.
///
/// Every variant is a recoverable condition a caller can handle; the crate
/// never panics on these paths.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card path was unset, missing, or unreadable.
    RateCardUnavailable,
    /// A rate-card line was not well formed. Carries the 1-based line number,
    /// counting every line in the file including comments and blanks.
    MalformedRateCard {
        /// 1-based line number of the offending line.
        line: usize,
    },
    /// The requested zone was absent from the rate card.
    UnknownZone(String),
    /// The parcel weight exceeds the zone's largest band.
    Overweight {
        /// The requested weight in grams.
        grams: u32,
        /// The zone's largest `band_max_grams`.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => {
                write!(f, "rate card is unavailable")
            }
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            Self::Overweight { grams, limit } => {
                write!(
                    f,
                    "parcel of {grams} g exceeds the zone limit of {limit} g"
                )
            }
        }
    }
}

impl std::error::Error for QuoteError {}
