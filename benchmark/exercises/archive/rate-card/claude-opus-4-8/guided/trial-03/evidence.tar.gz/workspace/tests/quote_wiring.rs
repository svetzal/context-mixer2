//! Cross-module wiring: the public `quote` entry point reading a real rate-card
//! file named by `RATECARD_PATH`, plus proof the diagnostic record carries the
//! required queryable fields.
//!
//! `RATECARD_PATH` is process-global, so these tests serialize their access to
//! it through a shared mutex rather than relying on test-runner ordering.

// Test code asserts invariants with unwrap/expect; that is the test idiom, not
// a production recoverable path.
#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

use std::io::Write;
use std::sync::{Mutex, PoisonError};

use ratecard::{quote, Parcel, QuoteError};
use tempfile::NamedTempFile;

/// Serializes mutation of the process-global `RATECARD_PATH`.
static ENV_LOCK: Mutex<()> = Mutex::new(());

const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn parcel(weight: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams: weight,
        zone: zone.to_string(),
    }
}

/// Write `contents` to a temp file, point `RATECARD_PATH` at it, and run `body`
/// while holding the env lock.
fn with_card<T>(contents: &str, body: impl FnOnce() -> T) -> T {
    let guard = ENV_LOCK.lock().unwrap_or_else(PoisonError::into_inner);
    let mut file = NamedTempFile::new().expect("temp file");
    file.write_all(contents.as_bytes()).expect("write card");
    std::env::set_var("RATECARD_PATH", file.path());
    let out = body();
    std::env::remove_var("RATECARD_PATH");
    drop(guard);
    out
}

#[test]
fn reads_real_file_and_prices_domestic() {
    let q = with_card(SAMPLE, || quote(&parcel(750, "domestic"))).expect("quote");
    assert_eq!(q.base_cents, 899);
    assert_eq!(q.surcharge_cents, 0);
    assert_eq!(q.total_cents, 899);
    assert_eq!(q.band_max_grams, 2000);
}

#[test]
fn prices_international_with_percentage_surcharge() {
    let q = with_card(SAMPLE, || quote(&parcel(300, "international"))).expect("quote");
    assert_eq!(q.base_cents, 1499);
    assert_eq!(q.surcharge_cents, 300);
    assert_eq!(q.total_cents, 1799);
}

#[test]
fn combines_heavy_and_international_surcharges() {
    let q = with_card(SAMPLE, || quote(&parcel(15_000, "international"))).expect("quote");
    assert_eq!(q.base_cents, 4999);
    assert_eq!(q.surcharge_cents, 1500);
    assert_eq!(q.total_cents, 6499);
}

#[test]
fn unknown_zone_is_reported() {
    let err = with_card(SAMPLE, || quote(&parcel(100, "lunar"))).unwrap_err();
    assert_eq!(err, QuoteError::UnknownZone("lunar".to_string()));
}

#[test]
fn overweight_reports_zone_limit() {
    let err = with_card(SAMPLE, || quote(&parcel(30_000, "domestic"))).unwrap_err();
    assert_eq!(
        err,
        QuoteError::Overweight {
            grams: 30_000,
            limit: 20_000,
        }
    );
}

#[test]
fn malformed_line_number_is_reported() {
    let bad = "# header\ndomestic\t500\t599\nbroken row\n";
    let err = with_card(bad, || quote(&parcel(100, "domestic"))).unwrap_err();
    assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
}

#[test]
fn unset_path_is_unavailable() {
    let guard = ENV_LOCK.lock().unwrap_or_else(PoisonError::into_inner);
    std::env::remove_var("RATECARD_PATH");
    let err = quote(&parcel(100, "domestic")).unwrap_err();
    drop(guard);
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn missing_file_is_unavailable() {
    let guard = ENV_LOCK.lock().unwrap_or_else(PoisonError::into_inner);
    std::env::set_var("RATECARD_PATH", "/no/such/rate/card/at/this/path.tsv");
    let err = quote(&parcel(100, "domestic")).unwrap_err();
    std::env::remove_var("RATECARD_PATH");
    drop(guard);
    assert_eq!(err, QuoteError::RateCardUnavailable);
}
