//! The rate-card source boundary.
//!
//! The pure core works on rate-card *text*; this module owns the effectful job
//! of producing that text. The [`RateCardSource`] trait is the project-owned
//! contract the core depends on, so tests can substitute an in-memory source
//! without touching the environment or the filesystem. [`EnvFileSource`] is the
//! thin production adapter that reads the path in `RATECARD_PATH`.

use std::env;
use std::fs;

use crate::model::QuoteError;

/// A source of rate-card text.
///
/// Implementors map every failure to [`QuoteError::RateCardUnavailable`]; the
/// core never sees a vendor error type.
pub(crate) trait RateCardSource {
    /// Read the full rate-card text, or report that it is unavailable.
    fn read(&self) -> Result<String, QuoteError>;
}

/// Reads the rate card from the file named by the `RATECARD_PATH` environment
/// variable.
///
/// An unset variable, a missing file, or any read error all surface as
/// [`QuoteError::RateCardUnavailable`].
pub(crate) struct EnvFileSource;

impl RateCardSource for EnvFileSource {
    fn read(&self) -> Result<String, QuoteError> {
        let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
        fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}
