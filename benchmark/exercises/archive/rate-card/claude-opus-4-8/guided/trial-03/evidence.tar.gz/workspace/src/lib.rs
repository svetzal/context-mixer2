//! Shipping quotes from a zone rate card.
//!
//! Warehouse operators price outbound parcels against a rate card that
//! operations maintains and redeploys without a code change. This crate owns
//! reading that card — from the path in the `RATECARD_PATH` environment
//! variable — and turning a [`Parcel`] into a [`Quote`].
//!
//! The design keeps the pricing rules pure (see the private `core` module) and
//! confines the effects — the environment and filesystem — to a thin gateway
//! and the [`quote`] shell below.
//!
//! # Example
//!
//! ```
//! use std::io::Write;
//! use ratecard::{quote, Parcel};
//!
//! let mut card = tempfile::NamedTempFile::new().unwrap();
//! writeln!(card, "domestic\t500\t599").unwrap();
//! std::env::set_var("RATECARD_PATH", card.path());
//!
//! let parcel = Parcel { weight_grams: 300, zone: "domestic".to_string() };
//! let q = quote(&parcel).unwrap();
//! assert_eq!(q.total_cents, 599);
//! ```

// unwrap/expect/panic are forbidden in production paths but are the natural
// idiom for asserting invariants in tests; relax the restriction lints there.
#![cfg_attr(
    test,
    allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)
)]

mod core;
mod gateway;
mod model;

pub mod zones;

pub use model::{Parcel, Quote, QuoteError};

use gateway::{EnvFileSource, RateCardSource};

/// Price a parcel against the current rate card.
///
/// Reads the rate card named by `RATECARD_PATH`, selects the matching band for
/// the parcel's zone and weight, and applies surcharges. See [`QuoteError`] for
/// the failure modes.
///
/// Every call emits a structured `tracing` record — the zone, weight in grams,
/// and resulting total in cents are individually queryable fields — so
/// operators can correlate and query quoting activity in production.
///
/// # Errors
///
/// Returns [`QuoteError::RateCardUnavailable`] if `RATECARD_PATH` is unset,
/// missing, or unreadable; [`QuoteError::MalformedRateCard`] if a card line is
/// malformed; [`QuoteError::UnknownZone`] if the parcel's zone is absent; and
/// [`QuoteError::Overweight`] if the parcel exceeds the zone's largest band.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_with_source(parcel, &EnvFileSource)
}

/// The pure-shell orchestration: read the card from `source`, parse it, compute
/// the quote, and record the outcome. Kept separate from [`quote`] so the wiring
/// can be exercised against an in-memory source.
fn quote_with_source(
    parcel: &Parcel,
    source: &impl RateCardSource,
) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "quote",
        zone = parcel.zone.as_str(),
        weight_grams = parcel.weight_grams,
    );
    let _enter = span.enter();

    let result = read_and_compute(parcel, source);

    match &result {
        Ok(q) => tracing::info!(
            zone = parcel.zone.as_str(),
            weight_grams = parcel.weight_grams,
            total_cents = q.total_cents,
            "quote computed",
        ),
        Err(err) => tracing::warn!(
            zone = parcel.zone.as_str(),
            weight_grams = parcel.weight_grams,
            error = %err,
            "quote failed",
        ),
    }

    result
}

/// Read the rate card and compute the quote, without any instrumentation.
fn read_and_compute(
    parcel: &Parcel,
    source: &impl RateCardSource,
) -> Result<Quote, QuoteError> {
    let text = source.read()?;
    let bands = core::parse_rate_card(&text)?;
    core::compute_quote(parcel, &bands)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// An in-memory rate-card source for exercising the shell without I/O.
    struct FixedSource(Result<String, QuoteError>);

    impl RateCardSource for FixedSource {
        fn read(&self) -> Result<String, QuoteError> {
            self.0.clone()
        }
    }

    fn card() -> String {
        "\
domestic\t500\t599
domestic\t2000\t899
international\t500\t1499
"
        .to_string()
    }

    fn parcel(weight: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams: weight,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn shell_computes_a_quote_from_its_source() {
        let source = FixedSource(Ok(card()));
        let q = quote_with_source(&parcel(300, "domestic"), &source).expect("quote");
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn shell_surfaces_unavailable_source() {
        let source = FixedSource(Err(QuoteError::RateCardUnavailable));
        let err = quote_with_source(&parcel(300, "domestic"), &source).unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn shell_surfaces_malformed_card() {
        let source = FixedSource(Ok("domestic\t500\n".to_string()));
        let err = quote_with_source(&parcel(300, "domestic"), &source).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }
}
