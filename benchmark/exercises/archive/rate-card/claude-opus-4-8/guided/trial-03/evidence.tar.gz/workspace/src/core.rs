//! Pure quoting logic.
//!
//! Everything here is a total function of its inputs: parsing rate-card text
//! and turning a parcel plus parsed bands into a [`Quote`]. There is no I/O,
//! no clock, and no environment access, so the whole module is exercised by
//! ordinary in-memory unit tests.

use crate::model::{Parcel, Quote, QuoteError};

/// Grams above which the heavy-parcel surcharge applies (strictly above).
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
/// Flat surcharge added for parcels above [`HEAVY_THRESHOLD_GRAMS`].
const HEAVY_SURCHARGE_CENTS: u64 = 500;
/// Zone name that attracts the international percentage surcharge.
const INTERNATIONAL_ZONE: &str = "international";

/// One priced band parsed from the rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct Band {
    /// The zone this band belongs to.
    pub zone: String,
    /// The inclusive upper weight bound of the band, in grams.
    pub max_grams: u32,
    /// The base price for parcels falling in this band, in cents.
    pub cents: u64,
}

/// Parse tab-separated rate-card text into bands.
///
/// Lines that are empty or begin with `#` are skipped. Every other line must
/// be exactly three tab-separated fields — zone, `band_max_grams`, `cents` —
/// whose numeric fields parse, or [`QuoteError::MalformedRateCard`] is
/// returned carrying the 1-based line number (counting all lines, including
/// the skipped ones).
pub(crate) fn parse_rate_card(text: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();

    for (index, raw) in text.lines().enumerate() {
        let line = index + 1;
        let trimmed = raw.trim_end_matches(['\r']);

        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = trimmed.split('\t').collect();
        let [zone, max_grams, cents] = fields.as_slice() else {
            return Err(QuoteError::MalformedRateCard { line });
        };

        let max_grams = max_grams
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line })?;
        let cents = cents
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line })?;

        bands.push(Band {
            zone: (*zone).to_string(),
            max_grams,
            cents,
        });
    }

    Ok(bands)
}

/// Compute a quote for `parcel` against already-parsed `bands`.
///
/// Selects the first band for the parcel's zone (in ascending `max_grams`)
/// whose bound is greater than or equal to the parcel weight, then applies
/// surcharges. Returns [`QuoteError::UnknownZone`] when the zone is absent and
/// [`QuoteError::Overweight`] when the parcel exceeds the zone's largest band.
pub(crate) fn compute_quote(parcel: &Parcel, bands: &[Band]) -> Result<Quote, QuoteError> {
    let mut zone_bands: Vec<&Band> =
        bands.iter().filter(|b| b.zone == parcel.zone).collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.max_grams);

    let matching = zone_bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams);

    let Some(band) = matching else {
        // Non-empty and sorted, so the last element is the largest band.
        let limit = zone_bands
            .last()
            .map_or(0, |b| b.max_grams);
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        });
    };

    let base_cents = band.cents;
    let surcharge_cents = surcharge_for(parcel, base_cents);
    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

/// Sum the surcharges that apply to a parcel with the given base price.
fn surcharge_for(parcel: &Parcel, base_cents: u64) -> u64 {
    let mut surcharge = 0;

    if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        surcharge += HEAVY_SURCHARGE_CENTS;
    }

    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge += international_surcharge(base_cents);
    }

    surcharge
}

/// 20% of `base_cents`, rounded half-up to the nearest cent.
fn international_surcharge(base_cents: u64) -> u64 {
    // base * 0.2 rounded half-up == (base * 20 + 50) / 100 in integer math.
    (base_cents * 20 + 50) / 100
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn parcel(weight: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams: weight,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn parses_comments_and_blanks_are_skipped() {
        let bands = parse_rate_card(SAMPLE).expect("sample parses");
        assert_eq!(bands.len(), 5);
    }

    #[test]
    fn blank_lines_are_ignored() {
        let text = "\ndomestic\t500\t599\n\n";
        let bands = parse_rate_card(text).expect("parses");
        assert_eq!(bands.len(), 1);
    }

    #[test]
    fn malformed_reports_wrong_field_count() {
        let text = "domestic\t500\n";
        let err = parse_rate_card(text).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn malformed_reports_unparseable_number() {
        let text = "# header\ndomestic\theavy\t599\n";
        let err = parse_rate_card(text).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn malformed_line_number_counts_all_lines() {
        let text = "# a\n\ndomestic\t500\t599\nbad line here\n";
        let err = parse_rate_card(text).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn first_band_at_or_above_weight_matches() {
        let bands = parse_rate_card(SAMPLE).expect("parses");
        let quote = compute_quote(&parcel(750, "domestic"), &bands).expect("quote");
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
    }

    #[test]
    fn weight_exactly_on_band_boundary_matches_that_band() {
        let bands = parse_rate_card(SAMPLE).expect("parses");
        let quote = compute_quote(&parcel(500, "domestic"), &bands).expect("quote");
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn unknown_zone_carries_requested_zone() {
        let bands = parse_rate_card(SAMPLE).expect("parses");
        let err = compute_quote(&parcel(100, "orbital"), &bands).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("orbital".to_string()));
    }

    #[test]
    fn overweight_carries_largest_band_limit() {
        let bands = parse_rate_card(SAMPLE).expect("parses");
        let err = compute_quote(&parcel(25_000, "domestic"), &bands).unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000,
            }
        );
    }

    #[test]
    fn heavy_surcharge_applies_strictly_above_threshold() {
        let bands = parse_rate_card(SAMPLE).expect("parses");
        let quote = compute_quote(&parcel(15_000, "domestic"), &bands).expect("quote");
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn heavy_surcharge_excludes_exact_threshold() {
        let bands = parse_rate_card(SAMPLE).expect("parses");
        let quote = compute_quote(&parcel(10_000, "domestic"), &bands).expect("quote");
        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_twenty_percent_rounded_half_up() {
        let bands = parse_rate_card(SAMPLE).expect("parses");
        // base 1499 * 0.2 = 299.8 -> rounds to 300.
        let quote = compute_quote(&parcel(300, "international"), &bands).expect("quote");
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn surcharges_add_together() {
        let bands = parse_rate_card(SAMPLE).expect("parses");
        // base 4999, international 20% = 999.8 -> 1000, plus 500 heavy.
        let quote = compute_quote(&parcel(15_000, "international"), &bands).expect("quote");
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn international_rounds_half_up_at_the_midpoint() {
        // base 5 * 0.2 = 1.0 exactly; base 3 * 0.2 = 0.6 -> 1.
        assert_eq!(international_surcharge(5), 1);
        assert_eq!(international_surcharge(3), 1);
        // base 2 * 0.2 = 0.4 -> 0.
        assert_eq!(international_surcharge(2), 0);
        // base 25 * 0.2 = 5.0 exactly.
        assert_eq!(international_surcharge(25), 5);
    }
}
