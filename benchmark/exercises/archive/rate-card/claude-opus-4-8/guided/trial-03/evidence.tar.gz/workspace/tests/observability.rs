//! Proves each quote is observable: a successful call emits a diagnostic event
//! whose zone, weight, and total are individually queryable fields (not baked
//! into a flat message string).

// Test code asserts invariants with unwrap/expect; that is the test idiom, not
// a production recoverable path.
#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

use std::io::Write;
use std::sync::{Arc, Mutex};

use ratecard::{quote, Parcel};
use tempfile::NamedTempFile;
use tracing::field::{Field, Visit};
use tracing::subscriber::with_default;
use tracing_subscriber::layer::{Context, SubscriberExt};
use tracing_subscriber::registry::Registry;
use tracing_subscriber::Layer;

/// A captured event: its message plus a flat map of field name to debug value.
#[derive(Default)]
struct Captured {
    message: Option<String>,
    fields: Vec<(String, String)>,
}

impl Visit for Captured {
    fn record_debug(&mut self, field: &Field, value: &dyn std::fmt::Debug) {
        let rendered = format!("{value:?}");
        if field.name() == "message" {
            self.message = Some(rendered);
        } else {
            self.fields.push((field.name().to_string(), rendered));
        }
    }

    fn record_u64(&mut self, field: &Field, value: u64) {
        self.fields.push((field.name().to_string(), value.to_string()));
    }

    fn record_i64(&mut self, field: &Field, value: i64) {
        self.fields.push((field.name().to_string(), value.to_string()));
    }

    fn record_str(&mut self, field: &Field, value: &str) {
        self.fields.push((field.name().to_string(), value.to_string()));
    }
}

/// A layer that records every event's fields into a shared buffer.
struct CapturingLayer(Arc<Mutex<Vec<Captured>>>);

impl<S: tracing::Subscriber> Layer<S> for CapturingLayer {
    fn on_event(&self, event: &tracing::Event<'_>, _ctx: Context<'_, S>) {
        let mut captured = Captured::default();
        event.record(&mut captured);
        self.0.lock().expect("lock").push(captured);
    }
}

#[test]
fn successful_quote_emits_queryable_fields() {
    let mut file = NamedTempFile::new().expect("temp file");
    writeln!(file, "domestic\t2000\t899").expect("write card");
    std::env::set_var("RATECARD_PATH", file.path());

    let events = Arc::new(Mutex::new(Vec::new()));
    let subscriber = Registry::default().with(CapturingLayer(Arc::clone(&events)));

    let quoted = with_default(subscriber, || {
        quote(&Parcel {
            weight_grams: 750,
            zone: "domestic".to_string(),
        })
    })
    .expect("quote");

    std::env::remove_var("RATECARD_PATH");

    let events = events.lock().expect("lock");
    let record = events
        .iter()
        .find(|e| e.fields.iter().any(|(name, _)| name == "total_cents"))
        .expect("a diagnostic event carrying total_cents");

    let field = |name: &str| {
        record
            .fields
            .iter()
            .find(|(n, _)| n == name)
            .map(|(_, v)| v.clone())
    };

    assert_eq!(field("zone").as_deref(), Some("domestic"));
    assert_eq!(field("weight_grams").as_deref(), Some("750"));
    assert_eq!(
        field("total_cents").as_deref(),
        Some(quoted.total_cents.to_string().as_str())
    );
}
