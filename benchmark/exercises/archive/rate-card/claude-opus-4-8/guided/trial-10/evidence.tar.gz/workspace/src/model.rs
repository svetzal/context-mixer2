//! Public domain types for shipping quotes.

use std::fmt;

/// A parcel awaiting a shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Billable weight of the parcel in grams.
    pub weight_grams: u32,
    /// Destination zone, matched against the rate card.
    pub zone: String,
}

/// A priced shipping quote for a [`Parcel`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// The matched band's price, before surcharges.
    pub base_cents: u64,
    /// Surcharges applied on top of the base price.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// The `band_max_grams` threshold of the matched band.
    pub band_max_grams: u32,
}

/// The ways a quote can fail.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card path was unset, missing, or unreadable.
    RateCardUnavailable,
    /// A rate-card line could not be parsed; carries the 1-based line number.
    MalformedRateCard {
        /// 1-based line number of the offending line, counting comments and blanks.
        line: usize,
    },
    /// The requested zone is absent from the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight {
        /// The requested parcel weight in grams.
        grams: u32,
        /// The zone's largest `band_max_grams`.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}
