//! Cross-module wiring: the loaded card flows through parsing and pricing, and
//! the environment-backed source resolves `RATECARD_PATH`.

// Integration tests are their own crate and legitimately unwrap fixtures.
#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

use std::io::Write;

use ratecard::{quote, quote_with, Parcel, QuoteError, RateCardSource};

const CARD: &str = "# zone\tband_max_grams\tcents\n\
    domestic\t500\t599\n\
    domestic\t2000\t899\n\
    domestic\t20000\t1799\n\
    international\t500\t1499\n\
    international\t20000\t4999\n";

/// An in-memory source that hands back fixed text.
struct FixedCard(&'static str);

impl RateCardSource for FixedCard {
    fn load(&self) -> Result<String, QuoteError> {
        Ok(self.0.to_owned())
    }
}

/// A source that reports the card as unavailable.
struct Unavailable;

impl RateCardSource for Unavailable {
    fn load(&self) -> Result<String, QuoteError> {
        Err(QuoteError::RateCardUnavailable)
    }
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_owned(),
    }
}

#[test]
fn domestic_quote_flows_through_the_pipeline() {
    let q = quote_with(&FixedCard(CARD), &parcel(750, "domestic")).unwrap();
    assert_eq!(q.base_cents, 899);
    assert_eq!(q.band_max_grams, 2000);
    assert_eq!(q.total_cents, 899);
}

#[test]
fn international_heavy_quote_stacks_surcharges() {
    let q = quote_with(&FixedCard(CARD), &parcel(15_000, "international")).unwrap();
    assert_eq!(q.base_cents, 4999);
    assert_eq!(q.surcharge_cents, 1500);
    assert_eq!(q.total_cents, 6499);
}

#[test]
fn unknown_zone_surfaces_through_the_pipeline() {
    let err = quote_with(&FixedCard(CARD), &parcel(100, "lunar")).unwrap_err();
    assert_eq!(err, QuoteError::UnknownZone("lunar".to_owned()));
}

#[test]
fn unavailable_source_surfaces() {
    let err = quote_with(&Unavailable, &parcel(100, "domestic")).unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn env_backed_quote_honours_the_ratecard_path() {
    // Both env cases live in one test: `RATECARD_PATH` is process-global, so
    // splitting them into parallel tests would race.
    std::env::remove_var("RATECARD_PATH");
    let missing = quote(&parcel(250, "domestic")).unwrap_err();
    assert_eq!(missing, QuoteError::RateCardUnavailable);

    let mut file = tempfile::NamedTempFile::new().unwrap();
    file.write_all(CARD.as_bytes()).unwrap();
    std::env::set_var("RATECARD_PATH", file.path());

    let q = quote(&parcel(250, "domestic")).unwrap();
    assert_eq!(q.total_cents, 599);
    assert_eq!(q.band_max_grams, 500);

    std::env::remove_var("RATECARD_PATH");
}

#[test]
fn display_is_human_readable() {
    let err = QuoteError::MalformedRateCard { line: 7 };
    assert_eq!(err.to_string(), "malformed rate card at line 7");
    // Exercised as a std::error::Error trait object.
    let _dyn: &dyn std::error::Error = &err;
}
