//! Rate-card loading behind a project-owned gateway trait.
//!
//! Wrapping the filesystem and environment lookups behind [`RateCardSource`]
//! keeps the parsing and pricing core free of I/O and lets tests inject an
//! in-memory card without touching real files.

use crate::model::QuoteError;

/// A source of raw rate-card text.
///
/// The concrete [`EnvFileSource`] reads the path named by `RATECARD_PATH`;
/// tests supply their own implementations.
pub trait RateCardSource {
    /// Load the raw rate-card text, or explain why it is unavailable.
    fn load(&self) -> Result<String, QuoteError>;
}

/// Reads the rate card from the file named by the `RATECARD_PATH` environment
/// variable. An unset variable or an unreadable file maps to
/// [`QuoteError::RateCardUnavailable`].
#[derive(Debug, Default, Clone, Copy)]
pub struct EnvFileSource;

impl RateCardSource for EnvFileSource {
    fn load(&self) -> Result<String, QuoteError> {
        let path = std::env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
        std::fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}
