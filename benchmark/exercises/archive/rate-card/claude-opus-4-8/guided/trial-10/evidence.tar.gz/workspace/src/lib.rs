//! Shipping quotes for the `ratecard` fulfilment service.
//!
//! Operations maintain a tab-separated rate card that this crate reads and
//! turns into a [`Quote`] for a [`Parcel`]. The public [`quote`] function reads
//! the card from the path in the `RATECARD_PATH` environment variable; the
//! generic [`quote_with`] takes any [`RateCardSource`], which is how tests and
//! embedders supply a card without a real file.
//!
//! The parsing and pricing core is pure — a thin imperative shell ([`quote`])
//! performs the I/O and emits observability.
//!
//! ```
//! use ratecard::{quote_with, Parcel, QuoteError, RateCardSource};
//!
//! struct InMemory(&'static str);
//! impl RateCardSource for InMemory {
//!     fn load(&self) -> Result<String, QuoteError> {
//!         Ok(self.0.to_owned())
//!     }
//! }
//!
//! let card = "domestic\t500\t599\ninternational\t500\t1499\n";
//! let parcel = Parcel { weight_grams: 250, zone: "domestic".to_owned() };
//! let q = quote_with(&InMemory(card), &parcel).expect("a quote");
//! assert_eq!(q.total_cents, 599);
//! ```

// The panic-prone restriction lints target production paths; test code
// legitimately unwraps, so quiet them there to keep the warnings meaningful.
#![cfg_attr(
    test,
    allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)
)]

pub mod zones;

mod model;
mod parse;
mod pricing;
mod source;

pub use model::{Parcel, Quote, QuoteError};
pub use source::{EnvFileSource, RateCardSource};

/// Quote `parcel` against the rate card named by the `RATECARD_PATH`
/// environment variable.
///
/// # Errors
///
/// Returns a [`QuoteError`] when the rate card is unavailable or malformed, the
/// zone is unknown, or the parcel exceeds the zone's largest band.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_with(&EnvFileSource, parcel)
}

/// Quote `parcel` against the rate card produced by `source`.
///
/// This is the seam the pure core is wired through: [`quote`] passes the
/// environment-backed [`EnvFileSource`], while tests pass an in-memory source.
/// Each call is observable — it opens a `quote` tracing span carrying the zone
/// and weight, and emits a record with the resulting total on success.
///
/// # Errors
///
/// Returns a [`QuoteError`] when the rate card is unavailable or malformed, the
/// zone is unknown, or the parcel exceeds the zone's largest band.
pub fn quote_with(source: &impl RateCardSource, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "quote",
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
    );
    let _enter = span.enter();

    let text = source.load()?;
    let card = parse::parse_rate_card(&text)?;
    let quote = pricing::compute_quote(&card, parcel)?;

    tracing::info!(total_cents = quote.total_cents, "quote computed");

    Ok(quote)
}
