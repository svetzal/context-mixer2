//! Pure quote pricing over a parsed rate card.

use crate::model::{Parcel, Quote, QuoteError};
use crate::parse::RateCard;

/// Weight, in grams, strictly above which the heavy-parcel surcharge applies.
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
/// Flat surcharge, in cents, for a parcel above [`HEAVY_THRESHOLD_GRAMS`].
const HEAVY_SURCHARGE_CENTS: u64 = 500;
/// Zone name whose base price attracts a proportional surcharge.
const INTERNATIONAL_ZONE: &str = "international";

/// Price `parcel` against the parsed `card`.
///
/// Returns [`QuoteError::UnknownZone`] when the zone is absent and
/// [`QuoteError::Overweight`] when the parcel exceeds the zone's largest band.
pub(crate) fn compute_quote(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = card
        .bands(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    // A zone key only exists once at least one band was recorded, so the last
    // (heaviest) band is always present.
    let limit = match bands.last() {
        Some(band) => band.max_grams,
        None => return Err(QuoteError::UnknownZone(parcel.zone.clone())),
    };

    let band = bands
        .iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        surcharge_cents += HEAVY_SURCHARGE_CENTS;
    }

    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge_cents += international_surcharge(base_cents);
    }

    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

/// 20% of `base_cents`, rounded half-up to the nearest cent.
fn international_surcharge(base_cents: u64) -> u64 {
    (base_cents * 20 + 50) / 100
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::parse::parse_rate_card;

    const SAMPLE: &str = "domestic\t500\t599\n\
        domestic\t2000\t899\n\
        domestic\t20000\t1799\n\
        international\t500\t1499\n\
        international\t20000\t4999\n";

    fn card() -> RateCard {
        parse_rate_card(SAMPLE).unwrap()
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_owned(),
        }
    }

    #[test]
    fn picks_first_band_at_or_above_weight() {
        let quote = compute_quote(&card(), &parcel(500, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
    }

    #[test]
    fn steps_up_to_next_band() {
        let quote = compute_quote(&card(), &parcel(1500, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn heavy_parcel_adds_flat_surcharge() {
        let quote = compute_quote(&card(), &parcel(15_000, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn exactly_ten_thousand_grams_is_not_heavy() {
        // 10000 is not strictly above the threshold.
        let quote = compute_quote(&card(), &parcel(10_000, "domestic")).unwrap();
        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_proportional_surcharge() {
        let quote = compute_quote(&card(), &parcel(500, "international")).unwrap();
        assert_eq!(quote.base_cents, 1499);
        // 20% of 1499 = 299.8, rounded half-up = 300.
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn international_heavy_stacks_both_surcharges() {
        let quote = compute_quote(&card(), &parcel(15_000, "international")).unwrap();
        assert_eq!(quote.base_cents, 4999);
        // 20% of 4999 = 999.8 -> 1000, plus the 500 heavy surcharge.
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_carries_requested_zone() {
        let err = compute_quote(&card(), &parcel(100, "lunar")).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".to_owned()));
    }

    #[test]
    fn overweight_carries_largest_band() {
        let err = compute_quote(&card(), &parcel(25_000, "domestic")).unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000,
            }
        );
    }
}
