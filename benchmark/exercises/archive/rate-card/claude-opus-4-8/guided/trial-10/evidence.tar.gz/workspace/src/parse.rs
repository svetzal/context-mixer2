//! Pure parsing of the tab-separated rate card into an in-memory structure.
//!
//! This module performs no I/O: it turns already-loaded text into a
//! [`RateCard`], so its behaviour is deterministic and testable in isolation.

use std::collections::BTreeMap;

use crate::model::QuoteError;

/// One priced band within a zone.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct Band {
    pub(crate) max_grams: u32,
    pub(crate) cents: u64,
}

/// A parsed rate card: each zone maps to its bands, sorted ascending by weight.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

impl RateCard {
    /// The bands for `zone`, ascending by `max_grams`, or `None` if the zone is
    /// absent from the card.
    pub(crate) fn bands(&self, zone: &str) -> Option<&[Band]> {
        self.zones.get(zone).map(Vec::as_slice)
    }
}

/// Parse tab-separated rate-card text.
///
/// Empty lines and lines beginning with `#` are ignored. Every other line must
/// hold exactly three tab-separated fields — zone, `band_max_grams`, `cents` —
/// whose numeric fields parse, or the whole card is rejected with
/// [`QuoteError::MalformedRateCard`] carrying the 1-based line number.
pub(crate) fn parse_rate_card(text: &str) -> Result<RateCard, QuoteError> {
    let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

    for (index, raw) in text.lines().enumerate() {
        let line = index + 1;
        let trimmed = raw.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = raw.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line });
        }

        let zone = fields[0];
        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line })?;

        zones
            .entry(zone.to_owned())
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(RateCard { zones })
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
        domestic\t500\t599\n\
        domestic\t2000\t899\n\
        domestic\t20000\t1799\n\
        international\t500\t1499\n\
        international\t20000\t4999\n";

    #[test]
    fn ignores_comments_and_blank_lines() {
        let card = parse_rate_card("\n# a comment\n\ndomestic\t500\t599\n").unwrap();
        assert_eq!(card.bands("domestic").unwrap().len(), 1);
    }

    #[test]
    fn sorts_bands_ascending() {
        let card = parse_rate_card(SAMPLE).unwrap();
        let domestic = card.bands("domestic").unwrap();
        let maxima: Vec<u32> = domestic.iter().map(|b| b.max_grams).collect();
        assert_eq!(maxima, vec![500, 2000, 20000]);
    }

    #[test]
    fn wrong_field_count_is_malformed_with_line() {
        let text = "domestic\t500\t599\ndomestic\t2000\n";
        let err = parse_rate_card(text).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn unparsable_number_is_malformed_with_line() {
        let text = "# header\ndomestic\theavy\t599\n";
        let err = parse_rate_card(text).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn line_numbers_count_comments_and_blanks() {
        let text = "\n\n# comment\ndomestic\t500\tnope\n";
        let err = parse_rate_card(text).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn absent_zone_has_no_bands() {
        let card = parse_rate_card(SAMPLE).unwrap();
        assert!(card.bands("lunar").is_none());
    }
}
