//! Human-readable labels for zone names.

/// A display label for a zone name, falling back to the raw name for zones we
/// don't have a friendly label for.
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}
