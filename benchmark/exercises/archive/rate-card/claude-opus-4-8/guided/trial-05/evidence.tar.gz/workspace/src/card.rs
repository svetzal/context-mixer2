//! Parsing the rate card into a queryable in-memory structure.
//!
//! This module is pure: it turns rate-card *text* into a [`RateCard`] and
//! answers band lookups. It performs no I/O, so it is fully testable without a
//! filesystem.

use crate::model::QuoteError;

/// A single priced band for a zone: everything up to and including
/// `max_grams` costs `cents`.
#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    zone: String,
    max_grams: u32,
    cents: u64,
}

/// A parsed rate card, ready to answer band lookups.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RateCard {
    bands: Vec<Band>,
}

/// The band that prices a given weight, plus the zone's ceiling.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BandMatch {
    /// The matching band's price, in cents.
    pub cents: u64,
    /// The matching band's `max_grams` threshold.
    pub max_grams: u32,
}

impl RateCard {
    /// Parse rate-card text into a [`RateCard`].
    ///
    /// The text is tab-separated, one band per line. Empty lines and lines
    /// beginning with `#` are ignored. Every other line must be exactly three
    /// tab-separated fields — `zone`, `band_max_grams`, `cents` — whose numbers
    /// parse, or parsing fails with [`QuoteError::MalformedRateCard`] carrying
    /// the 1-based line number.
    ///
    /// ```
    /// # use ratecard::RateCard;
    /// let card = RateCard::parse("domestic\t500\t599").unwrap();
    /// assert!(card.zone_exists("domestic"));
    /// ```
    pub fn parse(text: &str) -> Result<RateCard, QuoteError> {
        let mut bands = Vec::new();
        for (index, raw) in text.lines().enumerate() {
            let line = index + 1;
            let trimmed = raw.trim_end_matches(['\r']);
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }
            bands.push(parse_band(trimmed, line)?);
        }
        Ok(RateCard { bands })
    }

    /// Whether any band exists for `zone`.
    pub fn zone_exists(&self, zone: &str) -> bool {
        self.bands.iter().any(|band| band.zone == zone)
    }

    /// Find the band that prices `weight_grams` in `zone`.
    ///
    /// The matching band is the first, in ascending `max_grams`, whose
    /// threshold is greater than or equal to the weight. Returns:
    /// - `Ok(Some(_))` when a band matches;
    /// - `Ok(None)` when the zone exists but the weight exceeds its largest
    ///   band — the caller reports [`QuoteError::Overweight`];
    /// - `Err(UnknownZone)` when the zone has no bands.
    pub fn lookup(&self, zone: &str, weight_grams: u32) -> Result<Option<BandMatch>, QuoteError> {
        let mut zone_bands: Vec<&Band> =
            self.bands.iter().filter(|band| band.zone == zone).collect();
        if zone_bands.is_empty() {
            return Err(QuoteError::UnknownZone(zone.to_string()));
        }
        zone_bands.sort_by_key(|band| band.max_grams);
        match zone_bands.iter().find(|band| band.max_grams >= weight_grams) {
            Some(band) => Ok(Some(BandMatch {
                cents: band.cents,
                max_grams: band.max_grams,
            })),
            None => Ok(None),
        }
    }

    /// The largest `max_grams` threshold available for `zone`, if any.
    pub fn zone_limit(&self, zone: &str) -> Option<u32> {
        self.bands
            .iter()
            .filter(|band| band.zone == zone)
            .map(|band| band.max_grams)
            .max()
    }
}

fn parse_band(line: &str, line_number: usize) -> Result<Band, QuoteError> {
    let malformed = || QuoteError::MalformedRateCard { line: line_number };
    let mut fields = line.split('\t');
    let zone = fields.next().ok_or_else(malformed)?;
    let max_grams = fields.next().ok_or_else(malformed)?;
    let cents = fields.next().ok_or_else(malformed)?;
    if fields.next().is_some() {
        return Err(malformed());
    }
    if zone.is_empty() {
        return Err(malformed());
    }
    let max_grams = max_grams.parse::<u32>().map_err(|_| malformed())?;
    let cents = cents.parse::<u64>().map_err(|_| malformed())?;
    Ok(Band {
        zone: zone.to_string(),
        max_grams,
        cents,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    #[test]
    fn skips_comments_and_blanks() {
        let card = RateCard::parse("# header\n\ndomestic\t500\t599\n").unwrap();
        assert!(card.zone_exists("domestic"));
    }

    #[test]
    fn matches_first_band_at_or_above_weight() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let hit = card.lookup("domestic", 500).unwrap().unwrap();
        assert_eq!(hit.cents, 599);
        assert_eq!(hit.max_grams, 500);

        let hit = card.lookup("domestic", 501).unwrap().unwrap();
        assert_eq!(hit.cents, 899);
        assert_eq!(hit.max_grams, 2000);
    }

    #[test]
    fn unknown_zone_reports_requested_zone() {
        let card = RateCard::parse(SAMPLE).unwrap();
        let err = card.lookup("lunar", 100).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".to_string()));
    }

    #[test]
    fn overweight_yields_none_and_limit() {
        let card = RateCard::parse(SAMPLE).unwrap();
        assert!(card.lookup("domestic", 20001).unwrap().is_none());
        assert_eq!(card.zone_limit("domestic"), Some(20000));
    }

    #[test]
    fn wrong_field_count_is_malformed_with_line() {
        let err = RateCard::parse("domestic\t500\t599\ndomestic\t500\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn unparseable_number_is_malformed_with_line() {
        let err = RateCard::parse("# c\ndomestic\theavy\t599\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }
}
