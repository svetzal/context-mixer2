//! Pure quote calculation: parcel + rate card in, [`Quote`] out.
//!
//! This module holds the pricing policy and nothing else. It has no I/O, so the
//! rules — band matching, surcharges, rounding — are exercised directly in unit
//! tests without a filesystem or environment.

use crate::card::RateCard;
use crate::model::{Parcel, Quote, QuoteError};

/// Weight strictly above this many grams incurs the heavy surcharge.
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
/// Flat surcharge, in cents, for parcels above [`HEAVY_THRESHOLD_GRAMS`].
const HEAVY_SURCHARGE_CENTS: u64 = 500;
/// Zone whose base price attracts a percentage surcharge.
const INTERNATIONAL_ZONE: &str = "international";

/// Price `parcel` against an already-parsed `card`.
///
/// This is the pure heart of the crate: given the card, the result is a
/// deterministic function of the parcel with no side effects.
pub fn price(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let matched = match card.lookup(&parcel.zone, parcel.weight_grams)? {
        Some(band) => band,
        None => {
            let limit = card.zone_limit(&parcel.zone).unwrap_or(0);
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = matched.cents;
    let surcharge_cents =
        heavy_surcharge(parcel.weight_grams) + zone_surcharge(&parcel.zone, base_cents);
    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: matched.max_grams,
    })
}

fn heavy_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > HEAVY_THRESHOLD_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    }
}

/// 20% of `base_cents`, rounded half-up to the nearest cent, for the
/// international zone; zero otherwise.
fn zone_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == INTERNATIONAL_ZONE {
        // 20% == base * 20 / 100; +50 before the integer divide rounds half-up.
        (base_cents * 20 + 50) / 100
    } else {
        0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    fn card() -> RateCard {
        RateCard::parse(SAMPLE).unwrap()
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn domestic_light_has_no_surcharge() {
        let q = price(&card(), &parcel(300, "domestic")).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn heavy_domestic_adds_flat_surcharge() {
        let q = price(&card(), &parcel(15_000, "domestic")).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn international_adds_twenty_percent_rounded_half_up() {
        // 1499 * 0.20 = 299.8 -> 300
        let q = price(&card(), &parcel(400, "international")).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn heavy_international_stacks_both_surcharges() {
        // base 4999; heavy 500; 4999*0.20 = 999.8 -> 1000; total 4999+1500
        let q = price(&card(), &parcel(18_000, "international")).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn exactly_ten_thousand_is_not_heavy() {
        let q = price(&card(), &parcel(10_000, "domestic")).unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn overweight_carries_zone_limit() {
        let err = price(&card(), &parcel(25_000, "domestic")).unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20000
            }
        );
    }

    #[test]
    fn unknown_zone_propagates() {
        let err = price(&card(), &parcel(100, "orbital")).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("orbital".to_string()));
    }
}
