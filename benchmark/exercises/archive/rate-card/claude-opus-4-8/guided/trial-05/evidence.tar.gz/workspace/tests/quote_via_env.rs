//! Integration coverage for the real filesystem/environment shell.
//!
//! These tests drive `quote` end to end through `RATECARD_PATH`, exercising the
//! wiring that the pure unit tests deliberately skip. Because `RATECARD_PATH`
//! is process-global, the cases run under a shared mutex so they never race.
//!
//! This is test code: `unwrap`/`expect` on setup is the intended failure
//! signal, so the recoverable-path restrictions are relaxed for these helpers.
#![allow(clippy::unwrap_used, clippy::expect_used)]

use std::io::Write;
use std::path::Path;
use std::sync::Mutex;

use ratecard::{quote, Parcel, QuoteError};
use tempfile::NamedTempFile;

static ENV_GUARD: Mutex<()> = Mutex::new(());

const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

fn with_card<T>(contents: &str, body: impl FnOnce() -> T) -> T {
    let guard = ENV_GUARD.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    let mut file = NamedTempFile::new().expect("create temp rate card");
    file.write_all(contents.as_bytes()).expect("write rate card");
    file.flush().expect("flush rate card");
    std::env::set_var("RATECARD_PATH", file.path());
    let result = body();
    std::env::remove_var("RATECARD_PATH");
    drop(guard);
    result
}

fn with_missing_card<T>(body: impl FnOnce() -> T) -> T {
    let guard = ENV_GUARD.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    std::env::remove_var("RATECARD_PATH");
    let result = body();
    drop(guard);
    result
}

#[test]
fn prices_a_domestic_parcel_end_to_end() {
    let parcel = Parcel {
        weight_grams: 750,
        zone: "domestic".into(),
    };
    let quoted = with_card(SAMPLE, || quote(&parcel)).expect("a quote");
    assert_eq!(quoted.base_cents, 899);
    assert_eq!(quoted.surcharge_cents, 0);
    assert_eq!(quoted.total_cents, 899);
    assert_eq!(quoted.band_max_grams, 2000);
}

#[test]
fn prices_heavy_international_with_stacked_surcharges() {
    let parcel = Parcel {
        weight_grams: 18_000,
        zone: "international".into(),
    };
    let quoted = with_card(SAMPLE, || quote(&parcel)).expect("a quote");
    assert_eq!(quoted.base_cents, 4999);
    assert_eq!(quoted.surcharge_cents, 1500);
    assert_eq!(quoted.total_cents, 6499);
}

#[test]
fn unknown_zone_carries_requested_zone() {
    let parcel = Parcel {
        weight_grams: 100,
        zone: "lunar".into(),
    };
    let err = with_card(SAMPLE, || quote(&parcel)).unwrap_err();
    assert_eq!(err, QuoteError::UnknownZone("lunar".into()));
}

#[test]
fn overweight_carries_zone_limit() {
    let parcel = Parcel {
        weight_grams: 25_000,
        zone: "domestic".into(),
    };
    let err = with_card(SAMPLE, || quote(&parcel)).unwrap_err();
    assert_eq!(
        err,
        QuoteError::Overweight {
            grams: 25_000,
            limit: 20_000
        }
    );
}

#[test]
fn malformed_line_reports_one_based_number() {
    let broken = "# header\ndomestic\t500\t599\ndomestic\tnope\t100\n";
    let parcel = Parcel {
        weight_grams: 100,
        zone: "domestic".into(),
    };
    let err = with_card(broken, || quote(&parcel)).unwrap_err();
    assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
}

#[test]
fn unset_path_is_unavailable() {
    let parcel = Parcel {
        weight_grams: 100,
        zone: "domestic".into(),
    };
    let err = with_missing_card(|| quote(&parcel)).unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn missing_file_is_unavailable() {
    let parcel = Parcel {
        weight_grams: 100,
        zone: "domestic".into(),
    };
    let guard = ENV_GUARD.lock().unwrap_or_else(|p| p.into_inner());
    let missing = Path::new("/tmp/ratecard-does-not-exist-9f3a2b.tsv");
    std::env::set_var("RATECARD_PATH", missing);
    let err = quote(&parcel).unwrap_err();
    std::env::remove_var("RATECARD_PATH");
    drop(guard);
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn error_types_implement_std_error() {
    fn assert_error<E: std::error::Error>() {}
    assert_error::<QuoteError>();
}
