//! Shipping quotes from a zone rate card.
//!
//! Warehouse operators price outbound parcels against a rate card that
//! operations maintains and redeploys without a code change. This crate reads
//! that card and turns a [`Parcel`] into a [`Quote`].
//!
//! The crate is split into a pure core and a thin imperative shell:
//!
//! - [`RateCard`] parses card text and answers band lookups ([`card`]).
//! - [`price`] applies the pricing policy to a parcel ([`calc`]).
//! - [`RateCardSource`] is the gateway onto the filesystem ([`source`]); the
//!   [`quote`] function is the shell that wires the two together and emits a
//!   diagnostic record per call.
//!
//! ```no_run
//! use ratecard::{quote, Parcel};
//!
//! let parcel = Parcel { weight_grams: 750, zone: "domestic".into() };
//! let priced = quote(&parcel)?;
//! println!("{} cents", priced.total_cents);
//! # Ok::<(), ratecard::QuoteError>(())
//! ```

pub mod calc;
pub mod card;
pub mod model;
pub mod source;
pub mod zones;

pub use calc::price;
pub use card::RateCard;
pub use model::{Parcel, Quote, QuoteError};
pub use source::{EnvFileSource, RateCardSource};

/// Quote `parcel` against the rate card named by `RATECARD_PATH`.
///
/// This is the crate's imperative shell: it loads the card through the default
/// [`EnvFileSource`] gateway, parses it, applies the pure pricing policy, and
/// emits one structured diagnostic record — carrying the zone, weight, and
/// resulting total — before returning.
///
/// See [`crate::model::QuoteError`] for the failure modes.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_with_source(&EnvFileSource, parcel)
}

/// Quote `parcel` against the card provided by `source`.
///
/// The shell behind [`quote`], parameterised over the [`RateCardSource`]
/// gateway so tests can drive it with an in-memory fake instead of the
/// filesystem.
pub fn quote_with_source<S: RateCardSource>(
    source: &S,
    parcel: &Parcel,
) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "quote",
        zone = parcel.zone.as_str(),
        weight_grams = parcel.weight_grams,
    );
    let _enter = span.enter();

    let result = source
        .load()
        .and_then(|text| RateCard::parse(&text))
        .and_then(|card| price(&card, parcel));

    match &result {
        Ok(quote) => tracing::info!(
            zone = parcel.zone.as_str(),
            weight_grams = parcel.weight_grams,
            total_cents = quote.total_cents,
            outcome = "quoted",
            "quote produced",
        ),
        Err(error) => tracing::warn!(
            zone = parcel.zone.as_str(),
            weight_grams = parcel.weight_grams,
            outcome = "error",
            error = %error,
            "quote failed",
        ),
    }

    result
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    struct FakeSource {
        text: Result<String, QuoteError>,
    }

    impl RateCardSource for FakeSource {
        fn load(&self) -> Result<String, QuoteError> {
            self.text.clone()
        }
    }

    fn ok_source() -> FakeSource {
        FakeSource {
            text: Ok(SAMPLE.to_string()),
        }
    }

    #[test]
    fn wires_card_through_to_a_quote() {
        let parcel = Parcel {
            weight_grams: 750,
            zone: "domestic".into(),
        };
        let quote = quote_with_source(&ok_source(), &parcel).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn unavailable_source_surfaces_unavailable() {
        let source = FakeSource {
            text: Err(QuoteError::RateCardUnavailable),
        };
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        assert_eq!(
            quote_with_source(&source, &parcel).unwrap_err(),
            QuoteError::RateCardUnavailable
        );
    }

    #[test]
    fn malformed_card_surfaces_line() {
        let source = FakeSource {
            text: Ok("domestic\t500\t599\nbroken\tline\n".to_string()),
        };
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        assert_eq!(
            quote_with_source(&source, &parcel).unwrap_err(),
            QuoteError::MalformedRateCard { line: 2 }
        );
    }
}
