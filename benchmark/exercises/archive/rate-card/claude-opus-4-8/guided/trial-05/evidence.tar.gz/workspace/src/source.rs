//! The rate-card gateway: the crate's one edge onto the environment and
//! filesystem.
//!
//! Business logic depends on the [`RateCardSource`] trait, never on
//! [`std::env`](mod@std::env) or [`std::fs`] directly. The concrete
//! [`EnvFileSource`] is the
//! thin adapter that reads `RATECARD_PATH` and its file; tests substitute an
//! in-memory fake that implements the same project-owned contract.

use crate::model::QuoteError;

/// A source of raw rate-card text.
///
/// Implementations return the card's full contents, or
/// [`QuoteError::RateCardUnavailable`] when the card cannot be obtained.
pub trait RateCardSource {
    /// Load the rate card's raw text.
    fn load(&self) -> Result<String, QuoteError>;
}

/// Reads the rate card from the file named by the `RATECARD_PATH` environment
/// variable.
///
/// An unset variable, or a missing or unreadable file, becomes
/// [`QuoteError::RateCardUnavailable`].
#[derive(Debug, Default, Clone, Copy)]
pub struct EnvFileSource;

/// The environment variable naming the rate-card file.
pub const RATECARD_PATH_VAR: &str = "RATECARD_PATH";

impl RateCardSource for EnvFileSource {
    fn load(&self) -> Result<String, QuoteError> {
        let path = std::env::var_os(RATECARD_PATH_VAR).ok_or(QuoteError::RateCardUnavailable)?;
        std::fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}
