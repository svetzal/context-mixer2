//! Public domain types for shipping quotes.
//!
//! These are plain data: a [`Parcel`] describes what a caller wants priced, a
//! [`Quote`] is the priced result, and [`QuoteError`] enumerates the ways a
//! quote can fail. They carry no I/O and no behaviour beyond error formatting.

/// A parcel to be priced against the rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Billable weight of the parcel, in grams.
    pub weight_grams: u32,
    /// Delivery zone name, matched against the rate card's zones.
    pub zone: String,
}

/// The priced result for a [`Parcel`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// The matching band's price, in cents, before surcharges.
    pub base_cents: u64,
    /// Total surcharges applied on top of `base_cents`, in cents.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`, in cents.
    pub total_cents: u64,
    /// The `band_max_grams` threshold of the band that matched.
    pub band_max_grams: u32,
}

/// The recoverable failure modes of [`quote`](crate::quote).
///
/// Every variant is a condition a caller can reasonably handle; none of them
/// warrant terminating the process.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The `RATECARD_PATH` environment variable is unset, or its file is
    /// missing or unreadable.
    RateCardUnavailable,
    /// A rate-card line is not three tab-separated fields, or its numbers do
    /// not parse. `line` is the 1-based line number in the file, counting
    /// comments and blank lines.
    MalformedRateCard {
        /// 1-based line number of the offending line.
        line: usize,
    },
    /// The requested zone has no bands in the rate card. Carries the zone that
    /// was requested.
    UnknownZone(String),
    /// The parcel weighs more than the zone's largest band allows.
    Overweight {
        /// The parcel's weight, in grams.
        grams: u32,
        /// The largest `band_max_grams` available for the zone.
        limit: u32,
    },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable: check RATECARD_PATH")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel of {grams}g exceeds zone limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}
