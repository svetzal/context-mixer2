//! Pure quote logic.
//!
//! Everything in this module is free of I/O: it parses rate-card *text* and
//! computes quotes from in-memory data. This keeps the pricing policy
//! deterministic and testable without a filesystem or environment.

use crate::Parcel;

/// A single rate-card band: for `zone`, parcels up to `band_max_grams` cost
/// `cents`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Band {
    /// Zone this band applies to.
    pub zone: String,
    /// Inclusive upper weight bound, in grams, for this band.
    pub band_max_grams: u32,
    /// Base price for this band, in cents.
    pub cents: u64,
}

/// The band price already resolved for a parcel, before surcharges.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct MatchedBand {
    /// Base price, in cents.
    pub base_cents: u64,
    /// The band's weight threshold, in grams.
    pub band_max_grams: u32,
}

/// Failures that arise purely from rate-card content or the requested parcel,
/// independent of how the card was obtained.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CoreError {
    /// A line was not three tab-separated fields, or its numbers did not parse.
    /// Carries the 1-based line number of the offending line.
    Malformed {
        /// 1-based line number, counting comments and blanks.
        line: usize,
    },
    /// The requested zone is absent from the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight {
        /// Requested weight, in grams.
        grams: u32,
        /// The zone's largest band threshold, in grams.
        limit: u32,
    },
}

/// Weight, in grams, strictly above which the heavy-parcel surcharge applies.
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;

/// Flat surcharge, in cents, for parcels above [`HEAVY_THRESHOLD_GRAMS`].
const HEAVY_SURCHARGE_CENTS: u64 = 500;

/// Zone whose base price attracts a percentage surcharge.
const INTERNATIONAL_ZONE: &str = "international";

/// Parse tab-separated rate-card text into bands.
///
/// Lines that are empty (or whitespace only) or begin with `#` are ignored.
/// Line numbering is 1-based and counts every line, including comments and
/// blanks, so a reported [`CoreError::Malformed`] points at the real source
/// line.
pub fn parse_rate_card(text: &str) -> Result<Vec<Band>, CoreError> {
    let mut bands = Vec::new();
    for (index, raw) in text.lines().enumerate() {
        let line = index + 1;
        let trimmed = raw.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = raw.split('\t').collect();
        if fields.len() != 3 {
            return Err(CoreError::Malformed { line });
        }
        let band_max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| CoreError::Malformed { line })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| CoreError::Malformed { line })?;
        bands.push(Band {
            zone: fields[0].to_string(),
            band_max_grams,
            cents,
        });
    }
    Ok(bands)
}

/// Resolve the band that prices `parcel` against the parsed rate card.
pub fn match_band(bands: &[Band], parcel: &Parcel) -> Result<MatchedBand, CoreError> {
    let mut zone_bands: Vec<&Band> = bands.iter().filter(|b| b.zone == parcel.zone).collect();
    if zone_bands.is_empty() {
        return Err(CoreError::UnknownZone(parcel.zone.clone()));
    }
    zone_bands.sort_by_key(|b| b.band_max_grams);

    let limit = zone_bands
        .iter()
        .map(|b| b.band_max_grams)
        .max()
        .unwrap_or(0);

    match zone_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
    {
        Some(band) => Ok(MatchedBand {
            base_cents: band.cents,
            band_max_grams: band.band_max_grams,
        }),
        None => Err(CoreError::Overweight {
            grams: parcel.weight_grams,
            limit,
        }),
    }
}

/// The total surcharge, in cents, for a parcel priced at `base_cents`.
///
/// Surcharges accumulate:
/// - weight strictly above 10000 grams adds 500 cents;
/// - the `international` zone adds 20% of `base_cents`, rounded half-up.
pub fn surcharge_cents(parcel: &Parcel, base_cents: u64) -> u64 {
    let mut total = 0;
    if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        total += HEAVY_SURCHARGE_CENTS;
    }
    if parcel.zone == INTERNATIONAL_ZONE {
        total += international_surcharge(base_cents);
    }
    total
}

/// 20% of `base_cents`, rounded half-up to the nearest cent.
///
/// Uses integer arithmetic: `(base_cents * 20 + 50) / 100`, factored to
/// `(base_cents * 2 + 5) / 10`, which rounds a trailing half upward.
fn international_surcharge(base_cents: u64) -> u64 {
    (base_cents * 2 + 5) / 10
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn skips_comments_and_blanks() {
        let bands = parse_rate_card(SAMPLE).expect("sample parses");
        assert_eq!(bands.len(), 5);
        assert_eq!(bands[0].zone, "domestic");
        assert_eq!(bands[0].band_max_grams, 500);
        assert_eq!(bands[0].cents, 599);
    }

    #[test]
    fn blank_lines_are_ignored_but_still_counted() {
        let text = "\n\n# note\ndomestic\t500\t599\n";
        let bands = parse_rate_card(text).expect("parses");
        assert_eq!(bands, vec![Band { zone: "domestic".into(), band_max_grams: 500, cents: 599 }]);
    }

    #[test]
    fn wrong_field_count_is_malformed_with_line_number() {
        let text = "# header\ndomestic\t500\n";
        assert_eq!(parse_rate_card(text), Err(CoreError::Malformed { line: 2 }));
    }

    #[test]
    fn unparsable_number_is_malformed_with_line_number() {
        let text = "domestic\t500\t599\ndomestic\ttwo-k\t899\n";
        assert_eq!(parse_rate_card(text), Err(CoreError::Malformed { line: 2 }));
    }

    #[test]
    fn matches_first_band_at_or_above_weight() {
        let bands = parse_rate_card(SAMPLE).expect("parses");
        let matched = match_band(&bands, &parcel(500, "domestic")).expect("matches");
        assert_eq!(matched.base_cents, 599);
        assert_eq!(matched.band_max_grams, 500);

        let matched = match_band(&bands, &parcel(501, "domestic")).expect("matches");
        assert_eq!(matched.base_cents, 899);
        assert_eq!(matched.band_max_grams, 2000);
    }

    #[test]
    fn unknown_zone_carries_requested_zone() {
        let bands = parse_rate_card(SAMPLE).expect("parses");
        assert_eq!(
            match_band(&bands, &parcel(100, "lunar")),
            Err(CoreError::UnknownZone("lunar".to_string()))
        );
    }

    #[test]
    fn overweight_reports_largest_band_as_limit() {
        let bands = parse_rate_card(SAMPLE).expect("parses");
        assert_eq!(
            match_band(&bands, &parcel(20001, "domestic")),
            Err(CoreError::Overweight { grams: 20001, limit: 20000 })
        );
    }

    #[test]
    fn heavy_parcel_adds_flat_surcharge() {
        assert_eq!(surcharge_cents(&parcel(10000, "domestic"), 1799), 0);
        assert_eq!(surcharge_cents(&parcel(10001, "domestic"), 1799), 500);
    }

    #[test]
    fn international_surcharge_is_twenty_percent_half_up() {
        assert_eq!(surcharge_cents(&parcel(400, "international"), 1499), 300);
        assert_eq!(surcharge_cents(&parcel(400, "international"), 4999), 1000);
    }

    #[test]
    fn heavy_international_parcel_stacks_both_surcharges() {
        // 20% of 4999 = 999.8 -> 1000, plus 500 for weight over 10kg.
        assert_eq!(surcharge_cents(&parcel(15000, "international"), 4999), 1500);
    }
}
