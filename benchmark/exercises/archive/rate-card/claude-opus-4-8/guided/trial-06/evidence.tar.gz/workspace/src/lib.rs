//! Shipping quotes from a zone rate card.
//!
//! The crate root exports the fixed public contract — [`Parcel`], [`Quote`],
//! [`QuoteError`], and [`quote`]. Internally the work is split into a pure
//! `core` (parsing and pricing) and a thin `gateway` shell that reads the rate
//! card from the environment and filesystem.
//!
//! ```no_run
//! use ratecard::{quote, Parcel};
//!
//! // With RATECARD_PATH pointing at a valid rate card:
//! let parcel = Parcel { weight_grams: 750, zone: "domestic".to_string() };
//! if let Ok(q) = quote(&parcel) {
//!     println!("total: {} cents", q.total_cents);
//! }
//! ```

mod core;
mod gateway;
pub mod zones;

use std::fmt;

use crate::core::CoreError;
use crate::gateway::{EnvFileRateCardSource, RateCardSource};

/// A parcel to be priced: its weight in grams and its shipping zone.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight, in grams.
    pub weight_grams: u32,
    /// Shipping zone name, matched against the rate card.
    pub zone: String,
}

/// A computed shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Base price from the matching band, in cents.
    pub base_cents: u64,
    /// Accumulated surcharges, in cents.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`, in cents.
    pub total_cents: u64,
    /// The matching band's weight threshold, in grams.
    pub band_max_grams: u32,
}

/// The ways a quote can fail.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card was missing, unreadable, or its path was unset.
    RateCardUnavailable,
    /// A rate-card line was malformed; carries its 1-based line number.
    MalformedRateCard {
        /// 1-based line number of the offending line.
        line: usize,
    },
    /// The requested zone is absent from the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight {
        /// Requested weight, in grams.
        grams: u32,
        /// The zone's largest band threshold, in grams.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card is unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel of {grams} g exceeds the zone limit of {limit} g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

impl From<CoreError> for QuoteError {
    fn from(error: CoreError) -> Self {
        match error {
            CoreError::Malformed { line } => QuoteError::MalformedRateCard { line },
            CoreError::UnknownZone(zone) => QuoteError::UnknownZone(zone),
            CoreError::Overweight { grams, limit } => QuoteError::Overweight { grams, limit },
        }
    }
}

/// Price a parcel against the rate card named by `RATECARD_PATH`.
///
/// Reads and parses the rate card, resolves the matching band, applies
/// surcharges, and emits a structured diagnostic record carrying the zone,
/// weight, and resulting total.
///
/// # Errors
///
/// Returns [`QuoteError`] when the rate card cannot be obtained, is malformed,
/// does not cover the requested zone, or cannot accommodate the parcel's
/// weight.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_with(&EnvFileRateCardSource, parcel)
}

/// Price a parcel against an explicit rate-card source.
///
/// This is the wiring seam: it depends only on the [`RateCardSource`] gateway
/// contract, so callers (and tests) can supply any source.
fn quote_with(source: &impl RateCardSource, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let text = source.load().map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = core::parse_rate_card(&text)?;
    let matched = core::match_band(&bands, parcel)?;

    let base_cents = matched.base_cents;
    let surcharge_cents = core::surcharge_cents(parcel, base_cents);
    let total_cents = base_cents + surcharge_cents;

    let quote = Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: matched.band_max_grams,
    };

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = quote.total_cents,
        "shipping quote computed"
    );

    Ok(quote)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::gateway::Unavailable;

    struct StaticSource(Result<String, Unavailable>);

    impl RateCardSource for StaticSource {
        fn load(&self) -> Result<String, Unavailable> {
            self.0.clone()
        }
    }

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    fn source(text: &str) -> StaticSource {
        StaticSource(Ok(text.to_string()))
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel { weight_grams, zone: zone.to_string() }
    }

    #[test]
    fn domestic_light_parcel_has_no_surcharge() {
        let q = quote_with(&source(SAMPLE), &parcel(500, "domestic")).expect("quote");
        assert_eq!(q, Quote { base_cents: 599, surcharge_cents: 0, total_cents: 599, band_max_grams: 500 });
    }

    #[test]
    fn international_parcel_adds_percentage_surcharge() {
        let q = quote_with(&source(SAMPLE), &parcel(400, "international")).expect("quote");
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn heavy_domestic_parcel_adds_flat_surcharge() {
        let q = quote_with(&source(SAMPLE), &parcel(15000, "domestic")).expect("quote");
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn unavailable_source_maps_to_rate_card_unavailable() {
        let source = StaticSource(Err(Unavailable));
        assert_eq!(quote_with(&source, &parcel(500, "domestic")), Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn malformed_line_number_propagates() {
        let text = "domestic\t500\t599\nbroken-line\n";
        assert_eq!(
            quote_with(&source(text), &parcel(100, "domestic")),
            Err(QuoteError::MalformedRateCard { line: 2 })
        );
    }

    #[test]
    fn unknown_zone_and_overweight_propagate() {
        assert_eq!(
            quote_with(&source(SAMPLE), &parcel(100, "lunar")),
            Err(QuoteError::UnknownZone("lunar".to_string()))
        );
        assert_eq!(
            quote_with(&source(SAMPLE), &parcel(20001, "international")),
            Err(QuoteError::Overweight { grams: 20001, limit: 20000 })
        );
    }

    #[test]
    fn error_types_display_and_are_std_errors() {
        let err: &dyn std::error::Error = &QuoteError::UnknownZone("mars".to_string());
        assert_eq!(err.to_string(), "unknown zone: mars");
    }
}
