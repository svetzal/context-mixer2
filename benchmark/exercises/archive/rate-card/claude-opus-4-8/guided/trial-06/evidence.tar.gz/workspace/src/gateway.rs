//! The thin imperative shell that supplies rate-card text.
//!
//! Reading configuration and the filesystem is an effect. It lives behind the
//! [`RateCardSource`] gateway trait so the pure core never depends on a
//! concrete I/O client, and so tests can substitute an in-memory source.

use std::env;
use std::fs;

/// The rate card could not be obtained.
///
/// A single opaque variant: from the caller's perspective an unset path, a
/// missing file, and an unreadable file are the same recoverable condition.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Unavailable;

/// A source of raw rate-card text.
pub trait RateCardSource {
    /// Load the rate-card text, or report that it is unavailable.
    fn load(&self) -> Result<String, Unavailable>;
}

/// Reads the rate card from the file named by the `RATECARD_PATH` environment
/// variable.
#[derive(Debug, Default, Clone)]
pub struct EnvFileRateCardSource;

impl RateCardSource for EnvFileRateCardSource {
    fn load(&self) -> Result<String, Unavailable> {
        let path = env::var("RATECARD_PATH").map_err(|_| Unavailable)?;
        fs::read_to_string(path).map_err(|_| Unavailable)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// An in-memory fake honouring the same [`RateCardSource`] contract, used
    /// to exercise wiring without touching the environment or filesystem.
    struct InMemorySource(Result<String, Unavailable>);

    impl RateCardSource for InMemorySource {
        fn load(&self) -> Result<String, Unavailable> {
            self.0.clone()
        }
    }

    #[test]
    fn fake_source_returns_its_text() {
        let source = InMemorySource(Ok("domestic\t500\t599\n".to_string()));
        assert_eq!(source.load(), Ok("domestic\t500\t599\n".to_string()));
    }

    #[test]
    fn fake_source_can_report_unavailable() {
        let source = InMemorySource(Err(Unavailable));
        assert_eq!(source.load(), Err(Unavailable));
    }
}
