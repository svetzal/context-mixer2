//! Boundary tests for the public `quote` wiring: they exercise the real
//! `RATECARD_PATH` environment variable and filesystem read.
//!
//! `RATECARD_PATH` is process-global, so these tests serialize their access to
//! it through a mutex rather than relying on Cargo's default parallelism.

use std::env;
use std::sync::Mutex;

use ratecard::{quote, Parcel, QuoteError};
use tempfile::NamedTempFile;

static ENV_LOCK: Mutex<()> = Mutex::new(());

const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

/// Write `contents` to a temp file, point `RATECARD_PATH` at it, and run `body`
/// while holding the environment lock. The temp file lives until `body`
/// returns.
fn with_rate_card<T>(contents: &str, body: impl FnOnce() -> T) -> T {
    let guard = ENV_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    let file = NamedTempFile::new().expect("create temp rate card");
    std::fs::write(file.path(), contents).expect("write rate card");
    env::set_var("RATECARD_PATH", file.path());
    let result = body();
    env::remove_var("RATECARD_PATH");
    drop(guard);
    result
}

#[test]
fn quotes_a_domestic_parcel_from_a_file() {
    let quote = with_rate_card(SAMPLE, || {
        quote(&Parcel { weight_grams: 750, zone: "domestic".to_string() }).expect("quote")
    });
    assert_eq!(quote.base_cents, 899);
    assert_eq!(quote.surcharge_cents, 0);
    assert_eq!(quote.total_cents, 899);
    assert_eq!(quote.band_max_grams, 2000);
}

#[test]
fn quotes_a_heavy_international_parcel_from_a_file() {
    let quote = with_rate_card(SAMPLE, || {
        quote(&Parcel { weight_grams: 15000, zone: "international".to_string() }).expect("quote")
    });
    // Largest international band is 20000 @ 4999; 20% of 4999 = 1000, plus 500
    // for weight over 10kg.
    assert_eq!(quote.base_cents, 4999);
    assert_eq!(quote.surcharge_cents, 1500);
    assert_eq!(quote.total_cents, 6499);
    assert_eq!(quote.band_max_grams, 20000);
}

#[test]
fn unset_path_is_rate_card_unavailable() {
    let guard = ENV_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    env::remove_var("RATECARD_PATH");
    let result = quote(&Parcel { weight_grams: 100, zone: "domestic".to_string() });
    drop(guard);
    assert_eq!(result, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn missing_file_is_rate_card_unavailable() {
    let guard = ENV_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    env::set_var("RATECARD_PATH", "/no/such/rate/card/at/this/path.tsv");
    let result = quote(&Parcel { weight_grams: 100, zone: "domestic".to_string() });
    env::remove_var("RATECARD_PATH");
    drop(guard);
    assert_eq!(result, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn malformed_file_reports_line_number() {
    let text = "# header\ndomestic\t500\t599\ndomestic\tnot-a-number\t899\n";
    let result = with_rate_card(text, || {
        quote(&Parcel { weight_grams: 100, zone: "domestic".to_string() })
    });
    assert_eq!(result, Err(QuoteError::MalformedRateCard { line: 3 }));
}
