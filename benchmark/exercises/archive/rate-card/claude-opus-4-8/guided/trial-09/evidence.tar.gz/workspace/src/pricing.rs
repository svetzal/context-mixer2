//! Pure pricing core.
//!
//! Everything in this module is a pure function over in-memory data: it parses
//! rate-card text into bands and prices a parcel against them. There is no I/O
//! here, so the behaviour is deterministic and can be exercised without a
//! filesystem, environment, or runtime services.

use crate::{Parcel, Quote, QuoteError};

/// Grams above which the heavy-parcel surcharge applies (strictly greater than).
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;

/// Flat surcharge, in cents, for parcels over [`HEAVY_THRESHOLD_GRAMS`].
const HEAVY_SURCHARGE_CENTS: u64 = 500;

/// Zone name that attracts the proportional international surcharge.
const INTERNATIONAL_ZONE: &str = "international";

/// Proportional international surcharge, expressed as a percentage of the base.
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

/// A single priced band within the rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct Band {
    /// Zone this band belongs to.
    zone: String,
    /// Inclusive upper weight bound, in grams, for this band.
    max_grams: u32,
    /// Base price, in cents, for parcels that fall in this band.
    cents: u64,
}

/// A parsed rate card: an unordered collection of priced bands.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub(crate) struct RateCard {
    bands: Vec<Band>,
}

impl RateCard {
    /// Parse tab-separated rate-card text into a [`RateCard`].
    ///
    /// Empty lines and lines beginning with `#` are ignored. Every remaining
    /// line must hold exactly three tab-separated fields — zone, max grams, and
    /// cents — whose numeric fields parse. A line that fails either check yields
    /// [`QuoteError::MalformedRateCard`] carrying its 1-based line number,
    /// counting every line in the input including comments and blanks.
    pub(crate) fn parse(text: &str) -> Result<Self, QuoteError> {
        let mut bands = Vec::new();

        for (index, line) in text.lines().enumerate() {
            let line_number = index + 1;

            if line.is_empty() || line.starts_with('#') {
                continue;
            }

            let fields: Vec<&str> = line.split('\t').collect();
            if fields.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: line_number });
            }

            let max_grams = fields[1]
                .parse::<u32>()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
            let cents = fields[2]
                .parse::<u64>()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

            bands.push(Band {
                zone: fields[0].to_string(),
                max_grams,
                cents,
            });
        }

        Ok(Self { bands })
    }

    /// Price a parcel against this rate card.
    ///
    /// Returns [`QuoteError::UnknownZone`] when the parcel's zone has no bands,
    /// and [`QuoteError::Overweight`] when the parcel is heavier than the zone's
    /// largest band.
    pub(crate) fn price(&self, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let mut zone_bands: Vec<&Band> = self
            .bands
            .iter()
            .filter(|band| band.zone == parcel.zone)
            .collect();

        if zone_bands.is_empty() {
            return Err(QuoteError::UnknownZone(parcel.zone.clone()));
        }

        zone_bands.sort_by_key(|band| band.max_grams);

        // Bands are sorted ascending, so the largest bound is the last one and
        // the matching band is the first whose bound covers the weight.
        let limit = zone_bands
            .last()
            .map(|band| band.max_grams)
            .unwrap_or(0); // zone_bands is non-empty here.

        let band = zone_bands
            .iter()
            .find(|band| parcel.weight_grams <= band.max_grams)
            .ok_or(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            })?;

        let base_cents = band.cents;
        let surcharge_cents = surcharge_for(parcel, base_cents);
        let total_cents = base_cents + surcharge_cents;

        Ok(Quote {
            base_cents,
            surcharge_cents,
            total_cents,
            band_max_grams: band.max_grams,
        })
    }
}

/// Compute the combined surcharge, in cents, for a parcel and its base price.
///
/// A parcel strictly heavier than [`HEAVY_THRESHOLD_GRAMS`] adds a flat charge,
/// and an international parcel adds a percentage of the base rounded half-up to
/// the nearest cent. The two surcharges add together.
fn surcharge_for(parcel: &Parcel, base_cents: u64) -> u64 {
    let mut surcharge = 0;

    if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        surcharge += HEAVY_SURCHARGE_CENTS;
    }

    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge += percent_half_up(base_cents, INTERNATIONAL_SURCHARGE_PERCENT);
    }

    surcharge
}

/// Return `percent`% of `value`, rounded half-up to the nearest integer.
fn percent_half_up(value: u64, percent: u64) -> u64 {
    (value * percent + 50) / 100
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999";

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    fn quote(text: &str, weight_grams: u32, zone: &str) -> Result<Quote, QuoteError> {
        RateCard::parse(text)?.price(&parcel(weight_grams, zone))
    }

    #[test]
    fn matches_first_band_at_or_above_weight() {
        let q = quote(SAMPLE, 300, "domestic").expect("priced");
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
    }

    #[test]
    fn weight_equal_to_bound_selects_that_band() {
        let q = quote(SAMPLE, 500, "domestic").expect("priced");
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn weight_just_over_bound_selects_next_band() {
        let q = quote(SAMPLE, 501, "domestic").expect("priced");
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn heavy_parcel_adds_flat_surcharge() {
        // 10001g is strictly above the 10000g threshold.
        let q = quote(SAMPLE, 10_001, "domestic").expect("priced");
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn weight_exactly_at_heavy_threshold_has_no_surcharge() {
        let q = quote(SAMPLE, 10_000, "domestic").expect("priced");
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_proportional_surcharge() {
        // 20% of 1499 = 299.8, rounded half-up to 300.
        let q = quote(SAMPLE, 400, "international").expect("priced");
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_and_heavy_surcharges_add_together() {
        // Base 4999, +20% (1000, from 999.8 half-up) and +500 flat.
        let q = quote(SAMPLE, 15_000, "international").expect("priced");
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1000 + 500);
        assert_eq!(q.total_cents, 4999 + 1500);
    }

    #[test]
    fn unknown_zone_carries_requested_zone() {
        match quote(SAMPLE, 100, "lunar") {
            Err(QuoteError::UnknownZone(zone)) => assert_eq!(zone, "lunar"),
            other => panic!("expected UnknownZone, got {other:?}"),
        }
    }

    #[test]
    fn overweight_carries_grams_and_largest_limit() {
        match quote(SAMPLE, 25_000, "domestic") {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 25_000);
                assert_eq!(limit, 20_000);
            }
            other => panic!("expected Overweight, got {other:?}"),
        }
    }

    #[test]
    fn wrong_field_count_is_malformed_with_line_number() {
        let text = "# header\ndomestic\t500\t599\ndomestic\t2000"; // line 3 malformed
        match RateCard::parse(text) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
            other => panic!("expected MalformedRateCard, got {other:?}"),
        }
    }

    #[test]
    fn non_numeric_field_is_malformed_with_line_number() {
        let text = "domestic\tfive-hundred\t599"; // line 1 malformed
        match RateCard::parse(text) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            other => panic!("expected MalformedRateCard, got {other:?}"),
        }
    }

    #[test]
    fn blank_and_comment_lines_still_count_toward_line_numbers() {
        let text = "\n# comment\n\ndomestic\t500\tnope"; // line 4 malformed
        match RateCard::parse(text) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 4),
            other => panic!("expected MalformedRateCard, got {other:?}"),
        }
    }

    #[test]
    fn half_up_rounding_is_used() {
        assert_eq!(percent_half_up(1499, 20), 300); // 299.8 -> 300
        assert_eq!(percent_half_up(4999, 20), 1000); // 999.8 -> 1000
        assert_eq!(percent_half_up(500, 20), 100); // 100.0 -> 100
    }
}
