//! Rate-card source gateway.
//!
//! The pricing core depends on the project-owned [`RateCardSource`] contract
//! rather than on `std::env` or `std::fs` directly. Production wires in
//! [`EnvFileSource`], which reads the path named by `RATECARD_PATH`; tests can
//! substitute an in-memory fake that implements the same contract.

/// The rate card could not be obtained.
///
/// This is the gateway's single edge failure: the source path is unset, or the
/// file behind it is missing or unreadable.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Unavailable;

/// A source of raw rate-card text.
pub trait RateCardSource {
    /// Load the raw rate-card text, or report it [`Unavailable`].
    fn load(&self) -> Result<String, Unavailable>;
}

/// Environment variable naming the rate-card file.
const RATECARD_PATH_VAR: &str = "RATECARD_PATH";

/// Reads the rate card from the file named by the `RATECARD_PATH` environment
/// variable. This is the thin imperative shell around the filesystem.
#[derive(Debug, Clone, Default)]
pub struct EnvFileSource;

impl EnvFileSource {
    /// Construct a source that reads `RATECARD_PATH` at load time.
    pub fn new() -> Self {
        Self
    }
}

impl RateCardSource for EnvFileSource {
    fn load(&self) -> Result<String, Unavailable> {
        let path = std::env::var(RATECARD_PATH_VAR).map_err(|_| Unavailable)?;
        std::fs::read_to_string(path).map_err(|_| Unavailable)
    }
}
