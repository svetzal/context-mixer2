//! Cross-module wiring tests: exercise the public [`ratecard::quote`] through a
//! real `RATECARD_PATH` and temp file. `RATECARD_PATH` is process-global, so a
//! mutex serializes the tests that touch it.

// This is a test crate; asserting by panic and unwrapping fixtures is expected.
#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

use std::io::Write;
use std::sync::Mutex;

use ratecard::{quote, Parcel, QuoteError};
use tempfile::NamedTempFile;

/// Serializes access to the shared `RATECARD_PATH` environment variable.
static ENV_LOCK: Mutex<()> = Mutex::new(());

const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_string(),
    }
}

/// Write `contents` to a temp file, point `RATECARD_PATH` at it, and run `body`.
/// The temp file outlives `body`; the lock is held for the whole closure.
fn with_rate_card<T>(contents: &str, body: impl FnOnce() -> T) -> T {
    let guard = ENV_LOCK.lock().unwrap_or_else(|poison| poison.into_inner());

    let mut file = NamedTempFile::new().expect("create temp rate card");
    file.write_all(contents.as_bytes())
        .expect("write temp rate card");
    file.flush().expect("flush temp rate card");

    std::env::set_var("RATECARD_PATH", file.path());
    let result = body();
    std::env::remove_var("RATECARD_PATH");

    drop(guard);
    result
}

#[test]
fn prices_a_domestic_parcel_end_to_end() {
    with_rate_card(SAMPLE, || {
        let q = quote(&parcel(300, "domestic")).expect("priced");
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    });
}

#[test]
fn prices_an_international_parcel_with_surcharge() {
    with_rate_card(SAMPLE, || {
        let q = quote(&parcel(400, "international")).expect("priced");
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
        assert_eq!(q.band_max_grams, 500);
    });
}

#[test]
fn heavy_international_parcel_combines_surcharges() {
    with_rate_card(SAMPLE, || {
        let q = quote(&parcel(15_000, "international")).expect("priced");
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
        assert_eq!(q.band_max_grams, 20_000);
    });
}

#[test]
fn unknown_zone_is_reported() {
    with_rate_card(SAMPLE, || {
        assert_eq!(
            quote(&parcel(100, "lunar")),
            Err(QuoteError::UnknownZone("lunar".into()))
        );
    });
}

#[test]
fn overweight_is_reported_with_the_largest_limit() {
    with_rate_card(SAMPLE, || {
        assert_eq!(
            quote(&parcel(30_000, "domestic")),
            Err(QuoteError::Overweight {
                grams: 30_000,
                limit: 20_000,
            })
        );
    });
}

#[test]
fn malformed_line_is_reported_with_its_number() {
    let card = "# header\ndomestic\t500\t599\nbroken-line\n";
    with_rate_card(card, || {
        assert_eq!(
            quote(&parcel(100, "domestic")),
            Err(QuoteError::MalformedRateCard { line: 3 })
        );
    });
}

#[test]
fn unset_path_is_rate_card_unavailable() {
    let guard = ENV_LOCK.lock().unwrap_or_else(|poison| poison.into_inner());
    std::env::remove_var("RATECARD_PATH");
    assert_eq!(
        quote(&parcel(100, "domestic")),
        Err(QuoteError::RateCardUnavailable)
    );
    drop(guard);
}

#[test]
fn missing_file_is_rate_card_unavailable() {
    let guard = ENV_LOCK.lock().unwrap_or_else(|poison| poison.into_inner());
    std::env::set_var("RATECARD_PATH", "/no/such/rate/card/file.tsv");
    let result = quote(&parcel(100, "domestic"));
    std::env::remove_var("RATECARD_PATH");
    drop(guard);
    assert_eq!(result, Err(QuoteError::RateCardUnavailable));
}
