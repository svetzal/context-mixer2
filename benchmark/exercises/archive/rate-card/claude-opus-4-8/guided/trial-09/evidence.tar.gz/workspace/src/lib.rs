//! Shipping quotes from a zone rate card.
//!
//! The crate reads a tab-separated rate card, selects the band that covers a
//! parcel's weight, applies weight- and zone-based surcharges, and returns a
//! [`Quote`]. Reading the card is isolated behind the [`source`] gateway so the
//! pricing logic in [`pricing`] stays pure and testable.
//!
//! # Example
//!
//! ```
//! use std::io::Write;
//!
//! let mut file = tempfile::NamedTempFile::new().unwrap();
//! writeln!(file, "domestic\t500\t599").unwrap();
//! writeln!(file, "domestic\t2000\t899").unwrap();
//! std::env::set_var("RATECARD_PATH", file.path());
//!
//! let parcel = ratecard::Parcel { weight_grams: 300, zone: "domestic".into() };
//! let quote = ratecard::quote(&parcel).unwrap();
//! assert_eq!(quote.base_cents, 599);
//! assert_eq!(quote.total_cents, 599);
//! assert_eq!(quote.band_max_grams, 500);
//! ```

// The panic-avoidance restriction lints target recoverable paths in shipped
// library code; test code legitimately asserts by panicking.
#![cfg_attr(
    test,
    allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)
)]

pub mod pricing;
pub mod source;
pub mod zones;

use source::{EnvFileSource, RateCardSource, Unavailable};

/// A parcel to be priced: a weight and a shipping zone.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Shipping zone the parcel is bound for.
    pub zone: String,
}

/// A computed shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Base price, in cents, of the matching band.
    pub base_cents: u64,
    /// Combined surcharges, in cents.
    pub surcharge_cents: u64,
    /// Total price, in cents: `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// Upper weight bound, in grams, of the matching band.
    pub band_max_grams: u32,
}

/// A reason a quote could not be produced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card is missing, unreadable, or its path is unset.
    RateCardUnavailable,
    /// A rate-card line was not three tab-separated fields, or its numbers did
    /// not parse. Carries the offending 1-based line number.
    MalformedRateCard {
        /// 1-based line number of the offending line.
        line: usize,
    },
    /// The requested zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight {
        /// The parcel weight, in grams.
        grams: u32,
        /// The largest available band bound, in grams.
        limit: u32,
    },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel of {grams}g exceeds the limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

impl From<Unavailable> for QuoteError {
    fn from(_: Unavailable) -> Self {
        Self::RateCardUnavailable
    }
}

/// Quote a parcel against the rate card named by `RATECARD_PATH`.
///
/// This is the imperative shell: it reads the card through the environment-backed
/// [`EnvFileSource`] gateway, prices the parcel with the pure core, and emits a
/// tracing record for the call.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_with(&EnvFileSource::new(), parcel)
}

/// Quote a parcel against a supplied rate-card source.
///
/// Separating the source from [`quote`] keeps the wiring testable with an
/// in-memory fake and keeps the pricing core free of I/O.
fn quote_with<S: RateCardSource>(source: &S, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "quote",
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
    );
    let _entered = span.enter();

    let result = compute(source, parcel);

    match &result {
        Ok(quote) => tracing::info!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            total_cents = quote.total_cents,
            "quote computed",
        ),
        Err(error) => tracing::warn!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            error = %error,
            "quote failed",
        ),
    }

    result
}

/// Load, parse, and price — the pure steps threaded through the gateway.
fn compute<S: RateCardSource>(source: &S, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let text = source.load()?;
    let card = pricing::RateCard::parse(&text)?;
    card.price(parcel)
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
international\t500\t1499";

    /// In-memory fake implementing the gateway contract — no filesystem.
    struct FakeSource(Result<String, Unavailable>);

    impl RateCardSource for FakeSource {
        fn load(&self) -> Result<String, Unavailable> {
            self.0.clone()
        }
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn wires_source_through_to_a_priced_quote() {
        let source = FakeSource(Ok(SAMPLE.to_string()));
        let quote = quote_with(&source, &parcel(300, "domestic")).expect("priced");
        assert_eq!(quote.total_cents, 599);
    }

    #[test]
    fn unavailable_source_maps_to_rate_card_unavailable() {
        let source = FakeSource(Err(Unavailable));
        assert_eq!(
            quote_with(&source, &parcel(300, "domestic")),
            Err(QuoteError::RateCardUnavailable)
        );
    }

    #[test]
    fn display_is_implemented_for_each_variant() {
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "rate card is unavailable"
        );
        assert_eq!(
            QuoteError::MalformedRateCard { line: 7 }.to_string(),
            "malformed rate card at line 7"
        );
        assert_eq!(
            QuoteError::UnknownZone("lunar".into()).to_string(),
            "unknown zone: lunar"
        );
        assert_eq!(
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000
            }
            .to_string(),
            "parcel of 25000g exceeds the limit of 20000g"
        );
    }

    #[test]
    fn quote_error_is_a_std_error() {
        fn assert_error<E: std::error::Error>(_: &E) {}
        assert_error(&QuoteError::RateCardUnavailable);
    }
}
