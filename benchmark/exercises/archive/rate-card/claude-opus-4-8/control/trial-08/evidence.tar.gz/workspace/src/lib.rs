pub mod zones;

use std::env;
use std::fmt;
use std::fs;

/// A parcel to be priced against the rate card.
#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The computed price for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Everything that can go wrong producing a quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` was unset, or the file was missing or unreadable.
    RateCardUnavailable,
    /// A line did not hold three tab-separated integer fields.
    MalformedRateCard { line: usize },
    /// The parcel's zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card is unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(
                    f,
                    "parcel of {grams} g exceeds the zone limit of {limit} g"
                )
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// One band read from the rate card, scoped to a zone.
struct Band {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

/// Price a parcel against the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_rate_card()?;

    // Collect this zone's bands in ascending threshold order.
    let mut zone_bands: Vec<&Band> = bands
        .iter()
        .filter(|b| b.zone == parcel.zone)
        .collect();
    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }
    zone_bands.sort_by_key(|b| b.band_max_grams);

    let largest = zone_bands
        .last()
        .expect("zone_bands is non-empty")
        .band_max_grams;

    let band = zone_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest,
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    // Weight strictly above 10 kg adds a flat handling fee.
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    // International parcels add 20% of base, rounded half-up to the cent.
    if parcel.zone == "international" {
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    // Observability: one diagnostic record per call.
    eprintln!(
        "ratecard quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

/// Read and parse the rate card into bands.
fn load_rate_card() -> Result<Vec<Band>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    if path.is_empty() {
        return Err(QuoteError::RateCardUnavailable);
    }
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands = Vec::new();
    for (idx, raw) in contents.lines().enumerate() {
        let line_no = idx + 1;
        let trimmed = raw.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = raw.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }

        let zone = fields[0].to_string();
        let band_max_grams: u32 = fields[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents: u64 = fields[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;

        bands.push(Band {
            zone,
            band_max_grams,
            cents,
        });
    }

    Ok(bands)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    // `RATECARD_PATH` is process-global; serialize tests that touch it.
    static ENV_LOCK: Mutex<()> = Mutex::new(());

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn write_card(contents: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().expect("create temp file");
        file.write_all(contents.as_bytes()).expect("write card");
        file.flush().expect("flush card");
        file
    }

    fn quote_with(card: &str, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let _guard = ENV_LOCK.lock().unwrap();
        let file = write_card(card);
        env::set_var("RATECARD_PATH", file.path());
        let result = quote(parcel);
        env::remove_var("RATECARD_PATH");
        result
    }

    #[test]
    fn picks_first_band_at_or_above_weight() {
        let q = quote_with(
            CARD,
            &Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            },
        )
        .unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn crosses_into_higher_band() {
        let q = quote_with(
            CARD,
            &Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            },
        )
        .unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
        assert_eq!(q.total_cents, 899);
    }

    #[test]
    fn heavy_domestic_adds_flat_surcharge() {
        // 10001 g > 10000 g flat fee, still inside the 20000 band.
        let q = quote_with(
            CARD,
            &Parcel {
                weight_grams: 10_001,
                zone: "domestic".into(),
            },
        )
        .unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn exactly_10000_has_no_flat_surcharge() {
        let q = quote_with(
            CARD,
            &Parcel {
                weight_grams: 10_000,
                zone: "domestic".into(),
            },
        )
        .unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_twenty_percent_rounded_half_up() {
        // base 1499 -> 20% = 299.8 -> rounds to 300.
        let q = quote_with(
            CARD,
            &Parcel {
                weight_grams: 500,
                zone: "international".into(),
            },
        )
        .unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_stacks_flat_and_percentage() {
        // base 4999 -> 20% = 999.8 -> 1000, plus 500 flat for >10kg.
        let q = quote_with(
            CARD,
            &Parcel {
                weight_grams: 15_000,
                zone: "international".into(),
            },
        )
        .unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_carries_requested_zone() {
        let err = quote_with(
            CARD,
            &Parcel {
                weight_grams: 100,
                zone: "lunar".into(),
            },
        )
        .unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".into()));
    }

    #[test]
    fn overweight_carries_largest_band() {
        let err = quote_with(
            CARD,
            &Parcel {
                weight_grams: 20_001,
                zone: "domestic".into(),
            },
        )
        .unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            }
        );
    }

    #[test]
    fn unset_path_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap();
        env::remove_var("RATECARD_PATH");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn missing_file_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap();
        env::set_var("RATECARD_PATH", "/no/such/rate/card/here.tsv");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        env::remove_var("RATECARD_PATH");
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn wrong_field_count_is_malformed_with_line_number() {
        // Line 3 has only two fields.
        let card = "# header\ndomestic\t500\t599\ndomestic\t2000\n";
        let err = quote_with(
            card,
            &Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            },
        )
        .unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn unparsable_number_is_malformed_with_line_number() {
        let card = "domestic\t500\t599\ndomestic\theavy\t899\n";
        let err = quote_with(
            card,
            &Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            },
        )
        .unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn comments_and_blanks_count_toward_line_numbers() {
        // Blank line 2, comment line 3, malformed line 4.
        let card = "domestic\t500\t599\n\n# a comment\nbad line here\n";
        let err = quote_with(
            card,
            &Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            },
        )
        .unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn error_implements_display_and_error_trait() {
        let err: Box<dyn std::error::Error> =
            Box::new(QuoteError::UnknownZone("lunar".into()));
        assert_eq!(err.to_string(), "unknown zone: lunar");
    }
}
