pub mod zones;

use std::env;
use std::fmt;
use std::fs;

/// A parcel to be quoted: its weight and destination zone.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A shipping quote for a parcel.
#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Anything that can go wrong while producing a quote.
#[derive(Debug)]
pub enum QuoteError {
    /// The rate card path is unset, missing, or unreadable.
    RateCardUnavailable,
    /// A line in the rate card could not be parsed. Carries the 1-based line number.
    MalformedRateCard { line: usize },
    /// The requested zone is absent from the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card is unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// One band of the rate card: an upper weight threshold and its price.
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Grams above this threshold incur the heavy-parcel surcharge.
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
/// Flat surcharge added for parcels above the heavy threshold.
const HEAVY_SURCHARGE_CENTS: u64 = 500;
/// Zone that attracts the international percentage surcharge.
const INTERNATIONAL_ZONE: &str = "international";

/// Produce a quote for `parcel`, reading the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_bands_for_zone(&parcel.zone)?;

    // A zone with no bands at all is unknown.
    let largest = bands
        .iter()
        .map(|b| b.max_grams)
        .max()
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    if parcel.weight_grams > largest {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest,
        });
    }

    // The matching band is the first (ascending) whose threshold covers the weight.
    let mut sorted: Vec<&Band> = bands.iter().collect();
    sorted.sort_by_key(|b| b.max_grams);
    let band = sorted
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .expect("weight within largest band must match a band");

    let base_cents = band.cents;

    let mut surcharge_cents = 0u64;
    if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        surcharge_cents += HEAVY_SURCHARGE_CENTS;
    }
    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge_cents += international_surcharge(base_cents);
    }

    let total_cents = base_cents + surcharge_cents;

    // Observability: one diagnostic record per call.
    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

/// 20% of `base_cents`, rounded half-up to the nearest cent.
fn international_surcharge(base_cents: u64) -> u64 {
    (base_cents * 20 + 50) / 100
}

/// Emit a diagnostic record describing this quote.
fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!(
        "quote zone={zone} weight_grams={weight_grams} total_cents={total_cents}"
    );
}

/// Read the rate card and return the bands belonging to `zone`.
fn load_bands_for_zone(zone: &str) -> Result<Vec<Band>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    if path.is_empty() {
        return Err(QuoteError::RateCardUnavailable);
    }
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands = Vec::new();
    for (index, raw) in contents.lines().enumerate() {
        let line_number = index + 1;
        let line = raw.trim_end_matches(['\r']);

        if line.trim().is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let band_zone = fields[0];
        let max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        if band_zone == zone {
            bands.push(Band { max_grams, cents });
        }
    }

    Ok(bands)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;

    // RATECARD_PATH is process-global; serialize tests that touch it.
    static ENV_LOCK: Mutex<()> = Mutex::new(());

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn with_card<F: FnOnce()>(contents: &str, body: F) {
        let _guard = ENV_LOCK.lock().unwrap();
        let mut file = tempfile::NamedTempFile::new().unwrap();
        file.write_all(contents.as_bytes()).unwrap();
        file.flush().unwrap();
        env::set_var("RATECARD_PATH", file.path());
        body();
        env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn matches_first_covering_band() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn boundary_weight_uses_that_band() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);

            let q2 = quote(&Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(q2.base_cents, 899);
            assert_eq!(q2.band_max_grams, 2000);
        });
    }

    #[test]
    fn heavy_surcharge_applies_above_ten_kilos() {
        with_card(SAMPLE, || {
            // 10000 exactly: no surcharge.
            let q = quote(&Parcel {
                weight_grams: 10_000,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.base_cents, 1799);

            // 10001: heavy surcharge.
            let q2 = quote(&Parcel {
                weight_grams: 10_001,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(q2.surcharge_cents, 500);
            assert_eq!(q2.total_cents, 1799 + 500);
        });
    }

    #[test]
    fn international_surcharge_is_twenty_percent_half_up() {
        with_card(SAMPLE, || {
            // 1499 -> 20% = 299.8 -> 300 (half up).
            let q = quote(&Parcel {
                weight_grams: 200,
                zone: "international".into(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 1499);
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_and_heavy_stack() {
        with_card(SAMPLE, || {
            // 15000g international: base 4999, heavy 500, intl 20% of 4999 = 999.8 -> 1000.
            let q = quote(&Parcel {
                weight_grams: 15_000,
                zone: "international".into(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 4999);
            assert_eq!(q.surcharge_cents, 500 + 1000);
            assert_eq!(q.total_cents, 4999 + 1500);
        });
    }

    #[test]
    fn unknown_zone_carries_the_zone() {
        with_card(SAMPLE, || {
            let err = quote(&Parcel {
                weight_grams: 100,
                zone: "lunar".into(),
            })
            .unwrap_err();
            match err {
                QuoteError::UnknownZone(z) => assert_eq!(z, "lunar"),
                other => panic!("expected UnknownZone, got {other:?}"),
            }
        });
    }

    #[test]
    fn overweight_carries_largest_band() {
        with_card(SAMPLE, || {
            let err = quote(&Parcel {
                weight_grams: 25_000,
                zone: "domestic".into(),
            })
            .unwrap_err();
            match err {
                QuoteError::Overweight { grams, limit } => {
                    assert_eq!(grams, 25_000);
                    assert_eq!(limit, 20_000);
                }
                other => panic!("expected Overweight, got {other:?}"),
            }
        });
    }

    #[test]
    fn missing_path_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap();
        env::remove_var("RATECARD_PATH");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn unreadable_path_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap();
        env::set_var("RATECARD_PATH", "/no/such/ratecard/file.tsv");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        env::remove_var("RATECARD_PATH");
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn wrong_field_count_is_malformed_with_line_number() {
        // line 1 comment, line 2 blank, line 3 bad (two fields).
        let card = "# header\n\ndomestic\t500\n";
        with_card(card, || {
            let err = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            })
            .unwrap_err();
            match err {
                QuoteError::MalformedRateCard { line } => assert_eq!(line, 3),
                other => panic!("expected MalformedRateCard, got {other:?}"),
            }
        });
    }

    #[test]
    fn unparseable_number_is_malformed() {
        let card = "domestic\t500\t599\ndomestic\theavy\t899\n";
        with_card(card, || {
            let err = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            })
            .unwrap_err();
            match err {
                QuoteError::MalformedRateCard { line } => assert_eq!(line, 2),
                other => panic!("expected MalformedRateCard, got {other:?}"),
            }
        });
    }

    #[test]
    fn error_types_are_display_and_error() {
        fn assert_error<E: std::error::Error>(_: &E) {}
        let e = QuoteError::UnknownZone("x".into());
        assert_error(&e);
        assert!(!format!("{e}").is_empty());
    }
}
