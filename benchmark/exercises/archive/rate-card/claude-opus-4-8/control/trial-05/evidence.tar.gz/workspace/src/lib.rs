pub mod zones;

use std::env;
use std::fmt;
use std::fs;

/// A parcel to be priced.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The result of pricing a parcel against the rate card.
#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Everything that can go wrong while producing a quote.
#[derive(Debug)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, or the file it names is missing or unreadable.
    RateCardUnavailable,
    /// A line in the rate card is not three tab-separated fields, or its
    /// numbers do not parse. Carries the 1-based line number.
    MalformedRateCard { line: usize },
    /// The requested zone is absent from the rate card.
    UnknownZone(String),
    /// The parcel weighs more than the zone's largest band allows.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {}", zone)
            }
            QuoteError::Overweight { grams, limit } => {
                write!(
                    f,
                    "parcel of {} grams exceeds zone limit of {} grams",
                    grams, limit
                )
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// One priced band from the rate card.
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Reads the rate card named by `RATECARD_PATH` and prices `parcel`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_bands(&parcel.zone)?;

    if bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    // Bands apply in ascending threshold; the match is the first whose
    // threshold is >= the parcel weight.
    let limit = bands
        .iter()
        .map(|b| b.max_grams)
        .max()
        .expect("bands is non-empty");

    let band = bands.iter().find(|b| b.max_grams >= parcel.weight_grams);

    let band = match band {
        Some(band) => band,
        None => {
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            })
        }
    };

    let base_cents = band.cents;

    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        // 20% of base, rounded half-up to the cent.
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    // Observability: one diagnostic record per call.
    eprintln!(
        "ratecard quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

/// Reads and parses the rate card, returning only the bands for `zone` in the
/// order they appear (ascending threshold, per the card's contract).
fn load_bands(zone: &str) -> Result<Vec<Band>, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands: Vec<Band> = Vec::new();

    for (index, raw) in contents.lines().enumerate() {
        let line_number = index + 1;

        let trimmed = raw.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = raw.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let card_zone = fields[0];
        let max_grams: u32 = fields[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        if card_zone == zone {
            bands.push(Band { max_grams, cents });
        }
    }

    // Ensure ascending application regardless of card ordering.
    bands.sort_by_key(|b| b.max_grams);

    Ok(bands)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::{Mutex, MutexGuard};
    use tempfile::NamedTempFile;

    // RATECARD_PATH is process-global, so serialize tests that touch it.
    static ENV_LOCK: Mutex<()> = Mutex::new(());

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    struct Fixture {
        _guard: MutexGuard<'static, ()>,
        _file: NamedTempFile,
    }

    fn with_card(card: &str) -> Fixture {
        let guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(card.as_bytes()).unwrap();
        file.flush().unwrap();
        env::set_var("RATECARD_PATH", file.path());
        Fixture {
            _guard: guard,
            _file: file,
        }
    }

    fn parcel(weight: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams: weight,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn picks_first_band_at_or_above_weight() {
        let _fx = with_card(CARD);
        let q = quote(&parcel(300, "domestic")).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
    }

    #[test]
    fn boundary_is_inclusive() {
        let _fx = with_card(CARD);
        let q = quote(&parcel(500, "domestic")).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn crosses_into_next_band() {
        let _fx = with_card(CARD);
        let q = quote(&parcel(501, "domestic")).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn heavy_domestic_adds_flat_surcharge() {
        let _fx = with_card(CARD);
        // 10001 > 10000, within the 20000 band.
        let q = quote(&parcel(10_001, "domestic")).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn exactly_10000_has_no_flat_surcharge() {
        let _fx = with_card(CARD);
        let q = quote(&parcel(10_000, "domestic")).unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_20_percent_rounded_half_up() {
        let _fx = with_card(CARD);
        // base 1499, 20% = 299.8 -> 300.
        let q = quote(&parcel(400, "international")).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_heavy_stacks_both_surcharges() {
        let _fx = with_card(CARD);
        // base 4999, 20% = 999.8 -> 1000, plus 500 flat.
        let q = quote(&parcel(15_000, "international")).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_carries_requested_zone() {
        let _fx = with_card(CARD);
        match quote(&parcel(100, "lunar")) {
            Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "lunar"),
            other => panic!("expected UnknownZone, got {:?}", other),
        }
    }

    #[test]
    fn overweight_carries_largest_band_limit() {
        let _fx = with_card(CARD);
        match quote(&parcel(25_000, "domestic")) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 25_000);
                assert_eq!(limit, 20_000);
            }
            other => panic!("expected Overweight, got {:?}", other),
        }
    }

    #[test]
    fn unset_path_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        env::remove_var("RATECARD_PATH");
        match quote(&parcel(100, "domestic")) {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected RateCardUnavailable, got {:?}", other),
        }
    }

    #[test]
    fn missing_file_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        env::set_var("RATECARD_PATH", "/nonexistent/path/to/ratecard.tsv");
        match quote(&parcel(100, "domestic")) {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected RateCardUnavailable, got {:?}", other),
        }
    }

    #[test]
    fn wrong_field_count_is_malformed_with_line_number() {
        let card = "# header\ndomestic\t500\t599\ndomestic\t2000\n";
        let _fx = with_card(card);
        match quote(&parcel(100, "domestic")) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
            other => panic!("expected MalformedRateCard, got {:?}", other),
        }
    }

    #[test]
    fn unparseable_number_is_malformed_with_line_number() {
        let card = "domestic\t500\t599\ndomestic\ttwo-thousand\t899\n";
        let _fx = with_card(card);
        match quote(&parcel(100, "domestic")) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 2),
            other => panic!("expected MalformedRateCard, got {:?}", other),
        }
    }

    #[test]
    fn malformed_counts_blanks_and_comments() {
        // Line 1 comment, line 2 blank, line 3 good, line 4 malformed.
        let card = "# comment\n\ndomestic\t500\t599\ngarbage\n";
        let _fx = with_card(card);
        match quote(&parcel(100, "domestic")) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 4),
            other => panic!("expected MalformedRateCard, got {:?}", other),
        }
    }

    #[test]
    fn error_implements_display_and_std_error() {
        fn assert_error<E: std::error::Error>(_: &E) {}
        let e = QuoteError::UnknownZone("lunar".to_string());
        assert_error(&e);
        assert!(!e.to_string().is_empty());
    }
}
