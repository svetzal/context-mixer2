pub mod zones;

use std::collections::BTreeMap;
use std::fmt;

/// A parcel to be priced: its weight and the shipping zone it belongs to.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A priced quote for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Everything that can go wrong while producing a quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` was unset, or the file was missing or unreadable.
    RateCardUnavailable,
    /// A rate-card line was not three tab-separated numeric fields.
    MalformedRateCard { line: usize },
    /// The parcel's zone is absent from the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(
                    f,
                    "overweight: {grams} grams exceeds limit of {limit} grams"
                )
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// One priced band within a zone: everything up to `band_max_grams` costs `cents`.
struct Band {
    band_max_grams: u32,
    cents: u64,
}

/// The parsed rate card: zones mapped to their bands, sorted ascending by threshold.
struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

impl RateCard {
    /// Parse the tab-separated rate card. Empty lines and lines beginning with
    /// `#` are ignored. Every other line must be three tab-separated fields:
    /// `zone`, `band_max_grams`, `cents`. Line numbers are 1-based and count
    /// every line in the file, including comments and blanks.
    fn parse(contents: &str) -> Result<RateCard, QuoteError> {
        let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

        for (index, raw_line) in contents.lines().enumerate() {
            let line_number = index + 1;
            let line = raw_line.trim_end_matches(['\r', '\n']);

            if line.is_empty() || line.starts_with('#') {
                continue;
            }

            let fields: Vec<&str> = line.split('\t').collect();
            if fields.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: line_number });
            }

            let zone = fields[0];
            let band_max_grams = fields[1]
                .parse::<u32>()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
            let cents = fields[2]
                .parse::<u64>()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

            zones.entry(zone.to_string()).or_default().push(Band {
                band_max_grams,
                cents,
            });
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.band_max_grams);
        }

        Ok(RateCard { zones })
    }
}

/// Emit a diagnostic record for one quote call, so each pricing is observable in
/// operation. Carries the zone, the weight in grams, and the resulting total.
fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!(
        "ratecard.quote zone={zone} weight_grams={weight_grams} total_cents={total_cents}"
    );
}

/// Price a parcel against the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = std::fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let card = RateCard::parse(&contents)?;

    let bands = card
        .zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    // Bands are sorted ascending; the matching band is the first whose threshold
    // is at least the parcel weight.
    let band = bands
        .iter()
        .find(|band| band.band_max_grams >= parcel.weight_grams);

    let band = match band {
        Some(band) => band,
        None => {
            // The largest band is the last one after the ascending sort.
            let limit = bands
                .last()
                .map(|band| band.band_max_grams)
                .unwrap_or(0);
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    // Heavy-parcel surcharge: strictly above 10 kg.
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    // International surcharge: 20% of base, rounded half-up to the cent.
    if parcel.zone == "international" {
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::{Mutex, MutexGuard};
    use tempfile::NamedTempFile;

    // `RATECARD_PATH` is process-global; serialise the tests that touch it.
    static ENV_LOCK: Mutex<()> = Mutex::new(());

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
        domestic\t500\t599\n\
        domestic\t2000\t899\n\
        domestic\t20000\t1799\n\
        international\t500\t1499\n\
        international\t20000\t4999\n";

    struct EnvGuard<'a> {
        _lock: MutexGuard<'a, ()>,
        _file: NamedTempFile,
    }

    fn with_card(contents: &str) -> EnvGuard<'static> {
        let lock = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(contents.as_bytes()).unwrap();
        file.flush().unwrap();
        std::env::set_var("RATECARD_PATH", file.path());
        EnvGuard {
            _lock: lock,
            _file: file,
        }
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn picks_first_band_at_or_above_weight() {
        let _g = with_card(SAMPLE);
        let q = quote(&parcel(500, "domestic")).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
    }

    #[test]
    fn boundary_is_inclusive() {
        let _g = with_card(SAMPLE);
        // Exactly 500 grams stays in the 500 band, 501 moves to the next.
        assert_eq!(quote(&parcel(500, "domestic")).unwrap().band_max_grams, 500);
        assert_eq!(quote(&parcel(501, "domestic")).unwrap().band_max_grams, 2000);
    }

    #[test]
    fn middle_band_selected() {
        let _g = with_card(SAMPLE);
        let q = quote(&parcel(1500, "domestic")).unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
        assert_eq!(q.total_cents, 899);
    }

    #[test]
    fn heavy_surcharge_added_above_ten_kilos() {
        let _g = with_card(SAMPLE);
        // 15 kg domestic: base 1799, +500 heavy surcharge.
        let q = quote(&parcel(15_000, "domestic")).unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn heavy_surcharge_is_strictly_above_ten_kilos() {
        let _g = with_card(SAMPLE);
        // Exactly 10 kg: no heavy surcharge.
        let q = quote(&parcel(10_000, "domestic")).unwrap();
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_surcharge_is_twenty_percent_half_up() {
        let _g = with_card(SAMPLE);
        // 300 g international: base 1499, 20% = 299.8 -> 300 (half-up).
        let q = quote(&parcel(300, "international")).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn international_and_heavy_surcharges_stack() {
        let _g = with_card(SAMPLE);
        // 15 kg international: base 4999, 20% = 999.8 -> 1000, plus 500 heavy.
        let q = quote(&parcel(15_000, "international")).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
        assert_eq!(q.band_max_grams, 20000);
    }

    #[test]
    fn unknown_zone_carries_requested_zone() {
        let _g = with_card(SAMPLE);
        match quote(&parcel(100, "lunar")) {
            Err(QuoteError::UnknownZone(zone)) => assert_eq!(zone, "lunar"),
            other => panic!("expected UnknownZone, got {other:?}"),
        }
    }

    #[test]
    fn overweight_carries_largest_band_limit() {
        let _g = with_card(SAMPLE);
        match quote(&parcel(25_000, "domestic")) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 25_000);
                assert_eq!(limit, 20_000);
            }
            other => panic!("expected Overweight, got {other:?}"),
        }
    }

    #[test]
    fn unset_path_is_unavailable() {
        let _lock = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        std::env::remove_var("RATECARD_PATH");
        assert_eq!(
            quote(&parcel(100, "domestic")),
            Err(QuoteError::RateCardUnavailable)
        );
    }

    #[test]
    fn missing_file_is_unavailable() {
        let _lock = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        std::env::set_var("RATECARD_PATH", "/no/such/rate/card/at/all.tsv");
        assert_eq!(
            quote(&parcel(100, "domestic")),
            Err(QuoteError::RateCardUnavailable)
        );
    }

    #[test]
    fn wrong_field_count_is_malformed_with_line_number() {
        // Line 2 has only two fields.
        let card = "# header\ndomestic\t500\ndomestic\t2000\t899\n";
        let _g = with_card(card);
        assert_eq!(
            quote(&parcel(100, "domestic")),
            Err(QuoteError::MalformedRateCard { line: 2 })
        );
    }

    #[test]
    fn unparseable_number_is_malformed_with_line_number() {
        // Line 3 has a non-numeric cents field. Blank line 2 still counts.
        let card = "domestic\t500\t599\n\ndomestic\t2000\tcheap\n";
        let _g = with_card(card);
        assert_eq!(
            quote(&parcel(100, "domestic")),
            Err(QuoteError::MalformedRateCard { line: 3 })
        );
    }

    #[test]
    fn comments_and_blanks_do_not_break_parsing() {
        let card = "\n# a comment\n\ndomestic\t500\t599\n# trailing\n";
        let _g = with_card(card);
        let q = quote(&parcel(400, "domestic")).unwrap();
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn error_types_implement_display_and_error() {
        fn assert_error<E: std::error::Error>(_: &E) {}
        let e = QuoteError::UnknownZone("mars".to_string());
        assert_error(&e);
        assert!(!e.to_string().is_empty());
    }
}
