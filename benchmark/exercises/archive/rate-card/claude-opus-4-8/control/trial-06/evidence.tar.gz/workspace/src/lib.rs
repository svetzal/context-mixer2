pub mod zones;

use std::fmt;

/// A parcel to be quoted: its weight in grams and the destination zone.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The computed price for a parcel, in integer cents.
#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Everything that can go wrong producing a quote.
#[derive(Debug)]
pub enum QuoteError {
    /// `RATECARD_PATH` was unset, or the file could not be read.
    RateCardUnavailable,
    /// A line was not three tab-separated fields, or a number failed to parse.
    /// Carries the 1-based line number of the offending line.
    MalformedRateCard { line: usize },
    /// The requested zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel of {grams}g exceeds the zone limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// One band of the rate card for a single zone.
struct Band {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

/// Read and parse the rate card named by `RATECARD_PATH`.
fn load_rate_card() -> Result<Vec<Band>, QuoteError> {
    let path = std::env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = std::fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands = Vec::new();
    for (index, raw) in contents.lines().enumerate() {
        let line_no = index + 1;
        let line = raw.trim_end_matches(['\r', '\n']);

        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }

        let band_max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;

        bands.push(Band {
            zone: fields[0].to_string(),
            band_max_grams,
            cents,
        });
    }

    Ok(bands)
}

/// 20% of `base_cents`, rounded half-up to the nearest cent.
fn international_surcharge(base_cents: u64) -> u64 {
    (base_cents * 20 + 50) / 100
}

/// Produce a quote for `parcel`, reading the rate card from `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_rate_card()?;

    // Bands for the requested zone, ascending by threshold.
    let mut zone_bands: Vec<&Band> =
        bands.iter().filter(|b| b.zone == parcel.zone).collect();
    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }
    zone_bands.sort_by_key(|b| b.band_max_grams);

    let limit = zone_bands
        .iter()
        .map(|b| b.band_max_grams)
        .max()
        .expect("zone_bands is non-empty");

    let matched = zone_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let base_cents = matched.cents;
    let band_max_grams = matched.band_max_grams;

    let mut surcharge_cents = 0u64;
    if parcel.weight_grams > 10000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += international_surcharge(base_cents);
    }

    let total_cents = base_cents + surcharge_cents;

    // Observability: one diagnostic record per call.
    eprintln!(
        "ratecard quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    /// Write `contents` to a temp file, point RATECARD_PATH at it, run `f`.
    /// The env var is process-global, so these tests share one guard.
    fn with_card<R>(contents: &str, f: impl FnOnce() -> R) -> R {
        use std::sync::Mutex;
        static LOCK: Mutex<()> = Mutex::new(());
        let _guard = LOCK.lock().unwrap();

        let mut file = NamedTempFile::new().unwrap();
        file.write_all(contents.as_bytes()).unwrap();
        file.flush().unwrap();
        std::env::set_var("RATECARD_PATH", file.path());
        let result = f();
        std::env::remove_var("RATECARD_PATH");
        result
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn matches_first_band_at_or_above_weight() {
        with_card(CARD, || {
            let q = quote(&parcel(500, "domestic")).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
        });
    }

    #[test]
    fn weight_just_over_a_threshold_climbs_to_the_next_band() {
        with_card(CARD, || {
            let q = quote(&parcel(501, "domestic")).unwrap();
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
        });
    }

    #[test]
    fn heavy_domestic_parcel_gets_the_overweight_surcharge() {
        with_card(CARD, || {
            let q = quote(&parcel(15000, "domestic")).unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.band_max_grams, 20000);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
        });
    }

    #[test]
    fn exactly_ten_thousand_grams_has_no_weight_surcharge() {
        with_card(CARD, || {
            let q = quote(&parcel(10000, "domestic")).unwrap();
            assert_eq!(q.surcharge_cents, 0);
        });
    }

    #[test]
    fn international_adds_twenty_percent_rounded_half_up() {
        with_card(CARD, || {
            // 20% of 1499 = 299.8 -> 300
            let q = quote(&parcel(400, "international")).unwrap();
            assert_eq!(q.base_cents, 1499);
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_heavy_stacks_both_surcharges() {
        with_card(CARD, || {
            // base 4999, weight surcharge 500, 20% of 4999 = 999.8 -> 1000
            let q = quote(&parcel(15000, "international")).unwrap();
            assert_eq!(q.base_cents, 4999);
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
        });
    }

    #[test]
    fn unknown_zone_carries_the_requested_zone() {
        with_card(CARD, || {
            match quote(&parcel(100, "lunar")) {
                Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "lunar"),
                other => panic!("expected UnknownZone, got {other:?}"),
            }
        });
    }

    #[test]
    fn overweight_carries_grams_and_the_largest_band() {
        with_card(CARD, || {
            match quote(&parcel(25000, "domestic")) {
                Err(QuoteError::Overweight { grams, limit }) => {
                    assert_eq!(grams, 25000);
                    assert_eq!(limit, 20000);
                }
                other => panic!("expected Overweight, got {other:?}"),
            }
        });
    }

    #[test]
    fn unset_path_is_rate_card_unavailable() {
        use std::sync::Mutex;
        static LOCK: Mutex<()> = Mutex::new(());
        let _guard = LOCK.lock().unwrap();
        std::env::remove_var("RATECARD_PATH");
        match quote(&parcel(100, "domestic")) {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected RateCardUnavailable, got {other:?}"),
        }
    }

    #[test]
    fn missing_file_is_rate_card_unavailable() {
        use std::sync::Mutex;
        static LOCK: Mutex<()> = Mutex::new(());
        let _guard = LOCK.lock().unwrap();
        std::env::set_var("RATECARD_PATH", "/no/such/ratecard/file.tsv");
        let result = quote(&parcel(100, "domestic"));
        std::env::remove_var("RATECARD_PATH");
        match result {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected RateCardUnavailable, got {other:?}"),
        }
    }

    #[test]
    fn wrong_field_count_reports_the_line_number() {
        // line 1 comment, line 2 blank, line 3 has two fields
        let card = "# header\n\ndomestic\t500\n";
        with_card(card, || match quote(&parcel(100, "domestic")) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
            other => panic!("expected MalformedRateCard, got {other:?}"),
        });
    }

    #[test]
    fn unparseable_number_reports_the_line_number() {
        let card = "domestic\t500\t599\ndomestic\theavy\t899\n";
        with_card(card, || match quote(&parcel(100, "domestic")) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 2),
            other => panic!("expected MalformedRateCard, got {other:?}"),
        });
    }

    #[test]
    fn comments_and_blanks_do_not_count_against_parsing() {
        // Leading comments/blanks are skipped but still counted for line numbers.
        with_card(CARD, || {
            let q = quote(&parcel(500, "domestic")).unwrap();
            assert_eq!(q.base_cents, 599);
        });
    }
}
