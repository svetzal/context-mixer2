pub mod zones;

use std::collections::BTreeMap;
use std::fmt;

/// A parcel to be quoted.
#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A calculated shipping quote.
#[derive(Debug, Clone)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Reasons a quote may fail.
#[derive(Debug)]
pub enum QuoteError {
    /// `RATECARD_PATH` was unset, or the file was missing or unreadable.
    RateCardUnavailable,
    /// A rate-card line could not be parsed; carries the 1-based line number.
    MalformedRateCard { line: usize },
    /// The requested zone was not present in the rate card.
    UnknownZone(String),
    /// The weight exceeded the zone's largest band; carries that limit.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// A single band within a zone: parcels up to `max_grams` cost `cents`.
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculate a shipping quote for `parcel` against the rate card named by the
/// `RATECARD_PATH` environment variable.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = load_rate_card()?;

    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    // Bands are stored ascending by threshold. The matching band is the first
    // whose threshold is >= the parcel weight.
    let band = bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams);

    let band = match band {
        Some(b) => b,
        None => {
            // Above the zone's largest band.
            let limit = bands
                .last()
                .map(|b| b.max_grams)
                .unwrap_or(0);
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let band_max_grams = band.max_grams;

    let mut surcharge_cents: u64 = 0;

    // Weight strictly above 10000 grams adds a flat surcharge.
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    // International zone adds 20% of base, rounded half-up to the cent.
    if parcel.zone == "international" {
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    // Observability: one diagnostic record per call.
    eprintln!(
        "ratecard quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

/// Read and parse the rate card into a map of zone -> ascending bands.
fn load_rate_card() -> Result<BTreeMap<String, Vec<Band>>, QuoteError> {
    let path = std::env::var_os("RATECARD_PATH")
        .ok_or(QuoteError::RateCardUnavailable)?;

    let contents = std::fs::read_to_string(&path)
        .map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut card: BTreeMap<String, Vec<Band>> = BTreeMap::new();

    for (index, raw) in contents.lines().enumerate() {
        let line_no = index + 1;
        let trimmed = raw.trim();

        // Skip blank lines and comments.
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = raw.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }

        let zone = fields[0];
        let max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;

        card.entry(zone.to_string())
            .or_default()
            .push(Band { max_grams, cents });
    }

    // Ensure bands apply in ascending threshold order.
    for bands in card.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(card)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::{Mutex, OnceLock};

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    // Tests mutate the process-wide RATECARD_PATH env var, so they must not run
    // concurrently against it.
    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    /// Run `f` with `RATECARD_PATH` pointed at a file holding `card`.
    fn with_card<T>(card: &str, f: impl FnOnce() -> T) -> T {
        let _guard = env_lock().lock().unwrap();
        let mut file = tempfile::NamedTempFile::new().unwrap();
        file.write_all(card.as_bytes()).unwrap();
        file.flush().unwrap();
        std::env::set_var("RATECARD_PATH", file.path());
        let result = f();
        std::env::remove_var("RATECARD_PATH");
        result
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn domestic_first_band() {
        with_card(SAMPLE, || {
            let q = quote(&parcel(300, "domestic")).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn matches_band_at_exact_threshold() {
        with_card(SAMPLE, || {
            let q = quote(&parcel(500, "domestic")).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_middle_band() {
        with_card(SAMPLE, || {
            let q = quote(&parcel(1500, "domestic")).unwrap();
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
            assert_eq!(q.surcharge_cents, 0);
        });
    }

    #[test]
    fn heavy_domestic_adds_flat_surcharge() {
        with_card(SAMPLE, || {
            // 15000g is above 10000 -> +500, within the 20000 band.
            let q = quote(&parcel(15000, "domestic")).unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
            assert_eq!(q.band_max_grams, 20000);
        });
    }

    #[test]
    fn ten_thousand_grams_is_not_overweight_surcharged() {
        with_card(SAMPLE, || {
            // Strictly above 10000 -> exactly 10000 gets no flat surcharge.
            let q = quote(&parcel(10000, "domestic")).unwrap();
            assert_eq!(q.surcharge_cents, 0);
        });
    }

    #[test]
    fn international_percentage_surcharge_rounds_half_up() {
        with_card(SAMPLE, || {
            // base 1499, 20% = 299.8 -> 300.
            let q = quote(&parcel(400, "international")).unwrap();
            assert_eq!(q.base_cents, 1499);
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn international_heavy_stacks_surcharges() {
        with_card(SAMPLE, || {
            // base 4999, 20% = 999.8 -> 1000, plus 500 flat for >10000g.
            let q = quote(&parcel(15000, "international")).unwrap();
            assert_eq!(q.base_cents, 4999);
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
            assert_eq!(q.band_max_grams, 20000);
        });
    }

    #[test]
    fn unknown_zone() {
        with_card(SAMPLE, || {
            match quote(&parcel(100, "lunar")) {
                Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "lunar"),
                other => panic!("expected UnknownZone, got {other:?}"),
            }
        });
    }

    #[test]
    fn overweight_reports_largest_band() {
        with_card(SAMPLE, || {
            match quote(&parcel(25000, "domestic")) {
                Err(QuoteError::Overweight { grams, limit }) => {
                    assert_eq!(grams, 25000);
                    assert_eq!(limit, 20000);
                }
                other => panic!("expected Overweight, got {other:?}"),
            }
        });
    }

    #[test]
    fn unset_path_is_unavailable() {
        let _guard = env_lock().lock().unwrap();
        std::env::remove_var("RATECARD_PATH");
        match quote(&parcel(100, "domestic")) {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected RateCardUnavailable, got {other:?}"),
        }
    }

    #[test]
    fn missing_file_is_unavailable() {
        let _guard = env_lock().lock().unwrap();
        std::env::set_var("RATECARD_PATH", "/no/such/rate/card/file.tsv");
        let result = quote(&parcel(100, "domestic"));
        std::env::remove_var("RATECARD_PATH");
        match result {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected RateCardUnavailable, got {other:?}"),
        }
    }

    #[test]
    fn malformed_wrong_field_count_reports_line() {
        // Line 2 has only two fields.
        let card = "# header\ndomestic\t500\ninternational\t500\t1499\n";
        with_card(card, || match quote(&parcel(100, "domestic")) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 2),
            other => panic!("expected MalformedRateCard, got {other:?}"),
        });
    }

    #[test]
    fn malformed_bad_number_reports_line_counting_blanks_and_comments() {
        // Line numbers: 1 comment, 2 blank, 3 good, 4 bad number.
        let card = "# comment\n\ndomestic\t500\t599\ndomestic\tlots\t899\n";
        with_card(card, || match quote(&parcel(100, "domestic")) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 4),
            other => panic!("expected MalformedRateCard, got {other:?}"),
        });
    }

    #[test]
    fn display_and_error_trait() {
        let e: Box<dyn std::error::Error> =
            Box::new(QuoteError::UnknownZone("mars".to_string()));
        assert!(e.to_string().contains("mars"));
    }
}
