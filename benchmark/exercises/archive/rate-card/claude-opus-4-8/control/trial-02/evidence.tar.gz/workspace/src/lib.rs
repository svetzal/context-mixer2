pub mod zones;

use std::collections::HashMap;
use std::env;
use std::fmt;
use std::fs;

/// A parcel awaiting a shipping quote.
#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A computed shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Everything that can go wrong while producing a quote.
#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, or the file it names is missing/unreadable.
    RateCardUnavailable,
    /// A rate-card line is not three tab-separated fields, or its numbers do
    /// not parse. Carries the 1-based line number of the offending line.
    MalformedRateCard { line: usize },
    /// The requested zone is absent from the rate card.
    UnknownZone(String),
    /// The parcel weighs more than the zone's largest band allows.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(
                    f,
                    "parcel of {grams} g exceeds the zone limit of {limit} g"
                )
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// One priced band within a zone: parcels up to `band_max_grams` cost `cents`.
struct Band {
    band_max_grams: u32,
    cents: u64,
}

/// Compute a shipping quote for `parcel` against the rate card named by the
/// `RATECARD_PATH` environment variable.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_zone_bands(&parcel.zone)?;

    let band = bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            // `bands` is non-empty and sorted ascending, so the last band
            // carries the zone's largest threshold.
            limit: bands.last().map(|b| b.band_max_grams).unwrap_or(0),
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        // 20% of base, rounded half-up to the cent.
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

/// Read the rate card and return the ascending-by-threshold bands for `zone`,
/// or the appropriate error.
fn load_zone_bands(zone: &str) -> Result<Vec<Band>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut by_zone: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, raw_line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let line = raw_line.trim_end_matches(['\r', '\n']);

        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone_name = fields[0];
        let band_max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        by_zone.entry(zone_name.to_string()).or_default().push(Band {
            band_max_grams,
            cents,
        });
    }

    let mut bands = by_zone
        .remove(zone)
        .ok_or_else(|| QuoteError::UnknownZone(zone.to_string()))?;

    bands.sort_by_key(|b| b.band_max_grams);
    Ok(bands)
}

/// Emit a per-call diagnostic record so each quote is observable in operation.
fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!(
        "ratecard quote zone={zone} weight_grams={weight_grams} total_cents={total_cents}"
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    // `quote` reads a process-global environment variable, so tests that set it
    // must not run concurrently.
    static ENV_LOCK: Mutex<()> = Mutex::new(());

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
        domestic\t500\t599\n\
        domestic\t2000\t899\n\
        domestic\t20000\t1799\n\
        international\t500\t1499\n\
        international\t20000\t4999\n";

    /// Run `body` with `RATECARD_PATH` pointing at a file holding `card`.
    fn with_card<T>(card: &str, body: impl FnOnce() -> T) -> T {
        let _guard = ENV_LOCK.lock().unwrap();
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(card.as_bytes()).unwrap();
        env::set_var("RATECARD_PATH", file.path());
        let result = body();
        env::remove_var("RATECARD_PATH");
        result
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn picks_first_band_at_or_above_weight() {
        with_card(SAMPLE, || {
            let q = quote(&parcel(500, "domestic")).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
        });
    }

    #[test]
    fn weight_just_over_a_band_falls_into_the_next() {
        with_card(SAMPLE, || {
            let q = quote(&parcel(501, "domestic")).unwrap();
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
        });
    }

    #[test]
    fn heavy_domestic_parcel_gets_the_over_10kg_surcharge() {
        with_card(SAMPLE, || {
            let q = quote(&parcel(10_001, "domestic")).unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
            assert_eq!(q.band_max_grams, 20000);
        });
    }

    #[test]
    fn exactly_10kg_has_no_heavy_surcharge() {
        with_card(SAMPLE, || {
            let q = quote(&parcel(10_000, "domestic")).unwrap();
            assert_eq!(q.surcharge_cents, 0);
        });
    }

    #[test]
    fn international_adds_20_percent_rounded_half_up() {
        with_card(SAMPLE, || {
            // base 1499 -> 20% = 299.8 -> rounds half-up to 300.
            let q = quote(&parcel(500, "international")).unwrap();
            assert_eq!(q.base_cents, 1499);
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_heavy_stacks_both_surcharges() {
        with_card(SAMPLE, || {
            // base 4999 -> 20% = 999.8 -> 1000, plus 500 for >10kg.
            let q = quote(&parcel(15_000, "international")).unwrap();
            assert_eq!(q.base_cents, 4999);
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
        });
    }

    #[test]
    fn unknown_zone_carries_the_requested_zone() {
        with_card(SAMPLE, || {
            let err = quote(&parcel(100, "lunar")).unwrap_err();
            assert_eq!(err, QuoteError::UnknownZone("lunar".to_string()));
        });
    }

    #[test]
    fn overweight_reports_the_largest_band_as_limit() {
        with_card(SAMPLE, || {
            let err = quote(&parcel(20_001, "domestic")).unwrap_err();
            assert_eq!(
                err,
                QuoteError::Overweight {
                    grams: 20_001,
                    limit: 20_000
                }
            );
        });
    }

    #[test]
    fn unset_path_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap();
        env::remove_var("RATECARD_PATH");
        let err = quote(&parcel(100, "domestic")).unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn missing_file_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap();
        env::set_var("RATECARD_PATH", "/no/such/rate/card/file.tsv");
        let err = quote(&parcel(100, "domestic")).unwrap_err();
        env::remove_var("RATECARD_PATH");
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn wrong_field_count_is_malformed_with_line_number() {
        // Line 1 is a comment, line 2 is blank, the bad row is line 3.
        let card = "# header\n\ndomestic\t500\n";
        with_card(card, || {
            let err = quote(&parcel(100, "domestic")).unwrap_err();
            assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
        });
    }

    #[test]
    fn unparseable_number_is_malformed_with_line_number() {
        let card = "domestic\t500\t599\ndomestic\theavy\t899\n";
        with_card(card, || {
            let err = quote(&parcel(100, "domestic")).unwrap_err();
            assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
        });
    }

    #[test]
    fn comments_and_blanks_do_not_shift_line_numbers() {
        let card = "domestic\t500\t599\n\n# a comment\ndomestic\t2000\tnope\n";
        with_card(card, || {
            let err = quote(&parcel(100, "domestic")).unwrap_err();
            assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
        });
    }

    #[test]
    fn error_type_implements_display_and_error() {
        fn assert_error<E: std::error::Error>(_: &E) {}
        let err = QuoteError::UnknownZone("mars".to_string());
        assert_error(&err);
        assert_eq!(err.to_string(), "unknown zone: mars");
    }
}
