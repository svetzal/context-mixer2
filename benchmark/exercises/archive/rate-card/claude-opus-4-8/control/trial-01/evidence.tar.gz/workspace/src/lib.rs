pub mod zones;

use std::env;
use std::fmt;
use std::fs;

/// A parcel to be quoted.
#[derive(Debug)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The computed shipping quote for a parcel.
#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Everything that can go wrong producing a quote.
#[derive(Debug)]
pub enum QuoteError {
    /// `RATECARD_PATH` was unset, or the file could not be read.
    RateCardUnavailable,
    /// A line did not have three fields, or a number failed to parse.
    /// `line` is the 1-based line number in the file.
    MalformedRateCard { line: usize },
    /// The requested zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel weighs more than the zone's largest band allows.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(
                    f,
                    "parcel of {grams} grams exceeds the zone limit of {limit} grams"
                )
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// One priced band of the rate card.
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Compute a quote for `parcel` against the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_zone_bands(&parcel.zone)?;

    if bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    // Bands ascend by max_grams; the match is the first that fits.
    let limit = bands.iter().map(|b| b.max_grams).max().unwrap();
    let band = bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents = 0u64;

    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }

    if parcel.zone == "international" {
        // 20% of base, rounded half-up to the cent.
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

/// Read the rate card and return only the bands for `zone`, in file order.
fn load_zone_bands(zone: &str) -> Result<Vec<Band>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands = Vec::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;

        let trimmed = line.trim_end_matches(['\r', '\n']);
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = trimmed.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let band_zone = fields[0];
        let max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        if band_zone == zone {
            bands.push(Band { max_grams, cents });
        }
    }

    // Apply bands in ascending band_max_grams regardless of file order.
    bands.sort_by_key(|b| b.max_grams);

    Ok(bands)
}

/// Emit an observable record for this quote: zone, weight, and total.
fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!(
        "ratecard quote zone={zone} weight_grams={weight_grams} total_cents={total_cents}"
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::{Mutex, MutexGuard, OnceLock};
    use tempfile::NamedTempFile;

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    // `RATECARD_PATH` is process-global; serialise the tests that touch it.
    fn env_lock() -> MutexGuard<'static, ()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(())).lock().unwrap()
    }

    fn with_card(card: &str, f: impl FnOnce()) {
        let _guard = env_lock();
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(card.as_bytes()).unwrap();
        env::set_var("RATECARD_PATH", file.path());
        f();
        env::remove_var("RATECARD_PATH");
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn matches_first_band_at_or_above_weight() {
        with_card(CARD, || {
            let q = quote(&parcel(300, "domestic")).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
        });
    }

    #[test]
    fn weight_exactly_on_threshold_uses_that_band() {
        with_card(CARD, || {
            let q = quote(&parcel(500, "domestic")).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn middle_band_selected() {
        with_card(CARD, || {
            let q = quote(&parcel(1500, "domestic")).unwrap();
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
        });
    }

    #[test]
    fn heavy_domestic_adds_weight_surcharge() {
        with_card(CARD, || {
            // 15000g > 10000g -> +500; domestic -> no zone surcharge.
            let q = quote(&parcel(15000, "domestic")).unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
            assert_eq!(q.band_max_grams, 20000);
        });
    }

    #[test]
    fn international_adds_twenty_percent_half_up() {
        with_card(CARD, || {
            // 20% of 1499 = 299.8 -> 300.
            let q = quote(&parcel(300, "international")).unwrap();
            assert_eq!(q.base_cents, 1499);
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn international_heavy_stacks_both_surcharges() {
        with_card(CARD, || {
            // base 4999; 20% = 999.8 -> 1000; +500 for weight -> 1500.
            let q = quote(&parcel(15000, "international")).unwrap();
            assert_eq!(q.base_cents, 4999);
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
            assert_eq!(q.band_max_grams, 20000);
        });
    }

    #[test]
    fn just_above_ten_kilos_gets_surcharge() {
        with_card(CARD, || {
            let q = quote(&parcel(10001, "domestic")).unwrap();
            assert_eq!(q.surcharge_cents, 500);
        });
        with_card(CARD, || {
            let q = quote(&parcel(10000, "domestic")).unwrap();
            assert_eq!(q.surcharge_cents, 0);
        });
    }

    #[test]
    fn unknown_zone_carries_the_request() {
        with_card(CARD, || {
            match quote(&parcel(300, "lunar")) {
                Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "lunar"),
                other => panic!("expected UnknownZone, got {other:?}"),
            }
        });
    }

    #[test]
    fn overweight_reports_largest_band() {
        with_card(CARD, || {
            match quote(&parcel(25000, "domestic")) {
                Err(QuoteError::Overweight { grams, limit }) => {
                    assert_eq!(grams, 25000);
                    assert_eq!(limit, 20000);
                }
                other => panic!("expected Overweight, got {other:?}"),
            }
        });
    }

    #[test]
    fn unset_path_is_unavailable() {
        let _guard = env_lock();
        env::remove_var("RATECARD_PATH");
        match quote(&parcel(300, "domestic")) {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected RateCardUnavailable, got {other:?}"),
        }
    }

    #[test]
    fn missing_file_is_unavailable() {
        let _guard = env_lock();
        env::set_var("RATECARD_PATH", "/no/such/rate/card/at/all");
        let result = quote(&parcel(300, "domestic"));
        env::remove_var("RATECARD_PATH");
        match result {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected RateCardUnavailable, got {other:?}"),
        }
    }

    #[test]
    fn wrong_field_count_reports_line() {
        // Line 2 has only two fields.
        let bad = "# header\ndomestic\t500\n";
        with_card(bad, || match quote(&parcel(300, "domestic")) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 2),
            other => panic!("expected MalformedRateCard, got {other:?}"),
        });
    }

    #[test]
    fn unparseable_number_reports_line_counting_blanks_and_comments() {
        // 1: comment, 2: blank, 3: good, 4: bad number.
        let bad = "# header\n\ndomestic\t500\t599\ndomestic\tXXX\t899\n";
        with_card(bad, || match quote(&parcel(300, "domestic")) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 4),
            other => panic!("expected MalformedRateCard, got {other:?}"),
        });
    }

    #[test]
    fn blanks_and_comments_are_ignored() {
        let card = "\n# a comment\n\ndomestic\t500\t599\n\n";
        with_card(card, || {
            let q = quote(&parcel(300, "domestic")).unwrap();
            assert_eq!(q.base_cents, 599);
        });
    }

    #[test]
    fn display_and_error_trait_hold() {
        let e: Box<dyn std::error::Error> =
            Box::new(QuoteError::UnknownZone("lunar".to_string()));
        assert!(e.to_string().contains("lunar"));
    }
}
