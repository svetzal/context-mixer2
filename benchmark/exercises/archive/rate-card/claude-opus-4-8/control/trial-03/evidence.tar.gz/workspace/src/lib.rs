pub mod zones;

use std::collections::BTreeMap;
use std::fmt;

/// A parcel to be quoted: its weight in grams and its destination zone.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The result of pricing a parcel against the rate card.
#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Everything that can go wrong while producing a quote.
#[derive(Debug)]
pub enum QuoteError {
    /// The `RATECARD_PATH` was unset, missing, or unreadable.
    RateCardUnavailable,
    /// A line did not hold three tab-separated fields, or its numbers did not
    /// parse. Carries the 1-based line number of the offending line.
    MalformedRateCard { line: usize },
    /// The requested zone is absent from the rate card.
    UnknownZone(String),
    /// The weight exceeds the zone's largest band. `limit` is that band's max.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(
                    f,
                    "overweight: {grams} grams exceeds limit of {limit} grams"
                )
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// One band within a zone: parcels up to `max_grams` cost `cents`.
#[derive(Clone, Copy)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Weight, in grams, strictly above which the heavy surcharge applies.
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
/// Flat surcharge, in cents, for parcels above the heavy threshold.
const HEAVY_SURCHARGE_CENTS: u64 = 500;
/// Zone that attracts the international percentage surcharge.
const INTERNATIONAL_ZONE: &str = "international";

/// Price a parcel against the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = load_rate_card()?;

    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    // Bands are held sorted ascending by max_grams; the first band that can
    // hold the weight is the match.
    let band = bands
        .iter()
        .find(|b| parcel.weight_grams <= b.max_grams)
        .ok_or_else(|| {
            let limit = bands
                .last()
                .map(|b| b.max_grams)
                .unwrap_or(0);
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            }
        })?;

    let base_cents = band.cents;

    let mut surcharge_cents = 0u64;
    if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        surcharge_cents += HEAVY_SURCHARGE_CENTS;
    }
    if parcel.zone == INTERNATIONAL_ZONE {
        // 20% of base_cents, rounded half-up to the cent.
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    // Observability: one diagnostic record per call.
    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

/// Read and parse the rate card into zone -> ascending bands.
fn load_rate_card() -> Result<BTreeMap<String, Vec<Band>>, QuoteError> {
    let path = std::env::var("RATECARD_PATH")
        .map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents =
        std::fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut card: BTreeMap<String, Vec<Band>> = BTreeMap::new();

    // Line numbers are 1-based and count every line, comments and blanks
    // included.
    for (idx, raw) in contents.lines().enumerate() {
        let line_no = idx + 1;
        let trimmed = raw.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = raw.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }

        let zone = fields[0].to_string();
        let max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;

        card.entry(zone).or_default().push(Band { max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(card)
}

/// Emit a diagnostic record for a single quote call.
fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!(
        "ratecard quote zone={zone} weight_grams={weight_grams} total_cents={total_cents}"
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;

    // quote() reads a process-global env var, so tests that set it must not
    // run concurrently.
    static ENV_LOCK: Mutex<()> = Mutex::new(());

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    /// Run `f` with `RATECARD_PATH` pointed at a file holding `contents`.
    fn with_card<T>(contents: &str, f: impl FnOnce() -> T) -> T {
        let _guard = ENV_LOCK.lock().unwrap();
        let mut file = tempfile::NamedTempFile::new().unwrap();
        file.write_all(contents.as_bytes()).unwrap();
        file.flush().unwrap();
        std::env::set_var("RATECARD_PATH", file.path());
        let out = f();
        std::env::remove_var("RATECARD_PATH");
        out
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn picks_first_band_at_or_above_weight() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&parcel(300, "domestic")).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
        });
    }

    #[test]
    fn boundary_weight_stays_in_its_band() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&parcel(500, "domestic")).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn just_over_boundary_moves_up_a_band() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&parcel(501, "domestic")).unwrap();
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
        });
    }

    #[test]
    fn heavy_parcel_adds_flat_surcharge() {
        with_card(SAMPLE_CARD, || {
            // 15000g domestic -> band 20000 (1799), heavy +500.
            let q = quote(&parcel(15_000, "domestic")).unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
            assert_eq!(q.band_max_grams, 20_000);
        });
    }

    #[test]
    fn heavy_threshold_is_strict() {
        with_card(SAMPLE_CARD, || {
            // exactly 10000g is NOT above the threshold.
            let q = quote(&parcel(10_000, "domestic")).unwrap();
            assert_eq!(q.surcharge_cents, 0);
        });
    }

    #[test]
    fn international_adds_twenty_percent_rounded_half_up() {
        with_card(SAMPLE_CARD, || {
            // 300g international -> band 500 (1499), 20% = 299.8 -> 300.
            let q = quote(&parcel(300, "international")).unwrap();
            assert_eq!(q.base_cents, 1499);
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_and_heavy_surcharges_add_together() {
        with_card(SAMPLE_CARD, || {
            // 15000g international -> band 20000 (4999).
            // heavy +500, 20% of 4999 = 999.8 -> 1000. total surcharge 1500.
            let q = quote(&parcel(15_000, "international")).unwrap();
            assert_eq!(q.base_cents, 4999);
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
        });
    }

    #[test]
    fn unknown_zone_carries_the_requested_zone() {
        with_card(SAMPLE_CARD, || {
            match quote(&parcel(100, "lunar")) {
                Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "lunar"),
                other => panic!("expected UnknownZone, got {other:?}"),
            }
        });
    }

    #[test]
    fn overweight_carries_the_largest_band_limit() {
        with_card(SAMPLE_CARD, || {
            match quote(&parcel(25_000, "domestic")) {
                Err(QuoteError::Overweight { grams, limit }) => {
                    assert_eq!(grams, 25_000);
                    assert_eq!(limit, 20_000);
                }
                other => panic!("expected Overweight, got {other:?}"),
            }
        });
    }

    #[test]
    fn unset_path_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap();
        std::env::remove_var("RATECARD_PATH");
        match quote(&parcel(100, "domestic")) {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected RateCardUnavailable, got {other:?}"),
        }
    }

    #[test]
    fn missing_file_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap();
        std::env::set_var("RATECARD_PATH", "/no/such/rate/card/at/all");
        let result = quote(&parcel(100, "domestic"));
        std::env::remove_var("RATECARD_PATH");
        match result {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected RateCardUnavailable, got {other:?}"),
        }
    }

    #[test]
    fn wrong_field_count_is_malformed_with_line_number() {
        // line 3 has only two fields.
        let card = "# header\ndomestic\t500\t599\ndomestic\t2000\n";
        with_card(card, || match quote(&parcel(100, "domestic")) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
            other => panic!("expected MalformedRateCard, got {other:?}"),
        });
    }

    #[test]
    fn unparseable_number_is_malformed_with_line_number() {
        // line 2 has a non-numeric weight.
        let card = "# header\ndomestic\theavy\t599\n";
        with_card(card, || match quote(&parcel(100, "domestic")) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 2),
            other => panic!("expected MalformedRateCard, got {other:?}"),
        });
    }

    #[test]
    fn comments_and_blanks_count_toward_line_numbers() {
        // blank line 2, comment line 3, bad line 4.
        let card = "# header\n\n# a comment\ndomestic\tbad\t599\n";
        with_card(card, || match quote(&parcel(100, "domestic")) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 4),
            other => panic!("expected MalformedRateCard, got {other:?}"),
        });
    }

    #[test]
    fn error_types_implement_display_and_error() {
        fn assert_error<E: std::error::Error>(_: &E) {}
        let e = QuoteError::UnknownZone("mars".into());
        assert_error(&e);
        assert!(!e.to_string().is_empty());
    }
}
