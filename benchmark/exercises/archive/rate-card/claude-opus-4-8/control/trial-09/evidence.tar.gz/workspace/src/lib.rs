pub mod zones;

use std::env;
use std::fmt;
use std::fs;

/// A parcel awaiting a shipping quote.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The priced result of quoting a parcel against the rate card.
#[derive(Debug, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Everything that can go wrong while producing a quote.
#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card is unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(
                    f,
                    "parcel weight {grams}g exceeds the zone limit of {limit}g"
                )
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// One band of the rate card: an upper weight threshold and its price.
struct Band {
    band_max_grams: u32,
    cents: u64,
}

/// Produce a shipping quote for `parcel` from the rate card named by the
/// `RATECARD_PATH` environment variable.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_bands_for_zone(&parcel.zone)?;

    // The zone exists in the card but carries no bands: treat as unknown.
    if bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let limit = bands
        .iter()
        .map(|b| b.band_max_grams)
        .max()
        .expect("bands is non-empty");

    let band = bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let base_cents = band.cents;
    let band_max_grams = band.band_max_grams;

    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        // 20% of base, rounded half-up to the cent.
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    // Diagnostic record, one per call.
    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

/// Read the rate card and collect the ascending bands for `zone`.
fn load_bands_for_zone(zone: &str) -> Result<Vec<Band>, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands: Vec<Band> = Vec::new();

    for (index, raw_line) in contents.lines().enumerate() {
        let line_no = index + 1; // 1-based, counts every line.
        let line = raw_line;

        if line.trim().is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }

        let band_max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;

        if fields[0] == zone {
            bands.push(Band {
                band_max_grams,
                cents,
            });
        }
    }

    bands.sort_by_key(|b| b.band_max_grams);
    Ok(bands)
}

/// Emit a per-call diagnostic to stderr carrying zone, weight, and total.
fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!(
        "quote zone={zone} weight_grams={weight_grams} total_cents={total_cents}"
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use tempfile::NamedTempFile;

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    /// Write `contents` to a temp file, point RATECARD_PATH at it, run `f`.
    ///
    /// Serialised through a mutex because the environment variable is global.
    fn with_card<T>(contents: &str, f: impl FnOnce() -> T) -> T {
        use std::sync::Mutex;
        static LOCK: Mutex<()> = Mutex::new(());
        let _guard = LOCK.lock().unwrap_or_else(|e| e.into_inner());

        let mut file = NamedTempFile::new().unwrap();
        file.write_all(contents.as_bytes()).unwrap();
        file.flush().unwrap();
        env::set_var("RATECARD_PATH", file.path());
        let result = f();
        env::remove_var("RATECARD_PATH");
        result
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn matches_first_band_at_or_above_weight() {
        with_card(CARD, || {
            let q = quote(&parcel(300, "domestic")).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
        });
    }

    #[test]
    fn weight_equal_to_threshold_matches_that_band() {
        with_card(CARD, || {
            let q = quote(&parcel(500, "domestic")).unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn picks_middle_band() {
        with_card(CARD, || {
            let q = quote(&parcel(1500, "domestic")).unwrap();
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
            assert_eq!(q.total_cents, 899);
        });
    }

    #[test]
    fn heavy_weight_adds_flat_surcharge() {
        with_card(CARD, || {
            // 12000g > 10000g, domestic top band 20000 @ 1799.
            let q = quote(&parcel(12_000, "domestic")).unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
        });
    }

    #[test]
    fn exactly_10000_does_not_surcharge() {
        with_card(CARD, || {
            let q = quote(&parcel(10_000, "domestic")).unwrap();
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_adds_20_percent_rounded_half_up() {
        with_card(CARD, || {
            // base 1499, 20% = 299.8 -> 300 half-up.
            let q = quote(&parcel(400, "international")).unwrap();
            assert_eq!(q.base_cents, 1499);
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_and_heavy_surcharges_add() {
        with_card(CARD, || {
            // base 4999, 20% = 999.8 -> 1000, plus 500 heavy = 1500.
            let q = quote(&parcel(15_000, "international")).unwrap();
            assert_eq!(q.base_cents, 4999);
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
        });
    }

    #[test]
    fn unknown_zone_carries_requested_zone() {
        with_card(CARD, || {
            match quote(&parcel(300, "lunar")) {
                Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "lunar"),
                other => panic!("expected UnknownZone, got {other:?}"),
            }
        });
    }

    #[test]
    fn overweight_carries_largest_band() {
        with_card(CARD, || {
            match quote(&parcel(25_000, "domestic")) {
                Err(QuoteError::Overweight { grams, limit }) => {
                    assert_eq!(grams, 25_000);
                    assert_eq!(limit, 20_000);
                }
                other => panic!("expected Overweight, got {other:?}"),
            }
        });
    }

    #[test]
    fn unset_path_is_unavailable() {
        // Ensure it is unset.
        use std::sync::Mutex;
        static LOCK: Mutex<()> = Mutex::new(());
        let _guard = LOCK.lock().unwrap_or_else(|e| e.into_inner());
        env::remove_var("RATECARD_PATH");
        assert_eq!(
            quote(&parcel(300, "domestic")),
            Err(QuoteError::RateCardUnavailable)
        );
    }

    #[test]
    fn missing_file_is_unavailable() {
        use std::sync::Mutex;
        static LOCK: Mutex<()> = Mutex::new(());
        let _guard = LOCK.lock().unwrap_or_else(|e| e.into_inner());
        env::set_var("RATECARD_PATH", "/no/such/rate/card/anywhere");
        let result = quote(&parcel(300, "domestic"));
        env::remove_var("RATECARD_PATH");
        assert_eq!(result, Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn wrong_field_count_reports_line() {
        let bad = "domestic\t500\t599\ndomestic\t2000\n";
        with_card(bad, || {
            assert_eq!(
                quote(&parcel(300, "domestic")),
                Err(QuoteError::MalformedRateCard { line: 2 })
            );
        });
    }

    #[test]
    fn unparseable_number_reports_line() {
        let bad = "# header\ndomestic\t500\tabc\n";
        with_card(bad, || {
            assert_eq!(
                quote(&parcel(300, "domestic")),
                Err(QuoteError::MalformedRateCard { line: 2 })
            );
        });
    }

    #[test]
    fn comments_and_blanks_count_toward_line_numbers() {
        // Lines: 1 comment, 2 blank, 3 good, 4 malformed.
        let bad = "# c\n\ndomestic\t500\t599\ndomestic\tbad\t1\n";
        with_card(bad, || {
            assert_eq!(
                quote(&parcel(300, "domestic")),
                Err(QuoteError::MalformedRateCard { line: 4 })
            );
        });
    }

    #[test]
    fn error_types_display_and_are_std_errors() {
        let e: Box<dyn std::error::Error> = Box::new(QuoteError::UnknownZone("z".into()));
        assert!(e.to_string().contains('z'));
    }
}
