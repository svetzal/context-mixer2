use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

/// A parcel to price against the configured rate card.
#[derive(Debug, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price and band selected for a parcel.
#[derive(Debug, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// An error encountered while loading a rate card or pricing a parcel.
#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card line {line} is malformed")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighs {grams} grams, over the {limit} gram limit")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Clone, Copy)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculate a shipping quote from the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let result = quote_inner(parcel);
    eprintln!(
        "diagnostic=quote zone={} weight_grams={} total_cents={}",
        parcel.zone,
        parcel.weight_grams,
        result
            .as_ref()
            .map_or_else(|_| "unavailable".to_owned(), |quote| quote.total_cents.to_string())
    );
    result
}

fn quote_inner(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = parse_rate_card(&contents)?;
    let zone_bands = bands
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = zone_bands
        .iter()
        .find(|band| parcel.weight_grams <= band.max_grams)
        .copied()
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: zone_bands.last().expect("a rate-card zone cannot have zero bands").max_grams,
        })?;

    let weight_surcharge = if parcel.weight_grams > 10_000 { 500 } else { 0 };
    let international_surcharge = if parcel.zone == "international" {
        // Integer arithmetic gives half-up rounding for a 20% surcharge.
        (band.cents * 20 + 50) / 100
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;
    let total_cents = band.cents + surcharge_cents;

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut bands: HashMap<String, Vec<Band>> = HashMap::new();

    for (line_index, line) in contents.lines().enumerate() {
        let line_number = line_index + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        bands.entry(fields[0].to_owned()).or_default().push(Band { max_grams, cents });
    }

    for zone_bands in bands.values_mut() {
        zone_bands.sort_unstable_by_key(|band| band.max_grams);
    }
    Ok(bands)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::io::Write;
    use std::path::PathBuf;
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn card(contents: &str) -> PathBuf {
        let path = std::env::temp_dir().join(format!("ratecard-test-{}", std::process::id()));
        let mut file = fs::File::create(&path).unwrap();
        file.write_all(contents.as_bytes()).unwrap();
        path
    }

    fn with_card(contents: &str, parcel: Parcel) -> Result<Quote, QuoteError> {
        let _guard = ENV_LOCK.lock().unwrap();
        let path = card(contents);
        std::env::set_var("RATECARD_PATH", &path);
        let result = quote(&parcel);
        std::env::remove_var("RATECARD_PATH");
        fs::remove_file(path).unwrap();
        result
    }

    #[test]
    fn selects_the_first_sufficient_band_and_adds_surcharges() {
        let result = with_card(
            "# comment\ninternational\t20000\t4999\ninternational\t500\t1499\n",
            Parcel {
                weight_grams: 10_001,
                zone: "international".into(),
            },
        )
        .unwrap();

        assert_eq!(result.base_cents, 4999);
        assert_eq!(result.surcharge_cents, 1500);
        assert_eq!(result.total_cents, 6499);
        assert_eq!(result.band_max_grams, 20_000);
    }

    #[test]
    fn reports_unknown_zone_and_overweight() {
        let unknown = with_card(
            "domestic\t500\t599\n",
            Parcel {
                weight_grams: 1,
                zone: "mars".into(),
            },
        );
        assert_eq!(unknown, Err(QuoteError::UnknownZone("mars".into())));

        let overweight = with_card(
            "domestic\t500\t599\n",
            Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            },
        );
        assert_eq!(
            overweight,
            Err(QuoteError::Overweight {
                grams: 501,
                limit: 500
            })
        );
    }

    #[test]
    fn reports_unavailable_and_malformed_cards() {
        let _guard = ENV_LOCK.lock().unwrap();
        std::env::remove_var("RATECARD_PATH");
        assert_eq!(
            quote(&Parcel {
                weight_grams: 1,
                zone: "domestic".into()
            }),
            Err(QuoteError::RateCardUnavailable)
        );

        let path = card("# first\ninvalid\ndomestic\t500\t599\n");
        std::env::set_var("RATECARD_PATH", &path);
        assert_eq!(
            quote(&Parcel {
                weight_grams: 1,
                zone: "domestic".into()
            }),
            Err(QuoteError::MalformedRateCard { line: 2 })
        );
        std::env::remove_var("RATECARD_PATH");
        fs::remove_file(path).unwrap();
    }
}
