//! Shipping quotes calculated from an operations-managed rate card.

use std::collections::HashMap;
use std::env;
use std::fmt;
use std::fs;
use std::path::Path;

pub mod zones;

/// A parcel to price.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price calculated for a parcel.
#[derive(Debug, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// An error encountered while loading the rate card or pricing a parcel.
#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card line {line} is malformed")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds rate-card limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Clone, Copy)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculate a shipping quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents =
        fs::read_to_string(Path::new(&path)).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = parse_rate_card(&contents)?;

    let zone_bands = bands
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band = zone_bands
        .iter()
        .find(|band| parcel.weight_grams <= band.max_grams)
        .copied()
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: zone_bands.last().expect("a zone is only inserted with a band").max_grams,
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        // 20% is one fifth. Rounding the remainder up at .5 gives half-up
        // rounding without multiplying a potentially large u64 by 20.
        band.cents / 5 + u64::from(band.cents % 5 >= 3)
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;
    let total_cents = band.cents + surcharge_cents;

    eprintln!(
        "ratecard.quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut bands: HashMap<String, Vec<Band>> = HashMap::new();

    for (line_index, line) in contents.lines().enumerate() {
        let line_number = line_index + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        bands.entry(fields[0].to_owned()).or_default().push(Band { max_grams, cents });
    }

    for zone_bands in bands.values_mut() {
        zone_bands.sort_unstable_by_key(|band| band.max_grams);
    }

    Ok(bands)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use std::{fs, path::PathBuf, time::SystemTime};

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn card(contents: &str) -> PathBuf {
        let nonce = SystemTime::now()
            .duration_since(SystemTime::UNIX_EPOCH)
            .expect("system clock")
            .as_nanos();
        let path = env::temp_dir().join(format!("ratecard-test-{}-{nonce}", std::process::id()));
        let mut file = fs::File::create(&path).expect("temporary rate card");
        file.write_all(contents.as_bytes()).expect("write rate card");
        path
    }

    fn quote_with_card(contents: &str, parcel: Parcel) -> Result<Quote, QuoteError> {
        let _guard = ENV_LOCK.lock().expect("environment lock");
        let file = card(contents);
        let old_path = env::var_os("RATECARD_PATH");
        env::set_var("RATECARD_PATH", &file);
        let result = quote(&parcel);
        fs::remove_file(file).expect("remove temporary rate card");
        match old_path {
            Some(path) => env::set_var("RATECARD_PATH", path),
            None => env::remove_var("RATECARD_PATH"),
        }
        result
    }

    #[test]
    fn selects_sorted_band_and_adds_surcharges() {
        let result = quote_with_card(
            "# comment\ninternational\t20000\t4999\ninternational\t500\t1499\n",
            Parcel {
                weight_grams: 12_000,
                zone: "international".into(),
            },
        )
        .expect("quote");

        assert_eq!(result.base_cents, 4999);
        assert_eq!(result.surcharge_cents, 1500);
        assert_eq!(result.total_cents, 6499);
        assert_eq!(result.band_max_grams, 20_000);
    }

    #[test]
    fn reports_unknown_zone_and_overweight() {
        assert_eq!(
            quote_with_card(
                "domestic\t500\t599\n",
                Parcel {
                    weight_grams: 1,
                    zone: "mars".into()
                }
            ),
            Err(QuoteError::UnknownZone("mars".into()))
        );
        assert_eq!(
            quote_with_card(
                "domestic\t500\t599\n",
                Parcel {
                    weight_grams: 501,
                    zone: "domestic".into()
                }
            ),
            Err(QuoteError::Overweight {
                grams: 501,
                limit: 500
            })
        );
    }

    #[test]
    fn reports_malformed_line_number_and_unavailable_card() {
        assert_eq!(
            quote_with_card(
                "# one\n\ndomestic\tnope\t599\n",
                Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                }
            ),
            Err(QuoteError::MalformedRateCard { line: 3 })
        );

        let _guard = ENV_LOCK.lock().expect("environment lock");
        let old_path = env::var_os("RATECARD_PATH");
        env::remove_var("RATECARD_PATH");
        assert_eq!(
            quote(&Parcel {
                weight_grams: 1,
                zone: "domestic".into()
            }),
            Err(QuoteError::RateCardUnavailable)
        );
        if let Some(path) = old_path {
            env::set_var("RATECARD_PATH", path);
        }
    }
}
