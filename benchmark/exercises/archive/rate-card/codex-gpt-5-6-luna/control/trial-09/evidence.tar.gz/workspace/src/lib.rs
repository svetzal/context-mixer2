use std::{collections::HashMap, env, error::Error, fmt, fs};

pub mod zones;

/// A parcel to be priced by the rate card.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price calculated for a parcel.
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Reasons a parcel could not be priced.
#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card on line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighs {grams} grams, exceeding the {limit} gram limit")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Clone, Copy)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculate a shipping quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let rates = parse_rate_card(&contents)?;

    let bands = rates
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let largest = bands.last().expect("rate card zones cannot be empty");
    if parcel.weight_grams > largest.max_grams {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest.max_grams,
        });
    }

    let band = bands
        .iter()
        .find(|band| parcel.weight_grams <= band.max_grams)
        .expect("weight was checked against the largest band");
    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        // Add half the denominator before division to round half-up.
        (band.cents * 20 + 50) / 100
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;
    let total_cents = band.cents + surcharge_cents;

    eprintln!(
        "{{\"event\":\"shipping_quote\",\"zone\":{:?},\"weight_grams\":{},\"total_cents\":{}}}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut rates: HashMap<String, Vec<Band>> = HashMap::new();
    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        rates.entry(fields[0].to_owned()).or_default().push(Band { max_grams, cents });
    }

    for bands in rates.values_mut() {
        bands.sort_unstable_by_key(|band| band.max_grams);
    }
    Ok(rates)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Mutex;
    use std::{fs, io::Write, path::PathBuf};

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn with_card(contents: &str, action: impl FnOnce()) {
        let _guard = ENV_LOCK.lock().unwrap();
        let path = PathBuf::from(format!(
            "{}/ratecard-test-{}-{}",
            env::temp_dir().display(),
            std::process::id(),
            contents.len()
        ));
        let mut file = fs::File::create(&path).unwrap();
        file.write_all(contents.as_bytes()).unwrap();
        let previous = env::var_os("RATECARD_PATH");
        unsafe { env::set_var("RATECARD_PATH", &path) };
        action();
        match previous {
            Some(value) => unsafe { env::set_var("RATECARD_PATH", value) },
            None => unsafe { env::remove_var("RATECARD_PATH") },
        }
        fs::remove_file(path).unwrap();
    }

    #[test]
    fn selects_sorted_band_and_calculates_surcharge() {
        with_card("domestic\t2000\t899\ndomestic\t500\t599\n", || {
            let result = quote(&Parcel {
                weight_grams: 600,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(result.base_cents, 899);
            assert_eq!(result.surcharge_cents, 0);
            assert_eq!(result.total_cents, 899);
            assert_eq!(result.band_max_grams, 2000);
        });
    }

    #[test]
    fn applies_both_surcharges() {
        with_card("international\t20000\t4999\n", || {
            let result = quote(&Parcel {
                weight_grams: 15000,
                zone: "international".into(),
            })
            .unwrap();
            assert_eq!(result.surcharge_cents, 1500);
            assert_eq!(result.total_cents, 6499);
        });
    }

    #[test]
    fn reports_malformed_lines_and_unknown_or_overweight_parcels() {
        with_card("# comment\n\n domestic\t500\t599\n", || {
            assert!(matches!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                }),
                Err(QuoteError::UnknownZone(_))
            ));
        });
        with_card("domestic\tnope\t599\n", || {
            assert!(matches!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                }),
                Err(QuoteError::MalformedRateCard { line: 1 })
            ));
        });
        with_card("domestic\t500\t599\n", || {
            assert!(matches!(
                quote(&Parcel {
                    weight_grams: 501,
                    zone: "domestic".into()
                }),
                Err(QuoteError::Overweight {
                    grams: 501,
                    limit: 500
                })
            ));
        });
    }
}
