use std::collections::HashMap;
use std::env;
use std::fmt;
use std::fs;

pub mod zones;

/// A parcel to price.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price calculated for a parcel.
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Reasons a parcel could not be priced.
#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighs {grams} grams, exceeding the {limit} gram limit")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Clone, Copy)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculate a shipping quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let result = quote_inner(parcel);
    match result.as_ref().ok().map(|quote| quote.total_cents) {
        Some(total_cents) => eprintln!(
            "ratecard.quote zone={:?} weight_grams={} total_cents={total_cents}",
            parcel.zone, parcel.weight_grams
        ),
        None => eprintln!(
            "ratecard.quote zone={:?} weight_grams={} total_cents=null",
            parcel.zone, parcel.weight_grams
        ),
    }
    result
}

fn quote_inner(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = parse_rate_card(&contents)?;
    let zone_bands = bands
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band = zone_bands
        .iter()
        .find(|band| parcel.weight_grams <= band.max_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: zone_bands.last().expect("a zone always has a band").max_grams,
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        // Divide before rounding so this cannot overflow for a valid u64 rate.
        band.cents / 5 + u64::from(band.cents % 5 >= 3)
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut bands: HashMap<String, Vec<Band>> = HashMap::new();
    for (line_index, line) in contents.lines().enumerate() {
        let line_number = line_index + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        bands.entry(fields[0].to_owned()).or_default().push(Band { max_grams, cents });
    }
    for zone_bands in bands.values_mut() {
        zone_bands.sort_by_key(|band| band.max_grams);
    }
    Ok(bands)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::{Mutex, OnceLock};
    use tempfile::NamedTempFile;

    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    fn with_card(contents: &str, test: impl FnOnce()) {
        let _guard = env_lock().lock().unwrap();
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(contents.as_bytes()).unwrap();
        let previous = env::var_os("RATECARD_PATH");
        env::set_var("RATECARD_PATH", file.path());
        test();
        match previous {
            Some(value) => env::set_var("RATECARD_PATH", value),
            None => env::remove_var("RATECARD_PATH"),
        }
    }

    #[test]
    fn selects_sorted_band_and_adds_surcharges() {
        with_card("# comment\ninternational\t20000\t4999\ninternational\t500\t1499\n", || {
            let result = quote(&Parcel {
                weight_grams: 10_001,
                zone: "international".into(),
            })
            .unwrap();
            assert_eq!(result.base_cents, 4999);
            assert_eq!(result.surcharge_cents, 1500);
            assert_eq!(result.total_cents, 6499);
            assert_eq!(result.band_max_grams, 20_000);
        });
    }

    #[test]
    fn reports_public_error_variants() {
        with_card("domestic\t500\t599\n", || {
            assert!(
                matches!(quote(&Parcel { weight_grams: 1, zone: "mars".into() }), Err(QuoteError::UnknownZone(zone)) if zone == "mars")
            );
            assert!(matches!(
                quote(&Parcel {
                    weight_grams: 501,
                    zone: "domestic".into()
                }),
                Err(QuoteError::Overweight {
                    grams: 501,
                    limit: 500
                })
            ));
        });
        with_card("bad line\n", || {
            assert!(matches!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                }),
                Err(QuoteError::MalformedRateCard { line: 1 })
            ));
        });
    }

    #[test]
    fn unavailable_rate_card_is_reported() {
        let _guard = env_lock().lock().unwrap();
        env::remove_var("RATECARD_PATH");
        assert!(matches!(
            quote(&Parcel {
                weight_grams: 1,
                zone: "domestic".into()
            }),
            Err(QuoteError::RateCardUnavailable)
        ));
    }
}
