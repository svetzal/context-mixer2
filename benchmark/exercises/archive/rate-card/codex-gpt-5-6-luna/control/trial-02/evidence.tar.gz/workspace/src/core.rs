use std::{collections::HashMap, env, fs};

use tracing::info;

/// A parcel to price.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The calculated shipping quote, in cents.
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// An error encountered while loading or applying the rate card.
#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card on line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighs {grams} grams, above limit {limit}")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Clone, Copy)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculate a quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = parse_rate_card(&contents)?;

    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band =
        bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands.last().map_or(0, |band| band.max_grams),
            }
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        // Add 50 before dividing to round 20% half-up to the nearest cent.
        (band.cents * 20 + 50) / 100
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;
    let total_cents = band.cents + surcharge_cents;

    info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents,
        "quote calculated"
    );

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut card: HashMap<String, Vec<Band>> = HashMap::new();

    for (line_index, raw_line) in contents.lines().enumerate() {
        let line_number = line_index + 1;
        let line = raw_line.strip_suffix('\r').unwrap_or(raw_line);
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        card.entry(fields[0].to_owned()).or_default().push(Band { max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_unstable_by_key(|band| band.max_grams);
    }
    Ok(card)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::{Mutex, OnceLock};
    use tempfile::NamedTempFile;

    static ENV_LOCK: OnceLock<Mutex<()>> = OnceLock::new();

    fn with_card(contents: &str, parcel: Parcel) -> Result<Quote, QuoteError> {
        let _guard = ENV_LOCK.get_or_init(|| Mutex::new(())).lock().unwrap();
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(contents.as_bytes()).unwrap();
        let previous = env::var_os("RATECARD_PATH");
        env::set_var("RATECARD_PATH", file.path());
        let result = quote(&parcel);
        match previous {
            Some(value) => env::set_var("RATECARD_PATH", value),
            None => env::remove_var("RATECARD_PATH"),
        }
        result
    }

    #[test]
    fn selects_sorted_band_and_adds_weight_surcharge() {
        let result = with_card(
            "# comment\ndomestic\t20000\t1799\ndomestic\t500\t599\ndomestic\t2000\t899\n",
            Parcel {
                weight_grams: 10_001,
                zone: "domestic".into(),
            },
        )
        .unwrap();
        assert_eq!(
            (
                result.base_cents,
                result.surcharge_cents,
                result.total_cents,
                result.band_max_grams
            ),
            (1799, 500, 2299, 20000)
        );
    }

    #[test]
    fn applies_international_surcharge_with_half_up_rounding() {
        let result = with_card(
            "international\t500\t1499\n",
            Parcel {
                weight_grams: 500,
                zone: "international".into(),
            },
        )
        .unwrap();
        assert_eq!((result.surcharge_cents, result.total_cents), (300, 1799));
    }

    #[test]
    fn reports_unknown_zone_and_overweight() {
        assert!(matches!(
            with_card(
                "domestic\t500\t599\n",
                Parcel {
                    weight_grams: 1,
                    zone: "mars".into()
                }
            ),
            Err(QuoteError::UnknownZone(zone)) if zone == "mars"
        ));
        assert!(matches!(
            with_card(
                "domestic\t500\t599\n",
                Parcel {
                    weight_grams: 501,
                    zone: "domestic".into()
                }
            ),
            Err(QuoteError::Overweight {
                grams: 501,
                limit: 500
            })
        ));
    }

    #[test]
    fn reports_malformed_line_number() {
        assert!(matches!(
            with_card(
                "# heading\n\ndomestic\tbad\t599\n",
                Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                }
            ),
            Err(QuoteError::MalformedRateCard { line: 3 })
        ));
    }
}
