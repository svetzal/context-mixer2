pub mod zones;

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

/// A parcel to price against the configured shipping rate card.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price calculated for a parcel.
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Errors encountered while loading a rate card or calculating a quote.
#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card on line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighs {grams} grams, exceeding the {limit} gram limit")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Clone, Copy)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculate a shipping quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let rate_card = parse_rate_card(&contents)?;
    let bands = rate_card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band =
        bands.iter().find(|band| band.max_grams >= parcel.weight_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands.last().expect("a zone cannot have no bands").max_grams,
            }
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        // Integer half-up rounding: (base * 20 / 100), rounded at .5 cents.
        (band.cents * 20 + 50) / 100
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;
    let total_cents = band.cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut rate_card: HashMap<String, Vec<Band>> = HashMap::new();

    for (line_number, line) in contents.lines().enumerate() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let mut fields = line.split('\t');
        let Some(zone) = fields.next() else {
            return Err(QuoteError::MalformedRateCard {
                line: line_number + 1,
            });
        };
        let Some(max_grams) = fields.next() else {
            return Err(QuoteError::MalformedRateCard {
                line: line_number + 1,
            });
        };
        let Some(cents) = fields.next() else {
            return Err(QuoteError::MalformedRateCard {
                line: line_number + 1,
            });
        };
        if fields.next().is_some() {
            return Err(QuoteError::MalformedRateCard {
                line: line_number + 1,
            });
        }

        let max_grams =
            max_grams.trim().parse::<u32>().map_err(|_| QuoteError::MalformedRateCard {
                line: line_number + 1,
            })?;
        let cents = cents.trim().parse::<u64>().map_err(|_| QuoteError::MalformedRateCard {
            line: line_number + 1,
        })?;

        rate_card
            .entry(zone.trim().to_owned())
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in rate_card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }
    Ok(rate_card)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Mutex;
    use std::{fs, time::SystemTime};

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn with_card(contents: &str, parcel: Parcel) -> Result<Quote, QuoteError> {
        let _guard = ENV_LOCK.lock().unwrap();
        let unique = SystemTime::now().duration_since(SystemTime::UNIX_EPOCH).unwrap().as_nanos();
        let path = std::env::temp_dir().join(format!("ratecard-test-{unique}.tsv"));
        fs::write(&path, contents).unwrap();
        std::env::set_var("RATECARD_PATH", &path);
        let result = quote(&parcel);
        fs::remove_file(path).unwrap();
        result
    }

    #[test]
    fn selects_band_and_adds_weight_surcharge() {
        let result = with_card(
            "domestic\t500\t599\ndomestic\t20000\t1799\n",
            Parcel {
                weight_grams: 10_001,
                zone: "domestic".into(),
            },
        )
        .unwrap();
        assert_eq!(result.base_cents, 1799);
        assert_eq!(result.surcharge_cents, 500);
        assert_eq!(result.total_cents, 2299);
        assert_eq!(result.band_max_grams, 20_000);
    }

    #[test]
    fn rounds_international_surcharge_half_up() {
        let result = with_card(
            "international\t500\t1499\n",
            Parcel {
                weight_grams: 500,
                zone: "international".into(),
            },
        )
        .unwrap();
        assert_eq!(result.surcharge_cents, 300);
        assert_eq!(result.total_cents, 1799);
    }

    #[test]
    fn reports_malformed_line_number_and_unknown_zone() {
        assert!(matches!(
            with_card(
                "# comment\n\ndomestic\tnope\t599\n",
                Parcel {
                    weight_grams: 1,
                    zone: "domestic".into(),
                }
            ),
            Err(QuoteError::MalformedRateCard { line: 3 })
        ));
        assert!(matches!(
            with_card("domestic\t500\t599\n", Parcel {
                weight_grams: 1,
                zone: "rural".into(),
            }),
            Err(QuoteError::UnknownZone(zone)) if zone == "rural"
        ));
    }

    #[test]
    fn reports_overweight_against_largest_band() {
        assert!(matches!(
            with_card(
                "domestic\t500\t599\ndomestic\t2000\t899\n",
                Parcel {
                    weight_grams: 2001,
                    zone: "domestic".into(),
                }
            ),
            Err(QuoteError::Overweight {
                grams: 2001,
                limit: 2000
            })
        ));
    }
}
