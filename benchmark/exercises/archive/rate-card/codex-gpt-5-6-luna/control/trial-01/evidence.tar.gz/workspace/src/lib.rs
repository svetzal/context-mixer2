pub mod zones;

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

/// A parcel to be priced by the rate card.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price and band selected for a parcel.
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// An error encountered while loading or applying the rate card.
#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown rate-card zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weighs {grams} grams, over the {limit}-gram limit")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Clone, Copy)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculate a shipping quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = parse_rate_card(&contents)?;
    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band =
        bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands.last().expect("a zone always has a band").max_grams,
            }
        })?;

    let mut surcharge_cents = if parcel.weight_grams > 10_000 { 500 } else { 0 };
    if parcel.zone == "international" {
        // Integer arithmetic gives half-up rounding without floating-point loss.
        surcharge_cents += (band.cents * 20 + 50) / 100;
    }
    let total_cents = band.cents + surcharge_cents;

    emit_diagnostic(parcel, total_cents);

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut card: HashMap<String, Vec<Band>> = HashMap::new();

    for (line_index, line) in contents.lines().enumerate() {
        let line_number = line_index + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let zone = fields[0].trim();
        let max_grams = fields[1]
            .trim()
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .trim()
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        if zone.is_empty() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        card.entry(zone.to_owned()).or_default().push(Band { max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }
    Ok(card)
}

fn emit_diagnostic(parcel: &Parcel, total_cents: u64) {
    eprintln!(
        "diagnostic=shipping_quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::path::PathBuf;
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn rate_card(contents: &str) -> PathBuf {
        let path = env::temp_dir().join(format!("ratecard-test-{}.txt", std::process::id()));
        fs::write(&path, contents).unwrap();
        path
    }

    fn with_card(contents: &str, parcel: Parcel) -> Result<Quote, QuoteError> {
        let _guard = ENV_LOCK.lock().unwrap();
        let path = rate_card(contents);
        unsafe { env::set_var("RATECARD_PATH", &path) };
        let result = quote(&parcel);
        unsafe { env::remove_var("RATECARD_PATH") };
        fs::remove_file(path).unwrap();
        result
    }

    #[test]
    fn selects_sorted_band_and_adds_weight_surcharge() {
        let result = with_card(
            "# comment\ndomestic\t20000\t1799\ndomestic\t500\t599\n",
            Parcel {
                weight_grams: 10_001,
                zone: "domestic".into(),
            },
        )
        .unwrap();
        assert_eq!(result.base_cents, 1799);
        assert_eq!(result.surcharge_cents, 500);
        assert_eq!(result.total_cents, 2299);
        assert_eq!(result.band_max_grams, 20_000);
    }

    #[test]
    fn international_surcharge_rounds_half_up() {
        let result = with_card(
            "international\t500\t1499\n",
            Parcel {
                weight_grams: 500,
                zone: "international".into(),
            },
        )
        .unwrap();
        assert_eq!(result.surcharge_cents, 300);
        assert_eq!(result.total_cents, 1799);
    }

    #[test]
    fn reports_card_and_lookup_errors() {
        let malformed = with_card(
            "# first\n\ndomestic\tnot-a-number\t599\n",
            Parcel {
                weight_grams: 1,
                zone: "domestic".into(),
            },
        );
        assert!(matches!(malformed, Err(QuoteError::MalformedRateCard { line: 3 })));

        let unknown = with_card(
            "domestic\t500\t599\n",
            Parcel {
                weight_grams: 1,
                zone: "remote".into(),
            },
        );
        assert!(matches!(unknown, Err(QuoteError::UnknownZone(zone)) if zone == "remote"));

        let overweight = with_card(
            "domestic\t500\t599\n",
            Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            },
        );
        assert!(matches!(
            overweight,
            Err(QuoteError::Overweight {
                grams: 501,
                limit: 500
            })
        ));
    }
}
