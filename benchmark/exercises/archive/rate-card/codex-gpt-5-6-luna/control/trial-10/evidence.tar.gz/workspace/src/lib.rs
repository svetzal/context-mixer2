pub mod zones;

use std::{env, error::Error, fmt, fs};

/// A parcel to be priced against the configured rate card.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price calculated for a parcel.
#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// An error encountered while loading or applying the rate card.
#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card is unavailable"),
            Self::MalformedRateCard { line } => write!(f, "malformed rate card at line {line}"),
            Self::UnknownZone(zone) => write!(f, "unknown rate-card zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weighs {grams} grams, exceeding the {limit}-gram limit")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculates a shipping quote using the rate card at `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let mut bands: Vec<(String, Band)> = Vec::new();

    for (line_index, line) in contents.lines().enumerate() {
        let line_number = line_index + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        bands.push((fields[0].to_owned(), Band { max_grams, cents }));
    }

    let zone_bands: Vec<_> = bands
        .iter()
        .filter(|(zone, _)| zone == &parcel.zone)
        .map(|(_, band)| band)
        .collect();
    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let largest = zone_bands
        .iter()
        .max_by_key(|band| band.max_grams)
        .expect("zone_bands was checked to be non-empty");
    let selected = zone_bands
        .iter()
        .filter(|band| band.max_grams >= parcel.weight_grams)
        .min_by_key(|band| band.max_grams);
    let band = selected.ok_or(QuoteError::Overweight {
        grams: parcel.weight_grams,
        limit: largest.max_grams,
    })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        // Integer arithmetic implements half-up rounding without floating point.
        (band.cents * 20 + 50) / 100
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;
    let total_cents = band.cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn quote_from(card: &str, parcel: Parcel) -> Result<Quote, QuoteError> {
        let _guard = ENV_LOCK.lock().unwrap();
        let path = env::temp_dir().join(format!("ratecard-test-{}", std::process::id()));
        fs::write(&path, card).unwrap();
        env::set_var("RATECARD_PATH", &path);
        let result = quote(&parcel);
        fs::remove_file(path).unwrap();
        result
    }

    #[test]
    fn selects_smallest_matching_band() {
        let result = quote_from(
            "domestic\t500\t599\ndomestic\t2000\t899\n",
            Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            },
        )
        .unwrap();
        assert_eq!(result.base_cents, 899);
        assert_eq!(result.total_cents, 899);
        assert_eq!(result.band_max_grams, 2000);
    }

    #[test]
    fn applies_both_surcharges_with_half_up_rounding() {
        let result = quote_from(
            "international\t20000\t1499\n",
            Parcel {
                weight_grams: 10001,
                zone: "international".into(),
            },
        )
        .unwrap();
        assert_eq!(result.surcharge_cents, 800); // 500 + round-half-up(299.8)
        assert_eq!(result.total_cents, 2299);
    }

    #[test]
    fn reports_malformed_physical_line_number() {
        let error = quote_from(
            "# comment\n\ndomestic\tnope\t599\n",
            Parcel {
                weight_grams: 1,
                zone: "domestic".into(),
            },
        )
        .unwrap_err();
        assert!(matches!(error, QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn reports_unknown_zone_and_overweight() {
        let unknown = quote_from(
            "domestic\t500\t599\n",
            Parcel {
                weight_grams: 1,
                zone: "moon".into(),
            },
        )
        .unwrap_err();
        assert!(matches!(unknown, QuoteError::UnknownZone(zone) if zone == "moon"));

        let overweight = quote_from(
            "domestic\t500\t599\n",
            Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            },
        )
        .unwrap_err();
        assert!(matches!(
            overweight,
            QuoteError::Overweight {
                grams: 501,
                limit: 500
            }
        ));
    }
}
