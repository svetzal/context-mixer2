pub mod zones;

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

/// A parcel to price against the configured rate card.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price calculated for a parcel.
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// An error encountered while loading or applying the rate card.
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card line {line} is malformed")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighs {grams} grams, exceeding the {limit} gram limit")
            }
        }
    }
}

impl fmt::Debug for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("RateCardUnavailable"),
            Self::MalformedRateCard { line } => {
                formatter.debug_struct("MalformedRateCard").field("line", line).finish()
            }
            Self::UnknownZone(zone) => formatter.debug_tuple("UnknownZone").field(zone).finish(),
            Self::Overweight { grams, limit } => formatter
                .debug_struct("Overweight")
                .field("grams", grams)
                .field("limit", limit)
                .finish(),
        }
    }
}

impl Error for QuoteError {}

#[derive(Clone, Copy)]
struct Band {
    maximum_grams: u32,
    cents: u64,
}

/// Calculate a shipping quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = parse_rate_card(&contents)?;

    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band =
        bands
            .iter()
            .find(|band| band.maximum_grams >= parcel.weight_grams)
            .ok_or_else(|| QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands
                    .last()
                    .expect("a zone in the card always has at least one band")
                    .maximum_grams,
            })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        // Twenty percent is one fifth; round half-up when the remainder is
        // at least half of the denominator.
        band.cents / 5 + u64::from(band.cents % 5 >= 3)
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;
    let result = Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents.saturating_add(surcharge_cents),
        band_max_grams: band.maximum_grams,
    };

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, result.total_cents
    );
    Ok(result)
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut card: HashMap<String, Vec<Band>> = HashMap::new();
    for (line_index, line) in contents.lines().enumerate() {
        let line_number = line_index + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let maximum_grams = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        card.entry(fields[0].to_owned()).or_default().push(Band {
            maximum_grams,
            cents,
        });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|band| band.maximum_grams);
    }
    Ok(card)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn with_card(contents: &str, test: impl FnOnce()) {
        let _lock = ENV_LOCK.lock().unwrap();
        let file = NamedTempFile::new().unwrap();
        fs::write(file.path(), contents).unwrap();
        unsafe { env::set_var("RATECARD_PATH", file.path()) };
        test();
        unsafe { env::remove_var("RATECARD_PATH") };
    }

    #[test]
    fn selects_sorted_band_and_adds_weight_surcharge() {
        with_card("domestic\t20000\t1799\ndomestic\t500\t599\n", || {
            let result = quote(&Parcel {
                weight_grams: 10_001,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(result.base_cents, 1799);
            assert_eq!(result.surcharge_cents, 500);
            assert_eq!(result.total_cents, 2299);
            assert_eq!(result.band_max_grams, 20_000);
        });
    }

    #[test]
    fn adds_international_surcharge_with_half_up_rounding() {
        with_card("international\t500\t1499\n", || {
            let result = quote(&Parcel {
                weight_grams: 500,
                zone: "international".into(),
            })
            .unwrap();
            assert_eq!(result.surcharge_cents, 300);
            assert_eq!(result.total_cents, 1799);
        });
    }

    #[test]
    fn reports_line_numbers_and_lookup_errors() {
        with_card("# heading\n\ndomestic\tnope\t599\n", || {
            assert!(matches!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                }),
                Err(QuoteError::MalformedRateCard { line: 3 })
            ));
        });
        with_card("domestic\t500\t599\n", || {
            assert!(matches!(
                quote(&Parcel {
                    weight_grams: 1,
                    zone: "remote".into()
                }),
                Err(QuoteError::UnknownZone(zone)) if zone == "remote"
            ));
            assert!(matches!(
                quote(&Parcel {
                    weight_grams: 501,
                    zone: "domestic".into()
                }),
                Err(QuoteError::Overweight {
                    grams: 501,
                    limit: 500
                })
            ));
        });
    }
}
