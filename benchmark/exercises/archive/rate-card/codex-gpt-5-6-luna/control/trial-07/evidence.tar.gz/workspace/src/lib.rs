pub mod zones;

use std::{env, error::Error, fmt, fs};

/// A parcel to be priced by the rate card.
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price calculated for a parcel.
#[derive(Debug, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Errors that can prevent a parcel from being quoted.
#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "rate card line {line} is malformed")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown rate-card zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighs {grams} grams, above the {limit}-gram limit")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug)]
struct Band {
    zone: String,
    max_grams: u32,
    cents: u64,
}

/// Calculate a shipping quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let mut bands = parse_rate_card(&contents)?;

    bands.sort_by_key(|band| band.max_grams);

    let zone_bands: Vec<&Band> = bands.iter().filter(|band| band.zone == parcel.zone).collect();
    let largest_band = zone_bands
        .iter()
        .max_by_key(|band| band.max_grams)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = zone_bands
        .iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .copied()
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest_band.max_grams,
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        // Divide by five rather than multiplying first, avoiding overflow for
        // the largest representable rate while retaining half-up rounding.
        band.cents / 5 + u64::from(band.cents % 5 >= 3)
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;
    let total_cents = band.cents + surcharge_cents;

    eprintln!(
        "{{\"event\":\"quote\",\"zone\":{:?},\"weight_grams\":{},\"total_cents\":{}}}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn parse_rate_card(contents: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();
    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        bands.push(Band {
            zone: fields[0].to_owned(),
            max_grams,
            cents,
        });
    }
    Ok(bands)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::io::Write;
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn with_card(contents: &str, parcel: Parcel) -> Result<Quote, QuoteError> {
        let _guard = ENV_LOCK.lock().unwrap();
        let path = env::temp_dir().join(format!("ratecard-test-{}", std::process::id()));
        let mut file = fs::File::create(&path).unwrap();
        file.write_all(contents.as_bytes()).unwrap();
        env::set_var("RATECARD_PATH", &path);
        let result = quote(&parcel);
        env::remove_var("RATECARD_PATH");
        fs::remove_file(path).unwrap();
        result
    }

    #[test]
    fn selects_the_first_matching_band() {
        let quote = with_card(
            "# comment\ndomestic\t500\t599\ndomestic\t2000\t899\n",
            Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            },
        )
        .unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
        assert_eq!(quote.total_cents, 899);
    }

    #[test]
    fn adds_weight_and_rounded_international_surcharges() {
        let quote = with_card(
            "international\t20000\t1499\n",
            Parcel {
                weight_grams: 10001,
                zone: "international".into(),
            },
        )
        .unwrap();
        assert_eq!(quote.surcharge_cents, 800);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn reports_unknown_zone_and_overweight() {
        let unknown = with_card(
            "domestic\t500\t599\n",
            Parcel {
                weight_grams: 1,
                zone: "rural".into(),
            },
        );
        assert_eq!(unknown, Err(QuoteError::UnknownZone("rural".into())));

        let overweight = with_card(
            "domestic\t500\t599\n",
            Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            },
        );
        assert_eq!(
            overweight,
            Err(QuoteError::Overweight {
                grams: 501,
                limit: 500
            })
        );
    }

    #[test]
    fn reports_malformed_lines_with_file_line_numbers() {
        let result = with_card(
            "# comment\n\ndomestic\tnope\t599\n",
            Parcel {
                weight_grams: 1,
                zone: "domestic".into(),
            },
        );
        assert_eq!(result, Err(QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn missing_path_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap();
        env::remove_var("RATECARD_PATH");
        assert_eq!(
            quote(&Parcel {
                weight_grams: 1,
                zone: "domestic".into()
            }),
            Err(QuoteError::RateCardUnavailable)
        );
    }
}
