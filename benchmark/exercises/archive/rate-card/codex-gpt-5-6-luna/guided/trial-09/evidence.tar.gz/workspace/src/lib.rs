use std::{env, fs};

pub mod zones;

/// A parcel to be priced against the configured rate card.
#[derive(Debug, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price calculated for a parcel.
#[derive(Debug, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// A failure encountered while loading or applying a rate card.
#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card on line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weight {grams}g exceeds band limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug, PartialEq, Eq)]
struct Band {
    zone: String,
    max_grams: u32,
    cents: u64,
}

/// Calculate a shipping quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let result = load_rate_card().and_then(|bands| calculate_quote(parcel, &bands));

    let total_cents = result.as_ref().ok().map(|calculated| calculated.total_cents);
    eprintln!(
        "{{\"event\":\"shipping_quote\",\"zone\":{:?},\"weight_grams\":{},\"total_cents\":{}}}",
        parcel.zone,
        parcel.weight_grams,
        total_cents.map_or_else(|| "null".to_owned(), |total| total.to_string())
    );
    result
}

fn load_rate_card() -> Result<Vec<Band>, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();
    for (index, raw_line) in contents.lines().enumerate() {
        let line = index + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = raw_line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line });
        }
        let max_grams =
            fields[1].parse::<u32>().map_err(|_| QuoteError::MalformedRateCard { line })?;
        let cents = fields[2].parse::<u64>().map_err(|_| QuoteError::MalformedRateCard { line })?;
        bands.push(Band {
            zone: fields[0].to_owned(),
            max_grams,
            cents,
        });
    }
    Ok(bands)
}

fn calculate_quote(parcel: &Parcel, bands: &[Band]) -> Result<Quote, QuoteError> {
    let mut zone_bands: Vec<&Band> = bands.iter().filter(|band| band.zone == parcel.zone).collect();
    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }
    zone_bands.sort_by_key(|band| band.max_grams);

    let band = match zone_bands.iter().find(|band| band.max_grams >= parcel.weight_grams).copied() {
        Some(band) => band,
        None => {
            let limit = zone_bands.last().map(|band| band.max_grams).unwrap_or_default();
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        (band.cents * 20 + 50) / 100
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;
    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    const CARD: &str = "# shipping rates\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\ninternational\t500\t1499\ninternational\t20000\t4999\n";

    #[test]
    fn parses_comments_and_sorts_bands() {
        let bands =
            parse_rate_card("domestic\t2000\t899\n\n# comment\ndomestic\t500\t599\n").unwrap();
        let quote = calculate_quote(
            &Parcel {
                weight_grams: 400,
                zone: "domestic".to_owned(),
            },
            &bands,
        )
        .unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn applies_both_surcharges() {
        let bands = parse_rate_card(CARD).unwrap();
        let quote = calculate_quote(
            &Parcel {
                weight_grams: 15_000,
                zone: "international".to_owned(),
            },
            &bands,
        )
        .unwrap();
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn reports_unknown_zone_and_overweight() {
        let bands = parse_rate_card(CARD).unwrap();
        assert_eq!(
            calculate_quote(
                &Parcel {
                    weight_grams: 1,
                    zone: "moon".to_owned(),
                },
                &bands,
            ),
            Err(QuoteError::UnknownZone("moon".to_owned()))
        );
        assert_eq!(
            calculate_quote(
                &Parcel {
                    weight_grams: 20_001,
                    zone: "international".to_owned(),
                },
                &bands,
            ),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            })
        );
    }

    #[test]
    fn rejects_malformed_lines_with_physical_line_number() {
        assert_eq!(
            parse_rate_card("# comment\n\ndomestic\tnope\t599\n"),
            Err(QuoteError::MalformedRateCard { line: 3 })
        );
        assert_eq!(
            parse_rate_card("domestic\t500\t599\textra\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }
}
