//! Shipping rate-card quote calculation.

pub mod zones;

/// A parcel whose shipping price should be calculated.
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Rate-card zone used for pricing.
    pub zone: String,
}

/// The calculated shipping price and the band that produced it.
#[derive(Debug, PartialEq, Eq)]
pub struct Quote {
    /// Price of the matching rate-card band, in cents.
    pub base_cents: u64,
    /// Sum of all applicable surcharges, in cents.
    pub surcharge_cents: u64,
    /// Base price plus surcharges, in cents.
    pub total_cents: u64,
    /// Maximum weight of the matching rate-card band, in grams.
    pub band_max_grams: u32,
}

/// Errors that can occur while loading or applying a rate card.
#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    /// The configured rate-card path was missing or could not be read.
    RateCardUnavailable,
    /// A non-comment, non-blank rate-card line could not be parsed.
    MalformedRateCard { line: usize },
    /// The parcel's zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel is heavier than every band in its zone.
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown rate-card zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighs {grams} grams, over {limit}-gram limit")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Calculates a quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = std::fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = zones::parse_rate_card(&contents)?;
    let quote = zones::calculate_quote(&card, parcel)?;

    eprintln!(
        "diagnostic=shipping_quote_calculated zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, quote.total_cents
    );
    Ok(quote)
}
