use crate::{Parcel, Quote, QuoteError};

#[derive(Debug)]
pub(crate) struct Band {
    max_grams: u32,
    cents: u64,
}

#[derive(Debug)]
pub(crate) struct RateCard {
    zones: std::collections::BTreeMap<String, Vec<Band>>,
}

pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}

pub(crate) fn parse_rate_card(contents: &str) -> Result<RateCard, QuoteError> {
    let mut zones = std::collections::BTreeMap::<String, Vec<Band>>::new();

    for (line_index, line) in contents.lines().enumerate() {
        let line_number = line_index + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let max_grams = fields[1]
            .trim()
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .trim()
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        zones
            .entry(fields[0].trim().to_owned())
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }
    Ok(RateCard { zones })
}

pub(crate) fn calculate_quote(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = card
        .zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let last = bands.last().ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band = bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: last.max_grams,
        },
    )?;

    let mut surcharge_cents = u64::from(parcel.weight_grams > 10_000) * 500;
    if parcel.zone == "international" {
        // 20% is one fifth; doing the division this way avoids multiplying
        // a potentially large rate by 20 before rounding half-up.
        surcharge_cents += band.cents / 5 + u64::from(band.cents % 5 >= 3);
    }

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    const CARD: &str =
        "# comment\ndomestic\t500\t599\ndomestic\t2000\t899\ninternational\t20000\t4999\n";

    #[test]
    fn parses_and_sorts_bands() {
        let card = parse_rate_card("domestic\t2000\t899\ndomestic\t500\t599").unwrap();
        assert_eq!(card.zones["domestic"][0].max_grams, 500);
    }

    #[test]
    fn calculates_international_and_weight_surcharges() {
        let card = parse_rate_card(CARD).unwrap();
        let result = calculate_quote(
            &card,
            &Parcel {
                weight_grams: 15_000,
                zone: "international".to_owned(),
            },
        )
        .unwrap();
        assert_eq!(result.base_cents, 4999);
        assert_eq!(result.surcharge_cents, 1500);
        assert_eq!(result.total_cents, 6499);
    }

    #[test]
    fn reports_malformed_line_number_and_domain_errors() {
        assert_eq!(
            parse_rate_card("# one\n\ndomestic\tbad\t599").unwrap_err(),
            QuoteError::MalformedRateCard { line: 3 }
        );
        let card = parse_rate_card(CARD).unwrap();
        let parcel = Parcel {
            weight_grams: 1,
            zone: "moon".to_owned(),
        };
        assert_eq!(
            calculate_quote(&card, &parcel).unwrap_err(),
            QuoteError::UnknownZone("moon".to_owned())
        );
    }
}
