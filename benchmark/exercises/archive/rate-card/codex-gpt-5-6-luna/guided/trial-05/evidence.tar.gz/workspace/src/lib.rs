use std::{env, fs};

pub mod zones;

/// A parcel to price against the configured rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Rate-card zone name.
    pub zone: String,
}

/// The price calculated for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Price of the matching rate-card band, in cents.
    pub base_cents: u64,
    /// Sum of all applicable surcharges, in cents.
    pub surcharge_cents: u64,
    /// Total price, in cents.
    pub total_cents: u64,
    /// Maximum weight of the matching band, in grams.
    pub band_max_grams: u32,
}

/// Errors encountered while loading or applying the rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The `RATECARD_PATH` variable is missing or its file cannot be read.
    RateCardUnavailable,
    /// A rate-card line is not valid, identified by its 1-based line number.
    MalformedRateCard { line: usize },
    /// The parcel's zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel exceeds the largest band for its zone.
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card on line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown rate-card zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighs {grams} grams, over the {limit}-gram limit")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    zone: String,
    max_grams: u32,
    cents: u64,
}

/// Calculate a shipping quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let result = quote_from_rate_card(parcel);
    let total_cents = result
        .as_ref()
        .map_or_else(|_| "unavailable".to_owned(), |quote| quote.total_cents.to_string());
    eprintln!(
        "quote zone={} weight_grams={} total_cents={total_cents}",
        parcel.zone, parcel.weight_grams
    );
    result
}

fn quote_from_rate_card(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = parse_rate_card(&contents)?;
    let mut zone_bands: Vec<&Band> = bands.iter().filter(|band| band.zone == parcel.zone).collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }
    zone_bands.sort_by_key(|band| band.max_grams);

    let band = zone_bands
        .iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .copied()
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: zone_bands.last().map_or(0, |band| band.max_grams),
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        (band.cents * 20 + 50) / 100
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;
    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

fn parse_rate_card(contents: &str) -> Result<Vec<Band>, QuoteError> {
    contents
        .lines()
        .enumerate()
        .filter(|(_, line)| !line.is_empty() && !line.starts_with('#'))
        .map(|(index, line)| {
            let fields: Vec<&str> = line.split('\t').collect();
            if fields.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: index + 1 });
            }
            let max_grams = fields[1]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
            let cents = fields[2]
                .parse()
                .map_err(|_| QuoteError::MalformedRateCard { line: index + 1 })?;
            Ok(Band {
                zone: fields[0].to_owned(),
                max_grams,
                cents,
            })
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn with_card(contents: &str, parcel: Parcel) -> Result<Quote, QuoteError> {
        let _guard = ENV_LOCK.lock().unwrap();
        let path = std::env::temp_dir().join(format!(
            "ratecard-test-{}-{}",
            std::process::id(),
            parcel.weight_grams
        ));
        fs::write(&path, contents).unwrap();
        std::env::set_var("RATECARD_PATH", &path);
        let result = quote(&parcel);
        std::env::remove_var("RATECARD_PATH");
        fs::remove_file(path).unwrap();
        result
    }

    #[test]
    fn selects_band_and_applies_international_surcharge() {
        let quote = with_card(
            "# comment\ninternational\t20000\t4999\ninternational\t500\t1499\n",
            Parcel {
                weight_grams: 500,
                zone: "international".into(),
            },
        )
        .unwrap();
        assert_eq!(
            quote,
            Quote {
                base_cents: 1499,
                surcharge_cents: 300,
                total_cents: 1799,
                band_max_grams: 500
            }
        );
    }

    #[test]
    fn adds_weight_surcharge_and_rounds_percent_half_up() {
        let quote = with_card(
            "international\t20000\t5001\n",
            Parcel {
                weight_grams: 10001,
                zone: "international".into(),
            },
        )
        .unwrap();
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6501);
    }

    #[test]
    fn reports_failures() {
        assert_eq!(
            with_card(
                "domestic\tbad\t599\n",
                Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                }
            ),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(
            with_card(
                "domestic\t500\t599\n",
                Parcel {
                    weight_grams: 1,
                    zone: "rural".into()
                }
            ),
            Err(QuoteError::UnknownZone("rural".into()))
        );
        assert_eq!(
            with_card(
                "domestic\t500\t599\n",
                Parcel {
                    weight_grams: 501,
                    zone: "domestic".into()
                }
            ),
            Err(QuoteError::Overweight {
                grams: 501,
                limit: 500
            })
        );
    }
}
