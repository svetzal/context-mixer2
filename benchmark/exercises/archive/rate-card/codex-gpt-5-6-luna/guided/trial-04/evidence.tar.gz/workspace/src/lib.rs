use std::{env, fs};

pub mod zones;

/// A parcel for which a shipping quote should be calculated.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Rate-card zone used to price the parcel.
    pub zone: String,
}

/// The calculated shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// The selected rate-card band's price.
    pub base_cents: u64,
    /// The sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// Base price plus surcharges.
    pub total_cents: u64,
    /// The maximum weight of the selected rate-card band.
    pub band_max_grams: u32,
}

/// A failure encountered while loading or applying a rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The configured rate-card path was absent or could not be read.
    RateCardUnavailable,
    /// A rate-card line did not contain valid tab-separated data.
    MalformedRateCard { line: usize },
    /// No rate-card bands exist for the requested zone.
    UnknownZone(String),
    /// The parcel exceeds the largest band for its zone.
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown rate-card zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighs {grams} grams, over the {limit}-gram limit")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculate a shipping quote using the rate card at `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = parse_rate_card(&contents)?;
    let quote = calculate_quote(parcel, &bands)?;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = quote.total_cents,
        "shipping quote calculated"
    );
    Ok(quote)
}

fn parse_rate_card(
    contents: &str,
) -> Result<std::collections::HashMap<String, Vec<Band>>, QuoteError> {
    let mut card = std::collections::HashMap::<String, Vec<Band>>::new();

    for (line_index, line) in contents.lines().enumerate() {
        let line_number = line_index + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        card.entry(fields[0].to_owned()).or_default().push(Band { max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_unstable_by_key(|band| band.max_grams);
    }
    Ok(card)
}

fn calculate_quote(
    parcel: &Parcel,
    card: &std::collections::HashMap<String, Vec<Band>>,
) -> Result<Quote, QuoteError> {
    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band =
        bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands.last().map_or(0, |band| band.max_grams),
            }
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        // Twenty percent is one fifth. Avoid multiplying first so the calculation
        // remains safe for every valid u64 rate, then round the remainder half-up.
        band.cents / 5 + u64::from(band.cents % 5 >= 3)
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn with_card(contents: &str, parcel: Parcel) -> Result<Quote, QuoteError> {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
        let mut file = NamedTempFile::new().expect("temporary rate card");
        file.write_all(contents.as_bytes()).expect("write rate card");
        let previous = env::var_os("RATECARD_PATH");
        env::set_var("RATECARD_PATH", file.path());
        let result = quote(&parcel);
        match previous {
            Some(value) => env::set_var("RATECARD_PATH", value),
            None => env::remove_var("RATECARD_PATH"),
        }
        result
    }

    #[test]
    fn selects_sorted_band_and_applies_surcharges() {
        let result = with_card(
            "international\t20000\t4999\ndomestic\t20000\t1799\ndomestic\t500\t599\n",
            Parcel {
                weight_grams: 15_000,
                zone: "domestic".into(),
            },
        )
        .expect("quote");
        assert_eq!(
            result,
            Quote {
                base_cents: 1799,
                surcharge_cents: 500,
                total_cents: 2299,
                band_max_grams: 20_000
            }
        );
    }

    #[test]
    fn rounds_international_surcharge_half_up() {
        let result = with_card(
            "international\t500\t5\n",
            Parcel {
                weight_grams: 1,
                zone: "international".into(),
            },
        )
        .expect("quote");
        assert_eq!(result.surcharge_cents, 1);
        assert_eq!(result.total_cents, 6);
    }

    #[test]
    fn reports_errors_and_line_numbers() {
        assert_eq!(
            with_card(
                "# comment\nwrong\tline\n",
                Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                }
            ),
            Err(QuoteError::MalformedRateCard { line: 2 })
        );
        assert_eq!(
            with_card(
                "domestic\t5\t10\n",
                Parcel {
                    weight_grams: 6,
                    zone: "domestic".into()
                }
            ),
            Err(QuoteError::Overweight { grams: 6, limit: 5 })
        );
        assert_eq!(
            with_card(
                "domestic\t5\t10\n",
                Parcel {
                    weight_grams: 1,
                    zone: "rural".into()
                }
            ),
            Err(QuoteError::UnknownZone("rural".into()))
        );
    }
}
