use std::{collections::HashMap, env, error::Error, fmt, fs, path::Path};

/// A parcel to price against the configured rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price and band selected for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Errors that can occur while loading or applying the rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(formatter, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown shipping zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighs {grams} grams, above the {limit} gram limit")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculate a shipping quote using the rate card named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let result = load_rate_card().and_then(|card| quote_from_card(parcel, &card));

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = ?result.as_ref().ok().map(|quote| quote.total_cents),
        "shipping quote calculated"
    );

    result
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents =
        fs::read_to_string(Path::new(&path)).map_err(|_| QuoteError::RateCardUnavailable)?;
    let mut card: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        card.entry(fields[0].to_owned()).or_default().push(Band { max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }
    Ok(card)
}

fn quote_from_card(
    parcel: &Parcel,
    card: &HashMap<String, Vec<Band>>,
) -> Result<Quote, QuoteError> {
    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let largest = bands.last().map(|band| band.max_grams).unwrap_or(0);
    let band = bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest,
        },
    )?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        band.cents / 5 + u64::from(band.cents % 5 >= 3)
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;
    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn with_card(contents: &str, parcel: Parcel) -> Result<Quote, QuoteError> {
        let _guard = ENV_LOCK.lock().unwrap();
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(contents.as_bytes()).unwrap();
        let previous = env::var_os("RATECARD_PATH");
        unsafe {
            env::set_var("RATECARD_PATH", file.path());
        }
        let result = quote(&parcel);
        match previous {
            Some(value) => unsafe { env::set_var("RATECARD_PATH", value) },
            None => unsafe { env::remove_var("RATECARD_PATH") },
        }
        result
    }

    #[test]
    fn selects_first_sufficient_band_and_weight_surcharge() {
        let result = with_card(
            "domestic\t500\t599\ndomestic\t20000\t1799\n",
            Parcel {
                weight_grams: 10_001,
                zone: "domestic".into(),
            },
        );
        assert_eq!(
            result.unwrap(),
            Quote {
                base_cents: 1799,
                surcharge_cents: 500,
                total_cents: 2299,
                band_max_grams: 20000
            }
        );
    }

    #[test]
    fn applies_half_up_international_surcharge() {
        let result = with_card(
            "international\t500\t1499\n",
            Parcel {
                weight_grams: 500,
                zone: "international".into(),
            },
        );
        assert_eq!(result.unwrap().surcharge_cents, 300);
    }

    #[test]
    fn reports_parse_line_numbers_and_unknown_or_overweight_zones() {
        assert_eq!(
            with_card(
                "# comment\n\ndomestic\tnope\t10\n",
                Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                }
            ),
            Err(QuoteError::MalformedRateCard { line: 3 })
        );
        assert_eq!(
            with_card(
                "domestic\t500\t10\n",
                Parcel {
                    weight_grams: 1,
                    zone: "remote".into()
                }
            ),
            Err(QuoteError::UnknownZone("remote".into()))
        );
        assert_eq!(
            with_card(
                "domestic\t500\t10\n",
                Parcel {
                    weight_grams: 501,
                    zone: "domestic".into()
                }
            ),
            Err(QuoteError::Overweight {
                grams: 501,
                limit: 500
            })
        );
    }
}
