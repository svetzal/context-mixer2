//! Shipping quotes calculated from an operator-maintained rate card.

use std::{env, fs};

/// A parcel to price.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Rate-card zone to use.
    pub zone: String,
}

/// The price calculated for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Price of the selected rate-card band, in cents.
    pub base_cents: u64,
    /// Sum of all applicable surcharges, in cents.
    pub surcharge_cents: u64,
    /// Base price plus surcharges, in cents.
    pub total_cents: u64,
    /// Weight threshold of the selected band.
    pub band_max_grams: u32,
}

/// Failures that can occur while calculating a quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate-card path was not configured or could not be read.
    RateCardUnavailable,
    /// A non-comment rate-card line was invalid.
    MalformedRateCard { line: usize },
    /// The requested zone has no bands.
    UnknownZone(String),
    /// The parcel exceeds the largest band for its zone.
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown rate-card zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighs {grams} grams, exceeding {limit} grams")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    zone: String,
    max_grams: u32,
    cents: u64,
}

/// Read the configured rate card and calculate a shipping quote.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = parse_rate_card(&contents)?;
    let result = calculate_quote(parcel, &bands);

    if let Ok(ref calculated) = result {
        eprintln!(
            "quote zone={} weight_grams={} total_cents={}",
            parcel.zone, parcel.weight_grams, calculated.total_cents
        );
    }

    result
}

fn parse_rate_card(contents: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();

    for (line_index, line) in contents.lines().enumerate() {
        let line_number = line_index + 1;
        if line.trim().is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        bands.push(Band {
            zone: fields[0].to_owned(),
            max_grams,
            cents,
        });
    }

    Ok(bands)
}

fn calculate_quote(parcel: &Parcel, bands: &[Band]) -> Result<Quote, QuoteError> {
    let mut zone_bands: Vec<_> = bands.iter().filter(|band| band.zone == parcel.zone).collect();
    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }
    zone_bands.sort_by_key(|band| band.max_grams);

    let band = zone_bands
        .iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: zone_bands.last().map_or(0, |band| band.max_grams),
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        // 20% is one fifth; adding two implements half-up rounding for cents.
        band.cents.saturating_add(2) / 5
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn with_rate_card(contents: &str, parcel: Parcel) -> Result<Quote, QuoteError> {
        let _guard = ENV_LOCK.lock().unwrap();
        let file = NamedTempFile::new().unwrap();
        fs::write(file.path(), contents).unwrap();
        unsafe { env::set_var("RATECARD_PATH", file.path()) };
        let result = quote(&parcel);
        unsafe { env::remove_var("RATECARD_PATH") };
        result
    }

    #[test]
    fn selects_first_ascending_band_and_adds_surcharges() {
        let quote = with_rate_card(
            "domestic\t2000\t899\ndomestic\t500\t599\n",
            Parcel {
                weight_grams: 1500,
                zone: "domestic".into(),
            },
        )
        .unwrap();
        assert_eq!(
            quote,
            Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2000
            }
        );
    }

    #[test]
    fn applies_international_and_heavy_surcharges_with_half_up_rounding() {
        let quote = with_rate_card(
            "international\t20000\t3\n",
            Parcel {
                weight_grams: 10001,
                zone: "international".into(),
            },
        )
        .unwrap();
        assert_eq!(quote.surcharge_cents, 501);
        assert_eq!(quote.total_cents, 504);
    }

    #[test]
    fn reports_errors_and_counts_physical_lines() {
        let error = with_rate_card(
            "# comment\n\ninvalid\n",
            Parcel {
                weight_grams: 1,
                zone: "domestic".into(),
            },
        )
        .unwrap_err();
        assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });

        let error = with_rate_card(
            "domestic\t10\t1\n",
            Parcel {
                weight_grams: 11,
                zone: "domestic".into(),
            },
        )
        .unwrap_err();
        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 11,
                limit: 10
            }
        );
    }
}
