use std::{env, error::Error, fmt, fs};

/// A parcel to price against the configured rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// The rate-card zone for the parcel.
    pub zone: String,
}

/// The price calculated for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// The selected rate-card price in cents.
    pub base_cents: u64,
    /// The sum of all applicable surcharges in cents.
    pub surcharge_cents: u64,
    /// The base price plus all surcharges in cents.
    pub total_cents: u64,
    /// The maximum weight of the selected rate band.
    pub band_max_grams: u32,
}

/// Errors that can occur while loading or applying the rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate-card path is missing, unset, or cannot be read.
    RateCardUnavailable,
    /// A rate-card line is not valid, including its 1-based line number.
    MalformedRateCard { line: usize },
    /// The parcel's zone does not occur in the rate card.
    UnknownZone(String),
    /// The parcel exceeds the largest band for its zone.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card on line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown rate-card zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighs {grams} grams, over the {limit}-gram limit")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

#[derive(Debug, Default)]
struct RateCard {
    zones: std::collections::HashMap<String, Vec<Band>>,
}

impl RateCard {
    fn parse(contents: &str) -> Result<Self, QuoteError> {
        let mut card = Self::default();

        for (line_index, line) in contents.lines().enumerate() {
            let line_number = line_index + 1;
            if line.is_empty() || line.starts_with('#') {
                continue;
            }

            let fields: Vec<_> = line.split('\t').collect();
            if fields.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: line_number });
            }

            let max_grams = fields[1]
                .parse::<u32>()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
            let cents = fields[2]
                .parse::<u64>()
                .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

            card.zones
                .entry(fields[0].to_owned())
                .or_default()
                .push(Band { max_grams, cents });
        }

        for bands in card.zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(card)
    }

    fn calculate(&self, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let bands = self
            .zones
            .get(&parcel.zone)
            .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
        let limit = bands.last().map_or(0, |band| band.max_grams);
        let band = bands.iter().find(|band| parcel.weight_grams <= band.max_grams);
        let band = band.ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

        let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
        let international_surcharge = if parcel.zone == "international" {
            (band.cents * 20 + 50) / 100
        } else {
            0
        };
        let surcharge_cents = weight_surcharge + international_surcharge;

        Ok(Quote {
            base_cents: band.cents,
            surcharge_cents,
            total_cents: band.cents + surcharge_cents,
            band_max_grams: band.max_grams,
        })
    }
}

/// Calculate a parcel's shipping quote from the rate card at `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let result = RateCard::parse(&contents)?.calculate(parcel)?;

    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = result.total_cents,
        "shipping quote calculated"
    );
    Ok(result)
}

pub mod zones;

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::{Mutex, OnceLock};
    use tempfile::NamedTempFile;

    static ENV_LOCK: OnceLock<Mutex<()>> = OnceLock::new();

    fn with_card(contents: &str, parcel: Parcel) -> Result<Quote, QuoteError> {
        let _guard = ENV_LOCK.get_or_init(|| Mutex::new(())).lock().unwrap();
        let mut file = NamedTempFile::new().unwrap();
        file.write_all(contents.as_bytes()).unwrap();
        std::env::set_var("RATECARD_PATH", file.path());
        quote(&parcel)
    }

    #[test]
    fn selects_first_sufficient_band_and_applies_surcharges() {
        let quote = with_card(
            "domestic\t500\t599\ndomestic\t20000\t1799\ninternational\t20000\t4999\n",
            Parcel {
                weight_grams: 15_000,
                zone: "domestic".into(),
            },
        )
        .unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20_000);
    }

    #[test]
    fn rounds_international_surcharge_half_up() {
        let quote = with_card(
            "international\t500\t1499\n",
            Parcel {
                weight_grams: 500,
                zone: "international".into(),
            },
        )
        .unwrap();
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn reports_unknown_zone_and_overweight() {
        assert_eq!(
            with_card(
                "domestic\t500\t599\n",
                Parcel {
                    weight_grams: 1,
                    zone: "mars".into()
                }
            ),
            Err(QuoteError::UnknownZone("mars".into()))
        );
        assert_eq!(
            with_card(
                "domestic\t500\t599\n",
                Parcel {
                    weight_grams: 501,
                    zone: "domestic".into()
                }
            ),
            Err(QuoteError::Overweight {
                grams: 501,
                limit: 500
            })
        );
    }

    #[test]
    fn reports_malformed_line_number() {
        assert_eq!(
            with_card(
                "# comment\n\ndomestic\tnope\t599\n",
                Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                }
            ),
            Err(QuoteError::MalformedRateCard { line: 3 })
        );
    }
}
