pub mod zones;

use std::{env, error::Error, fmt, fs};

/// A parcel to be priced by the rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Rate-card zone for the parcel.
    pub zone: String,
}

/// The price calculated for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Price from the matching rate-card band.
    pub base_cents: u64,
    /// Sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// Base price plus surcharges.
    pub total_cents: u64,
    /// Maximum weight of the matching band.
    pub band_max_grams: u32,
}

/// Errors encountered while loading or applying the rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The configured rate card could not be found or read.
    RateCardUnavailable,
    /// A non-comment, non-empty line has invalid rate-card syntax.
    MalformedRateCard { line: usize },
    /// The parcel's zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel exceeds the largest band for its zone.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card on line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown rate-card zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighs {grams} grams, exceeding {limit} grams")
            }
        }
    }
}

impl Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculate a parcel's shipping quote from the configured rate card.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = parse_rate_card(&contents)?;
    let zone_bands = bands
        .get(parcel.zone.as_str())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = zone_bands
        .iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: zone_bands.last().map_or(0, |band| band.max_grams),
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        (band.cents * 20 + 50) / 100
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;
    let result = Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    };

    eprintln!(
        "{{\"event\":\"shipping_quote\",\"zone\":{zone:?},\"weight_grams\":{},\"total_cents\":{}}}",
        parcel.weight_grams,
        result.total_cents,
        zone = parcel.zone
    );
    Ok(result)
}

fn parse_rate_card(
    contents: &str,
) -> Result<std::collections::BTreeMap<String, Vec<Band>>, QuoteError> {
    let mut bands = std::collections::BTreeMap::<String, Vec<Band>>::new();

    for (line_index, line) in contents.lines().enumerate() {
        let line_number = line_index + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        bands.entry(fields[0].to_owned()).or_default().push(Band { max_grams, cents });
    }

    for zone_bands in bands.values_mut() {
        zone_bands.sort_by_key(|band| band.max_grams);
    }
    Ok(bands)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::{Mutex, OnceLock};
    use tempfile::NamedTempFile;

    fn env_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    fn with_card(contents: &str, parcel: Parcel) -> Result<Quote, QuoteError> {
        let _guard = env_lock().lock().unwrap_or_else(|poisoned| poisoned.into_inner());
        let mut file = NamedTempFile::new().expect("temporary file");
        file.write_all(contents.as_bytes()).expect("write card");
        let old = env::var_os("RATECARD_PATH");
        // SAFETY: Tests serialize environment access with env_lock.
        unsafe { env::set_var("RATECARD_PATH", file.path()) };
        let result = quote(&parcel);
        match old {
            Some(value) => unsafe { env::set_var("RATECARD_PATH", value) },
            None => unsafe { env::remove_var("RATECARD_PATH") },
        }
        result
    }

    #[test]
    fn calculates_band_and_surcharges() {
        let quote = with_card(
            "# comment\ndomestic\t500\t599\ndomestic\t2000\t899\n\ninternational\t20000\t4999\n",
            Parcel {
                weight_grams: 15_000,
                zone: "international".into(),
            },
        )
        .expect("quote");
        assert_eq!(
            quote,
            Quote {
                base_cents: 4999,
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20_000
            }
        );
    }

    #[test]
    fn rounds_international_surcharge_half_up() {
        let quote = with_card(
            "international\t500\t3\n",
            Parcel {
                weight_grams: 1,
                zone: "international".into(),
            },
        )
        .expect("quote");
        assert_eq!(quote.surcharge_cents, 1);
    }

    #[test]
    fn reports_errors_and_physical_line_numbers() {
        assert_eq!(
            with_card(
                "# comment\nwrong\tline\n",
                Parcel {
                    weight_grams: 1,
                    zone: "domestic".into()
                }
            ),
            Err(QuoteError::MalformedRateCard { line: 2 })
        );
        assert_eq!(
            with_card(
                "domestic\t500\t599\n",
                Parcel {
                    weight_grams: 501,
                    zone: "domestic".into()
                }
            ),
            Err(QuoteError::Overweight {
                grams: 501,
                limit: 500
            })
        );
        assert_eq!(
            with_card(
                "domestic\t500\t599\n",
                Parcel {
                    weight_grams: 1,
                    zone: "remote".into()
                }
            ),
            Err(QuoteError::UnknownZone("remote".into()))
        );
    }
}
