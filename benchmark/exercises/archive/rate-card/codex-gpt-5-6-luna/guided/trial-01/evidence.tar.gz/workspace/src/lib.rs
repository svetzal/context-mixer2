//! Shipping quote calculation from an operator-maintained rate card.

use std::{collections::HashMap, env, fs};

pub mod zones;

/// A parcel to price.
#[derive(Debug, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Rate-card zone name.
    pub zone: String,
}

/// The price calculated for a parcel.
#[derive(Debug, PartialEq, Eq)]
pub struct Quote {
    /// Price of the selected band, in cents.
    pub base_cents: u64,
    /// Sum of all applicable surcharges, in cents.
    pub surcharge_cents: u64,
    /// Base price plus surcharges, in cents.
    pub total_cents: u64,
    /// Weight threshold of the selected band.
    pub band_max_grams: u32,
}

/// Errors encountered while loading a rate card or calculating a quote.
#[derive(Debug, PartialEq, Eq)]
pub enum QuoteError {
    /// The environment variable is absent or its file cannot be read.
    RateCardUnavailable,
    /// A non-comment rate-card line has an invalid shape or number.
    MalformedRateCard { line: usize },
    /// No rate bands exist for the requested zone.
    UnknownZone(String),
    /// The parcel exceeds the largest band for its zone.
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown rate-card zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighs {grams} grams, over the {limit}-gram limit")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// Calculate a quote using the file named by `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let result = load_rate_card().and_then(|bands| calculate_quote(parcel, &bands));
    let total_cents = result.as_ref().ok().map(|value| value.total_cents);
    eprintln!(
        "shipping_quote zone={:?} weight_grams={} total_cents={:?} success={}",
        parcel.zone,
        parcel.weight_grams,
        total_cents,
        result.is_ok()
    );
    result
}

fn load_rate_card() -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<HashMap<String, Vec<Band>>, QuoteError> {
    let mut card: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, raw_line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let line = raw_line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = raw_line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        card.entry(fields[0].to_owned()).or_default().push(Band { max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_unstable_by_key(|band| band.max_grams);
    }
    Ok(card)
}

fn calculate_quote(
    parcel: &Parcel,
    card: &HashMap<String, Vec<Band>>,
) -> Result<Quote, QuoteError> {
    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let Some(largest) = bands.last() else {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    };
    let band = bands.iter().find(|band| parcel.weight_grams <= band.max_grams).ok_or(
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest.max_grams,
        },
    )?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        // 20% is base / 5; a remainder of 3 or 4 rounds up half-up.
        (band.cents / 5) + u64::from(band.cents % 5 >= 3)
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;
    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    const CARD: &str = "# comment\ndomestic\t500\t599\ndomestic\t2000\t899\ndomestic\t20000\t1799\ninternational\t500\t1499\ninternational\t20000\t4999\n";

    #[test]
    fn selects_the_first_band_that_fits() {
        let card = parse_rate_card(CARD).unwrap();
        let result = calculate_quote(
            &Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            },
            &card,
        )
        .unwrap();
        assert_eq!(
            result,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500
            }
        );
    }

    #[test]
    fn applies_both_surcharges_and_rounds_international_price() {
        let card = parse_rate_card("international\t20000\t4999\n").unwrap();
        let result = calculate_quote(
            &Parcel {
                weight_grams: 10_001,
                zone: "international".into(),
            },
            &card,
        )
        .unwrap();
        assert_eq!(result.surcharge_cents, 1500);
        assert_eq!(result.total_cents, 6499);
    }

    #[test]
    fn reports_malformed_lines_using_physical_line_numbers() {
        assert_eq!(
            parse_rate_card("# header\n\ndomestic\tbad\t100\n"),
            Err(QuoteError::MalformedRateCard { line: 3 })
        );
    }

    #[test]
    fn reports_unknown_and_overweight() {
        let card = parse_rate_card("domestic\t500\t599\n").unwrap();
        assert_eq!(
            calculate_quote(
                &Parcel {
                    weight_grams: 1,
                    zone: "rural".into()
                },
                &card
            ),
            Err(QuoteError::UnknownZone("rural".into()))
        );
        assert_eq!(
            calculate_quote(
                &Parcel {
                    weight_grams: 501,
                    zone: "domestic".into()
                },
                &card
            ),
            Err(QuoteError::Overweight {
                grams: 501,
                limit: 500
            })
        );
    }
}
