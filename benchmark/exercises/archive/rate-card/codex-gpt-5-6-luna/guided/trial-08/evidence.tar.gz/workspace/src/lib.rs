use std::{env, fs};

use tracing::info;

mod rate_card;

/// A parcel for which a shipping quote is requested.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Rate-card zone for the parcel.
    pub zone: String,
}

/// The calculated shipping price for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Price from the matching rate-card band.
    pub base_cents: u64,
    /// Sum of all applicable surcharges.
    pub surcharge_cents: u64,
    /// Total price in cents.
    pub total_cents: u64,
    /// Maximum weight of the matching rate-card band.
    pub band_max_grams: u32,
}

/// Errors that can occur while loading a rate card or calculating a quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The configured rate-card path is missing or cannot be read.
    RateCardUnavailable,
    /// A rate-card line has an invalid shape or numeric value.
    MalformedRateCard { line: usize },
    /// The parcel's zone has no rate-card bands.
    UnknownZone(String),
    /// The parcel exceeds the largest band for its zone.
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::RateCardUnavailable => formatter.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(formatter, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(formatter, "unknown rate-card zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(formatter, "parcel weighs {grams} grams; rate-card limit is {limit}")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Calculates a shipping quote using the rate card at `RATECARD_PATH`.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let result = load_rate_card().and_then(|bands| calculate_quote(parcel, &bands));
    let total_cents = result.as_ref().ok().map(|calculated| calculated.total_cents);

    info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = ?total_cents,
        success = result.is_ok(),
        "shipping quote calculated"
    );

    result
}

fn load_rate_card() -> Result<Vec<rate_card::Band>, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    rate_card::parse(&contents)
}

fn calculate_quote(parcel: &Parcel, bands: &[rate_card::Band]) -> Result<Quote, QuoteError> {
    let zone_bands: Vec<_> = bands.iter().filter(|band| band.zone == parcel.zone).collect();
    let largest_band =
        zone_bands.last().ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band = zone_bands
        .iter()
        .find(|candidate| candidate.max_grams >= parcel.weight_grams)
        .copied()
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest_band.max_grams,
        })?;

    let weight_surcharge = u64::from(parcel.weight_grams > 10_000) * 500;
    let international_surcharge = if parcel.zone == "international" {
        band.cents / 5 + u64::from(band.cents % 5 >= 3)
    } else {
        0
    };
    let surcharge_cents = weight_surcharge + international_surcharge;

    Ok(Quote {
        base_cents: band.cents,
        surcharge_cents,
        total_cents: band.cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn calculates_band_and_surcharges() {
        let bands =
            rate_card::parse("international\t500\t1499\ninternational\t20000\t4999").unwrap();
        let quote = calculate_quote(
            &Parcel {
                weight_grams: 15_000,
                zone: "international".to_owned(),
            },
            &bands,
        )
        .unwrap();

        assert_eq!(
            quote,
            Quote {
                base_cents: 4999,
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20000
            }
        );
    }

    #[test]
    fn rounds_international_surcharge_half_up() {
        let bands = rate_card::parse("international\t500\t101").unwrap();
        let quote = calculate_quote(
            &Parcel {
                weight_grams: 500,
                zone: "international".into(),
            },
            &bands,
        )
        .unwrap();
        assert_eq!(quote.surcharge_cents, 20);
    }

    #[test]
    fn distinguishes_unknown_and_overweight_zones() {
        let bands = rate_card::parse("domestic\t500\t599").unwrap();
        assert_eq!(
            calculate_quote(
                &Parcel {
                    weight_grams: 1,
                    zone: "mars".into()
                },
                &bands
            ),
            Err(QuoteError::UnknownZone("mars".into()))
        );
        assert_eq!(
            calculate_quote(
                &Parcel {
                    weight_grams: 501,
                    zone: "domestic".into()
                },
                &bands
            ),
            Err(QuoteError::Overweight {
                grams: 501,
                limit: 500
            })
        );
    }
}
