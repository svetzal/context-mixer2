#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct Band {
    pub(crate) zone: String,
    pub(crate) max_grams: u32,
    pub(crate) cents: u64,
}

pub(crate) fn parse(contents: &str) -> Result<Vec<Band>, super::QuoteError> {
    let mut bands = Vec::new();

    for (line_index, line) in contents.lines().enumerate() {
        let line_number = line_index + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(super::QuoteError::MalformedRateCard { line: line_number });
        }

        let max_grams = fields[1]
            .parse::<u32>()
            .map_err(|_| super::QuoteError::MalformedRateCard { line: line_number })?;
        let cents = fields[2]
            .parse::<u64>()
            .map_err(|_| super::QuoteError::MalformedRateCard { line: line_number })?;
        bands.push(Band {
            zone: fields[0].to_owned(),
            max_grams,
            cents,
        });
    }

    bands.sort_by_key(|band| band.max_grams);
    Ok(bands)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ignores_comments_and_blank_lines_but_counts_them_for_errors() {
        let error = parse("# header\n\nzone\tbad\t100").unwrap_err();
        assert_eq!(error, super::super::QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn rejects_wrong_field_count() {
        assert_eq!(
            parse("domestic\t500").unwrap_err(),
            super::super::QuoteError::MalformedRateCard { line: 1 }
        );
    }
}
