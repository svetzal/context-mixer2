//! Every quote must be observable in operation.
//!
//! These tests capture what an operator's collector would see: one record per
//! call, carrying zone, weight, and total as queryable fields rather than
//! interpolated message text.

// Tests may abort on a broken fixture; library code may not.
#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

use std::collections::BTreeMap;
use std::fmt::Debug;
use std::sync::{Arc, Mutex};

use ratecard::gateway::InMemoryRateCard;
use ratecard::{quote_from, Parcel};
use tracing::field::{Field, Visit};
use tracing::span::{Attributes, Id};
use tracing::{Event, Subscriber};
use tracing_subscriber::layer::{Context, Layer};
use tracing_subscriber::prelude::*;
use tracing_subscriber::registry::LookupSpan;

const CARD: &str = "domestic\t500\t599\n\
                    international\t20000\t4999\n";

/// One captured record: its target name and its fields, as strings.
#[derive(Debug, Clone)]
struct Record {
    name: String,
    fields: BTreeMap<String, String>,
}

impl Record {
    fn field(&self, name: &str) -> Option<&str> {
        self.fields.get(name).map(String::as_str)
    }
}

/// Collects every event and span the crate emits.
#[derive(Debug, Clone, Default)]
struct Collector {
    events: Arc<Mutex<Vec<Record>>>,
    spans: Arc<Mutex<Vec<Record>>>,
}

impl Collector {
    fn events(&self) -> Vec<Record> {
        match self.events.lock() {
            Ok(events) => events.clone(),
            Err(poisoned) => poisoned.into_inner().clone(),
        }
    }

    fn spans(&self) -> Vec<Record> {
        match self.spans.lock() {
            Ok(spans) => spans.clone(),
            Err(poisoned) => poisoned.into_inner().clone(),
        }
    }
}

impl<S> Layer<S> for Collector
where
    S: Subscriber + for<'a> LookupSpan<'a>,
{
    fn on_new_span(&self, attributes: &Attributes<'_>, _id: &Id, _ctx: Context<'_, S>) {
        let mut fields = FieldCollector::default();
        attributes.record(&mut fields);

        let record = Record {
            name: attributes.metadata().name().to_owned(),
            fields: fields.0,
        };

        match self.spans.lock() {
            Ok(mut spans) => spans.push(record),
            Err(poisoned) => poisoned.into_inner().push(record),
        }
    }

    fn on_event(&self, event: &Event<'_>, _ctx: Context<'_, S>) {
        let mut fields = FieldCollector::default();
        event.record(&mut fields);

        let record = Record {
            name: event.metadata().name().to_owned(),
            fields: fields.0,
        };

        match self.events.lock() {
            Ok(mut events) => events.push(record),
            Err(poisoned) => poisoned.into_inner().push(record),
        }
    }
}

#[derive(Default)]
struct FieldCollector(BTreeMap<String, String>);

impl Visit for FieldCollector {
    fn record_debug(&mut self, field: &Field, value: &dyn Debug) {
        self.0.insert(field.name().to_owned(), format!("{value:?}"));
    }

    fn record_str(&mut self, field: &Field, value: &str) {
        self.0.insert(field.name().to_owned(), value.to_owned());
    }

    fn record_u64(&mut self, field: &Field, value: u64) {
        self.0.insert(field.name().to_owned(), value.to_string());
    }

    fn record_i64(&mut self, field: &Field, value: i64) {
        self.0.insert(field.name().to_owned(), value.to_string());
    }
}

/// Runs `body` with a collector installed, and returns what it captured.
fn observing(body: impl FnOnce()) -> Collector {
    let collector = Collector::default();
    let subscriber = tracing_subscriber::registry().with(collector.clone());

    tracing::subscriber::with_default(subscriber, body);

    collector
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_owned(),
    }
}

#[test]
fn a_priced_quote_records_zone_weight_and_total() {
    let collected = observing(|| {
        let _ = quote_from(&parcel(300, "domestic"), &InMemoryRateCard::new(CARD));
    });

    let priced: Vec<_> = collected
        .events()
        .into_iter()
        .filter(|event| event.field("outcome") == Some("priced"))
        .collect();

    let [record] = priced.as_slice() else {
        panic!("expected exactly one priced record, got {priced:?}");
    };

    assert_eq!(record.field("zone"), Some("domestic"));
    assert_eq!(record.field("weight_grams"), Some("300"));
    assert_eq!(record.field("total_cents"), Some("599"));
}

#[test]
fn the_recorded_total_includes_surcharges() {
    let collected = observing(|| {
        let _ = quote_from(
            &parcel(15_000, "international"),
            &InMemoryRateCard::new(CARD),
        );
    });

    let record = collected
        .events()
        .into_iter()
        .find(|event| event.field("outcome") == Some("priced"))
        .expect("a priced record");

    assert_eq!(record.field("zone"), Some("international"));
    assert_eq!(record.field("weight_grams"), Some("15000"));
    assert_eq!(record.field("base_cents"), Some("4999"));
    assert_eq!(record.field("surcharge_cents"), Some("1500"));
    assert_eq!(record.field("total_cents"), Some("6499"));
}

#[test]
fn every_call_records_exactly_once() {
    let collected = observing(|| {
        let card = InMemoryRateCard::new(CARD);
        let _ = quote_from(&parcel(100, "domestic"), &card);
        let _ = quote_from(&parcel(400, "domestic"), &card);
        let _ = quote_from(&parcel(100, "lunar"), &card);
    });

    let outcomes: Vec<_> = collected
        .events()
        .into_iter()
        .filter_map(|event| event.field("outcome").map(str::to_owned))
        .collect();

    assert_eq!(outcomes, vec!["priced", "priced", "rejected"]);
}

#[test]
fn a_rejection_records_its_reason_as_a_queryable_field() {
    let collected = observing(|| {
        let _ = quote_from(&parcel(100, "lunar"), &InMemoryRateCard::new(CARD));
    });

    let record = collected
        .events()
        .into_iter()
        .find(|event| event.field("outcome") == Some("rejected"))
        .expect("a rejection record");

    assert_eq!(record.field("zone"), Some("lunar"));
    assert_eq!(record.field("weight_grams"), Some("100"));
    assert_eq!(record.field("reason"), Some("unknown_zone"));
    assert_eq!(record.field("error"), Some("unknown zone: lunar"));
}

#[test]
fn records_correlate_with_a_span_by_identifier() {
    let collected = observing(|| {
        let card = InMemoryRateCard::new(CARD);
        let _ = quote_from(&parcel(100, "domestic"), &card);
        let _ = quote_from(&parcel(400, "domestic"), &card);
    });

    let spans: Vec<_> = collected
        .spans()
        .into_iter()
        .filter(|span| span.name == "ratecard.quote")
        .collect();
    assert_eq!(spans.len(), 2, "one span per call: {spans:?}");

    let span_ids: Vec<_> = spans
        .iter()
        .filter_map(|span| span.field("quote_id").map(str::to_owned))
        .collect();
    assert_eq!(span_ids.len(), 2);
    assert_ne!(span_ids.first(), span_ids.last(), "identifiers are distinct");

    let event_ids: Vec<_> = collected
        .events()
        .into_iter()
        .filter_map(|event| event.field("quote_id").map(str::to_owned))
        .collect();
    assert_eq!(event_ids, span_ids);
}

#[test]
fn the_span_carries_the_parcel_it_is_pricing() {
    let collected = observing(|| {
        let _ = quote_from(&parcel(750, "international"), &InMemoryRateCard::new(CARD));
    });

    let span = collected
        .spans()
        .into_iter()
        .find(|span| span.name == "ratecard.quote")
        .expect("a quote span");

    assert_eq!(span.field("zone"), Some("international"));
    assert_eq!(span.field("weight_grams"), Some("750"));
}
