//! Shipping quotes for the fulfilment service.
//!
//! [`quote`] prices a [`Parcel`] against the rate card named by the
//! `RATECARD_PATH` environment variable, which operations redeploys without a
//! code change.
//!
//! The rate card is tab-separated, one band per line; empty lines and lines
//! beginning with `#` are ignored:
//!
//! ```text
//! # zone	band_max_grams	cents
//! domestic	500	599
//! domestic	2000	899
//! international	500	1499
//! ```
//!
//! A parcel is priced by the lightest band that covers it. Surcharges add on
//! top: 500 cents for weight strictly above 10 kg, and 20% of the base price
//! (rounded half-up to the cent) for the `international` zone.
//!
//! Reading the card is the only side effect, and it sits behind
//! [`gateway::RateCardSource`], so the rules can be exercised without a
//! filesystem:
//!
//! ```
//! use ratecard::gateway::InMemoryRateCard;
//! use ratecard::{quote_from, Parcel};
//!
//! let card = InMemoryRateCard::new("international\t500\t1499\n");
//! let parcel = Parcel {
//!     weight_grams: 300,
//!     zone: "international".to_owned(),
//! };
//!
//! let quote = quote_from(&parcel, &card)?;
//!
//! assert_eq!(quote.base_cents, 1499);
//! assert_eq!(quote.surcharge_cents, 300); // 299.8, rounded half-up
//! assert_eq!(quote.total_cents, 1799);
//! assert_eq!(quote.band_max_grams, 500);
//! # Ok::<(), ratecard::QuoteError>(())
//! ```

// Tests may abort on a broken fixture; library code may not.
#![cfg_attr(test, allow(clippy::unwrap_used, clippy::expect_used, clippy::panic))]

mod error;
pub mod gateway;
mod pricing;
pub mod rate_card;
pub mod zones;

use std::sync::atomic::{AtomicU64, Ordering};

pub use error::QuoteError;

use gateway::{EnvFileRateCard, RateCardSource};
use rate_card::RateCard;

/// A parcel to be priced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// The parcel's weight, in grams.
    pub weight_grams: u32,
    /// The destination zone, as named in the rate card.
    pub zone: String,
}

/// What shipping a parcel costs.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quote {
    /// The matched band's price, before surcharges.
    pub base_cents: u64,
    /// Every surcharge that applied, added together.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// The matched band's weight threshold, in grams.
    pub band_max_grams: u32,
}

/// Prices `parcel` against the rate card named by `RATECARD_PATH`.
///
/// # Errors
///
/// - [`QuoteError::RateCardUnavailable`] when `RATECARD_PATH` is unset or the
///   file it names cannot be read.
/// - [`QuoteError::MalformedRateCard`] when a line of the card is not three
///   tab-separated fields, or its numbers do not parse.
/// - [`QuoteError::UnknownZone`] when the parcel's zone has no bands.
/// - [`QuoteError::Overweight`] when the parcel is heavier than its zone's
///   largest band.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_from(parcel, &EnvFileRateCard::default())
}

/// Prices `parcel` against a caller-supplied rate-card source.
///
/// [`quote`] is this function wired to the file named by `RATECARD_PATH`.
/// Tests can pass a [`gateway::InMemoryRateCard`] instead.
///
/// # Errors
///
/// The same failures as [`quote`].
pub fn quote_from<S>(parcel: &Parcel, source: &S) -> Result<Quote, QuoteError>
where
    S: RateCardSource + ?Sized,
{
    let quote_id = next_quote_id();
    let span = tracing::info_span!(
        "ratecard.quote",
        quote_id,
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
    );
    let _entered = span.enter();

    let result = price(parcel, source);
    record(quote_id, parcel, &result);
    result
}

/// The pure half: card text in, quote out.
fn price<S>(parcel: &Parcel, source: &S) -> Result<Quote, QuoteError>
where
    S: RateCardSource + ?Sized,
{
    let text = source.load().map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = RateCard::parse(&text)?;
    let band = card.band_for(&parcel.zone, parcel.weight_grams)?;

    Ok(pricing::price(band, &parcel.zone, parcel.weight_grams))
}

/// Emits the per-call diagnostic record.
///
/// Zone, weight, and outcome are queryable fields rather than interpolated
/// message text, and `quote_id` correlates the record with its span.
fn record(quote_id: u64, parcel: &Parcel, result: &Result<Quote, QuoteError>) {
    match result {
        Ok(quote) => tracing::info!(
            quote_id,
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            base_cents = quote.base_cents,
            surcharge_cents = quote.surcharge_cents,
            total_cents = quote.total_cents,
            band_max_grams = quote.band_max_grams,
            outcome = "priced",
            "parcel quoted"
        ),
        Err(error) => tracing::warn!(
            quote_id,
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            outcome = "rejected",
            reason = error_kind(error),
            error = %error,
            "parcel not quoted"
        ),
    }
}

/// A low-cardinality field for grouping rejections.
fn error_kind(error: &QuoteError) -> &'static str {
    match error {
        QuoteError::RateCardUnavailable => "rate_card_unavailable",
        QuoteError::MalformedRateCard { .. } => "malformed_rate_card",
        QuoteError::UnknownZone(_) => "unknown_zone",
        QuoteError::Overweight { .. } => "overweight",
    }
}

/// Per-process sequence number, so concurrent quotes stay distinguishable.
fn next_quote_id() -> u64 {
    static NEXT: AtomicU64 = AtomicU64::new(1);
    NEXT.fetch_add(1, Ordering::Relaxed)
}

#[cfg(test)]
mod tests {
    use super::{error_kind, quote_from, Parcel, Quote, QuoteError};
    use crate::gateway::InMemoryRateCard;

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
                        \n\
                        domestic\t500\t599\n\
                        domestic\t2000\t899\n\
                        domestic\t20000\t1799\n\
                        international\t500\t1499\n\
                        international\t20000\t4999\n";

    fn quote_for(weight_grams: u32, zone: &str) -> Result<Quote, QuoteError> {
        quote_from(
            &Parcel {
                weight_grams,
                zone: zone.to_owned(),
            },
            &InMemoryRateCard::new(CARD),
        )
    }

    #[test]
    fn prices_a_light_domestic_parcel_from_its_band() {
        assert_eq!(
            quote_for(100, "domestic"),
            Ok(Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            })
        );
    }

    #[test]
    fn a_heavy_international_parcel_pays_both_surcharges() {
        assert_eq!(
            quote_for(15_000, "international"),
            Ok(Quote {
                base_cents: 4999,
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20_000,
            })
        );
    }

    #[test]
    fn an_unavailable_card_is_reported_as_such() {
        assert_eq!(
            quote_from(
                &Parcel {
                    weight_grams: 100,
                    zone: "domestic".to_owned(),
                },
                &InMemoryRateCard::unavailable(),
            ),
            Err(QuoteError::RateCardUnavailable)
        );
    }

    #[test]
    fn a_malformed_card_names_the_offending_line() {
        assert_eq!(
            quote_from(
                &Parcel {
                    weight_grams: 100,
                    zone: "domestic".to_owned(),
                },
                &InMemoryRateCard::new("# header\ndomestic\t500\n"),
            ),
            Err(QuoteError::MalformedRateCard { line: 2 })
        );
    }

    #[test]
    fn an_unknown_zone_carries_the_requested_zone() {
        assert_eq!(
            quote_for(100, "lunar"),
            Err(QuoteError::UnknownZone("lunar".to_owned()))
        );
    }

    #[test]
    fn an_overweight_parcel_carries_the_zone_limit() {
        assert_eq!(
            quote_for(25_000, "domestic"),
            Err(QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000,
            })
        );
    }

    #[test]
    fn rejection_reasons_are_low_cardinality() {
        assert_eq!(
            error_kind(&QuoteError::UnknownZone("lunar".to_owned())),
            "unknown_zone"
        );
        assert_eq!(
            error_kind(&QuoteError::Overweight {
                grams: 1,
                limit: 0
            }),
            "overweight"
        );
    }
}
