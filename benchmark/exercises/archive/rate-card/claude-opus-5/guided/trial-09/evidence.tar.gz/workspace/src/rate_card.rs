//! The rate card itself: parsing its text and selecting a band.
//!
//! Everything in this module is pure. It takes the card as text — never a
//! path, a file handle, or an environment variable — so the pricing rules can
//! be exercised without touching a filesystem.

use crate::error::QuoteError;

/// One priced weight band within a zone.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Band {
    /// The zone this band prices.
    pub zone: String,
    /// The heaviest parcel this band covers, in grams.
    pub max_grams: u32,
    /// The band's base price, in cents.
    pub cents: u64,
}

/// A parsed rate card: every band, for every zone.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct RateCard {
    bands: Vec<Band>,
}

impl RateCard {
    /// Parses the tab-separated card text.
    ///
    /// Lines that are empty (or only whitespace) and lines beginning with `#`
    /// are ignored, but they still count towards the line numbers reported by
    /// [`QuoteError::MalformedRateCard`].
    ///
    /// # Errors
    ///
    /// Returns [`QuoteError::MalformedRateCard`] for the first line that is
    /// not three tab-separated fields or whose numbers do not parse.
    pub fn parse(text: &str) -> Result<Self, QuoteError> {
        let mut bands = Vec::new();

        for (index, raw) in text.lines().enumerate() {
            let line_number = index.saturating_add(1);
            let malformed = || QuoteError::MalformedRateCard { line: line_number };

            let line = raw.trim_end_matches('\r');
            if line.trim().is_empty() || line.trim_start().starts_with('#') {
                continue;
            }

            let mut fields = line.split('\t');
            let (Some(zone), Some(max_grams), Some(cents), None) =
                (fields.next(), fields.next(), fields.next(), fields.next())
            else {
                return Err(malformed());
            };

            bands.push(Band {
                zone: zone.trim().to_owned(),
                max_grams: max_grams.trim().parse().map_err(|_| malformed())?,
                cents: cents.trim().parse().map_err(|_| malformed())?,
            });
        }

        Ok(Self { bands })
    }

    /// Selects the band that prices `weight_grams` in `zone`.
    ///
    /// Bands apply in ascending `max_grams`, so the match is the lightest band
    /// that still covers the parcel. The card's own line order does not matter.
    ///
    /// # Errors
    ///
    /// Returns [`QuoteError::UnknownZone`] when the zone has no bands at all,
    /// and [`QuoteError::Overweight`] when it has bands but none reach the
    /// parcel's weight.
    pub fn band_for(&self, zone: &str, weight_grams: u32) -> Result<&Band, QuoteError> {
        let mut matched: Option<&Band> = None;
        let mut heaviest: Option<u32> = None;

        for band in self.bands.iter().filter(|band| band.zone == zone) {
            heaviest = Some(heaviest.map_or(band.max_grams, |seen| seen.max(band.max_grams)));

            if band.max_grams >= weight_grams {
                matched = Some(match matched {
                    Some(current) if current.max_grams <= band.max_grams => current,
                    _ => band,
                });
            }
        }

        match (matched, heaviest) {
            (Some(band), _) => Ok(band),
            (None, Some(limit)) => Err(QuoteError::Overweight {
                grams: weight_grams,
                limit,
            }),
            (None, None) => Err(QuoteError::UnknownZone(zone.to_owned())),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::{Band, RateCard};
    use crate::error::QuoteError;

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
                          domestic\t500\t599\n\
                          domestic\t2000\t899\n\
                          domestic\t20000\t1799\n\
                          international\t500\t1499\n\
                          international\t20000\t4999\n";

    fn sample() -> RateCard {
        match RateCard::parse(SAMPLE) {
            Ok(card) => card,
            Err(error) => panic!("sample card should parse: {error}"),
        }
    }

    #[test]
    fn ignores_comments_and_blank_lines() {
        let card = match RateCard::parse("# header\n\n   \ndomestic\t500\t599\n") {
            Ok(card) => card,
            Err(error) => panic!("should parse: {error}"),
        };

        assert_eq!(
            card.band_for("domestic", 100),
            Ok(&Band {
                zone: "domestic".to_owned(),
                max_grams: 500,
                cents: 599,
            })
        );
    }

    #[test]
    fn counts_every_line_when_reporting_a_malformed_one() {
        let text = "# header\n\ndomestic\t500\t599\ndomestic\t2000\n";

        assert_eq!(
            RateCard::parse(text),
            Err(QuoteError::MalformedRateCard { line: 4 })
        );
    }

    #[test]
    fn rejects_a_line_with_too_many_fields() {
        assert_eq!(
            RateCard::parse("domestic\t500\t599\textra\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn rejects_an_unparseable_weight() {
        assert_eq!(
            RateCard::parse("domestic\theavy\t599\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn rejects_an_unparseable_price() {
        assert_eq!(
            RateCard::parse("domestic\t500\tfree\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn rejects_a_negative_price() {
        assert_eq!(
            RateCard::parse("domestic\t500\t-1\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn reports_the_first_malformed_line_in_any_zone() {
        let text = "international\t500\n domestic\t500\t599\n";

        assert_eq!(
            RateCard::parse(text),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn matches_the_lightest_band_that_covers_the_parcel() {
        let card = sample();

        assert_eq!(card.band_for("domestic", 501).map(|band| band.max_grams), Ok(2000));
        assert_eq!(card.band_for("domestic", 2000).map(|band| band.max_grams), Ok(2000));
        assert_eq!(card.band_for("domestic", 2001).map(|band| band.max_grams), Ok(20_000));
    }

    #[test]
    fn treats_the_band_threshold_as_inclusive() {
        let card = sample();

        assert_eq!(card.band_for("domestic", 500).map(|band| band.cents), Ok(599));
    }

    #[test]
    fn orders_bands_by_weight_not_by_file_order() {
        let card = match RateCard::parse("domestic\t20000\t1799\ndomestic\t500\t599\n") {
            Ok(card) => card,
            Err(error) => panic!("should parse: {error}"),
        };

        assert_eq!(card.band_for("domestic", 100).map(|band| band.cents), Ok(599));
    }

    #[test]
    fn an_absent_zone_is_unknown() {
        assert_eq!(
            sample().band_for("lunar", 100),
            Err(QuoteError::UnknownZone("lunar".to_owned()))
        );
    }

    #[test]
    fn a_zone_is_matched_exactly() {
        assert_eq!(
            sample().band_for("Domestic", 100),
            Err(QuoteError::UnknownZone("Domestic".to_owned()))
        );
    }

    #[test]
    fn a_parcel_beyond_the_largest_band_is_overweight() {
        assert_eq!(
            sample().band_for("domestic", 20_001),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            })
        );
    }

    #[test]
    fn the_overweight_limit_is_that_zones_largest_band() {
        let card = match RateCard::parse("regional\t500\t599\ndomestic\t20000\t1799\n") {
            Ok(card) => card,
            Err(error) => panic!("should parse: {error}"),
        };

        assert_eq!(
            card.band_for("regional", 900),
            Err(QuoteError::Overweight {
                grams: 900,
                limit: 500,
            })
        );
    }

    #[test]
    fn an_empty_card_knows_no_zones() {
        assert_eq!(
            RateCard::default().band_for("domestic", 100),
            Err(QuoteError::UnknownZone("domestic".to_owned()))
        );
    }

    #[test]
    fn tolerates_carriage_returns() {
        let card = match RateCard::parse("domestic\t500\t599\r\n") {
            Ok(card) => card,
            Err(error) => panic!("should parse: {error}"),
        };

        assert_eq!(card.band_for("domestic", 100).map(|band| band.cents), Ok(599));
    }
}
