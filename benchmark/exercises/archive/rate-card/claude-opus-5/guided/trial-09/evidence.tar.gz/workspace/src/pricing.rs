//! Turning a matched band into a priced quote.
//!
//! Pure arithmetic: no clock, no I/O, no configuration.

use crate::rate_card::Band;
use crate::Quote;

/// The zone that attracts the international surcharge.
const INTERNATIONAL_ZONE: &str = "international";

/// Parcels heavier than this attract the heavy surcharge.
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;

/// What a parcel over [`HEAVY_THRESHOLD_GRAMS`] adds, in cents.
const HEAVY_SURCHARGE_CENTS: u64 = 500;

/// Prices a parcel against the band that covers it.
///
/// Surcharges accumulate: the heavy surcharge is a flat amount, the
/// international surcharge is 20% of the base price rounded half-up to the
/// cent, and a parcel can attract both.
pub(crate) fn price(band: &Band, zone: &str, weight_grams: u32) -> Quote {
    let base_cents = band.cents;

    let heavy = if weight_grams > HEAVY_THRESHOLD_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    };

    let international = if zone == INTERNATIONAL_ZONE {
        one_fifth_rounded_half_up(base_cents)
    } else {
        0
    };

    let surcharge_cents = heavy.saturating_add(international);

    Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    }
}

/// 20% of `cents`, rounded half-up to the nearest cent.
///
/// Saturating rather than wrapping: a rate card with an absurd price should
/// still produce a number instead of aborting the caller.
fn one_fifth_rounded_half_up(cents: u64) -> u64 {
    cents.saturating_mul(2).saturating_add(5) / 10
}

#[cfg(test)]
mod tests {
    use super::{one_fifth_rounded_half_up, price};
    use crate::rate_card::Band;

    fn band(zone: &str, max_grams: u32, cents: u64) -> Band {
        Band {
            zone: zone.to_owned(),
            max_grams,
            cents,
        }
    }

    #[test]
    fn a_light_domestic_parcel_pays_only_the_base() {
        let quote = price(&band("domestic", 500, 599), "domestic", 100);

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn weight_above_ten_kilograms_adds_five_hundred_cents() {
        let quote = price(&band("domestic", 20_000, 1799), "domestic", 10_001);

        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn ten_kilograms_exactly_is_not_heavy() {
        let quote = price(&band("domestic", 20_000, 1799), "domestic", 10_000);

        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_a_fifth_of_the_base() {
        let quote = price(&band("international", 500, 1499), "international", 100);

        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn surcharges_accumulate() {
        let quote = price(&band("international", 20_000, 4999), "international", 15_000);

        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 500 + 1000);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn the_international_surcharge_rounds_half_up() {
        assert_eq!(one_fifth_rounded_half_up(1499), 300); // 299.8
        assert_eq!(one_fifth_rounded_half_up(100), 20); // exact
        assert_eq!(one_fifth_rounded_half_up(2), 0); // 0.4 down
        assert_eq!(one_fifth_rounded_half_up(3), 1); // 0.6 up
        assert_eq!(one_fifth_rounded_half_up(5), 1); // 1.0 exact
        assert_eq!(one_fifth_rounded_half_up(1225), 245); // 245.0 exact
        assert_eq!(one_fifth_rounded_half_up(1227), 245); // 245.4 down
        assert_eq!(one_fifth_rounded_half_up(1228), 246); // 245.6 up
    }

    #[test]
    fn an_absurd_base_price_saturates_instead_of_overflowing() {
        let quote = price(&band("international", 20_000, u64::MAX), "international", 15_000);

        assert_eq!(quote.total_cents, u64::MAX);
    }

    #[test]
    fn a_zone_that_is_not_international_pays_no_percentage() {
        let quote = price(&band("regional", 500, 1000), "regional", 100);

        assert_eq!(quote.surcharge_cents, 0);
    }
}
