//! Human-readable names for the zones the rate card prices.

/// The operator-facing label for `zone`.
///
/// Unrecognised zones are returned unchanged: the rate card, not this table,
/// decides which zones exist.
///
/// ```
/// assert_eq!(ratecard::zones::zone_label("domestic"), "Domestic ground");
/// assert_eq!(ratecard::zones::zone_label("lunar"), "lunar");
/// ```
#[must_use]
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}
