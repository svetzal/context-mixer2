//! The wiring `quote` actually ships: a real file, named by a real
//! `RATECARD_PATH`.
//!
//! The pricing rules themselves are covered by unit tests against an
//! in-memory card; what is verified here is that the environment variable,
//! the filesystem, and the rules meet correctly.

// Tests may abort on a broken fixture; library code may not.
#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

use std::io::Write;
use std::sync::{Mutex, MutexGuard, OnceLock};

use ratecard::{quote, Parcel, Quote, QuoteError};
use tempfile::{NamedTempFile, TempDir};

const CARD: &str = "# zone\tband_max_grams\tcents\n\
                    \n\
                    domestic\t500\t599\n\
                    domestic\t2000\t899\n\
                    domestic\t20000\t1799\n\
                    international\t500\t1499\n\
                    international\t20000\t4999\n";

/// `RATECARD_PATH` is process-wide state, so these tests take turns.
fn env_lock() -> MutexGuard<'static, ()> {
    static LOCK: OnceLock<Mutex<()>> = OnceLock::new();

    match LOCK.get_or_init(|| Mutex::new(())).lock() {
        Ok(guard) => guard,
        Err(poisoned) => poisoned.into_inner(),
    }
}

/// Runs `body` with `RATECARD_PATH` pointing at a file holding `card`.
fn with_card<T>(card: &str, body: impl FnOnce() -> T) -> T {
    let mut file = NamedTempFile::new().expect("temp file");
    file.write_all(card.as_bytes()).expect("write card");
    file.flush().expect("flush card");

    with_path(&file.path().display().to_string(), body)
}

/// Runs `body` with `RATECARD_PATH` set to `path`, restoring it afterwards.
fn with_path<T>(path: &str, body: impl FnOnce() -> T) -> T {
    let _guard = env_lock();
    let previous = std::env::var_os("RATECARD_PATH");

    std::env::set_var("RATECARD_PATH", path);
    let outcome = body();

    match previous {
        Some(value) => std::env::set_var("RATECARD_PATH", value),
        None => std::env::remove_var("RATECARD_PATH"),
    }

    outcome
}

/// Runs `body` with `RATECARD_PATH` unset, restoring it afterwards.
fn without_path<T>(body: impl FnOnce() -> T) -> T {
    let _guard = env_lock();
    let previous = std::env::var_os("RATECARD_PATH");

    std::env::remove_var("RATECARD_PATH");
    let outcome = body();

    if let Some(value) = previous {
        std::env::set_var("RATECARD_PATH", value);
    }

    outcome
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_owned(),
    }
}

#[test]
fn prices_a_parcel_from_the_deployed_card() {
    let quoted = with_card(CARD, || quote(&parcel(750, "domestic")));

    assert_eq!(
        quoted,
        Ok(Quote {
            base_cents: 899,
            surcharge_cents: 0,
            total_cents: 899,
            band_max_grams: 2000,
        })
    );
}

#[test]
fn applies_both_surcharges_end_to_end() {
    let quoted = with_card(CARD, || quote(&parcel(12_000, "international")));

    assert_eq!(
        quoted,
        Ok(Quote {
            base_cents: 4999,
            surcharge_cents: 1500,
            total_cents: 6499,
            band_max_grams: 20_000,
        })
    );
}

#[test]
fn a_redeployed_card_changes_the_price_without_a_code_change() {
    let first = with_card(CARD, || quote(&parcel(100, "domestic")));
    let second = with_card("domestic\t500\t650\n", || quote(&parcel(100, "domestic")));

    assert_eq!(first.map(|quote| quote.total_cents), Ok(599));
    assert_eq!(second.map(|quote| quote.total_cents), Ok(650));
}

#[test]
fn an_unset_path_is_unavailable() {
    let quoted = without_path(|| quote(&parcel(100, "domestic")));

    assert_eq!(quoted, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn a_missing_file_is_unavailable() {
    let directory = TempDir::new().expect("temp dir");
    let missing = directory.path().join("no-such-card.tsv");

    let quoted = with_path(&missing.display().to_string(), || {
        quote(&parcel(100, "domestic"))
    });

    assert_eq!(quoted, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn an_unreadable_path_is_unavailable() {
    // A directory is readable as a path but not as a file.
    let directory = TempDir::new().expect("temp dir");

    let quoted = with_path(&directory.path().display().to_string(), || {
        quote(&parcel(100, "domestic"))
    });

    assert_eq!(quoted, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn a_malformed_line_names_its_position_in_the_file() {
    let card = "# zone\tband_max_grams\tcents\n\
                \n\
                domestic\t500\t599\n\
                domestic\ttwo thousand\t899\n";

    let quoted = with_card(card, || quote(&parcel(100, "domestic")));

    assert_eq!(quoted, Err(QuoteError::MalformedRateCard { line: 4 }));
}

#[test]
fn an_unknown_zone_is_rejected() {
    let quoted = with_card(CARD, || quote(&parcel(100, "lunar")));

    assert_eq!(quoted, Err(QuoteError::UnknownZone("lunar".to_owned())));
}

#[test]
fn an_overweight_parcel_is_rejected_against_its_own_zone() {
    let quoted = with_card(CARD, || quote(&parcel(30_000, "international")));

    assert_eq!(
        quoted,
        Err(QuoteError::Overweight {
            grams: 30_000,
            limit: 20_000,
        })
    );
}

#[test]
fn errors_reach_callers_as_std_errors() {
    let quoted = with_card(CARD, || quote(&parcel(100, "lunar")));

    let error: Box<dyn std::error::Error> = match quoted {
        Ok(quote) => panic!("expected a rejection, got {quote:?}"),
        Err(error) => Box::new(error),
    };

    assert_eq!(error.to_string(), "unknown zone: lunar");
}
