# ratecard

Shipping quotes for the fulfilment service.

Warehouse operators price outbound parcels against a rate card that operations
maintains and redeploys without a code change. This crate owns reading that card
and turning a parcel into a quote.

## The rate card

`quote` reads the card from the file named by the `RATECARD_PATH` environment
variable, on every call, so operations can redeploy it without a code change.
It is tab-separated, one band per line; blank lines and lines beginning with
`#` are ignored:

```text
# zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
international	500	1499
```

A parcel is priced by the lightest band that covers it. Surcharges add on top:
500 cents for weight strictly above 10 kg, and 20% of the base price (rounded
half-up to the cent) for the `international` zone.

Reading the card is the crate's only side effect and sits behind the
`gateway::RateCardSource` trait; `gateway::InMemoryRateCard` prices against a
card held in memory, with no filesystem involved.

## Observability

Every call emits one `tracing` record — zone, weight, outcome, and either the
resulting total or the reason for rejection — inside a `ratecard.quote` span
that carries a `quote_id` for correlation.

## Development

```bash
cargo test
cargo clippy --all-targets
cargo doc --no-deps
```
