//! The failure modes a quote can report.

use std::fmt;

/// Why a quote could not be produced.
///
/// Every variant is recoverable by the caller: the rate card can be
/// redeployed, the zone corrected, or the parcel split.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` was unset, or the file it names could not be read.
    RateCardUnavailable,
    /// A rate-card line was not three tab-separated fields, or its numbers
    /// did not parse. `line` is 1-based and counts every line in the file,
    /// including comments and blanks.
    MalformedRateCard {
        /// 1-based number of the offending line.
        line: usize,
    },
    /// The requested zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight {
        /// The parcel's weight.
        grams: u32,
        /// The zone's largest `band_max_grams`.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => f.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel of {grams} g exceeds the zone limit of {limit} g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[cfg(test)]
mod tests {
    use super::QuoteError;

    #[test]
    fn display_names_the_offending_line() {
        assert_eq!(
            QuoteError::MalformedRateCard { line: 7 }.to_string(),
            "malformed rate card at line 7"
        );
    }

    #[test]
    fn display_carries_the_requested_zone() {
        assert_eq!(
            QuoteError::UnknownZone("lunar".to_owned()).to_string(),
            "unknown zone: lunar"
        );
    }

    #[test]
    fn display_reports_both_weight_and_limit() {
        assert_eq!(
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000
            }
            .to_string(),
            "parcel of 25000 g exceeds the zone limit of 20000 g"
        );
    }

    #[test]
    fn is_a_std_error() {
        fn assert_error<E: std::error::Error>(_: &E) {}
        assert_error(&QuoteError::RateCardUnavailable);
    }
}
