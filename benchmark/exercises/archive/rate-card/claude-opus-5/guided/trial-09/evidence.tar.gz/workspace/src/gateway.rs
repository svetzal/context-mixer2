//! The edge of the crate: where rate-card text comes from.
//!
//! Pricing depends on the [`RateCardSource`] contract, never on
//! [`std::fs`] or [`mod@std::env`] directly, so the rules can be exercised
//! against an in-memory card.

use std::fmt;
use std::path::PathBuf;

/// The environment variable naming the rate-card file.
pub const RATE_CARD_PATH_VAR: &str = "RATECARD_PATH";

/// The rate card could not be obtained.
///
/// Deliberately opaque: the reason a card is missing is an operational
/// detail, and callers of [`crate::quote`] see a single
/// [`crate::QuoteError::RateCardUnavailable`] either way. The cause is
/// reported through tracing instead.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct RateCardUnavailable;

impl fmt::Display for RateCardUnavailable {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("rate card could not be read")
    }
}

impl std::error::Error for RateCardUnavailable {}

/// Somewhere rate-card text can be read from.
pub trait RateCardSource {
    /// Reads the current rate card as text.
    ///
    /// # Errors
    ///
    /// Returns [`RateCardUnavailable`] when the card cannot be obtained,
    /// whether it is unconfigured, missing, or unreadable.
    fn load(&self) -> Result<String, RateCardUnavailable>;
}

/// Reads the card from the file named by an environment variable.
///
/// This is the adapter [`crate::quote`] uses. Operations redeploys the file
/// without a code change, so the path is resolved on every call rather than
/// cached.
#[derive(Debug, Clone)]
pub struct EnvFileRateCard {
    variable: String,
}

impl EnvFileRateCard {
    /// Reads the card from the file named by `variable`.
    #[must_use]
    pub fn new(variable: impl Into<String>) -> Self {
        Self {
            variable: variable.into(),
        }
    }
}

impl Default for EnvFileRateCard {
    /// Reads the card from the file named by `RATECARD_PATH`.
    fn default() -> Self {
        Self::new(RATE_CARD_PATH_VAR)
    }
}

impl RateCardSource for EnvFileRateCard {
    fn load(&self) -> Result<String, RateCardUnavailable> {
        let Some(path) = std::env::var_os(&self.variable) else {
            tracing::debug!(
                variable = %self.variable,
                reason = "unset",
                "rate card path is not configured"
            );
            return Err(RateCardUnavailable);
        };

        if path.is_empty() {
            tracing::debug!(
                variable = %self.variable,
                reason = "empty",
                "rate card path is not configured"
            );
            return Err(RateCardUnavailable);
        }

        let path = PathBuf::from(path);
        std::fs::read_to_string(&path).map_err(|error| {
            tracing::debug!(
                variable = %self.variable,
                path = %path.display(),
                reason = "unreadable",
                error = %error,
                "rate card could not be read"
            );
            RateCardUnavailable
        })
    }
}

/// A rate card held in memory, for tests and examples.
///
/// This is a fake, not a mock: it behaves like a real source, and code under
/// test cannot tell the difference.
#[derive(Debug, Clone, Default)]
pub struct InMemoryRateCard {
    text: Option<String>,
}

impl InMemoryRateCard {
    /// A source that yields `text`.
    #[must_use]
    pub fn new(text: impl Into<String>) -> Self {
        Self {
            text: Some(text.into()),
        }
    }

    /// A source that is unavailable, as an unset or unreadable path would be.
    #[must_use]
    pub fn unavailable() -> Self {
        Self { text: None }
    }
}

impl RateCardSource for InMemoryRateCard {
    fn load(&self) -> Result<String, RateCardUnavailable> {
        self.text.clone().ok_or(RateCardUnavailable)
    }
}

#[cfg(test)]
mod tests {
    use super::{EnvFileRateCard, InMemoryRateCard, RateCardSource, RateCardUnavailable};

    #[test]
    fn an_in_memory_card_yields_its_text() {
        assert_eq!(
            InMemoryRateCard::new("domestic\t500\t599").load(),
            Ok("domestic\t500\t599".to_owned())
        );
    }

    #[test]
    fn an_unavailable_in_memory_card_reports_it() {
        assert_eq!(
            InMemoryRateCard::unavailable().load(),
            Err(RateCardUnavailable)
        );
    }

    #[test]
    fn an_unset_variable_is_unavailable() {
        let source = EnvFileRateCard::new("RATECARD_PATH_DELIBERATELY_UNSET_FOR_TESTS");

        assert_eq!(source.load(), Err(RateCardUnavailable));
    }
}
