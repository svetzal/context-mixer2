//! The pricing rules. Pure: a rate card and a parcel in, a quote out.

use crate::card::RateCard;
use crate::error::QuoteError;
use crate::parcel::{Parcel, Quote};

/// Weight strictly above this attracts the heavy-parcel surcharge.
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
/// What the heavy-parcel surcharge costs.
const HEAVY_SURCHARGE_CENTS: u64 = 500;
/// The zone whose parcels attract the international uplift.
const INTERNATIONAL_ZONE: &str = "international";
/// The international uplift, as a percentage of the band price.
const INTERNATIONAL_UPLIFT_PERCENT: u64 = 20;

/// Prices `parcel` against `card`.
///
/// # Errors
///
/// [`QuoteError::UnknownZone`] when the card does not price the parcel's zone,
/// and [`QuoteError::Overweight`] when the parcel outweighs every band.
pub(crate) fn price(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let band = card.band_for(&parcel.zone, parcel.weight_grams)?;
    let base_cents = band.cents;

    let heavy = if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    };
    let uplift = if parcel.zone == INTERNATIONAL_ZONE {
        percent_of(base_cents, INTERNATIONAL_UPLIFT_PERCENT)
    } else {
        0
    };

    let surcharge_cents = heavy.saturating_add(uplift);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    })
}

/// `percent` percent of `amount`, rounded half-up to the whole cent.
fn percent_of(amount: u64, percent: u64) -> u64 {
    amount.saturating_mul(percent).saturating_add(50).saturating_div(100)
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::panic, reason = "tests assert outcomes")]
mod tests {
    use super::{percent_of, price};
    use crate::card::RateCard;
    use crate::error::QuoteError;
    use crate::parcel::Parcel;

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
        domestic\t500\t599\n\
        domestic\t2000\t899\n\
        domestic\t20000\t1799\n\
        international\t500\t1499\n\
        international\t20000\t4999\n";

    fn sample_card() -> RateCard {
        RateCard::parse(SAMPLE).unwrap()
    }

    #[test]
    fn a_light_domestic_parcel_pays_only_its_band() {
        let quote = price(&sample_card(), &Parcel::new(400, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn a_band_boundary_belongs_to_the_lower_band() {
        let quote = price(&sample_card(), &Parcel::new(500, "domestic")).unwrap();
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.base_cents, 599);
    }

    #[test]
    fn ten_kilograms_exactly_is_not_yet_heavy() {
        let quote = price(&sample_card(), &Parcel::new(10_000, "domestic")).unwrap();
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn above_ten_kilograms_adds_the_heavy_surcharge() {
        let quote = price(&sample_card(), &Parcel::new(10_001, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn international_adds_a_fifth_of_the_band_price() {
        let quote = price(&sample_card(), &Parcel::new(400, "international")).unwrap();
        assert_eq!(quote.base_cents, 1499);
        // 20% of 1499 is 299.8, rounded half-up to 300.
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn surcharges_add_together() {
        let quote = price(&sample_card(), &Parcel::new(15_000, "international")).unwrap();
        assert_eq!(quote.base_cents, 4999);
        // 20% of 4999 is 999.8 -> 1000, plus 500 for the weight.
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20_000);
    }

    #[test]
    fn an_unknown_zone_carries_what_was_asked_for() {
        assert_eq!(
            price(&sample_card(), &Parcel::new(100, "lunar")),
            Err(QuoteError::UnknownZone("lunar".to_string()))
        );
    }

    #[test]
    fn an_overweight_parcel_carries_the_zone_limit() {
        assert_eq!(
            price(&sample_card(), &Parcel::new(30_000, "international")),
            Err(QuoteError::Overweight {
                grams: 30_000,
                limit: 20_000
            })
        );
    }

    #[test]
    fn rounding_is_half_up() {
        // 20% of 5 is 1.0; of 3 is 0.6; of 2 is 0.4; of 13 is 2.6.
        assert_eq!(percent_of(5, 20), 1);
        assert_eq!(percent_of(3, 20), 1);
        assert_eq!(percent_of(2, 20), 0);
        assert_eq!(percent_of(13, 20), 3);
        // Exactly half a cent rounds up: 20% of 15 is 3.0, 20% of 1_00 is 20.
        assert_eq!(percent_of(15, 20), 3);
        assert_eq!(percent_of(100, 20), 20);
        // A true half: 50% of 5 is 2.5 -> 3.
        assert_eq!(percent_of(5, 50), 3);
    }
}
