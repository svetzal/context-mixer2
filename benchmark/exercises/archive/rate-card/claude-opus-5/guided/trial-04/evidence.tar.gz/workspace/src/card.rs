//! Turning rate card text into bands. Pure: no files, no environment.

use std::collections::BTreeMap;

use crate::error::QuoteError;

/// One priced weight band within a zone.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Band {
    /// The heaviest parcel this band covers, inclusive.
    pub max_grams: u32,
    /// The band's price before surcharges.
    pub cents: u64,
}

/// The bands operations published, indexed by zone.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

impl RateCard {
    /// Reads a tab-separated rate card.
    ///
    /// Empty lines and lines beginning with `#` are ignored. Every other line
    /// must be `zone`, `band_max_grams`, `cents` separated by tabs.
    ///
    /// # Errors
    ///
    /// [`QuoteError::MalformedRateCard`] for the first line that is not three
    /// tab-separated fields or whose numbers do not parse, carrying that line's
    /// 1-based number counted across the whole file.
    ///
    /// ```
    /// let card = ratecard::RateCard::parse("# zone\tmax\tcents\ndomestic\t500\t599\n")?;
    /// assert_eq!(card.zone_count(), 1);
    /// # Ok::<(), ratecard::QuoteError>(())
    /// ```
    pub fn parse(text: &str) -> Result<Self, QuoteError> {
        let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

        for (index, raw) in text.lines().enumerate() {
            let line_number = index + 1;
            let line = raw.strip_suffix('\r').unwrap_or(raw);
            let trimmed = line.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }

            let (zone, band) = parse_band(line, line_number)?;
            zones.entry(zone).or_default().push(band);
        }

        // Bands apply in ascending order regardless of how the file lists them.
        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(Self { zones })
    }

    /// How many zones the card prices.
    #[must_use]
    pub fn zone_count(&self) -> usize {
        self.zones.len()
    }

    /// The band that prices a parcel of `weight_grams` in `zone`: the first
    /// band, ascending, whose `max_grams` reaches the weight.
    ///
    /// # Errors
    ///
    /// [`QuoteError::UnknownZone`] when the card prices no bands for `zone`,
    /// and [`QuoteError::Overweight`] when the weight exceeds every band.
    pub fn band_for(&self, zone: &str, weight_grams: u32) -> Result<Band, QuoteError> {
        let bands = self
            .zones
            .get(zone)
            .filter(|bands| !bands.is_empty())
            .ok_or_else(|| QuoteError::UnknownZone(zone.to_string()))?;

        bands
            .iter()
            .find(|band| band.max_grams >= weight_grams)
            .copied()
            .ok_or_else(|| QuoteError::Overweight {
                grams: weight_grams,
                limit: bands.iter().map(|band| band.max_grams).max().unwrap_or(0),
            })
    }
}

/// Splits one non-blank, non-comment line into its zone and band.
fn parse_band(line: &str, line_number: usize) -> Result<(String, Band), QuoteError> {
    let malformed = || QuoteError::MalformedRateCard { line: line_number };

    let mut fields = line.split('\t');
    let (Some(zone), Some(max_grams), Some(cents), None) =
        (fields.next(), fields.next(), fields.next(), fields.next())
    else {
        return Err(malformed());
    };

    if zone.is_empty() {
        return Err(malformed());
    }

    let max_grams: u32 = max_grams.parse().map_err(|_| malformed())?;
    let cents: u64 = cents.parse().map_err(|_| malformed())?;

    Ok((zone.to_string(), Band { max_grams, cents }))
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::panic, reason = "tests assert outcomes")]
mod tests {
    use super::{Band, RateCard};
    use crate::error::QuoteError;

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
        domestic\t500\t599\n\
        domestic\t2000\t899\n\
        domestic\t20000\t1799\n\
        international\t500\t1499\n\
        international\t20000\t4999\n";

    #[test]
    fn skips_comments_and_blank_lines() {
        let card = RateCard::parse("# header\n\n\ndomestic\t500\t599\n\n").unwrap();
        assert_eq!(card.zone_count(), 1);
        assert_eq!(
            card.band_for("domestic", 10).unwrap(),
            Band {
                max_grams: 500,
                cents: 599
            }
        );
    }

    #[test]
    fn reads_every_zone_in_the_sample_card() {
        let card = RateCard::parse(SAMPLE).unwrap();
        assert_eq!(card.zone_count(), 2);
    }

    #[test]
    fn matches_the_first_band_that_reaches_the_weight() {
        let card = RateCard::parse(SAMPLE).unwrap();
        assert_eq!(card.band_for("domestic", 1).unwrap().cents, 599);
        assert_eq!(card.band_for("domestic", 500).unwrap().cents, 599);
        assert_eq!(card.band_for("domestic", 501).unwrap().cents, 899);
        assert_eq!(card.band_for("domestic", 2000).unwrap().cents, 899);
        assert_eq!(card.band_for("domestic", 2001).unwrap().max_grams, 20_000);
    }

    #[test]
    fn orders_bands_ascending_however_the_file_lists_them() {
        let card = RateCard::parse("domestic\t20000\t1799\ndomestic\t500\t599\n").unwrap();
        assert_eq!(card.band_for("domestic", 100).unwrap().cents, 599);
    }

    #[test]
    fn reports_an_absent_zone() {
        let card = RateCard::parse(SAMPLE).unwrap();
        assert_eq!(card.band_for("lunar", 100), Err(QuoteError::UnknownZone("lunar".to_string())));
    }

    #[test]
    fn reports_a_weight_beyond_the_largest_band() {
        let card = RateCard::parse(SAMPLE).unwrap();
        assert_eq!(
            card.band_for("domestic", 20_001),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            })
        );
    }

    #[test]
    fn counts_comments_and_blanks_when_numbering_a_malformed_line() {
        let text = "# header\n\ndomestic\t500\t599\ndomestic\theavy\t899\n";
        assert_eq!(RateCard::parse(text), Err(QuoteError::MalformedRateCard { line: 4 }));
    }

    #[test]
    fn rejects_lines_without_exactly_three_fields() {
        assert_eq!(
            RateCard::parse("domestic\t500\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(
            RateCard::parse("domestic\t500\t599\textra\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(
            RateCard::parse("domestic 500 599\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn rejects_unparsable_numbers() {
        assert_eq!(
            RateCard::parse("domestic\t-500\t599\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(
            RateCard::parse("domestic\t500\t5.99\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(
            RateCard::parse("domestic\t500\t\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn tolerates_windows_line_endings() {
        let card = RateCard::parse("# header\r\ndomestic\t500\t599\r\n").unwrap();
        assert_eq!(card.band_for("domestic", 100).unwrap().cents, 599);
    }

    #[test]
    fn an_empty_card_knows_no_zones() {
        let card = RateCard::parse("").unwrap();
        assert_eq!(
            card.band_for("domestic", 1),
            Err(QuoteError::UnknownZone("domestic".to_string()))
        );
    }
}
