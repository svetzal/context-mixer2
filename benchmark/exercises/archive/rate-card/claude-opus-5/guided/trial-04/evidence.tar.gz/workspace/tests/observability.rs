//! Every quote leaves a diagnostic record an operator can query.
//!
//! The recorder below is a project-owned fake subscriber: it implements the
//! `tracing` collector contract and keeps what was emitted, so these tests
//! assert on structured fields rather than on formatted log text.

#![allow(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::indexing_slicing
)]

use std::sync::{Arc, Mutex};

use ratecard::{quote_with, Parcel, StaticRateCardSource, UnavailableRateCardSource};
use tracing::field::{Field, Visit};
use tracing::span::{Attributes, Id, Record};
use tracing::{Event, Metadata, Subscriber};

const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
    domestic\t500\t599\n\
    domestic\t2000\t899\n\
    domestic\t20000\t1799\n\
    international\t500\t1499\n\
    international\t20000\t4999\n";

/// One recorded span or event: its name and its fields.
#[derive(Debug, Clone)]
struct Captured {
    name: String,
    fields: Vec<(String, String)>,
}

impl Captured {
    fn field(&self, name: &str) -> Option<&str> {
        self.fields.iter().find(|(key, _)| key == name).map(|(_, value)| value.as_str())
    }
}

#[derive(Default)]
struct Collected {
    spans: Vec<Captured>,
    events: Vec<Captured>,
}

/// A subscriber that keeps everything it is told.
#[derive(Clone, Default)]
struct Recorder {
    collected: Arc<Mutex<Collected>>,
}

impl Recorder {
    fn spans(&self) -> Vec<Captured> {
        self.collected.lock().expect("recorder lock").spans.clone()
    }

    fn events(&self) -> Vec<Captured> {
        self.collected.lock().expect("recorder lock").events.clone()
    }
}

/// Flattens field values into strings so tests can compare them.
#[derive(Default)]
struct Fields(Vec<(String, String)>);

impl Visit for Fields {
    fn record_debug(&mut self, field: &Field, value: &dyn std::fmt::Debug) {
        self.0.push((field.name().to_string(), format!("{value:?}")));
    }

    fn record_str(&mut self, field: &Field, value: &str) {
        self.0.push((field.name().to_string(), value.to_string()));
    }

    fn record_u64(&mut self, field: &Field, value: u64) {
        self.0.push((field.name().to_string(), value.to_string()));
    }

    fn record_i64(&mut self, field: &Field, value: i64) {
        self.0.push((field.name().to_string(), value.to_string()));
    }
}

impl Subscriber for Recorder {
    fn enabled(&self, _metadata: &Metadata<'_>) -> bool {
        true
    }

    fn new_span(&self, attributes: &Attributes<'_>) -> Id {
        let mut fields = Fields::default();
        attributes.record(&mut fields);

        let mut collected = self.collected.lock().expect("recorder lock");
        collected.spans.push(Captured {
            name: attributes.metadata().name().to_string(),
            fields: fields.0,
        });
        Id::from_u64(u64::try_from(collected.spans.len()).unwrap_or(1))
    }

    fn record(&self, span: &Id, values: &Record<'_>) {
        let mut fields = Fields::default();
        values.record(&mut fields);

        let mut collected = self.collected.lock().expect("recorder lock");
        let index = usize::try_from(span.into_u64()).unwrap_or(0).saturating_sub(1);
        if let Some(recorded) = collected.spans.get_mut(index) {
            recorded.fields.extend(fields.0);
        }
    }

    fn record_follows_from(&self, _span: &Id, _follows: &Id) {}

    fn event(&self, event: &Event<'_>) {
        let mut fields = Fields::default();
        event.record(&mut fields);

        self.collected.lock().expect("recorder lock").events.push(Captured {
            name: event.metadata().name().to_string(),
            fields: fields.0,
        });
    }

    fn enter(&self, _span: &Id) {}

    fn exit(&self, _span: &Id) {}
}

fn record_quote(body: impl FnOnce()) -> Recorder {
    let recorder = Recorder::default();
    tracing::subscriber::with_default(recorder.clone(), body);
    recorder
}

#[test]
fn a_priced_parcel_reports_zone_weight_and_total_as_queryable_fields() {
    let recorder = record_quote(|| {
        let source = StaticRateCardSource::new(SAMPLE);
        let priced = quote_with(&source, &Parcel::new(12_000, "international")).unwrap();
        assert_eq!(priced.total_cents, 6499);
    });

    let events = recorder.events();
    let event = events
        .iter()
        .find(|event| event.field("total_cents").is_some())
        .expect("a diagnostic record carrying the total");

    assert_eq!(event.field("zone"), Some("international"));
    assert_eq!(event.field("weight_grams"), Some("12000"));
    assert_eq!(event.field("total_cents"), Some("6499"));
    assert_eq!(event.field("base_cents"), Some("4999"));
    assert_eq!(event.field("surcharge_cents"), Some("1500"));
}

#[test]
fn each_call_opens_a_span_that_carries_its_outcome() {
    let recorder = record_quote(|| {
        let source = StaticRateCardSource::new(SAMPLE);
        quote_with(&source, &Parcel::new(400, "domestic")).unwrap();
    });

    let spans = recorder.spans();
    let span = spans.iter().find(|span| span.name == "quote").expect("a span per quote");

    assert_eq!(span.field("zone"), Some("domestic"));
    assert_eq!(span.field("weight_grams"), Some("400"));
    assert_eq!(span.field("total_cents"), Some("599"));
    assert_eq!(span.field("outcome"), Some("priced"));
}

#[test]
fn a_call_per_parcel_leaves_a_record_per_parcel() {
    let recorder = record_quote(|| {
        let source = StaticRateCardSource::new(SAMPLE);
        for weight in [100, 600, 3000] {
            quote_with(&source, &Parcel::new(weight, "domestic")).unwrap();
        }
    });

    let totals: Vec<_> = recorder
        .events()
        .iter()
        .filter_map(|event| event.field("total_cents").map(str::to_string))
        .collect();

    assert_eq!(totals, vec!["599", "899", "1799"]);
    assert_eq!(recorder.spans().len(), 3);
}

#[test]
fn a_rejected_parcel_is_recorded_with_its_reason() {
    let recorder = record_quote(|| {
        let outcome = quote_with(&UnavailableRateCardSource, &Parcel::new(100, "domestic"));
        assert!(outcome.is_err());
    });

    let events = recorder.events();
    let event = events
        .iter()
        .find(|event| event.field("error").is_some())
        .expect("a diagnostic record for the failure");

    assert_eq!(event.field("zone"), Some("domestic"));
    assert_eq!(event.field("weight_grams"), Some("100"));
    assert_eq!(event.field("error"), Some("the rate card is unavailable"));

    let spans = recorder.spans();
    let span = spans.iter().find(|span| span.name == "quote").expect("a span per quote");
    assert_eq!(span.field("outcome"), Some("rejected"));
}
