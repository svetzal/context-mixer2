# ratecard

Shipping quotes for the fulfilment service.

Warehouse operators price outbound parcels against a rate card that operations
maintains and redeploys without a code change. This crate owns reading that card
and turning a parcel into a quote.

## Using it

`quote` reads the tab-separated rate card named by the `RATECARD_PATH`
environment variable, afresh on every call, so a redeployed card takes effect
without a restart.

```rust
use ratecard::{quote, Parcel};

let priced = quote(&Parcel { weight_grams: 750, zone: "domestic".to_string() })?;
println!("{} cents", priced.total_cents);
```

Callers that already know where the card lives — tests, embedders — can pass a
[`RateCardSource`] to `quote_with` instead and keep the filesystem out of it.

Each call opens a `quote` tracing span and emits an event carrying the zone,
the weight in grams, and the total in cents as structured fields.

## Development

```bash
cargo test
cargo clippy --all-targets
cargo doc --no-deps
```

[`RateCardSource`]: src/source.rs
