//! Human-readable names for the zones the rate card prices.

/// The label warehouse staff see for `zone`, or the zone itself when it has no
/// established name.
///
/// ```
/// assert_eq!(ratecard::zones::zone_label("domestic"), "Domestic ground");
/// assert_eq!(ratecard::zones::zone_label("lunar"), "lunar");
/// ```
#[must_use]
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}
