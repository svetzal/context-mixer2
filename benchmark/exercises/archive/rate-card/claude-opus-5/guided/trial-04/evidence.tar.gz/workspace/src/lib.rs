//! Shipping quotes for the fulfilment service.
//!
//! Operations publishes a tab-separated rate card and redeploys it without a
//! code change; this crate reads that card and turns a [`Parcel`] into a
//! [`Quote`].
//!
//! ```
//! use ratecard::{Parcel, StaticRateCardSource, quote_with};
//!
//! let card = StaticRateCardSource::new(
//!     "# zone\tband_max_grams\tcents\n\
//!      domestic\t500\t599\n\
//!      domestic\t2000\t899\n",
//! );
//! let priced = quote_with(&card, &Parcel::new(750, "domestic"))?;
//!
//! assert_eq!(priced.base_cents, 899);
//! assert_eq!(priced.surcharge_cents, 0);
//! assert_eq!(priced.total_cents, 899);
//! assert_eq!(priced.band_max_grams, 2000);
//! # Ok::<(), ratecard::QuoteError>(())
//! ```
//!
//! [`quote`] is the same calculation reading the card named by
//! `RATECARD_PATH`.

mod card;
mod error;
mod parcel;
mod pricing;
mod source;

pub mod zones;

pub use card::{Band, RateCard};
pub use error::QuoteError;
pub use parcel::{Parcel, Quote};
pub use source::{
    EnvRateCardSource, FileRateCardSource, RateCardSource, StaticRateCardSource,
    UnavailableRateCardSource, RATECARD_PATH_VAR,
};

/// Prices a parcel against the rate card named by the `RATECARD_PATH`
/// environment variable.
///
/// The card is re-read on every call, so a redeployed card takes effect
/// immediately.
///
/// # Errors
///
/// - [`QuoteError::RateCardUnavailable`] if `RATECARD_PATH` is unset or the
///   file it names cannot be read.
/// - [`QuoteError::MalformedRateCard`] if a line is not three tab-separated
///   fields or its numbers do not parse.
/// - [`QuoteError::UnknownZone`] if the card prices no bands for the parcel's
///   zone.
/// - [`QuoteError::Overweight`] if the parcel outweighs the zone's largest
///   band.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_with(&EnvRateCardSource::new(), parcel)
}

/// Prices a parcel against a rate card from `source`.
///
/// This is [`quote`] with the card's whereabouts supplied by the caller, which
/// is what tests and embedders want.
///
/// # Errors
///
/// The same failures as [`quote`], with
/// [`QuoteError::RateCardUnavailable`] coming from `source`.
pub fn quote_with(
    source: &(impl RateCardSource + ?Sized),
    parcel: &Parcel,
) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "quote",
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = tracing::field::Empty,
        outcome = tracing::field::Empty,
    );
    let _entered = span.enter();

    let result = source
        .load()
        .and_then(|text| RateCard::parse(&text))
        .and_then(|card| pricing::price(&card, parcel));

    match &result {
        Ok(priced) => {
            span.record("total_cents", priced.total_cents);
            span.record("outcome", "priced");
            tracing::info!(
                zone = %parcel.zone,
                weight_grams = parcel.weight_grams,
                total_cents = priced.total_cents,
                base_cents = priced.base_cents,
                surcharge_cents = priced.surcharge_cents,
                band_max_grams = priced.band_max_grams,
                "parcel priced"
            );
        }
        Err(error) => {
            span.record("outcome", "rejected");
            tracing::warn!(
                zone = %parcel.zone,
                weight_grams = parcel.weight_grams,
                error = %error,
                "parcel not priced"
            );
        }
    }

    result
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::panic, reason = "tests assert outcomes")]
mod tests {
    use super::{quote_with, Parcel, QuoteError, StaticRateCardSource, UnavailableRateCardSource};

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
        domestic\t500\t599\n\
        domestic\t2000\t899\n\
        domestic\t20000\t1799\n\
        international\t500\t1499\n\
        international\t20000\t4999\n";

    #[test]
    fn prices_a_parcel_from_the_supplied_card() {
        let priced =
            quote_with(&StaticRateCardSource::new(SAMPLE), &Parcel::new(12_000, "international"))
                .unwrap();

        assert_eq!(priced.base_cents, 4999);
        assert_eq!(priced.surcharge_cents, 1500);
        assert_eq!(priced.total_cents, 6499);
        assert_eq!(priced.band_max_grams, 20_000);
    }

    #[test]
    fn passes_through_a_load_failure() {
        assert_eq!(
            quote_with(&UnavailableRateCardSource, &Parcel::new(100, "domestic")),
            Err(QuoteError::RateCardUnavailable)
        );
    }

    #[test]
    fn passes_through_a_parse_failure() {
        let source = StaticRateCardSource::new("# header\ndomestic\t500\n");
        assert_eq!(
            quote_with(&source, &Parcel::new(100, "domestic")),
            Err(QuoteError::MalformedRateCard { line: 2 })
        );
    }

    #[test]
    fn accepts_a_boxed_source() {
        let source: Box<dyn super::RateCardSource> = Box::new(StaticRateCardSource::new(SAMPLE));
        let priced = quote_with(source.as_ref(), &Parcel::new(100, "domestic")).unwrap();
        assert_eq!(priced.total_cents, 599);
    }
}
