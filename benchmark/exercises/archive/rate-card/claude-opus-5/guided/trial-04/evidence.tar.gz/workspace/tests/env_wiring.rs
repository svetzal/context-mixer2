//! `quote` reading the card named by `RATECARD_PATH`.
//!
//! These tests drive the real filesystem and the real environment, because
//! that wiring is exactly what they exist to check. The environment is
//! process-global, so every test here takes the same lock before touching it.

#![allow(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::indexing_slicing
)]

use std::io::Write;
use std::path::Path;
use std::sync::{Mutex, MutexGuard, OnceLock};

use ratecard::{quote, Parcel, QuoteError, RATECARD_PATH_VAR};
use tempfile::NamedTempFile;

const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
    domestic\t500\t599\n\
    domestic\t2000\t899\n\
    domestic\t20000\t1799\n\
    international\t500\t1499\n\
    international\t20000\t4999\n";

fn env_lock() -> MutexGuard<'static, ()> {
    static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    match LOCK.get_or_init(|| Mutex::new(())).lock() {
        Ok(guard) => guard,
        Err(poisoned) => poisoned.into_inner(),
    }
}

fn card_file(contents: &str) -> NamedTempFile {
    let mut file = NamedTempFile::new().expect("temp file");
    file.write_all(contents.as_bytes()).expect("write card");
    file.flush().expect("flush card");
    file
}

/// Runs `body` with `RATECARD_PATH` pointed at `path`, restoring the
/// environment afterwards.
fn with_ratecard_path<T>(path: Option<&Path>, body: impl FnOnce() -> T) -> T {
    let _guard = env_lock();
    let previous = std::env::var(RATECARD_PATH_VAR).ok();

    match path {
        Some(path) => std::env::set_var(RATECARD_PATH_VAR, path),
        None => std::env::remove_var(RATECARD_PATH_VAR),
    }

    let outcome = body();

    match previous {
        Some(value) => std::env::set_var(RATECARD_PATH_VAR, value),
        None => std::env::remove_var(RATECARD_PATH_VAR),
    }

    outcome
}

#[test]
fn prices_a_domestic_parcel_from_the_deployed_card() {
    let card = card_file(SAMPLE);
    let priced =
        with_ratecard_path(Some(card.path()), || quote(&Parcel::new(1500, "domestic".to_string())))
            .unwrap();

    assert_eq!(priced.base_cents, 899);
    assert_eq!(priced.surcharge_cents, 0);
    assert_eq!(priced.total_cents, 899);
    assert_eq!(priced.band_max_grams, 2000);
}

#[test]
fn applies_both_surcharges_to_a_heavy_international_parcel() {
    let card = card_file(SAMPLE);
    let priced = with_ratecard_path(Some(card.path()), || {
        quote(&Parcel {
            weight_grams: 18_000,
            zone: "international".to_string(),
        })
    })
    .unwrap();

    assert_eq!(priced.base_cents, 4999);
    assert_eq!(priced.surcharge_cents, 1500);
    assert_eq!(priced.total_cents, 6499);
    assert_eq!(priced.band_max_grams, 20_000);
}

#[test]
fn a_redeployed_card_takes_effect_on_the_next_call() {
    let original = card_file(SAMPLE);
    let discounted = card_file("domestic\t500\t399\n");
    let parcel = Parcel::new(100, "domestic");

    let before = with_ratecard_path(Some(original.path()), || quote(&parcel)).unwrap();
    let after = with_ratecard_path(Some(discounted.path()), || quote(&parcel)).unwrap();

    assert_eq!(before.total_cents, 599);
    assert_eq!(after.total_cents, 399);
}

#[test]
fn an_unset_path_is_unavailable() {
    let outcome = with_ratecard_path(None, || quote(&Parcel::new(100, "domestic")));
    assert_eq!(outcome, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn a_missing_file_is_unavailable() {
    let missing = Path::new("/nonexistent/directory/ratecard.tsv");
    let outcome = with_ratecard_path(Some(missing), || quote(&Parcel::new(100, "domestic")));
    assert_eq!(outcome, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn a_malformed_line_is_reported_by_its_position_in_the_file() {
    let card = card_file("# zone\tband_max_grams\tcents\n\ndomestic\t500\t599\ndomestic\t2000\n");
    let outcome = with_ratecard_path(Some(card.path()), || quote(&Parcel::new(100, "domestic")));
    assert_eq!(outcome, Err(QuoteError::MalformedRateCard { line: 4 }));
}

#[test]
fn an_absent_zone_is_reported_with_the_zone_asked_for() {
    let card = card_file(SAMPLE);
    let outcome = with_ratecard_path(Some(card.path()), || quote(&Parcel::new(100, "lunar")));
    assert_eq!(outcome, Err(QuoteError::UnknownZone("lunar".to_string())));
}

#[test]
fn too_heavy_for_the_zone_is_reported_with_its_limit() {
    let card = card_file(SAMPLE);
    let outcome = with_ratecard_path(Some(card.path()), || quote(&Parcel::new(25_000, "domestic")));
    assert_eq!(
        outcome,
        Err(QuoteError::Overweight {
            grams: 25_000,
            limit: 20_000
        })
    );
}

#[test]
fn errors_match_and_describe_themselves() {
    let card = card_file(SAMPLE);
    let outcome = with_ratecard_path(Some(card.path()), || quote(&Parcel::new(100, "lunar")));

    match outcome {
        Err(QuoteError::UnknownZone(zone)) => {
            assert_eq!(zone, "lunar");
            let as_error: &dyn std::error::Error = &QuoteError::UnknownZone(zone);
            assert_eq!(as_error.to_string(), "unknown zone `lunar`");
        }
        other => panic!("expected an unknown zone, got {other:?}"),
    }
}
