//! The edge between the pricing rules and wherever the rate card lives.
//!
//! Operations redeploy the card without a code change, so loading it is a
//! gateway: the rules depend on [`RateCardSource`], never on the filesystem or
//! the environment directly.

use std::path::{Path, PathBuf};

use crate::error::QuoteError;

/// The environment variable naming the rate card file.
pub const RATECARD_PATH_VAR: &str = "RATECARD_PATH";

/// Somewhere rate card text can be read from.
pub trait RateCardSource {
    /// Reads the current rate card text.
    ///
    /// # Errors
    ///
    /// [`QuoteError::RateCardUnavailable`] when the card cannot be read.
    fn load(&self) -> Result<String, QuoteError>;
}

/// Reads the rate card from a known path.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FileRateCardSource {
    path: PathBuf,
}

impl FileRateCardSource {
    /// Reads the card at `path`.
    #[must_use]
    pub fn new(path: impl Into<PathBuf>) -> Self {
        Self { path: path.into() }
    }

    /// The path this source reads.
    #[must_use]
    pub fn path(&self) -> &Path {
        &self.path
    }
}

impl RateCardSource for FileRateCardSource {
    fn load(&self) -> Result<String, QuoteError> {
        std::fs::read_to_string(&self.path).map_err(|error| {
            tracing::warn!(
                path = %self.path.display(),
                reason = %error,
                "rate card could not be read"
            );
            QuoteError::RateCardUnavailable
        })
    }
}

/// Reads the rate card from the path in [`RATECARD_PATH_VAR`].
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct EnvRateCardSource;

impl EnvRateCardSource {
    /// A source that resolves `RATECARD_PATH` afresh on every load, so a
    /// redeployed card is picked up without a restart.
    #[must_use]
    pub fn new() -> Self {
        Self
    }
}

impl RateCardSource for EnvRateCardSource {
    fn load(&self) -> Result<String, QuoteError> {
        let Ok(path) = std::env::var(RATECARD_PATH_VAR) else {
            tracing::warn!(
                variable = RATECARD_PATH_VAR,
                "rate card path is unset or not readable as text"
            );
            return Err(QuoteError::RateCardUnavailable);
        };

        FileRateCardSource::new(path).load()
    }
}

/// Rate card text held in memory, for tests and callers that already have the
/// card to hand.
///
/// ```
/// use ratecard::{RateCardSource, StaticRateCardSource};
///
/// let source = StaticRateCardSource::new("domestic\t500\t599\n");
/// assert_eq!(source.load()?, "domestic\t500\t599\n");
/// # Ok::<(), ratecard::QuoteError>(())
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct StaticRateCardSource {
    text: String,
}

impl StaticRateCardSource {
    /// Serves `text` as the rate card.
    #[must_use]
    pub fn new(text: impl Into<String>) -> Self {
        Self { text: text.into() }
    }
}

impl RateCardSource for StaticRateCardSource {
    fn load(&self) -> Result<String, QuoteError> {
        Ok(self.text.clone())
    }
}

/// A source that is always unavailable, for exercising the failure path.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct UnavailableRateCardSource;

impl RateCardSource for UnavailableRateCardSource {
    fn load(&self) -> Result<String, QuoteError> {
        Err(QuoteError::RateCardUnavailable)
    }
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::panic, reason = "tests assert outcomes")]
mod tests {
    use super::{
        FileRateCardSource, RateCardSource, StaticRateCardSource, UnavailableRateCardSource,
    };
    use crate::error::QuoteError;

    #[test]
    fn a_static_source_serves_its_text() {
        let source = StaticRateCardSource::new("domestic\t500\t599\n");
        assert_eq!(source.load().unwrap(), "domestic\t500\t599\n");
    }

    #[test]
    fn an_unavailable_source_reports_it() {
        assert_eq!(UnavailableRateCardSource.load(), Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn a_missing_file_is_unavailable() {
        let source = FileRateCardSource::new("/nonexistent/ratecard.tsv");
        assert_eq!(source.load(), Err(QuoteError::RateCardUnavailable));
    }
}
