//! What operators ask about, and what they get back.

/// A parcel awaiting a price.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Billable weight in grams.
    pub weight_grams: u32,
    /// The destination zone, as named in the rate card.
    pub zone: String,
}

impl Parcel {
    /// Convenience constructor for a parcel bound for `zone`.
    ///
    /// ```
    /// let parcel = ratecard::Parcel::new(750, "domestic");
    /// assert_eq!(parcel.weight_grams, 750);
    /// assert_eq!(parcel.zone, "domestic");
    /// ```
    #[must_use]
    pub fn new(weight_grams: u32, zone: impl Into<String>) -> Self {
        Self {
            weight_grams,
            zone: zone.into(),
        }
    }
}

/// The price of carrying a parcel, broken out so an invoice can explain itself.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quote {
    /// The matched band's price.
    pub base_cents: u64,
    /// Everything added on top of the band price.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// The upper weight bound of the band that priced this parcel.
    pub band_max_grams: u32,
}
