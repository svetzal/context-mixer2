//! The failure modes a quote can report to its caller.

use std::fmt;

/// Why a parcel could not be priced.
///
/// Every variant is recoverable: the caller decides whether an unreadable rate
/// card is fatal, whether an unknown zone is a user error, and so on.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, or the file it names is missing or unreadable.
    RateCardUnavailable,
    /// A rate card line is not three tab-separated fields, or its numbers do
    /// not parse. `line` is 1-based and counts every line in the file,
    /// including comments and blanks.
    MalformedRateCard {
        /// 1-based number of the offending line.
        line: usize,
    },
    /// The parcel's zone has no bands in the rate card. Carries the requested
    /// zone.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight {
        /// The parcel's weight.
        grams: u32,
        /// The largest `band_max_grams` the zone offers.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "the rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone `{zone}`"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams} g exceeds the zone limit of {limit} g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[cfg(test)]
mod tests {
    use super::QuoteError;

    #[test]
    fn each_variant_describes_itself() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "the rate card is unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 7 }.to_string(),
            "malformed rate card at line 7"
        );
        assert_eq!(
            QuoteError::UnknownZone("lunar".to_string()).to_string(),
            "unknown zone `lunar`"
        );
        assert_eq!(
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000
            }
            .to_string(),
            "parcel weight 25000 g exceeds the zone limit of 20000 g"
        );
    }

    #[test]
    fn is_a_standard_error() {
        let boxed: Box<dyn std::error::Error> = Box::new(QuoteError::RateCardUnavailable);
        assert_eq!(boxed.to_string(), "the rate card is unavailable");
    }
}
