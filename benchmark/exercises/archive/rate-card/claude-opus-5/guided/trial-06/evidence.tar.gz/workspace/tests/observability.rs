//! Every quote leaves a queryable record behind.

// Tests assert loudly; the restriction lints that guard the library
// against panicking on recoverable paths do not apply here.
#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

use std::io;
use std::sync::{Arc, Mutex, PoisonError};

use ratecard::gateway::{CardUnavailable, RateCardSource};
use ratecard::{quote_from, Parcel};
use tracing_subscriber::fmt::MakeWriter;

const CARD: &str = "domestic\t2000\t899\ninternational\t20000\t4999\n";

struct StoredCard(&'static str);

impl RateCardSource for StoredCard {
    fn load(&self) -> Result<String, CardUnavailable> {
        Ok(self.0.to_owned())
    }
}

/// Collects everything a subscriber writes, so a test can read it back.
#[derive(Clone, Default)]
struct Recorder(Arc<Mutex<Vec<u8>>>);

impl Recorder {
    fn recorded(&self) -> String {
        let buffer = self.0.lock().unwrap_or_else(PoisonError::into_inner);
        String::from_utf8_lossy(&buffer).into_owned()
    }
}

impl io::Write for Recorder {
    fn write(&mut self, buf: &[u8]) -> io::Result<usize> {
        self.0
            .lock()
            .unwrap_or_else(PoisonError::into_inner)
            .extend_from_slice(buf);
        Ok(buf.len())
    }

    fn flush(&mut self) -> io::Result<()> {
        Ok(())
    }
}

impl<'writer> MakeWriter<'writer> for Recorder {
    type Writer = Self;

    fn make_writer(&'writer self) -> Self::Writer {
        self.clone()
    }
}

/// Runs `call` with a subscriber of our own and returns what it recorded.
fn trace_of(call: impl FnOnce()) -> String {
    let recorder = Recorder::default();
    let subscriber = tracing_subscriber::fmt()
        .with_writer(recorder.clone())
        .with_ansi(false)
        .with_max_level(tracing::Level::TRACE)
        .finish();

    tracing::subscriber::with_default(subscriber, call);
    recorder.recorded()
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_owned(),
    }
}

#[test]
fn a_priced_parcel_records_zone_weight_and_total() {
    let trace = trace_of(|| {
        let _ = quote_from(&StoredCard(CARD), &parcel(1200, "domestic"));
    });

    assert!(trace.contains(r#"zone="domestic""#), "zone missing from {trace}");
    assert!(
        trace.contains("weight_grams=1200"),
        "weight missing from {trace}"
    );
    assert!(
        trace.contains("total_cents=899"),
        "total missing from {trace}"
    );
}

#[test]
fn the_recorded_total_includes_surcharges() {
    let trace = trace_of(|| {
        let _ = quote_from(&StoredCard(CARD), &parcel(15_000, "international"));
    });

    assert!(
        trace.contains("total_cents=6499"),
        "surcharged total missing from {trace}"
    );
    assert!(
        trace.contains("surcharge_cents=1500"),
        "surcharge missing from {trace}"
    );
}

#[test]
fn each_call_leaves_its_own_record() {
    let trace = trace_of(|| {
        let _ = quote_from(&StoredCard(CARD), &parcel(100, "domestic"));
        let _ = quote_from(&StoredCard(CARD), &parcel(100, "domestic"));
    });

    assert_eq!(trace.matches("quoted parcel").count(), 2, "trace: {trace}");
}

#[test]
fn a_failed_quote_records_the_parcel_and_a_queryable_outcome() {
    let trace = trace_of(|| {
        let _ = quote_from(&StoredCard(CARD), &parcel(300, "lunar"));
    });

    assert!(trace.contains(r#"zone="lunar""#), "zone missing from {trace}");
    assert!(
        trace.contains("weight_grams=300"),
        "weight missing from {trace}"
    );
    assert!(
        trace.contains(r#"outcome="unknown_zone""#),
        "outcome missing from {trace}"
    );
}

#[test]
fn quoting_without_a_subscriber_is_harmless() {
    // No subscriber installed: the call still prices normally.
    let quoted = quote_from(&StoredCard(CARD), &parcel(1200, "domestic")).expect("priced");
    assert_eq!(quoted.total_cents, 899);
}
