//! Parsing the rate card text into bands. Pure: text in, bands or a
//! [`QuoteError`] out, no filesystem in sight.

use std::collections::HashMap;

use crate::error::QuoteError;

/// One priced weight band within a zone.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Band {
    /// Inclusive upper weight bound of the band, in grams.
    pub max_grams: u32,
    /// Price of the band, in cents.
    pub cents: u64,
}

/// The deployed rate card: every zone operations priced, and the bands they
/// priced it in.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct RateCard {
    zones: HashMap<String, Vec<Band>>,
}

impl RateCard {
    /// Reads a tab-separated rate card.
    ///
    /// Each meaningful line is `zone`, `band_max_grams`, `cents`. Empty lines
    /// and lines beginning with `#` are ignored, but they still count towards
    /// the line number reported by [`QuoteError::MalformedRateCard`].
    ///
    /// # Errors
    ///
    /// Returns [`QuoteError::MalformedRateCard`] for the first line that is not
    /// three tab-separated fields, or whose numbers do not parse.
    pub fn parse(text: &str) -> Result<Self, QuoteError> {
        let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

        for (index, raw) in text.lines().enumerate() {
            let line_number = index.saturating_add(1);
            let line = raw.strip_suffix('\r').unwrap_or(raw);
            if line.trim().is_empty() || line.trim_start().starts_with('#') {
                continue;
            }

            let (zone, band) = parse_band(line, line_number)?;
            zones.entry(zone).or_default().push(band);
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(Self { zones })
    }

    /// The bands priced for `zone`, in ascending order of `max_grams`, or
    /// `None` if the card does not price that zone.
    #[must_use]
    pub fn bands(&self, zone: &str) -> Option<&[Band]> {
        self.zones.get(zone).map(Vec::as_slice)
    }
}

impl FromIterator<(String, Band)> for RateCard {
    /// Builds a card directly from bands, so core tests do not need card text.
    fn from_iter<I: IntoIterator<Item = (String, Band)>>(entries: I) -> Self {
        let mut zones: HashMap<String, Vec<Band>> = HashMap::new();
        for (zone, band) in entries {
            zones.entry(zone).or_default().push(band);
        }
        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }
        Self { zones }
    }
}

fn parse_band(line: &str, line_number: usize) -> Result<(String, Band), QuoteError> {
    let malformed = || QuoteError::MalformedRateCard { line: line_number };

    let mut fields = line.split('\t');
    let (Some(zone), Some(max_grams), Some(cents), None) = (
        fields.next(),
        fields.next(),
        fields.next(),
        fields.next(),
    ) else {
        return Err(malformed());
    };

    if zone.is_empty() {
        return Err(malformed());
    }

    let max_grams: u32 = max_grams.parse().map_err(|_| malformed())?;
    let cents: u64 = cents.parse().map_err(|_| malformed())?;

    Ok((zone.to_owned(), Band { max_grams, cents }))
}

#[cfg(test)]
mod tests {
    use super::{Band, RateCard};
    use crate::error::QuoteError;

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
                          domestic\t500\t599\n\
                          domestic\t2000\t899\n\
                          \n\
                          international\t500\t1499\n";

    #[test]
    fn reads_bands_for_each_zone() {
        let card = RateCard::parse(SAMPLE).expect("sample card parses");

        assert_eq!(
            card.bands("domestic"),
            Some(
                [
                    Band {
                        max_grams: 500,
                        cents: 599
                    },
                    Band {
                        max_grams: 2000,
                        cents: 899
                    },
                ]
                .as_slice()
            )
        );
        assert_eq!(
            card.bands("international"),
            Some(
                [Band {
                    max_grams: 500,
                    cents: 1499
                }]
                .as_slice()
            )
        );
    }

    #[test]
    fn has_no_bands_for_an_unpriced_zone() {
        let card = RateCard::parse(SAMPLE).expect("sample card parses");
        assert_eq!(card.bands("lunar"), None);
    }

    #[test]
    fn orders_bands_ascending_however_the_card_lists_them() {
        let card = RateCard::parse("domestic\t2000\t899\ndomestic\t500\t599\n")
            .expect("card parses");

        let maxima: Vec<u32> = card
            .bands("domestic")
            .expect("domestic is priced")
            .iter()
            .map(|band| band.max_grams)
            .collect();
        assert_eq!(maxima, vec![500, 2000]);
    }

    #[test]
    fn ignores_comments_and_blank_lines() {
        let card = RateCard::parse("\n#comment\n   \ndomestic\t500\t599\n")
            .expect("card parses");
        assert!(card.bands("domestic").is_some());
    }

    #[test]
    fn counts_every_line_when_reporting_a_short_row() {
        let err = RateCard::parse("# header\n\ndomestic\t500\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn rejects_a_row_with_a_trailing_field() {
        let err = RateCard::parse("domestic\t500\t599\textra\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn rejects_a_row_split_on_spaces() {
        let err = RateCard::parse("domestic 500 599\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn rejects_numbers_that_do_not_parse() {
        assert_eq!(
            RateCard::parse("domestic\theavy\t599\n").unwrap_err(),
            QuoteError::MalformedRateCard { line: 1 }
        );
        assert_eq!(
            RateCard::parse("domestic\t500\t5.99\n").unwrap_err(),
            QuoteError::MalformedRateCard { line: 1 }
        );
        assert_eq!(
            RateCard::parse("domestic\t500\t-599\n").unwrap_err(),
            QuoteError::MalformedRateCard { line: 1 }
        );
    }

    #[test]
    fn rejects_a_row_with_no_zone() {
        let err = RateCard::parse("\t500\t599\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn reports_the_first_offending_line() {
        let err = RateCard::parse("domestic\tbad\t599\ndomestic\talso-bad\t599\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn tolerates_windows_line_endings() {
        let card = RateCard::parse("# header\r\ndomestic\t500\t599\r\n").expect("card parses");
        assert_eq!(
            card.bands("domestic"),
            Some(
                [Band {
                    max_grams: 500,
                    cents: 599
                }]
                .as_slice()
            )
        );
    }

    #[test]
    fn an_empty_card_prices_nothing() {
        let card = RateCard::parse("").expect("empty card parses");
        assert_eq!(card.bands("domestic"), None);
    }
}
