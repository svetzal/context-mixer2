//! The edge contract between pricing and wherever the rate card lives, and the
//! environment-and-filesystem gateway that satisfies it in production.

use std::fs;

/// The rate card text could not be obtained.
///
/// Deliberately opaque: the core has one response to every way a card can fail
/// to arrive, and the detail belongs in the trace, not in the type.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct CardUnavailable;

/// Somewhere the rate card text can be read from.
///
/// Pricing depends on this contract rather than on the filesystem, so tests
/// substitute an in-memory card and operations can redeploy the real one.
pub trait RateCardSource {
    /// Reads the current rate card text.
    ///
    /// # Errors
    ///
    /// Returns [`CardUnavailable`] when the card cannot be read at all.
    fn load(&self) -> Result<String, CardUnavailable>;
}

/// Reads the rate card from the file named by an environment variable.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct EnvRateCardSource {
    variable: &'static str,
}

impl EnvRateCardSource {
    /// Reads the card from the path held in `variable`.
    #[must_use]
    pub const fn new(variable: &'static str) -> Self {
        Self { variable }
    }
}

impl Default for EnvRateCardSource {
    /// Reads the card from the path held in [`crate::RATECARD_PATH_VAR`].
    fn default() -> Self {
        Self::new(crate::RATECARD_PATH_VAR)
    }
}

impl RateCardSource for EnvRateCardSource {
    fn load(&self) -> Result<String, CardUnavailable> {
        let Some(path) = std::env::var_os(self.variable) else {
            tracing::warn!(variable = self.variable, "rate card path is unset");
            return Err(CardUnavailable);
        };

        fs::read_to_string(&path).map_err(|error| {
            tracing::warn!(
                variable = self.variable,
                path = %std::path::Path::new(&path).display(),
                error = %error,
                "rate card could not be read"
            );
            CardUnavailable
        })
    }
}
