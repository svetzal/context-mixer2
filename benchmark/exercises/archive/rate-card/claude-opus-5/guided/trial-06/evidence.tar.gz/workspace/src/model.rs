//! The values a caller hands in and gets back.

/// A parcel awaiting a price.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Billable weight of the parcel, in grams.
    pub weight_grams: u32,
    /// Destination zone, matched against the zone column of the rate card.
    pub zone: String,
}

/// The price of shipping one [`Parcel`], broken out so an operator can see how
/// the total was reached.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quote {
    /// Price of the matching band, before surcharges.
    pub base_cents: u64,
    /// Surcharges added to the base price.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// Upper weight bound of the band that priced this parcel, in grams.
    pub band_max_grams: u32,
}
