//! The ways a quote can fail.

use std::fmt;

/// Why a parcel could not be priced.
///
/// Every variant is a condition the caller is expected to handle: a rate card
/// that operations has not deployed yet, a card they deployed with a typo in
/// it, or a parcel the card does not cover.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, or the file it names could not be read.
    RateCardUnavailable,
    /// A line of the rate card is not three tab-separated fields, or its
    /// numbers do not parse. Carries the 1-based line number, counting every
    /// line in the file including comments and blanks.
    MalformedRateCard {
        /// 1-based number of the offending line.
        line: usize,
    },
    /// The requested zone has no bands in the rate card. Carries the zone as
    /// it was requested.
    UnknownZone(String),
    /// The parcel weighs more than the zone's largest band allows.
    Overweight {
        /// Weight of the parcel, in grams.
        grams: u32,
        /// Upper bound of the zone's largest band, in grams.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => f.write_str("rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone `{zone}`"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel of {grams}g exceeds the zone limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// A short, low-cardinality label for the failure, suitable as a queryable
/// tracing field.
impl QuoteError {
    pub(crate) const fn outcome(&self) -> &'static str {
        match self {
            Self::RateCardUnavailable => "rate_card_unavailable",
            Self::MalformedRateCard { .. } => "malformed_rate_card",
            Self::UnknownZone(_) => "unknown_zone",
            Self::Overweight { .. } => "overweight",
        }
    }
}

#[cfg(test)]
mod tests {
    use super::QuoteError;

    #[test]
    fn displays_each_variant_for_an_operator() {
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "rate card unavailable"
        );
        assert_eq!(
            QuoteError::MalformedRateCard { line: 7 }.to_string(),
            "malformed rate card at line 7"
        );
        assert_eq!(
            QuoteError::UnknownZone("lunar".to_owned()).to_string(),
            "unknown zone `lunar`"
        );
        assert_eq!(
            QuoteError::Overweight {
                grams: 21_000,
                limit: 20_000
            }
            .to_string(),
            "parcel of 21000g exceeds the zone limit of 20000g"
        );
    }

    #[test]
    fn is_a_std_error() {
        let err: &dyn std::error::Error = &QuoteError::RateCardUnavailable;
        assert_eq!(err.to_string(), "rate card unavailable");
    }
}
