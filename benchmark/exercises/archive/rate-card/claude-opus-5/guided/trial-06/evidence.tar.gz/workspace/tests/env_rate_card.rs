//! The production wiring: `RATECARD_PATH`, a real file, and `quote`.
//!
//! The environment is process-wide, so these tests take a lock rather than
//! racing each other over the same variable.

// Tests assert loudly; the restriction lints that guard the library
// against panicking on recoverable paths do not apply here.
#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

use std::io::Write;
use std::sync::{Mutex, MutexGuard, PoisonError};

use ratecard::{quote, Parcel, QuoteError, RATECARD_PATH_VAR};
use tempfile::NamedTempFile;

static ENVIRONMENT: Mutex<()> = Mutex::new(());

fn exclusive_environment() -> MutexGuard<'static, ()> {
    ENVIRONMENT.lock().unwrap_or_else(PoisonError::into_inner)
}

const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn deployed(card: &str) -> NamedTempFile {
    let mut file = NamedTempFile::new().expect("temp file");
    file.write_all(card.as_bytes()).expect("write card");
    file.flush().expect("flush card");
    std::env::set_var(RATECARD_PATH_VAR, file.path());
    file
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_owned(),
    }
}

#[test]
fn prices_a_parcel_against_the_deployed_card() {
    let _lock = exclusive_environment();
    let _card = deployed(CARD);

    let quoted = quote(&parcel(1200, "domestic")).expect("priced");

    assert_eq!(quoted.base_cents, 899);
    assert_eq!(quoted.surcharge_cents, 0);
    assert_eq!(quoted.total_cents, 899);
    assert_eq!(quoted.band_max_grams, 2000);
}

#[test]
fn picks_up_a_redeployed_card_without_a_restart() {
    let _lock = exclusive_environment();

    let _first = deployed("domestic\t2000\t899\n");
    assert_eq!(
        quote(&parcel(1200, "domestic")).expect("priced").total_cents,
        899
    );

    let _second = deployed("domestic\t2000\t949\n");
    assert_eq!(
        quote(&parcel(1200, "domestic")).expect("priced").total_cents,
        949
    );
}

#[test]
fn an_unset_path_leaves_the_card_unavailable() {
    let _lock = exclusive_environment();
    std::env::remove_var(RATECARD_PATH_VAR);

    assert_eq!(
        quote(&parcel(100, "domestic")).unwrap_err(),
        QuoteError::RateCardUnavailable
    );
}

#[test]
fn a_path_to_nothing_leaves_the_card_unavailable() {
    let _lock = exclusive_environment();
    let missing = NamedTempFile::new().expect("temp file");
    let path = missing.path().to_path_buf();
    drop(missing);
    std::env::set_var(RATECARD_PATH_VAR, &path);

    assert_eq!(
        quote(&parcel(100, "domestic")).unwrap_err(),
        QuoteError::RateCardUnavailable
    );
}

#[test]
fn an_unreadable_path_leaves_the_card_unavailable() {
    let _lock = exclusive_environment();
    let directory = tempfile::tempdir().expect("temp dir");
    std::env::set_var(RATECARD_PATH_VAR, directory.path());

    assert_eq!(
        quote(&parcel(100, "domestic")).unwrap_err(),
        QuoteError::RateCardUnavailable
    );
}

#[test]
fn a_bad_line_in_the_deployed_card_is_reported_by_line_number() {
    let _lock = exclusive_environment();
    let _card = deployed("# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\t2000\n");

    assert_eq!(
        quote(&parcel(100, "domestic")).unwrap_err(),
        QuoteError::MalformedRateCard { line: 3 }
    );
}

#[test]
fn an_unpriced_zone_in_the_deployed_card_is_named() {
    let _lock = exclusive_environment();
    let _card = deployed(CARD);

    assert_eq!(
        quote(&parcel(100, "lunar")).unwrap_err(),
        QuoteError::UnknownZone("lunar".to_owned())
    );
}

#[test]
fn an_overweight_parcel_reports_the_zone_limit() {
    let _lock = exclusive_environment();
    let _card = deployed(CARD);

    assert_eq!(
        quote(&parcel(30_000, "international")).unwrap_err(),
        QuoteError::Overweight {
            grams: 30_000,
            limit: 20_000
        }
    );
}
