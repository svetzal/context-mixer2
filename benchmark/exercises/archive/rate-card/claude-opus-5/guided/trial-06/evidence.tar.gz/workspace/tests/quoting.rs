//! Cross-module behaviour: card text in through the gateway contract, quote or
//! error out, with no filesystem involved.

// Tests assert loudly; the restriction lints that guard the library
// against panicking on recoverable paths do not apply here.
#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

use ratecard::gateway::{CardUnavailable, RateCardSource};
use ratecard::{quote_from, Parcel, QuoteError};

/// A rate card held in memory, standing in for a deployed file.
struct StoredCard(&'static str);

impl RateCardSource for StoredCard {
    fn load(&self) -> Result<String, CardUnavailable> {
        Ok(self.0.to_owned())
    }
}

/// A source that has nothing to give, as when the card has not been deployed.
struct NoCard;

impl RateCardSource for NoCard {
    fn load(&self) -> Result<String, CardUnavailable> {
        Err(CardUnavailable)
    }
}

const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_owned(),
    }
}

#[test]
fn prices_the_published_card_across_its_domestic_bands() {
    let cases = [
        (100_u32, 599_u64, 500_u32),
        (500, 599, 500),
        (501, 899, 2000),
        (2000, 899, 2000),
        (2001, 1799, 20_000),
        (10_000, 1799, 20_000),
    ];

    for (grams, base_cents, band_max_grams) in cases {
        let quote = quote_from(&StoredCard(CARD), &parcel(grams, "domestic"))
            .unwrap_or_else(|err| panic!("{grams}g domestic should price: {err}"));

        assert_eq!(quote.base_cents, base_cents, "base for {grams}g");
        assert_eq!(quote.surcharge_cents, 0, "surcharge for {grams}g");
        assert_eq!(quote.total_cents, base_cents, "total for {grams}g");
        assert_eq!(quote.band_max_grams, band_max_grams, "band for {grams}g");
    }
}

#[test]
fn a_heavy_domestic_parcel_pays_the_flat_surcharge() {
    let quote = quote_from(&StoredCard(CARD), &parcel(12_500, "domestic")).expect("priced");

    assert_eq!(quote.base_cents, 1799);
    assert_eq!(quote.surcharge_cents, 500);
    assert_eq!(quote.total_cents, 2299);
    assert_eq!(quote.band_max_grams, 20_000);
}

#[test]
fn an_international_parcel_pays_the_uplift() {
    let quote = quote_from(&StoredCard(CARD), &parcel(500, "international")).expect("priced");

    assert_eq!(quote.base_cents, 1499);
    assert_eq!(quote.surcharge_cents, 300);
    assert_eq!(quote.total_cents, 1799);
    assert_eq!(quote.band_max_grams, 500);
}

#[test]
fn a_heavy_international_parcel_pays_both() {
    let quote = quote_from(&StoredCard(CARD), &parcel(19_000, "international")).expect("priced");

    assert_eq!(quote.base_cents, 4999);
    assert_eq!(quote.surcharge_cents, 1500);
    assert_eq!(quote.total_cents, 6499);
    assert_eq!(quote.band_max_grams, 20_000);
}

#[test]
fn an_unpriced_zone_comes_back_named() {
    let err = quote_from(&StoredCard(CARD), &parcel(100, "lunar")).unwrap_err();
    assert_eq!(err, QuoteError::UnknownZone("lunar".to_owned()));
}

#[test]
fn a_parcel_beyond_the_largest_band_is_overweight() {
    let err = quote_from(&StoredCard(CARD), &parcel(25_000, "domestic")).unwrap_err();
    assert_eq!(
        err,
        QuoteError::Overweight {
            grams: 25_000,
            limit: 20_000
        }
    );
}

#[test]
fn a_card_that_cannot_be_read_is_unavailable() {
    let err = quote_from(&NoCard, &parcel(100, "domestic")).unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn a_bad_line_is_reported_by_its_number_in_the_file() {
    let err = quote_from(
        &StoredCard("# zone\tband_max_grams\tcents\n\ndomestic\t500\tfree\n"),
        &parcel(100, "domestic"),
    )
    .unwrap_err();

    assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
}

#[test]
fn a_malformed_card_fails_before_any_zone_is_priced() {
    // The bad line is for another zone entirely, and still stops the quote.
    let err = quote_from(
        &StoredCard("domestic\t500\t599\ninternational\tbad\t1499\n"),
        &parcel(100, "domestic"),
    )
    .unwrap_err();

    assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
}

#[test]
fn an_empty_card_prices_no_zone() {
    let err = quote_from(&StoredCard(""), &parcel(100, "domestic")).unwrap_err();
    assert_eq!(err, QuoteError::UnknownZone("domestic".to_owned()));
}

#[test]
fn quote_errors_are_std_errors_callers_can_report() {
    let err: Box<dyn std::error::Error> =
        Box::new(quote_from(&NoCard, &parcel(100, "domestic")).unwrap_err());
    assert_eq!(err.to_string(), "rate card unavailable");
}
