//! Turning a parcel and a rate card into a quote. Pure: no filesystem, no
//! environment, no clock.

use crate::error::QuoteError;
use crate::model::{Parcel, Quote};
use crate::rate_card::RateCard;

/// Weight, in grams, strictly above which the heavy-parcel surcharge applies.
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
/// Flat surcharge, in cents, for a parcel above [`HEAVY_THRESHOLD_GRAMS`].
const HEAVY_SURCHARGE_CENTS: u64 = 500;
/// Zone that carries the cross-border uplift.
const INTERNATIONAL_ZONE: &str = "international";
/// Cross-border uplift, as a percentage of the base price.
const INTERNATIONAL_UPLIFT_PERCENT: u64 = 20;

/// Prices `parcel` against `card`.
///
/// The matching band is the first, in ascending order of `max_grams`, whose
/// bound is greater than or equal to the parcel weight.
///
/// # Errors
///
/// Returns [`QuoteError::UnknownZone`] when the card does not price the
/// parcel's zone, and [`QuoteError::Overweight`] when the parcel outweighs the
/// zone's largest band.
pub fn price(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = card
        .bands(&parcel.zone)
        .filter(|bands| !bands.is_empty())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let Some(band) = bands
        .iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
    else {
        let limit = bands.iter().map(|band| band.max_grams).max().unwrap_or(0);
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        });
    };

    let base_cents = band.cents;
    let surcharge_cents = surcharges(base_cents, parcel);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    })
}

/// Every surcharge the parcel attracts, added together.
fn surcharges(base_cents: u64, parcel: &Parcel) -> u64 {
    let heavy = if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    };

    let international = if parcel.zone == INTERNATIONAL_ZONE {
        percent_of_half_up(base_cents, INTERNATIONAL_UPLIFT_PERCENT)
    } else {
        0
    };

    heavy.saturating_add(international)
}

/// `percent` percent of `cents`, rounded half-up to the nearest cent.
fn percent_of_half_up(cents: u64, percent: u64) -> u64 {
    let scaled = u128::from(cents)
        .saturating_mul(u128::from(percent))
        .saturating_add(50);
    u64::try_from(scaled.wrapping_div(100)).unwrap_or(u64::MAX)
}

#[cfg(test)]
mod tests {
    use super::{percent_of_half_up, price};
    use crate::error::QuoteError;
    use crate::model::Parcel;
    use crate::rate_card::{Band, RateCard};

    fn card() -> RateCard {
        [
            ("domestic", 500, 599),
            ("domestic", 2000, 899),
            ("domestic", 20_000, 1799),
            ("international", 500, 1499),
            ("international", 20_000, 4999),
        ]
        .into_iter()
        .map(|(zone, max_grams, cents)| (zone.to_owned(), Band { max_grams, cents }))
        .collect()
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_owned(),
        }
    }

    #[test]
    fn prices_a_light_domestic_parcel_from_the_first_band() {
        let quote = price(&card(), &parcel(200, "domestic")).expect("priced");

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn a_weight_exactly_on_a_bound_stays_in_that_band() {
        let quote = price(&card(), &parcel(500, "domestic")).expect("priced");

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn a_gram_over_a_bound_moves_up_a_band() {
        let quote = price(&card(), &parcel(501, "domestic")).expect("priced");

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn a_weightless_parcel_takes_the_lowest_band() {
        let quote = price(&card(), &parcel(0, "domestic")).expect("priced");

        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.total_cents, 599);
    }

    #[test]
    fn heavy_parcels_pay_a_flat_surcharge_above_ten_kilos() {
        let quote = price(&card(), &parcel(10_001, "domestic")).expect("priced");

        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn ten_kilos_exactly_is_not_heavy() {
        let quote = price(&card(), &parcel(10_000, "domestic")).expect("priced");

        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn international_parcels_pay_a_fifth_of_the_base() {
        let quote = price(&card(), &parcel(400, "international")).expect("priced");

        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300); // 299.8 rounds half-up to 300
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn surcharges_add_together() {
        let quote = price(&card(), &parcel(15_000, "international")).expect("priced");

        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 500 + 1000); // 999.8 rounds to 1000
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn rounds_the_uplift_half_up() {
        assert_eq!(percent_of_half_up(0, 20), 0);
        assert_eq!(percent_of_half_up(10, 20), 2);
        assert_eq!(percent_of_half_up(1499, 20), 300);
        // 1497 * 20% = 299.4, down; 1498 * 20% = 299.6, up.
        assert_eq!(percent_of_half_up(1497, 20), 299);
        assert_eq!(percent_of_half_up(1498, 20), 300);
        // Exactly half a cent goes up, not to even.
        assert_eq!(percent_of_half_up(5, 10), 1);
        assert_eq!(percent_of_half_up(15, 10), 2);
    }

    #[test]
    fn an_unpriced_zone_is_rejected_by_name() {
        let err = price(&card(), &parcel(100, "lunar")).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".to_owned()));
    }

    #[test]
    fn zone_matching_is_exact() {
        let err = price(&card(), &parcel(100, "Domestic")).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("Domestic".to_owned()));
    }

    #[test]
    fn a_parcel_past_the_largest_band_is_overweight() {
        let err = price(&card(), &parcel(20_001, "domestic")).unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            }
        );
    }

    #[test]
    fn the_overweight_limit_is_the_zones_own_largest_band() {
        let card: RateCard = [(
            "domestic".to_owned(),
            Band {
                max_grams: 500,
                cents: 599,
            },
        )]
        .into_iter()
        .collect();

        let err = price(&card, &parcel(600, "domestic")).unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 600,
                limit: 500
            }
        );
    }

    #[test]
    fn extreme_prices_saturate_rather_than_overflow() {
        let card: RateCard = [(
            "international".to_owned(),
            Band {
                max_grams: u32::MAX,
                cents: u64::MAX,
            },
        )]
        .into_iter()
        .collect();

        let quote = price(&card, &parcel(u32::MAX, "international")).expect("priced");
        assert_eq!(quote.total_cents, u64::MAX);
    }
}
