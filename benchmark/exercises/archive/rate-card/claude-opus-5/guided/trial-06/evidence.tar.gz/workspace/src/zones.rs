//! Human-facing names for the zones the rate card prices.

/// The name warehouse staff know a zone by.
///
/// Zones the rate card carries but this crate does not name are passed through
/// unchanged, so a new zone in the card is usable before it is labelled here.
///
/// ```
/// assert_eq!(ratecard::zones::zone_label("domestic"), "Domestic ground");
/// assert_eq!(ratecard::zones::zone_label("lunar"), "lunar");
/// ```
#[must_use]
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}
