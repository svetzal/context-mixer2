# ratecard

Shipping quotes for the fulfilment service.

Warehouse operators price outbound parcels against a rate card that operations
maintains and redeploys without a code change. This crate owns reading that card
and turning a parcel into a quote.

## Using it

`quote` reads the card named by `RATECARD_PATH` and prices one parcel:

```rust
use ratecard::{quote, Parcel};

let parcel = Parcel { weight_grams: 1200, zone: "domestic".to_owned() };
let priced = quote(&parcel)?;
assert_eq!(priced.total_cents, priced.base_cents + priced.surcharge_cents);
```

Every failure is a `QuoteError` the caller handles: the card is unavailable, a
line of it is malformed, the zone is unpriced, or the parcel is overweight.
Nothing panics on those paths.

## The rate card

Tab-separated, one band per line. Empty lines and lines beginning with `#` are
ignored, but they still count towards the line number a malformed-card error
reports.

```text
# zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
domestic	20000	1799
international	500	1499
international	20000	4999
```

A parcel takes the first band, in ascending order of `band_max_grams`, whose
bound is at or above its weight. Surcharges add together: 500 cents above
10000 grams, plus 20% of the base — rounded half-up — for `international`.

## Shape

Reading the card is the only side effect, and it sits behind
`gateway::RateCardSource`. `rate_card::RateCard::parse` and `pricing::price`
are pure, and their tests never touch a filesystem. `quote_from` is the shell:
it fetches the card, calls the core, and records the call.

## Observability

Each call opens a `quote` span carrying `zone` and `weight_grams`, and emits an
event carrying the outcome — `total_cents` and its breakdown when priced, a
queryable `outcome` label when not. Install any `tracing` subscriber to see
them.

## Development

```bash
cargo test
cargo clippy --all-targets
cargo doc --no-deps
```
