//! Shipping quotes for the fulfilment service.
//!
//! Operations maintains a rate card — zones, weight bands, prices — and
//! redeploys it without a code change. [`quote`] reads that card from the path
//! in the `RATECARD_PATH` environment variable and prices one [`Parcel`]
//! against it.
//!
//! Reading the card is the only side effect. Everything downstream of the text
//! is pure: [`rate_card::RateCard::parse`] turns card text into bands, and
//! [`pricing::price`] turns bands and a parcel into a [`Quote`]. Callers with
//! their own card storage can bypass the environment entirely by implementing
//! [`gateway::RateCardSource`] and calling [`quote_from`].
//!
//! ```
//! use std::io::Write;
//! use ratecard::{quote, Parcel};
//!
//! let mut card = tempfile::NamedTempFile::new()?;
//! write!(card, "# zone\tband_max_grams\tcents\ndomestic\t500\t599\n")?;
//! std::env::set_var("RATECARD_PATH", card.path());
//!
//! let quote = quote(&Parcel { weight_grams: 250, zone: "domestic".to_owned() })?;
//! assert_eq!(quote.total_cents, 599);
//! # Ok::<(), Box<dyn std::error::Error>>(())
//! ```

// Tests may assert loudly and do their own arithmetic; the library may not.
#![cfg_attr(
    test,
    allow(
        clippy::unwrap_used,
        clippy::expect_used,
        clippy::panic,
        clippy::arithmetic_side_effects
    )
)]

pub mod error;
pub mod gateway;
pub mod model;
pub mod pricing;
pub mod rate_card;
pub mod zones;

pub use crate::error::QuoteError;
pub use crate::model::{Parcel, Quote};

use crate::gateway::{EnvRateCardSource, RateCardSource};
use crate::rate_card::RateCard;

/// Environment variable naming the deployed rate card file.
pub const RATECARD_PATH_VAR: &str = "RATECARD_PATH";

/// Prices `parcel` against the rate card deployed at `RATECARD_PATH`.
///
/// # Errors
///
/// Returns [`QuoteError::RateCardUnavailable`] when `RATECARD_PATH` is unset or
/// its file cannot be read, [`QuoteError::MalformedRateCard`] when the card has
/// a bad line, [`QuoteError::UnknownZone`] when the card does not price the
/// parcel's zone, and [`QuoteError::Overweight`] when the parcel outweighs that
/// zone's largest band.
///
/// ```
/// use std::io::Write;
/// use ratecard::{quote, Parcel, QuoteError};
///
/// let mut card = tempfile::NamedTempFile::new()?;
/// write!(card, "international\t500\t1499\n")?;
/// std::env::set_var("RATECARD_PATH", card.path());
///
/// let parcel = Parcel { weight_grams: 400, zone: "international".to_owned() };
/// let priced = quote(&parcel)?;
/// assert_eq!(priced.base_cents, 1499);
/// assert_eq!(priced.surcharge_cents, 300);
/// assert_eq!(priced.total_cents, 1799);
/// assert_eq!(priced.band_max_grams, 500);
///
/// let unpriced = Parcel { weight_grams: 400, zone: "lunar".to_owned() };
/// assert_eq!(quote(&unpriced), Err(QuoteError::UnknownZone("lunar".to_owned())));
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// ```
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_from(&EnvRateCardSource::default(), parcel)
}

/// Prices `parcel` against the rate card held by `source`.
///
/// The shell around the pure core: it obtains the card text, hands it to
/// parsing and pricing, and records the outcome of the call.
///
/// # Errors
///
/// As [`quote`], except that [`QuoteError::RateCardUnavailable`] reflects
/// whatever `source` reports rather than the environment specifically.
///
/// ```
/// use ratecard::gateway::{CardUnavailable, RateCardSource};
/// use ratecard::{quote_from, Parcel};
///
/// struct FixedCard;
/// impl RateCardSource for FixedCard {
///     fn load(&self) -> Result<String, CardUnavailable> {
///         Ok("domestic\t2000\t899\n".to_owned())
///     }
/// }
///
/// let parcel = Parcel { weight_grams: 1200, zone: "domestic".to_owned() };
/// assert_eq!(quote_from(&FixedCard, &parcel)?.total_cents, 899);
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// ```
pub fn quote_from<S: RateCardSource + ?Sized>(
    source: &S,
    parcel: &Parcel,
) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "quote",
        zone = parcel.zone.as_str(),
        weight_grams = parcel.weight_grams,
        total_cents = tracing::field::Empty,
        outcome = tracing::field::Empty,
    );
    let _entered = span.enter();

    let result = priced(source, parcel);

    match &result {
        Ok(quote) => {
            span.record("total_cents", quote.total_cents);
            span.record("outcome", "quoted");
            tracing::info!(
                zone = parcel.zone.as_str(),
                weight_grams = parcel.weight_grams,
                base_cents = quote.base_cents,
                surcharge_cents = quote.surcharge_cents,
                total_cents = quote.total_cents,
                band_max_grams = quote.band_max_grams,
                "quoted parcel"
            );
        }
        Err(error) => {
            span.record("outcome", error.outcome());
            tracing::warn!(
                zone = parcel.zone.as_str(),
                weight_grams = parcel.weight_grams,
                outcome = error.outcome(),
                error = %error,
                "parcel could not be quoted"
            );
        }
    }

    result
}

/// The whole calculation, with no instrumentation in the way of reading it.
fn priced<S: RateCardSource + ?Sized>(source: &S, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let text = source
        .load()
        .map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = RateCard::parse(&text)?;
    pricing::price(&card, parcel)
}
