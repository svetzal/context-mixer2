//! Every quote leaves a diagnostic record an operator can query by field.

// A test that cannot get its fixture should say so and stop.
#![allow(clippy::expect_used, clippy::unwrap_used, clippy::panic)]

mod support;

use ratecard::{quote_with, InMemoryRateCard, Parcel};
use support::{Recorder, CARD};

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_owned(),
    }
}

#[test]
fn a_priced_parcel_reports_zone_weight_and_total_as_fields() {
    let recorder = Recorder::new();

    let quote = recorder
        .capturing(|| quote_with(&InMemoryRateCard::new(CARD), &parcel(15_000, "international")))
        .expect("priced");

    let event = recorder.event_with("total_cents").expect("a quote emits a diagnostic record");
    assert_eq!(event.get("zone").map(String::as_str), Some("international"));
    assert_eq!(event.get("weight_grams").map(String::as_str), Some("15000"));
    assert_eq!(
        event.get("total_cents").map(String::as_str),
        Some(quote.total_cents.to_string().as_str())
    );
}

#[test]
fn one_record_per_call() {
    let recorder = Recorder::new();

    recorder.capturing(|| {
        let card = InMemoryRateCard::new(CARD);
        let _ = quote_with(&card, &parcel(100, "domestic"));
        let _ = quote_with(&card, &parcel(200, "domestic"));
    });

    assert_eq!(recorder.events().len(), 2);
}

#[test]
fn the_quote_span_carries_its_own_outcome_and_total() {
    let recorder = Recorder::new();

    drop(recorder.capturing(|| quote_with(&InMemoryRateCard::new(CARD), &parcel(300, "domestic"))));

    let (name, fields) = recorder.spans().pop().expect("a quote opens a span");
    assert_eq!(name, "quote");
    assert_eq!(fields.get("zone").map(String::as_str), Some("domestic"));
    assert_eq!(fields.get("weight_grams").map(String::as_str), Some("300"));
    assert_eq!(fields.get("total_cents").map(String::as_str), Some("599"));
    assert_eq!(fields.get("outcome").map(String::as_str), Some("priced"));
}

#[test]
fn a_declined_quote_reports_the_reason_rather_than_a_total() {
    let recorder = Recorder::new();

    drop(recorder.capturing(|| quote_with(&InMemoryRateCard::new(CARD), &parcel(100, "lunar"))));

    let event = recorder
        .event_with("error")
        .expect("a declined quote emits a diagnostic record");
    assert_eq!(event.get("zone").map(String::as_str), Some("lunar"));
    assert_eq!(event.get("weight_grams").map(String::as_str), Some("100"));
    assert_eq!(event.get("error").map(String::as_str), Some("unknown zone `lunar`"));

    let (_, fields) = recorder.spans().pop().expect("a quote opens a span");
    assert_eq!(fields.get("outcome").map(String::as_str), Some("declined"));
    assert_eq!(fields.get("total_cents"), None);
}

#[test]
fn an_unreadable_card_reports_why_at_the_source() {
    let recorder = Recorder::new();

    drop(
        recorder
            .capturing(|| quote_with(&InMemoryRateCard::unavailable(), &parcel(100, "domestic"))),
    );

    let event = recorder
        .event_with("error")
        .expect("a declined quote emits a diagnostic record");
    assert_eq!(event.get("error").map(String::as_str), Some("rate card unavailable"));
}
