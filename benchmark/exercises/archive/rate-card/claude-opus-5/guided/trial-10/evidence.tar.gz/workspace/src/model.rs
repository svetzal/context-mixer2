//! The parcel a caller prices and the quote it earns.
//!
//! These are plain data: no I/O, no invariants beyond their field types, so
//! they can be constructed freely in tests.

/// A parcel presented for pricing.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Billable weight of the parcel, in grams.
    pub weight_grams: u32,
    /// Rate-card zone the parcel ships to, e.g. `domestic`.
    pub zone: String,
}

/// The price of shipping a [`Parcel`], broken out so a caller can show its
/// parts on an invoice.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quote {
    /// Price of the matching weight band, before surcharges.
    pub base_cents: u64,
    /// Surcharges that apply to this parcel, added together.
    pub surcharge_cents: u64,
    /// What the caller is billed: `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// Upper weight of the band that priced this parcel, in grams.
    pub band_max_grams: u32,
}
