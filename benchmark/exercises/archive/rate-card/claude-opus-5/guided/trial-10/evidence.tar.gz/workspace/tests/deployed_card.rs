//! The deployed path: `quote` reading the card operations pointed
//! `RATECARD_PATH` at.

// A test that cannot get its fixture should say so and stop.
#![allow(clippy::expect_used, clippy::unwrap_used, clippy::panic)]

mod support;

use std::error::Error;
use std::fs;
use std::path::Path;
use std::sync::{Mutex, PoisonError};

use ratecard::{quote, Parcel, Quote, QuoteError, RATECARD_PATH_VAR};
use support::CARD;
use tempfile::TempDir;

/// `RATECARD_PATH` is process-wide, so only one test may hold it at a time.
static ENVIRONMENT: Mutex<()> = Mutex::new(());

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_owned(),
    }
}

/// Point `RATECARD_PATH` at `path` for the duration of `body`, then put the
/// environment back the way it was found.
fn with_ratecard_path<T>(path: Option<&Path>, body: impl FnOnce() -> T) -> T {
    let _serialised = ENVIRONMENT.lock().unwrap_or_else(PoisonError::into_inner);
    let restore = std::env::var_os(RATECARD_PATH_VAR);

    match path {
        Some(path) => std::env::set_var(RATECARD_PATH_VAR, path),
        None => std::env::remove_var(RATECARD_PATH_VAR),
    }

    let outcome = body();

    match restore {
        Some(previous) => std::env::set_var(RATECARD_PATH_VAR, previous),
        None => std::env::remove_var(RATECARD_PATH_VAR),
    }
    outcome
}

/// Deploy `card` to a file and quote `parcel` against it.
fn quote_against(card: &str, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let directory = TempDir::new().expect("a temporary directory");
    let path = directory.path().join("rates.tsv");
    fs::write(&path, card).expect("the card is written");

    with_ratecard_path(Some(&path), || quote(parcel))
}

#[test]
fn prices_a_domestic_parcel_from_the_deployed_card() {
    let quote = quote_against(CARD, &parcel(300, "domestic")).expect("priced");

    assert_eq!(quote.base_cents, 599);
    assert_eq!(quote.surcharge_cents, 0);
    assert_eq!(quote.total_cents, 599);
    assert_eq!(quote.band_max_grams, 500);
}

#[test]
fn prices_an_international_parcel_with_its_proportional_surcharge() {
    let quote = quote_against(CARD, &parcel(400, "international")).expect("priced");

    assert_eq!(quote.base_cents, 1499);
    assert_eq!(quote.surcharge_cents, 300);
    assert_eq!(quote.total_cents, 1799);
    assert_eq!(quote.band_max_grams, 500);
}

#[test]
fn prices_a_heavy_international_parcel_with_both_surcharges() {
    let quote = quote_against(CARD, &parcel(12_000, "international")).expect("priced");

    assert_eq!(quote.base_cents, 4999);
    assert_eq!(quote.surcharge_cents, 1500);
    assert_eq!(quote.total_cents, 6499);
    assert_eq!(quote.band_max_grams, 20_000);
}

#[test]
fn a_zone_the_card_does_not_price_is_unknown() {
    assert_eq!(
        quote_against(CARD, &parcel(300, "lunar")),
        Err(QuoteError::UnknownZone("lunar".to_owned()))
    );
}

#[test]
fn a_parcel_past_the_largest_band_is_overweight() {
    assert_eq!(
        quote_against(CARD, &parcel(25_000, "domestic")),
        Err(QuoteError::Overweight {
            grams: 25_000,
            limit: 20_000
        })
    );
}

#[test]
fn a_malformed_line_is_reported_by_its_line_number_in_the_file() {
    let card = "# zone\tband_max_grams\tcents\n\ndomestic\t500\t599\ndomestic\t2000\n";

    assert_eq!(
        quote_against(card, &parcel(300, "domestic")),
        Err(QuoteError::MalformedRateCard { line: 4 })
    );
}

#[test]
fn an_unset_path_leaves_the_rate_card_unavailable() {
    let outcome = with_ratecard_path(None, || quote(&parcel(300, "domestic")));

    assert_eq!(outcome, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn a_path_pointing_at_nothing_leaves_the_rate_card_unavailable() {
    let directory = TempDir::new().expect("a temporary directory");
    let missing = directory.path().join("never-deployed.tsv");

    let outcome = with_ratecard_path(Some(&missing), || quote(&parcel(300, "domestic")));

    assert_eq!(outcome, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn an_unreadable_path_leaves_the_rate_card_unavailable() {
    let directory = TempDir::new().expect("a temporary directory");

    let outcome = with_ratecard_path(Some(directory.path()), || quote(&parcel(300, "domestic")));

    assert_eq!(outcome, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn a_declined_quote_travels_as_a_standard_error() {
    let error = quote_against(CARD, &parcel(300, "lunar")).expect_err("declined");

    let reported: Box<dyn Error> = Box::new(error);
    assert_eq!(reported.to_string(), "unknown zone `lunar`");
    assert!(reported.source().is_none());
}
