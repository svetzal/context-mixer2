//! How zones are named to people.
//!
//! Rate-card zones are terse identifiers; these are the labels an operator
//! reads on a screen.

/// The human-readable label for a rate-card zone.
///
/// A zone the crate has no label for is shown as operations named it.
///
/// ```
/// assert_eq!(ratecard::zones::zone_label("domestic"), "Domestic ground");
/// assert_eq!(ratecard::zones::zone_label("lunar"), "lunar");
/// ```
#[must_use]
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}
