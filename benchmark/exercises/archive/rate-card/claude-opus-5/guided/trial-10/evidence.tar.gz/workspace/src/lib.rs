//! Shipping quotes from an operations-maintained rate card.
//!
//! Operations deploys a tab-separated rate card and points `RATECARD_PATH` at
//! it. [`quote`] reads that card and prices a [`Parcel`]:
//!
//! ```text
//! # zone	band_max_grams	cents
//! domestic	500	599
//! domestic	2000	899
//! international	500	1499
//! ```
//!
//! The band that prices a parcel is the first, ascending, whose
//! `band_max_grams` covers the parcel's weight. Surcharges then add together:
//! 500 cents for a parcel above 10 kg, and 20% of the base price for the
//! `international` zone, rounded half-up.
//!
//! ```
//! use ratecard::{quote_with, InMemoryRateCard, Parcel};
//!
//! let card = InMemoryRateCard::new("domestic\t500\t599\ninternational\t500\t1499\n");
//!
//! let parcel = Parcel { weight_grams: 400, zone: "international".to_owned() };
//! let quote = quote_with(&card, &parcel)?;
//!
//! assert_eq!(quote.base_cents, 1499);
//! assert_eq!(quote.surcharge_cents, 300);
//! assert_eq!(quote.total_cents, 1799);
//! assert_eq!(quote.band_max_grams, 500);
//! # Ok::<(), ratecard::QuoteError>(())
//! ```
//!
//! Pricing itself is pure. [`quote`] is the thin shell that reads the card
//! from the environment; [`quote_with`] takes any [`RateCardSource`], which is
//! how tests price against a card without touching the filesystem.

// The rate card is tab-separated, and the sample above shows the separator it
// really carries rather than a spaced-out imitation of one.
#![allow(clippy::tabs_in_doc_comments)]
// Test code says what it means with `expect` and plain arithmetic; the
// restrictions below exist to protect callers of the library, not its tests.
#![cfg_attr(
    test,
    allow(
        clippy::unwrap_used,
        clippy::expect_used,
        clippy::panic,
        clippy::indexing_slicing,
        clippy::arithmetic_side_effects
    )
)]

mod error;
mod model;
mod pricing;
mod rate_card;
mod source;
pub mod zones;

pub use error::QuoteError;
pub use model::{Parcel, Quote};
pub use source::{
    EnvRateCardFile, InMemoryRateCard, RateCardSource, RateCardUnavailable, RATECARD_PATH_VAR,
};

use rate_card::RateCard;

/// Price a parcel against the rate card named by `RATECARD_PATH`.
///
/// # Errors
///
/// - [`QuoteError::RateCardUnavailable`] when `RATECARD_PATH` is unset or its
///   file cannot be read.
/// - [`QuoteError::MalformedRateCard`] when a line of the card is not three
///   tab-separated fields, or its numbers do not parse.
/// - [`QuoteError::UnknownZone`] when the card prices no bands for the
///   parcel's zone.
/// - [`QuoteError::Overweight`] when the parcel is heavier than the zone's
///   largest band.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_with(&EnvRateCardFile, parcel)
}

/// Price a parcel against a rate card from `source`.
///
/// [`quote`] is this function wired to the deployed card; take this one to
/// price against a card you supply.
///
/// # Errors
///
/// The same failures as [`quote`], with
/// [`QuoteError::RateCardUnavailable`] standing for any failure of `source`.
pub fn quote_with<S>(source: &S, parcel: &Parcel) -> Result<Quote, QuoteError>
where
    S: RateCardSource + ?Sized,
{
    let span = tracing::info_span!(
        "quote",
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = tracing::field::Empty,
        outcome = tracing::field::Empty,
    );
    let _entered = span.enter();

    let outcome = priced(source, parcel);

    match &outcome {
        Ok(quote) => {
            span.record("total_cents", quote.total_cents);
            span.record("outcome", "priced");
            tracing::info!(
                zone = %parcel.zone,
                weight_grams = parcel.weight_grams,
                base_cents = quote.base_cents,
                surcharge_cents = quote.surcharge_cents,
                total_cents = quote.total_cents,
                band_max_grams = quote.band_max_grams,
                "parcel priced"
            );
        }
        Err(error) => {
            span.record("outcome", "declined");
            tracing::warn!(
                zone = %parcel.zone,
                weight_grams = parcel.weight_grams,
                error = %error,
                "quote declined"
            );
        }
    }

    outcome
}

/// Load, parse, price. The only step here that touches the world is the load.
fn priced<S>(source: &S, parcel: &Parcel) -> Result<Quote, QuoteError>
where
    S: RateCardSource + ?Sized,
{
    let text = source.load().map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = RateCard::parse(&text)?;
    pricing::price(&card, parcel)
}

#[cfg(test)]
mod tests {
    use super::{quote_with, InMemoryRateCard, Parcel, QuoteError};

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_owned(),
        }
    }

    #[test]
    fn prices_a_parcel_from_the_card_the_source_supplies() {
        let quote =
            quote_with(&InMemoryRateCard::new(CARD), &parcel(1200, "domestic")).expect("priced");

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn a_source_with_no_card_leaves_the_rate_card_unavailable() {
        assert_eq!(
            quote_with(&InMemoryRateCard::unavailable(), &parcel(100, "domestic")),
            Err(QuoteError::RateCardUnavailable)
        );
    }

    #[test]
    fn a_malformed_card_names_the_offending_line() {
        let card = InMemoryRateCard::new("# header\ndomestic\t500\t599\ndomestic\toops\n");

        assert_eq!(
            quote_with(&card, &parcel(100, "domestic")),
            Err(QuoteError::MalformedRateCard { line: 3 })
        );
    }

    #[test]
    fn prices_through_a_boxed_source() {
        let source: Box<dyn super::RateCardSource> = Box::new(InMemoryRateCard::new(CARD));

        let quote = quote_with(source.as_ref(), &parcel(300, "domestic")).expect("priced");

        assert_eq!(quote.total_cents, 599);
    }
}
