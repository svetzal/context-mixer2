//! Turning rate-card text into bands.
//!
//! Parsing is pure: it takes the text the source produced and never touches
//! the filesystem or the environment itself.

use std::collections::BTreeMap;

use crate::error::QuoteError;

/// One priced weight band within a zone.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct Band {
    /// Upper weight this band covers, inclusive, in grams.
    pub(crate) max_grams: u32,
    /// Price of the band, before surcharges.
    pub(crate) cents: u64,
}

/// Every zone the rate card prices, each with its bands in ascending weight.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub(crate) struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

impl RateCard {
    /// Read a tab-separated rate card.
    ///
    /// Empty lines and lines beginning with `#` carry no bands and are
    /// skipped, but they still count towards the line number reported by
    /// [`QuoteError::MalformedRateCard`].
    pub(crate) fn parse(text: &str) -> Result<Self, QuoteError> {
        let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

        for (index, line) in text.lines().enumerate() {
            if line.trim().is_empty() || line.starts_with('#') {
                continue;
            }

            let (zone, band) = parse_band(line).ok_or(QuoteError::MalformedRateCard {
                line: index.saturating_add(1),
            })?;
            zones.entry(zone.to_owned()).or_default().push(band);
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(Self { zones })
    }

    /// The bands priced for `zone`, ascending, or `None` when the rate card
    /// does not mention the zone at all.
    pub(crate) fn bands(&self, zone: &str) -> Option<&[Band]> {
        self.zones.get(zone).map(Vec::as_slice)
    }
}

/// A band line is exactly three tab-separated fields whose numbers parse.
fn parse_band(line: &str) -> Option<(&str, Band)> {
    let mut fields = line.split('\t');
    let zone = fields.next()?;
    let max_grams = fields.next()?;
    let cents = fields.next()?;
    if fields.next().is_some() {
        return None;
    }

    Some((
        zone,
        Band {
            max_grams: max_grams.parse().ok()?,
            cents: cents.parse().ok()?,
        },
    ))
}

#[cfg(test)]
mod tests {
    use super::{Band, RateCard};
    use crate::error::QuoteError;

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn parsed(text: &str) -> RateCard {
        RateCard::parse(text).expect("rate card parses")
    }

    #[test]
    fn reads_the_bands_of_each_zone() {
        let card = parsed(CARD);

        assert_eq!(
            card.bands("domestic"),
            Some(
                [
                    Band {
                        max_grams: 500,
                        cents: 599
                    },
                    Band {
                        max_grams: 2000,
                        cents: 899
                    },
                    Band {
                        max_grams: 20_000,
                        cents: 1799
                    },
                ]
                .as_slice()
            )
        );
    }

    #[test]
    fn a_zone_off_the_card_has_no_bands() {
        assert_eq!(parsed(CARD).bands("lunar"), None);
    }

    #[test]
    fn orders_bands_ascending_however_the_file_lists_them() {
        let card = parsed("domestic\t20000\t1799\ndomestic\t500\t599\n");

        let ascending: Vec<u32> = card
            .bands("domestic")
            .unwrap_or_default()
            .iter()
            .map(|band| band.max_grams)
            .collect();
        assert_eq!(ascending, vec![500, 20_000]);
    }

    #[test]
    fn skips_comments_and_blank_lines() {
        let card = parsed("\n# a comment\n\ndomestic\t500\t599\n");

        assert_eq!(card.bands("domestic").map(<[Band]>::len), Some(1));
    }

    #[test]
    fn a_short_line_is_malformed_at_its_own_line_number() {
        assert_eq!(
            RateCard::parse("# header\n\ndomestic\t500\n"),
            Err(QuoteError::MalformedRateCard { line: 3 })
        );
    }

    #[test]
    fn a_fourth_field_is_malformed() {
        assert_eq!(
            RateCard::parse("domestic\t500\t599\textra\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn a_field_separated_by_spaces_is_malformed() {
        assert_eq!(
            RateCard::parse("domestic 500 599\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn a_number_that_does_not_parse_is_malformed() {
        assert_eq!(
            RateCard::parse("domestic\theavy\t599\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(
            RateCard::parse("domestic\t500\t5.99\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(
            RateCard::parse("domestic\t500\t-599\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn reports_the_first_offending_line_only() {
        assert_eq!(
            RateCard::parse("domestic\t500\t599\nbad line\nalso\tbad\n"),
            Err(QuoteError::MalformedRateCard { line: 2 })
        );
    }

    #[test]
    fn an_empty_card_prices_nothing() {
        assert_eq!(parsed(""), RateCard::default());
    }

    #[test]
    fn a_final_line_without_a_newline_still_counts() {
        assert_eq!(parsed("domestic\t500\t599").bands("domestic").map(<[Band]>::len), Some(1));
    }
}
