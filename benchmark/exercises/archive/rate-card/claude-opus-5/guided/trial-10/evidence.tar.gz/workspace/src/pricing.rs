//! What a parcel costs, given a rate card.
//!
//! This is the whole pricing policy, and it is a pure function of a parsed
//! rate card and a parcel.

use crate::error::QuoteError;
use crate::model::{Parcel, Quote};
use crate::rate_card::RateCard;

/// Weight above which a parcel is heavy enough to surcharge, in grams.
const HEAVY_ABOVE_GRAMS: u32 = 10_000;
/// Flat surcharge applied to a heavy parcel.
const HEAVY_SURCHARGE_CENTS: u64 = 500;
/// The zone that carries a proportional surcharge.
const INTERNATIONAL_ZONE: &str = "international";
/// Percentage of the base price added for [`INTERNATIONAL_ZONE`].
const INTERNATIONAL_PERCENT: u128 = 20;

/// Price `parcel` against `card`.
pub(crate) fn price(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = card
        .bands(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band =
        bands.iter().find(|band| band.max_grams >= parcel.weight_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands.last().map_or(0, |band| band.max_grams),
            }
        })?;

    let base_cents = band.cents;
    let surcharge_cents = heavy_surcharge(parcel.weight_grams)
        .saturating_add(zone_surcharge(&parcel.zone, base_cents));

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    })
}

/// Parcels strictly above [`HEAVY_ABOVE_GRAMS`] carry a flat surcharge.
fn heavy_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > HEAVY_ABOVE_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    }
}

/// International parcels carry a percentage of their base price, rounded
/// half-up to the cent.
fn zone_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone != INTERNATIONAL_ZONE {
        return 0;
    }
    percent_of_cents(base_cents, INTERNATIONAL_PERCENT)
}

/// `percent` of `cents`, rounded half-up.
///
/// The arithmetic widens so that a rate card carrying an implausible price
/// saturates rather than wrapping.
fn percent_of_cents(cents: u64, percent: u128) -> u64 {
    let scaled = u128::from(cents).saturating_mul(percent).saturating_add(50);
    u64::try_from(scaled / 100).unwrap_or(u64::MAX)
}

#[cfg(test)]
mod tests {
    use super::{percent_of_cents, price};
    use crate::error::QuoteError;
    use crate::model::Parcel;
    use crate::rate_card::RateCard;

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn card() -> RateCard {
        RateCard::parse(CARD).expect("rate card parses")
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_owned(),
        }
    }

    #[test]
    fn prices_from_the_first_band_that_covers_the_weight() {
        let quote = price(&card(), &parcel(300, "domestic")).expect("priced");

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
    }

    #[test]
    fn a_weight_exactly_on_a_threshold_stays_in_that_band() {
        let quote = price(&card(), &parcel(500, "domestic")).expect("priced");

        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.base_cents, 599);
    }

    #[test]
    fn a_gram_over_a_threshold_moves_up_a_band() {
        let quote = price(&card(), &parcel(501, "domestic")).expect("priced");

        assert_eq!(quote.band_max_grams, 2000);
        assert_eq!(quote.base_cents, 899);
    }

    #[test]
    fn a_weightless_parcel_takes_the_smallest_band() {
        let quote = price(&card(), &parcel(0, "domestic")).expect("priced");

        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn weight_above_ten_kilos_adds_a_flat_surcharge() {
        let quote = price(&card(), &parcel(10_001, "domestic")).expect("priced");

        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn exactly_ten_kilos_is_not_heavy() {
        let quote = price(&card(), &parcel(10_000, "domestic")).expect("priced");

        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn international_adds_a_fifth_of_the_base_rounded_half_up() {
        // 20% of 1499 is 299.8, which rounds up to 300.
        let quote = price(&card(), &parcel(400, "international")).expect("priced");

        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn surcharges_add_together() {
        // 20% of 4999 is 999.8 -> 1000, plus the 500 heavy surcharge.
        let quote = price(&card(), &parcel(15_000, "international")).expect("priced");

        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20_000);
    }

    #[test]
    fn rounds_a_half_cent_up() {
        // 20% of 2500 is exactly 500, and of 2502 is 500.4 -> 500.
        assert_eq!(percent_of_cents(2500, 20), 500);
        assert_eq!(percent_of_cents(2502, 20), 500);
        // 20% of 2503 is 500.6 -> 501, and of 5 is 1.0 -> 1.
        assert_eq!(percent_of_cents(2503, 20), 501);
        assert_eq!(percent_of_cents(5, 20), 1);
        // An exact half cent goes up, not to even: 50% of 5 is 2.5 -> 3.
        assert_eq!(percent_of_cents(5, 50), 3);
    }

    #[test]
    fn an_absurd_price_saturates_rather_than_wrapping() {
        assert_eq!(percent_of_cents(u64::MAX, 20), u64::MAX / 5);
        assert_eq!(percent_of_cents(u64::MAX, 100_000_000_000), u64::MAX);
    }

    #[test]
    fn a_zone_off_the_card_is_unknown() {
        assert_eq!(
            price(&card(), &parcel(100, "lunar")),
            Err(QuoteError::UnknownZone("lunar".to_owned()))
        );
    }

    #[test]
    fn the_zone_is_matched_exactly() {
        assert_eq!(
            price(&card(), &parcel(100, "Domestic")),
            Err(QuoteError::UnknownZone("Domestic".to_owned()))
        );
    }

    #[test]
    fn a_parcel_past_the_largest_band_is_overweight() {
        assert_eq!(
            price(&card(), &parcel(20_001, "domestic")),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            })
        );
    }

    #[test]
    fn overweight_reports_the_limit_of_the_requested_zone() {
        let card = RateCard::parse("domestic\t20000\t1799\nexpress\t1000\t2999\n")
            .expect("rate card parses");

        assert_eq!(
            price(&card, &parcel(1500, "express")),
            Err(QuoteError::Overweight {
                grams: 1500,
                limit: 1000
            })
        );
    }
}
