//! Why a quote could not be produced.

use std::fmt;

/// Every way [`quote`](crate::quote) can decline to price a parcel.
///
/// Callers are expected to match on these, so each variant carries the detail
/// needed to report or recover without re-reading the rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card could not be located or read at all.
    RateCardUnavailable,
    /// A rate-card line was not three tab-separated fields, or its numbers did
    /// not parse. Carries the 1-based line number, counting comments and
    /// blank lines.
    MalformedRateCard {
        /// 1-based line number of the offending line.
        line: usize,
    },
    /// The requested zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight {
        /// Weight of the parcel presented, in grams.
        grams: u32,
        /// Largest `band_max_grams` the zone prices, in grams.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => f.write_str("rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone `{zone}`"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel of {grams}g exceeds the zone limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[cfg(test)]
mod tests {
    use super::QuoteError;

    #[test]
    fn each_variant_names_its_own_detail() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 4 }.to_string(),
            "malformed rate card at line 4"
        );
        assert_eq!(QuoteError::UnknownZone("lunar".to_owned()).to_string(), "unknown zone `lunar`");
        assert_eq!(
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000
            }
            .to_string(),
            "parcel of 25000g exceeds the zone limit of 20000g"
        );
    }

    #[test]
    fn is_usable_as_a_boxed_std_error() {
        let boxed: Box<dyn std::error::Error> = Box::new(QuoteError::RateCardUnavailable);
        assert_eq!(boxed.to_string(), "rate card unavailable");
    }
}
