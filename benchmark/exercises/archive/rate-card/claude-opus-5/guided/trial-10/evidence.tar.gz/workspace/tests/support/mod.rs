//! Shared fixtures for the integration tests.
//!
//! The recorder here is a fake operator: it collects the diagnostic records a
//! quote emits so a test can query them by field, the way a log backend
//! would.

// Each test binary compiles this module and uses part of it.
#![allow(dead_code, unreachable_pub)]

use std::collections::HashMap;
use std::fmt;
use std::sync::{Arc, Mutex, MutexGuard, PoisonError};

use tracing::field::{Field, Visit};
use tracing::span::{Attributes, Id, Record};
use tracing::{Event, Subscriber};
use tracing_subscriber::layer::{Context, Layer, SubscriberExt};
use tracing_subscriber::registry::{LookupSpan, Registry};

/// The rate card from the crate's README, in the file's own format.
pub const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

/// The fields of one diagnostic record, as an operator would query them.
pub type Fields = HashMap<String, String>;

/// Collects the spans and events emitted while it is installed.
#[derive(Clone, Default)]
pub struct Recorder {
    events: Arc<Mutex<Vec<Fields>>>,
    spans: Arc<Mutex<Vec<(String, Fields)>>>,
}

impl Recorder {
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Run `body` with this recorder collecting diagnostics on this thread.
    pub fn capturing<T>(&self, body: impl FnOnce() -> T) -> T {
        let subscriber = Registry::default().with(self.clone());
        tracing::subscriber::with_default(subscriber, body)
    }

    /// Every event recorded, in the order they were emitted.
    #[must_use]
    pub fn events(&self) -> Vec<Fields> {
        lock(&self.events).clone()
    }

    /// The first event carrying `field`.
    #[must_use]
    pub fn event_with(&self, field: &str) -> Option<Fields> {
        self.events().into_iter().find(|event| event.contains_key(field))
    }

    /// Every span that closed, with the fields it ended up carrying.
    #[must_use]
    pub fn spans(&self) -> Vec<(String, Fields)> {
        lock(&self.spans).clone()
    }
}

impl<S> Layer<S> for Recorder
where
    S: Subscriber + for<'a> LookupSpan<'a>,
{
    fn on_new_span(&self, attrs: &Attributes<'_>, id: &Id, ctx: Context<'_, S>) {
        let mut fields = Fields::new();
        attrs.record(&mut Collector(&mut fields));
        if let Some(span) = ctx.span(id) {
            span.extensions_mut().insert(Recorded(fields));
        }
    }

    fn on_record(&self, id: &Id, values: &Record<'_>, ctx: Context<'_, S>) {
        if let Some(span) = ctx.span(id) {
            let mut extensions = span.extensions_mut();
            if let Some(Recorded(fields)) = extensions.get_mut::<Recorded>() {
                values.record(&mut Collector(fields));
            }
        }
    }

    fn on_event(&self, event: &Event<'_>, _ctx: Context<'_, S>) {
        let mut fields = Fields::new();
        event.record(&mut Collector(&mut fields));
        lock(&self.events).push(fields);
    }

    fn on_close(&self, id: Id, ctx: Context<'_, S>) {
        if let Some(span) = ctx.span(&id) {
            let name = span.name().to_owned();
            if let Some(Recorded(fields)) = span.extensions().get::<Recorded>() {
                lock(&self.spans).push((name, fields.clone()));
            }
        }
    }
}

/// The fields a span has accumulated, kept alongside it until it closes.
struct Recorded(Fields);

/// Renders field values the way a structured backend would store them.
struct Collector<'a>(&'a mut Fields);

impl Collector<'_> {
    fn set(&mut self, field: &Field, value: String) {
        self.0.insert(field.name().to_owned(), value);
    }
}

impl Visit for Collector<'_> {
    fn record_str(&mut self, field: &Field, value: &str) {
        self.set(field, value.to_owned());
    }

    fn record_u64(&mut self, field: &Field, value: u64) {
        self.set(field, value.to_string());
    }

    fn record_i64(&mut self, field: &Field, value: i64) {
        self.set(field, value.to_string());
    }

    fn record_bool(&mut self, field: &Field, value: bool) {
        self.set(field, value.to_string());
    }

    fn record_debug(&mut self, field: &Field, value: &dyn fmt::Debug) {
        self.set(field, format!("{value:?}"));
    }
}

/// A test holding a poisoned lock has already failed; carry on regardless.
fn lock<T>(mutex: &Mutex<T>) -> MutexGuard<'_, T> {
    mutex.lock().unwrap_or_else(PoisonError::into_inner)
}
