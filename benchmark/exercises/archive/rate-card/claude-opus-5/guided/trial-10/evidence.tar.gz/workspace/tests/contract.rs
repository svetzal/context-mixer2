//! The shape an outside caller depends on: the names, the fields it reads
//! directly, and the variants it matches without a catch-all arm.

// A test that cannot get its fixture should say so and stop.
#![allow(clippy::expect_used, clippy::unwrap_used, clippy::panic)]

use std::error::Error;
use std::fmt::Display;

use ratecard::{quote, Parcel, Quote, QuoteError};

#[test]
fn quote_has_the_published_signature() {
    let published: fn(&Parcel) -> Result<Quote, QuoteError> = quote;

    // Calling it without a deployed card is the one outcome that needs no
    // fixture, whatever the ambient environment happens to hold.
    let parcel = Parcel {
        weight_grams: 100,
        zone: "domestic".to_owned(),
    };
    match published(&parcel) {
        Ok(_) | Err(_) => (),
    }
}

#[test]
fn a_quote_exposes_its_parts_as_public_fields() {
    let quote = Quote {
        base_cents: 599,
        surcharge_cents: 0,
        total_cents: 599,
        band_max_grams: 500,
    };

    assert_eq!(
        quote.base_cents + quote.surcharge_cents,
        quote.total_cents,
        "a quote's parts add up to its total"
    );
    assert_eq!(quote.band_max_grams, 500);
}

#[test]
fn every_failure_can_be_matched_without_a_catch_all_arm() {
    let failures = [
        QuoteError::RateCardUnavailable,
        QuoteError::MalformedRateCard { line: 7 },
        QuoteError::UnknownZone("lunar".to_owned()),
        QuoteError::Overweight {
            grams: 25_000,
            limit: 20_000,
        },
    ];

    let described: Vec<String> = failures
        .iter()
        .map(|failure| match failure {
            QuoteError::RateCardUnavailable => "unavailable".to_owned(),
            QuoteError::MalformedRateCard { line } => format!("line {line}"),
            QuoteError::UnknownZone(zone) => zone.clone(),
            QuoteError::Overweight { grams, limit } => format!("{grams} over {limit}"),
        })
        .collect();

    assert_eq!(described, ["unavailable", "line 7", "lunar", "25000 over 20000"]);
}

#[test]
fn a_failure_is_a_standard_error() {
    fn assert_reportable<E: Error + Display>(_: &E) {}

    assert_reportable(&QuoteError::RateCardUnavailable);
}
