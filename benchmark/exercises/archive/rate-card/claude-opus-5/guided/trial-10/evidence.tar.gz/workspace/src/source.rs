//! Where rate-card text comes from.
//!
//! Everything that touches the environment or the filesystem lives behind
//! [`RateCardSource`], so pricing itself never performs I/O and tests can
//! substitute a card without writing files.

use std::fmt;

/// Environment variable naming the rate-card file.
pub const RATECARD_PATH_VAR: &str = "RATECARD_PATH";

/// A source could not produce the rate card.
///
/// The reason stays with the source, which reports it as a diagnostic; the
/// caller only learns that no card is available.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct RateCardUnavailable;

impl fmt::Display for RateCardUnavailable {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("rate card unavailable")
    }
}

impl std::error::Error for RateCardUnavailable {}

/// Somewhere rate-card text can be fetched from.
///
/// This is the crate's own contract at the I/O edge; implement it to price
/// against a card that does not live in a file.
pub trait RateCardSource {
    /// Fetch the rate card as text.
    ///
    /// # Errors
    ///
    /// Returns [`RateCardUnavailable`] when the card cannot be reached or
    /// read.
    fn load(&self) -> Result<String, RateCardUnavailable>;
}

impl<T: RateCardSource + ?Sized> RateCardSource for &T {
    fn load(&self) -> Result<String, RateCardUnavailable> {
        (**self).load()
    }
}

/// Reads the rate card from the file named by `RATECARD_PATH`.
#[derive(Debug, Clone, Copy, Default)]
pub struct EnvRateCardFile;

impl RateCardSource for EnvRateCardFile {
    fn load(&self) -> Result<String, RateCardUnavailable> {
        let Some(path) = std::env::var_os(RATECARD_PATH_VAR) else {
            tracing::warn!(variable = RATECARD_PATH_VAR, reason = "unset", "rate card unavailable");
            return Err(RateCardUnavailable);
        };

        std::fs::read_to_string(&path).map_err(|error| {
            tracing::warn!(
                variable = RATECARD_PATH_VAR,
                path = %std::path::Path::new(&path).display(),
                reason = %error,
                "rate card unavailable"
            );
            RateCardUnavailable
        })
    }
}

/// A rate card held in memory, for tests and callers that carry their own
/// card text.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct InMemoryRateCard {
    text: Option<String>,
}

impl InMemoryRateCard {
    /// A source that hands back `text`.
    #[must_use]
    pub fn new(text: impl Into<String>) -> Self {
        Self {
            text: Some(text.into()),
        }
    }

    /// A source that behaves as though no rate card were deployed.
    #[must_use]
    pub const fn unavailable() -> Self {
        Self { text: None }
    }
}

impl RateCardSource for InMemoryRateCard {
    fn load(&self) -> Result<String, RateCardUnavailable> {
        self.text.clone().ok_or(RateCardUnavailable)
    }
}

#[cfg(test)]
mod tests {
    use super::{InMemoryRateCard, RateCardSource, RateCardUnavailable};

    #[test]
    fn an_in_memory_card_hands_back_its_text() {
        let source = InMemoryRateCard::new("domestic\t500\t599\n");

        assert_eq!(source.load(), Ok("domestic\t500\t599\n".to_owned()));
    }

    #[test]
    fn an_undeployed_card_is_unavailable() {
        assert_eq!(InMemoryRateCard::unavailable().load(), Err(RateCardUnavailable));
    }

    #[test]
    fn a_reference_to_a_source_is_itself_a_source() {
        let source = InMemoryRateCard::new("domestic\t500\t599\n");
        let by_reference: &dyn RateCardSource = &source;

        assert_eq!(by_reference.load(), source.load());
    }
}
