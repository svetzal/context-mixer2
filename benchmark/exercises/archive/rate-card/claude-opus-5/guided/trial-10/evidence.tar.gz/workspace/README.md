# ratecard

Shipping quotes for the fulfilment service.

Warehouse operators price outbound parcels against a rate card that operations
maintains and redeploys without a code change. This crate owns reading that card
and turning a parcel into a quote.

## Using it

Point `RATECARD_PATH` at the deployed card and call `quote`:

```rust
use ratecard::{quote, Parcel};

let parcel = Parcel { weight_grams: 1200, zone: "domestic".to_owned() };
match quote(&parcel) {
    Ok(quote) => println!("{} cents", quote.total_cents),
    Err(error) => eprintln!("no quote: {error}"),
}
```

The card is tab-separated, one band per line; blank lines and lines starting
with `#` are ignored.

```text
# zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
domestic	20000	1799
international	500	1499
international	20000	4999
```

A parcel is priced by the first band, ascending, whose `band_max_grams` covers
its weight. Surcharges then add together: 500 cents above 10 kg, and 20% of the
base price for `international`, rounded half-up.

Pricing is pure — reading the card is the only step that touches the world.
`quote_with` takes any `RateCardSource`, so a caller (or a test) can price
against a card it supplies rather than one on disk.

## Development

```bash
cargo test
cargo clippy --all-targets
cargo doc --no-deps
```
