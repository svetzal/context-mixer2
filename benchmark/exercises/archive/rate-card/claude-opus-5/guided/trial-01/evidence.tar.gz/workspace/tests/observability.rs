//! Every quote must be visible to an operator afterwards.
//!
//! These tests attach a recording subscriber and assert on the fields a call
//! leaves behind, rather than on formatted message text.

// A missing diagnostic record is a test failure, and a failure here should
// print what *was* recorded; the crate's no-panic standard is about library
// code.
#![allow(clippy::expect_used, clippy::panic)]

use std::collections::BTreeMap;
use std::fmt;
use std::sync::{Arc, Mutex};

use ratecard::{quote_from, Parcel, RateCardSource, RateCardUnavailable};
use tracing::field::{Field, Visit};
use tracing::subscriber::with_default;
use tracing_subscriber::layer::{Context, Layer};
use tracing_subscriber::prelude::*;
use tracing_subscriber::registry::LookupSpan;

const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
                      domestic\t500\t599\n\
                      international\t20000\t4999\n";

struct Fixture(&'static str);

impl RateCardSource for Fixture {
    fn load(&self) -> Result<String, RateCardUnavailable> {
        Ok(self.0.to_owned())
    }
}

/// One diagnostic record: a name plus the fields carried with it.
#[derive(Debug, Clone)]
struct Record {
    name: String,
    fields: BTreeMap<String, String>,
}

impl Record {
    fn field(&self, key: &str) -> Option<&str> {
        self.fields.get(key).map(String::as_str)
    }
}

/// Collects field values as strings, whatever their underlying type.
#[derive(Default)]
struct Fields(BTreeMap<String, String>);

impl Visit for Fields {
    fn record_debug(&mut self, field: &Field, value: &dyn fmt::Debug) {
        self.0.insert(field.name().to_owned(), format!("{value:?}"));
    }

    fn record_str(&mut self, field: &Field, value: &str) {
        self.0.insert(field.name().to_owned(), value.to_owned());
    }

    fn record_u64(&mut self, field: &Field, value: u64) {
        self.0.insert(field.name().to_owned(), value.to_string());
    }

    fn record_i64(&mut self, field: &Field, value: i64) {
        self.0.insert(field.name().to_owned(), value.to_string());
    }
}

/// An in-memory subscriber layer standing in for the operator's log pipeline.
#[derive(Default, Clone)]
struct Recorder {
    events: Arc<Mutex<Vec<Record>>>,
    spans: Arc<Mutex<Vec<(u64, Record)>>>,
}

impl Recorder {
    fn events(&self) -> Vec<Record> {
        match self.events.lock() {
            Ok(events) => events.clone(),
            Err(poisoned) => poisoned.into_inner().clone(),
        }
    }

    fn spans(&self) -> Vec<Record> {
        match self.spans.lock() {
            Ok(spans) => spans.iter().map(|(_, record)| record.clone()).collect(),
            Err(poisoned) => poisoned
                .into_inner()
                .iter()
                .map(|(_, record)| record.clone())
                .collect(),
        }
    }
}

impl<S> Layer<S> for Recorder
where
    S: tracing::Subscriber + for<'a> LookupSpan<'a>,
{
    fn on_new_span(&self, attrs: &tracing::span::Attributes<'_>, id: &tracing::Id, _: Context<'_, S>) {
        let mut fields = Fields::default();
        attrs.record(&mut fields);
        if let Ok(mut spans) = self.spans.lock() {
            spans.push((
                id.into_u64(),
                Record {
                    name: attrs.metadata().name().to_owned(),
                    fields: fields.0,
                },
            ));
        }
    }

    fn on_record(&self, id: &tracing::Id, values: &tracing::span::Record<'_>, _: Context<'_, S>) {
        let mut fields = Fields::default();
        values.record(&mut fields);
        if let Ok(mut spans) = self.spans.lock() {
            if let Some((_, record)) = spans.iter_mut().find(|(key, _)| *key == id.into_u64()) {
                record.fields.extend(fields.0);
            }
        }
    }

    fn on_event(&self, event: &tracing::Event<'_>, _: Context<'_, S>) {
        let mut fields = Fields::default();
        event.record(&mut fields);
        let name = fields
            .0
            .get("message")
            .cloned()
            .unwrap_or_else(|| event.metadata().name().to_owned());
        if let Ok(mut events) = self.events.lock() {
            events.push(Record {
                name,
                fields: fields.0,
            });
        }
    }
}

/// Runs `body` with a recording subscriber installed for the current thread.
fn recording<T>(body: impl FnOnce() -> T) -> (T, Recorder) {
    let recorder = Recorder::default();
    let subscriber = tracing_subscriber::registry().with(recorder.clone());
    let outcome = with_default(subscriber, body);
    (outcome, recorder)
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_owned(),
    }
}

#[test]
fn a_priced_parcel_leaves_zone_weight_and_total_behind() {
    let (priced, recorder) = recording(|| quote_from(&Fixture(SAMPLE), &parcel(480, "domestic")));

    assert!(priced.is_ok(), "expected a quote, got {priced:?}");
    let events = recorder.events();
    let record = events
        .iter()
        .find(|record| record.name == "parcel priced")
        .unwrap_or_else(|| panic!("no priced record among {events:?}"));

    assert_eq!(record.field("zone"), Some("domestic"));
    assert_eq!(record.field("weight_grams"), Some("480"));
    assert_eq!(record.field("total_cents"), Some("599"));
}

#[test]
fn each_call_emits_exactly_one_record() {
    let ((), recorder) = recording(|| {
        let source = Fixture(SAMPLE);
        let _ = quote_from(&source, &parcel(100, "domestic"));
        let _ = quote_from(&source, &parcel(200, "domestic"));
    });

    let priced = recorder
        .events()
        .into_iter()
        .filter(|record| record.name == "parcel priced")
        .count();

    assert_eq!(priced, 2);
}

#[test]
fn a_quote_is_correlated_by_a_span_carrying_its_outcome() {
    let (_, recorder) = recording(|| quote_from(&Fixture(SAMPLE), &parcel(15_000, "international")));

    let spans = recorder.spans();
    let span = spans
        .iter()
        .find(|record| record.name == "quote")
        .unwrap_or_else(|| panic!("no quote span among {spans:?}"));

    assert_eq!(span.field("zone"), Some("international"));
    assert_eq!(span.field("weight_grams"), Some("15000"));
    assert_eq!(span.field("total_cents"), Some("6499"));
    assert_eq!(span.field("outcome"), Some("priced"));
}

#[test]
fn a_failed_quote_is_observable_with_its_reason() {
    let (_, recorder) = recording(|| quote_from(&Fixture(SAMPLE), &parcel(100, "orbital")));

    let events = recorder.events();
    let record = events
        .iter()
        .find(|record| record.name == "parcel not priced")
        .unwrap_or_else(|| panic!("no failure record among {events:?}"));

    assert_eq!(record.field("zone"), Some("orbital"));
    assert_eq!(record.field("weight_grams"), Some("100"));
    assert_eq!(record.field("outcome"), Some("unknown_zone"));
    assert_eq!(record.field("error"), Some("unknown zone `orbital`"));
}
