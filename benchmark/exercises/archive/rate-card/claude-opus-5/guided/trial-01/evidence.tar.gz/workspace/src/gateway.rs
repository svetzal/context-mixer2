//! The edge where rate-card text comes from.
//!
//! [`RateCardSource`] is the crate's own contract, so pricing never names a
//! filesystem or an environment variable. [`EnvRateCardSource`] is the
//! production adapter; tests supply their own implementations rather than
//! standing up files.

use std::env;
use std::fs;
use std::path::PathBuf;

/// Environment variable naming the rate-card file.
pub const RATECARD_PATH_VAR: &str = "RATECARD_PATH";

/// A rate card could not be obtained.
///
/// The `detail` is for operators reading logs; callers see only
/// [`QuoteError::RateCardUnavailable`](crate::QuoteError::RateCardUnavailable).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RateCardUnavailable {
    /// Human-readable reason, safe to log.
    pub detail: String,
}

impl RateCardUnavailable {
    /// Builds an unavailability with the given reason.
    pub fn new(detail: impl Into<String>) -> Self {
        Self {
            detail: detail.into(),
        }
    }
}

/// Supplies the raw text of a rate card.
///
/// # Examples
///
/// ```
/// use ratecard::{quote_from, Parcel, RateCardSource, RateCardUnavailable};
///
/// struct Fixed(&'static str);
///
/// impl RateCardSource for Fixed {
///     fn load(&self) -> Result<String, RateCardUnavailable> {
///         Ok(self.0.to_owned())
///     }
/// }
///
/// let source = Fixed("domestic\t500\t599\n");
/// let parcel = Parcel { weight_grams: 250, zone: "domestic".to_owned() };
///
/// assert_eq!(quote_from(&source, &parcel)?.total_cents, 599);
/// # Ok::<(), ratecard::QuoteError>(())
/// ```
pub trait RateCardSource {
    /// Reads the rate card, or explains why it is unavailable.
    ///
    /// # Errors
    ///
    /// Returns [`RateCardUnavailable`] when the card cannot be located or read.
    fn load(&self) -> Result<String, RateCardUnavailable>;
}

/// Reads the rate card from the file named by `RATECARD_PATH`.
#[derive(Debug, Clone, Copy, Default)]
pub struct EnvRateCardSource;

impl RateCardSource for EnvRateCardSource {
    fn load(&self) -> Result<String, RateCardUnavailable> {
        let path = env::var_os(RATECARD_PATH_VAR).map(PathBuf::from).ok_or_else(|| {
            RateCardUnavailable::new(format!("{RATECARD_PATH_VAR} is not set"))
        })?;

        fs::read_to_string(&path).map_err(|error| {
            RateCardUnavailable::new(format!("{} could not be read: {error}", path.display()))
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn describes_the_variable_it_expects() {
        assert_eq!(RATECARD_PATH_VAR, "RATECARD_PATH");
        assert_eq!(
            RateCardUnavailable::new("nope"),
            RateCardUnavailable {
                detail: "nope".to_owned()
            }
        );
    }
}
