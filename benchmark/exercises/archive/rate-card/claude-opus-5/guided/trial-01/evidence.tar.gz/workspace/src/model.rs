//! The vocabulary a caller quotes against: a parcel, a quote, and the ways
//! quoting can fail.
//!
//! These types are plain data with no I/O of their own, so the pricing rules
//! that consume them stay testable without a rate-card file.

use std::error::Error;
use std::fmt;

/// A parcel awaiting a price.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Billable weight of the parcel, in grams.
    pub weight_grams: u32,
    /// Destination zone, matched verbatim against the rate card.
    pub zone: String,
}

/// The priced outcome for a parcel.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quote {
    /// The matching band's price, before surcharges.
    pub base_cents: u64,
    /// Everything added on top of the band price.
    pub surcharge_cents: u64,
    /// `base_cents` plus `surcharge_cents`.
    pub total_cents: u64,
    /// Upper weight bound of the band that priced this parcel, in grams.
    pub band_max_grams: u32,
}

/// Why a parcel could not be priced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card could not be located or read.
    RateCardUnavailable,
    /// A rate-card line was not three tab-separated fields, or its numbers did
    /// not parse.
    MalformedRateCard {
        /// 1-based line number of the offending line, counting comments and
        /// blank lines.
        line: usize,
    },
    /// The requested zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel weighs more than the heaviest band for its zone.
    Overweight {
        /// The parcel's weight, in grams.
        grams: u32,
        /// The heaviest band available for the zone, in grams.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone `{zone}`"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel of {grams}g exceeds the {limit}g limit for its zone")
            }
        }
    }
}

impl Error for QuoteError {}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn displays_each_failure_readably() {
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "rate card unavailable"
        );
        assert_eq!(
            QuoteError::MalformedRateCard { line: 7 }.to_string(),
            "malformed rate card at line 7"
        );
        assert_eq!(
            QuoteError::UnknownZone("lunar".into()).to_string(),
            "unknown zone `lunar`"
        );
        assert_eq!(
            QuoteError::Overweight {
                grams: 21_000,
                limit: 20_000,
            }
            .to_string(),
            "parcel of 21000g exceeds the 20000g limit for its zone"
        );
    }

    #[test]
    fn is_usable_as_a_boxed_std_error() {
        let boxed: Box<dyn Error> = Box::new(QuoteError::RateCardUnavailable);
        assert_eq!(boxed.to_string(), "rate card unavailable");
    }
}
