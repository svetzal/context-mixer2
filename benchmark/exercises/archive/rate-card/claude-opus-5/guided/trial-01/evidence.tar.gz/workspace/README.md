# ratecard

Shipping quotes for the fulfilment service.

Warehouse operators price outbound parcels against a rate card that operations
maintains and redeploys without a code change. This crate owns reading that card
and turning a parcel into a quote.

## Using it

`RATECARD_PATH` names the deployed rate card. Each call re-reads it, so a
redeployed card takes effect without a restart.

```rust
use ratecard::{quote, Parcel};

let parcel = Parcel { weight_grams: 750, zone: "domestic".to_owned() };
let quote = quote(&parcel)?;

println!("{} cents", quote.total_cents);
```

Failures come back as `QuoteError`: an unreadable or unset `RATECARD_PATH`, a
malformed line (carrying its 1-based number), an unknown zone, or a parcel past
the zone's heaviest band.

To price against something other than a file — a fixture, a config service —
implement `RateCardSource` and call `quote_from`.

## The rate card

Tab-separated, one band per line. Blank lines and lines starting with `#` are
ignored.

```text
# zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
domestic	20000	1799
international	500	1499
international	20000	4999
```

A parcel is priced by the first band, ascending, whose `band_max_grams` is at
least its weight. On top of that band price: 500 cents for anything above
10000 g, and 20% of the base (rounded half-up) for `international`.

## Observability

Every call opens a `quote` span carrying `zone`, `weight_grams`, `total_cents`,
and `outcome`, and emits one event per call with the same fields. Install any
`tracing` subscriber to collect them.

## Development

```bash
cargo test
cargo clippy --all-targets
cargo doc --no-deps
```
