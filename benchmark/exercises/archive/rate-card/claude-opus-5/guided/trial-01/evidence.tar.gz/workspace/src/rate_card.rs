//! Turning rate-card text into bands, and finding the band that prices a
//! parcel.
//!
//! Everything here is a pure function of the text it is handed. Where that text
//! came from — a file, a fixture, a test string — is the shell's problem.

use std::collections::BTreeMap;

use crate::model::QuoteError;

/// One priced weight band within a zone.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct Band {
    /// Inclusive upper weight bound of the band, in grams.
    pub(crate) max_grams: u32,
    /// The band's price, before surcharges.
    pub(crate) cents: u64,
}

/// The parsed rate card: bands per zone, each zone's bands in ascending
/// `max_grams` order.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub(crate) struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

impl RateCard {
    /// Parses tab-separated rate-card text.
    ///
    /// Empty lines and lines beginning with `#` are ignored. Every other line
    /// must be exactly three tab-separated fields — zone, band maximum in
    /// grams, price in cents — or parsing fails with the 1-based number of the
    /// offending line, counted across every line in the text.
    pub(crate) fn parse(text: &str) -> Result<Self, QuoteError> {
        let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

        for (index, line) in text.lines().enumerate() {
            let line_number = index.saturating_add(1);
            let trimmed = line.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }

            let (zone, band) = parse_band_line(line)
                .ok_or(QuoteError::MalformedRateCard { line: line_number })?;
            zones.entry(zone).or_default().push(band);
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(Self { zones })
    }

    /// Finds the band that prices `weight_grams` in `zone`.
    ///
    /// The match is the first band, ascending, whose maximum is at least the
    /// parcel's weight. A zone with no bands is [`QuoteError::UnknownZone`]; a
    /// weight past the heaviest band is [`QuoteError::Overweight`].
    pub(crate) fn band_for(&self, zone: &str, weight_grams: u32) -> Result<Band, QuoteError> {
        let bands = self
            .zones
            .get(zone)
            .ok_or_else(|| QuoteError::UnknownZone(zone.to_owned()))?;

        bands
            .iter()
            .find(|band| band.max_grams >= weight_grams)
            .copied()
            .ok_or_else(|| {
                let limit = bands.iter().map(|band| band.max_grams).max().unwrap_or(0);
                QuoteError::Overweight {
                    grams: weight_grams,
                    limit,
                }
            })
    }
}

/// Reads one non-comment line, or `None` if it is not a well-formed band.
///
/// Fields are trimmed before parsing so that stray carriage returns or padding
/// do not masquerade as malformed numbers, but the field *count* is taken from
/// the raw tab split: three fields exactly, no more, no fewer.
fn parse_band_line(line: &str) -> Option<(String, Band)> {
    let mut fields = line.split('\t');
    let zone = fields.next()?.trim();
    let max_grams = fields.next()?.trim();
    let cents = fields.next()?.trim();
    if fields.next().is_some() || zone.is_empty() {
        return None;
    }

    Some((
        zone.to_owned(),
        Band {
            max_grams: max_grams.parse().ok()?,
            cents: cents.parse().ok()?,
        },
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
                          domestic\t500\t599\n\
                          domestic\t2000\t899\n\
                          domestic\t20000\t1799\n\
                          international\t500\t1499\n\
                          international\t20000\t4999\n";

    fn sample() -> RateCard {
        match RateCard::parse(SAMPLE) {
            Ok(card) => card,
            Err(error) => unreachable!("sample rate card should parse: {error}"),
        }
    }

    #[test]
    fn matches_the_first_band_at_or_above_the_weight() {
        let card = sample();
        assert_eq!(
            card.band_for("domestic", 600),
            Ok(Band {
                max_grams: 2000,
                cents: 899
            })
        );
    }

    #[test]
    fn treats_a_band_maximum_as_inclusive() {
        let card = sample();
        assert_eq!(
            card.band_for("domestic", 500),
            Ok(Band {
                max_grams: 500,
                cents: 599
            })
        );
    }

    #[test]
    fn prices_a_weightless_parcel_in_the_lightest_band() {
        let card = sample();
        assert_eq!(
            card.band_for("domestic", 0),
            Ok(Band {
                max_grams: 500,
                cents: 599
            })
        );
    }

    #[test]
    fn orders_bands_ascending_regardless_of_file_order() {
        let shuffled = "domestic\t20000\t1799\ndomestic\t500\t599\ndomestic\t2000\t899\n";
        let card = match RateCard::parse(shuffled) {
            Ok(card) => card,
            Err(error) => unreachable!("shuffled rate card should parse: {error}"),
        };
        assert_eq!(
            card.band_for("domestic", 501),
            Ok(Band {
                max_grams: 2000,
                cents: 899
            })
        );
    }

    #[test]
    fn reports_an_absent_zone_with_the_requested_name() {
        let card = sample();
        assert_eq!(
            card.band_for("lunar", 100),
            Err(QuoteError::UnknownZone("lunar".to_owned()))
        );
    }

    #[test]
    fn reports_overweight_against_the_zones_largest_band() {
        let card = sample();
        assert_eq!(
            card.band_for("domestic", 20_001),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            })
        );
    }

    #[test]
    fn ignores_comments_and_blank_lines() {
        let text = "\n# a comment\n\ndomestic\t500\t599\n\n";
        let card = match RateCard::parse(text) {
            Ok(card) => card,
            Err(error) => unreachable!("commented rate card should parse: {error}"),
        };
        assert_eq!(
            card.band_for("domestic", 10),
            Ok(Band {
                max_grams: 500,
                cents: 599
            })
        );
    }

    #[test]
    fn counts_every_line_when_reporting_a_malformed_one() {
        let text = "# header\n\ndomestic\t500\t599\ndomestic\t2000\n";
        assert_eq!(
            RateCard::parse(text),
            Err(QuoteError::MalformedRateCard { line: 4 })
        );
    }

    #[test]
    fn rejects_a_line_with_too_many_fields() {
        let text = "domestic\t500\t599\textra\n";
        assert_eq!(
            RateCard::parse(text),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn rejects_a_line_that_is_not_tab_separated() {
        let text = "domestic 500 599\n";
        assert_eq!(
            RateCard::parse(text),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn rejects_numbers_that_do_not_parse() {
        let text = "domestic\theavy\t599\n";
        assert_eq!(
            RateCard::parse(text),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );

        let text = "domestic\t500\tfree\n";
        assert_eq!(
            RateCard::parse(text),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );

        let text = "domestic\t-500\t599\n";
        assert_eq!(
            RateCard::parse(text),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn rejects_a_band_without_a_zone() {
        let text = "\t500\t599\n";
        assert_eq!(
            RateCard::parse(text),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn survives_carriage_returns_from_a_windows_authored_card() {
        let text = "domestic\t500\t599\r\n";
        let card = match RateCard::parse(text) {
            Ok(card) => card,
            Err(error) => unreachable!("CRLF rate card should parse: {error}"),
        };
        assert_eq!(
            card.band_for("domestic", 500),
            Ok(Band {
                max_grams: 500,
                cents: 599
            })
        );
    }

    #[test]
    fn treats_an_empty_card_as_having_no_zones() {
        let card = match RateCard::parse("") {
            Ok(card) => card,
            Err(error) => unreachable!("empty rate card should parse: {error}"),
        };
        assert_eq!(
            card.band_for("domestic", 100),
            Err(QuoteError::UnknownZone("domestic".to_owned()))
        );
    }
}
