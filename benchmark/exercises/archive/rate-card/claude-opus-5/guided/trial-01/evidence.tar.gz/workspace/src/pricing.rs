//! The pricing rules: band price plus surcharges.
//!
//! Pure functions over a parsed [`RateCard`] and a [`Parcel`], so the rules can
//! be exercised without a rate-card file or a running service.

use crate::model::{Parcel, Quote, QuoteError};
use crate::rate_card::RateCard;

/// Weight above which a parcel attracts the heavy surcharge, in grams.
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
/// Flat surcharge applied to parcels above [`HEAVY_THRESHOLD_GRAMS`].
const HEAVY_SURCHARGE_CENTS: u64 = 500;
/// Zone that attracts the proportional surcharge.
const INTERNATIONAL_ZONE: &str = "international";
/// Percentage of the base price added for [`INTERNATIONAL_ZONE`] parcels.
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

/// Prices `parcel` against `card`.
pub(crate) fn price(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let band = card.band_for(&parcel.zone, parcel.weight_grams)?;
    let base_cents = band.cents;
    let surcharge_cents =
        heavy_surcharge(parcel.weight_grams).saturating_add(zone_surcharge(&parcel.zone, base_cents));

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    })
}

/// The flat surcharge for a heavy parcel; zero at or below the threshold.
fn heavy_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > HEAVY_THRESHOLD_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    }
}

/// The proportional surcharge for a zone, rounded half-up to the cent.
fn zone_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone != INTERNATIONAL_ZONE {
        return 0;
    }

    // Half-up in integer arithmetic: add half a cent's worth of numerator
    // before the truncating divide.
    base_cents
        .saturating_mul(INTERNATIONAL_SURCHARGE_PERCENT)
        .saturating_add(50)
        / 100
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
                          domestic\t500\t599\n\
                          domestic\t2000\t899\n\
                          domestic\t20000\t1799\n\
                          international\t500\t1499\n\
                          international\t20000\t4999\n";

    fn card() -> RateCard {
        match RateCard::parse(SAMPLE) {
            Ok(card) => card,
            Err(error) => unreachable!("sample rate card should parse: {error}"),
        }
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_owned(),
        }
    }

    #[test]
    fn prices_a_light_domestic_parcel_from_its_band_alone() {
        assert_eq!(
            price(&card(), &parcel(300, "domestic")),
            Ok(Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            })
        );
    }

    #[test]
    fn leaves_a_parcel_at_the_heavy_threshold_unsurcharged() {
        assert_eq!(
            price(&card(), &parcel(10_000, "domestic")),
            Ok(Quote {
                base_cents: 1799,
                surcharge_cents: 0,
                total_cents: 1799,
                band_max_grams: 20_000,
            })
        );
    }

    #[test]
    fn adds_the_flat_surcharge_just_above_the_heavy_threshold() {
        assert_eq!(
            price(&card(), &parcel(10_001, "domestic")),
            Ok(Quote {
                base_cents: 1799,
                surcharge_cents: 500,
                total_cents: 2299,
                band_max_grams: 20_000,
            })
        );
    }

    #[test]
    fn adds_a_fifth_of_the_base_for_international() {
        assert_eq!(
            price(&card(), &parcel(400, "international")),
            Ok(Quote {
                base_cents: 1499,
                surcharge_cents: 300,
                total_cents: 1799,
                band_max_grams: 500,
            })
        );
    }

    #[test]
    fn accumulates_the_heavy_and_international_surcharges() {
        assert_eq!(
            price(&card(), &parcel(15_000, "international")),
            Ok(Quote {
                base_cents: 4999,
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20_000,
            })
        );
    }

    #[test]
    fn rounds_the_international_surcharge_half_up() {
        // 200.4 rounds down, 200.6 rounds up, 1.0 stays put, 0.2 disappears.
        assert_eq!(zone_surcharge("international", 1002), 200);
        assert_eq!(zone_surcharge("international", 1003), 201);
        assert_eq!(zone_surcharge("international", 5), 1);
        assert_eq!(zone_surcharge("international", 1), 0);
    }

    #[test]
    fn surcharges_no_zone_but_international_proportionally() {
        assert_eq!(zone_surcharge("domestic", 1000), 0);
        assert_eq!(zone_surcharge("International", 1000), 0);
        assert_eq!(zone_surcharge("", 1000), 0);
    }

    #[test]
    fn propagates_lookup_failures_unchanged() {
        assert_eq!(
            price(&card(), &parcel(100, "lunar")),
            Err(QuoteError::UnknownZone("lunar".to_owned()))
        );
        assert_eq!(
            price(&card(), &parcel(25_000, "international")),
            Err(QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000,
            })
        );
    }
}
