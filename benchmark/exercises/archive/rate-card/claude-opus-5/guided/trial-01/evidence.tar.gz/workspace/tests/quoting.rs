//! Wiring: the published `quote` entry point against real files named by
//! `RATECARD_PATH`.
//!
//! The pricing rules themselves are covered by unit tests next to the code.
//! What is only observable here is the shell — environment lookup, file
//! reading, and the failure modes they introduce.

// A failed fixture is a broken test, not a recoverable condition: the crate's
// no-panic standard is about library code, so panicking setup is right here.
#![allow(clippy::expect_used, clippy::panic)]

use std::env;
use std::fs;
use std::path::Path;
use std::sync::{Mutex, MutexGuard, OnceLock};

use ratecard::{quote, Parcel, Quote, QuoteError, RATECARD_PATH_VAR};
use tempfile::TempDir;

const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
                      domestic\t500\t599\n\
                      domestic\t2000\t899\n\
                      domestic\t20000\t1799\n\
                      international\t500\t1499\n\
                      international\t20000\t4999\n";

/// `RATECARD_PATH` is process-wide state, so tests that set it take turns.
fn env_lock() -> MutexGuard<'static, ()> {
    static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    match LOCK.get_or_init(|| Mutex::new(())).lock() {
        Ok(guard) => guard,
        Err(poisoned) => poisoned.into_inner(),
    }
}

/// Runs `body` with `RATECARD_PATH` pointed at a card holding `contents`.
fn with_card<T>(contents: &str, body: impl FnOnce() -> T) -> T {
    let dir = TempDir::new().expect("temp dir");
    let path = dir.path().join("ratecard.tsv");
    fs::write(&path, contents).expect("write rate card");
    with_path(&path, body)
}

/// Runs `body` with `RATECARD_PATH` set to `path`, restoring it afterwards.
fn with_path<T>(path: &Path, body: impl FnOnce() -> T) -> T {
    let _guard = env_lock();
    let previous = env::var_os(RATECARD_PATH_VAR);
    env::set_var(RATECARD_PATH_VAR, path);
    let outcome = body();
    match previous {
        Some(value) => env::set_var(RATECARD_PATH_VAR, value),
        None => env::remove_var(RATECARD_PATH_VAR),
    }
    outcome
}

/// Runs `body` with `RATECARD_PATH` unset, restoring it afterwards.
fn without_path<T>(body: impl FnOnce() -> T) -> T {
    let _guard = env_lock();
    let previous = env::var_os(RATECARD_PATH_VAR);
    env::remove_var(RATECARD_PATH_VAR);
    let outcome = body();
    if let Some(value) = previous {
        env::set_var(RATECARD_PATH_VAR, value);
    }
    outcome
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_owned(),
    }
}

#[test]
fn prices_a_domestic_parcel_from_the_deployed_card() {
    let priced = with_card(SAMPLE, || quote(&parcel(750, "domestic")));

    assert_eq!(
        priced,
        Ok(Quote {
            base_cents: 899,
            surcharge_cents: 0,
            total_cents: 899,
            band_max_grams: 2000,
        })
    );
}

#[test]
fn stacks_surcharges_on_a_heavy_international_parcel() {
    let priced = with_card(SAMPLE, || quote(&parcel(19_000, "international")));

    assert_eq!(
        priced,
        Ok(Quote {
            base_cents: 4999,
            surcharge_cents: 1500,
            total_cents: 6499,
            band_max_grams: 20_000,
        })
    );
}

#[test]
fn rejects_a_zone_the_card_does_not_carry() {
    let priced = with_card(SAMPLE, || quote(&parcel(100, "orbital")));

    assert_eq!(priced, Err(QuoteError::UnknownZone("orbital".to_owned())));
}

#[test]
fn rejects_a_parcel_beyond_the_heaviest_band() {
    let priced = with_card(SAMPLE, || quote(&parcel(20_001, "domestic")));

    assert_eq!(
        priced,
        Err(QuoteError::Overweight {
            grams: 20_001,
            limit: 20_000,
        })
    );
}

#[test]
fn reports_an_unset_variable_as_unavailable() {
    let priced = without_path(|| quote(&parcel(100, "domestic")));

    assert_eq!(priced, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn reports_a_missing_file_as_unavailable() {
    let dir = TempDir::new().expect("temp dir");
    let absent = dir.path().join("not-deployed.tsv");

    let priced = with_path(&absent, || quote(&parcel(100, "domestic")));

    assert_eq!(priced, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn reports_an_unreadable_path_as_unavailable() {
    // A directory is readable as a path but not as a rate card.
    let dir = TempDir::new().expect("temp dir");

    let priced = with_path(dir.path(), || quote(&parcel(100, "domestic")));

    assert_eq!(priced, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn reports_a_malformed_line_by_its_position_in_the_file() {
    let card = "# zone\tband_max_grams\tcents\n\
                domestic\t500\t599\n\
                \n\
                domestic\ttwo thousand\t899\n";

    let priced = with_card(card, || quote(&parcel(100, "domestic")));

    assert_eq!(priced, Err(QuoteError::MalformedRateCard { line: 4 }));
}

#[test]
fn refuses_to_price_from_a_malformed_card_even_where_a_band_would_match() {
    let card = "domestic\t500\t599\ndomestic\t2000\n";

    let priced = with_card(card, || quote(&parcel(100, "domestic")));

    assert_eq!(priced, Err(QuoteError::MalformedRateCard { line: 2 }));
}

#[test]
fn picks_up_a_redeployed_card_without_a_restart() {
    let first = with_card(SAMPLE, || quote(&parcel(300, "domestic")));
    let repriced = with_card("domestic\t500\t649\n", || quote(&parcel(300, "domestic")));

    assert_eq!(first.map(|quote| quote.total_cents), Ok(599));
    assert_eq!(repriced.map(|quote| quote.total_cents), Ok(649));
}
