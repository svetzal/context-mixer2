//! Shipping quotes for the fulfilment service.
//!
//! Operations maintains a tab-separated rate card and redeploys it without a
//! code change; this crate reads that card and turns a [`Parcel`] into a
//! [`Quote`].
//!
//! # Layout
//!
//! The rules are pure: `rate_card` parses text into bands and `pricing`
//! applies band prices and surcharges, neither of them touching a filesystem.
//! [`quote`] is the thin shell around them — it asks a [`RateCardSource`] for
//! the card text, runs the rules, and reports the outcome to `tracing`.
//!
//! # Examples
//!
//! ```
//! use ratecard::{quote_from, Parcel, RateCardSource, RateCardUnavailable};
//!
//! struct Card(&'static str);
//!
//! impl RateCardSource for Card {
//!     fn load(&self) -> Result<String, RateCardUnavailable> {
//!         Ok(self.0.to_owned())
//!     }
//! }
//!
//! let card = Card("domestic\t500\t599\ninternational\t500\t1499\n");
//! let parcel = Parcel { weight_grams: 480, zone: "international".to_owned() };
//! let quote = quote_from(&card, &parcel)?;
//!
//! assert_eq!(quote.base_cents, 1499);
//! assert_eq!(quote.surcharge_cents, 300);
//! assert_eq!(quote.total_cents, 1799);
//! assert_eq!(quote.band_max_grams, 500);
//! # Ok::<(), ratecard::QuoteError>(())
//! ```

pub mod gateway;
mod model;
mod pricing;
mod rate_card;
pub mod zones;

use tracing::{field, info, info_span, warn};

pub use crate::gateway::{EnvRateCardSource, RateCardSource, RateCardUnavailable, RATECARD_PATH_VAR};
pub use crate::model::{Parcel, Quote, QuoteError};

use crate::rate_card::RateCard;

/// Prices a parcel against the rate card named by `RATECARD_PATH`.
///
/// # Errors
///
/// - [`QuoteError::RateCardUnavailable`] if `RATECARD_PATH` is unset or its
///   file cannot be read.
/// - [`QuoteError::MalformedRateCard`] if a line is not three tab-separated
///   fields or its numbers do not parse.
/// - [`QuoteError::UnknownZone`] if the parcel's zone is absent from the card.
/// - [`QuoteError::Overweight`] if the parcel outweighs the zone's largest
///   band.
///
/// # Examples
///
/// ```no_run
/// use ratecard::{quote, Parcel};
///
/// std::env::set_var("RATECARD_PATH", "/etc/fulfilment/ratecard.tsv");
/// let parcel = Parcel { weight_grams: 1200, zone: "domestic".to_owned() };
///
/// println!("{} cents", quote(&parcel)?.total_cents);
/// # Ok::<(), ratecard::QuoteError>(())
/// ```
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_from(&EnvRateCardSource, parcel)
}

/// Prices a parcel against a caller-supplied rate card source.
///
/// [`quote`] is this function wired to the environment; tests and alternative
/// deployments substitute their own [`RateCardSource`].
///
/// # Errors
///
/// The same failures as [`quote`], with unavailability decided by `source`.
pub fn quote_from<S>(source: &S, parcel: &Parcel) -> Result<Quote, QuoteError>
where
    S: RateCardSource + ?Sized,
{
    let span = info_span!(
        "quote",
        zone = %parcel.zone,
        weight_grams = u64::from(parcel.weight_grams),
        total_cents = field::Empty,
        outcome = field::Empty,
    );
    let _entered = span.enter();

    let result = load_card(source).and_then(|card| pricing::price(&card, parcel));

    match &result {
        Ok(quote) => {
            span.record("total_cents", quote.total_cents);
            span.record("outcome", "priced");
            info!(
                zone = %parcel.zone,
                weight_grams = u64::from(parcel.weight_grams),
                total_cents = quote.total_cents,
                base_cents = quote.base_cents,
                surcharge_cents = quote.surcharge_cents,
                band_max_grams = u64::from(quote.band_max_grams),
                "parcel priced"
            );
        }
        Err(error) => {
            span.record("outcome", outcome(error));
            warn!(
                zone = %parcel.zone,
                weight_grams = u64::from(parcel.weight_grams),
                outcome = outcome(error),
                error = %error,
                "parcel not priced"
            );
        }
    }

    result
}

/// Fetches and parses the card, folding source failures into the domain error.
fn load_card<S>(source: &S) -> Result<RateCard, QuoteError>
where
    S: RateCardSource + ?Sized,
{
    let text = source.load().map_err(|unavailable| {
        warn!(detail = %unavailable.detail, "rate card unavailable");
        QuoteError::RateCardUnavailable
    })?;

    RateCard::parse(&text)
}

/// A stable, low-cardinality label for a failure, suitable as a log field.
fn outcome(error: &QuoteError) -> &'static str {
    match error {
        QuoteError::RateCardUnavailable => "rate_card_unavailable",
        QuoteError::MalformedRateCard { .. } => "malformed_rate_card",
        QuoteError::UnknownZone(_) => "unknown_zone",
        QuoteError::Overweight { .. } => "overweight",
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    struct Fixture(&'static str);

    impl RateCardSource for Fixture {
        fn load(&self) -> Result<String, RateCardUnavailable> {
            Ok(self.0.to_owned())
        }
    }

    struct Missing;

    impl RateCardSource for Missing {
        fn load(&self) -> Result<String, RateCardUnavailable> {
            Err(RateCardUnavailable::new("no card here"))
        }
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_owned(),
        }
    }

    #[test]
    fn prices_through_the_supplied_source() {
        let source = Fixture("domestic\t500\t599\n");
        assert_eq!(
            quote_from(&source, &parcel(500, "domestic")),
            Ok(Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            })
        );
    }

    #[test]
    fn reports_an_unavailable_source_as_such() {
        assert_eq!(
            quote_from(&Missing, &parcel(500, "domestic")),
            Err(QuoteError::RateCardUnavailable)
        );
    }

    #[test]
    fn surfaces_a_malformed_card_with_its_line_number() {
        let source = Fixture("# header\ndomestic\t500\t599\nbroken line\n");
        assert_eq!(
            quote_from(&source, &parcel(100, "domestic")),
            Err(QuoteError::MalformedRateCard { line: 3 })
        );
    }

    #[test]
    fn labels_every_failure_distinctly() {
        assert_eq!(outcome(&QuoteError::RateCardUnavailable), "rate_card_unavailable");
        assert_eq!(
            outcome(&QuoteError::MalformedRateCard { line: 1 }),
            "malformed_rate_card"
        );
        assert_eq!(outcome(&QuoteError::UnknownZone(String::new())), "unknown_zone");
        assert_eq!(
            outcome(&QuoteError::Overweight {
                grams: 1,
                limit: 0
            }),
            "overweight"
        );
    }
}
