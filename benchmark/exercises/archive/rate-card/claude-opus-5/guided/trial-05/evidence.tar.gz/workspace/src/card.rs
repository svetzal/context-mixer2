//! The rate card itself: parsing card text into priced bands.
//!
//! This module is pure. It takes the card's text and never touches the
//! filesystem or the environment, so its behaviour is testable without I/O.

use std::collections::BTreeMap;

use crate::error::QuoteError;

/// Character separating a card line's fields.
const FIELD_SEPARATOR: char = '\t';
/// Prefix marking a line as an operator comment.
const COMMENT_PREFIX: char = '#';

/// One priced weight band within a zone.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Band {
    /// The heaviest parcel this band prices, inclusive.
    pub max_grams: u32,
    /// The band's price before surcharges.
    pub cents: u64,
}

/// A parsed rate card: the bands each zone prices, in ascending weight order.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

impl RateCard {
    /// Parses tab-separated card text into a rate card.
    ///
    /// Each band line is `zone`, `band_max_grams`, `cents`. Blank lines and
    /// lines beginning with `#` are ignored, but they still count towards the
    /// line number reported by [`QuoteError::MalformedRateCard`].
    ///
    /// # Errors
    ///
    /// Returns [`QuoteError::MalformedRateCard`] for the first line that is not
    /// exactly three tab-separated fields, or whose numbers do not parse.
    ///
    /// ```
    /// use ratecard::RateCard;
    ///
    /// let card = RateCard::parse("# zone\tband_max_grams\tcents\ndomestic\t500\t599\n")?;
    /// assert_eq!(card.largest_band("domestic").map(|band| band.max_grams), Some(500));
    /// # Ok::<(), ratecard::QuoteError>(())
    /// ```
    pub fn parse(text: &str) -> Result<Self, QuoteError> {
        let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

        for (offset, raw_line) in text.lines().enumerate() {
            let line_number = offset + 1;
            // Only the carriage return of a CRLF file is stripped: trimming the
            // whole line would hide a trailing tab, and a trailing tab is a
            // fourth field.
            let line = raw_line.trim_end_matches('\r');
            let content = line.trim();
            if content.is_empty() || content.starts_with(COMMENT_PREFIX) {
                continue;
            }

            let (zone, band) = parse_band_line(line, line_number)?;
            zones.entry(zone).or_default().push(band);
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(Self { zones })
    }

    /// The bands a zone prices, lightest first, or `None` if the card does not
    /// name the zone.
    #[must_use]
    pub fn bands(&self, zone: &str) -> Option<&[Band]> {
        self.zones.get(zone).map(Vec::as_slice)
    }

    /// The heaviest band a zone prices, or `None` if the card does not name it.
    #[must_use]
    pub fn largest_band(&self, zone: &str) -> Option<Band> {
        self.bands(zone).and_then(|bands| bands.last().copied())
    }
}

/// Splits one non-comment line into the zone it prices and the band it defines.
fn parse_band_line(line: &str, line_number: usize) -> Result<(String, Band), QuoteError> {
    let malformed = || QuoteError::MalformedRateCard { line: line_number };

    let fields: Vec<&str> = line.split(FIELD_SEPARATOR).map(str::trim).collect();
    let [zone, max_grams, cents] = fields.as_slice() else {
        return Err(malformed());
    };
    if zone.is_empty() {
        return Err(malformed());
    }

    let max_grams = max_grams.parse::<u32>().map_err(|_| malformed())?;
    let cents = cents.parse::<u64>().map_err(|_| malformed())?;

    Ok(((*zone).to_owned(), Band { max_grams, cents }))
}

#[cfg(test)]
#[allow(clippy::unwrap_used, reason = "a failing unwrap in a test is the failure report")]
mod tests {
    use super::{Band, RateCard};
    use crate::error::QuoteError;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn reads_every_band_of_every_zone() {
        let card = RateCard::parse(SAMPLE).unwrap();

        assert_eq!(
            card.bands("domestic"),
            Some(
                [
                    Band { max_grams: 500, cents: 599 },
                    Band { max_grams: 2000, cents: 899 },
                    Band { max_grams: 20_000, cents: 1799 },
                ]
                .as_slice()
            )
        );
        assert_eq!(card.largest_band("international"), Some(Band { max_grams: 20_000, cents: 4999 }));
    }

    #[test]
    fn orders_bands_by_ascending_weight_however_the_file_lists_them() {
        let card = RateCard::parse("domestic\t20000\t1799\ndomestic\t500\t599\n").unwrap();

        let weights: Vec<u32> = card.bands("domestic").unwrap().iter().map(|band| band.max_grams).collect();
        assert_eq!(weights, vec![500, 20_000]);
    }

    #[test]
    fn ignores_comments_and_blank_lines() {
        let card = RateCard::parse("\n# a comment\n\ndomestic\t500\t599\n\n").unwrap();

        assert_eq!(card.bands("domestic").map(<[Band]>::len), Some(1));
    }

    #[test]
    fn a_card_without_a_zone_simply_does_not_name_it() {
        let card = RateCard::parse(SAMPLE).unwrap();

        assert_eq!(card.bands("lunar"), None);
        assert_eq!(RateCard::parse("").unwrap(), RateCard::default());
    }

    #[test]
    fn reports_the_line_number_an_operator_would_see() {
        // Line 4 of the file, counting the comment and the blank line.
        let text = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\n\ndomestic\ttwo thousand\t899\n";

        assert_eq!(
            RateCard::parse(text),
            Err(QuoteError::MalformedRateCard { line: 4 })
        );
    }

    #[test]
    fn rejects_lines_that_are_not_three_tab_separated_fields() {
        let too_few = "domestic\t500\n";
        let too_many = "domestic\t500\t599\textra\n";
        let trailing_tab = "domestic\t500\t599\t\n";
        let not_tabs = "domestic 500 599\n";
        let no_zone = "\t500\t599\n";

        for text in [too_few, too_many, trailing_tab, not_tabs, no_zone] {
            assert_eq!(
                RateCard::parse(text),
                Err(QuoteError::MalformedRateCard { line: 1 }),
                "expected `{text:?}` to be rejected"
            );
        }
    }

    #[test]
    fn rejects_numbers_that_do_not_parse() {
        for text in ["domestic\t-500\t599\n", "domestic\t500\t5.99\n", "domestic\t\t599\n"] {
            assert_eq!(
                RateCard::parse(text),
                Err(QuoteError::MalformedRateCard { line: 1 }),
                "expected `{text:?}` to be rejected"
            );
        }
    }

    #[test]
    fn stops_at_the_first_bad_line() {
        let text = "domestic\tbad\t599\ndomestic\talso bad\t899\n";

        assert_eq!(
            RateCard::parse(text),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn tolerates_windows_line_endings() {
        let card = RateCard::parse("# header\r\ndomestic\t500\t599\r\n").unwrap();

        assert_eq!(card.largest_band("domestic"), Some(Band { max_grams: 500, cents: 599 }));
    }
}
