//! The failure modes a caller of [`quote`](crate::quote) can recover from.

use std::fmt;

/// Why a parcel could not be priced.
///
/// Every variant is a condition the caller is expected to handle: a rate card
/// that operations has not deployed yet, a card that was deployed with a bad
/// line in it, or a parcel that the deployed card does not cover.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card could not be located or read.
    ///
    /// Covers an unset `RATECARD_PATH`, a path that does not exist, and a file
    /// that cannot be read as UTF-8 text.
    RateCardUnavailable,

    /// A rate-card line was not three tab-separated fields, or its numbers did
    /// not parse.
    ///
    /// `line` is 1-based and counts every line in the file, including comments
    /// and blanks, so it points at what an operator sees in an editor.
    MalformedRateCard {
        /// 1-based number of the offending line.
        line: usize,
    },

    /// The requested zone has no bands in the rate card.
    UnknownZone(String),

    /// The parcel is heavier than the largest band the zone prices.
    Overweight {
        /// The parcel's weight.
        grams: u32,
        /// The largest `band_max_grams` the zone offers.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => f.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone `{zone}`"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel of {grams} g exceeds the zone limit of {limit} g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[cfg(test)]
mod tests {
    use super::QuoteError;

    fn rendered(error: &QuoteError) -> String {
        error.to_string()
    }

    #[test]
    fn each_variant_renders_its_own_detail() {
        assert_eq!(rendered(&QuoteError::RateCardUnavailable), "rate card is unavailable");
        assert_eq!(
            rendered(&QuoteError::MalformedRateCard { line: 7 }),
            "malformed rate card at line 7"
        );
        assert_eq!(
            rendered(&QuoteError::UnknownZone("lunar".to_owned())),
            "unknown zone `lunar`"
        );
        assert_eq!(
            rendered(&QuoteError::Overweight { grams: 30_000, limit: 20_000 }),
            "parcel of 30000 g exceeds the zone limit of 20000 g"
        );
    }

    #[test]
    fn is_a_standard_error() {
        let boxed: Box<dyn std::error::Error> = Box::new(QuoteError::RateCardUnavailable);
        assert_eq!(boxed.to_string(), "rate card is unavailable");
    }
}
