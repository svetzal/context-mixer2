//! Wiring: `quote` against a card deployed on disk at `RATECARD_PATH`.

#![allow(
    clippy::expect_used,
    reason = "the no-panic policy protects library callers; a failing expect here is the test report"
)]

use std::io::Write as _;
use std::sync::{Mutex, MutexGuard, OnceLock};

use ratecard::{quote, Parcel, QuoteError, RATECARD_PATH_VAR};
use tempfile::{NamedTempFile, TempDir};

const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

/// `RATECARD_PATH` is process-wide, so env-touching tests take turns.
fn env_lock() -> MutexGuard<'static, ()> {
    static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    let lock = LOCK.get_or_init(|| Mutex::new(()));
    lock.lock().unwrap_or_else(std::sync::PoisonError::into_inner)
}

/// Deploys card text to a file and points `RATECARD_PATH` at it.
fn deploy(card: &str) -> NamedTempFile {
    let mut file = NamedTempFile::new().expect("create a temporary rate card");
    file.write_all(card.as_bytes()).expect("write the rate card");
    file.flush().expect("flush the rate card");
    std::env::set_var(RATECARD_PATH_VAR, file.path());
    file
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel { weight_grams, zone: zone.to_owned() }
}

#[test]
fn prices_a_parcel_against_the_deployed_card() {
    let _guard = env_lock();
    let _card = deploy(SAMPLE);

    let quoted = quote(&parcel(750, "domestic")).expect("a domestic parcel prices");

    assert_eq!(quoted.base_cents, 899);
    assert_eq!(quoted.surcharge_cents, 0);
    assert_eq!(quoted.total_cents, 899);
    assert_eq!(quoted.band_max_grams, 2000);
}

#[test]
fn applies_both_surcharges_to_a_heavy_international_parcel() {
    let _guard = env_lock();
    let _card = deploy(SAMPLE);

    let quoted = quote(&parcel(12_000, "international")).expect("an international parcel prices");

    assert_eq!(quoted.base_cents, 4999);
    assert_eq!(quoted.surcharge_cents, 1500);
    assert_eq!(quoted.total_cents, 6499);
    assert_eq!(quoted.band_max_grams, 20_000);
}

#[test]
fn a_redeployed_card_prices_the_next_parcel() {
    let _guard = env_lock();
    let _card = deploy(SAMPLE);
    assert_eq!(quote(&parcel(100, "domestic")).map(|q| q.total_cents), Ok(599));

    let _redeployed = deploy("domestic\t500\t649\n");

    assert_eq!(quote(&parcel(100, "domestic")).map(|q| q.total_cents), Ok(649));
}

#[test]
fn an_unset_path_leaves_the_rate_card_unavailable() {
    let _guard = env_lock();
    std::env::remove_var(RATECARD_PATH_VAR);

    assert_eq!(
        quote(&parcel(100, "domestic")),
        Err(QuoteError::RateCardUnavailable)
    );
}

#[test]
fn a_path_to_nothing_leaves_the_rate_card_unavailable() {
    let _guard = env_lock();
    let empty = TempDir::new().expect("create a temporary directory");
    std::env::set_var(RATECARD_PATH_VAR, empty.path().join("no-such-card.tsv"));

    assert_eq!(
        quote(&parcel(100, "domestic")),
        Err(QuoteError::RateCardUnavailable)
    );
}

#[test]
fn an_unreadable_card_leaves_the_rate_card_unavailable() {
    let _guard = env_lock();
    // A directory is present but cannot be read as card text.
    let directory = TempDir::new().expect("create a temporary directory");
    std::env::set_var(RATECARD_PATH_VAR, directory.path());

    assert_eq!(
        quote(&parcel(100, "domestic")),
        Err(QuoteError::RateCardUnavailable)
    );
}

#[test]
fn a_bad_line_reports_its_number_in_the_deployed_file() {
    let _guard = env_lock();
    let _card = deploy("# zone\tband_max_grams\tcents\ndomestic\t500\t599\n\ndomestic\t2000\n");

    assert_eq!(
        quote(&parcel(100, "domestic")),
        Err(QuoteError::MalformedRateCard { line: 4 })
    );
}

#[test]
fn a_zone_the_deployed_card_does_not_price_is_unknown() {
    let _guard = env_lock();
    let _card = deploy(SAMPLE);

    assert_eq!(
        quote(&parcel(100, "lunar")),
        Err(QuoteError::UnknownZone("lunar".to_owned()))
    );
}

#[test]
fn a_parcel_past_the_largest_band_is_overweight() {
    let _guard = env_lock();
    let _card = deploy(SAMPLE);

    assert_eq!(
        quote(&parcel(25_000, "domestic")),
        Err(QuoteError::Overweight { grams: 25_000, limit: 20_000 })
    );
}
