//! The edge where rate-card text comes from.
//!
//! Pricing depends on this crate-owned contract rather than on the filesystem
//! or the environment directly, so the pure core can be driven by an in-memory
//! card in tests and by a deployed file in production.

use std::fs;

use crate::error::QuoteError;

/// Environment variable naming the deployed rate card.
pub const RATECARD_PATH_VAR: &str = "RATECARD_PATH";

/// Where rate-card text is read from.
///
/// Implementations report every retrieval failure as
/// [`QuoteError::RateCardUnavailable`]; a card that is present but wrong is the
/// parser's business, not the source's.
pub trait RateCardSource {
    /// Reads the current rate-card text.
    ///
    /// # Errors
    ///
    /// Returns [`QuoteError::RateCardUnavailable`] if the card cannot be
    /// located or read.
    fn load(&self) -> Result<String, QuoteError>;
}

/// Reads the rate card from the file named by `RATECARD_PATH`.
///
/// The variable is read on every call, so operations can redeploy the card
/// without a restart.
#[derive(Debug, Clone, Copy, Default)]
pub struct EnvRateCardSource;

impl RateCardSource for EnvRateCardSource {
    fn load(&self) -> Result<String, QuoteError> {
        let path = std::env::var(RATECARD_PATH_VAR).map_err(|_| QuoteError::RateCardUnavailable)?;
        fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}

/// A rate card held in memory, for tests and callers that carry their own card.
///
/// ```
/// use ratecard::{InMemoryRateCardSource, Parcel, quote_from};
///
/// let source = InMemoryRateCardSource::new("domestic\t500\t599\n");
/// let quote = quote_from(&source, &Parcel { weight_grams: 250, zone: "domestic".to_owned() })?;
///
/// assert_eq!(quote.total_cents, 599);
/// # Ok::<(), ratecard::QuoteError>(())
/// ```
#[derive(Debug, Clone, Default)]
pub struct InMemoryRateCardSource {
    text: Option<String>,
}

impl InMemoryRateCardSource {
    /// A source that serves the given card text.
    #[must_use]
    pub fn new(text: impl Into<String>) -> Self {
        Self { text: Some(text.into()) }
    }

    /// A source that has no card to serve, as when none has been deployed.
    #[must_use]
    pub fn unavailable() -> Self {
        Self { text: None }
    }
}

impl RateCardSource for InMemoryRateCardSource {
    fn load(&self) -> Result<String, QuoteError> {
        self.text.clone().ok_or(QuoteError::RateCardUnavailable)
    }
}

#[cfg(test)]
mod tests {
    use super::{InMemoryRateCardSource, RateCardSource};
    use crate::error::QuoteError;

    #[test]
    fn an_in_memory_source_serves_the_text_it_was_given() {
        let source = InMemoryRateCardSource::new("domestic\t500\t599\n");

        assert_eq!(source.load(), Ok("domestic\t500\t599\n".to_owned()));
    }

    #[test]
    fn an_undeployed_card_is_unavailable() {
        assert_eq!(
            InMemoryRateCardSource::unavailable().load(),
            Err(QuoteError::RateCardUnavailable)
        );
    }
}
