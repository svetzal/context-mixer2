//! What goes into a quote and what comes out of it.

/// A parcel awaiting a price.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Billable weight of the parcel.
    pub weight_grams: u32,
    /// Destination zone, as named in the rate card.
    pub zone: String,
}

/// The priced result for a parcel.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quote {
    /// The matching band's price, before surcharges.
    pub base_cents: u64,
    /// Heavy-parcel and zone surcharges, added together.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// The `band_max_grams` threshold of the band that matched.
    pub band_max_grams: u32,
}
