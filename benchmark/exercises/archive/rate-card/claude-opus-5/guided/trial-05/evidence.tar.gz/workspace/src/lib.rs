//! Shipping quotes for the fulfilment service.
//!
//! Operations maintains a rate card and redeploys it without a code change;
//! this crate reads that card and turns a parcel into a [`Quote`].
//!
//! ```no_run
//! use ratecard::{Parcel, quote};
//!
//! // With RATECARD_PATH naming a deployed card:
//! let quote = quote(&Parcel { weight_grams: 750, zone: "domestic".to_owned() })?;
//! println!("{} cents", quote.total_cents);
//! # Ok::<(), ratecard::QuoteError>(())
//! ```
//!
//! The card text is parsed and priced by a pure core ([`RateCard::parse`] and
//! [`RateCard::price`]); reaching the file behind `RATECARD_PATH` is confined to
//! the [`RateCardSource`] edge, so pricing can be exercised without I/O.

mod card;
mod error;
mod model;
mod pricing;
mod source;
pub mod zones;

pub use card::{Band, RateCard};
pub use error::QuoteError;
pub use model::{Parcel, Quote};
pub use source::{EnvRateCardSource, InMemoryRateCardSource, RateCardSource, RATECARD_PATH_VAR};

/// Prices a parcel against the rate card named by `RATECARD_PATH`.
///
/// # Errors
///
/// Returns [`QuoteError::RateCardUnavailable`] if the card cannot be read,
/// [`QuoteError::MalformedRateCard`] if a line of it does not parse,
/// [`QuoteError::UnknownZone`] if the card does not price the parcel's zone, and
/// [`QuoteError::Overweight`] if the parcel is heavier than that zone's largest
/// band.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_from(&EnvRateCardSource, parcel)
}

/// Prices a parcel against a card from an explicit source.
///
/// [`quote`] is this function bound to the deployed card; tests and callers that
/// carry their own card can pass any [`RateCardSource`].
///
/// # Errors
///
/// As [`quote`], with retrieval failures coming from `source`.
pub fn quote_from(source: &dyn RateCardSource, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "quote",
        zone = parcel.zone.as_str(),
        weight_grams = parcel.weight_grams,
        total_cents = tracing::field::Empty,
        outcome = tracing::field::Empty,
    );
    let _entered = span.enter();

    match price_parcel(source, parcel) {
        Ok(quote) => {
            span.record("total_cents", quote.total_cents);
            span.record("outcome", "priced");
            tracing::info!(
                zone = parcel.zone.as_str(),
                weight_grams = parcel.weight_grams,
                total_cents = quote.total_cents,
                base_cents = quote.base_cents,
                surcharge_cents = quote.surcharge_cents,
                band_max_grams = quote.band_max_grams,
                "parcel priced"
            );
            Ok(quote)
        }
        Err(error) => {
            span.record("outcome", "failed");
            tracing::warn!(
                zone = parcel.zone.as_str(),
                weight_grams = parcel.weight_grams,
                error = %error,
                "parcel not priced"
            );
            Err(error)
        }
    }
}

/// The unobserved pricing path: fetch the card, parse it, price the parcel.
fn price_parcel(source: &dyn RateCardSource, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let text = source.load()?;
    let card = RateCard::parse(&text)?;
    card.price(parcel)
}

#[cfg(test)]
#[allow(clippy::unwrap_used, reason = "a failing unwrap in a test is the failure report")]
mod tests {
    use super::{quote_from, InMemoryRateCardSource, Parcel, QuoteError};

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn prices_a_parcel_from_the_source_it_is_given() {
        let source = InMemoryRateCardSource::new(SAMPLE);

        let quote = quote_from(
            &source,
            &Parcel { weight_grams: 1200, zone: "international".to_owned() },
        )
        .unwrap();

        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.band_max_grams, 20_000);
        assert_eq!(quote.surcharge_cents, 1000);
        assert_eq!(quote.total_cents, 5999);
    }

    #[test]
    fn a_source_with_no_card_makes_the_rate_card_unavailable() {
        let source = InMemoryRateCardSource::unavailable();

        assert_eq!(
            quote_from(&source, &Parcel { weight_grams: 100, zone: "domestic".to_owned() }),
            Err(QuoteError::RateCardUnavailable)
        );
    }

    #[test]
    fn a_bad_line_surfaces_before_any_price() {
        let source = InMemoryRateCardSource::new("domestic\t500\t599\ndomestic\toops\t899\n");

        assert_eq!(
            quote_from(&source, &Parcel { weight_grams: 100, zone: "domestic".to_owned() }),
            Err(QuoteError::MalformedRateCard { line: 2 })
        );
    }
}
