//! Every quote is observable: one correlated span and one diagnostic record
//! per call, carrying zone, weight, and total as queryable fields.

#![allow(
    clippy::expect_used,
    reason = "the no-panic policy protects library callers; a failing expect here is the test report"
)]

use std::io;
use std::sync::{Arc, Mutex, PoisonError};

use ratecard::{quote_from, InMemoryRateCardSource, Parcel};
use tracing_subscriber::fmt::MakeWriter;

const SAMPLE: &str = "\
domestic\t500\t599
domestic\t2000\t899
international\t20000\t4999
";

/// Collects subscriber output so a test can read what an operator would see.
#[derive(Clone, Default)]
struct Captured(Arc<Mutex<Vec<u8>>>);

impl Captured {
    fn contents(&self) -> String {
        let bytes = self.0.lock().unwrap_or_else(PoisonError::into_inner);
        String::from_utf8_lossy(&bytes).into_owned()
    }
}

impl io::Write for Captured {
    fn write(&mut self, buf: &[u8]) -> io::Result<usize> {
        let mut bytes = self.0.lock().unwrap_or_else(PoisonError::into_inner);
        bytes.extend_from_slice(buf);
        Ok(buf.len())
    }

    fn flush(&mut self) -> io::Result<()> {
        Ok(())
    }
}

impl<'a> MakeWriter<'a> for Captured {
    type Writer = Self;

    fn make_writer(&'a self) -> Self::Writer {
        self.clone()
    }
}

/// Runs `call` with a capturing subscriber installed on this thread.
fn observed<T>(call: impl FnOnce() -> T) -> (T, String) {
    let captured = Captured::default();
    let subscriber = tracing_subscriber::fmt()
        .with_writer(captured.clone())
        .with_ansi(false)
        .finish();
    let result = tracing::subscriber::with_default(subscriber, call);
    (result, captured.contents())
}

/// Whether a field appears with the given value, quoted or not.
fn has_field(output: &str, field: &str, value: &str) -> bool {
    output.contains(&format!("{field}={value}")) || output.contains(&format!("{field}=\"{value}\""))
}

#[test]
fn a_priced_parcel_records_its_zone_weight_and_total() {
    let source = InMemoryRateCardSource::new(SAMPLE);

    let (quoted, output) = observed(|| {
        quote_from(&source, &Parcel { weight_grams: 12_000, zone: "international".to_owned() })
    });

    let quoted = quoted.expect("an international parcel prices");
    assert_eq!(quoted.total_cents, 6499);
    assert!(has_field(&output, "zone", "international"), "no zone field in `{output}`");
    assert!(has_field(&output, "weight_grams", "12000"), "no weight field in `{output}`");
    assert!(has_field(&output, "total_cents", "6499"), "no total field in `{output}`");
}

#[test]
fn the_record_sits_inside_a_span_naming_the_operation() {
    let source = InMemoryRateCardSource::new(SAMPLE);

    let (_, output) = observed(|| {
        quote_from(&source, &Parcel { weight_grams: 100, zone: "domestic".to_owned() })
    });

    assert!(output.contains("quote{"), "no quote span in `{output}`");
    assert!(has_field(&output, "outcome", "priced"), "span outcome missing from `{output}`");
}

#[test]
fn one_call_emits_one_record() {
    let source = InMemoryRateCardSource::new(SAMPLE);

    let ((), output) = observed(|| {
        for weight_grams in [100, 400, 1500] {
            let _ = quote_from(&source, &Parcel { weight_grams, zone: "domestic".to_owned() });
        }
    });

    assert_eq!(output.lines().filter(|line| line.contains("parcel priced")).count(), 3);
}

#[test]
fn a_failed_quote_is_observable_too() {
    let source = InMemoryRateCardSource::new(SAMPLE);

    let (_, output) = observed(|| {
        quote_from(&source, &Parcel { weight_grams: 100, zone: "lunar".to_owned() })
    });

    assert!(output.contains("parcel not priced"), "no failure record in `{output}`");
    assert!(has_field(&output, "zone", "lunar"), "no zone field in `{output}`");
    assert!(output.contains("unknown zone `lunar`"), "no reason in `{output}`");
    assert!(has_field(&output, "outcome", "failed"), "span outcome missing from `{output}`");
}
