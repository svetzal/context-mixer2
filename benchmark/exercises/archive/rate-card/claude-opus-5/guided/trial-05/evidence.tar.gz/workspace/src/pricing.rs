//! Turning a parcel and a rate card into a quote.
//!
//! This module is pure: given the same card and parcel it yields the same
//! quote, with no filesystem, environment, or clock involved.

use crate::card::RateCard;
use crate::error::QuoteError;
use crate::model::{Parcel, Quote};

/// Weight above which a parcel attracts the heavy surcharge, exclusive.
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
/// Flat surcharge for a parcel above [`HEAVY_THRESHOLD_GRAMS`].
const HEAVY_SURCHARGE_CENTS: u64 = 500;
/// The zone that attracts the proportional surcharge.
const SURCHARGED_ZONE: &str = "international";
/// Percent of `base_cents` added for [`SURCHARGED_ZONE`].
const ZONE_SURCHARGE_PERCENT: u64 = 20;
/// Denominator for the percentage above.
const PERCENT: u64 = 100;

impl RateCard {
    /// Prices a parcel against this card.
    ///
    /// The matching band is the lightest one whose `max_grams` is greater than
    /// or equal to the parcel's weight. Surcharges add together: a flat charge
    /// for a parcel above 10000 grams, plus 20% of the base for the
    /// `international` zone, rounded half-up to the cent.
    ///
    /// # Errors
    ///
    /// Returns [`QuoteError::UnknownZone`] if the card does not price the
    /// parcel's zone, or [`QuoteError::Overweight`] if the parcel is heavier
    /// than that zone's largest band.
    ///
    /// ```
    /// use ratecard::{Parcel, RateCard};
    ///
    /// let card = RateCard::parse("international\t500\t1499\n")?;
    /// let quote = card.price(&Parcel { weight_grams: 400, zone: "international".to_owned() })?;
    ///
    /// assert_eq!(quote.base_cents, 1499);
    /// assert_eq!(quote.surcharge_cents, 300); // 299.8 rounded half-up
    /// assert_eq!(quote.total_cents, 1799);
    /// # Ok::<(), ratecard::QuoteError>(())
    /// ```
    pub fn price(&self, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let bands = self
            .bands(&parcel.zone)
            .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

        let band = bands
            .iter()
            .find(|band| band.max_grams >= parcel.weight_grams)
            .ok_or_else(|| QuoteError::Overweight {
                grams: parcel.weight_grams,
                // A zone exists in the card only because a line created it, so
                // it always has at least one band; falling back to the parcel's
                // own weight keeps this total without an unwrap.
                limit: bands.last().map_or(parcel.weight_grams, |heaviest| heaviest.max_grams),
            })?;

        let base_cents = band.cents;
        let surcharge_cents = heavy_surcharge(parcel.weight_grams)
            .saturating_add(zone_surcharge(&parcel.zone, base_cents));

        Ok(Quote {
            base_cents,
            surcharge_cents,
            total_cents: base_cents.saturating_add(surcharge_cents),
            band_max_grams: band.max_grams,
        })
    }
}

/// The flat surcharge a parcel's weight attracts.
fn heavy_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > HEAVY_THRESHOLD_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    }
}

/// The proportional surcharge a zone attracts, rounded half-up to the cent.
fn zone_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone != SURCHARGED_ZONE {
        return 0;
    }
    // Integer arithmetic throughout: adding half the denominator before
    // dividing is round-half-up, with no floating point to misprice a cent.
    base_cents
        .saturating_mul(ZONE_SURCHARGE_PERCENT)
        .saturating_add(PERCENT / 2)
        / PERCENT
}

#[cfg(test)]
#[allow(clippy::unwrap_used, reason = "a failing unwrap in a test is the failure report")]
mod tests {
    use super::{zone_surcharge, HEAVY_SURCHARGE_CENTS};
    use crate::card::RateCard;
    use crate::error::QuoteError;
    use crate::model::Parcel;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn card() -> RateCard {
        RateCard::parse(SAMPLE).unwrap()
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel { weight_grams, zone: zone.to_owned() }
    }

    #[test]
    fn picks_the_lightest_band_that_still_covers_the_parcel() {
        let card = card();

        let quote = card.price(&parcel(600, "domestic")).unwrap();

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
    }

    #[test]
    fn a_band_covers_a_parcel_of_exactly_its_threshold() {
        let card = card();

        let quote = card.price(&parcel(500, "domestic")).unwrap();

        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.base_cents, 599);
    }

    #[test]
    fn a_gram_over_a_threshold_moves_up_a_band() {
        let card = card();

        assert_eq!(card.price(&parcel(501, "domestic")).unwrap().band_max_grams, 2000);
    }

    #[test]
    fn the_lightest_parcel_prices_at_the_lightest_band() {
        let card = card();

        assert_eq!(card.price(&parcel(0, "domestic")).unwrap().base_cents, 599);
    }

    #[test]
    fn weight_above_the_heavy_threshold_adds_the_flat_surcharge() {
        let card = card();

        let quote = card.price(&parcel(10_001, "domestic")).unwrap();

        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, HEAVY_SURCHARGE_CENTS);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn the_heavy_threshold_itself_is_not_surcharged() {
        let card = card();

        assert_eq!(card.price(&parcel(10_000, "domestic")).unwrap().surcharge_cents, 0);
    }

    #[test]
    fn international_adds_a_fifth_of_the_base() {
        let card = card();

        let quote = card.price(&parcel(500, "international")).unwrap();

        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn surcharges_add_together() {
        let card = card();

        let quote = card.price(&parcel(15_000, "international")).unwrap();

        assert_eq!(quote.base_cents, 4999);
        // 500 heavy + 1000 (999.8 rounded half-up) international
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20_000);
    }

    #[test]
    fn the_zone_surcharge_rounds_half_up() {
        // 20% of these bases lands on a whole cent, below the half cent, and above it.
        assert_eq!(zone_surcharge("international", 100), 20);
        assert_eq!(zone_surcharge("international", 102), 20); // 20.4 down
        assert_eq!(zone_surcharge("international", 1499), 300); // 299.8 up
        assert_eq!(zone_surcharge("international", 5), 1); // exactly 1.0
        assert_eq!(zone_surcharge("international", 1), 0); // 0.2 down
        assert_eq!(zone_surcharge("international", 3), 1); // 0.6 up
        assert_eq!(zone_surcharge("domestic", 1499), 0);
    }

    #[test]
    fn a_zone_the_card_does_not_price_is_unknown() {
        let card = card();

        assert_eq!(
            card.price(&parcel(100, "lunar")),
            Err(QuoteError::UnknownZone("lunar".to_owned()))
        );
    }

    #[test]
    fn zone_matching_is_exact() {
        let card = card();

        assert_eq!(
            card.price(&parcel(100, "Domestic")),
            Err(QuoteError::UnknownZone("Domestic".to_owned()))
        );
    }

    #[test]
    fn a_parcel_past_the_largest_band_is_overweight() {
        let card = card();

        assert_eq!(
            card.price(&parcel(20_001, "international")),
            Err(QuoteError::Overweight { grams: 20_001, limit: 20_000 })
        );
    }

    #[test]
    fn the_overweight_limit_is_the_zones_own_largest_band() {
        let card = RateCard::parse("domestic\t500\t599\ninternational\t20000\t4999\n").unwrap();

        assert_eq!(
            card.price(&parcel(600, "domestic")),
            Err(QuoteError::Overweight { grams: 600, limit: 500 })
        );
    }
}
