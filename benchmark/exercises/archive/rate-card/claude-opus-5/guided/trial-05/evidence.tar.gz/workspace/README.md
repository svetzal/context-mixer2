# ratecard

Shipping quotes for the fulfilment service.

Warehouse operators price outbound parcels against a rate card that operations
maintains and redeploys without a code change. This crate owns reading that card
and turning a parcel into a quote.

## Using it

`quote` reads the tab-separated card named by the `RATECARD_PATH` environment
variable on every call, so a redeployed card prices the next parcel:

```rust
use ratecard::{quote, Parcel};

let quoted = quote(&Parcel { weight_grams: 750, zone: "domestic".to_owned() })?;
assert_eq!(quoted.total_cents, quoted.base_cents + quoted.surcharge_cents);
```

Every failure a caller can recover from — an undeployed card, a bad line in it,
an unpriced zone, an overweight parcel — comes back as a `QuoteError` rather
than a panic. Each call emits a `quote` tracing span and a record carrying the
zone, weight in grams, and total in cents as queryable fields.

## Shape

- `card` and `pricing` are the pure core: card text in, quote out, no I/O.
- `source` is the edge. `RateCardSource` is the crate's own contract for where
  card text comes from; `EnvRateCardSource` reads the deployed file and
  `InMemoryRateCardSource` serves a card from memory for tests.
- `quote_from` prices against any source; `quote` is that bound to the
  deployed card.

## Development

```bash
cargo test
cargo clippy --all-targets
cargo doc --no-deps
```
