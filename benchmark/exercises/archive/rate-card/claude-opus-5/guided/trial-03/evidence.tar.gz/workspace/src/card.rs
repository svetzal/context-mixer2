//! Pure rate card parsing and band selection. Nothing here touches the
//! filesystem or the environment: it turns rate card *text* into bands, and
//! bands into the one that prices a parcel.

use std::collections::BTreeMap;

use crate::model::QuoteError;

/// One priced weight band within a zone.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct Band {
    pub(crate) max_grams: u32,
    pub(crate) cents: u64,
}

/// The bands operations published, grouped by zone.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub(crate) struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

impl RateCard {
    /// Parse tab-separated rate card text.
    ///
    /// Empty lines and lines beginning with `#` are ignored. Every other line
    /// must be exactly three tab-separated fields — zone, band max in grams,
    /// cents — or the parse fails with the offending 1-based line number,
    /// counted across every line in the text.
    pub(crate) fn parse(text: &str) -> Result<Self, QuoteError> {
        let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

        for (index, raw_line) in text.lines().enumerate() {
            let line = raw_line.strip_suffix('\r').unwrap_or(raw_line);
            if line.trim().is_empty() || line.trim_start().starts_with('#') {
                continue;
            }

            let malformed = || QuoteError::MalformedRateCard {
                line: index.saturating_add(1),
            };

            let mut fields = line.split('\t');
            let (Some(zone), Some(max_grams), Some(cents), None) =
                (fields.next(), fields.next(), fields.next(), fields.next())
            else {
                return Err(malformed());
            };

            let band = Band {
                max_grams: max_grams.parse().map_err(|_| malformed())?,
                cents: cents.parse().map_err(|_| malformed())?,
            };
            zones.entry(zone.to_owned()).or_default().push(band);
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(Self { zones })
    }

    /// The first band in the zone whose upper bound admits `grams`.
    ///
    /// A zone the card does not carry is [`QuoteError::UnknownZone`]; a weight
    /// past the zone's largest band is [`QuoteError::Overweight`].
    pub(crate) fn band_for(&self, zone: &str, grams: u32) -> Result<Band, QuoteError> {
        let bands = self
            .zones
            .get(zone)
            .filter(|bands| !bands.is_empty())
            .ok_or_else(|| QuoteError::UnknownZone(zone.to_owned()))?;

        bands.iter().find(|band| band.max_grams >= grams).copied().ok_or_else(|| {
            QuoteError::Overweight {
                grams,
                limit: bands.last().map_or(0, |band| band.max_grams),
            }
        })
    }
}

#[cfg(test)]
mod tests {
    #![allow(clippy::unwrap_used)]

    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn comments_and_blank_lines_are_ignored() {
        let card = RateCard::parse("\n# a comment\n\ndomestic\t500\t599\n").unwrap();

        assert_eq!(
            card.band_for("domestic", 100).unwrap(),
            Band {
                max_grams: 500,
                cents: 599
            }
        );
    }

    #[test]
    fn empty_text_carries_no_zones() {
        let card = RateCard::parse("").unwrap();

        assert_eq!(
            card.band_for("domestic", 1),
            Err(QuoteError::UnknownZone("domestic".to_owned()))
        );
    }

    #[test]
    fn the_matching_band_is_the_first_whose_bound_admits_the_weight() {
        let card = RateCard::parse(SAMPLE).unwrap();

        assert_eq!(card.band_for("domestic", 1).unwrap().max_grams, 500);
        assert_eq!(card.band_for("domestic", 500).unwrap().max_grams, 500);
        assert_eq!(card.band_for("domestic", 501).unwrap().max_grams, 2000);
        assert_eq!(card.band_for("domestic", 20_000).unwrap().max_grams, 20_000);
    }

    #[test]
    fn a_zero_gram_parcel_falls_in_the_smallest_band() {
        let card = RateCard::parse(SAMPLE).unwrap();

        assert_eq!(card.band_for("domestic", 0).unwrap().max_grams, 500);
    }

    #[test]
    fn bands_apply_in_ascending_order_however_the_file_lists_them() {
        let card = RateCard::parse("domestic\t20000\t1799\ndomestic\t500\t599\n").unwrap();

        assert_eq!(
            card.band_for("domestic", 100).unwrap(),
            Band {
                max_grams: 500,
                cents: 599
            }
        );
    }

    #[test]
    fn an_absent_zone_carries_the_requested_zone() {
        let card = RateCard::parse(SAMPLE).unwrap();

        assert_eq!(card.band_for("lunar", 100), Err(QuoteError::UnknownZone("lunar".to_owned())));
    }

    #[test]
    fn a_weight_past_the_largest_band_reports_that_bound_as_the_limit() {
        let card = RateCard::parse(SAMPLE).unwrap();

        assert_eq!(
            card.band_for("domestic", 20_001),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            })
        );
    }

    #[test]
    fn the_limit_is_per_zone() {
        let card = RateCard::parse("domestic\t20000\t1799\nislands\t500\t999\n").unwrap();

        assert_eq!(
            card.band_for("islands", 600),
            Err(QuoteError::Overweight {
                grams: 600,
                limit: 500
            })
        );
    }

    #[test]
    fn too_few_fields_is_malformed_at_its_line_number() {
        assert_eq!(
            RateCard::parse("domestic\t500\t599\ndomestic\t2000\n"),
            Err(QuoteError::MalformedRateCard { line: 2 })
        );
    }

    #[test]
    fn too_many_fields_is_malformed() {
        assert_eq!(
            RateCard::parse("domestic\t500\t599\textra\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn a_number_that_does_not_parse_is_malformed() {
        assert_eq!(
            RateCard::parse("domestic\theavy\t599\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(
            RateCard::parse("domestic\t500\tfree\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(
            RateCard::parse("domestic\t-500\t599\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn line_numbers_count_comments_and_blanks() {
        let text = "# header\n\ndomestic\t500\t599\n\n# note\nbroken line\n";

        assert_eq!(RateCard::parse(text), Err(QuoteError::MalformedRateCard { line: 6 }));
    }

    #[test]
    fn space_separated_lines_are_malformed() {
        assert_eq!(
            RateCard::parse("domestic 500 599\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn carriage_returns_survive_a_windows_authored_card() {
        let card = RateCard::parse("domestic\t500\t599\r\ndomestic\t2000\t899\r\n").unwrap();

        assert_eq!(card.band_for("domestic", 1_500).unwrap().cents, 899);
    }
}
