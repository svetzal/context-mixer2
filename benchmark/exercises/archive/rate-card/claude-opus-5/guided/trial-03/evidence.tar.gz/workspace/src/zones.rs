//! Human-facing names for the zones the rate card prices.

/// The label operators know a zone by, or the zone itself when it has no
/// registered label.
///
/// ```
/// assert_eq!(ratecard::zones::zone_label("domestic"), "Domestic ground");
/// assert_eq!(ratecard::zones::zone_label("islands"), "islands");
/// ```
#[must_use]
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn known_zones_carry_operator_labels() {
        assert_eq!(zone_label("domestic"), "Domestic ground");
        assert_eq!(zone_label("international"), "International air");
    }

    #[test]
    fn an_unlabelled_zone_speaks_for_itself() {
        assert_eq!(zone_label("islands"), "islands");
    }
}
