//! Pure pricing policy: given a parsed rate card and a parcel, what is owed.

use crate::card::RateCard;
use crate::model::{Parcel, Quote, QuoteError};

/// Weight above which a parcel attracts the heavy-parcel surcharge.
const HEAVY_ABOVE_GRAMS: u32 = 10_000;
/// Flat surcharge for a parcel heavier than [`HEAVY_ABOVE_GRAMS`].
const HEAVY_SURCHARGE_CENTS: u64 = 500;
/// The zone that attracts the proportional surcharge.
const INTERNATIONAL_ZONE: &str = "international";

/// Price `parcel` against `card`.
pub(crate) fn price(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let band = card.band_for(&parcel.zone, parcel.weight_grams)?;
    let base_cents = band.cents;

    let heavy = if parcel.weight_grams > HEAVY_ABOVE_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    };
    let international = if parcel.zone == INTERNATIONAL_ZONE {
        twenty_percent_half_up(base_cents)
    } else {
        0
    };

    let surcharge_cents = heavy.saturating_add(international);
    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    })
}

/// A fifth of `cents`, rounded half-up to the cent, in integer arithmetic.
fn twenty_percent_half_up(cents: u64) -> u64 {
    cents.saturating_mul(2).saturating_add(5) / 10
}

#[cfg(test)]
mod tests {
    #![allow(clippy::unwrap_used)]

    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn card() -> RateCard {
        RateCard::parse(SAMPLE).unwrap()
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_owned(),
        }
    }

    #[test]
    fn a_light_domestic_parcel_pays_its_band_and_nothing_more() {
        let quote = price(&card(), &parcel(400, "domestic")).unwrap();

        assert_eq!(
            quote,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn a_parcel_at_ten_thousand_grams_is_not_yet_heavy() {
        let quote = price(&card(), &parcel(10_000, "domestic")).unwrap();

        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 1_799);
    }

    #[test]
    fn a_parcel_above_ten_thousand_grams_pays_the_heavy_surcharge() {
        let quote = price(&card(), &parcel(10_001, "domestic")).unwrap();

        assert_eq!(
            quote,
            Quote {
                base_cents: 1_799,
                surcharge_cents: 500,
                total_cents: 2_299,
                band_max_grams: 20_000,
            }
        );
    }

    #[test]
    fn an_international_parcel_pays_a_fifth_of_its_band_rounded_half_up() {
        // 20% of 1499 is 299.8, which rounds to 300.
        let quote = price(&card(), &parcel(300, "international")).unwrap();

        assert_eq!(
            quote,
            Quote {
                base_cents: 1_499,
                surcharge_cents: 300,
                total_cents: 1_799,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn surcharges_add_together() {
        // 20% of 4999 is 999.8 -> 1000, plus the 500 heavy surcharge.
        let quote = price(&card(), &parcel(15_000, "international")).unwrap();

        assert_eq!(
            quote,
            Quote {
                base_cents: 4_999,
                surcharge_cents: 1_500,
                total_cents: 6_499,
                band_max_grams: 20_000,
            }
        );
    }

    #[test]
    fn the_proportional_surcharge_rounds_half_up() {
        assert_eq!(twenty_percent_half_up(0), 0);
        assert_eq!(twenty_percent_half_up(1), 0); // 0.2
        assert_eq!(twenty_percent_half_up(3), 1); // 0.6
        assert_eq!(twenty_percent_half_up(500), 100); // exactly 100
        assert_eq!(twenty_percent_half_up(1_499), 300); // 299.8
        assert_eq!(twenty_percent_half_up(1_497), 299); // 299.4
    }

    #[test]
    fn pricing_surfaces_card_lookup_failures() {
        assert_eq!(
            price(&card(), &parcel(100, "lunar")),
            Err(QuoteError::UnknownZone("lunar".to_owned()))
        );
        assert_eq!(
            price(&card(), &parcel(30_000, "domestic")),
            Err(QuoteError::Overweight {
                grams: 30_000,
                limit: 20_000
            })
        );
    }
}
