# ratecard

Shipping quotes for the fulfilment service.

Warehouse operators price outbound parcels against a rate card that operations
maintains and redeploys without a code change. This crate owns reading that card
and turning a parcel into a quote.

## The rate card

`quote` reads the card named by the `RATECARD_PATH` environment variable. The
file is tab-separated — zone, band max in grams, cents — and ignores blank lines
and lines beginning with `#`:

```text
# zone	band_max_grams	cents
domestic	500	599
domestic	20000	1799
international	20000	4999
```

A parcel takes the first band for its zone whose bound admits its weight. On top
of that band price, a parcel over 10000g adds 500 cents, and the `international`
zone adds 20% of the band price rounded half-up.

Callers holding their own card — tests among them — can price against it
directly with `quote_from` and an `InMemoryRateCard`, without deploying a file.

## Structure

A pure core behind a thin shell: `card` and `pricing` hold the policy and touch
nothing outside themselves, `source` holds the filesystem and the environment,
and `quote` wires the two together and records what it did through `tracing`.

## Development

```bash
cargo test              # unit, integration, and doc tests
cargo clippy --all-targets
cargo doc --no-deps
```
