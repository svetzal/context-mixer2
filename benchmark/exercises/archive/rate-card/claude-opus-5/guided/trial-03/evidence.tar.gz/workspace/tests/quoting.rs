//! End-to-end quoting through the deployed rate card: `RATECARD_PATH`, a real
//! file, and the public `quote` entry point.
//!
//! `RATECARD_PATH` is process-wide state, so every test here takes the same
//! lock and restores the variable it found.

#![allow(clippy::unwrap_used, clippy::expect_used)]

use std::io::Write as _;
use std::sync::{Mutex, MutexGuard, OnceLock, PoisonError};

use ratecard::{quote, Parcel, QuoteError, RATE_CARD_PATH_ENV};

const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn env_lock() -> MutexGuard<'static, ()> {
    static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    LOCK.get_or_init(|| Mutex::new(()))
        .lock()
        .unwrap_or_else(PoisonError::into_inner)
}

/// Restores `RATECARD_PATH` to what it was, whether the test passed or not.
struct EnvGuard {
    previous: Option<String>,
    _lock: MutexGuard<'static, ()>,
}

impl EnvGuard {
    fn pointing_at(path: Option<&std::path::Path>) -> Self {
        let lock = env_lock();
        let previous = std::env::var(RATE_CARD_PATH_ENV).ok();
        match path {
            Some(path) => std::env::set_var(RATE_CARD_PATH_ENV, path),
            None => std::env::remove_var(RATE_CARD_PATH_ENV),
        }
        Self {
            previous,
            _lock: lock,
        }
    }
}

impl Drop for EnvGuard {
    fn drop(&mut self) {
        match &self.previous {
            Some(value) => std::env::set_var(RATE_CARD_PATH_ENV, value),
            None => std::env::remove_var(RATE_CARD_PATH_ENV),
        }
    }
}

/// Writes `text` to a temporary file and points `RATECARD_PATH` at it.
fn with_deployed_card<T>(text: &str, body: impl FnOnce() -> T) -> T {
    let mut file = tempfile::NamedTempFile::new().expect("temp file");
    file.write_all(text.as_bytes()).expect("write card");
    file.flush().expect("flush card");

    let _guard = EnvGuard::pointing_at(Some(file.path()));
    body()
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_owned(),
    }
}

#[test]
fn a_deployed_card_prices_a_domestic_parcel() {
    with_deployed_card(SAMPLE, || {
        let quoted = quote(&parcel(400, "domestic")).unwrap();

        assert_eq!(quoted.base_cents, 599);
        assert_eq!(quoted.surcharge_cents, 0);
        assert_eq!(quoted.total_cents, 599);
        assert_eq!(quoted.band_max_grams, 500);
    });
}

#[test]
fn a_heavy_international_parcel_pays_both_surcharges() {
    with_deployed_card(SAMPLE, || {
        let quoted = quote(&parcel(12_000, "international")).unwrap();

        assert_eq!(quoted.base_cents, 4_999);
        assert_eq!(quoted.surcharge_cents, 1_500);
        assert_eq!(quoted.total_cents, 6_499);
        assert_eq!(quoted.band_max_grams, 20_000);
    });
}

#[test]
fn an_unknown_zone_carries_the_zone_that_was_asked_for() {
    with_deployed_card(SAMPLE, || {
        assert_eq!(quote(&parcel(400, "lunar")), Err(QuoteError::UnknownZone("lunar".to_owned())));
    });
}

#[test]
fn an_overweight_parcel_carries_the_zone_limit() {
    with_deployed_card(SAMPLE, || {
        assert_eq!(
            quote(&parcel(25_000, "international")),
            Err(QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000
            })
        );
    });
}

#[test]
fn a_malformed_card_carries_the_line_number() {
    let card = format!("{SAMPLE}\nislands\t500\n");

    with_deployed_card(&card, || {
        assert_eq!(quote(&parcel(400, "domestic")), Err(QuoteError::MalformedRateCard { line: 8 }));
    });
}

#[test]
fn an_unset_path_leaves_the_card_unavailable() {
    let _guard = EnvGuard::pointing_at(None);

    assert_eq!(quote(&parcel(400, "domestic")), Err(QuoteError::RateCardUnavailable));
}

#[test]
fn a_missing_file_leaves_the_card_unavailable() {
    let directory = tempfile::tempdir().expect("temp dir");
    let absent = directory.path().join("no-such-card.tsv");
    let _guard = EnvGuard::pointing_at(Some(&absent));

    assert_eq!(quote(&parcel(400, "domestic")), Err(QuoteError::RateCardUnavailable));
}

#[test]
fn an_unreadable_card_leaves_the_card_unavailable() {
    // A directory is readable as a path but not as a file.
    let directory = tempfile::tempdir().expect("temp dir");
    let _guard = EnvGuard::pointing_at(Some(directory.path()));

    assert_eq!(quote(&parcel(400, "domestic")), Err(QuoteError::RateCardUnavailable));
}

#[test]
fn a_redeployed_card_reprices_without_a_code_change() {
    let first = with_deployed_card(SAMPLE, || quote(&parcel(400, "domestic")).unwrap());
    let raised = SAMPLE.replace("domestic\t500\t599", "domestic\t500\t699");
    let second = with_deployed_card(&raised, || quote(&parcel(400, "domestic")).unwrap());

    assert_eq!(first.total_cents, 599);
    assert_eq!(second.total_cents, 699);
}
