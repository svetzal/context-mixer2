//! Shipping quotes for the fulfilment service.
//!
//! Operations maintains a tab-separated rate card and redeploys it without a
//! code change; this crate reads that card and turns a [`Parcel`] into a
//! [`Quote`].
//!
//! ```
//! use ratecard::{InMemoryRateCard, Parcel, quote_from};
//!
//! // Tab-separated: zone, band max in grams, cents.
//! let card = InMemoryRateCard::new(
//!     "domestic\t500\t599\ninternational\t500\t1499\n",
//! );
//!
//! let quote = quote_from(
//!     &card,
//!     &Parcel { weight_grams: 300, zone: "international".to_owned() },
//! )?;
//!
//! assert_eq!(quote.base_cents, 1_499);
//! assert_eq!(quote.surcharge_cents, 300); // 20% of 1499, rounded half-up
//! assert_eq!(quote.total_cents, 1_799);
//! assert_eq!(quote.band_max_grams, 500);
//! # Ok::<(), ratecard::QuoteError>(())
//! ```
//!
//! The structure is a pure core behind a thin shell: the `card` and `pricing`
//! modules hold the policy and touch nothing outside themselves, `source`
//! holds the filesystem and the environment, and [`quote`] wires the two
//! together and records what it did.

mod card;
mod model;
mod pricing;
mod source;

pub mod zones;

pub use model::{Parcel, Quote, QuoteError};
pub use source::{
    EnvRateCardSource, InMemoryRateCard, RateCardSource, UnavailableRateCard, RATE_CARD_PATH_ENV,
};

/// Price `parcel` against the rate card named by `RATECARD_PATH`.
///
/// # Errors
///
/// - [`QuoteError::RateCardUnavailable`] if the variable is unset or the file
///   cannot be read.
/// - [`QuoteError::MalformedRateCard`] if a line is not three tab-separated
///   fields or its numbers do not parse.
/// - [`QuoteError::UnknownZone`] if the card carries no bands for the parcel's
///   zone.
/// - [`QuoteError::Overweight`] if the parcel outweighs the zone's largest
///   band.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_from(&EnvRateCardSource, parcel)
}

/// Price `parcel` against the card `source` supplies.
///
/// [`quote`] is this function pointed at the deployed card; callers that hold
/// their own card — tests among them — can supply it directly.
///
/// # Errors
///
/// The same failures as [`quote`], with unavailability decided by `source`.
pub fn quote_from(source: &dyn RateCardSource, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "quote",
        zone = parcel.zone.as_str(),
        weight_grams = parcel.weight_grams,
    );
    let _entered = span.enter();

    let result = source
        .load()
        .and_then(|text| card::RateCard::parse(&text))
        .and_then(|card| pricing::price(&card, parcel));

    match &result {
        Ok(quote) => tracing::info!(
            zone = parcel.zone.as_str(),
            weight_grams = parcel.weight_grams,
            total_cents = quote.total_cents,
            "parcel quoted"
        ),
        Err(error) => tracing::warn!(
            zone = parcel.zone.as_str(),
            weight_grams = parcel.weight_grams,
            error = %error,
            "parcel not quoted"
        ),
    }

    result
}

#[cfg(test)]
mod tests {
    #![allow(clippy::unwrap_used)]

    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_owned(),
        }
    }

    #[test]
    fn a_parcel_is_priced_against_the_card_the_source_supplies() {
        let card = InMemoryRateCard::new(SAMPLE);

        let quote = quote_from(&card, &parcel(1_200, "domestic")).unwrap();

        assert_eq!(
            quote,
            Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2_000,
            }
        );
    }

    #[test]
    fn an_unavailable_source_stops_the_quote() {
        assert_eq!(
            quote_from(&UnavailableRateCard, &parcel(100, "domestic")),
            Err(QuoteError::RateCardUnavailable)
        );
    }

    #[test]
    fn a_malformed_card_reports_the_offending_line() {
        let card = InMemoryRateCard::new("# header\ndomestic\t500\t599\nbroken\n");

        assert_eq!(
            quote_from(&card, &parcel(100, "domestic")),
            Err(QuoteError::MalformedRateCard { line: 3 })
        );
    }

    #[test]
    fn a_malformed_card_fails_even_when_the_parcel_would_have_priced() {
        let card = InMemoryRateCard::new("domestic\t500\t599\ndomestic\tlots\t899\n");

        assert_eq!(
            quote_from(&card, &parcel(100, "domestic")),
            Err(QuoteError::MalformedRateCard { line: 2 })
        );
    }
}
