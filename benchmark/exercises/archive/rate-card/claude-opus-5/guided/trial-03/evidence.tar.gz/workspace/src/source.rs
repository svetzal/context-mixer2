//! The edge contract for fetching rate card text, and the adapters that
//! satisfy it. The filesystem and the environment live here and nowhere else.

use crate::model::QuoteError;

/// Environment variable naming the rate card operations deployed.
pub const RATE_CARD_PATH_ENV: &str = "RATECARD_PATH";

/// Where rate card text comes from.
///
/// Pricing depends on this contract rather than on the filesystem, so callers
/// and tests can supply a card without deploying a file.
pub trait RateCardSource {
    /// Fetch the current rate card text.
    ///
    /// # Errors
    ///
    /// Returns [`QuoteError::RateCardUnavailable`] when the card cannot be
    /// located or read.
    fn load(&self) -> Result<String, QuoteError>;
}

/// Reads the card from the file named by [`RATE_CARD_PATH_ENV`].
///
/// An unset variable, a missing file, and an unreadable file are all
/// [`QuoteError::RateCardUnavailable`]: from a caller's seat they are the same
/// operational fact.
#[derive(Debug, Clone, Copy, Default)]
pub struct EnvRateCardSource;

impl RateCardSource for EnvRateCardSource {
    fn load(&self) -> Result<String, QuoteError> {
        let path =
            std::env::var(RATE_CARD_PATH_ENV).map_err(|_| QuoteError::RateCardUnavailable)?;
        std::fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}

/// A rate card held in memory, for tests and callers that carry their own card.
///
/// ```
/// use ratecard::{InMemoryRateCard, Parcel, quote_from};
///
/// let card = InMemoryRateCard::new("domestic\t500\t599\n");
/// let quote = quote_from(&card, &Parcel { weight_grams: 100, zone: "domestic".into() })?;
///
/// assert_eq!(quote.total_cents, 599);
/// # Ok::<(), ratecard::QuoteError>(())
/// ```
#[derive(Debug, Clone)]
pub struct InMemoryRateCard {
    text: String,
}

impl InMemoryRateCard {
    /// Hold `text` as the rate card.
    #[must_use]
    pub fn new(text: impl Into<String>) -> Self {
        Self { text: text.into() }
    }
}

impl RateCardSource for InMemoryRateCard {
    fn load(&self) -> Result<String, QuoteError> {
        Ok(self.text.clone())
    }
}

/// A source that is always unavailable, for exercising that failure path.
#[derive(Debug, Clone, Copy, Default)]
pub struct UnavailableRateCard;

impl RateCardSource for UnavailableRateCard {
    fn load(&self) -> Result<String, QuoteError> {
        Err(QuoteError::RateCardUnavailable)
    }
}

#[cfg(test)]
mod tests {
    #![allow(clippy::unwrap_used)]

    use super::*;

    #[test]
    fn an_in_memory_card_yields_the_text_it_holds() {
        let card = InMemoryRateCard::new("domestic\t500\t599\n");

        assert_eq!(card.load().unwrap(), "domestic\t500\t599\n");
    }

    #[test]
    fn an_unavailable_card_reports_itself_unavailable() {
        assert_eq!(UnavailableRateCard.load(), Err(QuoteError::RateCardUnavailable));
    }
}
