//! The vocabulary a caller quotes against: a parcel in, a quote or a named
//! failure out.

use std::fmt;

/// A parcel awaiting a price.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Billable weight of the parcel, in grams.
    pub weight_grams: u32,
    /// Rate card zone the parcel ships to, e.g. `domestic`.
    pub zone: String,
}

/// The priced result for a parcel.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quote {
    /// Price of the matching band, before surcharges.
    pub base_cents: u64,
    /// Surcharges that apply on top of the band price.
    pub surcharge_cents: u64,
    /// What the customer pays: `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// Upper weight bound of the band that priced this parcel.
    pub band_max_grams: u32,
}

/// Why a parcel could not be priced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card could not be located or read.
    RateCardUnavailable,
    /// A rate card line was not three tab-separated fields, or its numbers did
    /// not parse. Carries the 1-based line number, counting every line in the
    /// file including comments and blanks.
    MalformedRateCard {
        /// 1-based line number of the offending line.
        line: usize,
    },
    /// The requested zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel weighs more than the zone's largest band admits.
    Overweight {
        /// Weight of the parcel, in grams.
        grams: u32,
        /// Largest `band_max_grams` the zone offers.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => f.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone `{zone}`"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel of {grams}g exceeds the {limit}g limit for its zone")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn each_error_names_its_cause() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card is unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 4 }.to_string(),
            "malformed rate card at line 4"
        );
        assert_eq!(QuoteError::UnknownZone("lunar".to_owned()).to_string(), "unknown zone `lunar`");
        assert_eq!(
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000
            }
            .to_string(),
            "parcel of 25000g exceeds the 20000g limit for its zone"
        );
    }

    #[test]
    fn quote_errors_are_std_errors() {
        fn as_std_error(error: QuoteError) -> Box<dyn std::error::Error> {
            Box::new(error)
        }

        let boxed = as_std_error(QuoteError::RateCardUnavailable);
        assert_eq!(boxed.to_string(), "rate card is unavailable");
    }
}
