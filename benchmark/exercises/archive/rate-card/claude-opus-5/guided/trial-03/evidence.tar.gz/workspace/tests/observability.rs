//! Every quote must be observable in operation. These tests capture the
//! diagnostic records a quote emits and assert on their fields individually —
//! a record whose zone, weight and total are only readable by scraping a
//! message string would not be queryable in production.

#![allow(clippy::unwrap_used, clippy::expect_used)]

use std::collections::BTreeMap;
use std::sync::{Arc, Mutex, PoisonError};

use tracing::field::{Field, Visit};
use tracing::span::{Attributes, Id, Record};
use tracing::{Event, Metadata, Subscriber};

use ratecard::{quote_from, InMemoryRateCard, Parcel, UnavailableRateCard};

const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t20000\t1799
international\t20000\t4999
";

/// One captured diagnostic record: its level, its message, and its fields as
/// separately addressable values.
#[derive(Debug, Clone)]
struct DiagnosticRecord {
    level: tracing::Level,
    fields: BTreeMap<String, String>,
}

impl DiagnosticRecord {
    fn field(&self, name: &str) -> Option<&str> {
        self.fields.get(name).map(String::as_str)
    }
}

/// A project-owned subscriber that records the events emitted on its thread.
#[derive(Debug, Clone, Default)]
struct RecordingSubscriber {
    records: Arc<Mutex<Vec<DiagnosticRecord>>>,
}

impl RecordingSubscriber {
    fn records(&self) -> Vec<DiagnosticRecord> {
        self.records.lock().unwrap_or_else(PoisonError::into_inner).clone()
    }
}

impl Subscriber for RecordingSubscriber {
    fn enabled(&self, _metadata: &Metadata<'_>) -> bool {
        true
    }

    fn register_callsite(
        &self,
        _metadata: &'static Metadata<'static>,
    ) -> tracing::subscriber::Interest {
        // `sometimes` keeps the decision per-event, so a subscriber installed
        // on one test thread never speaks for another.
        tracing::subscriber::Interest::sometimes()
    }

    fn new_span(&self, _span: &Attributes<'_>) -> Id {
        Id::from_u64(1)
    }

    fn record(&self, _span: &Id, _values: &Record<'_>) {}

    fn record_follows_from(&self, _span: &Id, _follows: &Id) {}

    fn event(&self, event: &Event<'_>) {
        let mut fields = FieldCollector::default();
        event.record(&mut fields);
        self.records
            .lock()
            .unwrap_or_else(PoisonError::into_inner)
            .push(DiagnosticRecord {
                level: *event.metadata().level(),
                fields: fields.0,
            });
    }

    fn enter(&self, _span: &Id) {}

    fn exit(&self, _span: &Id) {}
}

#[derive(Debug, Default)]
struct FieldCollector(BTreeMap<String, String>);

impl Visit for FieldCollector {
    fn record_str(&mut self, field: &Field, value: &str) {
        self.0.insert(field.name().to_owned(), value.to_owned());
    }

    fn record_u64(&mut self, field: &Field, value: u64) {
        self.0.insert(field.name().to_owned(), value.to_string());
    }

    fn record_i64(&mut self, field: &Field, value: i64) {
        self.0.insert(field.name().to_owned(), value.to_string());
    }

    fn record_debug(&mut self, field: &Field, value: &dyn std::fmt::Debug) {
        self.0.insert(field.name().to_owned(), format!("{value:?}"));
    }
}

fn capture<T>(body: impl FnOnce() -> T) -> (T, Vec<DiagnosticRecord>) {
    let subscriber = RecordingSubscriber::default();
    let outcome = tracing::subscriber::with_default(subscriber.clone(), body);
    (outcome, subscriber.records())
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_owned(),
    }
}

#[test]
fn a_priced_parcel_emits_a_record_carrying_zone_weight_and_total() {
    let card = InMemoryRateCard::new(SAMPLE);

    let (quoted, records) = capture(|| quote_from(&card, &parcel(15_000, "international")));

    let quoted = quoted.unwrap();
    let record = records
        .iter()
        .find(|record| record.field("total_cents").is_some())
        .expect("a record carrying the total");

    assert_eq!(record.field("zone"), Some("international"));
    assert_eq!(record.field("weight_grams"), Some("15000"));
    assert_eq!(record.field("total_cents"), Some(quoted.total_cents.to_string().as_str()));
}

#[test]
fn every_call_emits_exactly_one_record() {
    let card = InMemoryRateCard::new(SAMPLE);

    let ((), records) = capture(|| {
        let _ = quote_from(&card, &parcel(100, "domestic"));
        let _ = quote_from(&card, &parcel(200, "domestic"));
    });

    assert_eq!(records.len(), 2);
}

#[test]
fn a_failed_quote_is_observable_too() {
    let (_, records) = capture(|| quote_from(&UnavailableRateCard, &parcel(100, "domestic")));

    let record = records.first().expect("a record");

    assert_eq!(record.level, tracing::Level::WARN);
    assert_eq!(record.field("zone"), Some("domestic"));
    assert_eq!(record.field("weight_grams"), Some("100"));
    assert_eq!(record.field("error"), Some("rate card is unavailable"));
}

#[test]
fn quoting_works_with_no_subscriber_installed() {
    let card = InMemoryRateCard::new(SAMPLE);

    let quoted = quote_from(&card, &parcel(100, "domestic")).unwrap();

    assert_eq!(quoted.total_cents, 599);
}
