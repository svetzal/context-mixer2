//! Where the rate card text comes from.
//!
//! The core prices against text it is handed; this module owns the contract for
//! producing that text and the one concrete adapter that reads it from the
//! environment and the filesystem. Tests substitute an in-memory implementation
//! rather than intercepting the filesystem.

use std::fmt;
use std::path::PathBuf;

/// Environment variable naming the rate card file.
pub const RATECARD_PATH_VAR: &str = "RATECARD_PATH";

/// The rate card could not be produced.
///
/// Deliberately opaque: callers of [`crate::quote`] see only that the card is
/// unavailable, and nothing about the underlying vendor or I/O failure leaks
/// into the core.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct RateCardUnavailable;

impl fmt::Display for RateCardUnavailable {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("rate card unavailable")
    }
}

impl std::error::Error for RateCardUnavailable {}

/// Supplies the raw rate card text.
pub trait RateCardSource {
    /// Read the current rate card.
    ///
    /// # Errors
    ///
    /// Returns [`RateCardUnavailable`] when the card cannot be located or read.
    fn load(&self) -> Result<String, RateCardUnavailable>;
}

/// Reads the rate card from the file named by [`RATECARD_PATH_VAR`].
///
/// The variable is read on every load, so operations can redeploy the card
/// without restarting the process.
#[derive(Debug, Clone, Copy, Default)]
pub struct EnvPathRateCard;

impl EnvPathRateCard {
    /// A source that follows `RATECARD_PATH`.
    #[must_use]
    pub fn new() -> Self {
        Self
    }
}

impl RateCardSource for EnvPathRateCard {
    fn load(&self) -> Result<String, RateCardUnavailable> {
        let path = std::env::var_os(RATECARD_PATH_VAR)
            .map(PathBuf::from)
            .ok_or(RateCardUnavailable)?;

        if path.as_os_str().is_empty() {
            return Err(RateCardUnavailable);
        }

        std::fs::read_to_string(&path).map_err(|error| {
            tracing::warn!(
                path = %path.display(),
                error = %error,
                "rate card could not be read"
            );
            RateCardUnavailable
        })
    }
}

/// A rate card held in memory, for tests and for callers that already have the
/// card text.
///
/// ```
/// use ratecard::{InMemoryRateCard, RateCardSource};
///
/// let source = InMemoryRateCard::new("domestic\t500\t599\n");
/// assert_eq!(source.load()?, "domestic\t500\t599\n");
/// # Ok::<(), ratecard::RateCardUnavailable>(())
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct InMemoryRateCard {
    text: Option<String>,
}

impl InMemoryRateCard {
    /// A source that hands back `text`.
    #[must_use]
    pub fn new(text: impl Into<String>) -> Self {
        Self {
            text: Some(text.into()),
        }
    }

    /// A source that always reports the card as unavailable.
    #[must_use]
    pub fn unavailable() -> Self {
        Self { text: None }
    }
}

impl RateCardSource for InMemoryRateCard {
    fn load(&self) -> Result<String, RateCardUnavailable> {
        self.text.clone().ok_or(RateCardUnavailable)
    }
}

#[cfg(test)]
mod tests {
    // Tests assert by panicking; the no-panic policy governs library code.
    #![allow(clippy::expect_used, clippy::panic, clippy::unwrap_used)]

    use super::{InMemoryRateCard, RateCardSource, RateCardUnavailable};

    #[test]
    fn in_memory_source_returns_its_text() {
        let source = InMemoryRateCard::new("domestic\t500\t599\n");
        assert_eq!(source.load(), Ok("domestic\t500\t599\n".to_owned()));
    }

    #[test]
    fn in_memory_source_can_report_unavailability() {
        assert_eq!(InMemoryRateCard::unavailable().load(), Err(RateCardUnavailable));
    }

    #[test]
    fn unavailability_reads_plainly() {
        assert_eq!(RateCardUnavailable.to_string(), "rate card unavailable");
    }
}
