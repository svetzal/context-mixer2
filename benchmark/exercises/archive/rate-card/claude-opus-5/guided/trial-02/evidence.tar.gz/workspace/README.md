# ratecard

Shipping quotes for the fulfilment service.

Warehouse operators price outbound parcels against a rate card that operations
maintains and redeploys without a code change. This crate owns reading that card
and turning a parcel into a quote.

## Use

`quote` reads the rate card from the path in `RATECARD_PATH` on every call, so
operations can redeploy the card without restarting the process.

```rust
use ratecard::{quote, Parcel};

match quote(&Parcel::new(750, "domestic")) {
    Ok(quoted) => println!("{} cents", quoted.total_cents),
    Err(error) => eprintln!("no quote: {error}"),
}
```

The card is tab-separated — zone, band maximum in grams, cents — with blank
lines and `#` comments ignored:

```text
# zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
international	20000	4999
```

Bands apply in ascending order and the matching one is the first whose maximum
is at or above the parcel weight. Parcels over 10000 g add 500 cents, and the
`international` zone adds 20% of the base price rounded half-up.

Pricing itself is pure: `RateCard::parse` plus `RateCard::price` quote without
touching the environment or the filesystem, and `quote_from` prices against any
`RateCardSource` — including the in-memory one. Every call emits a `quote`
tracing span and one event carrying the zone, weight, and outcome as fields.

## Development

```bash
cargo test
cargo clippy --all-targets
cargo doc --no-deps
```
