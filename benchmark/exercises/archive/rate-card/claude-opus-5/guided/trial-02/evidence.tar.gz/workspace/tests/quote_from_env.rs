//! Wiring: `quote` finds the card through `RATECARD_PATH` and prices against it.
//!
//! `RATECARD_PATH` is process-global, so these tests serialise on a lock rather
//! than racing each other's environment.

// Tests assert by panicking; the no-panic policy governs library code.
#![allow(clippy::expect_used, clippy::panic, clippy::unwrap_used)]

use std::fs;
use std::io::Write as _;
use std::sync::{Mutex, MutexGuard, PoisonError};

use ratecard::{quote, Parcel, QuoteError, RATECARD_PATH_VAR};
use tempfile::{NamedTempFile, TempDir};

static ENV_LOCK: Mutex<()> = Mutex::new(());

const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn env_lock() -> MutexGuard<'static, ()> {
    ENV_LOCK.lock().unwrap_or_else(PoisonError::into_inner)
}

/// Point `RATECARD_PATH` at a file holding `card` for the life of the returned
/// guard, restoring the previous value afterwards.
struct CardOnDisk {
    _guard: MutexGuard<'static, ()>,
    previous: Option<std::ffi::OsString>,
    _file: Option<NamedTempFile>,
}

impl CardOnDisk {
    fn holding(card: &str) -> Self {
        let guard = env_lock();
        let previous = std::env::var_os(RATECARD_PATH_VAR);

        let mut file = NamedTempFile::new().expect("temp file is creatable");
        file.write_all(card.as_bytes()).expect("card is writable");
        file.flush().expect("card is flushable");
        std::env::set_var(RATECARD_PATH_VAR, file.path());

        Self {
            _guard: guard,
            previous,
            _file: Some(file),
        }
    }

    fn with_path(path: Option<&std::path::Path>) -> Self {
        let guard = env_lock();
        let previous = std::env::var_os(RATECARD_PATH_VAR);

        match path {
            Some(path) => std::env::set_var(RATECARD_PATH_VAR, path),
            None => std::env::remove_var(RATECARD_PATH_VAR),
        }

        Self {
            _guard: guard,
            previous,
            _file: None,
        }
    }
}

impl Drop for CardOnDisk {
    fn drop(&mut self) {
        match self.previous.take() {
            Some(previous) => std::env::set_var(RATECARD_PATH_VAR, previous),
            None => std::env::remove_var(RATECARD_PATH_VAR),
        }
    }
}

#[test]
fn prices_a_domestic_parcel_from_the_deployed_card() {
    let _card = CardOnDisk::holding(CARD);

    let quoted = quote(&Parcel::new(750, "domestic")).expect("parcel prices");

    assert_eq!(quoted.base_cents, 899);
    assert_eq!(quoted.surcharge_cents, 0);
    assert_eq!(quoted.total_cents, 899);
    assert_eq!(quoted.band_max_grams, 2000);
}

#[test]
fn prices_a_heavy_international_parcel_from_the_deployed_card() {
    let _card = CardOnDisk::holding(CARD);

    let quoted = quote(&Parcel::new(12_500, "international")).expect("parcel prices");

    assert_eq!(quoted.base_cents, 4999);
    assert_eq!(quoted.surcharge_cents, 1500);
    assert_eq!(quoted.total_cents, 6499);
    assert_eq!(quoted.band_max_grams, 20_000);
}

#[test]
fn rejects_a_zone_the_deployed_card_does_not_publish() {
    let _card = CardOnDisk::holding(CARD);

    assert_eq!(
        quote(&Parcel::new(100, "lunar")),
        Err(QuoteError::UnknownZone("lunar".to_owned()))
    );
}

#[test]
fn rejects_a_parcel_heavier_than_the_deployed_card_allows() {
    let _card = CardOnDisk::holding(CARD);

    assert_eq!(
        quote(&Parcel::new(30_000, "domestic")),
        Err(QuoteError::Overweight {
            grams: 30_000,
            limit: 20_000,
        })
    );
}

#[test]
fn reports_a_malformed_line_by_its_number_in_the_file() {
    let _card = CardOnDisk::holding("# header\n\ndomestic\t500\t599\ndomestic\t2000\tfree\n");

    assert_eq!(
        quote(&Parcel::new(100, "domestic")),
        Err(QuoteError::MalformedRateCard { line: 4 })
    );
}

#[test]
fn reports_an_unset_path_as_unavailable() {
    let _card = CardOnDisk::with_path(None);

    assert_eq!(quote(&Parcel::new(100, "domestic")), Err(QuoteError::RateCardUnavailable));
}

#[test]
fn reports_a_missing_file_as_unavailable() {
    let directory = TempDir::new().expect("temp dir is creatable");
    let missing = directory.path().join("no-such-card.tsv");
    let _card = CardOnDisk::with_path(Some(&missing));

    assert_eq!(quote(&Parcel::new(100, "domestic")), Err(QuoteError::RateCardUnavailable));
}

#[test]
fn reports_an_unreadable_path_as_unavailable() {
    // A directory is a path that exists but cannot be read as a rate card.
    let directory = TempDir::new().expect("temp dir is creatable");
    let _card = CardOnDisk::with_path(Some(directory.path()));

    assert_eq!(quote(&Parcel::new(100, "domestic")), Err(QuoteError::RateCardUnavailable));
}

#[test]
fn follows_the_card_when_operations_redeploys_it() {
    let directory = TempDir::new().expect("temp dir is creatable");
    let path = directory.path().join("ratecard.tsv");
    fs::write(&path, "domestic\t500\t599\n").expect("card is writable");
    let _card = CardOnDisk::with_path(Some(&path));

    let before = quote(&Parcel::new(100, "domestic")).expect("parcel prices");
    assert_eq!(before.total_cents, 599);

    fs::write(&path, "domestic\t500\t649\n").expect("card is rewritable");

    let after = quote(&Parcel::new(100, "domestic")).expect("parcel prices");
    assert_eq!(after.total_cents, 649);
}
