//! Human-facing names for the zones the rate card prices.

/// The label operators recognise for `zone`, or the zone itself when it has no
/// established name.
///
/// ```
/// use ratecard::zones::zone_label;
///
/// assert_eq!(zone_label("domestic"), "Domestic ground");
/// assert_eq!(zone_label("lunar"), "lunar");
/// ```
#[must_use]
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}

#[cfg(test)]
mod tests {
    // Tests assert by panicking; the no-panic policy governs library code.
    #![allow(clippy::expect_used, clippy::panic, clippy::unwrap_used)]

    use super::zone_label;

    #[test]
    fn names_the_published_zones() {
        assert_eq!(zone_label("domestic"), "Domestic ground");
        assert_eq!(zone_label("international"), "International air");
    }

    #[test]
    fn passes_an_unknown_zone_through() {
        assert_eq!(zone_label("orbital"), "orbital");
    }
}
