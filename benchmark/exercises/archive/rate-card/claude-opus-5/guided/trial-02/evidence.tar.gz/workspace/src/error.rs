//! Failure modes a caller can recover from.

use std::fmt;

/// Why a parcel could not be priced.
///
/// Every variant is a condition the caller can reasonably handle, so the crate
/// returns them instead of terminating the host process.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum QuoteError {
    /// The rate card could not be located or read.
    RateCardUnavailable,
    /// A rate card line was not three tab-separated fields, or its numbers did
    /// not parse. `line` is 1-based and counts every line in the file,
    /// including comments and blanks.
    MalformedRateCard {
        /// 1-based number of the offending line.
        line: usize,
    },
    /// The requested zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight {
        /// The weight that was presented.
        grams: u32,
        /// The largest `band_max_grams` the zone offers.
        limit: u32,
    },
}

impl QuoteError {
    /// A short, stable, low-cardinality label for this failure.
    ///
    /// Emitted as a tracing field so operators can group and filter rejected
    /// quotes without parsing message text.
    ///
    /// ```
    /// use ratecard::QuoteError;
    ///
    /// assert_eq!(QuoteError::RateCardUnavailable.kind(), "rate_card_unavailable");
    /// ```
    #[must_use]
    pub fn kind(&self) -> &'static str {
        match *self {
            Self::RateCardUnavailable => "rate_card_unavailable",
            Self::MalformedRateCard { .. } => "malformed_rate_card",
            Self::UnknownZone(_) => "unknown_zone",
            Self::Overweight { .. } => "overweight",
        }
    }
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {
            Self::RateCardUnavailable => f.write_str("rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(ref zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel of {grams} g exceeds the zone limit of {limit} g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[cfg(test)]
mod tests {
    // Tests assert by panicking; the no-panic policy governs library code.
    #![allow(clippy::expect_used, clippy::panic, clippy::unwrap_used)]

    use super::QuoteError;

    #[test]
    fn displays_each_failure_in_operator_language() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 7 }.to_string(),
            "malformed rate card at line 7"
        );
        assert_eq!(QuoteError::UnknownZone("lunar".to_owned()).to_string(), "unknown zone: lunar");
        assert_eq!(
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000,
            }
            .to_string(),
            "parcel of 25000 g exceeds the zone limit of 20000 g"
        );
    }

    #[test]
    fn is_usable_as_a_std_error() {
        let boxed: Box<dyn std::error::Error> = Box::new(QuoteError::RateCardUnavailable);
        assert_eq!(boxed.to_string(), "rate card unavailable");
    }

    #[test]
    fn labels_each_variant_for_querying() {
        assert_eq!(QuoteError::MalformedRateCard { line: 1 }.kind(), "malformed_rate_card");
        assert_eq!(QuoteError::UnknownZone(String::new()).kind(), "unknown_zone");
        assert_eq!(QuoteError::Overweight { grams: 1, limit: 0 }.kind(), "overweight");
    }
}
