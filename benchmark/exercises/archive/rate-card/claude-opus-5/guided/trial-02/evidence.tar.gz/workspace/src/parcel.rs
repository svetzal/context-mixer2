//! The parcel a caller wants priced.

/// A parcel presented for pricing.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct Parcel {
    /// Billable weight of the parcel, in grams.
    pub weight_grams: u32,
    /// Destination zone, matched against the zone column of the rate card.
    pub zone: String,
}

impl Parcel {
    /// Build a parcel for `zone` weighing `weight_grams`.
    ///
    /// ```
    /// use ratecard::Parcel;
    ///
    /// let parcel = Parcel::new(750, "domestic");
    /// assert_eq!(parcel.weight_grams, 750);
    /// assert_eq!(parcel.zone, "domestic");
    /// ```
    #[must_use]
    pub fn new(weight_grams: u32, zone: impl Into<String>) -> Self {
        Self {
            weight_grams,
            zone: zone.into(),
        }
    }
}
