//! The rate card and the pricing policy applied to it.
//!
//! Everything here is pure: text in, prices out. No filesystem, no environment,
//! no clock. Reading the card is the shell's job (see [`crate::source`]).

use std::collections::BTreeMap;

use crate::{Parcel, Quote, QuoteError};

/// Weight above which a parcel attracts the heavy-parcel surcharge.
const HEAVY_PARCEL_THRESHOLD_GRAMS: u32 = 10_000;
/// Flat surcharge for parcels above [`HEAVY_PARCEL_THRESHOLD_GRAMS`].
const HEAVY_PARCEL_SURCHARGE_CENTS: u64 = 500;
/// Zone that attracts the proportional surcharge.
const INTERNATIONAL_ZONE: &str = "international";
/// Percentage of the base price added for [`INTERNATIONAL_ZONE`].
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

/// One priced weight band: everything up to `max_grams` costs `cents`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Band {
    /// Inclusive upper weight bound of the band, in grams.
    pub max_grams: u32,
    /// Base price for a parcel that falls in this band.
    pub cents: u64,
}

/// A parsed rate card: the bands operations published, grouped by zone.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

impl RateCard {
    /// Parse the tab-separated rate card text.
    ///
    /// Empty lines and lines beginning with `#` are ignored. Every other line
    /// must be exactly three tab-separated fields: zone, band maximum in grams,
    /// and price in cents.
    ///
    /// # Errors
    ///
    /// Returns [`QuoteError::MalformedRateCard`] with the 1-based number of the
    /// first line that is not three fields or whose numbers do not parse.
    ///
    /// ```
    /// use ratecard::RateCard;
    ///
    /// let card = RateCard::parse("# zone\tband_max_grams\tcents\ndomestic\t500\t599\n")?;
    /// assert_eq!(card.zone_limit("domestic"), Some(500));
    /// # Ok::<(), ratecard::QuoteError>(())
    /// ```
    pub fn parse(text: &str) -> Result<Self, QuoteError> {
        let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

        for (index, raw_line) in text.lines().enumerate() {
            let line_number = index.saturating_add(1);
            let malformed = || QuoteError::MalformedRateCard { line: line_number };

            let line = raw_line.trim();
            if line.is_empty() || line.starts_with('#') {
                continue;
            }

            let mut fields = line.split('\t');
            let (Some(zone), Some(max_grams), Some(cents), None) =
                (fields.next(), fields.next(), fields.next(), fields.next())
            else {
                return Err(malformed());
            };

            let zone = zone.trim();
            if zone.is_empty() {
                return Err(malformed());
            }
            let max_grams: u32 = max_grams.trim().parse().map_err(|_ignored| malformed())?;
            let cents: u64 = cents.trim().parse().map_err(|_ignored| malformed())?;

            zones.entry(zone.to_owned()).or_default().push(Band { max_grams, cents });
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(Self { zones })
    }

    /// The largest band maximum published for `zone`, if the zone is known.
    #[must_use]
    pub fn zone_limit(&self, zone: &str) -> Option<u32> {
        self.zones.get(zone).and_then(|bands| bands.last()).map(|band| band.max_grams)
    }

    /// Price `parcel` against this card.
    ///
    /// # Errors
    ///
    /// Returns [`QuoteError::UnknownZone`] when the card has no bands for the
    /// parcel's zone, and [`QuoteError::Overweight`] when the parcel is heavier
    /// than the zone's largest band.
    ///
    /// ```
    /// use ratecard::{Parcel, RateCard};
    ///
    /// let card = RateCard::parse("international\t500\t1499\n")?;
    /// let quote = card.price(&Parcel::new(400, "international"))?;
    /// assert_eq!(quote.base_cents, 1499);
    /// assert_eq!(quote.surcharge_cents, 300); // 20%, rounded half-up
    /// assert_eq!(quote.total_cents, 1799);
    /// # Ok::<(), ratecard::QuoteError>(())
    /// ```
    pub fn price(&self, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let unknown_zone = || QuoteError::UnknownZone(parcel.zone.clone());

        let bands = self.zones.get(&parcel.zone).ok_or_else(unknown_zone)?;
        // A zone only exists in the map because a band was pushed into it, so
        // an empty band list is unreachable; treat it as an absent zone rather
        // than panicking on the impossible.
        let limit = bands.last().ok_or_else(unknown_zone)?.max_grams;

        let band = bands.iter().find(|band| band.max_grams >= parcel.weight_grams).ok_or(
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            },
        )?;

        let base_cents = band.cents;
        let surcharge_cents = surcharge_for(parcel, base_cents);

        Ok(Quote {
            base_cents,
            surcharge_cents,
            total_cents: base_cents.saturating_add(surcharge_cents),
            band_max_grams: band.max_grams,
        })
    }
}

/// Total surcharge for `parcel` given its `base_cents`.
fn surcharge_for(parcel: &Parcel, base_cents: u64) -> u64 {
    let mut surcharge = 0_u64;

    if parcel.weight_grams > HEAVY_PARCEL_THRESHOLD_GRAMS {
        surcharge = surcharge.saturating_add(HEAVY_PARCEL_SURCHARGE_CENTS);
    }

    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge =
            surcharge.saturating_add(percent_of(base_cents, INTERNATIONAL_SURCHARGE_PERCENT));
    }

    surcharge
}

/// `percent` percent of `cents`, rounded half-up to the whole cent.
///
/// Saturating rather than wrapping: an absurd published price should quote high,
/// never wrap around to nearly free.
fn percent_of(cents: u64, percent: u64) -> u64 {
    cents.saturating_mul(percent).saturating_add(50) / 100
}

#[cfg(test)]
mod tests {
    // Tests assert by panicking; the no-panic policy governs library code.
    #![allow(clippy::expect_used, clippy::panic, clippy::unwrap_used)]

    use super::RateCard;
    use crate::{Parcel, QuoteError};

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799

international\t500\t1499
international\t20000\t4999
";

    fn sample_card() -> RateCard {
        match RateCard::parse(SAMPLE) {
            Ok(card) => card,
            Err(error) => panic!("sample rate card should parse: {error}"),
        }
    }

    fn price(weight_grams: u32, zone: &str) -> Result<crate::Quote, QuoteError> {
        sample_card().price(&Parcel::new(weight_grams, zone))
    }

    #[test]
    fn ignores_comments_and_blank_lines() {
        let card = sample_card();
        assert_eq!(card.zone_limit("domestic"), Some(20_000));
        assert_eq!(card.zone_limit("international"), Some(20_000));
        assert_eq!(card.zone_limit("orbital"), None);
    }

    #[test]
    fn parses_an_empty_card() {
        assert_eq!(RateCard::parse(""), Ok(RateCard::default()));
    }

    #[test]
    fn picks_the_first_band_at_or_above_the_weight() {
        let quote = price(1, "domestic").expect("light parcel prices");
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn treats_a_band_maximum_as_inclusive() {
        let quote = price(500, "domestic").expect("boundary parcel prices");
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);

        let next = price(501, "domestic").expect("parcel just over the band prices");
        assert_eq!(next.base_cents, 899);
        assert_eq!(next.band_max_grams, 2000);
    }

    #[test]
    fn orders_bands_by_weight_regardless_of_file_order() {
        let shuffled = "domestic\t20000\t1799\ndomestic\t500\t599\ndomestic\t2000\t899\n";
        let card = RateCard::parse(shuffled).expect("shuffled card parses");
        let quote = card.price(&Parcel::new(100, "domestic")).expect("light parcel prices");
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn charges_no_surcharge_for_a_light_domestic_parcel() {
        let quote = price(2000, "domestic").expect("mid-weight parcel prices");
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
    }

    #[test]
    fn adds_the_heavy_surcharge_strictly_above_the_threshold() {
        let at_threshold = price(10_000, "domestic").expect("threshold parcel prices");
        assert_eq!(at_threshold.surcharge_cents, 0);
        assert_eq!(at_threshold.total_cents, 1799);

        let above = price(10_001, "domestic").expect("heavy parcel prices");
        assert_eq!(above.surcharge_cents, 500);
        assert_eq!(above.total_cents, 2299);
    }

    #[test]
    fn adds_twenty_percent_for_international_rounded_half_up() {
        // 20% of 1499 is 299.8, which rounds up to 300.
        let quote = price(500, "international").expect("international parcel prices");
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn rounds_the_international_surcharge_to_the_nearest_cent() {
        // A fifth of an integer lands on .0, .2, .4, .6 or .8 of a cent.
        let card = RateCard::parse(
            "international\t100\t1000\n\
             international\t200\t1001\n\
             international\t300\t1002\n\
             international\t400\t1003\n\
             international\t500\t1004\n",
        )
        .expect("card parses");

        let surcharge = |grams| {
            card.price(&Parcel::new(grams, "international"))
                .expect("parcel prices")
                .surcharge_cents
        };

        assert_eq!(surcharge(100), 200); // 200.0 exactly
        assert_eq!(surcharge(200), 200); // 200.2 rounds down
        assert_eq!(surcharge(300), 200); // 200.4 rounds down
        assert_eq!(surcharge(400), 201); // 200.6 rounds up
        assert_eq!(surcharge(500), 201); // 200.8 rounds up
    }

    #[test]
    fn adds_both_surcharges_to_a_heavy_international_parcel() {
        let quote = price(15_000, "international").expect("heavy international parcel prices");
        assert_eq!(quote.base_cents, 4999);
        // 20% of 4999 is 999.8 -> 1000, plus the 500 heavy surcharge.
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20_000);
    }

    #[test]
    fn rejects_a_zone_the_card_does_not_publish() {
        assert_eq!(price(100, "lunar"), Err(QuoteError::UnknownZone("lunar".to_owned())));
    }

    #[test]
    fn rejects_a_parcel_above_the_largest_band() {
        assert_eq!(
            price(20_001, "domestic"),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            })
        );
    }

    #[test]
    fn reports_an_unknown_zone_before_weighing_it() {
        assert_eq!(price(1_000_000, "lunar"), Err(QuoteError::UnknownZone("lunar".to_owned())));
    }

    #[test]
    fn counts_comments_and_blanks_when_numbering_a_malformed_line() {
        let text = "# header\n\ndomestic\t500\t599\ndomestic\theavy\t899\n";
        assert_eq!(RateCard::parse(text), Err(QuoteError::MalformedRateCard { line: 4 }));
    }

    #[test]
    fn rejects_lines_without_exactly_three_fields() {
        assert_eq!(
            RateCard::parse("domestic\t500\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(
            RateCard::parse("domestic\t500\t599\textra\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(
            RateCard::parse("domestic 500 599\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn rejects_numbers_that_do_not_parse() {
        assert_eq!(
            RateCard::parse("domestic\t-500\t599\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(
            RateCard::parse("domestic\t500\t5.99\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(RateCard::parse("\t500\t599\n"), Err(QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn stops_at_the_first_malformed_line() {
        let text = "domestic\tbad\t599\ninternational\talso-bad\t1499\n";
        assert_eq!(RateCard::parse(text), Err(QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn saturates_rather_than_overflowing_on_an_absurd_price() {
        let card =
            RateCard::parse(&format!("international\t500\t{}\n", u64::MAX)).expect("card parses");
        let quote = card.price(&Parcel::new(500, "international")).expect("absurd parcel prices");
        assert_eq!(quote.base_cents, u64::MAX);
        assert_eq!(quote.total_cents, u64::MAX);
    }
}
