//! Every quote leaves a queryable record: a `quote` span, and an event inside
//! it carrying the zone, the weight, and the outcome as separate fields.

// Tests assert by panicking; the no-panic policy governs library code.
#![allow(clippy::expect_used, clippy::panic, clippy::unwrap_used)]

use std::collections::BTreeMap;
use std::fmt::Debug;
use std::sync::{Arc, Mutex, PoisonError};

use ratecard::{quote_from, InMemoryRateCard, Parcel};
use tracing::field::{Field, Visit};
use tracing::subscriber::with_default;
use tracing::Level;
use tracing_subscriber::layer::{Context, Layer, SubscriberExt as _};
use tracing_subscriber::registry::LookupSpan;
use tracing_subscriber::Registry;

const CARD: &str = "\
domestic\t500\t599
domestic\t20000\t1799
international\t20000\t4999
";

/// One event as an operator's backend would see it.
#[derive(Debug, Clone)]
struct Record {
    level: Level,
    span: Option<String>,
    fields: BTreeMap<String, String>,
}

impl Record {
    fn field(&self, name: &str) -> Option<&str> {
        self.fields.get(name).map(String::as_str)
    }
}

#[derive(Default)]
struct FieldVisitor(BTreeMap<String, String>);

impl Visit for FieldVisitor {
    fn record_str(&mut self, field: &Field, value: &str) {
        self.0.insert(field.name().to_owned(), value.to_owned());
    }

    fn record_u64(&mut self, field: &Field, value: u64) {
        self.0.insert(field.name().to_owned(), value.to_string());
    }

    fn record_i64(&mut self, field: &Field, value: i64) {
        self.0.insert(field.name().to_owned(), value.to_string());
    }

    fn record_debug(&mut self, field: &Field, value: &dyn Debug) {
        self.0.insert(field.name().to_owned(), format!("{value:?}"));
    }
}

#[derive(Clone, Default)]
struct Capture(Arc<Mutex<Vec<Record>>>);

impl Capture {
    fn records(&self) -> Vec<Record> {
        self.0.lock().unwrap_or_else(PoisonError::into_inner).clone()
    }
}

impl<S> Layer<S> for Capture
where
    S: tracing::Subscriber + for<'a> LookupSpan<'a>,
{
    fn on_event(&self, event: &tracing::Event<'_>, context: Context<'_, S>) {
        let mut visitor = FieldVisitor::default();
        event.record(&mut visitor);

        let record = Record {
            level: *event.metadata().level(),
            span: context.event_span(event).map(|span| span.name().to_owned()),
            fields: visitor.0,
        };

        self.0.lock().unwrap_or_else(PoisonError::into_inner).push(record);
    }
}

/// Run `body` with a capturing subscriber installed on this thread.
fn captured(body: impl FnOnce()) -> Vec<Record> {
    let capture = Capture::default();
    let subscriber = Registry::default().with(capture.clone());
    with_default(subscriber, body);
    capture.records()
}

#[test]
fn records_a_priced_quote_with_queryable_fields() {
    let records = captured(|| {
        let quoted =
            quote_from(&InMemoryRateCard::new(CARD), &Parcel::new(12_500, "international"))
                .expect("parcel prices");
        assert_eq!(quoted.total_cents, 6499);
    });

    let record = records
        .iter()
        .find(|record| record.field("outcome") == Some("quoted"))
        .expect("a quoted parcel is recorded");

    assert_eq!(record.level, Level::INFO);
    assert_eq!(record.span.as_deref(), Some("quote"));
    assert_eq!(record.field("zone"), Some("international"));
    assert_eq!(record.field("weight_grams"), Some("12500"));
    assert_eq!(record.field("total_cents"), Some("6499"));
    assert_eq!(record.field("base_cents"), Some("4999"));
    assert_eq!(record.field("surcharge_cents"), Some("1500"));
    assert_eq!(record.field("band_max_grams"), Some("20000"));
}

#[test]
fn records_exactly_one_diagnostic_per_call() {
    let records = captured(|| {
        for grams in [100_u32, 200, 300] {
            let _ignored =
                quote_from(&InMemoryRateCard::new(CARD), &Parcel::new(grams, "domestic"));
        }
    });

    assert_eq!(records.iter().filter(|record| record.fields.contains_key("outcome")).count(), 3);
}

#[test]
fn records_a_rejected_quote_with_its_reason() {
    let records = captured(|| {
        let _ignored = quote_from(&InMemoryRateCard::new(CARD), &Parcel::new(100, "lunar"));
    });

    let record = records
        .iter()
        .find(|record| record.field("outcome") == Some("rejected"))
        .expect("a rejected parcel is recorded");

    assert_eq!(record.level, Level::WARN);
    assert_eq!(record.span.as_deref(), Some("quote"));
    assert_eq!(record.field("zone"), Some("lunar"));
    assert_eq!(record.field("weight_grams"), Some("100"));
    assert_eq!(record.field("reason"), Some("unknown_zone"));
    assert_eq!(record.field("error"), Some("unknown zone: lunar"));
}

#[test]
fn records_a_rejected_quote_when_the_card_is_unavailable() {
    let records = captured(|| {
        let _ignored = quote_from(&InMemoryRateCard::unavailable(), &Parcel::new(100, "domestic"));
    });

    let record = records
        .iter()
        .find(|record| record.field("outcome") == Some("rejected"))
        .expect("a rejected parcel is recorded");

    assert_eq!(record.field("reason"), Some("rate_card_unavailable"));
}
