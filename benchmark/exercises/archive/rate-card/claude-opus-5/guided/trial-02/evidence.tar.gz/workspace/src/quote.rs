//! The priced result of a quote.

/// The price of shipping one parcel, broken out so callers can show their work.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct Quote {
    /// The matching band's price, before surcharges.
    pub base_cents: u64,
    /// Everything added on top of [`Quote::base_cents`].
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`, the amount to bill.
    pub total_cents: u64,
    /// The upper weight bound of the band that priced this parcel.
    pub band_max_grams: u32,
}
