//! Shipping quotes for the fulfilment service.
//!
//! Operations publishes a tab-separated rate card and redeploys it without a
//! code change; this crate reads that card and turns a [`Parcel`] into a
//! [`Quote`].
//!
//! [`quote`] is the shell: it finds the card at the path in `RATECARD_PATH`,
//! reads it, and emits a tracing record for the call. The pricing itself lives
//! in [`RateCard`], which is pure and can be exercised without touching the
//! filesystem or the environment:
//!
//! ```
//! use ratecard::{Parcel, RateCard};
//!
//! let card = RateCard::parse("domestic\t500\t599\ndomestic\t2000\t899\n")?;
//! let quote = card.price(&Parcel::new(750, "domestic"))?;
//!
//! assert_eq!(quote.base_cents, 899);
//! assert_eq!(quote.surcharge_cents, 0);
//! assert_eq!(quote.total_cents, 899);
//! assert_eq!(quote.band_max_grams, 2000);
//! # Ok::<(), ratecard::QuoteError>(())
//! ```
//!
//! To price against a card supplied by the caller instead, hand any
//! [`RateCardSource`] to [`quote_from`].

mod card;
mod error;
mod parcel;
mod quote;
mod source;

pub mod zones;

pub use card::{Band, RateCard};
pub use error::QuoteError;
pub use parcel::Parcel;
pub use quote::Quote;
pub use source::{
    EnvPathRateCard, InMemoryRateCard, RateCardSource, RateCardUnavailable, RATECARD_PATH_VAR,
};

/// Price `parcel` against the rate card named by `RATECARD_PATH`.
///
/// # Errors
///
/// - [`QuoteError::RateCardUnavailable`] when `RATECARD_PATH` is unset or the
///   file it names is missing or unreadable.
/// - [`QuoteError::MalformedRateCard`] when a card line is not three
///   tab-separated fields or its numbers do not parse.
/// - [`QuoteError::UnknownZone`] when the card publishes no bands for the
///   parcel's zone.
/// - [`QuoteError::Overweight`] when the parcel is heavier than the zone's
///   largest band.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_from(&EnvPathRateCard::new(), parcel)
}

/// Price `parcel` against the card supplied by `source`.
///
/// Behaves exactly like [`quote`], including the tracing record, but takes the
/// card from any [`RateCardSource`].
///
/// # Errors
///
/// The same failures as [`quote`], with [`QuoteError::RateCardUnavailable`]
/// standing for any failure reported by `source`.
///
/// ```
/// use ratecard::{quote_from, InMemoryRateCard, Parcel};
///
/// let source = InMemoryRateCard::new("international\t20000\t4999\n");
/// let quote = quote_from(&source, &Parcel::new(15_000, "international"))?;
///
/// assert_eq!(quote.total_cents, 6499); // 4999 + 20% + 500 heavy surcharge
/// # Ok::<(), ratecard::QuoteError>(())
/// ```
pub fn quote_from<S>(source: &S, parcel: &Parcel) -> Result<Quote, QuoteError>
where
    S: RateCardSource + ?Sized,
{
    let span = tracing::info_span!(
        "quote",
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
    );
    let _entered = span.enter();

    let result = price(source, parcel);

    match result {
        Ok(quoted) => tracing::info!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            base_cents = quoted.base_cents,
            surcharge_cents = quoted.surcharge_cents,
            total_cents = quoted.total_cents,
            band_max_grams = quoted.band_max_grams,
            outcome = "quoted",
            "parcel quoted"
        ),
        Err(ref error) => tracing::warn!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            outcome = "rejected",
            reason = error.kind(),
            error = %error,
            "parcel not quoted"
        ),
    }

    result
}

/// Load the card and price the parcel, leaving observability to the caller.
fn price<S>(source: &S, parcel: &Parcel) -> Result<Quote, QuoteError>
where
    S: RateCardSource + ?Sized,
{
    let text = source.load().map_err(|RateCardUnavailable| QuoteError::RateCardUnavailable)?;

    RateCard::parse(&text)?.price(parcel)
}

#[cfg(test)]
mod tests {
    // Tests assert by panicking; the no-panic policy governs library code.
    #![allow(clippy::expect_used, clippy::panic, clippy::unwrap_used)]

    use super::{quote_from, InMemoryRateCard, Parcel, QuoteError};

    const CARD: &str = "domestic\t500\t599\ndomestic\t20000\t1799\n";

    #[test]
    fn prices_against_a_supplied_card() {
        let quoted = quote_from(&InMemoryRateCard::new(CARD), &Parcel::new(100, "domestic"))
            .expect("parcel prices");
        assert_eq!(quoted.total_cents, 599);
    }

    #[test]
    fn reports_an_unavailable_card() {
        assert_eq!(
            quote_from(&InMemoryRateCard::unavailable(), &Parcel::new(100, "domestic")),
            Err(QuoteError::RateCardUnavailable)
        );
    }

    #[test]
    fn surfaces_a_malformed_card_from_the_shell() {
        assert_eq!(
            quote_from(&InMemoryRateCard::new("domestic\t500\n"), &Parcel::new(100, "domestic")),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }
}
