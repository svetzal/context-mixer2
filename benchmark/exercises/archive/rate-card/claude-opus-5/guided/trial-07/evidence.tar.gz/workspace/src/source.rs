//! The edge where rate card text comes from.
//!
//! The core takes text; this module owns the contract for producing it and the
//! one adapter that reads it from the environment and the filesystem.

use std::env;
use std::fs;
use std::path::PathBuf;

/// Environment variable naming the rate card file.
pub const RATE_CARD_PATH_VAR: &str = "RATECARD_PATH";

/// The rate card could not be located or read.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Unavailable;

/// Project-owned contract for obtaining rate card text.
pub trait RateCardSource {
    /// Read the current rate card, or report it unavailable.
    fn load(&self) -> Result<String, Unavailable>;
}

/// Reads the file named by [`RATE_CARD_PATH_VAR`] on each call, so operations
/// can redeploy the card without restarting the caller.
#[derive(Debug, Clone, Copy, Default)]
pub struct EnvPathRateCardSource;

impl EnvPathRateCardSource {
    /// A source bound to the `RATECARD_PATH` environment variable.
    pub const fn new() -> Self {
        Self
    }
}

impl RateCardSource for EnvPathRateCardSource {
    fn load(&self) -> Result<String, Unavailable> {
        let path = env::var(RATE_CARD_PATH_VAR).map_err(|_| Unavailable)?;
        fs::read_to_string(PathBuf::from(path)).map_err(|_| Unavailable)
    }
}

#[cfg(test)]
pub(crate) mod fake {
    use super::{RateCardSource, Unavailable};

    /// An in-memory stand-in for the filesystem adapter.
    pub(crate) struct InMemorySource(Result<String, Unavailable>);

    impl InMemorySource {
        pub(crate) fn holding(text: &str) -> Self {
            Self(Ok(text.to_owned()))
        }

        pub(crate) fn unavailable() -> Self {
            Self(Err(Unavailable))
        }
    }

    impl RateCardSource for InMemorySource {
        fn load(&self) -> Result<String, Unavailable> {
            self.0.clone()
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::{Mutex, MutexGuard};

    /// The process environment is shared by every test thread, so the tests
    /// that reach for it take turns.
    static ENV: Mutex<()> = Mutex::new(());

    fn env_turn() -> MutexGuard<'static, ()> {
        ENV.lock().unwrap_or_else(std::sync::PoisonError::into_inner)
    }

    #[test]
    fn an_unset_variable_leaves_the_card_unavailable() {
        let _turn = env_turn();
        let previous = env::var(RATE_CARD_PATH_VAR).ok();
        env::remove_var(RATE_CARD_PATH_VAR);

        let loaded = EnvPathRateCardSource::new().load();

        if let Some(value) = previous {
            env::set_var(RATE_CARD_PATH_VAR, value);
        }
        assert_eq!(loaded, Err(Unavailable));
    }

    #[test]
    fn a_missing_file_leaves_the_card_unavailable() {
        let _turn = env_turn();
        let previous = env::var(RATE_CARD_PATH_VAR).ok();
        env::set_var(RATE_CARD_PATH_VAR, "/nonexistent/ratecard.tsv");

        let loaded = EnvPathRateCardSource::new().load();

        match previous {
            Some(value) => env::set_var(RATE_CARD_PATH_VAR, value),
            None => env::remove_var(RATE_CARD_PATH_VAR),
        }
        assert_eq!(loaded, Err(Unavailable));
    }
}
