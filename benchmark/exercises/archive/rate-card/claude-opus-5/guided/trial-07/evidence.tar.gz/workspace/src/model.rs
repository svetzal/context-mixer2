//! The public vocabulary of the crate: what is quoted, what a quote is, and
//! how quoting fails.

use std::fmt;

/// A parcel presented for pricing.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Billable weight of the parcel in grams.
    pub weight_grams: u32,
    /// Destination zone, matched against the zones named in the rate card.
    pub zone: String,
}

/// The priced result of quoting a [`Parcel`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quote {
    /// Price of the matching band, before surcharges.
    pub base_cents: u64,
    /// Surcharges applied on top of [`Quote::base_cents`].
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// Upper weight bound, in grams, of the band that priced this parcel.
    pub band_max_grams: u32,
}

/// Why a parcel could not be quoted.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card could not be located or read.
    RateCardUnavailable,
    /// A line of the rate card did not parse; `line` is 1-based and counts
    /// every line of the file, including comments and blanks.
    MalformedRateCard {
        /// 1-based number of the offending line.
        line: usize,
    },
    /// The requested zone is absent from the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight {
        /// Weight of the parcel, in grams.
        grams: u32,
        /// Largest band bound available for the zone, in grams.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel of {grams} g exceeds the zone limit of {limit} g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn unavailable_reads_as_a_sentence() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
    }

    #[test]
    fn malformed_names_the_line() {
        let error = QuoteError::MalformedRateCard { line: 4 };
        assert_eq!(error.to_string(), "malformed rate card at line 4");
    }

    #[test]
    fn unknown_zone_names_the_zone() {
        let error = QuoteError::UnknownZone("lunar".to_owned());
        assert_eq!(error.to_string(), "unknown zone: lunar");
    }

    #[test]
    fn overweight_names_weight_and_limit() {
        let error = QuoteError::Overweight { grams: 25_000, limit: 20_000 };
        assert_eq!(error.to_string(), "parcel of 25000 g exceeds the zone limit of 20000 g");
    }

    #[test]
    fn quote_error_is_a_std_error() {
        fn assert_error<E: std::error::Error>(_: &E) {}
        assert_error(&QuoteError::RateCardUnavailable);
    }
}
