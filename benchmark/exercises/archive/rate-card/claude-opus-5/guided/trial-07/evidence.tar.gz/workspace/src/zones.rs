//! Human-facing names for the zones the rate card prices.

/// The operator-facing label for `zone`, or the zone itself when it has none.
#[must_use]
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}
