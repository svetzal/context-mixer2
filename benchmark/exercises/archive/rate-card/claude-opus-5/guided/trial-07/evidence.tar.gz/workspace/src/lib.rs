//! Shipping quotes for the fulfilment service.
//!
//! [`quote`] prices a [`Parcel`] against the rate card that operations
//! maintains. The card is read fresh on each call from the file named by the
//! `RATECARD_PATH` environment variable, so a redeployed card takes effect
//! without a code change.
//!
//! ```
//! use ratecard::{quote, Parcel};
//! use std::io::Write;
//!
//! let mut card = tempfile::NamedTempFile::new()?;
//! writeln!(card, "domestic\t500\t599")?;
//! std::env::set_var("RATECARD_PATH", card.path());
//!
//! let priced = quote(&Parcel { weight_grams: 300, zone: "domestic".to_owned() })?;
//! assert_eq!(priced.base_cents, 599);
//! assert_eq!(priced.band_max_grams, 500);
//! # Ok::<(), Box<dyn std::error::Error>>(())
//! ```
//!
//! The pricing rules themselves are pure: one module turns card text into
//! bands, another turns bands and a parcel into a quote, and neither touches
//! the filesystem. Reading the card is the only part that does.

#![forbid(unsafe_code)]

mod card;
mod model;
mod pricing;
mod source;
pub mod zones;

pub use model::{Parcel, Quote, QuoteError};

use source::{EnvPathRateCardSource, RateCardSource};
use tracing::{field::Empty, info, info_span, warn};

/// Price `parcel` against the current rate card.
///
/// # Errors
///
/// Returns [`QuoteError::RateCardUnavailable`] when `RATECARD_PATH` is unset or
/// its file cannot be read, [`QuoteError::MalformedRateCard`] when a line of
/// that file is not a band, [`QuoteError::UnknownZone`] when the card does not
/// name the parcel's zone, and [`QuoteError::Overweight`] when the parcel is
/// heavier than the zone's largest band.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_from(&EnvPathRateCardSource::new(), parcel)
}

/// The shell around the pure core: load the card, price the parcel, and report
/// what happened. Every call leaves one traced record carrying the zone, the
/// weight, and either the total or the reason there is none.
fn quote_from(source: &dyn RateCardSource, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let span = info_span!(
        "quote",
        zone = parcel.zone.as_str(),
        weight_grams = parcel.weight_grams,
        total_cents = Empty,
    );
    let _entered = span.enter();

    let outcome = source
        .load()
        .map_err(|_unavailable| QuoteError::RateCardUnavailable)
        .and_then(|text| {
            card::parse(&text)
                .map_err(|malformed| QuoteError::MalformedRateCard { line: malformed.line })
        })
        .and_then(|card| pricing::price(&card, parcel));

    match &outcome {
        Ok(quote) => {
            span.record("total_cents", quote.total_cents);
            info!(
                zone = parcel.zone.as_str(),
                weight_grams = parcel.weight_grams,
                total_cents = quote.total_cents,
                "parcel quoted"
            );
        }
        Err(error) => {
            warn!(
                zone = parcel.zone.as_str(),
                weight_grams = parcel.weight_grams,
                error = %error,
                "parcel not quoted"
            );
        }
    }

    outcome
}

#[cfg(test)]
mod tests {
    // See the note in `card::tests`: test harnesses may panic.
    #![allow(clippy::panic, clippy::unwrap_used, clippy::expect_used)]

    use super::*;
    use crate::source::fake::InMemorySource;
    use std::collections::BTreeMap;
    use std::sync::{Arc, Mutex, PoisonError};
    use tracing::field::{Field, Visit};
    use tracing_subscriber::layer::{Context, Layer, SubscriberExt};
    use tracing_subscriber::Registry;

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
                          domestic\t500\t599\n\
                          domestic\t2000\t899\n\
                          domestic\t20000\t1799\n\
                          international\t500\t1499\n\
                          international\t20000\t4999\n";

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel { weight_grams, zone: zone.to_owned() }
    }

    /// A traced event, flattened to its fields.
    type Record = BTreeMap<String, String>;

    /// Collects the events emitted while it is installed, so instrumentation
    /// can be asserted on the same footing as the returned quote.
    #[derive(Clone, Default)]
    struct Recorder(Arc<Mutex<Vec<Record>>>);

    impl Recorder {
        fn records(&self) -> Vec<Record> {
            self.0.lock().unwrap_or_else(PoisonError::into_inner).clone()
        }
    }

    impl<S: tracing::Subscriber> Layer<S> for Recorder {
        fn on_event(&self, event: &tracing::Event<'_>, _ctx: Context<'_, S>) {
            let mut fields = Record::new();
            event.record(&mut FieldCollector(&mut fields));
            self.0.lock().unwrap_or_else(PoisonError::into_inner).push(fields);
        }
    }

    struct FieldCollector<'a>(&'a mut Record);

    impl Visit for FieldCollector<'_> {
        fn record_u64(&mut self, field: &Field, value: u64) {
            self.0.insert(field.name().to_owned(), value.to_string());
        }

        fn record_str(&mut self, field: &Field, value: &str) {
            self.0.insert(field.name().to_owned(), value.to_owned());
        }

        fn record_debug(&mut self, field: &Field, value: &dyn std::fmt::Debug) {
            self.0.insert(field.name().to_owned(), format!("{value:?}"));
        }
    }

    /// Quote against `card_text`, returning the outcome and everything traced.
    fn quote_observed(
        source: &dyn RateCardSource,
        parcel: &Parcel,
    ) -> (Result<Quote, QuoteError>, Vec<Record>) {
        let recorder = Recorder::default();
        let subscriber = Registry::default().with(recorder.clone());
        let outcome =
            tracing::subscriber::with_default(subscriber, || quote_from(source, parcel));
        (outcome, recorder.records())
    }

    #[test]
    fn prices_a_parcel_from_the_loaded_card() {
        let source = InMemorySource::holding(SAMPLE);

        let priced = quote_from(&source, &parcel(750, "international"));

        assert_eq!(
            priced,
            Ok(Quote {
                base_cents: 4999,
                surcharge_cents: 1000,
                total_cents: 5999,
                band_max_grams: 20_000,
            })
        );
    }

    #[test]
    fn an_unreadable_card_leaves_the_quote_unavailable() {
        let source = InMemorySource::unavailable();

        assert_eq!(
            quote_from(&source, &parcel(300, "domestic")),
            Err(QuoteError::RateCardUnavailable)
        );
    }

    #[test]
    fn a_malformed_card_line_surfaces_with_its_line_number() {
        let source = InMemorySource::holding("# note\ndomestic\t500\t599\ndomestic\t2000\n");

        assert_eq!(
            quote_from(&source, &parcel(300, "domestic")),
            Err(QuoteError::MalformedRateCard { line: 3 })
        );
    }

    #[test]
    fn a_malformed_card_is_rejected_even_for_an_unaffected_zone() {
        let source = InMemorySource::holding("domestic\t500\t599\ninternational\toops\t1499\n");

        assert_eq!(
            quote_from(&source, &parcel(300, "domestic")),
            Err(QuoteError::MalformedRateCard { line: 2 })
        );
    }

    #[test]
    fn a_priced_parcel_leaves_a_record_of_zone_weight_and_total() {
        let source = InMemorySource::holding(SAMPLE);

        let (outcome, records) = quote_observed(&source, &parcel(750, "domestic"));

        assert!(outcome.is_ok(), "expected a quote, got {outcome:?}");
        let record = records.first().expect("a quote should be observable");
        assert_eq!(record.get("zone").map(String::as_str), Some("domestic"));
        assert_eq!(record.get("weight_grams").map(String::as_str), Some("750"));
        assert_eq!(record.get("total_cents").map(String::as_str), Some("899"));
    }

    #[test]
    fn a_refused_parcel_leaves_a_record_carrying_the_reason() {
        let source = InMemorySource::holding(SAMPLE);

        let (outcome, records) = quote_observed(&source, &parcel(300, "lunar"));

        assert!(outcome.is_err(), "expected a refusal, got {outcome:?}");
        let record = records.first().expect("a refusal should be observable");
        assert_eq!(record.get("zone").map(String::as_str), Some("lunar"));
        assert_eq!(record.get("weight_grams").map(String::as_str), Some("300"));
        assert_eq!(record.get("error").map(String::as_str), Some("unknown zone: lunar"));
    }

    #[test]
    fn each_call_leaves_exactly_one_record() {
        let source = InMemorySource::holding(SAMPLE);

        let (_, records) = quote_observed(&source, &parcel(300, "domestic"));

        assert_eq!(records.len(), 1);
    }
}
