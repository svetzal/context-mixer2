//! Pure parsing of the tab-separated rate card text into an in-memory card.
//!
//! Nothing here touches the filesystem: the shell hands this module the text
//! it read, so every parsing rule is exercised without I/O.

use std::collections::BTreeMap;

/// One priced weight band of a zone.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Band {
    /// Inclusive upper weight bound of the band, in grams.
    pub max_grams: u32,
    /// Price of the band, in cents.
    pub cents: u64,
}

/// The bands of every zone the card names, each zone ordered by ascending
/// [`Band::max_grams`].
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

impl RateCard {
    /// Bands for `zone`, ascending by weight, or `None` when the card does not
    /// name the zone.
    pub fn bands(&self, zone: &str) -> Option<&[Band]> {
        self.zones.get(zone).map(Vec::as_slice)
    }
}

/// A line of the card that could not be read as a band.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct MalformedLine {
    /// 1-based number of the offending line, counting comments and blanks.
    pub line: usize,
}

/// Parse rate card text.
///
/// Empty lines and lines beginning with `#` are ignored. Every other line must
/// hold exactly three tab-separated fields: zone, band bound in grams, price in
/// cents.
pub fn parse(text: &str) -> Result<RateCard, MalformedLine> {
    let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

    for (index, raw) in text.lines().enumerate() {
        let line = index.saturating_add(1);
        if is_ignorable(raw) {
            continue;
        }
        let (zone, band) = parse_band(raw).ok_or(MalformedLine { line })?;
        zones.entry(zone).or_default().push(band);
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }

    Ok(RateCard { zones })
}

fn is_ignorable(raw: &str) -> bool {
    let trimmed = raw.trim();
    trimmed.is_empty() || trimmed.starts_with('#')
}

fn parse_band(raw: &str) -> Option<(String, Band)> {
    let mut fields = raw.split('\t');
    let (Some(zone), Some(max_grams), Some(cents), None) =
        (fields.next(), fields.next(), fields.next(), fields.next())
    else {
        return None;
    };

    Some((
        zone.trim().to_owned(),
        Band {
            max_grams: max_grams.trim().parse().ok()?,
            cents: cents.trim().parse().ok()?,
        },
    ))
}

#[cfg(test)]
mod tests {
    // A failing assertion is how a test reports; the no-panic policy is about
    // library code, not about the harness that checks it.
    #![allow(clippy::panic, clippy::unwrap_used, clippy::expect_used)]

    use super::*;

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
                          domestic\t500\t599\n\
                          domestic\t2000\t899\n\
                          domestic\t20000\t1799\n\
                          international\t500\t1499\n\
                          international\t20000\t4999\n";

    fn parsed(text: &str) -> RateCard {
        match parse(text) {
            Ok(card) => card,
            Err(malformed) => panic!("expected a parsable card, got line {}", malformed.line),
        }
    }

    #[test]
    fn reads_every_band_of_every_zone() {
        let card = parsed(SAMPLE);

        assert_eq!(
            card.bands("domestic"),
            Some(
                [
                    Band { max_grams: 500, cents: 599 },
                    Band { max_grams: 2000, cents: 899 },
                    Band { max_grams: 20_000, cents: 1799 },
                ]
                .as_slice()
            )
        );
        assert_eq!(
            card.bands("international"),
            Some(
                [
                    Band { max_grams: 500, cents: 1499 },
                    Band { max_grams: 20_000, cents: 4999 },
                ]
                .as_slice()
            )
        );
    }

    #[test]
    fn zones_absent_from_the_card_have_no_bands() {
        assert_eq!(parsed(SAMPLE).bands("lunar"), None);
    }

    #[test]
    fn orders_bands_by_ascending_bound() {
        let card = parsed("domestic\t20000\t1799\ndomestic\t500\t599\n");

        let bounds: Vec<u32> = card
            .bands("domestic")
            .unwrap_or_default()
            .iter()
            .map(|band| band.max_grams)
            .collect();
        assert_eq!(bounds, vec![500, 20_000]);
    }

    #[test]
    fn ignores_blank_and_commented_lines() {
        let card = parsed("\n# a note\n\ndomestic\t500\t599\n   \n");

        assert_eq!(card.bands("domestic").map(<[Band]>::len), Some(1));
    }

    #[test]
    fn rejects_a_line_with_too_few_fields() {
        assert_eq!(
            parse("domestic\t500\t599\ndomestic\t2000\n"),
            Err(MalformedLine { line: 2 })
        );
    }

    #[test]
    fn rejects_a_line_with_too_many_fields() {
        assert_eq!(
            parse("domestic\t500\t599\tstale\n"),
            Err(MalformedLine { line: 1 })
        );
    }

    #[test]
    fn rejects_an_unparsable_weight() {
        assert_eq!(parse("domestic\theavy\t599\n"), Err(MalformedLine { line: 1 }));
    }

    #[test]
    fn rejects_an_unparsable_price() {
        assert_eq!(parse("domestic\t500\tfree\n"), Err(MalformedLine { line: 1 }));
    }

    #[test]
    fn rejects_a_negative_price() {
        assert_eq!(parse("domestic\t500\t-1\n"), Err(MalformedLine { line: 1 }));
    }

    #[test]
    fn counts_comments_and_blanks_when_numbering_a_bad_line() {
        let text = "# zone\tband_max_grams\tcents\n\
                    \n\
                    domestic\t500\t599\n\
                    # another note\n\
                    domestic\toops\t899\n";

        assert_eq!(parse(text), Err(MalformedLine { line: 5 }));
    }

    #[test]
    fn reports_the_first_bad_line_only() {
        let text = "domestic\toops\t599\ndomestic\talso-oops\t899\n";

        assert_eq!(parse(text), Err(MalformedLine { line: 1 }));
    }

    #[test]
    fn an_empty_card_names_no_zones() {
        assert_eq!(parsed(""), RateCard::default());
    }

    #[test]
    fn reads_a_final_line_without_a_trailing_newline() {
        let card = parsed("domestic\t500\t599");

        assert_eq!(card.bands("domestic").map(<[Band]>::len), Some(1));
    }

    #[test]
    fn reads_windows_line_endings() {
        let card = parsed("domestic\t500\t599\r\ndomestic\t2000\t899\r\n");

        assert_eq!(card.bands("domestic").map(<[Band]>::len), Some(2));
    }
}
