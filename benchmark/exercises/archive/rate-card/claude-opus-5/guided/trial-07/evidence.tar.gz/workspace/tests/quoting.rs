//! Cross-module behaviour through the public entry point, wired to a real
//! rate card file named by `RATECARD_PATH` — the way callers use the crate.

// A test that cannot arrange its fixture should fail loudly; the no-panic
// policy is about library code.
#![allow(clippy::panic, clippy::unwrap_used, clippy::expect_used)]

use std::env;
use std::io::Write;
use std::sync::{Mutex, MutexGuard, PoisonError};

use ratecard::{quote, Parcel, Quote, QuoteError};
use tempfile::NamedTempFile;

const CARD: &str = "# zone\tband_max_grams\tcents\n\
                    domestic\t500\t599\n\
                    domestic\t2000\t899\n\
                    domestic\t20000\t1799\n\
                    international\t500\t1499\n\
                    international\t20000\t4999\n";

/// `RATECARD_PATH` is process-wide state, so tests that point it somewhere take
/// turns rather than racing.
static ENV: Mutex<()> = Mutex::new(());

fn env_turn() -> MutexGuard<'static, ()> {
    ENV.lock().unwrap_or_else(PoisonError::into_inner)
}

/// Quote against a card file holding `text`, with `RATECARD_PATH` pointing at
/// it for the duration of the call.
fn quote_against(text: &str, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let _turn = env_turn();
    let mut file = NamedTempFile::new().expect("a temporary rate card");
    file.write_all(text.as_bytes()).expect("writing the rate card");
    file.flush().expect("flushing the rate card");
    env::set_var("RATECARD_PATH", file.path());

    let outcome = quote(parcel);

    env::remove_var("RATECARD_PATH");
    outcome
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel { weight_grams, zone: zone.to_owned() }
}

#[test]
fn prices_a_light_domestic_parcel_from_the_deployed_card() {
    let priced = quote_against(CARD, &parcel(300, "domestic"));

    assert_eq!(
        priced,
        Ok(Quote {
            base_cents: 599,
            surcharge_cents: 0,
            total_cents: 599,
            band_max_grams: 500,
        })
    );
}

#[test]
fn prices_a_heavy_international_parcel_with_both_surcharges() {
    let priced = quote_against(CARD, &parcel(12_000, "international"));

    assert_eq!(
        priced,
        Ok(Quote {
            base_cents: 4999,
            surcharge_cents: 1500,
            total_cents: 6499,
            band_max_grams: 20_000,
        })
    );
}

#[test]
fn a_redeployed_card_prices_the_next_parcel() {
    let cheap = quote_against(CARD, &parcel(300, "domestic")).map(|q| q.total_cents);
    let dearer = quote_against("domestic\t500\t699\n", &parcel(300, "domestic"))
        .map(|q| q.total_cents);

    assert_eq!((cheap, dearer), (Ok(599), Ok(699)));
}

#[test]
fn a_zone_the_card_does_not_name_is_unknown() {
    let priced = quote_against(CARD, &parcel(300, "lunar"));

    assert_eq!(priced, Err(QuoteError::UnknownZone("lunar".to_owned())));
}

#[test]
fn a_parcel_beyond_the_largest_band_is_overweight() {
    let priced = quote_against(CARD, &parcel(25_000, "domestic"));

    assert_eq!(priced, Err(QuoteError::Overweight { grams: 25_000, limit: 20_000 }));
}

#[test]
fn a_malformed_line_reports_its_place_in_the_file() {
    let priced = quote_against("# note\n\ndomestic\t500\tfree\n", &parcel(300, "domestic"));

    assert_eq!(priced, Err(QuoteError::MalformedRateCard { line: 3 }));
}

#[test]
fn an_unset_path_leaves_the_rate_card_unavailable() {
    let _turn = env_turn();
    let previous = env::var("RATECARD_PATH").ok();
    env::remove_var("RATECARD_PATH");

    let priced = quote(&parcel(300, "domestic"));

    if let Some(value) = previous {
        env::set_var("RATECARD_PATH", value);
    }
    assert_eq!(priced, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn a_path_to_nothing_leaves_the_rate_card_unavailable() {
    let _turn = env_turn();
    env::set_var("RATECARD_PATH", "/nonexistent/directory/ratecard.tsv");

    let priced = quote(&parcel(300, "domestic"));

    env::remove_var("RATECARD_PATH");
    assert_eq!(priced, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn a_quote_error_carries_a_message_callers_can_report() {
    let priced = quote_against(CARD, &parcel(300, "lunar"));

    let message = priced.err().map(|error| error.to_string());
    assert_eq!(message, Some("unknown zone: lunar".to_owned()));
}
