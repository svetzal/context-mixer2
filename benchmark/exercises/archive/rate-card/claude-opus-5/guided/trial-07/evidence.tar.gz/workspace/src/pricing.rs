//! Pure pricing: an in-memory rate card plus a parcel yields a quote.

use crate::card::{Band, RateCard};
use crate::model::{Parcel, Quote, QuoteError};

/// Weight above which the heavy-parcel surcharge applies, in grams.
const HEAVY_ABOVE_GRAMS: u32 = 10_000;

/// Flat surcharge for parcels above [`HEAVY_ABOVE_GRAMS`], in cents.
const HEAVY_SURCHARGE_CENTS: u64 = 500;

/// Zone that carries the international surcharge.
const INTERNATIONAL_ZONE: &str = "international";

/// International surcharge, as a percentage of the base price.
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

/// Price `parcel` against `card`.
pub fn price(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = card
        .bands(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = matching_band(bands, parcel.weight_grams)?;
    let base_cents = band.cents;
    let surcharge_cents = heavy_surcharge(parcel.weight_grams)
        .saturating_add(international_surcharge(&parcel.zone, base_cents));

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    })
}

/// The first band, ascending, that admits `weight_grams`.
fn matching_band(bands: &[Band], weight_grams: u32) -> Result<Band, QuoteError> {
    bands
        .iter()
        .find(|band| weight_grams <= band.max_grams)
        .copied()
        .ok_or_else(|| QuoteError::Overweight {
            grams: weight_grams,
            limit: bands.iter().map(|band| band.max_grams).max().unwrap_or(0),
        })
}

fn heavy_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > HEAVY_ABOVE_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    }
}

fn international_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == INTERNATIONAL_ZONE {
        percent_of(base_cents, INTERNATIONAL_SURCHARGE_PERCENT)
    } else {
        0
    }
}

/// `percent` of `amount`, rounded half-up to the whole cent.
fn percent_of(amount: u64, percent: u64) -> u64 {
    amount.saturating_mul(percent).saturating_add(50) / 100
}

#[cfg(test)]
mod tests {
    // See the note in `card::tests`: test harnesses may panic.
    #![allow(clippy::panic, clippy::unwrap_used, clippy::expect_used)]

    use super::*;

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
                          domestic\t500\t599\n\
                          domestic\t2000\t899\n\
                          domestic\t20000\t1799\n\
                          international\t500\t1499\n\
                          international\t20000\t4999\n";

    fn sample_card() -> RateCard {
        match crate::card::parse(SAMPLE) {
            Ok(card) => card,
            Err(malformed) => panic!("sample card is malformed at line {}", malformed.line),
        }
    }

    fn quote_for(weight_grams: u32, zone: &str) -> Result<Quote, QuoteError> {
        price(
            &sample_card(),
            &Parcel { weight_grams, zone: zone.to_owned() },
        )
    }

    #[test]
    fn prices_the_first_band_that_admits_the_weight() {
        let quote = quote_for(300, "domestic");

        assert_eq!(
            quote,
            Ok(Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            })
        );
    }

    #[test]
    fn a_weight_equal_to_the_bound_stays_in_that_band() {
        let quote = quote_for(500, "domestic");

        assert_eq!(quote.map(|q| (q.base_cents, q.band_max_grams)), Ok((599, 500)));
    }

    #[test]
    fn a_weight_one_gram_over_the_bound_moves_up_a_band() {
        let quote = quote_for(501, "domestic");

        assert_eq!(quote.map(|q| (q.base_cents, q.band_max_grams)), Ok((899, 2000)));
    }

    #[test]
    fn a_weightless_parcel_takes_the_lightest_band() {
        assert_eq!(quote_for(0, "domestic").map(|q| q.band_max_grams), Ok(500));
    }

    #[test]
    fn weight_above_ten_kilos_adds_the_heavy_surcharge() {
        let quote = quote_for(10_001, "domestic");

        assert_eq!(
            quote,
            Ok(Quote {
                base_cents: 1799,
                surcharge_cents: 500,
                total_cents: 2299,
                band_max_grams: 20_000,
            })
        );
    }

    #[test]
    fn weight_exactly_ten_kilos_is_not_heavy() {
        assert_eq!(quote_for(10_000, "domestic").map(|q| q.surcharge_cents), Ok(0));
    }

    #[test]
    fn international_adds_a_fifth_of_the_base_rounded_half_up() {
        // 20% of 1499 is 299.8, which rounds to 300.
        let quote = quote_for(400, "international");

        assert_eq!(
            quote,
            Ok(Quote {
                base_cents: 1499,
                surcharge_cents: 300,
                total_cents: 1799,
                band_max_grams: 500,
            })
        );
    }

    #[test]
    fn heavy_and_international_surcharges_add_together() {
        // 20% of 4999 is 999.8, which rounds to 1000, plus 500 for the weight.
        let quote = quote_for(15_000, "international");

        assert_eq!(
            quote,
            Ok(Quote {
                base_cents: 4999,
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20_000,
            })
        );
    }

    #[test]
    fn rounds_a_fractional_cent_below_a_half_down() {
        // 20% of 1 is 0.2.
        assert_eq!(percent_of(1, 20), 0);
    }

    #[test]
    fn rounds_a_half_cent_up() {
        // 50% of 5 is 2.5.
        assert_eq!(percent_of(5, 50), 3);
    }

    #[test]
    fn a_zone_absent_from_the_card_is_unknown() {
        assert_eq!(
            quote_for(400, "lunar"),
            Err(QuoteError::UnknownZone("lunar".to_owned()))
        );
    }

    #[test]
    fn zone_matching_is_exact() {
        assert_eq!(
            quote_for(400, "Domestic"),
            Err(QuoteError::UnknownZone("Domestic".to_owned()))
        );
    }

    #[test]
    fn a_weight_above_the_largest_band_is_overweight() {
        assert_eq!(
            quote_for(20_001, "domestic"),
            Err(QuoteError::Overweight { grams: 20_001, limit: 20_000 })
        );
    }

    #[test]
    fn an_unknown_zone_outranks_an_overweight_parcel() {
        assert_eq!(
            quote_for(90_000, "lunar"),
            Err(QuoteError::UnknownZone("lunar".to_owned()))
        );
    }

    #[test]
    fn the_overweight_limit_is_the_largest_band_of_that_zone() {
        let card = match crate::card::parse("express\t100\t250\n") {
            Ok(card) => card,
            Err(malformed) => panic!("malformed at line {}", malformed.line),
        };

        assert_eq!(
            price(&card, &Parcel { weight_grams: 101, zone: "express".to_owned() }),
            Err(QuoteError::Overweight { grams: 101, limit: 100 })
        );
    }
}
