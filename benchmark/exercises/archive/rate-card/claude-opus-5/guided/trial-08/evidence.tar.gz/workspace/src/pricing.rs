//! Pricing a parcel against a parsed rate card. Pure: no files, no clock, no
//! environment — just arithmetic in whole cents.

use crate::error::QuoteError;
use crate::parcel::{Parcel, Quote};
use crate::rate_card::RateCard;

/// Weight above which a parcel attracts the heavy surcharge.
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
/// Flat surcharge for parcels above [`HEAVY_THRESHOLD_GRAMS`].
const HEAVY_SURCHARGE_CENTS: u64 = 500;
/// The zone that attracts a proportional surcharge.
const INTERNATIONAL_ZONE: &str = "international";
/// Percentage of `base_cents` added for [`INTERNATIONAL_ZONE`].
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

/// Prices `parcel` against `card`.
///
/// # Errors
///
/// [`QuoteError::UnknownZone`] if the card prices no bands for the parcel's
/// zone, or [`QuoteError::Overweight`] if the parcel is heavier than the
/// largest band that zone offers.
pub(crate) fn price(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = card
        .bands(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let Some(band) = bands.iter().find(|band| band.max_grams >= parcel.weight_grams) else {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: bands.iter().map(|band| band.max_grams).max().unwrap_or(0),
        });
    };

    let base_cents = band.cents;
    let surcharge_cents = surcharges(parcel, base_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    })
}

/// Every surcharge the parcel attracts, added together.
fn surcharges(parcel: &Parcel, base_cents: u64) -> u64 {
    let mut cents = 0_u64;

    if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        cents = cents.saturating_add(HEAVY_SURCHARGE_CENTS);
    }
    if parcel.zone == INTERNATIONAL_ZONE {
        cents = cents.saturating_add(percent_half_up(base_cents, INTERNATIONAL_SURCHARGE_PERCENT));
    }

    cents
}

/// `percent` of `cents`, rounded half-up to the whole cent.
///
/// Kept in integer arithmetic so the rounding is the one that was asked for
/// rather than whatever a binary float happens to land on.
fn percent_half_up(cents: u64, percent: u64) -> u64 {
    cents.saturating_mul(percent).saturating_add(50) / 100
}

#[cfg(test)]
mod tests {
    use super::{percent_half_up, price};
    use crate::error::QuoteError;
    use crate::parcel::Parcel;
    use crate::rate_card::RateCard;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn card() -> RateCard {
        match RateCard::parse(SAMPLE) {
            Ok(card) => card,
            Err(error) => panic!("the sample rate card should parse, got {error}"),
        }
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    fn quote(weight_grams: u32, zone: &str) -> Result<crate::parcel::Quote, QuoteError> {
        price(&card(), &parcel(weight_grams, zone))
    }

    #[test]
    fn charges_the_first_band_that_covers_the_weight() {
        let quote = quote(750, "domestic").expect("750g domestic is priced");

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
    }

    #[test]
    fn treats_the_band_maximum_as_inclusive() {
        let quote = quote(500, "domestic").expect("500g domestic is priced");

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn charges_one_gram_over_a_band_to_the_next_band() {
        let quote = quote(501, "domestic").expect("501g domestic is priced");

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn prices_a_weightless_parcel_in_the_smallest_band() {
        let quote = quote(0, "domestic").expect("0g domestic is priced");

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn leaves_a_parcel_at_the_heavy_threshold_unsurcharged() {
        let quote = quote(10_000, "domestic").expect("10000g domestic is priced");

        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn adds_the_heavy_surcharge_above_the_threshold() {
        let quote = quote(10_001, "domestic").expect("10001g domestic is priced");

        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn adds_a_fifth_of_the_base_for_international() {
        let quote = quote(400, "international").expect("400g international is priced");

        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn adds_both_surcharges_to_a_heavy_international_parcel() {
        let quote = quote(15_000, "international").expect("15000g international is priced");

        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20_000);
    }

    #[test]
    fn takes_the_international_share_of_the_base_only() {
        let heavy = quote(15_000, "international").expect("15000g international is priced");
        let light = quote(400, "international").expect("400g international is priced");

        assert_eq!(heavy.surcharge_cents - 500, 1000);
        assert_eq!(light.surcharge_cents, 300);
    }

    #[test]
    fn rejects_a_zone_the_card_does_not_price() {
        assert_eq!(quote(500, "lunar"), Err(QuoteError::UnknownZone("lunar".to_string())));
    }

    #[test]
    fn matches_zone_names_exactly() {
        assert_eq!(quote(500, "Domestic"), Err(QuoteError::UnknownZone("Domestic".to_string())));
    }

    #[test]
    fn rejects_a_parcel_above_the_largest_band() {
        assert_eq!(
            quote(20_001, "domestic"),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            })
        );
    }

    #[test]
    fn reports_the_limit_of_the_zone_that_was_asked_for() {
        let narrow = match RateCard::parse("express\t500\t999\n") {
            Ok(card) => card,
            Err(error) => panic!("the narrow rate card should parse, got {error}"),
        };

        assert_eq!(
            price(&narrow, &parcel(600, "express")),
            Err(QuoteError::Overweight {
                grams: 600,
                limit: 500,
            })
        );
    }

    #[test]
    fn rounds_a_half_cent_up() {
        assert_eq!(percent_half_up(10, 5), 1);
        assert_eq!(percent_half_up(10, 4), 0);
        assert_eq!(percent_half_up(599, 20), 120);
        assert_eq!(percent_half_up(0, 20), 0);
    }
}
