//! Shipping quotes for the fulfilment service.
//!
//! A parcel is priced against a rate card that operations maintains and
//! redeploys without a code change. [`quote`] reads that card from the file
//! named by `RATECARD_PATH`:
//!
//! ```no_run
//! use ratecard::{quote, Parcel};
//!
//! let parcel = Parcel { weight_grams: 750, zone: "domestic".to_string() };
//! let priced = quote(&parcel)?;
//! println!("{} cents", priced.total_cents);
//! # Ok::<(), ratecard::QuoteError>(())
//! ```
//!
//! Reading the file is the only side effect. Parsing the card and pricing
//! against it are pure, and [`quote_from`] exposes that seam so a caller — or a
//! test — can supply the card itself.

mod error;
mod parcel;
mod pricing;
mod rate_card;
mod source;
pub mod zones;

pub use error::QuoteError;
pub use parcel::{Parcel, Quote};
pub use source::{EnvRateCardSource, RateCardSource, RATECARD_PATH_VAR};

use rate_card::RateCard;

/// Prices `parcel` against the rate card named by `RATECARD_PATH`.
///
/// # Errors
///
/// - [`QuoteError::RateCardUnavailable`] if `RATECARD_PATH` is unset or its
///   file cannot be read.
/// - [`QuoteError::MalformedRateCard`] if a line of the card is not a
///   well-formed band.
/// - [`QuoteError::UnknownZone`] if the card prices no bands for the parcel's
///   zone.
/// - [`QuoteError::Overweight`] if the parcel exceeds the zone's largest band.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_from(&EnvRateCardSource, parcel)
}

/// Prices `parcel` against the rate card `source` supplies.
///
/// ```
/// use ratecard::{quote_from, Parcel, QuoteError};
///
/// let card = || Ok::<_, QuoteError>("domestic\t500\t599\n".to_string());
/// let parcel = Parcel { weight_grams: 250, zone: "domestic".to_string() };
///
/// let priced = quote_from(&card, &parcel)?;
/// assert_eq!(priced.total_cents, 599);
/// assert_eq!(priced.band_max_grams, 500);
/// # Ok::<(), QuoteError>(())
/// ```
///
/// # Errors
///
/// As [`quote`], with [`QuoteError::RateCardUnavailable`] reported whenever
/// `source` cannot produce a card.
pub fn quote_from<S>(source: &S, parcel: &Parcel) -> Result<Quote, QuoteError>
where
    S: RateCardSource + ?Sized,
{
    let span = tracing::info_span!(
        "quote",
        zone = parcel.zone.as_str(),
        weight_grams = parcel.weight_grams,
        total_cents = tracing::field::Empty,
    );
    let _entered = span.enter();

    let result = source
        .load()
        .and_then(|contents| RateCard::parse(&contents))
        .and_then(|card| pricing::price(&card, parcel));

    match &result {
        Ok(priced) => {
            span.record("total_cents", priced.total_cents);
            tracing::info!(
                zone = parcel.zone.as_str(),
                weight_grams = parcel.weight_grams,
                total_cents = priced.total_cents,
                base_cents = priced.base_cents,
                surcharge_cents = priced.surcharge_cents,
                band_max_grams = priced.band_max_grams,
                "parcel priced"
            );
        }
        Err(error) => {
            tracing::warn!(
                zone = parcel.zone.as_str(),
                weight_grams = parcel.weight_grams,
                error = %error,
                "parcel not priced"
            );
        }
    }

    result
}
