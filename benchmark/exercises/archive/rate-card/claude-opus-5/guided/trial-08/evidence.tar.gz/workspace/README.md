# ratecard

Shipping quotes for the fulfilment service.

Warehouse operators price outbound parcels against a rate card that operations
maintains and redeploys without a code change. This crate owns reading that card
and turning a parcel into a quote.

## Using it

`RATECARD_PATH` names the tab-separated card. Blank lines and lines starting
with `#` are ignored; every other line is `zone`, `band_max_grams`, `cents`.

```text
# zone	band_max_grams	cents
domestic	500	599
domestic	20000	1799
international	20000	4999
```

```rust
use ratecard::{quote, Parcel};

let priced = quote(&Parcel { weight_grams: 750, zone: "domestic".to_string() })?;
println!("{} cents", priced.total_cents);
```

The band charged is the first whose `band_max_grams` covers the weight. On top
of it, parcels over 10 kg add 500 cents, and `international` adds 20% of the
band price rounded half-up to the cent.

Every call emits a `tracing` record — inside a `quote` span — carrying the zone,
the weight, and the resulting total, so a deployment can see what it priced.
Nothing is logged unless the host installs a subscriber.

## Shape

Reading the file is the only side effect, and it lives behind the
`RateCardSource` trait. Parsing the card and pricing against it are pure, so
their tests need no filesystem. `quote_from` exposes that seam for callers who
already hold a card.

## Development

```bash
cargo test
cargo clippy --all-targets
cargo doc --no-deps
```
