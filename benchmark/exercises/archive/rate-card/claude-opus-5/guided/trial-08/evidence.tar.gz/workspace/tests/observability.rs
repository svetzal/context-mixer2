//! Every quote has to be visible in operation. These tests capture what the
//! crate emits and assert on the fields an operator would query, not on the
//! rendered message text.

use std::collections::BTreeMap;
use std::fmt::Debug;
use std::sync::{Arc, Mutex, PoisonError};

use ratecard::{quote_from, Parcel, QuoteError, RateCardSource};
use tracing::field::{Field, Visit};
use tracing::subscriber::with_default;
use tracing::Level;
use tracing_subscriber::layer::{Context, Layer, SubscriberExt};
use tracing_subscriber::Registry;

const SAMPLE_CARD: &str = "\
domestic\t500\t599
domestic\t20000\t1799
international\t20000\t4999
";

/// One captured diagnostic record.
#[derive(Debug, Clone)]
struct Record {
    level: Level,
    fields: BTreeMap<String, String>,
    span_fields: BTreeMap<String, String>,
}

impl Record {
    fn field(&self, name: &str) -> Option<&str> {
        self.fields.get(name).map(String::as_str)
    }
}

/// Collects field values off events and their enclosing spans.
#[derive(Default)]
struct FieldVisitor(BTreeMap<String, String>);

impl Visit for FieldVisitor {
    fn record_debug(&mut self, field: &Field, value: &dyn Debug) {
        self.0.insert(field.name().to_string(), format!("{value:?}"));
    }

    fn record_str(&mut self, field: &Field, value: &str) {
        self.0.insert(field.name().to_string(), value.to_string());
    }

    fn record_u64(&mut self, field: &Field, value: u64) {
        self.0.insert(field.name().to_string(), value.to_string());
    }
}

/// A subscriber layer that keeps every event for later inspection.
#[derive(Clone, Default)]
struct Capture(Arc<Mutex<Vec<Record>>>);

impl Capture {
    fn records(&self) -> Vec<Record> {
        self.0.lock().unwrap_or_else(PoisonError::into_inner).clone()
    }
}

impl<S> Layer<S> for Capture
where
    S: tracing::Subscriber + for<'a> tracing_subscriber::registry::LookupSpan<'a>,
{
    fn on_new_span(
        &self,
        attrs: &tracing::span::Attributes<'_>,
        id: &tracing::span::Id,
        ctx: Context<'_, S>,
    ) {
        let mut visitor = FieldVisitor::default();
        attrs.record(&mut visitor);
        if let Some(span) = ctx.span(id) {
            span.extensions_mut().insert(visitor.0);
        }
    }

    fn on_record(
        &self,
        id: &tracing::span::Id,
        values: &tracing::span::Record<'_>,
        ctx: Context<'_, S>,
    ) {
        let mut visitor = FieldVisitor::default();
        values.record(&mut visitor);
        if let Some(span) = ctx.span(id) {
            let mut extensions = span.extensions_mut();
            if let Some(existing) = extensions.get_mut::<BTreeMap<String, String>>() {
                existing.extend(visitor.0);
            }
        }
    }

    fn on_event(&self, event: &tracing::Event<'_>, ctx: Context<'_, S>) {
        let mut visitor = FieldVisitor::default();
        event.record(&mut visitor);

        let span_fields = ctx
            .event_span(event)
            .and_then(|span| span.extensions().get::<BTreeMap<String, String>>().cloned())
            .unwrap_or_default();

        self.0.lock().unwrap_or_else(PoisonError::into_inner).push(Record {
            level: *event.metadata().level(),
            fields: visitor.0,
            span_fields,
        });
    }
}

struct FakeCard(Result<String, QuoteError>);

impl RateCardSource for FakeCard {
    fn load(&self) -> Result<String, QuoteError> {
        self.0.clone()
    }
}

/// Runs `parcel` through pricing with capture installed, returning what was
/// emitted.
fn records_for(card: Result<&str, QuoteError>, parcel: &Parcel) -> Vec<Record> {
    let capture = Capture::default();
    let subscriber = Registry::default().with(capture.clone());

    with_default(subscriber, || {
        let source = FakeCard(card.map(str::to_string));
        let _ = quote_from(&source, parcel);
    });

    capture.records()
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_string(),
    }
}

#[test]
fn emits_one_record_per_call_carrying_zone_weight_and_total() {
    let records = records_for(Ok(SAMPLE_CARD), &parcel(250, "domestic"));

    assert_eq!(records.len(), 1, "expected one record, got {records:?}");
    let record = records.first().expect("one record was captured");
    assert_eq!(record.level, Level::INFO);
    assert_eq!(record.field("zone"), Some("domestic"));
    assert_eq!(record.field("weight_grams"), Some("250"));
    assert_eq!(record.field("total_cents"), Some("599"));
}

#[test]
fn breaks_the_total_down_into_its_parts() {
    let records = records_for(Ok(SAMPLE_CARD), &parcel(15_000, "international"));
    let record = records.first().expect("one record was captured");

    assert_eq!(record.field("base_cents"), Some("4999"));
    assert_eq!(record.field("surcharge_cents"), Some("1500"));
    assert_eq!(record.field("total_cents"), Some("6499"));
    assert_eq!(record.field("band_max_grams"), Some("20000"));
}

#[test]
fn correlates_the_record_with_the_span_of_the_call() {
    let records = records_for(Ok(SAMPLE_CARD), &parcel(250, "domestic"));
    let record = records.first().expect("one record was captured");

    assert_eq!(record.span_fields.get("zone").map(String::as_str), Some("domestic"));
    assert_eq!(record.span_fields.get("weight_grams").map(String::as_str), Some("250"));
    assert_eq!(
        record.span_fields.get("total_cents").map(String::as_str),
        Some("599"),
        "the span should carry the outcome it recorded"
    );
}

#[test]
fn reports_a_failed_quote_as_a_warning_naming_the_reason() {
    let records = records_for(Ok(SAMPLE_CARD), &parcel(250, "lunar"));

    let record = records.first().expect("one record was captured");
    assert_eq!(record.level, Level::WARN);
    assert_eq!(record.field("zone"), Some("lunar"));
    assert_eq!(record.field("weight_grams"), Some("250"));
    assert_eq!(record.field("error"), Some("unknown zone: lunar"));
    assert_eq!(record.field("total_cents"), None);
}

#[test]
fn reports_an_unavailable_card_too() {
    let records = records_for(Err(QuoteError::RateCardUnavailable), &parcel(250, "domestic"));

    let record = records.first().expect("one record was captured");
    assert_eq!(record.level, Level::WARN);
    assert_eq!(record.field("error"), Some("rate card unavailable"));
}

#[test]
fn keeps_records_of_separate_calls_apart() {
    let capture = Capture::default();
    let subscriber = Registry::default().with(capture.clone());

    with_default(subscriber, || {
        let source = FakeCard(Ok(SAMPLE_CARD.to_string()));
        let _ = quote_from(&source, &parcel(250, "domestic"));
        let _ = quote_from(&source, &parcel(15_000, "international"));
    });

    let totals: Vec<Option<String>> = capture
        .records()
        .iter()
        .map(|record| record.field("total_cents").map(str::to_string))
        .collect();
    assert_eq!(totals, vec![Some("599".to_string()), Some("6499".to_string())]);
}
