//! What operators ask about, and what they get back.

/// A parcel presented for pricing.
///
/// Fields are public because callers build parcels literally:
///
/// ```
/// use ratecard::Parcel;
///
/// let parcel = Parcel { weight_grams: 750, zone: "domestic".to_string() };
/// assert_eq!(parcel.weight_grams, 750);
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    /// Billable weight of the parcel.
    pub weight_grams: u32,
    /// Zone name, matched against the rate card exactly.
    pub zone: String,
}

/// The priced result for a parcel, in whole cents.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quote {
    /// Cents charged by the matching band.
    pub base_cents: u64,
    /// Cents added on top of the band by surcharges.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// Upper weight threshold of the band that matched.
    pub band_max_grams: u32,
}
