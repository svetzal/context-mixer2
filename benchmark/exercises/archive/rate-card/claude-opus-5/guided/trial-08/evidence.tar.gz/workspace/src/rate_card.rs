//! Turning rate card text into bands. Pure: no files, no environment.

use std::collections::BTreeMap;

use crate::error::QuoteError;

/// One priced weight band within a zone.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct Band {
    /// Inclusive upper weight bound of the band.
    pub(crate) max_grams: u32,
    /// Cents charged for parcels that land in the band.
    pub(crate) cents: u64,
}

/// Every zone the rate card prices, each holding at least one band, ascending
/// by `max_grams`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

impl RateCard {
    /// Parses tab-separated rate card text.
    ///
    /// Empty lines and lines beginning with `#` are ignored. Every other line
    /// must be exactly three tab-separated fields: zone, band max in grams,
    /// cents.
    ///
    /// # Errors
    ///
    /// [`QuoteError::MalformedRateCard`] with the 1-based number of the first
    /// line that is neither ignorable nor a well-formed band.
    pub(crate) fn parse(contents: &str) -> Result<Self, QuoteError> {
        let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

        for (index, raw) in contents.lines().enumerate() {
            let line_number = index + 1;
            let line = raw.trim_end();
            if line.trim().is_empty() || line.trim_start().starts_with('#') {
                continue;
            }

            let (zone, band) = parse_band(line, line_number)?;
            zones.entry(zone).or_default().push(band);
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(Self { zones })
    }

    /// The bands for `zone`, ascending, or `None` if the zone is not priced.
    pub(crate) fn bands(&self, zone: &str) -> Option<&[Band]> {
        self.zones.get(zone).map(Vec::as_slice)
    }
}

/// Reads one band line, attributing any failure to `line_number`.
fn parse_band(line: &str, line_number: usize) -> Result<(String, Band), QuoteError> {
    let malformed = || QuoteError::MalformedRateCard { line: line_number };

    let mut fields = line.split('\t');
    let zone = fields.next().ok_or_else(malformed)?;
    let max_grams = fields.next().ok_or_else(malformed)?;
    let cents = fields.next().ok_or_else(malformed)?;
    if fields.next().is_some() || zone.is_empty() {
        return Err(malformed());
    }

    Ok((
        zone.to_string(),
        Band {
            max_grams: max_grams.parse().map_err(|_| malformed())?,
            cents: cents.parse().map_err(|_| malformed())?,
        },
    ))
}

#[cfg(test)]
mod tests {
    use super::{Band, RateCard};
    use crate::error::QuoteError;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn parsed(contents: &str) -> RateCard {
        match RateCard::parse(contents) {
            Ok(card) => card,
            Err(error) => panic!("expected a parseable rate card, got {error}"),
        }
    }

    #[test]
    fn collects_the_bands_of_each_zone() {
        let card = parsed(SAMPLE);

        assert_eq!(
            card.bands("domestic"),
            Some(
                [
                    Band {
                        max_grams: 500,
                        cents: 599
                    },
                    Band {
                        max_grams: 2000,
                        cents: 899
                    },
                    Band {
                        max_grams: 20_000,
                        cents: 1799
                    },
                ]
                .as_slice()
            )
        );
    }

    #[test]
    fn reports_no_bands_for_an_absent_zone() {
        assert_eq!(parsed(SAMPLE).bands("lunar"), None);
    }

    #[test]
    fn ignores_comments_and_blank_lines() {
        let card = parsed("\n# a comment\n\ndomestic\t500\t599\n\n");

        assert_eq!(
            card.bands("domestic"),
            Some(
                [Band {
                    max_grams: 500,
                    cents: 599
                }]
                .as_slice()
            )
        );
    }

    #[test]
    fn orders_bands_ascending_however_the_file_lists_them() {
        let card = parsed("domestic\t20000\t1799\ndomestic\t500\t599\n");

        let maxima: Vec<u32> = card
            .bands("domestic")
            .unwrap_or_default()
            .iter()
            .map(|band| band.max_grams)
            .collect();
        assert_eq!(maxima, vec![500, 20_000]);
    }

    #[test]
    fn counts_comments_and_blanks_when_numbering_a_malformed_line() {
        let contents = "# header\n\ndomestic\t500\t599\ndomestic\toops\t899\n";

        assert_eq!(RateCard::parse(contents), Err(QuoteError::MalformedRateCard { line: 4 }));
    }

    #[test]
    fn rejects_a_line_with_too_few_fields() {
        assert_eq!(
            RateCard::parse("domestic\t500\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn rejects_a_line_with_too_many_fields() {
        assert_eq!(
            RateCard::parse("domestic\t500\t599\textra\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn rejects_space_separated_fields() {
        assert_eq!(
            RateCard::parse("domestic 500 599\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn rejects_unparseable_cents() {
        assert_eq!(
            RateCard::parse("domestic\t500\t5.99\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn rejects_a_negative_band_maximum() {
        assert_eq!(
            RateCard::parse("domestic\t-500\t599\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn rejects_a_nameless_zone() {
        assert_eq!(RateCard::parse("\t500\t599\n"), Err(QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn tolerates_carriage_returns() {
        let card = parsed("domestic\t500\t599\r\n");

        assert_eq!(
            card.bands("domestic"),
            Some(
                [Band {
                    max_grams: 500,
                    cents: 599
                }]
                .as_slice()
            )
        );
    }

    #[test]
    fn accepts_an_empty_card_with_no_zones() {
        assert_eq!(parsed("# nothing priced yet\n").bands("domestic"), None);
    }
}
