//! The edge where the rate card comes from.
//!
//! Pricing depends on this contract rather than on the filesystem, so tests can
//! supply a card in memory and the deployed binary can read the one operations
//! redeployed.

use std::env;
use std::fs;

use crate::error::QuoteError;

/// Environment variable naming the rate card file.
pub const RATECARD_PATH_VAR: &str = "RATECARD_PATH";

/// Somewhere rate card text can be read from.
pub trait RateCardSource {
    /// Reads the current rate card.
    ///
    /// # Errors
    ///
    /// [`QuoteError::RateCardUnavailable`] if the card cannot be read at all.
    fn load(&self) -> Result<String, QuoteError>;
}

/// Reads the file named by `RATECARD_PATH`.
///
/// Deliberately thin: it resolves the variable, reads the bytes, and reports
/// either failure as [`QuoteError::RateCardUnavailable`]. Nothing here
/// interprets the card.
#[derive(Debug, Clone, Copy, Default)]
pub struct EnvRateCardSource;

impl RateCardSource for EnvRateCardSource {
    fn load(&self) -> Result<String, QuoteError> {
        let path = env::var(RATECARD_PATH_VAR).map_err(|_| QuoteError::RateCardUnavailable)?;
        fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}

impl<F> RateCardSource for F
where
    F: Fn() -> Result<String, QuoteError>,
{
    fn load(&self) -> Result<String, QuoteError> {
        self()
    }
}
