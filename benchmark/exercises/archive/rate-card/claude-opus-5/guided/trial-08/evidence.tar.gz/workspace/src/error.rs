//! The failure modes a caller can act on.

use std::fmt;

/// Why a parcel could not be priced.
///
/// Every variant is a condition the caller is expected to handle, so the crate
/// reports them rather than terminating the process.
/// Callers match these variants directly, so the set stays exhaustive.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` was unset, or the file it names could not be read.
    RateCardUnavailable,
    /// A line of the rate card was not three tab-separated fields, or its
    /// numbers did not parse. `line` is 1-based and counts every line in the
    /// file, including comments and blanks.
    MalformedRateCard {
        /// 1-based number of the offending line.
        line: usize,
    },
    /// The requested zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the largest band its zone offers.
    Overweight {
        /// Weight of the parcel that was rejected.
        grams: u32,
        /// Largest `band_max_grams` the zone offers.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => {
                write!(f, "rate card unavailable")
            }
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            Self::Overweight { grams, limit } => {
                write!(f, "parcel of {grams}g exceeds the zone limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[cfg(test)]
mod tests {
    use super::QuoteError;

    #[test]
    fn describes_an_unavailable_rate_card() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
    }

    #[test]
    fn describes_a_malformed_line_by_number() {
        assert_eq!(
            QuoteError::MalformedRateCard { line: 4 }.to_string(),
            "malformed rate card at line 4"
        );
    }

    #[test]
    fn names_the_zone_it_could_not_find() {
        assert_eq!(QuoteError::UnknownZone("lunar".to_string()).to_string(), "unknown zone: lunar");
    }

    #[test]
    fn reports_both_weight_and_limit_when_overweight() {
        assert_eq!(
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000,
            }
            .to_string(),
            "parcel of 25000g exceeds the zone limit of 20000g"
        );
    }

    #[test]
    fn is_usable_as_a_standard_error() {
        fn as_error(e: QuoteError) -> Box<dyn std::error::Error> {
            Box::new(e)
        }

        assert_eq!(as_error(QuoteError::RateCardUnavailable).to_string(), "rate card unavailable");
    }
}
