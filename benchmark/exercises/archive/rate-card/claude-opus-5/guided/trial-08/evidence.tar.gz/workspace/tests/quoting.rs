//! Pricing behaviour through the public API, with the rate card supplied in
//! memory so no test touches a real filesystem.

use ratecard::{quote_from, Parcel, Quote, QuoteError, RateCardSource};

const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

/// A rate card held in memory, standing in for the deployed file.
struct FakeCard(Result<String, QuoteError>);

impl FakeCard {
    fn holding(contents: &str) -> Self {
        Self(Ok(contents.to_string()))
    }

    fn missing() -> Self {
        Self(Err(QuoteError::RateCardUnavailable))
    }
}

impl RateCardSource for FakeCard {
    fn load(&self) -> Result<String, QuoteError> {
        self.0.clone()
    }
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_string(),
    }
}

fn quoted(weight_grams: u32, zone: &str) -> Result<Quote, QuoteError> {
    quote_from(&FakeCard::holding(SAMPLE_CARD), &parcel(weight_grams, zone))
}

#[test]
fn prices_a_light_domestic_parcel_from_its_band() {
    let quote = quoted(250, "domestic").expect("250g domestic is priced");

    assert_eq!(quote.base_cents, 599);
    assert_eq!(quote.surcharge_cents, 0);
    assert_eq!(quote.total_cents, 599);
    assert_eq!(quote.band_max_grams, 500);
}

#[test]
fn steps_up_a_band_when_the_weight_crosses_a_threshold() {
    assert_eq!(
        quoted(500, "domestic").map(|q| (q.base_cents, q.band_max_grams)),
        Ok((599, 500))
    );
    assert_eq!(
        quoted(501, "domestic").map(|q| (q.base_cents, q.band_max_grams)),
        Ok((899, 2000))
    );
    assert_eq!(
        quoted(2001, "domestic").map(|q| (q.base_cents, q.band_max_grams)),
        Ok((1799, 20_000))
    );
}

#[test]
fn surcharges_a_parcel_over_ten_kilos() {
    let quote = quoted(12_000, "domestic").expect("12000g domestic is priced");

    assert_eq!(quote.base_cents, 1799);
    assert_eq!(quote.surcharge_cents, 500);
    assert_eq!(quote.total_cents, 2299);
}

#[test]
fn surcharges_international_by_a_fifth_of_the_base() {
    let quote = quoted(500, "international").expect("500g international is priced");

    assert_eq!(quote.base_cents, 1499);
    assert_eq!(quote.surcharge_cents, 300);
    assert_eq!(quote.total_cents, 1799);
}

#[test]
fn stacks_the_weight_and_zone_surcharges() {
    let quote = quoted(18_000, "international").expect("18000g international is priced");

    assert_eq!(quote.base_cents, 4999);
    assert_eq!(quote.surcharge_cents, 1500);
    assert_eq!(quote.total_cents, 6499);
    assert_eq!(quote.band_max_grams, 20_000);
}

#[test]
fn refuses_a_zone_the_card_does_not_price() {
    assert_eq!(quoted(500, "lunar"), Err(QuoteError::UnknownZone("lunar".to_string())));
}

#[test]
fn refuses_a_parcel_heavier_than_the_largest_band() {
    assert_eq!(
        quoted(25_000, "international"),
        Err(QuoteError::Overweight {
            grams: 25_000,
            limit: 20_000,
        })
    );
}

#[test]
fn reports_an_unreadable_card_as_unavailable() {
    assert_eq!(
        quote_from(&FakeCard::missing(), &parcel(500, "domestic")),
        Err(QuoteError::RateCardUnavailable)
    );
}

#[test]
fn reports_the_line_number_of_a_malformed_band() {
    let card = FakeCard::holding("# header\n\ndomestic\t500\t599\ndomestic\t2000\n");

    assert_eq!(
        quote_from(&card, &parcel(250, "domestic")),
        Err(QuoteError::MalformedRateCard { line: 4 })
    );
}

#[test]
fn rejects_a_malformed_card_before_pricing_anything() {
    let card = FakeCard::holding("domestic\tnot-a-number\t599\n");

    assert_eq!(
        quote_from(&card, &parcel(250, "lunar")),
        Err(QuoteError::MalformedRateCard { line: 1 })
    );
}

#[test]
fn lets_a_caller_match_every_failure_without_a_catch_all() {
    fn describe(error: &QuoteError) -> String {
        match error {
            QuoteError::RateCardUnavailable => "unavailable".to_string(),
            QuoteError::MalformedRateCard { line } => format!("malformed at {line}"),
            QuoteError::UnknownZone(zone) => format!("unknown zone {zone}"),
            QuoteError::Overweight { grams, limit } => format!("{grams} over {limit}"),
        }
    }

    let error = quoted(500, "lunar").expect_err("an unknown zone cannot be priced");
    assert_eq!(describe(&error), "unknown zone lunar");
}

#[test]
fn survives_a_card_redeployed_between_calls() {
    let cheap = FakeCard::holding("domestic\t500\t599\n");
    let dear = FakeCard::holding("domestic\t500\t699\n");

    assert_eq!(quote_from(&cheap, &parcel(250, "domestic")).map(|q| q.total_cents), Ok(599));
    assert_eq!(quote_from(&dear, &parcel(250, "domestic")).map(|q| q.total_cents), Ok(699));
}
