//! The one side effect the crate has: reading the file named by
//! `RATECARD_PATH`. These tests share process-wide environment state, so they
//! take a lock rather than run concurrently.

use std::env;
use std::fs;
use std::sync::{Mutex, MutexGuard, PoisonError};

use ratecard::{quote, Parcel, QuoteError, RATECARD_PATH_VAR};

/// Serialises the tests that mutate `RATECARD_PATH`.
static ENV_LOCK: Mutex<()> = Mutex::new(());

const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn env_lock() -> MutexGuard<'static, ()> {
    ENV_LOCK.lock().unwrap_or_else(PoisonError::into_inner)
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_string(),
    }
}

#[test]
fn prices_against_the_card_the_environment_points_at() {
    let _guard = env_lock();
    let dir = tempfile::tempdir().expect("a temporary directory");
    let path = dir.path().join("rates.tsv");
    fs::write(&path, SAMPLE_CARD).expect("the rate card is written");
    env::set_var(RATECARD_PATH_VAR, &path);

    let priced = quote(&parcel(750, "domestic")).expect("750g domestic is priced");

    assert_eq!(priced.base_cents, 899);
    assert_eq!(priced.total_cents, 899);
    assert_eq!(priced.band_max_grams, 2000);
}

#[test]
fn reports_an_unset_variable_as_unavailable() {
    let _guard = env_lock();
    env::remove_var(RATECARD_PATH_VAR);

    assert_eq!(quote(&parcel(750, "domestic")), Err(QuoteError::RateCardUnavailable));
}

#[test]
fn reports_a_missing_file_as_unavailable() {
    let _guard = env_lock();
    let dir = tempfile::tempdir().expect("a temporary directory");
    env::set_var(RATECARD_PATH_VAR, dir.path().join("absent.tsv"));

    assert_eq!(quote(&parcel(750, "domestic")), Err(QuoteError::RateCardUnavailable));
}

#[test]
fn reports_an_unreadable_path_as_unavailable() {
    let _guard = env_lock();
    let dir = tempfile::tempdir().expect("a temporary directory");
    env::set_var(RATECARD_PATH_VAR, dir.path());

    assert_eq!(quote(&parcel(750, "domestic")), Err(QuoteError::RateCardUnavailable));
}

#[test]
fn reads_the_card_afresh_on_every_call() {
    let _guard = env_lock();
    let dir = tempfile::tempdir().expect("a temporary directory");
    let path = dir.path().join("rates.tsv");
    env::set_var(RATECARD_PATH_VAR, &path);

    fs::write(&path, "domestic\t500\t599\n").expect("the first rate card is written");
    let before = quote(&parcel(250, "domestic")).expect("250g domestic is priced");

    fs::write(&path, "domestic\t500\t699\n").expect("the redeployed rate card is written");
    let after = quote(&parcel(250, "domestic")).expect("250g domestic is priced again");

    assert_eq!(before.total_cents, 599);
    assert_eq!(after.total_cents, 699);
}
