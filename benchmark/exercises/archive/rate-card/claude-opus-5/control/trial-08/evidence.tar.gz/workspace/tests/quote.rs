//! The public contract, exercised end to end against a card on disk.

use std::env;
use std::fs;
use std::sync::{Mutex, MutexGuard};

use ratecard::diagnostics::{self, Outcome};
use ratecard::{quote, Parcel, Quote, QuoteError};

const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

/// `RATECARD_PATH` is process-wide, so tests that set it take turns.
static ENV: Mutex<()> = Mutex::new(());

fn lock() -> MutexGuard<'static, ()> {
    ENV.lock().unwrap_or_else(|poisoned| poisoned.into_inner())
}

/// Run `f` with `contents` deployed as the rate card.
fn with_card<T>(contents: &str, f: impl FnOnce() -> T) -> T {
    let _guard = lock();
    let dir = tempfile::tempdir().expect("temp dir");
    let path = dir.path().join("rates.tsv");
    fs::write(&path, contents).expect("write card");

    env::set_var("RATECARD_PATH", &path);
    let value = f();
    env::remove_var("RATECARD_PATH");

    value
}

fn quote_for(weight_grams: u32, zone: &str) -> Result<Quote, QuoteError> {
    with_card(CARD, || {
        quote(&Parcel {
            weight_grams,
            zone: zone.to_string(),
        })
    })
}

#[test]
fn prices_a_parcel_from_its_band() {
    assert_eq!(
        quote_for(300, "domestic"),
        Ok(Quote {
            base_cents: 599,
            surcharge_cents: 0,
            total_cents: 599,
            band_max_grams: 500,
        })
    );
}

#[test]
fn a_band_includes_its_own_threshold() {
    assert_eq!(quote_for(500, "domestic").unwrap().base_cents, 599);
    assert_eq!(quote_for(501, "domestic").unwrap().base_cents, 899);
    assert_eq!(quote_for(2000, "domestic").unwrap().band_max_grams, 2000);
    assert_eq!(quote_for(2001, "domestic").unwrap().band_max_grams, 20000);
}

#[test]
fn a_weightless_parcel_falls_in_the_first_band() {
    assert_eq!(
        quote_for(0, "domestic"),
        Ok(Quote {
            base_cents: 599,
            surcharge_cents: 0,
            total_cents: 599,
            band_max_grams: 500,
        })
    );
}

#[test]
fn international_adds_twenty_percent_rounded_half_up() {
    assert_eq!(
        quote_for(400, "international"),
        Ok(Quote {
            base_cents: 1499,
            // 299.8 rounds up
            surcharge_cents: 300,
            total_cents: 1799,
            band_max_grams: 500,
        })
    );
}

#[test]
fn heavy_parcels_add_a_flat_five_hundred() {
    assert_eq!(
        quote_for(15_000, "domestic"),
        Ok(Quote {
            base_cents: 1799,
            surcharge_cents: 500,
            total_cents: 2299,
            band_max_grams: 20000,
        })
    );
}

#[test]
fn the_heavy_surcharge_starts_strictly_above_ten_kilos() {
    assert_eq!(quote_for(10_000, "domestic").unwrap().surcharge_cents, 0);
    assert_eq!(quote_for(10_001, "domestic").unwrap().surcharge_cents, 500);
}

#[test]
fn a_heavy_international_parcel_takes_both_surcharges() {
    assert_eq!(
        quote_for(15_000, "international"),
        Ok(Quote {
            base_cents: 4999,
            // 500 flat + 999.8 rounded up
            surcharge_cents: 1500,
            total_cents: 6499,
            band_max_grams: 20000,
        })
    );
}

#[test]
fn an_unpriced_zone_is_unknown() {
    assert_eq!(quote_for(300, "lunar"), Err(QuoteError::UnknownZone("lunar".to_string())));
}

#[test]
fn too_heavy_for_the_zone_reports_its_limit() {
    assert_eq!(
        quote_for(20_001, "domestic"),
        Err(QuoteError::Overweight {
            grams: 20_001,
            limit: 20_000,
        })
    );
    assert_eq!(
        quote_for(20_001, "international"),
        Err(QuoteError::Overweight {
            grams: 20_001,
            limit: 20_000,
        })
    );
}

#[test]
fn an_unset_path_leaves_the_card_unavailable() {
    let _guard = lock();
    env::remove_var("RATECARD_PATH");

    assert_eq!(
        quote(&Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        }),
        Err(QuoteError::RateCardUnavailable)
    );
}

#[test]
fn a_missing_file_leaves_the_card_unavailable() {
    let _guard = lock();
    let dir = tempfile::tempdir().expect("temp dir");
    env::set_var("RATECARD_PATH", dir.path().join("absent.tsv"));

    let result = quote(&Parcel {
        weight_grams: 300,
        zone: "domestic".to_string(),
    });
    env::remove_var("RATECARD_PATH");

    assert_eq!(result, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn an_unreadable_card_leaves_it_unavailable() {
    let _guard = lock();
    let dir = tempfile::tempdir().expect("temp dir");
    // A directory is present but cannot be read as a card.
    env::set_var("RATECARD_PATH", dir.path());

    let result = quote(&Parcel {
        weight_grams: 300,
        zone: "domestic".to_string(),
    });
    env::remove_var("RATECARD_PATH");

    assert_eq!(result, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn a_short_line_is_malformed_at_its_line_number() {
    let card = "# zone\tband_max_grams\tcents\n\ndomestic\t500\t599\ndomestic\t2000\n";
    let result = with_card(card, || {
        quote(&Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        })
    });
    assert_eq!(result, Err(QuoteError::MalformedRateCard { line: 4 }));
}

#[test]
fn an_unparsable_number_is_malformed_at_its_line_number() {
    let card = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\theavy\t899\n";
    let result = with_card(card, || {
        quote(&Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        })
    });
    assert_eq!(result, Err(QuoteError::MalformedRateCard { line: 3 }));
}

#[test]
fn a_malformed_line_fails_the_card_even_for_an_untouched_zone() {
    let card = "domestic\t500\t599\ninternational\tlots\t1499\n";
    let result = with_card(card, || {
        quote(&Parcel {
            weight_grams: 300,
            zone: "domestic".to_string(),
        })
    });
    assert_eq!(result, Err(QuoteError::MalformedRateCard { line: 2 }));
}

#[test]
fn comments_and_blanks_are_ignored_but_still_counted() {
    let card = "#one\n\n#three\n\ndomestic\t500\t599\n";
    let quoted = with_card(card, || {
        quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
    });
    assert_eq!(quoted.unwrap().base_cents, 599);

    let card = "#one\n\n#three\n\ndomestic\t500\tfree\n";
    let failed = with_card(card, || {
        quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
    });
    assert_eq!(failed, Err(QuoteError::MalformedRateCard { line: 5 }));
}

#[test]
fn bands_out_of_order_in_the_file_still_apply_in_order() {
    let card = "domestic\t20000\t1799\ndomestic\t500\t599\ndomestic\t2000\t899\n";
    let quoted = with_card(card, || {
        quote(&Parcel {
            weight_grams: 1_000,
            zone: "domestic".to_string(),
        })
    });
    assert_eq!(
        quoted,
        Ok(Quote {
            base_cents: 899,
            surcharge_cents: 0,
            total_cents: 899,
            band_max_grams: 2000,
        })
    );
}

#[test]
fn the_card_can_be_redeployed_between_quotes() {
    let parcel = Parcel {
        weight_grams: 300,
        zone: "domestic".to_string(),
    };
    assert_eq!(with_card(CARD, || quote(&parcel)).unwrap().base_cents, 599);
    assert_eq!(with_card("domestic\t500\t650\n", || quote(&parcel)).unwrap().base_cents, 650);
}

#[test]
fn every_priced_quote_is_recorded() {
    let (quoted, records) = diagnostics::capture(|| {
        with_card(CARD, || {
            quote(&Parcel {
                weight_grams: 15_000,
                zone: "international".to_string(),
            })
        })
    });

    let total_cents = quoted.unwrap().total_cents;
    assert_eq!(records.len(), 1);
    assert_eq!(records[0].zone, "international");
    assert_eq!(records[0].weight_grams, 15_000);
    assert_eq!(records[0].outcome, Outcome::Quoted { total_cents });
}

#[test]
fn a_failed_quote_is_recorded_too() {
    let (_, records) = diagnostics::capture(|| {
        with_card(CARD, || {
            quote(&Parcel {
                weight_grams: 300,
                zone: "lunar".to_string(),
            })
        })
    });

    assert_eq!(records.len(), 1);
    assert_eq!(records[0].zone, "lunar");
    assert_eq!(records[0].weight_grams, 300);
    assert_eq!(
        records[0].outcome,
        Outcome::Failed {
            reason: "unknown zone: lunar".to_string()
        }
    );
}

#[test]
fn one_record_per_call() {
    let (_, records) = diagnostics::capture(|| {
        with_card(CARD, || {
            for weight_grams in [100, 700, 15_000] {
                let _ = quote(&Parcel {
                    weight_grams,
                    zone: "domestic".to_string(),
                });
            }
        })
    });

    let weights: Vec<u32> = records.iter().map(|record| record.weight_grams).collect();
    assert_eq!(weights, vec![100, 700, 15_000]);
}
