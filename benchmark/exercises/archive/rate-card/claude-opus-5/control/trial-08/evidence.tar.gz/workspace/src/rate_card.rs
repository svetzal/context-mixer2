//! Reading the tab-separated rate card operations deploys.

use std::collections::BTreeMap;
use std::env;
use std::fs;

use crate::QuoteError;

/// One priced weight band within a zone.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct Band {
    pub(crate) max_grams: u32,
    pub(crate) cents: u64,
}

/// Every zone's bands, each zone's held in ascending `max_grams`.
#[derive(Debug, Default, PartialEq, Eq)]
pub(crate) struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

impl RateCard {
    /// Load the card named by the `var` environment variable. An unset
    /// variable, or a file that cannot be read as text, is
    /// [`QuoteError::RateCardUnavailable`].
    pub(crate) fn from_env(var: &str) -> Result<Self, QuoteError> {
        let path = env::var_os(var).ok_or(QuoteError::RateCardUnavailable)?;
        let text = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
        Self::parse(&text)
    }

    /// Parse the whole card, so a bad line is reported whether or not the
    /// parcel being priced would have touched it.
    pub(crate) fn parse(text: &str) -> Result<Self, QuoteError> {
        let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

        for (index, raw) in text.lines().enumerate() {
            // Line numbers count every line in the file, comments and blanks included.
            let line = index + 1;
            let malformed = || QuoteError::MalformedRateCard { line };

            let content = raw.trim_end_matches('\r');
            let trimmed = content.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }

            let fields: Vec<&str> = content.split('\t').collect();
            let [zone, max_grams, cents] = fields[..] else {
                return Err(malformed());
            };
            let max_grams: u32 = max_grams.trim().parse().map_err(|_| malformed())?;
            let cents: u64 = cents.trim().parse().map_err(|_| malformed())?;

            zones
                .entry(zone.trim().to_string())
                .or_default()
                .push(Band { max_grams, cents });
        }

        // The card need not be written in order; the bands still apply in it.
        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(Self { zones })
    }

    /// The first band in `zone` wide enough to hold `weight_grams`.
    pub(crate) fn band_for(&self, zone: &str, weight_grams: u32) -> Result<Band, QuoteError> {
        let bands =
            self.zones.get(zone).ok_or_else(|| QuoteError::UnknownZone(zone.to_string()))?;

        bands
            .iter()
            .copied()
            .find(|band| band.max_grams >= weight_grams)
            .ok_or_else(|| QuoteError::Overweight {
                grams: weight_grams,
                // Bands are sorted and a zone only exists once it has one.
                limit: bands.last().map_or(0, |band| band.max_grams),
            })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
                        domestic\t500\t599\n\
                        domestic\t2000\t899\n\
                        domestic\t20000\t1799\n\
                        international\t500\t1499\n\
                        international\t20000\t4999\n";

    fn card() -> RateCard {
        RateCard::parse(CARD).expect("sample card parses")
    }

    #[test]
    fn skips_comments_and_blank_lines() {
        let parsed = RateCard::parse("# a comment\n\n   \n\ndomestic\t500\t599\n").unwrap();
        assert_eq!(
            parsed.band_for("domestic", 1),
            Ok(Band {
                max_grams: 500,
                cents: 599
            })
        );
    }

    #[test]
    fn matches_the_first_band_at_or_above_the_weight() {
        let card = card();
        assert_eq!(card.band_for("domestic", 0).unwrap().max_grams, 500);
        assert_eq!(card.band_for("domestic", 500).unwrap().max_grams, 500);
        assert_eq!(card.band_for("domestic", 501).unwrap().max_grams, 2000);
        assert_eq!(card.band_for("domestic", 2000).unwrap().max_grams, 2000);
        assert_eq!(card.band_for("domestic", 2001).unwrap().max_grams, 20000);
    }

    #[test]
    fn orders_bands_written_out_of_order() {
        let parsed =
            RateCard::parse("domestic\t20000\t1799\ndomestic\t500\t599\ndomestic\t2000\t899\n")
                .unwrap();
        assert_eq!(parsed.band_for("domestic", 400).unwrap().cents, 599);
        assert_eq!(parsed.band_for("domestic", 1500).unwrap().cents, 899);
    }

    #[test]
    fn unknown_zone_carries_the_requested_zone() {
        assert_eq!(
            card().band_for("lunar", 100),
            Err(QuoteError::UnknownZone("lunar".to_string()))
        );
    }

    #[test]
    fn overweight_carries_the_largest_band() {
        assert_eq!(
            card().band_for("domestic", 20001),
            Err(QuoteError::Overweight {
                grams: 20001,
                limit: 20000
            })
        );
    }

    #[test]
    fn wrong_field_count_is_malformed_at_that_line() {
        let too_few = RateCard::parse("domestic\t500\t599\ndomestic\t2000\n");
        assert_eq!(too_few, Err(QuoteError::MalformedRateCard { line: 2 }));

        let too_many = RateCard::parse("domestic\t500\t599\textra\n");
        assert_eq!(too_many, Err(QuoteError::MalformedRateCard { line: 1 }));

        let unseparated = RateCard::parse("domestic 500 599\n");
        assert_eq!(unseparated, Err(QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn unparsable_numbers_are_malformed_counting_every_line() {
        let text = "# header\n\ndomestic\t500\t599\ndomestic\theavy\t899\n";
        assert_eq!(RateCard::parse(text), Err(QuoteError::MalformedRateCard { line: 4 }));

        let text = "# header\ndomestic\t500\tfree\n";
        assert_eq!(RateCard::parse(text), Err(QuoteError::MalformedRateCard { line: 2 }));
    }

    #[test]
    fn reports_the_first_malformed_line() {
        let text = "domestic\t500\t599\nbad\nalso\tbad\n";
        assert_eq!(RateCard::parse(text), Err(QuoteError::MalformedRateCard { line: 2 }));
    }

    #[test]
    fn an_empty_card_knows_no_zones() {
        let parsed = RateCard::parse("").unwrap();
        assert_eq!(
            parsed.band_for("domestic", 1),
            Err(QuoteError::UnknownZone("domestic".to_string()))
        );
    }

    #[test]
    fn tolerates_windows_line_endings() {
        let parsed = RateCard::parse("# zone\r\ndomestic\t500\t599\r\n").unwrap();
        assert_eq!(parsed.band_for("domestic", 100).unwrap().cents, 599);
    }
}
