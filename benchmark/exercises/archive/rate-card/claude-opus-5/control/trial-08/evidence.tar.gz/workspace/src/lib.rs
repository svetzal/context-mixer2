//! Shipping quotes for the fulfilment service.
//!
//! [`quote`] prices a [`Parcel`] against the rate card named by the
//! `RATECARD_PATH` environment variable, so operations can redeploy the card
//! without a code change.

pub mod diagnostics;
mod rate_card;
pub mod zones;

use std::error::Error;
use std::fmt;

use diagnostics::{Outcome, QuoteRecord};
use rate_card::RateCard;

/// Environment variable naming the rate card to price against.
const RATECARD_PATH_VAR: &str = "RATECARD_PATH";

/// Weight strictly above this attracts the heavy-parcel surcharge.
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_SURCHARGE_CENTS: u64 = 500;

/// The zone that attracts the international uplift, and the uplift itself.
const INTERNATIONAL_ZONE: &str = "international";
const INTERNATIONAL_UPLIFT_PERCENT: u64 = 20;

/// A parcel awaiting a price.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// What a parcel costs to ship, and the band that priced it.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Why a parcel could not be priced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, or its file is missing or unreadable.
    RateCardUnavailable,
    /// A card line is not three tab-separated fields, or its numbers do not
    /// parse. `line` is 1-based and counts comments and blanks.
    MalformedRateCard { line: usize },
    /// The card prices no bands for the requested zone.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => write!(f, "malformed rate card at line {line}"),
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel of {grams} g exceeds the {limit} g limit for its zone")
            }
        }
    }
}

impl Error for QuoteError {}

/// Price `parcel` against the deployed rate card, emitting a diagnostic record
/// for the call either way.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let result = price(parcel);

    diagnostics::emit(&QuoteRecord {
        zone: parcel.zone.clone(),
        weight_grams: parcel.weight_grams,
        outcome: match &result {
            Ok(quote) => Outcome::Quoted {
                total_cents: quote.total_cents,
            },
            Err(error) => Outcome::Failed {
                reason: error.to_string(),
            },
        },
    });

    result
}

fn price(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = RateCard::from_env(RATECARD_PATH_VAR)?;
    let band = card.band_for(&parcel.zone, parcel.weight_grams)?;

    let base_cents = band.cents;
    let surcharge_cents = surcharge_for(parcel, base_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    })
}

/// Surcharges accumulate: heavy parcels and international zones can both apply.
fn surcharge_for(parcel: &Parcel, base_cents: u64) -> u64 {
    let mut surcharge = 0u64;

    if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        surcharge = surcharge.saturating_add(HEAVY_SURCHARGE_CENTS);
    }

    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge =
            surcharge.saturating_add(percent_half_up(base_cents, INTERNATIONAL_UPLIFT_PERCENT));
    }

    surcharge
}

/// `percent` of `cents`, rounded half-up to the cent.
fn percent_half_up(cents: u64, percent: u64) -> u64 {
    let scaled = u128::from(cents) * u128::from(percent);
    u64::try_from((scaled + 50) / 100).unwrap_or(u64::MAX)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn heavy_surcharge_applies_strictly_above_the_threshold() {
        let at = Parcel {
            weight_grams: HEAVY_THRESHOLD_GRAMS,
            zone: "domestic".to_string(),
        };
        let above = Parcel {
            weight_grams: HEAVY_THRESHOLD_GRAMS + 1,
            zone: "domestic".to_string(),
        };
        assert_eq!(surcharge_for(&at, 1799), 0);
        assert_eq!(surcharge_for(&above, 1799), 500);
    }

    #[test]
    fn international_uplift_is_twenty_percent_of_base() {
        let parcel = Parcel {
            weight_grams: 100,
            zone: "international".to_string(),
        };
        assert_eq!(surcharge_for(&parcel, 1499), 300);
        assert_eq!(surcharge_for(&parcel, 1000), 200);
    }

    #[test]
    fn surcharges_add_together() {
        let parcel = Parcel {
            weight_grams: 15_000,
            zone: "international".to_string(),
        };
        assert_eq!(surcharge_for(&parcel, 4999), 500 + 1000);
    }

    #[test]
    fn other_zones_take_no_uplift() {
        let parcel = Parcel {
            weight_grams: 100,
            zone: "International".to_string(),
        };
        assert_eq!(surcharge_for(&parcel, 1499), 0);
    }

    #[test]
    fn rounds_half_up_to_the_cent() {
        assert_eq!(percent_half_up(1499, 20), 300); // 299.8
        assert_eq!(percent_half_up(1, 20), 0); // 0.2
        assert_eq!(percent_half_up(3, 20), 1); // 0.6
        assert_eq!(percent_half_up(25, 20), 5); // 5.0
        assert_eq!(percent_half_up(0, 20), 0);
    }

    #[test]
    fn errors_describe_themselves() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 7 }.to_string(),
            "malformed rate card at line 7"
        );
        assert_eq!(QuoteError::UnknownZone("lunar".to_string()).to_string(), "unknown zone: lunar");
        assert_eq!(
            QuoteError::Overweight {
                grams: 21_000,
                limit: 20_000
            }
            .to_string(),
            "parcel of 21000 g exceeds the 20000 g limit for its zone"
        );
    }

    #[test]
    fn quote_error_is_a_std_error() {
        let error: Box<dyn Error> = Box::new(QuoteError::RateCardUnavailable);
        assert_eq!(error.to_string(), "rate card unavailable");
    }
}
