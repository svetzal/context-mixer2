//! Diagnostic records emitted for every quote.
//!
//! Operations needs to see what the warehouse priced, so [`crate::quote`] emits
//! one [`QuoteRecord`] per call. By default records go to stderr; tests (and
//! embedders that want structured output) can intercept them with [`capture`].

use std::cell::RefCell;
use std::fmt;

/// What a quote call produced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Outcome {
    Quoted { total_cents: u64 },
    Failed { reason: String },
}

/// One quote, as observed from the outside.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct QuoteRecord {
    pub zone: String,
    pub weight_grams: u32,
    pub outcome: Outcome,
}

impl fmt::Display for QuoteRecord {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "ratecard quote zone={} weight_grams={}", self.zone, self.weight_grams)?;
        match &self.outcome {
            Outcome::Quoted { total_cents } => write!(f, " total_cents={total_cents}"),
            Outcome::Failed { reason } => write!(f, " total_cents=- error=\"{reason}\""),
        }
    }
}

thread_local! {
    static CAPTURED: RefCell<Option<Vec<QuoteRecord>>> = const { RefCell::new(None) };
}

pub(crate) fn emit(record: &QuoteRecord) {
    let intercepted = CAPTURED.with(|slot| match slot.borrow_mut().as_mut() {
        Some(records) => {
            records.push(record.clone());
            true
        }
        None => false,
    });
    if !intercepted {
        eprintln!("{record}");
    }
}

/// Run `f` with this thread's diagnostics collected instead of written to
/// stderr, returning its value alongside the records it produced.
///
/// Not reentrant: a nested `capture` takes over the outer one's records.
pub fn capture<T>(f: impl FnOnce() -> T) -> (T, Vec<QuoteRecord>) {
    CAPTURED.with(|slot| *slot.borrow_mut() = Some(Vec::new()));
    let value = f();
    let records = CAPTURED.with(|slot| slot.borrow_mut().take()).unwrap_or_default();
    (value, records)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn displays_a_priced_quote() {
        let record = QuoteRecord {
            zone: "domestic".to_string(),
            weight_grams: 750,
            outcome: Outcome::Quoted { total_cents: 899 },
        };
        assert_eq!(
            record.to_string(),
            "ratecard quote zone=domestic weight_grams=750 total_cents=899"
        );
    }

    #[test]
    fn displays_a_failed_quote() {
        let record = QuoteRecord {
            zone: "lunar".to_string(),
            weight_grams: 10,
            outcome: Outcome::Failed {
                reason: "unknown zone: lunar".to_string(),
            },
        };
        assert_eq!(
            record.to_string(),
            "ratecard quote zone=lunar weight_grams=10 total_cents=- error=\"unknown zone: lunar\""
        );
    }

    #[test]
    fn capture_collects_records_and_returns_the_value() {
        let record = QuoteRecord {
            zone: "domestic".to_string(),
            weight_grams: 1,
            outcome: Outcome::Quoted { total_cents: 599 },
        };
        let (value, records) = capture(|| {
            emit(&record);
            42
        });
        assert_eq!(value, 42);
        assert_eq!(records, vec![record]);
    }

    #[test]
    fn capture_stops_at_its_own_boundary() {
        let record = QuoteRecord {
            zone: "domestic".to_string(),
            weight_grams: 1,
            outcome: Outcome::Quoted { total_cents: 599 },
        };
        let (_, first) = capture(|| emit(&record));
        assert_eq!(first.len(), 1);
        let (_, second) = capture(|| ());
        assert!(second.is_empty());
    }
}
