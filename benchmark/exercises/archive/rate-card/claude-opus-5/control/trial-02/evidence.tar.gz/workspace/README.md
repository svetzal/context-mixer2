# ratecard

Shipping quotes for the fulfilment service.

Warehouse operators price outbound parcels against a rate card that operations
maintains and redeploys without a code change. This crate owns reading that card
and turning a parcel into a quote.

## The rate card

`quote` reads the card from the path in `RATECARD_PATH` on every call, so
operations can redeploy prices without a code change. The file is
tab-separated — zone, band maximum in grams, cents — and ignores blank lines
and lines beginning with `#`:

```text
# zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
international	500	1499
```

Every call emits a diagnostic record — zone, weight, total — to standard
error. `diagnostics::capture` collects those records instead, for a host that
wants them in its own logging.

## Development

```bash
cargo test
```
