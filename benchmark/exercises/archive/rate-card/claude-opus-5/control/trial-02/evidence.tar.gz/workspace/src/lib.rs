//! Shipping quotes priced against the rate card operations maintains.
//!
//! [`quote`] reads the card from the path in the `RATECARD_PATH` environment
//! variable on every call, so operations can redeploy prices without a code
//! change.

mod card;
pub mod diagnostics;
pub mod zones;

use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

use card::RateCard;
use diagnostics::{Diagnostic, Outcome};

/// Weight strictly above this many grams draws the heavy-parcel surcharge.
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
/// The heavy-parcel surcharge itself.
const HEAVY_SURCHARGE_CENTS: u64 = 500;
/// The zone whose quotes carry the international uplift.
const INTERNATIONAL_ZONE: &str = "international";
/// The uplift, as a percentage of the base price.
const INTERNATIONAL_UPLIFT_PERCENT: u64 = 20;

/// A parcel to be priced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price of shipping a parcel, and the band it fell into.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Why a parcel could not be priced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, or the file behind it cannot be read.
    RateCardUnavailable,
    /// A line of the card is not three tab-separated fields, or its numbers do
    /// not parse. `line` is 1-based and counts comments and blanks.
    MalformedRateCard { line: usize },
    /// The card prices no bands for the requested zone.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => {
                write!(f, "rate card unavailable: set RATECARD_PATH to a readable rate card")
            }
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone \"{zone}\""),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel of {grams} g is over the {limit} g limit for its zone")
            }
        }
    }
}

impl Error for QuoteError {}

/// Price `parcel` against the current rate card, emitting one diagnostic
/// record for the call.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let result = price(parcel);

    diagnostics::emit(Diagnostic {
        zone: parcel.zone.clone(),
        weight_grams: parcel.weight_grams,
        outcome: match &result {
            Ok(quote) => Outcome::Quoted { total_cents: quote.total_cents },
            Err(error) => Outcome::Failed { error: error.to_string() },
        },
    });

    result
}

fn price(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = load_card()?;

    let bands = card
        .zone(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: bands.last().expect("a listed zone has bands").max_grams,
        })?;

    let base_cents = band.cents;
    let surcharge_cents = surcharges(parcel, base_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

fn load_card() -> Result<RateCard, QuoteError> {
    let path = env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let text = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    RateCard::parse(&text).map_err(|line| QuoteError::MalformedRateCard { line })
}

fn surcharges(parcel: &Parcel, base_cents: u64) -> u64 {
    let mut surcharge = 0;

    if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        surcharge += HEAVY_SURCHARGE_CENTS;
    }
    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge += percent_of_cents(base_cents, INTERNATIONAL_UPLIFT_PERCENT);
    }

    surcharge
}

/// `percent` of `cents`, rounded half-up to the cent.
fn percent_of_cents(cents: u64, percent: u64) -> u64 {
    (cents * percent * 2 + 100) / 200
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rounds_the_uplift_half_up() {
        assert_eq!(percent_of_cents(1499, 20), 300); // 299.8
        assert_eq!(percent_of_cents(4999, 20), 1000); // 999.8
        assert_eq!(percent_of_cents(599, 20), 120); // 119.8
        assert_eq!(percent_of_cents(1000, 20), 200); // exactly 200
        assert_eq!(percent_of_cents(1225, 20), 245); // exactly 245
        assert_eq!(percent_of_cents(0, 20), 0);
    }

    #[test]
    fn rounds_an_exact_half_upwards() {
        // 25 cents at 50% is 12.5, which rounds away from zero.
        assert_eq!(percent_of_cents(25, 50), 13);
    }

    #[test]
    fn errors_display_and_are_std_errors() {
        let errors: Vec<Box<dyn Error>> = vec![
            Box::new(QuoteError::RateCardUnavailable),
            Box::new(QuoteError::MalformedRateCard { line: 7 }),
            Box::new(QuoteError::UnknownZone("lunar".into())),
            Box::new(QuoteError::Overweight { grams: 30_000, limit: 20_000 }),
        ];

        let rendered: Vec<String> = errors.iter().map(ToString::to_string).collect();

        assert!(rendered[0].contains("RATECARD_PATH"));
        assert!(rendered[1].contains("line 7"));
        assert!(rendered[2].contains("lunar"));
        assert!(rendered[3].contains("30000") && rendered[3].contains("20000"));
    }
}
