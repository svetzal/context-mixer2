//! End-to-end quoting against a rate card on disk.

use std::env;
use std::io::Write;
use std::sync::{Mutex, MutexGuard, OnceLock};

use ratecard::diagnostics::{self, Outcome};
use ratecard::{quote, Parcel, Quote, QuoteError};

const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

/// `RATECARD_PATH` is process-wide, so tests that set it take turns.
fn env_lock() -> MutexGuard<'static, ()> {
    static LOCK: OnceLock<Mutex<()>> = OnceLock::new();

    LOCK.get_or_init(|| Mutex::new(()))
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
}

/// Run `f` with `RATECARD_PATH` pointing at a card holding `text`.
fn with_card<T>(text: &str, f: impl FnOnce() -> T) -> T {
    let _guard = env_lock();

    let mut file = tempfile::NamedTempFile::new().expect("temp file");
    file.write_all(text.as_bytes()).expect("write card");
    file.flush().expect("flush card");

    let previous = env::var_os("RATECARD_PATH");
    env::set_var("RATECARD_PATH", file.path());
    let outcome = f();
    restore(previous);

    outcome
}

/// Run `f` with `RATECARD_PATH` set to `path`, which need not exist.
fn with_card_path<T>(path: Option<&str>, f: impl FnOnce() -> T) -> T {
    let _guard = env_lock();

    let previous = env::var_os("RATECARD_PATH");
    match path {
        Some(path) => env::set_var("RATECARD_PATH", path),
        None => env::remove_var("RATECARD_PATH"),
    }
    let outcome = f();
    restore(previous);

    outcome
}

fn restore(previous: Option<std::ffi::OsString>) {
    match previous {
        Some(value) => env::set_var("RATECARD_PATH", value),
        None => env::remove_var("RATECARD_PATH"),
    }
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel { weight_grams, zone: zone.to_string() }
}

fn quoted(weight_grams: u32, zone: &str) -> Quote {
    with_card(CARD, || quote(&parcel(weight_grams, zone))).expect("quotes")
}

fn refused(weight_grams: u32, zone: &str) -> QuoteError {
    with_card(CARD, || quote(&parcel(weight_grams, zone))).expect_err("refuses")
}

#[test]
fn prices_the_first_band_that_covers_the_weight() {
    let quote = quoted(300, "domestic");

    assert_eq!(
        quote,
        Quote { base_cents: 599, surcharge_cents: 0, total_cents: 599, band_max_grams: 500 }
    );
}

#[test]
fn a_weight_equal_to_the_band_maximum_stays_in_that_band() {
    let quote = quoted(500, "domestic");

    assert_eq!(quote.base_cents, 599);
    assert_eq!(quote.band_max_grams, 500);
}

#[test]
fn a_weight_one_gram_over_moves_up_a_band() {
    let quote = quoted(501, "domestic");

    assert_eq!(quote.base_cents, 899);
    assert_eq!(quote.band_max_grams, 2000);
}

#[test]
fn a_weightless_parcel_falls_into_the_smallest_band() {
    let quote = quoted(0, "domestic");

    assert_eq!(quote.base_cents, 599);
    assert_eq!(quote.band_max_grams, 500);
}

#[test]
fn weight_above_ten_kilos_adds_the_heavy_surcharge() {
    let quote = quoted(10_001, "domestic");

    assert_eq!(
        quote,
        Quote {
            base_cents: 1799,
            surcharge_cents: 500,
            total_cents: 2299,
            band_max_grams: 20_000,
        }
    );
}

#[test]
fn exactly_ten_kilos_is_not_heavy() {
    let quote = quoted(10_000, "domestic");

    assert_eq!(quote.surcharge_cents, 0);
    assert_eq!(quote.total_cents, 1799);
}

#[test]
fn international_adds_a_fifth_of_the_base_rounded_half_up() {
    // 20% of 1499 is 299.8.
    let quote = quoted(400, "international");

    assert_eq!(
        quote,
        Quote {
            base_cents: 1499,
            surcharge_cents: 300,
            total_cents: 1799,
            band_max_grams: 500,
        }
    );
}

#[test]
fn surcharges_add_together() {
    // 20% of 4999 is 999.8, plus 500 for weight.
    let quote = quoted(15_000, "international");

    assert_eq!(
        quote,
        Quote {
            base_cents: 4999,
            surcharge_cents: 1500,
            total_cents: 6499,
            band_max_grams: 20_000,
        }
    );
}

#[test]
fn an_unlisted_zone_is_refused_by_name() {
    assert_eq!(refused(300, "lunar"), QuoteError::UnknownZone("lunar".to_string()));
}

#[test]
fn a_parcel_over_the_largest_band_is_overweight() {
    assert_eq!(
        refused(25_000, "domestic"),
        QuoteError::Overweight { grams: 25_000, limit: 20_000 }
    );
}

#[test]
fn the_overweight_limit_is_the_zones_own_largest_band() {
    let card = "domestic\t20000\t1799\ninternational\t500\t1499\n";
    let error = with_card(card, || quote(&parcel(600, "international"))).expect_err("refuses");

    assert_eq!(error, QuoteError::Overweight { grams: 600, limit: 500 });
}

#[test]
fn an_unset_path_leaves_the_card_unavailable() {
    let error = with_card_path(None, || quote(&parcel(300, "domestic"))).expect_err("refuses");

    assert_eq!(error, QuoteError::RateCardUnavailable);
}

#[test]
fn a_missing_file_leaves_the_card_unavailable() {
    let error = with_card_path(Some("/nonexistent/ratecard.tsv"), || {
        quote(&parcel(300, "domestic"))
    })
    .expect_err("refuses");

    assert_eq!(error, QuoteError::RateCardUnavailable);
}

#[test]
fn a_malformed_line_is_reported_by_its_file_line_number() {
    let card = "# zone\tband_max_grams\tcents\n\ndomestic\t500\t599\ndomestic\t2000\n";
    let error = with_card(card, || quote(&parcel(300, "domestic"))).expect_err("refuses");

    assert_eq!(error, QuoteError::MalformedRateCard { line: 4 });
}

#[test]
fn an_unparseable_number_is_malformed() {
    let card = "domestic\t500\tfree\n";
    let error = with_card(card, || quote(&parcel(300, "domestic"))).expect_err("refuses");

    assert_eq!(error, QuoteError::MalformedRateCard { line: 1 });
}

#[test]
fn a_malformed_line_is_reported_even_for_an_unrelated_zone() {
    let card = "domestic\t500\t599\ninternational\tbroken\t1499\n";
    let error = with_card(card, || quote(&parcel(300, "domestic"))).expect_err("refuses");

    assert_eq!(error, QuoteError::MalformedRateCard { line: 2 });
}

#[test]
fn an_empty_card_knows_no_zones() {
    let error = with_card("# nothing priced yet\n", || quote(&parcel(300, "domestic")))
        .expect_err("refuses");

    assert_eq!(error, QuoteError::UnknownZone("domestic".to_string()));
}

#[test]
fn a_priced_quote_emits_a_diagnostic_record() {
    let (result, records) =
        diagnostics::capture(|| with_card(CARD, || quote(&parcel(15_000, "international"))));

    let quote = result.expect("quotes");
    assert_eq!(records.len(), 1);
    assert_eq!(records[0].zone, "international");
    assert_eq!(records[0].weight_grams, 15_000);
    assert_eq!(records[0].outcome, Outcome::Quoted { total_cents: quote.total_cents });
}

#[test]
fn a_refused_quote_still_emits_a_diagnostic_record() {
    let (result, records) =
        diagnostics::capture(|| with_card(CARD, || quote(&parcel(300, "lunar"))));

    assert!(result.is_err());
    assert_eq!(records.len(), 1);
    assert_eq!(records[0].zone, "lunar");
    assert_eq!(records[0].weight_grams, 300);
    assert!(matches!(records[0].outcome, Outcome::Failed { .. }));
}

#[test]
fn every_call_is_recorded() {
    let (_, records) = diagnostics::capture(|| {
        with_card(CARD, || {
            let _ = quote(&parcel(300, "domestic"));
            let _ = quote(&parcel(300, "domestic"));
        })
    });

    assert_eq!(records.len(), 2);
}

#[test]
fn a_record_renders_zone_weight_and_total() {
    let (_, records) =
        diagnostics::capture(|| with_card(CARD, || quote(&parcel(750, "domestic"))));

    let rendered = records[0].to_string();

    assert!(rendered.contains("domestic"), "{rendered}");
    assert!(rendered.contains("750"), "{rendered}");
    assert!(rendered.contains("899"), "{rendered}");
}

#[test]
fn the_card_is_reread_on_every_call() {
    let cheap = with_card("domestic\t500\t599\n", || quote(&parcel(300, "domestic")))
        .expect("quotes");
    let dear = with_card("domestic\t500\t699\n", || quote(&parcel(300, "domestic")))
        .expect("quotes");

    assert_eq!(cheap.base_cents, 599);
    assert_eq!(dear.base_cents, 699);
}
