//! Parsing and lookup for the tab-separated rate card operations maintains.

use std::collections::BTreeMap;

/// One priced band: parcels up to `max_grams` cost `cents`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct Band {
    pub(crate) max_grams: u32,
    pub(crate) cents: u64,
}

/// The bands of every zone in a rate card, each zone ordered ascending by
/// `max_grams`.
#[derive(Debug, Default)]
pub(crate) struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

impl RateCard {
    /// Parse a rate card. On failure the error is the 1-based number of the
    /// offending line, counting comments and blanks.
    pub(crate) fn parse(text: &str) -> Result<Self, usize> {
        let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

        for (index, raw) in text.lines().enumerate() {
            let line = raw.trim_end_matches('\r');
            if line.trim().is_empty() || line.trim_start().starts_with('#') {
                continue;
            }

            let line_number = index + 1;
            let mut fields = line.split('\t');
            let (Some(zone), Some(max_grams), Some(cents), None) = (
                fields.next(),
                fields.next(),
                fields.next(),
                fields.next(),
            ) else {
                return Err(line_number);
            };

            let max_grams: u32 = max_grams.trim().parse().map_err(|_| line_number)?;
            let cents: u64 = cents.trim().parse().map_err(|_| line_number)?;

            zones
                .entry(zone.trim().to_string())
                .or_default()
                .push(Band { max_grams, cents });
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(Self { zones })
    }

    /// The bands priced for `zone`, or `None` when the card does not carry it.
    /// A returned slice is never empty.
    pub(crate) fn zone(&self, zone: &str) -> Option<&[Band]> {
        self.zones.get(zone).map(Vec::as_slice)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
                          domestic\t500\t599\n\
                          domestic\t2000\t899\n\
                          \n\
                          international\t500\t1499\n";

    fn bands(card: &RateCard, zone: &str) -> Vec<Band> {
        card.zone(zone).expect("zone present").to_vec()
    }

    #[test]
    fn reads_bands_per_zone() {
        let card = RateCard::parse(SAMPLE).expect("parses");

        assert_eq!(
            bands(&card, "domestic"),
            vec![
                Band { max_grams: 500, cents: 599 },
                Band { max_grams: 2000, cents: 899 },
            ]
        );
        assert_eq!(
            bands(&card, "international"),
            vec![Band { max_grams: 500, cents: 1499 }]
        );
    }

    #[test]
    fn skips_comments_and_blank_lines() {
        let card = RateCard::parse("#comment\n\n   \ndomestic\t500\t599\n").expect("parses");

        assert_eq!(card.zone("domestic").map(<[Band]>::len), Some(1));
    }

    #[test]
    fn orders_bands_ascending_regardless_of_file_order() {
        let card =
            RateCard::parse("domestic\t2000\t899\ndomestic\t500\t599\n").expect("parses");

        assert_eq!(
            bands(&card, "domestic")
                .iter()
                .map(|band| band.max_grams)
                .collect::<Vec<_>>(),
            vec![500, 2000]
        );
    }

    #[test]
    fn absent_zone_is_none() {
        let card = RateCard::parse(SAMPLE).expect("parses");

        assert!(card.zone("lunar").is_none());
    }

    #[test]
    fn reports_the_line_with_too_few_fields() {
        let err = RateCard::parse("#header\ndomestic\t500\n").expect_err("rejects");

        assert_eq!(err, 2);
    }

    #[test]
    fn reports_the_line_with_too_many_fields() {
        let err = RateCard::parse("domestic\t500\t599\textra\n").expect_err("rejects");

        assert_eq!(err, 1);
    }

    #[test]
    fn reports_the_line_with_an_unparseable_number() {
        let err = RateCard::parse("domestic\t500\t599\ndomestic\theavy\t899\n")
            .expect_err("rejects");

        assert_eq!(err, 2);
    }

    #[test]
    fn reports_the_line_with_a_negative_number() {
        let err = RateCard::parse("domestic\t-500\t599\n").expect_err("rejects");

        assert_eq!(err, 1);
    }

    #[test]
    fn counts_comments_and_blanks_towards_the_line_number() {
        let err = RateCard::parse("# zone\tband\tcents\n\n\nbroken\n").expect_err("rejects");

        assert_eq!(err, 4);
    }

    #[test]
    fn tolerates_carriage_returns() {
        let card = RateCard::parse("domestic\t500\t599\r\n").expect("parses");

        assert_eq!(
            bands(&card, "domestic"),
            vec![Band { max_grams: 500, cents: 599 }]
        );
    }
}
