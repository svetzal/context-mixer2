//! One diagnostic record per quote, so pricing is observable in operation.
//!
//! Records go to standard error by default. Callers that want to inspect them —
//! tests, or a host wiring quotes into its own logging — run the work inside
//! [`capture`].

use std::cell::RefCell;
use std::fmt;

use crate::zones::zone_label;

/// What a quote call did.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Outcome {
    Quoted { total_cents: u64 },
    Failed { error: String },
}

/// The record emitted for a single quote call.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Diagnostic {
    pub zone: String,
    pub weight_grams: u32,
    pub outcome: Outcome,
}

impl fmt::Display for Diagnostic {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "ratecard quote zone={} ({}) weight_grams={}",
            self.zone,
            zone_label(&self.zone),
            self.weight_grams
        )?;
        match &self.outcome {
            Outcome::Quoted { total_cents } => write!(f, " total_cents={total_cents}"),
            Outcome::Failed { error } => write!(f, " error={error}"),
        }
    }
}

thread_local! {
    static SINK: RefCell<Option<Vec<Diagnostic>>> = const { RefCell::new(None) };
}

/// Emit one record: into the active capture if there is one, otherwise to
/// standard error.
pub(crate) fn emit(record: Diagnostic) {
    let captured = SINK.with(|sink| match sink.borrow_mut().as_mut() {
        Some(records) => {
            records.push(record.clone());
            true
        }
        None => false,
    });

    if !captured {
        eprintln!("{record}");
    }
}

/// Run `f`, collecting the diagnostics it emits on this thread instead of
/// writing them to standard error.
pub fn capture<T>(f: impl FnOnce() -> T) -> (T, Vec<Diagnostic>) {
    let previous = SINK.with(|sink| sink.replace(Some(Vec::new())));
    let value = f();
    let records = SINK.with(|sink| sink.replace(previous));

    (value, records.unwrap_or_default())
}
