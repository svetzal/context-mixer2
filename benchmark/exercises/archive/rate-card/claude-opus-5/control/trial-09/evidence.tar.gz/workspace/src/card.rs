//! Reading the rate card operations maintains.
//!
//! The card is tab-separated, one band per line: zone, band_max_grams, cents.
//! Blank lines and comments are skipped, but they still count towards the line
//! numbers reported for malformed lines.

use std::collections::HashMap;

/// One priced weight band within a zone.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct Band {
    pub(crate) max_grams: u32,
    pub(crate) cents: u64,
}

/// A line the card parser could not make sense of, by 1-based line number.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct MalformedLine {
    pub(crate) line: usize,
}

/// The bands of every zone on the card, each zone's bands held in ascending
/// order of `max_grams`.
#[derive(Debug, Default, Clone)]
pub(crate) struct RateCard {
    zones: HashMap<String, Vec<Band>>,
}

impl RateCard {
    /// Parse a whole card, rejecting it outright on the first line that is not
    /// three tab-separated fields with numbers that parse.
    pub(crate) fn parse(text: &str) -> Result<Self, MalformedLine> {
        let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

        for (offset, line) in text.lines().enumerate() {
            let number = offset + 1;
            if is_ignorable(line) {
                continue;
            }
            let (zone, band) = parse_band(line).ok_or(MalformedLine { line: number })?;
            zones.entry(zone.to_owned()).or_default().push(band);
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(Self { zones })
    }

    /// The bands priced for `zone`, ascending, or `None` when the card says
    /// nothing about that zone.
    pub(crate) fn bands(&self, zone: &str) -> Option<&[Band]> {
        self.zones
            .get(zone)
            .map(Vec::as_slice)
            .filter(|bands| !bands.is_empty())
    }
}

fn is_ignorable(line: &str) -> bool {
    let trimmed = line.trim();
    trimmed.is_empty() || trimmed.starts_with('#')
}

fn parse_band(line: &str) -> Option<(&str, Band)> {
    let mut fields = line.split('\t');
    let zone = fields.next()?.trim();
    let max_grams = fields.next()?.trim();
    let cents = fields.next()?.trim();
    if fields.next().is_some() {
        return None;
    }

    Some((
        zone,
        Band {
            max_grams: max_grams.parse().ok()?,
            cents: cents.parse().ok()?,
        },
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799

international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn reads_every_band_of_a_zone_in_ascending_order() {
        let card = RateCard::parse(SAMPLE).expect("sample card parses");

        assert_eq!(
            card.bands("domestic"),
            Some(
                [
                    Band { max_grams: 500, cents: 599 },
                    Band { max_grams: 2000, cents: 899 },
                    Band { max_grams: 20000, cents: 1799 },
                ]
                .as_slice()
            )
        );
    }

    #[test]
    fn orders_bands_ascending_however_the_card_lists_them() {
        let card = RateCard::parse("domestic\t20000\t1799\ndomestic\t500\t599\n")
            .expect("unordered card parses");

        let maxima: Vec<u32> = card
            .bands("domestic")
            .expect("domestic is priced")
            .iter()
            .map(|band| band.max_grams)
            .collect();
        assert_eq!(maxima, vec![500, 20000]);
    }

    #[test]
    fn says_nothing_about_a_zone_the_card_omits() {
        let card = RateCard::parse(SAMPLE).expect("sample card parses");

        assert_eq!(card.bands("lunar"), None);
    }

    #[test]
    fn skips_comments_and_blank_lines() {
        let card = RateCard::parse("\n# a comment\n   \ndomestic\t500\t599\n")
            .expect("decorated card parses");

        assert_eq!(
            card.bands("domestic"),
            Some([Band { max_grams: 500, cents: 599 }].as_slice())
        );
    }

    #[test]
    fn counts_comments_and_blanks_when_numbering_a_malformed_line() {
        // The offending line is the fourth in the file, two of which are skipped.
        let card = RateCard::parse("# header\n\ndomestic\t500\t599\ndomestic\t2000\n");

        assert_eq!(card.unwrap_err(), MalformedLine { line: 4 });
    }

    #[test]
    fn rejects_a_line_with_too_few_fields() {
        assert_eq!(
            RateCard::parse("domestic\t500").unwrap_err(),
            MalformedLine { line: 1 }
        );
    }

    #[test]
    fn rejects_a_line_with_too_many_fields() {
        assert_eq!(
            RateCard::parse("domestic\t500\t599\textra").unwrap_err(),
            MalformedLine { line: 1 }
        );
    }

    #[test]
    fn rejects_a_line_split_by_something_other_than_tabs() {
        assert_eq!(
            RateCard::parse("domestic 500 599").unwrap_err(),
            MalformedLine { line: 1 }
        );
    }

    #[test]
    fn rejects_a_band_maximum_that_is_not_a_number() {
        assert_eq!(
            RateCard::parse("domestic\theavy\t599").unwrap_err(),
            MalformedLine { line: 1 }
        );
    }

    #[test]
    fn rejects_a_price_that_is_not_a_number() {
        assert_eq!(
            RateCard::parse("domestic\t500\t5.99").unwrap_err(),
            MalformedLine { line: 1 }
        );
    }

    #[test]
    fn rejects_a_malformed_line_even_in_a_zone_nobody_asked_about() {
        assert_eq!(
            RateCard::parse("domestic\t500\t599\nlunar\t500\tfree").unwrap_err(),
            MalformedLine { line: 2 }
        );
    }

    #[test]
    fn tolerates_carriage_returns() {
        let card = RateCard::parse("# header\r\ndomestic\t500\t599\r\n").expect("crlf card parses");

        assert_eq!(
            card.bands("domestic"),
            Some([Band { max_grams: 500, cents: 599 }].as_slice())
        );
    }

    #[test]
    fn an_empty_card_prices_nothing() {
        let card = RateCard::parse("").expect("empty card parses");

        assert_eq!(card.bands("domestic"), None);
    }
}
