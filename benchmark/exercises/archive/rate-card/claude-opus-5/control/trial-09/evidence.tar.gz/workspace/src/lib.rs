//! Shipping quotes for the fulfilment service.
//!
//! A parcel is priced against the rate card operations maintains, found at the
//! path in the `RATECARD_PATH` environment variable. The card is read afresh on
//! every quote, so a redeployed card takes effect without a restart.

mod card;
mod diagnostics;
mod pricing;
pub mod zones;

use std::env;
use std::fmt;
use std::fs;

use card::RateCard;

/// The environment variable naming the rate card to price against.
const RATECARD_PATH_VAR: &str = "RATECARD_PATH";

/// A parcel to be priced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// What a parcel costs to ship, and the band that decided it.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Why a parcel could not be priced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card is missing, unreadable, or its path unset.
    RateCardUnavailable,
    /// A line of the card is not three tab-separated fields with numbers that
    /// parse, given by its 1-based line number.
    MalformedRateCard { line: usize },
    /// The card prices nothing for the requested zone.
    UnknownZone(String),
    /// The parcel outweighs the heaviest band its zone prices.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(
                f,
                "rate card unavailable: set {RATECARD_PATH_VAR} to a readable rate card"
            ),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone {zone:?}"),
            Self::Overweight { grams, limit } => write!(
                f,
                "parcel of {grams} g is over the {limit} g limit for its zone"
            ),
        }
    }
}

impl std::error::Error for QuoteError {}

/// Price `parcel` against the current rate card.
///
/// Every call leaves a diagnostic record on stderr, whether or not it priced.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let outcome = price(parcel);
    diagnostics::record(parcel, &outcome);
    outcome
}

fn price(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = RateCard::parse(&read_rate_card()?)
        .map_err(|fault| QuoteError::MalformedRateCard { line: fault.line })?;

    let bands = card
        .bands(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = pricing::matching_band(bands, parcel.weight_grams).ok_or_else(|| {
        QuoteError::Overweight {
            grams: parcel.weight_grams,
            // A zone is only ever held with at least one band, so the heaviest
            // exists whenever a parcel can outweigh it.
            limit: pricing::heaviest_band(bands).map_or(0, |heaviest| heaviest.max_grams),
        }
    })?;

    let base_cents = band.cents;
    let surcharge_cents = pricing::surcharge_cents(&parcel.zone, parcel.weight_grams, base_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

fn read_rate_card() -> Result<String, QuoteError> {
    let path = env::var(RATECARD_PATH_VAR).map_err(|_| QuoteError::RateCardUnavailable)?;
    fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)
}

#[cfg(test)]
mod tests {
    use std::io::Write;
    use std::sync::{Mutex, MutexGuard, OnceLock};

    use tempfile::NamedTempFile;

    use super::*;

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    /// `RATECARD_PATH` is process-wide, so tests that set it take turns.
    fn env_lock() -> MutexGuard<'static, ()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
    }

    /// Quote against `card`, with the environment held for the call.
    fn quote_against(card: &str, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let _guard = env_lock();
        let mut file = NamedTempFile::new().expect("temp file");
        file.write_all(card.as_bytes()).expect("write card");
        file.flush().expect("flush card");

        env::set_var(RATECARD_PATH_VAR, file.path());
        let outcome = quote(parcel);
        env::remove_var(RATECARD_PATH_VAR);
        outcome
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel { weight_grams, zone: zone.to_owned() }
    }

    #[test]
    fn prices_a_domestic_parcel_from_its_band() {
        let quote = quote_against(CARD, &parcel(750, "domestic")).expect("priced");

        assert_eq!(
            quote,
            Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2000,
            }
        );
    }

    #[test]
    fn a_weight_on_a_band_threshold_stays_in_that_band() {
        let quote = quote_against(CARD, &parcel(500, "domestic")).expect("priced");

        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.total_cents, 599);
    }

    #[test]
    fn adds_the_heavy_surcharge_above_ten_kilos() {
        let quote = quote_against(CARD, &parcel(10_001, "domestic")).expect("priced");

        assert_eq!(
            quote,
            Quote {
                base_cents: 1799,
                surcharge_cents: 500,
                total_cents: 2299,
                band_max_grams: 20000,
            }
        );
    }

    #[test]
    fn ten_kilos_exactly_carries_no_heavy_surcharge() {
        let quote = quote_against(CARD, &parcel(10_000, "domestic")).expect("priced");

        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn adds_a_fifth_of_the_base_for_international() {
        let quote = quote_against(CARD, &parcel(400, "international")).expect("priced");

        assert_eq!(
            quote,
            Quote {
                base_cents: 1499,
                surcharge_cents: 300,
                total_cents: 1799,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn a_heavy_international_parcel_pays_both_surcharges() {
        let quote = quote_against(CARD, &parcel(15_000, "international")).expect("priced");

        assert_eq!(
            quote,
            Quote {
                base_cents: 4999,
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20000,
            }
        );
    }

    #[test]
    fn a_zone_the_card_omits_is_unknown() {
        let error = quote_against(CARD, &parcel(750, "lunar")).unwrap_err();

        assert_eq!(error, QuoteError::UnknownZone("lunar".to_owned()));
    }

    #[test]
    fn a_parcel_past_the_heaviest_band_is_overweight() {
        let error = quote_against(CARD, &parcel(20_001, "domestic")).unwrap_err();

        assert_eq!(error, QuoteError::Overweight { grams: 20_001, limit: 20_000 });
    }

    #[test]
    fn the_overweight_limit_is_the_zones_own_heaviest_band() {
        let card = "domestic\t20000\t1799\nexpress\t1000\t2599\n";

        let error = quote_against(card, &parcel(1_500, "express")).unwrap_err();

        assert_eq!(error, QuoteError::Overweight { grams: 1_500, limit: 1_000 });
    }

    #[test]
    fn a_malformed_line_is_reported_by_its_number_in_the_file() {
        let card = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\n\ndomestic\ttwo\t899\n";

        let error = quote_against(card, &parcel(300, "domestic")).unwrap_err();

        assert_eq!(error, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn a_malformed_card_fails_before_an_unknown_zone_is_considered() {
        let error = quote_against("domestic\t500", &parcel(300, "lunar")).unwrap_err();

        assert_eq!(error, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn an_unset_path_leaves_the_card_unavailable() {
        let _guard = env_lock();
        env::remove_var(RATECARD_PATH_VAR);

        let error = quote(&parcel(750, "domestic")).unwrap_err();

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn a_missing_file_leaves_the_card_unavailable() {
        let _guard = env_lock();
        env::set_var(RATECARD_PATH_VAR, "/nonexistent/directory/ratecard.tsv");

        let error = quote(&parcel(750, "domestic")).unwrap_err();
        env::remove_var(RATECARD_PATH_VAR);

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn an_unreadable_card_is_unavailable() {
        let _guard = env_lock();
        let directory = tempfile::tempdir().expect("temp dir");
        // A directory can be named but not read as a card.
        env::set_var(RATECARD_PATH_VAR, directory.path());

        let error = quote(&parcel(750, "domestic")).unwrap_err();
        env::remove_var(RATECARD_PATH_VAR);

        assert_eq!(error, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn an_empty_card_knows_no_zones() {
        let error = quote_against("", &parcel(750, "domestic")).unwrap_err();

        assert_eq!(error, QuoteError::UnknownZone("domestic".to_owned()));
    }

    #[test]
    fn a_redeployed_card_prices_the_next_parcel() {
        let dearer = "domestic\t2000\t999\n";

        assert_eq!(
            quote_against(CARD, &parcel(750, "domestic")).expect("priced").total_cents,
            899
        );
        assert_eq!(
            quote_against(dearer, &parcel(750, "domestic")).expect("priced").total_cents,
            999
        );
    }

    #[test]
    fn every_failure_reads_as_a_sentence() {
        let cases = [
            QuoteError::RateCardUnavailable,
            QuoteError::MalformedRateCard { line: 4 },
            QuoteError::UnknownZone("lunar".to_owned()),
            QuoteError::Overweight { grams: 20_001, limit: 20_000 },
        ];

        for case in cases {
            assert!(!case.to_string().is_empty(), "{case:?} says nothing");
        }

        assert_eq!(
            QuoteError::MalformedRateCard { line: 4 }.to_string(),
            "malformed rate card at line 4"
        );
    }

    #[test]
    fn a_failure_is_a_std_error() {
        fn as_error(error: QuoteError) -> Box<dyn std::error::Error> {
            Box::new(error)
        }

        assert_eq!(
            as_error(QuoteError::UnknownZone("lunar".to_owned())).to_string(),
            "unknown zone \"lunar\""
        );
    }
}
