//! Making each quote observable in operation.
//!
//! Every call to [`crate::quote`] leaves one record on stderr naming the zone,
//! the weight asked about, and what the caller was told.

use crate::{Parcel, Quote, QuoteError};

/// Emit the record for one quote call.
pub(crate) fn record(parcel: &Parcel, outcome: &Result<Quote, QuoteError>) {
    eprintln!("{}", render(parcel, outcome));
}

/// The record's text: field-per-key, so an operator can grep it and a log
/// shipper can split it.
fn render(parcel: &Parcel, outcome: &Result<Quote, QuoteError>) -> String {
    let head = format!(
        "ratecard.quote zone={:?} weight_grams={}",
        parcel.zone, parcel.weight_grams
    );

    match outcome {
        Ok(quote) => format!(
            "{head} total_cents={} base_cents={} surcharge_cents={} band_max_grams={}",
            quote.total_cents, quote.base_cents, quote.surcharge_cents, quote.band_max_grams
        ),
        Err(error) => format!("{head} total_cents=none error={error}"),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn parcel() -> Parcel {
        Parcel { weight_grams: 750, zone: "domestic".to_owned() }
    }

    #[test]
    fn a_quoted_parcel_records_zone_weight_and_total() {
        let quoted = Ok(Quote {
            base_cents: 899,
            surcharge_cents: 0,
            total_cents: 899,
            band_max_grams: 2000,
        });

        let line = render(&parcel(), &quoted);

        assert!(line.contains(r#"zone="domestic""#), "{line}");
        assert!(line.contains("weight_grams=750"), "{line}");
        assert!(line.contains("total_cents=899"), "{line}");
    }

    #[test]
    fn a_failed_quote_records_the_reason_in_place_of_a_total() {
        let failed = Err(QuoteError::UnknownZone("lunar".to_owned()));

        let line = render(&parcel(), &failed);

        assert!(line.contains("total_cents=none"), "{line}");
        assert!(line.contains("error=unknown zone \"lunar\""), "{line}");
    }

    #[test]
    fn emitting_a_record_does_not_disturb_the_caller() {
        record(
            &parcel(),
            &Ok(Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2000,
            }),
        );
    }
}
