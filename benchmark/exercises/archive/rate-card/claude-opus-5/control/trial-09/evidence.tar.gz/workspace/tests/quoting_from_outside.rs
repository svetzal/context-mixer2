//! The crate's public surface, used the way a caller outside it uses it.

use std::env;
use std::io::Write;
use std::sync::{Mutex, MutexGuard, OnceLock};

use ratecard::{quote, Parcel, Quote, QuoteError};
use tempfile::NamedTempFile;

const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

/// `RATECARD_PATH` is process-wide, so tests that set it take turns.
fn env_lock() -> MutexGuard<'static, ()> {
    static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    LOCK.get_or_init(|| Mutex::new(()))
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
}

fn quote_against(card: &str, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let _guard = env_lock();
    let mut file = NamedTempFile::new().expect("temp file");
    file.write_all(card.as_bytes()).expect("write card");
    file.flush().expect("flush card");

    env::set_var("RATECARD_PATH", file.path());
    let outcome = quote(parcel);
    env::remove_var("RATECARD_PATH");
    outcome
}

#[test]
fn a_quote_exposes_its_base_surcharge_total_and_band() {
    let parcel = Parcel { weight_grams: 15_000, zone: "international".to_owned() };

    let quote = quote_against(CARD, &parcel).expect("priced");

    assert_eq!(quote.base_cents, 4999);
    assert_eq!(quote.surcharge_cents, 1500);
    assert_eq!(quote.total_cents, 6499);
    assert_eq!(quote.band_max_grams, 20000);
}

#[test]
fn every_failure_can_be_matched_and_read() {
    let overweight = Parcel { weight_grams: 50_000, zone: "domestic".to_owned() };

    let described = match quote_against(CARD, &overweight) {
        Err(QuoteError::Overweight { grams, limit }) => format!("{grams} over {limit}"),
        Err(QuoteError::UnknownZone(zone)) => zone,
        Err(other) => other.to_string(),
        Ok(quote) => panic!("unexpectedly priced at {} cents", quote.total_cents),
    };

    assert_eq!(described, "50000 over 20000");
}

#[test]
fn a_failure_travels_as_a_boxed_std_error() {
    let unknown = Parcel { weight_grams: 750, zone: "lunar".to_owned() };

    let error: Box<dyn std::error::Error> = Box::new(quote_against(CARD, &unknown).unwrap_err());

    assert!(error.to_string().contains("lunar"), "{error}");
}
