//! Turning a matched band into money.

use crate::card::Band;

/// Weight strictly above this attracts the heavy-parcel surcharge.
const HEAVY_ABOVE_GRAMS: u32 = 10_000;

/// What a parcel over [`HEAVY_ABOVE_GRAMS`] adds to the quote.
const HEAVY_SURCHARGE_CENTS: u64 = 500;

/// The zone that attracts the international uplift.
const INTERNATIONAL_ZONE: &str = "international";

/// The international uplift, as a percentage of the base price.
const INTERNATIONAL_UPLIFT_PERCENT: u64 = 20;

/// The band a parcel of `grams` falls in: the first, ascending, whose maximum
/// reaches the weight. `None` means the parcel outweighs the whole zone.
pub(crate) fn matching_band(bands: &[Band], grams: u32) -> Option<Band> {
    bands.iter().copied().find(|band| band.max_grams >= grams)
}

/// The heaviest band the zone prices, which is the limit an overweight parcel
/// is reported against.
pub(crate) fn heaviest_band(bands: &[Band]) -> Option<Band> {
    bands.last().copied()
}

/// Every surcharge the parcel attracts, added together.
pub(crate) fn surcharge_cents(zone: &str, grams: u32, base_cents: u64) -> u64 {
    let heavy = if grams > HEAVY_ABOVE_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    };

    let international = if zone == INTERNATIONAL_ZONE {
        percent_of(base_cents, INTERNATIONAL_UPLIFT_PERCENT)
    } else {
        0
    };

    heavy + international
}

/// `percent` of `cents`, rounded half-up to the whole cent.
fn percent_of(cents: u64, percent: u64) -> u64 {
    (cents * percent + 50) / 100
}

#[cfg(test)]
mod tests {
    use super::*;

    fn bands() -> Vec<Band> {
        vec![
            Band { max_grams: 500, cents: 599 },
            Band { max_grams: 2000, cents: 899 },
            Band { max_grams: 20000, cents: 1799 },
        ]
    }

    #[test]
    fn matches_the_first_band_that_reaches_the_weight() {
        assert_eq!(matching_band(&bands(), 750).map(|band| band.max_grams), Some(2000));
    }

    #[test]
    fn a_weight_exactly_on_a_threshold_stays_in_that_band() {
        assert_eq!(matching_band(&bands(), 500).map(|band| band.max_grams), Some(500));
    }

    #[test]
    fn a_gram_over_a_threshold_moves_up_a_band() {
        assert_eq!(matching_band(&bands(), 501).map(|band| band.max_grams), Some(2000));
    }

    #[test]
    fn a_weightless_parcel_falls_in_the_lightest_band() {
        assert_eq!(matching_band(&bands(), 0).map(|band| band.max_grams), Some(500));
    }

    #[test]
    fn no_band_matches_a_parcel_past_the_heaviest() {
        assert_eq!(matching_band(&bands(), 20001), None);
    }

    #[test]
    fn the_heaviest_band_is_the_last_ascending() {
        assert_eq!(heaviest_band(&bands()).map(|band| band.max_grams), Some(20000));
    }

    #[test]
    fn a_light_domestic_parcel_attracts_nothing() {
        assert_eq!(surcharge_cents("domestic", 500, 599), 0);
    }

    #[test]
    fn ten_kilos_exactly_is_not_yet_heavy() {
        assert_eq!(surcharge_cents("domestic", 10_000, 1799), 0);
    }

    #[test]
    fn a_gram_over_ten_kilos_is_heavy() {
        assert_eq!(surcharge_cents("domestic", 10_001, 1799), 500);
    }

    #[test]
    fn international_adds_a_fifth_of_the_base() {
        assert_eq!(surcharge_cents("international", 500, 1499), 300);
    }

    #[test]
    fn a_heavy_international_parcel_pays_both_surcharges() {
        assert_eq!(surcharge_cents("international", 15_000, 4999), 500 + 1000);
    }

    #[test]
    fn rounds_the_uplift_half_up_to_the_cent() {
        // 20% of 599 is 119.8 cents, and of 597 is 119.4.
        assert_eq!(percent_of(599, 20), 120);
        assert_eq!(percent_of(597, 20), 119);
        // 20% of 25 is exactly 5, which must not drift upwards.
        assert_eq!(percent_of(25, 20), 5);
        // A true half lands upwards: 50% of 5 is 2.5.
        assert_eq!(percent_of(5, 50), 3);
    }

    #[test]
    fn an_unrecognised_zone_name_attracts_no_uplift() {
        assert_eq!(surcharge_cents("International", 500, 1499), 0);
    }
}
