# ratecard

Shipping quotes for the fulfilment service.

Warehouse operators price outbound parcels against a rate card that operations
maintains and redeploys without a code change. This crate owns reading that card
and turning a parcel into a quote.

## Configuration

`RATECARD_PATH` names the tab-separated card to price against. It is read on
every quote, so operations can redeploy a card without a restart. Each call
leaves one record on stderr naming the zone, the weight, and what the caller was
told:

```text
ratecard.quote zone="domestic" weight_grams=750 total_cents=899 base_cents=899 surcharge_cents=0 band_max_grams=2000
```

## Development

```bash
cargo test
```
