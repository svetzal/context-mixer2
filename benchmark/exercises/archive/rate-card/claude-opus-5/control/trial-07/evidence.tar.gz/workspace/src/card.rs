//! Reading the rate card operations deploys alongside the service.
//!
//! The card is a tab-separated table of `zone`, `band_max_grams`, `cents`.
//! Blank lines and `#` comments carry no bands but still occupy a line number,
//! so parse errors can point operators at the exact line in their file.

use std::collections::HashMap;
use std::env;
use std::fs;
use std::path::PathBuf;

use crate::QuoteError;

/// Environment variable naming the deployed rate card.
pub const RATECARD_PATH_VAR: &str = "RATECARD_PATH";

/// One priced weight band within a zone.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Band {
    pub max_grams: u32,
    pub cents: u64,
}

/// A parsed rate card: every zone with its bands in ascending weight order.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct RateCard {
    zones: HashMap<String, Vec<Band>>,
}

impl RateCard {
    /// Loads the card named by `RATECARD_PATH`.
    ///
    /// An unset variable, a missing file, or an unreadable one are all the same
    /// operational fault: the service cannot price anything right now.
    pub fn from_env() -> Result<Self, QuoteError> {
        let path = env::var_os(RATECARD_PATH_VAR).ok_or(QuoteError::RateCardUnavailable)?;
        Self::from_path(PathBuf::from(path))
    }

    /// Loads the card at `path`.
    pub fn from_path(path: PathBuf) -> Result<Self, QuoteError> {
        let text = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
        Self::parse(&text)
    }

    /// Parses card text, reporting the 1-based number of the first bad line.
    pub fn parse(text: &str) -> Result<Self, QuoteError> {
        let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

        for (index, raw) in text.lines().enumerate() {
            let line = index + 1;
            let content = raw.trim_end_matches('\r');
            let trimmed = content.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }

            let band = parse_band(content).ok_or(QuoteError::MalformedRateCard { line })?;
            zones.entry(band.0).or_default().push(band.1);
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(Self { zones })
    }

    /// The bands for `zone`, ascending, or `None` when the card omits the zone.
    pub fn bands(&self, zone: &str) -> Option<&[Band]> {
        self.zones.get(zone).map(|bands| bands.as_slice())
    }
}

/// Splits one non-comment line into its zone and band, or `None` if malformed.
fn parse_band(content: &str) -> Option<(String, Band)> {
    let mut fields = content.split('\t');
    let zone = fields.next()?.trim();
    let max_grams = fields.next()?.trim();
    let cents = fields.next()?.trim();
    if fields.next().is_some() || zone.is_empty() {
        return None;
    }

    Some((
        zone.to_string(),
        Band {
            max_grams: max_grams.parse().ok()?,
            cents: cents.parse().ok()?,
        },
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899

international\t500\t1499
";

    #[test]
    fn collects_bands_per_zone() {
        let card = RateCard::parse(SAMPLE).expect("sample card parses");

        assert_eq!(
            card.bands("domestic"),
            Some(
                [
                    Band {
                        max_grams: 500,
                        cents: 599
                    },
                    Band {
                        max_grams: 2000,
                        cents: 899
                    },
                ]
                .as_slice()
            )
        );
        assert_eq!(
            card.bands("international"),
            Some(
                [Band {
                    max_grams: 500,
                    cents: 1499
                }]
                .as_slice()
            )
        );
    }

    #[test]
    fn zone_missing_from_card_has_no_bands() {
        let card = RateCard::parse(SAMPLE).expect("sample card parses");

        assert_eq!(card.bands("lunar"), None);
    }

    #[test]
    fn orders_bands_by_weight_regardless_of_file_order() {
        let card = RateCard::parse("domestic\t2000\t899\ndomestic\t500\t599\n")
            .expect("out of order card parses");

        let maxima: Vec<u32> = card
            .bands("domestic")
            .expect("domestic priced")
            .iter()
            .map(|band| band.max_grams)
            .collect();
        assert_eq!(maxima, vec![500, 2000]);
    }

    #[test]
    fn comments_and_blanks_still_count_toward_line_numbers() {
        let text = "# header\n\ndomestic\t500\tnot-a-number\n";

        assert_eq!(RateCard::parse(text), Err(QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn rejects_lines_without_three_fields() {
        assert_eq!(
            RateCard::parse("domestic\t500\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(
            RateCard::parse("domestic\t500\t599\textra\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(
            RateCard::parse("domestic 500 599\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn rejects_unparsable_numbers() {
        assert_eq!(
            RateCard::parse("domestic\t-500\t599\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(
            RateCard::parse("domestic\t500\t5.99\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn rejects_a_blank_zone() {
        assert_eq!(RateCard::parse("\t500\t599\n"), Err(QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn reports_the_first_malformed_line() {
        let text = "domestic\t500\t599\ndomestic\tbad\t899\ndomestic\t2000\tworse\n";

        assert_eq!(RateCard::parse(text), Err(QuoteError::MalformedRateCard { line: 2 }));
    }

    #[test]
    fn tolerates_windows_line_endings() {
        let card = RateCard::parse("# header\r\ndomestic\t500\t599\r\n").expect("crlf card parses");

        assert_eq!(
            card.bands("domestic"),
            Some(
                [Band {
                    max_grams: 500,
                    cents: 599
                }]
                .as_slice()
            )
        );
    }

    #[test]
    fn an_unset_path_leaves_the_card_unavailable() {
        let _guard = crate::tests::env_lock();
        let restore = crate::tests::clear_ratecard_path();

        assert_eq!(RateCard::from_env(), Err(QuoteError::RateCardUnavailable));

        drop(restore);
    }

    #[test]
    fn a_missing_file_leaves_the_card_unavailable() {
        assert_eq!(
            RateCard::from_path(PathBuf::from("/nonexistent/ratecard.tsv")),
            Err(QuoteError::RateCardUnavailable)
        );
    }
}
