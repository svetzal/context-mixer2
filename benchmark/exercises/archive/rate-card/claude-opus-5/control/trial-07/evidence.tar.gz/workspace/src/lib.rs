//! Shipping quotes for the fulfilment service.
//!
//! Operations deploys a rate card — a tab-separated table of priced weight
//! bands per zone — and points `RATECARD_PATH` at it. [`quote`] reads that card
//! and prices one [`Parcel`] against it.

pub mod card;
pub mod diagnostics;
pub mod zones;

use std::error::Error;
use std::fmt;

use crate::card::RateCard;
use crate::diagnostics::QuoteRecord;

/// The zone whose quotes carry the air-freight surcharge.
const INTERNATIONAL_ZONE: &str = "international";

/// Weight above which a parcel needs two-person handling.
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;

/// Flat handling surcharge for a heavy parcel.
const HEAVY_SURCHARGE_CENTS: u64 = 500;

/// International surcharge, as a percentage of the base rate.
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

/// A parcel to be priced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price of shipping one parcel, itemised.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Why a parcel could not be priced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card is unset, missing, or unreadable.
    RateCardUnavailable,
    /// A line of the rate card does not parse; `line` is 1-based.
    MalformedRateCard { line: usize },
    /// The rate card prices no bands for the requested zone.
    UnknownZone(String),
    /// The parcel outweighs the zone's largest band.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel of {grams} g exceeds the {limit} g limit")
            }
        }
    }
}

impl Error for QuoteError {}

/// Prices `parcel` against the rate card named by `RATECARD_PATH`.
///
/// Each successful quote emits a [`diagnostics::QuoteRecord`].
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = RateCard::from_env()?;
    let quote = price(&card, parcel)?;

    diagnostics::emit(QuoteRecord {
        zone: parcel.zone.clone(),
        weight_grams: parcel.weight_grams,
        total_cents: quote.total_cents,
    });

    Ok(quote)
}

/// Prices `parcel` against an already loaded `card`.
fn price(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = card
        .bands(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    // Bands arrive ascending, so the first one wide enough is the cheapest one
    // that fits.
    let band =
        bands.iter().find(|band| band.max_grams >= parcel.weight_grams).ok_or_else(|| {
            QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: bands.last().map_or(0, |band| band.max_grams),
            }
        })?;

    let base_cents = band.cents;
    let surcharge_cents = heavy_surcharge(parcel.weight_grams)
        .saturating_add(zone_surcharge(&parcel.zone, base_cents));

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    })
}

/// The flat surcharge for parcels over the heavy-handling threshold.
fn heavy_surcharge(weight_grams: u32) -> u64 {
    if weight_grams > HEAVY_THRESHOLD_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    }
}

/// The zone's proportional surcharge, rounded half-up to the cent.
fn zone_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone != INTERNATIONAL_ZONE {
        return 0;
    }

    // Widened so the percentage cannot overflow the base rate.
    let scaled = u128::from(base_cents) * u128::from(INTERNATIONAL_SURCHARGE_PERCENT);
    round_half_up(scaled, 100)
}

/// Divides, rounding a tie away from zero rather than down.
fn round_half_up(numerator: u128, divisor: u128) -> u64 {
    u64::try_from((numerator + divisor / 2) / divisor).unwrap_or(u64::MAX)
}

#[cfg(test)]
pub(crate) mod tests {
    use super::*;

    use std::env;
    use std::ffi::OsString;
    use std::sync::{Arc, Mutex, MutexGuard, OnceLock};

    use crate::card::RATECARD_PATH_VAR;
    use crate::diagnostics::{self, DiagnosticSink};
    use tempfile::TempDir;

    pub(crate) const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    /// `RATECARD_PATH` and the diagnostic sink are process-wide, so tests that
    /// touch either take this lock rather than racing each other.
    pub(crate) fn env_lock() -> MutexGuard<'static, ()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
    }

    /// Restores `RATECARD_PATH` to its prior value when dropped.
    pub(crate) struct RestorePath(Option<OsString>);

    impl Drop for RestorePath {
        fn drop(&mut self) {
            match self.0.take() {
                Some(previous) => env::set_var(RATECARD_PATH_VAR, previous),
                None => env::remove_var(RATECARD_PATH_VAR),
            }
        }
    }

    pub(crate) fn clear_ratecard_path() -> RestorePath {
        let restore = RestorePath(env::var_os(RATECARD_PATH_VAR));
        env::remove_var(RATECARD_PATH_VAR);
        restore
    }

    /// Writes `text` to a card file and points `RATECARD_PATH` at it.
    fn deploy_card(text: &str) -> (TempDir, RestorePath) {
        let dir = tempfile::tempdir().expect("temp dir");
        let path = dir.path().join("ratecard.tsv");
        std::fs::write(&path, text).expect("write card");

        let restore = RestorePath(env::var_os(RATECARD_PATH_VAR));
        env::set_var(RATECARD_PATH_VAR, &path);
        (dir, restore)
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    /// Collects the records a quote emits.
    #[derive(Default)]
    struct Recorder(Mutex<Vec<QuoteRecord>>);

    impl DiagnosticSink for Recorder {
        fn record(&self, record: &QuoteRecord) {
            self.0
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner())
                .push(record.clone());
        }
    }

    impl Recorder {
        fn records(&self) -> Vec<QuoteRecord> {
            self.0.lock().unwrap_or_else(|poisoned| poisoned.into_inner()).clone()
        }
    }

    fn sample_card() -> RateCard {
        RateCard::parse(SAMPLE_CARD).expect("sample card parses")
    }

    #[test]
    fn prices_from_the_first_band_that_fits() {
        let card = sample_card();

        let quote = price(&card, &parcel(400, "domestic")).expect("priced");

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn a_weight_exactly_on_a_boundary_stays_in_the_lower_band() {
        let card = sample_card();

        let quote = price(&card, &parcel(500, "domestic")).expect("priced");

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn a_gram_over_a_boundary_climbs_to_the_next_band() {
        let card = sample_card();

        let quote = price(&card, &parcel(501, "domestic")).expect("priced");

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn heavy_parcels_add_the_handling_surcharge() {
        let card = sample_card();

        let quote = price(&card, &parcel(10_001, "domestic")).expect("priced");

        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn the_heavy_threshold_itself_is_not_heavy() {
        let card = sample_card();

        let quote = price(&card, &parcel(10_000, "domestic")).expect("priced");

        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_a_fifth_of_the_base_rate() {
        let card = sample_card();

        let quote = price(&card, &parcel(400, "international")).expect("priced");

        assert_eq!(quote.base_cents, 1499);
        // 20% of 1499 is 299.8, rounded half-up to 300.
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn surcharges_stack() {
        let card = sample_card();

        let quote = price(&card, &parcel(15_000, "international")).expect("priced");

        assert_eq!(quote.base_cents, 4999);
        // 500 handling plus 20% of 4999, which is 999.8 rounded up to 1000.
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn the_zone_surcharge_rounds_to_the_nearest_cent() {
        assert_eq!(zone_surcharge(INTERNATIONAL_ZONE, 0), 0);
        // A fifth of a whole number of cents lands on .0, .2, .4, .6 or .8, so
        // every rounding case is one of these five.
        assert_eq!(zone_surcharge(INTERNATIONAL_ZONE, 1000), 200);
        assert_eq!(zone_surcharge(INTERNATIONAL_ZONE, 1001), 200);
        assert_eq!(zone_surcharge(INTERNATIONAL_ZONE, 1002), 200);
        assert_eq!(zone_surcharge(INTERNATIONAL_ZONE, 1003), 201);
        assert_eq!(zone_surcharge(INTERNATIONAL_ZONE, 1004), 201);
    }

    #[test]
    fn a_half_cent_surcharge_rounds_up() {
        // Half-up is only observable where the fraction is exactly .5, which a
        // fifth never is — so exercise the boundary through the shared rounding
        // the surcharge performs.
        assert_eq!(round_half_up(2_005, 10), 201);
        assert_eq!(round_half_up(2_004, 10), 200);
        assert_eq!(round_half_up(2_015, 10), 202);
    }

    #[test]
    fn domestic_pays_no_zone_surcharge() {
        assert_eq!(zone_surcharge("domestic", 1499), 0);
    }

    #[test]
    fn a_zone_the_card_omits_is_unknown() {
        let card = sample_card();

        assert_eq!(
            price(&card, &parcel(400, "lunar")).unwrap_err(),
            QuoteError::UnknownZone("lunar".to_string())
        );
    }

    #[test]
    fn zone_matching_is_exact() {
        let card = sample_card();

        assert_eq!(
            price(&card, &parcel(400, "Domestic")).unwrap_err(),
            QuoteError::UnknownZone("Domestic".to_string())
        );
    }

    #[test]
    fn a_parcel_past_the_largest_band_is_overweight() {
        let card = sample_card();

        assert_eq!(
            price(&card, &parcel(20_001, "domestic")).unwrap_err(),
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            }
        );
    }

    #[test]
    fn overweight_reports_the_zones_own_limit() {
        let card = RateCard::parse("domestic\t20000\t1799\ninternational\t500\t1499\n")
            .expect("card parses");

        assert_eq!(
            price(&card, &parcel(600, "international")).unwrap_err(),
            QuoteError::Overweight {
                grams: 600,
                limit: 500,
            }
        );
    }

    #[test]
    fn quotes_read_the_deployed_card() {
        let _guard = env_lock();
        let (_dir, _restore) = deploy_card(SAMPLE_CARD);

        let quote = quote(&parcel(1_500, "domestic")).expect("priced");

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn quotes_without_a_card_path_report_it_unavailable() {
        let _guard = env_lock();
        let _restore = clear_ratecard_path();

        assert_eq!(quote(&parcel(400, "domestic")).unwrap_err(), QuoteError::RateCardUnavailable);
    }

    #[test]
    fn quotes_from_a_missing_card_report_it_unavailable() {
        let _guard = env_lock();
        let restore = RestorePath(env::var_os(RATECARD_PATH_VAR));
        env::set_var(RATECARD_PATH_VAR, "/nonexistent/ratecard.tsv");

        assert_eq!(quote(&parcel(400, "domestic")).unwrap_err(), QuoteError::RateCardUnavailable);

        drop(restore);
    }

    #[test]
    fn quotes_surface_the_offending_line_of_a_bad_card() {
        let _guard = env_lock();
        let (_dir, _restore) = deploy_card("# header\ndomestic\t500\t599\nbroken line\n");

        assert_eq!(
            quote(&parcel(400, "domestic")).unwrap_err(),
            QuoteError::MalformedRateCard { line: 3 }
        );
    }

    #[test]
    fn every_quote_emits_a_diagnostic_record() {
        let _guard = env_lock();
        let (_dir, _restore) = deploy_card(SAMPLE_CARD);
        let recorder = Arc::new(Recorder::default());
        let previous = diagnostics::set_sink(recorder.clone());

        quote(&parcel(750, "international")).expect("priced");

        diagnostics::clear_sink();
        if let Some(previous) = previous {
            diagnostics::set_sink(previous);
        }

        assert_eq!(
            recorder.records(),
            // 750 g clears the 500 g band, so it prices at 4999 plus a fifth.
            vec![QuoteRecord {
                zone: "international".to_string(),
                weight_grams: 750,
                total_cents: 5999,
            }]
        );
    }

    #[test]
    fn failed_quotes_emit_no_record() {
        let _guard = env_lock();
        let (_dir, _restore) = deploy_card(SAMPLE_CARD);
        let recorder = Arc::new(Recorder::default());
        let previous = diagnostics::set_sink(recorder.clone());

        let outcome = quote(&parcel(400, "lunar"));

        diagnostics::clear_sink();
        if let Some(previous) = previous {
            diagnostics::set_sink(previous);
        }

        assert!(outcome.is_err());
        assert!(recorder.records().is_empty());
    }

    #[test]
    fn errors_read_as_sentences() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 7 }.to_string(),
            "malformed rate card at line 7"
        );
        assert_eq!(QuoteError::UnknownZone("lunar".to_string()).to_string(), "unknown zone: lunar");
        assert_eq!(
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000,
            }
            .to_string(),
            "parcel of 25000 g exceeds the 20000 g limit"
        );
    }

    #[test]
    fn quote_errors_are_std_errors() {
        fn assert_error<E: Error>(_: &E) {}

        assert_error(&QuoteError::RateCardUnavailable);
        let boxed: Box<dyn Error> = Box::new(QuoteError::UnknownZone("lunar".to_string()));
        assert_eq!(boxed.to_string(), "unknown zone: lunar");
    }
}
