//! Diagnostic records for quotes, so pricing is observable in operation.
//!
//! Every successful quote emits one [`QuoteRecord`]. By default records go to
//! stderr; a host that already has a logging pipeline can install its own sink
//! with [`set_sink`] and forward them wherever it likes.

use std::fmt;
use std::sync::{Arc, Mutex, OnceLock};

use crate::zones::zone_label;

/// What one quote did: the zone asked for, the parcel weight, the price given.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct QuoteRecord {
    pub zone: String,
    pub weight_grams: u32,
    pub total_cents: u64,
}

impl fmt::Display for QuoteRecord {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "quote zone={} service=\"{}\" weight_grams={} total_cents={}",
            self.zone,
            zone_label(&self.zone),
            self.weight_grams,
            self.total_cents
        )
    }
}

/// A destination for quote records.
pub trait DiagnosticSink: Send + Sync {
    fn record(&self, record: &QuoteRecord);
}

impl<F> DiagnosticSink for F
where
    F: Fn(&QuoteRecord) + Send + Sync,
{
    fn record(&self, record: &QuoteRecord) {
        self(record)
    }
}

fn installed() -> &'static Mutex<Option<Arc<dyn DiagnosticSink>>> {
    static SINK: OnceLock<Mutex<Option<Arc<dyn DiagnosticSink>>>> = OnceLock::new();
    SINK.get_or_init(|| Mutex::new(None))
}

fn lock() -> std::sync::MutexGuard<'static, Option<Arc<dyn DiagnosticSink>>> {
    installed().lock().unwrap_or_else(|poisoned| poisoned.into_inner())
}

/// Routes subsequent records to `sink`, returning whatever it displaced.
pub fn set_sink(sink: Arc<dyn DiagnosticSink>) -> Option<Arc<dyn DiagnosticSink>> {
    lock().replace(sink)
}

/// Restores the default stderr sink, returning whatever it displaced.
pub fn clear_sink() -> Option<Arc<dyn DiagnosticSink>> {
    lock().take()
}

/// Emits one record for a completed quote.
pub(crate) fn emit(record: QuoteRecord) {
    // Cloned out of the lock so a sink cannot deadlock by touching the sink
    // registry, and so slow sinks do not serialise unrelated quotes.
    let sink = lock().clone();
    match sink {
        Some(sink) => sink.record(&record),
        None => eprintln!("{record}"),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn renders_the_zone_weight_and_total() {
        let record = QuoteRecord {
            zone: "international".to_string(),
            weight_grams: 750,
            total_cents: 5999,
        };

        assert_eq!(
            record.to_string(),
            "quote zone=international service=\"International air\" \
             weight_grams=750 total_cents=5999"
        );
    }
}
