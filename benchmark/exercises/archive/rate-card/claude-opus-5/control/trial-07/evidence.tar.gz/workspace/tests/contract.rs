//! The crate's public contract, exercised the way a caller outside the crate
//! sees it: structs built by literal, fields read directly, errors matched.
//!
//! `RATECARD_PATH` is process-wide, so every test here takes one lock and
//! deploys the card it needs.

use std::env;
use std::error::Error;
use std::sync::{Mutex, MutexGuard, OnceLock};

use ratecard::{quote, Parcel, QuoteError};
use tempfile::TempDir;

const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn env_lock() -> MutexGuard<'static, ()> {
    static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    LOCK.get_or_init(|| Mutex::new(()))
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
}

/// Writes `text` to a card file and points `RATECARD_PATH` at it. The returned
/// directory must outlive the quotes taken against it.
fn deploy(text: &str) -> TempDir {
    let dir = tempfile::tempdir().expect("temp dir");
    let path = dir.path().join("ratecard.tsv");
    std::fs::write(&path, text).expect("write card");
    env::set_var("RATECARD_PATH", &path);
    dir
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_string(),
    }
}

#[test]
fn quotes_a_domestic_parcel_from_its_band() {
    let _guard = env_lock();
    let _dir = deploy(CARD);

    let quote = quote(&parcel(1_200, "domestic")).expect("priced");

    assert_eq!(quote.base_cents, 899);
    assert_eq!(quote.surcharge_cents, 0);
    assert_eq!(quote.total_cents, 899);
    assert_eq!(quote.band_max_grams, 2_000);
}

#[test]
fn quotes_a_heavy_international_parcel_with_both_surcharges() {
    let _guard = env_lock();
    let _dir = deploy(CARD);

    let quote = quote(&parcel(12_000, "international")).expect("priced");

    assert_eq!(quote.base_cents, 4_999);
    assert_eq!(quote.surcharge_cents, 500 + 1_000);
    assert_eq!(quote.total_cents, 6_499);
    assert_eq!(quote.band_max_grams, 20_000);
}

#[test]
fn reports_each_failure_as_its_own_variant() {
    let _guard = env_lock();
    let _dir = deploy(CARD);

    match quote(&parcel(400, "lunar")) {
        Err(QuoteError::UnknownZone(zone)) => assert_eq!(zone, "lunar"),
        other => panic!("expected UnknownZone, got {other:?}"),
    }

    match quote(&parcel(20_001, "domestic")) {
        Err(QuoteError::Overweight { grams, limit }) => {
            assert_eq!(grams, 20_001);
            assert_eq!(limit, 20_000);
        }
        other => panic!("expected Overweight, got {other:?}"),
    }

    let _dir = deploy("# header\n\ndomestic\t500\tfree\n");
    match quote(&parcel(400, "domestic")) {
        Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
        other => panic!("expected MalformedRateCard, got {other:?}"),
    }

    env::remove_var("RATECARD_PATH");
    match quote(&parcel(400, "domestic")) {
        Err(QuoteError::RateCardUnavailable) => {}
        other => panic!("expected RateCardUnavailable, got {other:?}"),
    }
}

#[test]
fn a_redeployed_card_reprices_without_a_restart() {
    let _guard = env_lock();
    let _first = deploy(CARD);

    let before = quote(&parcel(400, "domestic")).expect("priced");

    let _second = deploy("domestic\t500\t649\n");
    let after = quote(&parcel(400, "domestic")).expect("repriced");

    assert_eq!(before.total_cents, 599);
    assert_eq!(after.total_cents, 649);
}

#[test]
fn quote_errors_are_reportable() {
    let error: Box<dyn Error> = Box::new(QuoteError::Overweight {
        grams: 25_000,
        limit: 20_000,
    });

    assert_eq!(error.to_string(), "parcel of 25000 g exceeds the 20000 g limit");
}
