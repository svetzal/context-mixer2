# ratecard

Shipping quotes for the fulfilment service.

Warehouse operators price outbound parcels against a rate card that operations
maintains and redeploys without a code change. This crate owns reading that card
and turning a parcel into a quote.

## The rate card

`quote` reads the card named by the `RATECARD_PATH` environment variable on
every call, so operations can redeploy pricing without restarting the service.
The card is tab-separated — `zone`, `band_max_grams`, `cents` — with blank lines
and `#` comments ignored.

Every quote emits a diagnostic record carrying the zone, weight, and total. Those
go to stderr unless the host installs its own sink with
`diagnostics::set_sink`.

## Development

```bash
cargo test
```
