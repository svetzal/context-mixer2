//! End-to-end quotes, driven through `RATECARD_PATH` the way callers use them.
//!
//! `RATECARD_PATH` is process-wide, so every test here takes `ENV_LOCK` before
//! touching it. Keep these tests in one file: separate integration test files
//! run as separate binaries, but the lock only serialises within a binary.

use std::ffi::OsStr;
use std::io::Write;
use std::sync::{Arc, Mutex, MutexGuard, OnceLock};

use ratecard::diagnostics::QuoteRecord;
use ratecard::{quote, Parcel, Quote, QuoteError};
use tempfile::NamedTempFile;

const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn env_lock() -> MutexGuard<'static, ()> {
    static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    LOCK.get_or_init(|| Mutex::new(()))
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
}

/// Run `body` with `RATECARD_PATH` pointing at a card holding `text`.
fn with_card<T>(text: &str, body: impl FnOnce() -> T) -> T {
    let _guard = env_lock();
    let card = write_card(text);

    run_with_path(Some(card.path().as_os_str()), body)
}

/// Run `body` with `RATECARD_PATH` set to `path`, or unset if `path` is `None`.
fn with_path<T>(path: Option<&str>, body: impl FnOnce() -> T) -> T {
    let _guard = env_lock();

    run_with_path(path.map(OsStr::new), body)
}

/// Run `body` against a card holding `text`, capturing the records it emits.
///
/// The sink is process-wide, so this takes the same lock as [`with_card`] to
/// keep other tests' quotes out of the capture.
fn with_card_capturing<T>(text: &str, body: impl FnOnce() -> T) -> (T, Vec<QuoteRecord>) {
    let _guard = env_lock();
    let card = write_card(text);

    let captured = Arc::new(Mutex::new(Vec::new()));
    let sink = Arc::clone(&captured);
    ratecard::diagnostics::set_sink(move |record| lock(&sink).push(record.clone()));

    let outcome = run_with_path(Some(card.path().as_os_str()), body);

    ratecard::diagnostics::clear_sink();
    let records = lock(&captured).clone();
    (outcome, records)
}

/// Set `RATECARD_PATH`, run `body`, and unset it again. Caller holds the lock.
fn run_with_path<T>(path: Option<&OsStr>, body: impl FnOnce() -> T) -> T {
    match path {
        Some(path) => std::env::set_var("RATECARD_PATH", path),
        None => std::env::remove_var("RATECARD_PATH"),
    }
    let outcome = body();
    std::env::remove_var("RATECARD_PATH");

    outcome
}

fn write_card(text: &str) -> NamedTempFile {
    let mut file = NamedTempFile::new().expect("temp file");
    file.write_all(text.as_bytes()).expect("write card");
    file.flush().expect("flush card");
    file
}

fn lock<T>(mutex: &Mutex<T>) -> MutexGuard<'_, T> {
    mutex.lock().unwrap_or_else(|poisoned| poisoned.into_inner())
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_string(),
    }
}

#[test]
fn quotes_a_domestic_parcel_from_the_deployed_card() {
    let quoted = with_card(SAMPLE, || quote(&parcel(1_200, "domestic"))).expect("quoted");

    assert_eq!(
        quoted,
        Quote {
            base_cents: 899,
            surcharge_cents: 0,
            total_cents: 899,
            band_max_grams: 2000,
        }
    );
}

#[test]
fn quotes_a_heavy_international_parcel_with_both_surcharges() {
    let quoted = with_card(SAMPLE, || quote(&parcel(15_000, "international"))).expect("quoted");

    assert_eq!(
        quoted,
        Quote {
            base_cents: 4999,
            surcharge_cents: 1500,
            total_cents: 6499,
            band_max_grams: 20000,
        }
    );
}

#[test]
fn picks_up_a_redeployed_card_without_a_restart() {
    let before = with_card(SAMPLE, || quote(&parcel(100, "domestic"))).expect("quoted");
    let after = with_card("domestic\t500\t649\n", || quote(&parcel(100, "domestic")))
        .expect("quoted");

    assert_eq!(before.base_cents, 599);
    assert_eq!(after.base_cents, 649);
}

#[test]
fn an_unset_path_leaves_the_rate_card_unavailable() {
    let error = with_path(None, || quote(&parcel(100, "domestic"))).unwrap_err();

    assert_eq!(error, QuoteError::RateCardUnavailable);
}

#[test]
fn a_missing_file_leaves_the_rate_card_unavailable() {
    let error = with_path(Some("/nonexistent/ratecard.tsv"), || {
        quote(&parcel(100, "domestic"))
    })
    .unwrap_err();

    assert_eq!(error, QuoteError::RateCardUnavailable);
}

#[test]
fn an_unreadable_card_leaves_the_rate_card_unavailable() {
    // A directory is readable as a path but not as a file.
    let error =
        with_path(Some("/"), || quote(&parcel(100, "domestic"))).unwrap_err();

    assert_eq!(error, QuoteError::RateCardUnavailable);
}

#[test]
fn a_broken_line_is_reported_by_its_number_in_the_file() {
    let card = "# zone\tband_max_grams\tcents\ndomestic\t500\t599\ndomestic\ttwo thousand\t899\n";

    let error = with_card(card, || quote(&parcel(100, "domestic"))).unwrap_err();

    assert_eq!(error, QuoteError::MalformedRateCard { line: 3 });
}

#[test]
fn a_malformed_card_fails_even_for_a_zone_that_parses_cleanly() {
    let card = "domestic\t500\t599\ninternational\t500\n";

    let error = with_card(card, || quote(&parcel(100, "domestic"))).unwrap_err();

    assert_eq!(error, QuoteError::MalformedRateCard { line: 2 });
}

#[test]
fn a_zone_the_card_omits_is_unknown() {
    let error = with_card(SAMPLE, || quote(&parcel(100, "lunar"))).unwrap_err();

    assert_eq!(error, QuoteError::UnknownZone("lunar".to_string()));
}

#[test]
fn a_parcel_past_the_largest_band_is_overweight() {
    let error = with_card(SAMPLE, || quote(&parcel(25_000, "domestic"))).unwrap_err();

    assert_eq!(
        error,
        QuoteError::Overweight {
            grams: 25_000,
            limit: 20_000
        }
    );
}

#[test]
fn the_overweight_limit_is_per_zone() {
    let card = "domestic\t20000\t1799\ninternational\t5000\t4999\n";

    let error = with_card(card, || quote(&parcel(6_000, "international"))).unwrap_err();

    assert_eq!(
        error,
        QuoteError::Overweight {
            grams: 6_000,
            limit: 5_000
        }
    );
}

#[test]
fn every_quote_leaves_a_diagnostic_record() {
    let (quoted, records) = with_card_capturing(SAMPLE, || {
        quote(&parcel(15_000, "international")).expect("quoted")
    });

    assert_eq!(
        records,
        vec![QuoteRecord {
            zone: "international".to_string(),
            weight_grams: 15_000,
            total_cents: quoted.total_cents,
        }]
    );
}

#[test]
fn each_call_leaves_its_own_record() {
    let (_, records) = with_card_capturing(SAMPLE, || {
        quote(&parcel(100, "domestic")).expect("quoted");
        quote(&parcel(2_000, "domestic")).expect("quoted");
    });

    let seen: Vec<u32> = records.iter().map(|record| record.weight_grams).collect();
    assert_eq!(seen, vec![100, 2_000]);
}
