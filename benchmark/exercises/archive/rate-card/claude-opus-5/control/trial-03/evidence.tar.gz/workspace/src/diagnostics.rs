//! Per-quote observability.
//!
//! Every quote the crate hands back also leaves a record behind, so operators
//! can answer "what did we charge for that parcel?" without reproducing the
//! call. Records go to stderr unless the host installs its own sink.

use std::fmt;
use std::sync::{OnceLock, RwLock};

/// The evidence that one quote happened.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct QuoteRecord {
    pub zone: String,
    pub weight_grams: u32,
    pub total_cents: u64,
}

impl fmt::Display for QuoteRecord {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "ratecard quote zone={} weight_grams={} total_cents={}",
            self.zone, self.weight_grams, self.total_cents
        )
    }
}

type Sink = Box<dyn Fn(&QuoteRecord) + Send + Sync>;

fn slot() -> &'static RwLock<Option<Sink>> {
    static SLOT: OnceLock<RwLock<Option<Sink>>> = OnceLock::new();
    SLOT.get_or_init(|| RwLock::new(None))
}

/// Send quote records somewhere of your choosing — a logger, a metrics
/// pipeline, a test buffer — instead of stderr. Replaces any previous sink.
pub fn set_sink<F>(sink: F)
where
    F: Fn(&QuoteRecord) + Send + Sync + 'static,
{
    *write_slot() = Some(Box::new(sink));
}

/// Go back to writing records to stderr.
pub fn clear_sink() {
    *write_slot() = None;
}

pub(crate) fn emit(record: &QuoteRecord) {
    let slot = slot().read().unwrap_or_else(|poisoned| poisoned.into_inner());
    match slot.as_ref() {
        Some(sink) => sink(record),
        None => eprintln!("{record}"),
    }
}

fn write_slot() -> std::sync::RwLockWriteGuard<'static, Option<Sink>> {
    slot()
        .write()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn renders_the_fields_an_operator_needs() {
        let record = QuoteRecord {
            zone: "international".to_string(),
            weight_grams: 12000,
            total_cents: 6499,
        };

        assert_eq!(
            record.to_string(),
            "ratecard quote zone=international weight_grams=12000 total_cents=6499"
        );
    }
}
