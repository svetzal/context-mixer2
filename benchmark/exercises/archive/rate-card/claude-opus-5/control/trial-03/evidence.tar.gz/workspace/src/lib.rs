//! Shipping quotes for the fulfilment service.
//!
//! [`quote`] reads the rate card named by the `RATECARD_PATH` environment
//! variable on every call, so operations can redeploy the card without a
//! restart, and prices a [`Parcel`] against it.

pub mod diagnostics;
mod rate_card;
pub mod zones;

use std::fmt;

use diagnostics::QuoteRecord;
use rate_card::{MalformedLine, RateCard};

/// Weight above this, in grams, attracts the heavy-parcel surcharge.
const HEAVY_ABOVE_GRAMS: u32 = 10_000;
/// The heavy-parcel surcharge itself.
const HEAVY_SURCHARGE_CENTS: u64 = 500;
/// The zone that attracts the percentage surcharge.
const INTERNATIONAL: &str = "international";
/// That percentage.
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

/// A parcel awaiting a price.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// What a parcel costs to ship, and the band that decided it.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Why a parcel could not be priced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, or the file it names cannot be read.
    RateCardUnavailable,
    /// A line of the card is not three tab-separated fields with parseable
    /// numbers. `line` is 1-based and counts comments and blanks.
    MalformedRateCard { line: usize },
    /// The card has no bands for the parcel's zone.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => write!(
                f,
                "parcel weighs {grams} g, above the {limit} g limit for its zone"
            ),
        }
    }
}

impl std::error::Error for QuoteError {}

/// Price a parcel against the currently deployed rate card.
///
/// Emits a [`QuoteRecord`] for every quote returned.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = load_rate_card()?;
    let quote = price(&card, parcel)?;

    diagnostics::emit(&QuoteRecord {
        zone: parcel.zone.clone(),
        weight_grams: parcel.weight_grams,
        total_cents: quote.total_cents,
    });

    Ok(quote)
}

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = std::env::var_os("RATECARD_PATH").ok_or(QuoteError::RateCardUnavailable)?;
    let text = std::fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    RateCard::parse(&text).map_err(|MalformedLine(line)| QuoteError::MalformedRateCard { line })
}

fn price(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = card
        .bands(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = bands
        .iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: bands.last().map_or(0, |band| band.max_grams),
        })?;

    let base_cents = band.cents;
    let surcharge_cents = surcharges(parcel, base_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    })
}

fn surcharges(parcel: &Parcel, base_cents: u64) -> u64 {
    let mut surcharge = 0;

    if parcel.weight_grams > HEAVY_ABOVE_GRAMS {
        surcharge += HEAVY_SURCHARGE_CENTS;
    }
    if parcel.zone == INTERNATIONAL {
        surcharge = surcharge.saturating_add(percent_of(
            base_cents,
            INTERNATIONAL_SURCHARGE_PERCENT,
        ));
    }

    surcharge
}

/// `percent` percent of `cents`, rounded half-up to the whole cent.
///
/// Saturating so that an absurd price on the card cannot panic a quote.
fn percent_of(cents: u64, percent: u64) -> u64 {
    cents.saturating_mul(percent).saturating_add(50) / 100
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn sample_card() -> RateCard {
        RateCard::parse(SAMPLE).expect("sample card parses")
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn prices_from_the_first_band_that_covers_the_weight() {
        let quote = price(&sample_card(), &parcel(750, "domestic")).expect("priced");

        assert_eq!(
            quote,
            Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2000,
            }
        );
    }

    #[test]
    fn a_weight_exactly_on_a_threshold_stays_in_that_band() {
        let quote = price(&sample_card(), &parcel(500, "domestic")).expect("priced");

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn one_gram_over_a_threshold_moves_up_a_band() {
        let quote = price(&sample_card(), &parcel(501, "domestic")).expect("priced");

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn a_weightless_parcel_lands_in_the_lightest_band() {
        let quote = price(&sample_card(), &parcel(0, "domestic")).expect("priced");

        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn weight_above_ten_kilos_adds_the_heavy_surcharge() {
        let quote = price(&sample_card(), &parcel(10_001, "domestic")).expect("priced");

        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn exactly_ten_kilos_is_not_heavy() {
        let quote = price(&sample_card(), &parcel(10_000, "domestic")).expect("priced");

        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn international_adds_a_fifth_of_the_base() {
        let quote = price(&sample_card(), &parcel(400, "international")).expect("priced");

        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn the_international_surcharge_rounds_half_up() {
        // 20% of 599 is 119.8 cents, and 20% of 2505 is exactly 501.0.
        assert_eq!(percent_of(599, 20), 120);
        assert_eq!(percent_of(2505, 20), 501);
        // 20% of 2 is 0.4, which rounds down; 20% of 3 is 0.6, which rounds up.
        assert_eq!(percent_of(2, 20), 0);
        assert_eq!(percent_of(3, 20), 1);
        // An exact half-cent rounds up, not to even.
        assert_eq!(percent_of(15, 10), 2);
        assert_eq!(percent_of(25, 10), 3);
    }

    #[test]
    fn surcharges_stack_on_a_heavy_international_parcel() {
        let quote = price(&sample_card(), &parcel(15_000, "international")).expect("priced");

        assert_eq!(quote.base_cents, 4999);
        // 500 heavy + 1000 (20% of 4999, rounded half-up from 999.8).
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20000);
    }

    #[test]
    fn total_is_always_base_plus_surcharge() {
        for (weight, zone) in [
            (100, "domestic"),
            (10_500, "domestic"),
            (100, "international"),
            (19_999, "international"),
        ] {
            let quote = price(&sample_card(), &parcel(weight, zone)).expect("priced");
            assert_eq!(quote.total_cents, quote.base_cents + quote.surcharge_cents);
        }
    }

    #[test]
    fn an_absent_zone_is_reported_with_the_name_asked_for() {
        let error = price(&sample_card(), &parcel(100, "lunar")).unwrap_err();

        assert_eq!(error, QuoteError::UnknownZone("lunar".to_string()));
    }

    #[test]
    fn zone_matching_is_exact() {
        let error = price(&sample_card(), &parcel(100, "Domestic")).unwrap_err();

        assert_eq!(error, QuoteError::UnknownZone("Domestic".to_string()));
    }

    #[test]
    fn too_heavy_for_the_zone_reports_that_zones_largest_band() {
        let error = price(&sample_card(), &parcel(20_001, "international")).unwrap_err();

        assert_eq!(
            error,
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            }
        );
    }

    #[test]
    fn an_unknown_zone_beats_an_overweight_parcel() {
        let error = price(&sample_card(), &parcel(50_000, "lunar")).unwrap_err();

        assert_eq!(error, QuoteError::UnknownZone("lunar".to_string()));
    }

    #[test]
    fn errors_read_like_sentences() {
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "rate card unavailable"
        );
        assert_eq!(
            QuoteError::MalformedRateCard { line: 7 }.to_string(),
            "malformed rate card at line 7"
        );
        assert_eq!(
            QuoteError::UnknownZone("lunar".to_string()).to_string(),
            "unknown zone: lunar"
        );
        assert_eq!(
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000
            }
            .to_string(),
            "parcel weighs 25000 g, above the 20000 g limit for its zone"
        );
    }

    #[test]
    fn quote_errors_are_std_errors() {
        fn assert_error<E: std::error::Error>(_: &E) {}

        assert_error(&QuoteError::RateCardUnavailable);
    }
}
