//! Reading the tab-separated rate card that operations maintains.
//!
//! The card is deliberately dumb: one band per line, `zone`, `band_max_grams`
//! and `cents` separated by tabs. Blank lines and `#` comments are ignored so
//! operators can annotate the file.

use std::collections::HashMap;

/// A price band: parcels up to `max_grams` in this zone cost `cents`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Band {
    pub max_grams: u32,
    pub cents: u64,
}

/// The 1-based number of a line the parser could not make sense of.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct MalformedLine(pub usize);

/// Every band the card describes, grouped by zone and ordered by weight.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct RateCard {
    zones: HashMap<String, Vec<Band>>,
}

impl RateCard {
    /// Parse a whole card, failing on the first line that is not three
    /// tab-separated fields with parseable numbers.
    ///
    /// Line numbers count every line in the file, comments and blanks
    /// included, so the number in the error matches what an operator sees in
    /// their editor.
    pub fn parse(text: &str) -> Result<Self, MalformedLine> {
        let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

        for (index, line) in text.lines().enumerate() {
            let line_number = index + 1;
            let trimmed = line.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }

            let (zone, band) = parse_band(line).ok_or(MalformedLine(line_number))?;
            zones.entry(zone).or_default().push(band);
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(Self { zones })
    }

    /// The bands for a zone, lightest first, or `None` if the card has never
    /// heard of it.
    pub fn bands(&self, zone: &str) -> Option<&[Band]> {
        self.zones.get(zone).map(Vec::as_slice)
    }
}

fn parse_band(line: &str) -> Option<(String, Band)> {
    let mut fields = line.split('\t');
    let zone = fields.next()?.trim();
    let max_grams = fields.next()?.trim();
    let cents = fields.next()?.trim();
    if fields.next().is_some() {
        return None;
    }

    Some((
        zone.to_string(),
        Band {
            max_grams: max_grams.parse().ok()?,
            cents: cents.parse().ok()?,
        },
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn groups_bands_by_zone() {
        let card = RateCard::parse(SAMPLE).expect("sample card parses");

        assert_eq!(
            card.bands("domestic"),
            Some(
                &[
                    Band { max_grams: 500, cents: 599 },
                    Band { max_grams: 2000, cents: 899 },
                    Band { max_grams: 20000, cents: 1799 },
                ][..]
            )
        );
        assert_eq!(
            card.bands("international"),
            Some(
                &[
                    Band { max_grams: 500, cents: 1499 },
                    Band { max_grams: 20000, cents: 4999 },
                ][..]
            )
        );
    }

    #[test]
    fn unlisted_zone_has_no_bands() {
        let card = RateCard::parse(SAMPLE).expect("sample card parses");

        assert_eq!(card.bands("lunar"), None);
    }

    #[test]
    fn orders_bands_by_weight_regardless_of_file_order() {
        let card = RateCard::parse("domestic\t2000\t899\ndomestic\t500\t599\n")
            .expect("card parses");

        let maxima: Vec<u32> = card
            .bands("domestic")
            .expect("domestic is present")
            .iter()
            .map(|band| band.max_grams)
            .collect();
        assert_eq!(maxima, vec![500, 2000]);
    }

    #[test]
    fn ignores_blank_lines_and_comments() {
        let card = RateCard::parse("\n# a note\n\t\ndomestic\t500\t599\n")
            .expect("card parses");

        assert_eq!(card.bands("domestic").map(<[Band]>::len), Some(1));
    }

    #[test]
    fn empty_card_yields_no_zones() {
        let card = RateCard::parse("").expect("empty card parses");

        assert_eq!(card.bands("domestic"), None);
    }

    #[test]
    fn reports_the_line_with_too_few_fields() {
        let error = RateCard::parse("# note\ndomestic\t500\n").unwrap_err();

        assert_eq!(error, MalformedLine(2));
    }

    #[test]
    fn reports_the_line_with_too_many_fields() {
        let error = RateCard::parse("domestic\t500\t599\textra\n").unwrap_err();

        assert_eq!(error, MalformedLine(1));
    }

    #[test]
    fn reports_the_line_with_an_unparseable_weight() {
        let error = RateCard::parse("domestic\t500\t599\ndomestic\theavy\t899\n").unwrap_err();

        assert_eq!(error, MalformedLine(2));
    }

    #[test]
    fn reports_the_line_with_an_unparseable_price() {
        let error = RateCard::parse("domestic\t500\tfree\n").unwrap_err();

        assert_eq!(error, MalformedLine(1));
    }

    #[test]
    fn counts_comments_and_blanks_when_numbering_lines() {
        let error =
            RateCard::parse("# header\n\n# another\ndomestic\t500\t599\nbroken\n").unwrap_err();

        assert_eq!(error, MalformedLine(5));
    }

    #[test]
    fn rejects_space_separated_lines() {
        let error = RateCard::parse("domestic 500 599\n").unwrap_err();

        assert_eq!(error, MalformedLine(1));
    }

    #[test]
    fn tolerates_carriage_returns() {
        let card = RateCard::parse("domestic\t500\t599\r\n").expect("card parses");

        assert_eq!(
            card.bands("domestic"),
            Some(&[Band { max_grams: 500, cents: 599 }][..])
        );
    }
}
