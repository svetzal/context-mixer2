# ratecard

Shipping quotes for the fulfilment service.

Warehouse operators price outbound parcels against a rate card that operations
maintains and redeploys without a code change. This crate owns reading that card
and turning a parcel into a quote.

## Operating

`quote` reads the tab-separated card named by the `RATECARD_PATH` environment
variable on every call, so operations can redeploy the card in place.

Every quote returned emits a diagnostic record — zone, weight in grams, total in
cents — to stderr. Hosts that would rather route those into their own logging
can install a sink with `ratecard::diagnostics::set_sink`.

## Development

```bash
cargo test
```
