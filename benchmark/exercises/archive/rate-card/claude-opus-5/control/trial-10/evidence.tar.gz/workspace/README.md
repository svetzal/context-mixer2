# ratecard

Shipping quotes for the fulfilment service.

Warehouse operators price outbound parcels against a rate card that operations
maintains and redeploys without a code change. This crate owns reading that card
and turning a parcel into a quote.

## The rate card

`quote` reads the card named by the `RATECARD_PATH` environment variable. It is
tab separated, one band per line; empty lines and lines beginning with `#` are
ignored.

```text
# zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
domestic	20000	1799
international	500	1499
international	20000	4999
```

A parcel is priced by the first band, ascending, whose `band_max_grams` reaches
its weight. Surcharges add together: 500 cents above 10000 grams, and 20% of the
base rate for `international`, rounded half up to the cent.

## Observability

Every call emits one `observe::QuoteRecord` carrying the zone, the weight, and
the total — to stderr by default. Route it elsewhere with `observe::set_sink`.

## Development

```bash
cargo test
```
