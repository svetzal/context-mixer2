//! Shipping quotes for the fulfilment service.
//!
//! [`quote`] prices a [`Parcel`] against the rate card deployed at the path in
//! the `RATECARD_PATH` environment variable, so operations can reprice without
//! a code change. Every call emits an [`observe::QuoteRecord`].

pub mod observe;
pub mod pricing;
pub mod rate_card;
pub mod zones;

use std::error::Error;
use std::fmt;

use observe::{Outcome, QuoteRecord};
use rate_card::RateCard;

/// A parcel awaiting a price.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// What a parcel costs to ship, and the band that decided it.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Why a parcel could not be priced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, or the file it names cannot be read.
    RateCardUnavailable,
    /// A card line is not three tab-separated fields, or its numbers do not
    /// parse. `line` is 1-based and counts comments and blanks.
    MalformedRateCard { line: usize },
    /// The card prices no such zone.
    UnknownZone(String),
    /// The parcel outweighs the zone's largest band.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(
                f,
                "rate card unavailable: set {} to a readable rate card",
                rate_card::PATH_VAR
            ),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone {zone:?}"),
            Self::Overweight { grams, limit } => write!(
                f,
                "overweight: {grams} g exceeds the {limit} g limit for this zone"
            ),
        }
    }
}

impl Error for QuoteError {}

/// Price `parcel` against the deployed rate card.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let result = RateCard::load().and_then(|card| pricing::price(&card, parcel));

    observe::emit(&QuoteRecord {
        zone: &parcel.zone,
        weight_grams: parcel.weight_grams,
        outcome: match &result {
            Ok(quote) => Outcome::Quoted { total_cents: quote.total_cents },
            Err(error) => Outcome::Failed { error },
        },
    });

    result
}
