//! Turning a parcel into a quote against a loaded rate card.

use crate::rate_card::RateCard;
use crate::{Parcel, Quote, QuoteError};

/// Above this weight the parcel is handled by hand.
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_SURCHARGE_CENTS: u64 = 500;

const INTERNATIONAL_ZONE: &str = "international";
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

/// Price `parcel` against `card`.
pub fn price(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = card
        .bands(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    // Bands arrive ascending, so the first that reaches the weight is the
    // cheapest one that covers it.
    let band = bands
        .iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or_else(|| QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: bands.last().map_or(0, |band| band.max_grams),
        })?;

    let base_cents = band.cents;
    let surcharge_cents = heavy_surcharge(parcel) + international_surcharge(parcel, base_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

fn heavy_surcharge(parcel: &Parcel) -> u64 {
    if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    }
}

fn international_surcharge(parcel: &Parcel, base_cents: u64) -> u64 {
    if parcel.zone == INTERNATIONAL_ZONE {
        percent_of(base_cents, INTERNATIONAL_SURCHARGE_PERCENT)
    } else {
        0
    }
}

/// `percent` of `cents`, rounded half-up to the cent.
fn percent_of(cents: u64, percent: u64) -> u64 {
    (cents * percent + 50) / 100
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rounds_percentages_half_up() {
        assert_eq!(percent_of(1499, 20), 300); // 299.8
        assert_eq!(percent_of(4999, 20), 1000); // 999.8
        assert_eq!(percent_of(1500, 20), 300); // 300.0
        assert_eq!(percent_of(1512, 20), 302); // 302.4
        assert_eq!(percent_of(1515, 20), 303); // 303.0
        assert_eq!(percent_of(25, 50), 13); // 12.5 rounds up
        assert_eq!(percent_of(0, 20), 0);
    }
}
