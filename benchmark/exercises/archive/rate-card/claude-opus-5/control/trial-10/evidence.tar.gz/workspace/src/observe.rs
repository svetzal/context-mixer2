//! Diagnostics for quotes, so pricing is observable in operation.
//!
//! Every call to [`crate::quote`] emits one [`QuoteRecord`]. Records go to
//! stderr unless the host installs its own sink with [`set_sink`].

use std::fmt;
use std::sync::Mutex;

use crate::zones::zone_label;
use crate::QuoteError;

/// What the quote call did with the parcel.
#[derive(Debug, Clone, Copy)]
pub enum Outcome<'a> {
    Quoted { total_cents: u64 },
    Failed { error: &'a QuoteError },
}

/// One quote, as observed: the zone, the weight, and what it came to.
#[derive(Debug, Clone, Copy)]
pub struct QuoteRecord<'a> {
    pub zone: &'a str,
    pub weight_grams: u32,
    pub outcome: Outcome<'a>,
}

impl QuoteRecord<'_> {
    /// The quoted total, or `None` when the parcel could not be priced.
    pub fn total_cents(&self) -> Option<u64> {
        match self.outcome {
            Outcome::Quoted { total_cents } => Some(total_cents),
            Outcome::Failed { .. } => None,
        }
    }
}

impl fmt::Display for QuoteRecord<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "ratecard.quote zone={} zone_label={:?} weight_grams={}",
            self.zone,
            zone_label(self.zone),
            self.weight_grams
        )?;
        match self.outcome {
            Outcome::Quoted { total_cents } => write!(f, " total_cents={total_cents}"),
            Outcome::Failed { error } => {
                write!(f, " total_cents=none error={:?}", error.to_string())
            }
        }
    }
}

type Sink = Box<dyn Fn(&QuoteRecord<'_>) + Send + Sync>;

static SINK: Mutex<Option<Sink>> = Mutex::new(None);

/// Route records somewhere other than stderr — a log crate, a metrics
/// pipeline, a test. Returns the sink it replaced.
pub fn set_sink(sink: Option<Sink>) -> Option<Sink> {
    let mut slot = SINK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    std::mem::replace(&mut *slot, sink)
}

pub(crate) fn emit(record: &QuoteRecord<'_>) {
    let slot = SINK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    match slot.as_ref() {
        Some(sink) => sink(record),
        None => eprintln!("{record}"),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_priced_parcel_reads_back_its_total() {
        let record = QuoteRecord {
            zone: "domestic",
            weight_grams: 750,
            outcome: Outcome::Quoted { total_cents: 899 },
        };

        assert_eq!(record.total_cents(), Some(899));
        assert_eq!(
            record.to_string(),
            "ratecard.quote zone=domestic zone_label=\"Domestic ground\" \
             weight_grams=750 total_cents=899"
        );
    }

    #[test]
    fn a_failed_parcel_records_the_reason_and_no_total() {
        let error = QuoteError::UnknownZone("lunar".to_string());
        let record = QuoteRecord {
            zone: "lunar",
            weight_grams: 750,
            outcome: Outcome::Failed { error: &error },
        };

        assert_eq!(record.total_cents(), None);
        let line = record.to_string();
        assert!(line.contains("zone=lunar"), "{line}");
        assert!(line.contains("weight_grams=750"), "{line}");
        assert!(line.contains("total_cents=none"), "{line}");
        assert!(line.contains("unknown zone"), "{line}");
    }
}
