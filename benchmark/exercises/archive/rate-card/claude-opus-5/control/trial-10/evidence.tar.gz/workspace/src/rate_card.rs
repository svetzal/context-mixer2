//! Reading the rate card that operations maintains and redeploys.

use std::collections::HashMap;
use std::env;
use std::fs;

use crate::QuoteError;

/// The environment variable naming the deployed rate card.
pub const PATH_VAR: &str = "RATECARD_PATH";

/// One priced weight band within a zone.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Band {
    pub max_grams: u32,
    pub cents: u64,
}

/// The bands of every zone, each zone's bands ordered ascending by threshold.
#[derive(Debug, Default, Clone, PartialEq, Eq)]
pub struct RateCard {
    zones: HashMap<String, Vec<Band>>,
}

impl RateCard {
    /// Load the card named by `RATECARD_PATH`.
    pub fn load() -> Result<Self, QuoteError> {
        let path = env::var(PATH_VAR).map_err(|_| QuoteError::RateCardUnavailable)?;
        let text = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
        Self::parse(&text)
    }

    /// Parse the tab-separated card. Every line is validated, so a malformed
    /// band is reported whether or not the quote would have consulted it.
    pub fn parse(text: &str) -> Result<Self, QuoteError> {
        let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

        for (index, line) in text.lines().enumerate() {
            let line_number = index + 1;
            let trimmed = line.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }

            let (zone, band) = parse_band(line, line_number)?;
            zones.entry(zone).or_default().push(band);
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(Self { zones })
    }

    /// The bands of `zone`, ascending, or `None` when the card omits the zone.
    pub fn bands(&self, zone: &str) -> Option<&[Band]> {
        self.zones.get(zone).map(Vec::as_slice)
    }
}

fn parse_band(line: &str, line_number: usize) -> Result<(String, Band), QuoteError> {
    let malformed = || QuoteError::MalformedRateCard { line: line_number };

    let fields: Vec<&str> = line.split('\t').collect();
    let [zone, max_grams, cents] = fields.as_slice() else {
        return Err(malformed());
    };

    let max_grams: u32 = max_grams.trim().parse().map_err(|_| malformed())?;
    let cents: u64 = cents.trim().parse().map_err(|_| malformed())?;

    Ok((zone.trim().to_string(), Band { max_grams, cents }))
}

#[cfg(test)]
mod tests {
    use super::*;

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
                        domestic\t500\t599\n\
                        domestic\t2000\t899\n\
                        \n\
                        international\t500\t1499\n";

    #[test]
    fn groups_bands_by_zone() {
        let card = RateCard::parse(CARD).unwrap();

        assert_eq!(
            card.bands("domestic"),
            Some(
                [
                    Band { max_grams: 500, cents: 599 },
                    Band { max_grams: 2000, cents: 899 },
                ]
                .as_slice()
            )
        );
        assert_eq!(
            card.bands("international"),
            Some([Band { max_grams: 500, cents: 1499 }].as_slice())
        );
    }

    #[test]
    fn absent_zone_has_no_bands() {
        assert_eq!(RateCard::parse(CARD).unwrap().bands("lunar"), None);
    }

    #[test]
    fn orders_bands_ascending_however_the_file_lists_them() {
        let card = RateCard::parse("domestic\t2000\t899\ndomestic\t500\t599\n").unwrap();

        let thresholds: Vec<u32> = card
            .bands("domestic")
            .unwrap()
            .iter()
            .map(|band| band.max_grams)
            .collect();
        assert_eq!(thresholds, [500, 2000]);
    }

    #[test]
    fn ignores_comments_and_blank_lines() {
        let card = RateCard::parse("\n#comment\n   \ndomestic\t500\t599\n").unwrap();

        assert_eq!(card.bands("domestic").unwrap().len(), 1);
    }

    #[test]
    fn counts_every_line_when_reporting_a_malformed_one() {
        let text = "# header\n\ndomestic\t500\t599\ndomestic\t2000\n";

        assert_eq!(
            RateCard::parse(text),
            Err(QuoteError::MalformedRateCard { line: 4 })
        );
    }

    #[test]
    fn rejects_extra_fields() {
        assert_eq!(
            RateCard::parse("domestic\t500\t599\textra\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn rejects_space_separated_bands() {
        assert_eq!(
            RateCard::parse("domestic 500 599\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn rejects_numbers_that_do_not_parse() {
        assert_eq!(
            RateCard::parse("domestic\theavy\t599\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(
            RateCard::parse("domestic\t500\t5.99\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
        assert_eq!(
            RateCard::parse("domestic\t500\t-599\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn reports_the_first_malformed_line() {
        assert_eq!(
            RateCard::parse("domestic\tx\t1\ndomestic\ty\t2\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn tolerates_carriage_returns() {
        let card = RateCard::parse("# zone\r\ndomestic\t500\t599\r\n").unwrap();

        assert_eq!(
            card.bands("domestic"),
            Some([Band { max_grams: 500, cents: 599 }].as_slice())
        );
    }
}
