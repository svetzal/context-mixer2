//! Behaviour of `quote` against a deployed rate card.
//!
//! `RATECARD_PATH` and the diagnostic sink are process-wide, so every test
//! that touches them takes `ENV` first.

use std::error::Error;
use std::io::Write;
use std::sync::{Arc, Mutex, MutexGuard};

use ratecard::observe::{Outcome, QuoteRecord};
use ratecard::{quote, Parcel, Quote, QuoteError};
use tempfile::NamedTempFile;

const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

static ENV: Mutex<()> = Mutex::new(());

fn lock() -> MutexGuard<'static, ()> {
    ENV.lock().unwrap_or_else(|poisoned| poisoned.into_inner())
}

/// Deploy `card` and run `body` against it.
fn with_card<T>(card: &str, body: impl FnOnce() -> T) -> T {
    let _guard = lock();

    let mut file = NamedTempFile::new().expect("temp file");
    file.write_all(card.as_bytes()).expect("write card");
    file.flush().expect("flush card");
    std::env::set_var("RATECARD_PATH", file.path());

    let outcome = body();

    std::env::remove_var("RATECARD_PATH");
    outcome
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel { weight_grams, zone: zone.to_string() }
}

fn quoted(weight_grams: u32, zone: &str) -> Quote {
    with_card(CARD, || quote(&parcel(weight_grams, zone))).expect("a quote")
}

fn failed(weight_grams: u32, zone: &str) -> QuoteError {
    with_card(CARD, || quote(&parcel(weight_grams, zone))).expect_err("an error")
}

#[test]
fn prices_from_the_first_band_that_covers_the_weight() {
    assert_eq!(
        quoted(750, "domestic"),
        Quote {
            base_cents: 899,
            surcharge_cents: 0,
            total_cents: 899,
            band_max_grams: 2000,
        }
    );
}

#[test]
fn a_weight_exactly_on_a_threshold_stays_in_that_band() {
    let quote = quoted(500, "domestic");

    assert_eq!(quote.band_max_grams, 500);
    assert_eq!(quote.base_cents, 599);
}

#[test]
fn a_gram_over_a_threshold_moves_up_a_band() {
    let quote = quoted(501, "domestic");

    assert_eq!(quote.band_max_grams, 2000);
    assert_eq!(quote.base_cents, 899);
}

#[test]
fn the_lightest_parcel_takes_the_lowest_band() {
    assert_eq!(quoted(1, "domestic").band_max_grams, 500);
    assert_eq!(quoted(0, "domestic").band_max_grams, 500);
}

#[test]
fn weight_above_ten_kilos_adds_a_flat_surcharge() {
    assert_eq!(
        quoted(10_001, "domestic"),
        Quote {
            base_cents: 1799,
            surcharge_cents: 500,
            total_cents: 2299,
            band_max_grams: 20000,
        }
    );
}

#[test]
fn ten_kilos_exactly_is_not_heavy() {
    let quote = quoted(10_000, "domestic");

    assert_eq!(quote.surcharge_cents, 0);
    assert_eq!(quote.total_cents, quote.base_cents);
}

#[test]
fn international_adds_a_fifth_of_the_base_rounded_half_up() {
    // 20% of 1499 is 299.8.
    assert_eq!(
        quoted(400, "international"),
        Quote {
            base_cents: 1499,
            surcharge_cents: 300,
            total_cents: 1799,
            band_max_grams: 500,
        }
    );
}

#[test]
fn surcharges_add_together() {
    // 20% of 4999 is 999.8, plus the 500 for weight.
    assert_eq!(
        quoted(15_000, "international"),
        Quote {
            base_cents: 4999,
            surcharge_cents: 1500,
            total_cents: 6499,
            band_max_grams: 20000,
        }
    );
}

#[test]
fn the_percentage_is_taken_on_the_base_not_the_running_total() {
    let quote = quoted(15_000, "international");

    assert_eq!(quote.surcharge_cents, 500 + 1000);
    assert_eq!(quote.total_cents, quote.base_cents + quote.surcharge_cents);
}

#[test]
fn a_zone_the_card_omits_is_unknown() {
    assert_eq!(failed(750, "lunar"), QuoteError::UnknownZone("lunar".into()));
}

#[test]
fn zones_are_matched_exactly() {
    assert_eq!(
        failed(750, "Domestic"),
        QuoteError::UnknownZone("Domestic".into())
    );
}

#[test]
fn a_parcel_past_the_largest_band_is_overweight() {
    assert_eq!(
        failed(20_001, "domestic"),
        QuoteError::Overweight { grams: 20_001, limit: 20_000 }
    );
}

#[test]
fn the_overweight_limit_is_the_zones_own_largest_band() {
    let card = "domestic\t20000\t1799\ninternational\t500\t1499\n";
    let error = with_card(card, || quote(&parcel(600, "international")));

    assert_eq!(
        error,
        Err(QuoteError::Overweight { grams: 600, limit: 500 })
    );
}

#[test]
fn an_unset_path_leaves_the_rate_card_unavailable() {
    let _guard = lock();
    std::env::remove_var("RATECARD_PATH");

    assert_eq!(
        quote(&parcel(750, "domestic")),
        Err(QuoteError::RateCardUnavailable)
    );
}

#[test]
fn a_missing_file_leaves_the_rate_card_unavailable() {
    let _guard = lock();
    std::env::set_var("RATECARD_PATH", "/nonexistent/rate/card.tsv");

    let result = quote(&parcel(750, "domestic"));
    std::env::remove_var("RATECARD_PATH");

    assert_eq!(result, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn a_malformed_line_reports_its_position_in_the_file() {
    let card = "# zone\tband_max_grams\tcents\n\
                domestic\t500\t599\n\
                \n\
                domestic\ttwo thousand\t899\n";
    let result = with_card(card, || quote(&parcel(400, "domestic")));

    assert_eq!(result, Err(QuoteError::MalformedRateCard { line: 4 }));
}

#[test]
fn a_malformed_line_fails_the_quote_even_in_another_zone() {
    let card = "domestic\t500\t599\ninternational\t500\n";
    let result = with_card(card, || quote(&parcel(400, "domestic")));

    assert_eq!(result, Err(QuoteError::MalformedRateCard { line: 2 }));
}

#[test]
fn errors_describe_themselves() {
    let errors = [
        QuoteError::RateCardUnavailable,
        QuoteError::MalformedRateCard { line: 4 },
        QuoteError::UnknownZone("lunar".into()),
        QuoteError::Overweight { grams: 20_001, limit: 20_000 },
    ];

    for error in &errors {
        assert!(!error.to_string().is_empty());
        // Compiles only because the variants implement std::error::Error.
        let _: &dyn Error = error;
    }

    assert!(QuoteError::MalformedRateCard { line: 4 }
        .to_string()
        .contains('4'));
    assert!(QuoteError::UnknownZone("lunar".into())
        .to_string()
        .contains("lunar"));
}

#[test]
fn every_call_emits_a_diagnostic_record() {
    let _guard = lock();

    let seen = Arc::new(Mutex::new(Vec::new()));
    let sink = Arc::clone(&seen);
    let previous = ratecard::observe::set_sink(Some(Box::new(move |record: &QuoteRecord<'_>| {
        let total = match record.outcome {
            Outcome::Quoted { total_cents } => total_cents.to_string(),
            Outcome::Failed { .. } => "none".to_string(),
        };
        sink.lock()
            .unwrap()
            .push(format!("{} {} {}", record.zone, record.weight_grams, total));
    })));

    let mut file = NamedTempFile::new().expect("temp file");
    file.write_all(CARD.as_bytes()).expect("write card");
    file.flush().expect("flush card");
    std::env::set_var("RATECARD_PATH", file.path());

    let _ = quote(&parcel(750, "domestic"));
    let _ = quote(&parcel(750, "lunar"));

    std::env::remove_var("RATECARD_PATH");
    ratecard::observe::set_sink(previous);

    let records = seen.lock().unwrap().clone();
    assert_eq!(records, ["domestic 750 899", "lunar 750 none"]);
}
