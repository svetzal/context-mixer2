//! End-to-end tests over the deployed rate card, driving `quote` exactly as an
//! external caller does.
//!
//! `RATECARD_PATH` is process-wide, so every test that touches it takes
//! [`ENV_LOCK`] for its whole body and restores the variable on the way out.

use std::env;
use std::fs;
use std::sync::{Mutex, MutexGuard, Once};

use ratecard::{quote, Parcel, Quote, QuoteError};

const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

static ENV_LOCK: Mutex<()> = Mutex::new(());

/// A rate card on disk, named by `RATECARD_PATH` for as long as this is held.
struct Deployment {
    _dir: tempfile::TempDir,
    _guard: MutexGuard<'static, ()>,
}

impl Drop for Deployment {
    fn drop(&mut self) {
        env::remove_var("RATECARD_PATH");
    }
}

fn lock() -> MutexGuard<'static, ()> {
    // A panicking test should fail on its own assertion, not poison the rest.
    ENV_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner())
}

fn deploy(card: &str) -> Deployment {
    let guard = lock();
    let dir = tempfile::tempdir().expect("temporary directory");
    let path = dir.path().join("rates.tsv");
    fs::write(&path, card).expect("write the card");
    env::set_var("RATECARD_PATH", &path);
    Deployment { _dir: dir, _guard: guard }
}

fn parcel(zone: &str, weight_grams: u32) -> Parcel {
    Parcel { weight_grams, zone: zone.to_string() }
}

#[test]
fn a_domestic_parcel_is_quoted_from_the_deployed_card() {
    let _deployment = deploy(CARD);
    assert_eq!(
        quote(&parcel("domestic", 750)).unwrap(),
        Quote {
            base_cents: 899,
            surcharge_cents: 0,
            total_cents: 899,
            band_max_grams: 2000,
        }
    );
}

#[test]
fn a_heavy_international_parcel_is_quoted_with_both_surcharges() {
    let _deployment = deploy(CARD);
    assert_eq!(
        quote(&parcel("international", 18_000)).unwrap(),
        Quote {
            base_cents: 4999,
            surcharge_cents: 1500,
            total_cents: 6499,
            band_max_grams: 20000,
        }
    );
}

#[test]
fn a_zone_the_card_does_not_price_is_unknown() {
    let _deployment = deploy(CARD);
    assert_eq!(
        quote(&parcel("lunar", 100)).unwrap_err(),
        QuoteError::UnknownZone("lunar".to_string())
    );
}

#[test]
fn a_parcel_past_the_largest_band_is_overweight() {
    let _deployment = deploy(CARD);
    assert_eq!(
        quote(&parcel("domestic", 30_000)).unwrap_err(),
        QuoteError::Overweight { grams: 30_000, limit: 20_000 }
    );
}

#[test]
fn a_malformed_line_reports_its_number_in_the_file() {
    let card = "# zone\tband_max_grams\tcents\n\ndomestic\t500\t599\ndomestic\ttwo kilos\t899\n";
    let _deployment = deploy(card);
    assert_eq!(
        quote(&parcel("domestic", 100)).unwrap_err(),
        QuoteError::MalformedRateCard { line: 4 }
    );
}

#[test]
fn a_redeployed_card_is_picked_up_without_a_restart() {
    let _deployment = deploy(CARD);
    assert_eq!(quote(&parcel("domestic", 100)).unwrap().total_cents, 599);

    let path = env::var("RATECARD_PATH").expect("a deployed card");
    fs::write(&path, "domestic\t500\t699\n").expect("redeploy the card");
    assert_eq!(quote(&parcel("domestic", 100)).unwrap().total_cents, 699);
}

#[test]
fn an_unset_path_leaves_no_card_to_price_against() {
    let _guard = lock();
    env::remove_var("RATECARD_PATH");
    assert_eq!(
        quote(&parcel("domestic", 100)).unwrap_err(),
        QuoteError::RateCardUnavailable
    );
}

#[test]
fn an_empty_path_leaves_no_card_to_price_against() {
    let _guard = lock();
    env::set_var("RATECARD_PATH", "");
    let result = quote(&parcel("domestic", 100));
    env::remove_var("RATECARD_PATH");
    assert_eq!(result.unwrap_err(), QuoteError::RateCardUnavailable);
}

#[test]
fn a_path_to_nothing_leaves_no_card_to_price_against() {
    let deployment = deploy(CARD);
    let path = env::var("RATECARD_PATH").expect("a deployed card");
    fs::remove_file(&path).expect("undeploy the card");
    assert_eq!(
        quote(&parcel("domestic", 100)).unwrap_err(),
        QuoteError::RateCardUnavailable
    );
    drop(deployment);
}

#[test]
fn an_unreadable_path_leaves_no_card_to_price_against() {
    let guard = lock();
    let dir = tempfile::tempdir().expect("temporary directory");
    // A directory is a path that exists and cannot be read as a card.
    env::set_var("RATECARD_PATH", dir.path());
    let result = quote(&parcel("domestic", 100));
    env::remove_var("RATECARD_PATH");
    drop(guard);
    assert_eq!(result.unwrap_err(), QuoteError::RateCardUnavailable);
}

// --- observability ---------------------------------------------------------

static RECORDS: Mutex<Vec<String>> = Mutex::new(Vec::new());
static CAPTURE: Capture = Capture;
static INSTALLED: Once = Once::new();

struct Capture;

impl log::Log for Capture {
    fn enabled(&self, _metadata: &log::Metadata) -> bool {
        true
    }

    fn log(&self, record: &log::Record) {
        RECORDS
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
            .push(format!("{} {} {}", record.level(), record.target(), record.args()));
    }

    fn flush(&self) {}
}

/// Start capturing log records, discarding anything captured so far.
///
/// Callers hold the environment lock, so only their own quotes land in the
/// buffer.
fn capture_records() {
    INSTALLED.call_once(|| {
        log::set_logger(&CAPTURE).expect("no other logger is installed");
        log::set_max_level(log::LevelFilter::Trace);
    });
    RECORDS
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
        .clear();
}

fn captured() -> Vec<String> {
    RECORDS
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
        .clone()
}

#[test]
fn every_quote_is_observable() {
    let _deployment = deploy(CARD);
    capture_records();

    let quoted = quote(&parcel("international", 18_000)).unwrap();

    let records = captured();
    assert_eq!(records.len(), 1, "one record per call: {records:?}");
    let record = &records[0];
    assert!(record.contains("international"), "zone missing: {record}");
    assert!(record.contains("18000"), "weight missing: {record}");
    assert!(
        record.contains(&quoted.total_cents.to_string()),
        "total missing: {record}"
    );
}

#[test]
fn a_quote_that_cannot_be_priced_is_observable_too() {
    let _deployment = deploy(CARD);
    capture_records();

    let _ = quote(&parcel("lunar", 4_200));

    let records = captured();
    assert_eq!(records.len(), 1, "one record per call: {records:?}");
    let record = &records[0];
    assert!(record.starts_with("WARN"), "not a warning: {record}");
    assert!(record.contains("lunar"), "zone missing: {record}");
    assert!(record.contains("4200"), "weight missing: {record}");
}
