//! The surcharge rules layered on top of a band's base price.

/// Weight above which a parcel needs two-person handling.
pub(crate) const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;

/// Flat handling surcharge for a heavy parcel.
pub(crate) const HEAVY_SURCHARGE_CENTS: u64 = 500;

/// Zone whose base price carries a customs and air-freight uplift.
pub(crate) const INTERNATIONAL_ZONE: &str = "international";

/// Uplift applied to the base price of an international parcel, in percent.
pub(crate) const INTERNATIONAL_UPLIFT_PERCENT: u64 = 20;

/// Every surcharge the parcel attracts, summed.
///
/// The uplift is taken on the base price alone, so the flat heavy-handling
/// charge is never itself marked up.
pub(crate) fn surcharge_cents(zone: &str, weight_grams: u32, base_cents: u64) -> u64 {
    let heavy = if weight_grams > HEAVY_THRESHOLD_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    };

    let uplift = if zone == INTERNATIONAL_ZONE {
        percent_of_cents(base_cents, INTERNATIONAL_UPLIFT_PERCENT)
    } else {
        0
    };

    heavy.saturating_add(uplift)
}

/// `percent` of `cents`, rounded half-up to the nearest cent.
///
/// Money never leaves integer arithmetic here: widening to `u128` keeps the
/// intermediate product exact for any price the card could carry.
fn percent_of_cents(cents: u64, percent: u64) -> u64 {
    let scaled = cents as u128 * percent as u128;
    let rounded = (scaled + 50) / 100;
    u64::try_from(rounded).unwrap_or(u64::MAX)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn an_ordinary_domestic_parcel_attracts_nothing() {
        assert_eq!(surcharge_cents("domestic", 500, 599), 0);
    }

    #[test]
    fn a_parcel_exactly_on_the_heavy_threshold_is_not_yet_heavy() {
        assert_eq!(surcharge_cents("domestic", HEAVY_THRESHOLD_GRAMS, 1799), 0);
    }

    #[test]
    fn a_parcel_one_gram_over_the_threshold_is_heavy() {
        assert_eq!(
            surcharge_cents("domestic", HEAVY_THRESHOLD_GRAMS + 1, 1799),
            HEAVY_SURCHARGE_CENTS
        );
    }

    #[test]
    fn an_international_parcel_carries_a_fifth_of_its_base() {
        // 20% of 1499 is 299.8, which rounds up to 300.
        assert_eq!(surcharge_cents("international", 500, 1499), 300);
    }

    #[test]
    fn a_heavy_international_parcel_carries_both_surcharges() {
        // 20% of 4999 is 999.8, which rounds up to 1000, plus the flat 500.
        assert_eq!(surcharge_cents("international", 15_000, 4999), 1500);
    }

    #[test]
    fn the_uplift_ignores_the_flat_heavy_charge() {
        // Were the uplift taken on base + 500 it would be 300, not 200.
        assert_eq!(surcharge_cents("international", 15_000, 1000), 700);
    }

    #[test]
    fn an_unrecognised_zone_carries_no_uplift() {
        assert_eq!(surcharge_cents("International", 500, 1499), 0);
        assert_eq!(surcharge_cents("intl", 500, 1499), 0);
    }

    #[test]
    fn a_percentage_landing_on_a_whole_cent_is_left_alone() {
        assert_eq!(percent_of_cents(1000, 20), 200);
        assert_eq!(percent_of_cents(0, 20), 0);
    }

    #[test]
    fn a_fraction_below_half_a_cent_rounds_down() {
        // 20% of 1001 is 200.2.
        assert_eq!(percent_of_cents(1001, 20), 200);
        // 20% of 1002 is 200.4.
        assert_eq!(percent_of_cents(1002, 20), 200);
    }

    #[test]
    fn a_fraction_above_half_a_cent_rounds_up() {
        // 20% of 1003 is 200.6.
        assert_eq!(percent_of_cents(1003, 20), 201);
        // 20% of 1004 is 200.8.
        assert_eq!(percent_of_cents(1004, 20), 201);
    }

    #[test]
    fn an_exact_half_cent_rounds_up() {
        // 50% of 5 is 2.5, the tie the half-up rule exists to settle.
        assert_eq!(percent_of_cents(5, 50), 3);
        // 25% of 10 is 2.5 as well.
        assert_eq!(percent_of_cents(10, 25), 3);
    }

    #[test]
    fn a_base_whose_uplift_would_overflow_plain_arithmetic_stays_exact() {
        // 1e18 * 20 does not fit in a u64; the widening to u128 is what keeps
        // this from wrapping into a nonsense price.
        assert_eq!(
            percent_of_cents(1_000_000_000_000_000_000, 20),
            200_000_000_000_000_000
        );
    }
}
