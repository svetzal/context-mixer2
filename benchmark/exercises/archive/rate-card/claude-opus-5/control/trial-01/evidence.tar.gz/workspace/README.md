# ratecard

Shipping quotes for the fulfilment service.

Warehouse operators price outbound parcels against a rate card that operations
maintains and redeploys without a code change. This crate owns reading that card
and turning a parcel into a quote.

## Configuration

`RATECARD_PATH` names the deployed rate card: a tab-separated file of
`zone`, `band_max_grams`, `cents`, one band per line, with `#` comments and
blank lines ignored. The card is re-read on every quote, so operations can
redeploy it under a running service.

```text
# zone	band_max_grams	cents
domestic	500	599
domestic	2000	899
international	500	1499
```

## Observability

Every call to `quote` emits a `log` record — info with the zone, weight and
total for a priced parcel, warn with the reason for one that could not be
priced — under the target `ratecard::quote`. Install any `log` implementation
to see them.

## Development

```bash
cargo test
```
