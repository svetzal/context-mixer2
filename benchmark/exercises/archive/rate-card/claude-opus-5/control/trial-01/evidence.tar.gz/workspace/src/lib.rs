//! Shipping quotes for the fulfilment service.
//!
//! Operations maintains a rate card and redeploys it without a code change;
//! this crate reads that card from the path in `RATECARD_PATH` and turns a
//! [`Parcel`] into a [`Quote`].
//!
//! ```no_run
//! use ratecard::{quote, Parcel};
//!
//! let parcel = Parcel { weight_grams: 750, zone: "domestic".to_string() };
//! let priced = quote(&parcel)?;
//! println!("{} cents", priced.total_cents);
//! # Ok::<(), ratecard::QuoteError>(())
//! ```
//!
//! Every call emits a `log` record naming the zone, the weight and the total,
//! so a deployment with a logger installed can see what it quoted.

mod pricing;
mod rate_card;

pub mod zones;

use std::error::Error;
use std::fmt;

use rate_card::RateCard;

/// A parcel awaiting a price.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A priced parcel, broken out so an invoice can show its working.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Why a parcel could not be priced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// No rate card could be read from `RATECARD_PATH`.
    RateCardUnavailable,
    /// The card has a line that is not three tab-separated fields, or whose
    /// numbers do not parse. `line` is 1-based and counts every line in the
    /// file, comments and blanks included.
    MalformedRateCard { line: usize },
    /// The card prices no such zone. Carries the zone that was asked for.
    UnknownZone(String),
    /// The parcel outweighs the zone's largest band, whose threshold is
    /// `limit`.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(
                f,
                "no rate card available from the {} environment variable",
                rate_card::RATE_CARD_PATH_ENV
            ),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone `{zone}`"),
            QuoteError::Overweight { grams, limit } => write!(
                f,
                "parcel of {grams}g exceeds the largest band of {limit}g for its zone"
            ),
        }
    }
}

impl Error for QuoteError {}

/// Price `parcel` against the deployed rate card.
///
/// The card is read afresh on every call, so operations can redeploy it under
/// a running service.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let result = price(parcel, &RateCard::load()?);
    record(parcel, &result);
    result
}

/// The pricing itself, separated from loading the card so it can be exercised
/// against a card in hand.
fn price(parcel: &Parcel, card: &RateCard) -> Result<Quote, QuoteError> {
    let band = card.band_for(&parcel.zone, parcel.weight_grams)?;
    let base_cents = band.cents;
    let surcharge_cents = pricing::surcharge_cents(&parcel.zone, parcel.weight_grams, base_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    })
}

/// Emit the diagnostic record for one quote.
///
/// A priced parcel logs at info with the total it was given; one that could
/// not be priced logs at warn with the reason, since that is what an operator
/// chasing a failed shipment needs to find.
fn record(parcel: &Parcel, result: &Result<Quote, QuoteError>) {
    match result {
        Ok(quote) => log::info!(
            target: "ratecard::quote",
            "quoted zone={} weight_grams={} total_cents={}",
            parcel.zone,
            parcel.weight_grams,
            quote.total_cents
        ),
        Err(error) => log::warn!(
            target: "ratecard::quote",
            "failed to quote zone={} weight_grams={}: {}",
            parcel.zone,
            parcel.weight_grams,
            error
        ),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn card() -> RateCard {
        RateCard::parse(SAMPLE).expect("sample card parses")
    }

    fn parcel(zone: &str, weight_grams: u32) -> Parcel {
        Parcel { weight_grams, zone: zone.to_string() }
    }

    #[test]
    fn a_light_domestic_parcel_is_priced_at_its_band() {
        let quote = price(&parcel("domestic", 100), &card()).unwrap();
        assert_eq!(
            quote,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn a_parcel_just_past_a_threshold_moves_up_a_band() {
        let quote = price(&parcel("domestic", 501), &card()).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
        assert_eq!(quote.total_cents, 899);
    }

    #[test]
    fn a_parcel_on_a_threshold_stays_in_the_lower_band() {
        let quote = price(&parcel("domestic", 500), &card()).unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn a_heavy_domestic_parcel_carries_the_flat_surcharge() {
        let quote = price(&parcel("domestic", 12_000), &card()).unwrap();
        assert_eq!(
            quote,
            Quote {
                base_cents: 1799,
                surcharge_cents: 500,
                total_cents: 2299,
                band_max_grams: 20000,
            }
        );
    }

    #[test]
    fn a_parcel_exactly_at_ten_kilos_is_not_yet_surcharged() {
        let quote = price(&parcel("domestic", 10_000), &card()).unwrap();
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn a_light_international_parcel_carries_the_uplift() {
        let quote = price(&parcel("international", 400), &card()).unwrap();
        assert_eq!(
            quote,
            Quote {
                base_cents: 1499,
                // 20% of 1499 is 299.8, rounded half-up to 300.
                surcharge_cents: 300,
                total_cents: 1799,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn a_heavy_international_parcel_carries_both_surcharges() {
        let quote = price(&parcel("international", 15_000), &card()).unwrap();
        assert_eq!(
            quote,
            Quote {
                base_cents: 4999,
                // 500 flat, plus 20% of 4999 rounded half-up to 1000.
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20000,
            }
        );
    }

    #[test]
    fn the_total_is_always_the_base_plus_the_surcharge() {
        for weight in [0, 499, 500, 501, 9_999, 10_000, 10_001, 19_999, 20_000] {
            for zone in ["domestic", "international"] {
                let quote = price(&parcel(zone, weight), &card()).unwrap();
                assert_eq!(
                    quote.total_cents,
                    quote.base_cents + quote.surcharge_cents,
                    "{zone} at {weight}g"
                );
            }
        }
    }

    #[test]
    fn a_zone_the_card_does_not_price_is_reported_back_verbatim() {
        assert_eq!(
            price(&parcel("lunar", 100), &card()).unwrap_err(),
            QuoteError::UnknownZone("lunar".to_string())
        );
    }

    #[test]
    fn a_parcel_beyond_the_zones_largest_band_is_overweight() {
        assert_eq!(
            price(&parcel("domestic", 25_000), &card()).unwrap_err(),
            QuoteError::Overweight { grams: 25_000, limit: 20_000 }
        );
    }

    #[test]
    fn each_zone_is_overweight_against_its_own_ceiling() {
        let narrow = RateCard::parse("domestic\t500\t599\ninternational\t20000\t4999\n").unwrap();
        assert_eq!(
            price(&parcel("domestic", 600), &narrow).unwrap_err(),
            QuoteError::Overweight { grams: 600, limit: 500 }
        );
        assert!(price(&parcel("international", 600), &narrow).is_ok());
    }

    #[test]
    fn an_unknown_zone_outranks_being_overweight() {
        // Nothing sensible can be said about a limit for a zone we do not price.
        assert_eq!(
            price(&parcel("lunar", 999_999), &card()).unwrap_err(),
            QuoteError::UnknownZone("lunar".to_string())
        );
    }

    #[test]
    fn errors_describe_themselves() {
        assert_eq!(
            QuoteError::MalformedRateCard { line: 7 }.to_string(),
            "malformed rate card at line 7"
        );
        assert_eq!(
            QuoteError::UnknownZone("lunar".to_string()).to_string(),
            "unknown zone `lunar`"
        );
        assert_eq!(
            QuoteError::Overweight { grams: 25_000, limit: 20_000 }.to_string(),
            "parcel of 25000g exceeds the largest band of 20000g for its zone"
        );
        assert!(QuoteError::RateCardUnavailable
            .to_string()
            .contains("RATECARD_PATH"));
    }

    #[test]
    fn quote_errors_are_std_errors() {
        fn as_std_error(error: QuoteError) -> Box<dyn Error> {
            Box::new(error)
        }
        assert!(as_std_error(QuoteError::RateCardUnavailable)
            .source()
            .is_none());
    }
}
