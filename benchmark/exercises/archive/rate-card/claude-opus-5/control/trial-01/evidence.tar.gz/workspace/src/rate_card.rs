//! Reading and interpreting the rate card that operations redeploys.
//!
//! The card is a tab-separated table of `zone`, `band_max_grams`, `cents`.
//! Operations edits it by hand, so parsing reports the 1-based number of any
//! offending line — counting comments and blanks, so the number matches what
//! an editor shows.

use std::collections::BTreeMap;
use std::env;
use std::fs;

use crate::QuoteError;

/// Environment variable naming the deployed rate card.
pub(crate) const RATE_CARD_PATH_ENV: &str = "RATECARD_PATH";

/// One priced weight band: everything up to and including `max_grams`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct Band {
    pub(crate) max_grams: u32,
    pub(crate) cents: u64,
}

/// The bands of every zone on the card, each zone's bands held in ascending
/// `max_grams` order regardless of how the file happened to list them.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub(crate) struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

impl RateCard {
    /// Read the card named by `RATECARD_PATH`.
    ///
    /// An unset, empty, missing or unreadable path is
    /// [`QuoteError::RateCardUnavailable`] — from a caller's point of view
    /// there is no card to price against, however it came to be missing.
    pub(crate) fn load() -> Result<Self, QuoteError> {
        let path = env::var_os(RATE_CARD_PATH_ENV).ok_or(QuoteError::RateCardUnavailable)?;
        if path.is_empty() {
            return Err(QuoteError::RateCardUnavailable);
        }
        let text = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
        Self::parse(&text)
    }

    /// Parse the card's text, rejecting the whole card on the first bad line.
    ///
    /// A half-understood card would silently misprice parcels, so a single
    /// unparseable line fails the lookup rather than being skipped.
    pub(crate) fn parse(text: &str) -> Result<Self, QuoteError> {
        let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

        for (index, line) in text.lines().enumerate() {
            let line_number = index + 1;
            let trimmed = line.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }

            let malformed = || QuoteError::MalformedRateCard { line: line_number };

            let fields: Vec<&str> = line.split('\t').collect();
            if fields.len() != 3 {
                return Err(malformed());
            }

            let zone = fields[0].trim();
            let max_grams: u32 = fields[1].trim().parse().map_err(|_| malformed())?;
            let cents: u64 = fields[2].trim().parse().map_err(|_| malformed())?;

            zones
                .entry(zone.to_string())
                .or_default()
                .push(Band { max_grams, cents });
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(RateCard { zones })
    }

    /// The band pricing `weight_grams` in `zone`: the first band, ascending,
    /// whose threshold reaches the parcel.
    pub(crate) fn band_for(&self, zone: &str, weight_grams: u32) -> Result<Band, QuoteError> {
        let bands = self
            .zones
            .get(zone)
            .filter(|bands| !bands.is_empty())
            .ok_or_else(|| QuoteError::UnknownZone(zone.to_string()))?;

        bands
            .iter()
            .copied()
            .find(|band| band.max_grams >= weight_grams)
            .ok_or_else(|| QuoteError::Overweight {
                grams: weight_grams,
                // Bands are sorted, so the last one is the zone's ceiling.
                limit: bands[bands.len() - 1].max_grams,
            })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799

international\t500\t1499
international\t20000\t4999
";

    fn sample() -> RateCard {
        RateCard::parse(SAMPLE).expect("sample card parses")
    }

    #[test]
    fn comments_and_blank_lines_are_ignored() {
        let card = sample();
        assert_eq!(card.zones.len(), 2);
        assert_eq!(card.zones["domestic"].len(), 3);
        assert_eq!(card.zones["international"].len(), 2);
    }

    #[test]
    fn an_empty_card_holds_no_zones() {
        let card = RateCard::parse("").expect("an empty card is well formed");
        assert_eq!(card, RateCard::default());
    }

    #[test]
    fn a_card_of_only_comments_and_blanks_holds_no_zones() {
        let card = RateCard::parse("# heading\n\n   \n# trailing\n").expect("well formed");
        assert_eq!(card, RateCard::default());
    }

    #[test]
    fn bands_are_ordered_ascending_however_the_file_lists_them() {
        let card = RateCard::parse("z\t20000\t1799\nz\t500\t599\nz\t2000\t899\n").unwrap();
        let thresholds: Vec<u32> = card.zones["z"].iter().map(|b| b.max_grams).collect();
        assert_eq!(thresholds, vec![500, 2000, 20000]);
    }

    #[test]
    fn the_first_band_reaching_the_parcel_prices_it() {
        let card = sample();
        assert_eq!(
            card.band_for("domestic", 1).unwrap(),
            Band { max_grams: 500, cents: 599 }
        );
        assert_eq!(
            card.band_for("domestic", 501).unwrap(),
            Band { max_grams: 2000, cents: 899 }
        );
    }

    #[test]
    fn a_parcel_exactly_on_a_threshold_stays_in_that_band() {
        let card = sample();
        assert_eq!(
            card.band_for("domestic", 500).unwrap(),
            Band { max_grams: 500, cents: 599 }
        );
        assert_eq!(
            card.band_for("domestic", 20000).unwrap(),
            Band { max_grams: 20000, cents: 1799 }
        );
    }

    #[test]
    fn a_weightless_parcel_takes_the_lowest_band() {
        let card = sample();
        assert_eq!(
            card.band_for("domestic", 0).unwrap(),
            Band { max_grams: 500, cents: 599 }
        );
    }

    #[test]
    fn a_zone_absent_from_the_card_is_unknown() {
        let card = sample();
        assert_eq!(
            card.band_for("lunar", 100).unwrap_err(),
            QuoteError::UnknownZone("lunar".to_string())
        );
    }

    #[test]
    fn zone_lookup_is_case_sensitive() {
        let card = sample();
        assert_eq!(
            card.band_for("Domestic", 100).unwrap_err(),
            QuoteError::UnknownZone("Domestic".to_string())
        );
    }

    #[test]
    fn a_parcel_past_the_largest_band_is_overweight_against_that_band() {
        let card = sample();
        assert_eq!(
            card.band_for("domestic", 20001).unwrap_err(),
            QuoteError::Overweight { grams: 20001, limit: 20000 }
        );
    }

    #[test]
    fn a_line_with_too_few_fields_is_malformed_at_its_own_number() {
        let text = "# heading\n\ndomestic\t500\t599\ndomestic\t2000\n";
        assert_eq!(
            RateCard::parse(text).unwrap_err(),
            QuoteError::MalformedRateCard { line: 4 }
        );
    }

    #[test]
    fn a_line_with_too_many_fields_is_malformed() {
        assert_eq!(
            RateCard::parse("domestic\t500\t599\textra\n").unwrap_err(),
            QuoteError::MalformedRateCard { line: 1 }
        );
    }

    #[test]
    fn space_separated_fields_are_not_tab_separated_fields() {
        assert_eq!(
            RateCard::parse("domestic 500 599\n").unwrap_err(),
            QuoteError::MalformedRateCard { line: 1 }
        );
    }

    #[test]
    fn an_unparseable_weight_is_malformed() {
        assert_eq!(
            RateCard::parse("# c\ndomestic\theavy\t599\n").unwrap_err(),
            QuoteError::MalformedRateCard { line: 2 }
        );
    }

    #[test]
    fn an_unparseable_price_is_malformed() {
        assert_eq!(
            RateCard::parse("domestic\t500\t5.99\n").unwrap_err(),
            QuoteError::MalformedRateCard { line: 1 }
        );
    }

    #[test]
    fn a_negative_number_is_malformed() {
        assert_eq!(
            RateCard::parse("domestic\t-500\t599\n").unwrap_err(),
            QuoteError::MalformedRateCard { line: 1 }
        );
    }

    #[test]
    fn the_first_offending_line_is_the_one_reported() {
        let text = "domestic\t500\t599\ndomestic\tbad\t899\ndomestic\talso\tbad\n";
        assert_eq!(
            RateCard::parse(text).unwrap_err(),
            QuoteError::MalformedRateCard { line: 2 }
        );
    }

    #[test]
    fn windows_line_endings_do_not_make_a_card_malformed() {
        let card = RateCard::parse("# zone\tmax\tcents\r\ndomestic\t500\t599\r\n")
            .expect("CRLF parses");
        assert_eq!(
            card.band_for("domestic", 10).unwrap(),
            Band { max_grams: 500, cents: 599 }
        );
    }

    #[test]
    fn padding_around_fields_is_tolerated() {
        let card = RateCard::parse("domestic \t 500 \t 599 \n").expect("padded fields parse");
        assert_eq!(
            card.band_for("domestic", 10).unwrap(),
            Band { max_grams: 500, cents: 599 }
        );
    }

    #[test]
    fn a_card_without_a_trailing_newline_parses() {
        let card = RateCard::parse("domestic\t500\t599").expect("parses");
        assert_eq!(
            card.band_for("domestic", 10).unwrap(),
            Band { max_grams: 500, cents: 599 }
        );
    }
}
