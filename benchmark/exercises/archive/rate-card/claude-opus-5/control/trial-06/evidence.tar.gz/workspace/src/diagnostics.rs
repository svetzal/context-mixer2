//! What the service can see of its own pricing.
//!
//! Every priced parcel leaves one record on stderr, in a key=value shape that
//! log collectors can split on.

use std::fmt;

/// One priced parcel, as it appears in the log.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct QuoteRecord<'a> {
    pub zone: &'a str,
    pub weight_grams: u32,
    pub total_cents: u64,
}

impl fmt::Display for QuoteRecord<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "ratecard.quote zone={} weight_grams={} total_cents={}",
            self.zone, self.weight_grams, self.total_cents
        )
    }
}

/// Write `record` where operators can see it.
pub fn emit(record: &QuoteRecord<'_>) {
    eprintln!("{record}");
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_record_names_the_zone_the_weight_and_the_total() {
        let record = QuoteRecord {
            zone: "international",
            weight_grams: 15_000,
            total_cents: 6499,
        };

        assert_eq!(
            record.to_string(),
            "ratecard.quote zone=international weight_grams=15000 total_cents=6499"
        );
    }

    #[test]
    fn emitting_a_record_is_safe_to_call() {
        emit(&QuoteRecord {
            zone: "domestic",
            weight_grams: 750,
            total_cents: 899,
        });
    }
}
