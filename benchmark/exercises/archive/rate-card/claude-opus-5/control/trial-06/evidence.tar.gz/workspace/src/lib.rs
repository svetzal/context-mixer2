//! Shipping quotes priced against a rate card that operations redeploys
//! without a code change.
//!
//! [`quote`] reads the card from the path in the `RATECARD_PATH` environment
//! variable on every call, so a redeployed card takes effect immediately.

pub mod diagnostics;
pub mod pricing;
pub mod rate_card;
pub mod zones;

use std::fmt;

use diagnostics::QuoteRecord;
use rate_card::RateCard;

/// A parcel awaiting a price.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The price of a parcel, broken out so operators can see how it was reached.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    /// The upper bound of the weight band the parcel priced into.
    pub band_max_grams: u32,
}

/// Why a parcel could not be priced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, or the file it names cannot be read.
    RateCardUnavailable,
    /// A line of the rate card is not three tab-separated fields, or its
    /// numbers do not parse. `line` is 1-based and counts every line in the
    /// file, including comments and blanks.
    MalformedRateCard { line: usize },
    /// The requested zone has no bands in the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable: set RATECARD_PATH to a readable rate card")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone `{zone}`")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel of {grams}g exceeds the zone limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Price `parcel` against the rate card named by `RATECARD_PATH`.
///
/// Emits a diagnostic record for every parcel it prices.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = RateCard::load_from_env()?;
    let quote = price(&card, parcel)?;

    diagnostics::emit(&QuoteRecord {
        zone: &parcel.zone,
        weight_grams: parcel.weight_grams,
        total_cents: quote.total_cents,
    });

    Ok(quote)
}

/// The pricing itself, against an already-loaded card.
fn price(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let band = card.band_for(&parcel.zone, parcel.weight_grams)?;
    let base_cents = band.cents;
    let surcharge_cents = pricing::surcharge_cents(base_cents, parcel.weight_grams, &parcel.zone);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn card() -> RateCard {
        RateCard::parse(CARD).expect("the sample card parses")
    }

    fn priced(zone: &str, weight_grams: u32) -> Result<Quote, QuoteError> {
        price(
            &card(),
            &Parcel {
                weight_grams,
                zone: zone.to_string(),
            },
        )
    }

    #[test]
    fn prices_into_the_first_band_that_covers_the_weight() {
        let quote = priced("domestic", 750).unwrap();

        assert_eq!(
            quote,
            Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2000,
            }
        );
    }

    #[test]
    fn a_weight_on_a_band_boundary_stays_in_that_band() {
        let quote = priced("domestic", 500).unwrap();

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn a_weightless_parcel_prices_into_the_smallest_band() {
        let quote = priced("domestic", 0).unwrap();

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn a_heavy_parcel_carries_the_heavy_surcharge() {
        let quote = priced("domestic", 15_000).unwrap();

        assert_eq!(
            quote,
            Quote {
                base_cents: 1799,
                surcharge_cents: 500,
                total_cents: 2299,
                band_max_grams: 20_000,
            }
        );
    }

    #[test]
    fn an_international_parcel_carries_the_international_surcharge() {
        let quote = priced("international", 750).unwrap();

        assert_eq!(
            quote,
            Quote {
                base_cents: 4999,
                surcharge_cents: 1000,
                total_cents: 5999,
                band_max_grams: 20_000,
            }
        );
    }

    #[test]
    fn surcharges_add_together() {
        let quote = priced("international", 15_000).unwrap();

        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 500 + 1000);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn a_zone_absent_from_the_card_is_unknown() {
        assert_eq!(
            priced("lunar", 100).unwrap_err(),
            QuoteError::UnknownZone("lunar".to_string())
        );
    }

    #[test]
    fn a_parcel_past_the_largest_band_is_overweight() {
        assert_eq!(
            priced("domestic", 20_001).unwrap_err(),
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            }
        );
    }

    #[test]
    fn the_overweight_limit_is_the_zones_own_largest_band() {
        let card = RateCard::parse("domestic\t500\t599\ninternational\t20000\t4999\n").unwrap();
        let parcel = Parcel {
            weight_grams: 600,
            zone: "domestic".to_string(),
        };

        assert_eq!(
            price(&card, &parcel).unwrap_err(),
            QuoteError::Overweight {
                grams: 600,
                limit: 500,
            }
        );
    }

    #[test]
    fn errors_read_as_sentences() {
        assert_eq!(
            QuoteError::MalformedRateCard { line: 7 }.to_string(),
            "malformed rate card at line 7"
        );
        assert_eq!(
            QuoteError::UnknownZone("lunar".to_string()).to_string(),
            "unknown zone `lunar`"
        );
        assert_eq!(
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            }
            .to_string(),
            "parcel of 20001g exceeds the zone limit of 20000g"
        );
        assert!(QuoteError::RateCardUnavailable
            .to_string()
            .contains("RATECARD_PATH"));
    }

    #[test]
    fn quote_errors_are_std_errors() {
        fn as_error(e: QuoteError) -> Box<dyn std::error::Error> {
            Box::new(e)
        }

        assert_eq!(
            as_error(QuoteError::RateCardUnavailable).to_string(),
            QuoteError::RateCardUnavailable.to_string()
        );
    }
}
