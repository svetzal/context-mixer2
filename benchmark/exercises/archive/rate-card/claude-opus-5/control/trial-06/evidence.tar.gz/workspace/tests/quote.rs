//! `quote` end to end, against a rate card on disk.
//!
//! `RATECARD_PATH` is process-wide, so these tests take a lock rather than
//! racing each other for it.

use std::env;
use std::io::Write;
use std::sync::{Mutex, MutexGuard, OnceLock};

use ratecard::{quote, Parcel, Quote, QuoteError};
use tempfile::NamedTempFile;

const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn env_lock() -> MutexGuard<'static, ()> {
    static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    LOCK.get_or_init(|| Mutex::new(()))
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
}

/// Run `body` with `RATECARD_PATH` pointing at a card holding `text`.
fn with_card<T>(text: &str, body: impl FnOnce() -> T) -> T {
    let _guard = env_lock();

    let mut file = NamedTempFile::new().expect("a temp file");
    file.write_all(text.as_bytes()).expect("writing the card");
    file.flush().expect("flushing the card");

    env::set_var("RATECARD_PATH", file.path());
    let outcome = body();
    env::remove_var("RATECARD_PATH");

    outcome
}

fn quote_for(zone: &str, weight_grams: u32) -> Result<Quote, QuoteError> {
    with_card(CARD, || {
        quote(&Parcel {
            weight_grams,
            zone: zone.to_string(),
        })
    })
}

#[test]
fn prices_a_domestic_parcel() {
    let quote = quote_for("domestic", 750).unwrap();

    assert_eq!(quote.base_cents, 899);
    assert_eq!(quote.surcharge_cents, 0);
    assert_eq!(quote.total_cents, 899);
    assert_eq!(quote.band_max_grams, 2000);
}

#[test]
fn prices_an_international_parcel_with_its_uplift() {
    let quote = quote_for("international", 400).unwrap();

    assert_eq!(quote.base_cents, 1499);
    assert_eq!(quote.surcharge_cents, 300);
    assert_eq!(quote.total_cents, 1799);
    assert_eq!(quote.band_max_grams, 500);
}

#[test]
fn prices_a_heavy_international_parcel_with_both_surcharges() {
    let quote = quote_for("international", 12_000).unwrap();

    assert_eq!(quote.base_cents, 4999);
    assert_eq!(quote.surcharge_cents, 1500);
    assert_eq!(quote.total_cents, 6499);
    assert_eq!(quote.band_max_grams, 20_000);
}

#[test]
fn rejects_an_unknown_zone() {
    assert_eq!(
        quote_for("lunar", 100).unwrap_err(),
        QuoteError::UnknownZone("lunar".to_string())
    );
}

#[test]
fn rejects_an_overweight_parcel() {
    assert_eq!(
        quote_for("domestic", 25_000).unwrap_err(),
        QuoteError::Overweight {
            grams: 25_000,
            limit: 20_000,
        }
    );
}

#[test]
fn rejects_a_malformed_card_by_line_number() {
    let text = "# zone\tband_max_grams\tcents\n\ndomestic\t500\t599\ndomestic\ttwo\t899\n";

    let outcome = with_card(text, || {
        quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
    });

    assert_eq!(
        outcome.unwrap_err(),
        QuoteError::MalformedRateCard { line: 4 }
    );
}

#[test]
fn reports_an_unset_path() {
    let _guard = env_lock();
    env::remove_var("RATECARD_PATH");

    let outcome = quote(&Parcel {
        weight_grams: 100,
        zone: "domestic".to_string(),
    });

    assert_eq!(outcome.unwrap_err(), QuoteError::RateCardUnavailable);
}

#[test]
fn reports_a_path_that_names_no_file() {
    let _guard = env_lock();
    env::set_var("RATECARD_PATH", "/nonexistent/ratecard.tsv");

    let outcome = quote(&Parcel {
        weight_grams: 100,
        zone: "domestic".to_string(),
    });
    env::remove_var("RATECARD_PATH");

    assert_eq!(outcome.unwrap_err(), QuoteError::RateCardUnavailable);
}

#[test]
fn rereads_the_card_so_a_redeploy_takes_effect() {
    let first = with_card("domestic\t500\t599\n", || {
        quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
    })
    .unwrap();

    let second = with_card("domestic\t500\t649\n", || {
        quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".to_string(),
        })
    })
    .unwrap();

    assert_eq!(first.total_cents, 599);
    assert_eq!(second.total_cents, 649);
}
