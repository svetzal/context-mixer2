//! Reading the rate card operations maintains.
//!
//! The card is tab-separated, one band per line: zone, band ceiling in grams,
//! price in cents. Empty lines and lines beginning with `#` are ignored.

use std::collections::HashMap;
use std::env;
use std::fs;

use crate::QuoteError;

/// The environment variable naming the rate card on disk.
pub const PATH_VAR: &str = "RATECARD_PATH";

/// One priced weight band within a zone.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Band {
    /// The heaviest parcel this band covers.
    pub max_grams: u32,
    pub cents: u64,
}

/// Every zone's bands, each zone's held in ascending order of `max_grams`.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct RateCard {
    zones: HashMap<String, Vec<Band>>,
}

impl RateCard {
    /// Read the card from the path in `RATECARD_PATH`.
    pub fn load_from_env() -> Result<RateCard, QuoteError> {
        let path = env::var_os(PATH_VAR).ok_or(QuoteError::RateCardUnavailable)?;
        let text = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

        RateCard::parse(&text)
    }

    /// Parse the card, rejecting the first line that does not hold three
    /// tab-separated fields with parseable numbers.
    pub fn parse(text: &str) -> Result<RateCard, QuoteError> {
        let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

        for (index, line) in text.lines().enumerate() {
            let line_number = index + 1;
            if is_ignorable(line) {
                continue;
            }

            let (zone, band) =
                parse_band(line).ok_or(QuoteError::MalformedRateCard { line: line_number })?;
            zones.entry(zone.to_string()).or_default().push(band);
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(RateCard { zones })
    }

    /// The band a parcel of `weight_grams` prices into within `zone`.
    pub fn band_for(&self, zone: &str, weight_grams: u32) -> Result<Band, QuoteError> {
        let bands = self
            .zones
            .get(zone)
            .filter(|bands| !bands.is_empty())
            .ok_or_else(|| QuoteError::UnknownZone(zone.to_string()))?;

        bands
            .iter()
            .copied()
            .find(|band| weight_grams <= band.max_grams)
            .ok_or(QuoteError::Overweight {
                grams: weight_grams,
                limit: bands
                    .last()
                    .expect("a zone's bands are never empty")
                    .max_grams,
            })
    }
}

/// Comments and blanks carry no band.
fn is_ignorable(line: &str) -> bool {
    line.trim().is_empty() || line.starts_with('#')
}

/// `None` when the line is not a well-formed band.
fn parse_band(line: &str) -> Option<(&str, Band)> {
    let mut fields = line.split('\t');
    let zone = fields.next()?;
    let max_grams = fields.next()?.parse().ok()?;
    let cents = fields.next()?.parse().ok()?;

    if fields.next().is_some() || zone.is_empty() {
        return None;
    }

    Some((zone, Band { max_grams, cents }))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reads_a_band_per_line() {
        let card = RateCard::parse("domestic\t500\t599\ndomestic\t2000\t899\n").unwrap();

        assert_eq!(
            card.band_for("domestic", 100).unwrap(),
            Band {
                max_grams: 500,
                cents: 599
            }
        );
        assert_eq!(
            card.band_for("domestic", 1500).unwrap(),
            Band {
                max_grams: 2000,
                cents: 899
            }
        );
    }

    #[test]
    fn ignores_comments_and_blank_lines() {
        let card =
            RateCard::parse("# zone\tband_max_grams\tcents\n\n   \ndomestic\t500\t599\n").unwrap();

        assert_eq!(card.band_for("domestic", 500).unwrap().cents, 599);
    }

    #[test]
    fn tolerates_a_card_without_a_trailing_newline() {
        let card = RateCard::parse("domestic\t500\t599").unwrap();

        assert_eq!(card.band_for("domestic", 1).unwrap().cents, 599);
    }

    #[test]
    fn orders_bands_however_the_card_lists_them() {
        let card = RateCard::parse("domestic\t20000\t1799\ndomestic\t500\t599\n").unwrap();

        assert_eq!(card.band_for("domestic", 100).unwrap().max_grams, 500);
    }

    #[test]
    fn counts_every_line_when_reporting_a_malformed_one() {
        let text = "# header\n\ndomestic\t500\t599\ndomestic\t2000\n";

        assert_eq!(
            RateCard::parse(text).unwrap_err(),
            QuoteError::MalformedRateCard { line: 4 }
        );
    }

    #[test]
    fn rejects_a_line_with_too_many_fields() {
        assert_eq!(
            RateCard::parse("domestic\t500\t599\textra\n").unwrap_err(),
            QuoteError::MalformedRateCard { line: 1 }
        );
    }

    #[test]
    fn rejects_numbers_that_do_not_parse() {
        assert_eq!(
            RateCard::parse("domestic\theavy\t599\n").unwrap_err(),
            QuoteError::MalformedRateCard { line: 1 }
        );
        assert_eq!(
            RateCard::parse("domestic\t500\tfree\n").unwrap_err(),
            QuoteError::MalformedRateCard { line: 1 }
        );
        assert_eq!(
            RateCard::parse("domestic\t-500\t599\n").unwrap_err(),
            QuoteError::MalformedRateCard { line: 1 }
        );
    }

    #[test]
    fn rejects_a_space_separated_line() {
        assert_eq!(
            RateCard::parse("domestic 500 599\n").unwrap_err(),
            QuoteError::MalformedRateCard { line: 1 }
        );
    }

    #[test]
    fn reports_the_first_malformed_line() {
        assert_eq!(
            RateCard::parse("bad\nalso bad\n").unwrap_err(),
            QuoteError::MalformedRateCard { line: 1 }
        );
    }

    #[test]
    fn an_absent_zone_is_unknown() {
        let card = RateCard::parse("domestic\t500\t599\n").unwrap();

        assert_eq!(
            card.band_for("international", 100).unwrap_err(),
            QuoteError::UnknownZone("international".to_string())
        );
    }

    #[test]
    fn an_empty_card_knows_no_zones() {
        let card = RateCard::parse("").unwrap();

        assert_eq!(
            card.band_for("domestic", 100).unwrap_err(),
            QuoteError::UnknownZone("domestic".to_string())
        );
    }

    #[test]
    fn a_parcel_past_the_largest_band_is_overweight() {
        let card = RateCard::parse("domestic\t500\t599\ndomestic\t2000\t899\n").unwrap();

        assert_eq!(
            card.band_for("domestic", 2001).unwrap_err(),
            QuoteError::Overweight {
                grams: 2001,
                limit: 2000,
            }
        );
    }
}
