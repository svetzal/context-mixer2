//! The surcharges that ride on top of a band's price.

/// Parcels strictly heavier than this carry the heavy surcharge.
pub const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;

/// What a heavy parcel adds.
pub const HEAVY_SURCHARGE_CENTS: u64 = 500;

/// The zone that carries the international uplift.
pub const INTERNATIONAL_ZONE: &str = "international";

/// The international uplift, as a percentage of the band price.
pub const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

/// Every surcharge a parcel earns, added together.
pub fn surcharge_cents(base_cents: u64, weight_grams: u32, zone: &str) -> u64 {
    heavy_surcharge_cents(weight_grams) + international_surcharge_cents(base_cents, zone)
}

fn heavy_surcharge_cents(weight_grams: u32) -> u64 {
    if weight_grams > HEAVY_THRESHOLD_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    }
}

fn international_surcharge_cents(base_cents: u64, zone: &str) -> u64 {
    if zone != INTERNATIONAL_ZONE {
        return 0;
    }

    percent_of_rounded_half_up(base_cents, INTERNATIONAL_SURCHARGE_PERCENT)
}

/// `percent` of `cents`, rounded half-up to the whole cent.
fn percent_of_rounded_half_up(cents: u64, percent: u64) -> u64 {
    (cents * percent + 50) / 100
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_light_domestic_parcel_carries_nothing() {
        assert_eq!(surcharge_cents(899, 2000, "domestic"), 0);
    }

    #[test]
    fn the_heavy_surcharge_starts_strictly_above_the_threshold() {
        assert_eq!(surcharge_cents(1799, HEAVY_THRESHOLD_GRAMS, "domestic"), 0);
        assert_eq!(
            surcharge_cents(1799, HEAVY_THRESHOLD_GRAMS + 1, "domestic"),
            HEAVY_SURCHARGE_CENTS
        );
    }

    #[test]
    fn international_adds_a_fifth_of_the_band_price() {
        assert_eq!(surcharge_cents(1000, 100, INTERNATIONAL_ZONE), 200);
    }

    #[test]
    fn the_international_uplift_rounds_half_up() {
        // 1499 * 0.2 = 299.8
        assert_eq!(percent_of_rounded_half_up(1499, 20), 300);
        // 4999 * 0.2 = 999.8
        assert_eq!(percent_of_rounded_half_up(4999, 20), 1000);
        // 1002 * 0.2 = 200.4
        assert_eq!(percent_of_rounded_half_up(1002, 20), 200);
        // 1252 * 0.2 = 250.4 — down; 1253 * 0.2 = 250.6 — up
        assert_eq!(percent_of_rounded_half_up(1252, 20), 250);
        assert_eq!(percent_of_rounded_half_up(1253, 20), 251);
        // An exact half rounds up: 1005 * 0.5 = 502.5
        assert_eq!(percent_of_rounded_half_up(1005, 50), 503);
    }

    #[test]
    fn surcharges_add_together() {
        assert_eq!(
            surcharge_cents(4999, 15_000, INTERNATIONAL_ZONE),
            HEAVY_SURCHARGE_CENTS + 1000
        );
    }

    #[test]
    fn an_unrecognised_zone_carries_no_uplift() {
        assert_eq!(surcharge_cents(4999, 100, "interstellar"), 0);
    }
}
