//! Shipping quotes for the fulfilment service.
//!
//! Operations maintains a rate card on disk and redeploys it without a code
//! change; this crate reads that card — from the path in `RATECARD_PATH` — and
//! turns a parcel into a quote.

pub mod diagnostics;
pub mod rate_card;
pub mod zones;

use std::fs;

use diagnostics::{Outcome, QuoteRecord};
use rate_card::{Band, RateCard};

/// The environment variable naming the rate card on disk.
pub const RATE_CARD_PATH_VAR: &str = "RATECARD_PATH";

/// Weight above which a parcel attracts the heavy surcharge.
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;

/// What the heavy surcharge costs.
const HEAVY_SURCHARGE_CENTS: u64 = 500;

/// The zone that attracts the international surcharge.
const INTERNATIONAL_ZONE: &str = "international";

/// The international surcharge, as a percentage of the base rate.
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

/// A parcel to be priced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// What shipping a parcel costs, and the band it was priced in.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Why a parcel could not be priced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, or the file it names cannot be read.
    RateCardUnavailable,
    /// The card has a line that is not three tab-separated, parseable fields.
    MalformedRateCard { line: usize },
    /// The card does not price the requested zone.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable: set {RATE_CARD_PATH_VAR} to a readable file")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => write!(f, "rate card does not price zone `{zone}`"),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel of {grams} g is over the {limit} g limit for its zone")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Price `parcel` against the rate card named by `RATECARD_PATH`.
///
/// Emits one [`QuoteRecord`] per call, whether or not the parcel could be
/// priced.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let result = load_rate_card().and_then(|card| price(parcel, &card));

    diagnostics::emit(&QuoteRecord {
        zone: parcel.zone.clone(),
        weight_grams: parcel.weight_grams,
        outcome: match &result {
            Ok(quote) => Outcome::Quoted { total_cents: quote.total_cents },
            Err(error) => Outcome::Failed { reason: error.to_string() },
        },
    });

    result
}

fn load_rate_card() -> Result<RateCard, QuoteError> {
    let path = std::env::var_os(RATE_CARD_PATH_VAR).ok_or(QuoteError::RateCardUnavailable)?;
    let text = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;

    RateCard::parse(&text)
        .map_err(|malformed| QuoteError::MalformedRateCard { line: malformed.line })
}

/// Price a parcel against an already-read card.
fn price(parcel: &Parcel, card: &RateCard) -> Result<Quote, QuoteError> {
    let bands = card
        .bands(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = matching_band(bands, parcel.weight_grams).ok_or_else(|| QuoteError::Overweight {
        grams: parcel.weight_grams,
        limit: bands.last().map_or(0, |band| band.max_grams),
    })?;

    let base_cents = band.cents;
    let surcharge_cents = surcharges(parcel, base_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

/// The first band, ascending, that can carry `weight_grams`.
fn matching_band(bands: &[Band], weight_grams: u32) -> Option<Band> {
    bands.iter().copied().find(|band| band.max_grams >= weight_grams)
}

fn surcharges(parcel: &Parcel, base_cents: u64) -> u64 {
    let mut cents = 0;

    if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        cents += HEAVY_SURCHARGE_CENTS;
    }
    if parcel.zone == INTERNATIONAL_ZONE {
        cents += percent_of(base_cents, INTERNATIONAL_SURCHARGE_PERCENT);
    }

    cents
}

/// `percent` of `cents`, rounded half-up to the cent.
fn percent_of(cents: u64, percent: u64) -> u64 {
    (cents * percent + 50) / 100
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
                          domestic\t500\t599\n\
                          domestic\t2000\t899\n\
                          domestic\t20000\t1799\n\
                          international\t500\t1499\n\
                          international\t20000\t4999\n";

    fn sample_card() -> RateCard {
        RateCard::parse(SAMPLE).expect("sample card parses")
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel { weight_grams, zone: zone.to_string() }
    }

    fn priced(weight_grams: u32, zone: &str) -> Quote {
        price(&parcel(weight_grams, zone), &sample_card()).expect("parcel is priceable")
    }

    fn refused(weight_grams: u32, zone: &str) -> QuoteError {
        price(&parcel(weight_grams, zone), &sample_card()).expect_err("parcel is not priceable")
    }

    #[test]
    fn prices_in_the_first_band_that_can_carry_the_parcel() {
        let quote = priced(750, "domestic");

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn a_parcel_exactly_on_a_threshold_stays_in_that_band() {
        let quote = priced(500, "domestic");

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn a_parcel_one_gram_over_a_threshold_moves_up_a_band() {
        let quote = priced(501, "domestic");

        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn a_weightless_parcel_prices_in_the_smallest_band() {
        let quote = priced(0, "domestic");

        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn a_light_domestic_parcel_carries_no_surcharge() {
        let quote = priced(750, "domestic");

        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
    }

    #[test]
    fn weight_over_ten_kilos_adds_the_heavy_surcharge() {
        let quote = priced(10_001, "domestic");

        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn weight_exactly_ten_kilos_is_not_heavy() {
        let quote = priced(10_000, "domestic");

        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_a_fifth_of_the_base_rate() {
        let quote = priced(400, "international");

        // 20% of 1499 is 299.8, rounded half-up.
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn a_heavy_international_parcel_pays_both_surcharges() {
        let quote = priced(15_000, "international");

        // 20% of 4999 is 999.8, rounded half-up, plus the 500 heavy charge.
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20_000);
    }

    #[test]
    fn the_total_is_always_the_base_plus_the_surcharges() {
        for (weight, zone) in [(0, "domestic"), (750, "domestic"), (10_001, "domestic"), (15_000, "international")] {
            let quote = priced(weight, zone);

            assert_eq!(quote.total_cents, quote.base_cents + quote.surcharge_cents);
        }
    }

    #[test]
    fn a_percentage_of_a_half_cent_rounds_up() {
        assert_eq!(percent_of(1499, 20), 300);
        assert_eq!(percent_of(5, 50), 3);
        assert_eq!(percent_of(0, 20), 0);
        assert_eq!(percent_of(1000, 20), 200);
    }

    #[test]
    fn an_unpriced_zone_is_refused_by_name() {
        assert_eq!(refused(750, "lunar"), QuoteError::UnknownZone("lunar".to_string()));
    }

    #[test]
    fn zone_matching_is_exact() {
        assert_eq!(
            refused(750, "Domestic"),
            QuoteError::UnknownZone("Domestic".to_string())
        );
    }

    #[test]
    fn a_parcel_over_the_largest_band_is_overweight() {
        assert_eq!(
            refused(20_001, "domestic"),
            QuoteError::Overweight { grams: 20_001, limit: 20_000 }
        );
    }

    #[test]
    fn the_overweight_limit_is_the_zones_own_largest_band() {
        let card = RateCard::parse("domestic\t20000\t1799\nexpress\t1000\t999\n")
            .expect("card parses");

        assert_eq!(
            price(&parcel(5_000, "express"), &card),
            Err(QuoteError::Overweight { grams: 5_000, limit: 1_000 })
        );
    }

    #[test]
    fn errors_describe_themselves() {
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "rate card unavailable: set RATECARD_PATH to a readable file"
        );
        assert_eq!(
            QuoteError::MalformedRateCard { line: 4 }.to_string(),
            "malformed rate card at line 4"
        );
        assert_eq!(
            QuoteError::UnknownZone("lunar".to_string()).to_string(),
            "rate card does not price zone `lunar`"
        );
        assert_eq!(
            QuoteError::Overweight { grams: 25_000, limit: 20_000 }.to_string(),
            "parcel of 25000 g is over the 20000 g limit for its zone"
        );
    }

    #[test]
    fn errors_are_usable_as_std_errors() {
        fn boxed(error: QuoteError) -> Box<dyn std::error::Error> {
            Box::new(error)
        }

        assert_eq!(
            boxed(QuoteError::RateCardUnavailable).to_string(),
            QuoteError::RateCardUnavailable.to_string()
        );
    }
}
