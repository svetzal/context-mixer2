//! Reading the operator-maintained rate card.
//!
//! The card is tab-separated, one band per line: `zone`, `band_max_grams`,
//! `cents`. Blank lines and lines beginning with `#` are ignored; every other
//! line must carry exactly three parseable fields.

use std::collections::BTreeMap;

/// One priced weight band within a zone.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Band {
    pub max_grams: u32,
    pub cents: u64,
}

/// A line the card could not be read from, by 1-based line number.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct MalformedLine {
    pub line: usize,
}

/// Every zone's bands, each zone's bands held in ascending `max_grams`.
#[derive(Debug, Default, Clone, PartialEq, Eq)]
pub struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

impl RateCard {
    /// Parse a whole card, failing on the first line that is not three
    /// tab-separated fields with parseable numbers.
    pub fn parse(text: &str) -> Result<Self, MalformedLine> {
        let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

        for (index, raw) in text.lines().enumerate() {
            let line = index + 1;
            let content = raw.trim_end_matches('\r');
            let trimmed = content.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') {
                continue;
            }

            let (zone, band) = parse_band(content).ok_or(MalformedLine { line })?;
            zones.entry(zone).or_default().push(band);
        }

        for bands in zones.values_mut() {
            bands.sort_by_key(|band| band.max_grams);
        }

        Ok(RateCard { zones })
    }

    /// The bands for `zone` in ascending order, or `None` if the card does not
    /// price that zone at all.
    pub fn bands(&self, zone: &str) -> Option<&[Band]> {
        self.zones
            .get(zone)
            .map(Vec::as_slice)
            .filter(|bands| !bands.is_empty())
    }
}

fn parse_band(content: &str) -> Option<(String, Band)> {
    let mut fields = content.split('\t');
    let zone = fields.next()?.trim();
    let max_grams = fields.next()?.trim();
    let cents = fields.next()?.trim();
    if fields.next().is_some() || zone.is_empty() {
        return None;
    }

    Some((
        zone.to_string(),
        Band {
            max_grams: max_grams.parse().ok()?,
            cents: cents.parse().ok()?,
        },
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
                          domestic\t500\t599\n\
                          domestic\t2000\t899\n\
                          domestic\t20000\t1799\n\
                          \n\
                          international\t500\t1499\n\
                          international\t20000\t4999\n";

    #[test]
    fn reads_every_band_of_a_zone() {
        let card = RateCard::parse(SAMPLE).expect("sample card parses");

        assert_eq!(
            card.bands("domestic"),
            Some(
                [
                    Band { max_grams: 500, cents: 599 },
                    Band { max_grams: 2000, cents: 899 },
                    Band { max_grams: 20000, cents: 1799 },
                ]
                .as_slice()
            )
        );
    }

    #[test]
    fn skips_comments_and_blank_lines() {
        let card = RateCard::parse("\n# only a comment\n\t\ndomestic\t500\t599\n")
            .expect("decorative lines are ignored");

        assert_eq!(card.bands("domestic").map(<[Band]>::len), Some(1));
    }

    #[test]
    fn holds_bands_ascending_however_the_card_lists_them() {
        let card = RateCard::parse("domestic\t20000\t1799\ndomestic\t500\t599\n")
            .expect("out-of-order bands parse");

        let maxima: Vec<u32> = card
            .bands("domestic")
            .expect("domestic is priced")
            .iter()
            .map(|band| band.max_grams)
            .collect();
        assert_eq!(maxima, vec![500, 20000]);
    }

    #[test]
    fn unpriced_zone_has_no_bands() {
        let card = RateCard::parse(SAMPLE).expect("sample card parses");

        assert_eq!(card.bands("lunar"), None);
    }

    #[test]
    fn too_few_fields_names_the_line() {
        let err = RateCard::parse("domestic\t500\t599\ndomestic\t2000\n")
            .expect_err("a two-field line is malformed");

        assert_eq!(err, MalformedLine { line: 2 });
    }

    #[test]
    fn too_many_fields_names_the_line() {
        let err = RateCard::parse("domestic\t500\t599\t\n")
            .expect_err("a four-field line is malformed");

        assert_eq!(err, MalformedLine { line: 1 });
    }

    #[test]
    fn unparseable_numbers_name_the_line() {
        let grams = RateCard::parse("domestic\theavy\t599\n").expect_err("grams must parse");
        let cents = RateCard::parse("domestic\t500\tfree\n").expect_err("cents must parse");

        assert_eq!(grams, MalformedLine { line: 1 });
        assert_eq!(cents, MalformedLine { line: 1 });
    }

    #[test]
    fn line_numbers_count_comments_and_blanks() {
        let err = RateCard::parse("# header\n\ndomestic\t500\t599\noops\n")
            .expect_err("the fourth line is malformed");

        assert_eq!(err, MalformedLine { line: 4 });
    }

    #[test]
    fn negative_numbers_are_malformed() {
        let err = RateCard::parse("domestic\t-500\t599\n").expect_err("grams cannot be negative");

        assert_eq!(err, MalformedLine { line: 1 });
    }

    #[test]
    fn space_separated_fields_are_malformed() {
        let err =
            RateCard::parse("domestic 500 599\n").expect_err("the card is tab-separated only");

        assert_eq!(err, MalformedLine { line: 1 });
    }

    #[test]
    fn an_empty_card_prices_nothing() {
        let card = RateCard::parse("").expect("an empty card is well-formed");

        assert_eq!(card.bands("domestic"), None);
    }
}
