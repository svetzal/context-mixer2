# ratecard

Shipping quotes for the fulfilment service.

Warehouse operators price outbound parcels against a rate card that operations
maintains and redeploys without a code change. This crate owns reading that card
and turning a parcel into a quote.

## Using it

`quote` reads the card named by the `RATECARD_PATH` environment variable, so
operations can redeploy pricing without a release.

```rust
use ratecard::{quote, Parcel};

let parcel = Parcel { weight_grams: 750, zone: "domestic".to_string() };
let priced = quote(&parcel)?;
assert_eq!(priced.total_cents, priced.base_cents + priced.surcharge_cents);
```

The card is tab-separated — `zone`, `band_max_grams`, `cents` — one band per
line, ascending or not. Blank lines and `#` comments are ignored; anything else
that is not three parseable fields fails the whole card, by line number.

## Observability

Every call emits one `diagnostics::QuoteRecord` carrying the zone, the weight,
and either the total or the reason it was refused. Records go to stderr unless
the host takes them over:

```rust
ratecard::diagnostics::set_sink(Box::new(|record| tracing::info!("{record}")));
```

## Development

```bash
cargo test
```
