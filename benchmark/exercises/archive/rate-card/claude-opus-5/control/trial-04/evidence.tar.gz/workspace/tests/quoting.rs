//! End-to-end quoting: a rate card on disk, `RATECARD_PATH`, and the
//! diagnostics that come out the other side.

use std::io::Write;
use std::sync::{Arc, Mutex, MutexGuard};

use ratecard::diagnostics::{Outcome, QuoteRecord};
use ratecard::{quote, Parcel, Quote, QuoteError, RATE_CARD_PATH_VAR};

const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799

international\t500\t1499
international\t20000\t4999
";

/// The environment and the diagnostics sink are process-wide, so tests that
/// touch either take turns.
fn exclusive() -> MutexGuard<'static, ()> {
    static LOCK: Mutex<()> = Mutex::new(());
    LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner())
}

/// Point `RATECARD_PATH` at a card holding `contents` and quote `parcel`,
/// collecting whatever diagnostics the call emits.
fn quoting(contents: &str, parcel: &Parcel) -> (Result<Quote, QuoteError>, Vec<QuoteRecord>) {
    let mut card = tempfile::NamedTempFile::new().expect("a temporary card file");
    card.write_all(contents.as_bytes()).expect("card is written");
    card.flush().expect("card is flushed");

    at_path(Some(card.path()), parcel)
}

/// Quote `parcel` with `RATECARD_PATH` set to `path`, or unset if `None`.
fn at_path(
    path: Option<&std::path::Path>,
    parcel: &Parcel,
) -> (Result<Quote, QuoteError>, Vec<QuoteRecord>) {
    let _guard = exclusive();

    let previous = std::env::var_os(RATE_CARD_PATH_VAR);
    match path {
        Some(path) => std::env::set_var(RATE_CARD_PATH_VAR, path),
        None => std::env::remove_var(RATE_CARD_PATH_VAR),
    }

    let records = Arc::new(Mutex::new(Vec::new()));
    let collected = Arc::clone(&records);
    ratecard::diagnostics::set_sink(Box::new(move |record: &QuoteRecord| {
        collected.lock().expect("sink is uncontended").push(record.clone());
    }));

    let result = quote(parcel);

    ratecard::diagnostics::clear_sink();
    match previous {
        Some(value) => std::env::set_var(RATE_CARD_PATH_VAR, value),
        None => std::env::remove_var(RATE_CARD_PATH_VAR),
    }

    let emitted = records.lock().expect("sink is uncontended").clone();
    (result, emitted)
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel { weight_grams, zone: zone.to_string() }
}

#[test]
fn prices_a_domestic_parcel_from_the_card_on_disk() {
    let (result, _) = quoting(SAMPLE_CARD, &parcel(750, "domestic"));

    assert_eq!(
        result,
        Ok(Quote {
            base_cents: 899,
            surcharge_cents: 0,
            total_cents: 899,
            band_max_grams: 2000,
        })
    );
}

#[test]
fn prices_a_heavy_international_parcel_with_both_surcharges() {
    let (result, _) = quoting(SAMPLE_CARD, &parcel(12_000, "international"));

    assert_eq!(
        result,
        Ok(Quote {
            base_cents: 4999,
            surcharge_cents: 1500,
            total_cents: 6499,
            band_max_grams: 20_000,
        })
    );
}

#[test]
fn refuses_a_zone_the_card_does_not_price() {
    let (result, _) = quoting(SAMPLE_CARD, &parcel(750, "lunar"));

    assert_eq!(result, Err(QuoteError::UnknownZone("lunar".to_string())));
}

#[test]
fn refuses_a_parcel_over_the_zones_largest_band() {
    let (result, _) = quoting(SAMPLE_CARD, &parcel(25_000, "domestic"));

    assert_eq!(
        result,
        Err(QuoteError::Overweight { grams: 25_000, limit: 20_000 })
    );
}

#[test]
fn refuses_to_quote_with_no_rate_card_path_set() {
    let (result, _) = at_path(None, &parcel(750, "domestic"));

    assert_eq!(result, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn refuses_to_quote_when_the_card_is_missing_from_disk() {
    let missing = std::env::temp_dir().join("ratecard-no-such-card.tsv");
    assert!(!missing.exists(), "the fixture path must not exist");

    let (result, _) = at_path(Some(&missing), &parcel(750, "domestic"));

    assert_eq!(result, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn refuses_to_quote_when_the_path_is_a_directory() {
    let directory = tempfile::tempdir().expect("a temporary directory");

    let (result, _) = at_path(Some(directory.path()), &parcel(750, "domestic"));

    assert_eq!(result, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn refuses_a_malformed_card_by_line_number() {
    let card = "# zone\tband_max_grams\tcents\n\
                domestic\t500\t599\n\
                \n\
                domestic\tvery heavy\t1799\n";

    let (result, _) = quoting(card, &parcel(400, "domestic"));

    assert_eq!(result, Err(QuoteError::MalformedRateCard { line: 4 }));
}

#[test]
fn a_malformed_card_is_refused_even_for_a_priceable_zone() {
    let card = "domestic\t500\t599\ninternational\t500\n";

    let (result, _) = quoting(card, &parcel(400, "domestic"));

    assert_eq!(result, Err(QuoteError::MalformedRateCard { line: 2 }));
}

#[test]
fn every_quote_is_observable() {
    let (_, records) = quoting(SAMPLE_CARD, &parcel(750, "domestic"));

    assert_eq!(
        records,
        vec![QuoteRecord {
            zone: "domestic".to_string(),
            weight_grams: 750,
            outcome: Outcome::Quoted { total_cents: 899 },
        }]
    );
}

#[test]
fn a_refused_quote_is_observable_too() {
    let (_, records) = quoting(SAMPLE_CARD, &parcel(750, "lunar"));

    let [record] = records.as_slice() else {
        panic!("expected exactly one record, got {records:?}");
    };
    assert_eq!(record.zone, "lunar");
    assert_eq!(record.weight_grams, 750);
    assert!(
        matches!(&record.outcome, Outcome::Failed { reason } if reason.contains("lunar")),
        "record should carry the reason: {record:?}"
    );
}
