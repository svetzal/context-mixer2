//! Observability for quoting.
//!
//! Every call to [`crate::quote`] emits one [`QuoteRecord`]. By default records
//! go to stderr; a host that already has a logging system can take them over
//! with [`set_sink`].

use std::sync::{Mutex, MutexGuard, OnceLock};

/// What a quote call did, as seen from outside.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Outcome {
    /// The parcel was priced, at this total.
    Quoted { total_cents: u64 },
    /// The parcel could not be priced, for this reason.
    Failed { reason: String },
}

/// One quote call: the parcel that was asked about and what came back.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct QuoteRecord {
    pub zone: String,
    pub weight_grams: u32,
    pub outcome: Outcome,
}

impl std::fmt::Display for QuoteRecord {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "ratecard.quote zone={} weight_grams={}",
            self.zone, self.weight_grams
        )?;
        match &self.outcome {
            Outcome::Quoted { total_cents } => write!(f, " total_cents={total_cents}"),
            Outcome::Failed { reason } => write!(f, " error={reason:?}"),
        }
    }
}

/// Somewhere for records to go.
pub type Sink = Box<dyn Fn(&QuoteRecord) + Send + Sync + 'static>;

fn installed() -> MutexGuard<'static, Option<Sink>> {
    static SINK: OnceLock<Mutex<Option<Sink>>> = OnceLock::new();
    SINK.get_or_init(|| Mutex::new(None))
        // A sink that panicked must not silence every later quote.
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
}

/// Route records to `sink` instead of stderr, returning whatever it replaced.
pub fn set_sink(sink: Sink) -> Option<Sink> {
    installed().replace(sink)
}

/// Route records back to stderr, returning whatever sink was installed.
pub fn clear_sink() -> Option<Sink> {
    installed().take()
}

pub(crate) fn emit(record: &QuoteRecord) {
    match installed().as_ref() {
        Some(sink) => sink(record),
        None => eprintln!("{record}"),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_quoted_record_reads_as_zone_weight_and_total() {
        let record = QuoteRecord {
            zone: "domestic".to_string(),
            weight_grams: 750,
            outcome: Outcome::Quoted { total_cents: 899 },
        };

        assert_eq!(
            record.to_string(),
            "ratecard.quote zone=domestic weight_grams=750 total_cents=899"
        );
    }

    #[test]
    fn a_failed_record_reads_as_zone_weight_and_reason() {
        let record = QuoteRecord {
            zone: "lunar".to_string(),
            weight_grams: 750,
            outcome: Outcome::Failed { reason: "unknown zone".to_string() },
        };

        assert_eq!(
            record.to_string(),
            "ratecard.quote zone=lunar weight_grams=750 error=\"unknown zone\""
        );
    }
}
