//! Shipping quotes for the fulfilment service.
//!
//! A parcel is priced against the rate card named by the `RATECARD_PATH`
//! environment variable, which operations redeploys without a code change.

mod diagnostics;
mod rate_card;
pub mod zones;

use std::fmt;

use diagnostics::QuoteRecord;
use rate_card::RateCard;

/// The environment variable naming the rate card to price against.
pub const RATECARD_PATH_ENV: &str = "RATECARD_PATH";

/// Parcels heavier than this carry the heavy-parcel surcharge.
const HEAVY_ABOVE_GRAMS: u32 = 10_000;

/// What the heavy-parcel surcharge adds.
const HEAVY_SURCHARGE_CENTS: u64 = 500;

/// The zone that carries a percentage surcharge on the base rate.
const INTERNATIONAL_ZONE: &str = "international";

/// What the international zone adds, as a percentage of the base rate.
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

/// A parcel awaiting a price.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// What a parcel costs to ship, and the band it was priced in.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Why a parcel could not be priced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, or the card it names could not be read.
    RateCardUnavailable,
    /// The card carries a line that is not three tab-separated fields, or
    /// whose numbers do not parse. `line` is 1-based and counts every line in
    /// the file, including comments and blanks.
    MalformedRateCard { line: usize },
    /// The card prices no bands for the requested zone.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => {
                write!(f, "no rate card: {RATECARD_PATH_ENV} is unset or unreadable")
            }
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "no rates for zone {zone:?}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel of {grams} g exceeds the {limit} g limit for this zone")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Price `parcel` against the rate card named by `RATECARD_PATH`.
///
/// Every call is reported to operators, priced or not.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let outcome = price(parcel);
    QuoteRecord::of(parcel, &outcome).emit();
    outcome
}

fn price(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = RateCard::from_env()?;
    let bands = card
        .zone(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let band = bands.covering(parcel.weight_grams).ok_or(QuoteError::Overweight {
        grams: parcel.weight_grams,
        limit: bands.limit(),
    })?;

    let base_cents = band.cents;
    let surcharge_cents = surcharge_cents(parcel, base_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents.saturating_add(surcharge_cents),
        band_max_grams: band.max_grams,
    })
}

/// Surcharges accumulate; a heavy international parcel carries both.
fn surcharge_cents(parcel: &Parcel, base_cents: u64) -> u64 {
    let mut surcharge = 0;
    if parcel.weight_grams > HEAVY_ABOVE_GRAMS {
        surcharge += HEAVY_SURCHARGE_CENTS;
    }
    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge += percent_half_up(base_cents, INTERNATIONAL_SURCHARGE_PERCENT);
    }
    surcharge
}

/// `percent` of `amount`, rounded half-up to the cent.
fn percent_half_up(amount: u64, percent: u64) -> u64 {
    // Widened so a card carrying absurd rates rounds rather than wrapping.
    let scaled = u128::from(amount) * u128::from(percent);
    u64::try_from((scaled + 50) / 100).unwrap_or(u64::MAX)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::env;
    use std::io::Write;
    use std::sync::{Mutex, MutexGuard, OnceLock};

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
                        domestic\t500\t599\n\
                        domestic\t2000\t899\n\
                        domestic\t20000\t1799\n\
                        international\t500\t1499\n\
                        international\t20000\t4999\n";

    /// `RATECARD_PATH` is process-wide, so tests that set it take turns.
    fn env_lock() -> MutexGuard<'static, ()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
    }

    /// Points `RATECARD_PATH` at a card for as long as it is held.
    struct Fixture {
        _lock: MutexGuard<'static, ()>,
        _card: Option<tempfile::NamedTempFile>,
    }

    impl Fixture {
        fn with_card(text: &str) -> Self {
            let mut card = tempfile::NamedTempFile::new().expect("a temporary card");
            card.write_all(text.as_bytes()).expect("the card is written");
            card.flush().expect("the card is flushed");
            let fixture = Self {
                _lock: env_lock(),
                _card: Some(card),
            };
            env::set_var(RATECARD_PATH_ENV, fixture._card.as_ref().unwrap().path());
            diagnostics::capture::drain();
            fixture
        }

        fn without_card() -> Self {
            let fixture = Self {
                _lock: env_lock(),
                _card: None,
            };
            env::remove_var(RATECARD_PATH_ENV);
            diagnostics::capture::drain();
            fixture
        }
    }

    impl Drop for Fixture {
        fn drop(&mut self) {
            env::remove_var(RATECARD_PATH_ENV);
        }
    }

    fn parcel(zone: &str, weight_grams: u32) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn prices_a_parcel_in_its_band() {
        let _fixture = Fixture::with_card(CARD);
        assert_eq!(
            quote(&parcel("domestic", 750)),
            Ok(Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2000,
            })
        );
    }

    #[test]
    fn a_weight_on_a_band_threshold_stays_in_that_band() {
        let _fixture = Fixture::with_card(CARD);
        let quote = quote(&parcel("domestic", 500)).unwrap();
        assert_eq!((quote.band_max_grams, quote.total_cents), (500, 599));
    }

    #[test]
    fn a_gram_over_a_threshold_moves_up_a_band() {
        let _fixture = Fixture::with_card(CARD);
        let quote = quote(&parcel("domestic", 501)).unwrap();
        assert_eq!((quote.band_max_grams, quote.total_cents), (2000, 899));
    }

    #[test]
    fn a_weightless_parcel_prices_in_the_first_band() {
        let _fixture = Fixture::with_card(CARD);
        assert_eq!(quote(&parcel("domestic", 0)).unwrap().band_max_grams, 500);
    }

    #[test]
    fn weight_above_ten_kilos_adds_the_heavy_surcharge() {
        let _fixture = Fixture::with_card(CARD);
        assert_eq!(
            quote(&parcel("domestic", 10_001)),
            Ok(Quote {
                base_cents: 1799,
                surcharge_cents: 500,
                total_cents: 2299,
                band_max_grams: 20000,
            })
        );
    }

    #[test]
    fn ten_kilos_exactly_is_not_heavy() {
        let _fixture = Fixture::with_card(CARD);
        assert_eq!(quote(&parcel("domestic", 10_000)).unwrap().surcharge_cents, 0);
    }

    #[test]
    fn international_adds_a_fifth_of_the_base_rate() {
        let _fixture = Fixture::with_card(CARD);
        assert_eq!(
            quote(&parcel("international", 400)),
            Ok(Quote {
                base_cents: 1499,
                // 20% of 1499 is 299.8, rounded half-up.
                surcharge_cents: 300,
                total_cents: 1799,
                band_max_grams: 500,
            })
        );
    }

    #[test]
    fn a_percentage_below_half_a_cent_rounds_down() {
        let card = "international\t500\t1002\n";
        let _fixture = Fixture::with_card(card);
        // 20% of 1002 is 200.4.
        assert_eq!(quote(&parcel("international", 100)).unwrap().surcharge_cents, 200);
    }

    #[test]
    fn a_percentage_landing_on_half_a_cent_rounds_up() {
        // No 20% of a whole cent lands on a half cent, so the rule is pinned
        // at the arithmetic rather than through a rate card.
        assert_eq!(percent_half_up(5, 50), 3); // 2.5
        assert_eq!(percent_half_up(7, 50), 4); // 3.5
        assert_eq!(percent_half_up(4, 50), 2); // 2.0
        assert_eq!(percent_half_up(1499, INTERNATIONAL_SURCHARGE_PERCENT), 300);
        assert_eq!(percent_half_up(0, INTERNATIONAL_SURCHARGE_PERCENT), 0);
    }

    #[test]
    fn a_heavy_international_parcel_carries_both_surcharges() {
        let _fixture = Fixture::with_card(CARD);
        assert_eq!(
            quote(&parcel("international", 15_000)),
            Ok(Quote {
                base_cents: 4999,
                // 500 heavy, plus 20% of 4999 rounded half-up from 999.8.
                surcharge_cents: 1500,
                total_cents: 6499,
                band_max_grams: 20000,
            })
        );
    }

    #[test]
    fn an_unpriced_zone_is_reported_with_the_zone_asked_for() {
        let _fixture = Fixture::with_card(CARD);
        assert_eq!(quote(&parcel("lunar", 100)), Err(QuoteError::UnknownZone("lunar".to_string())));
    }

    #[test]
    fn a_zone_is_matched_exactly() {
        let _fixture = Fixture::with_card(CARD);
        assert_eq!(
            quote(&parcel("Domestic", 100)),
            Err(QuoteError::UnknownZone("Domestic".to_string()))
        );
    }

    #[test]
    fn a_parcel_over_the_largest_band_is_overweight() {
        let _fixture = Fixture::with_card(CARD);
        assert_eq!(
            quote(&parcel("domestic", 20_001)),
            Err(QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000
            })
        );
    }

    #[test]
    fn the_overweight_limit_is_the_zones_own_largest_band() {
        let card = "domestic\t20000\t1799\nsmall\t500\t100\n";
        let _fixture = Fixture::with_card(card);
        assert_eq!(
            quote(&parcel("small", 600)),
            Err(QuoteError::Overweight {
                grams: 600,
                limit: 500
            })
        );
    }

    #[test]
    fn an_unset_path_leaves_the_card_unavailable() {
        let _fixture = Fixture::without_card();
        assert_eq!(quote(&parcel("domestic", 100)), Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn a_path_to_nothing_leaves_the_card_unavailable() {
        let _fixture = Fixture::without_card();
        env::set_var(RATECARD_PATH_ENV, "/nonexistent/rate/card.tsv");
        assert_eq!(quote(&parcel("domestic", 100)), Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn an_unreadable_card_is_unavailable() {
        let directory = tempfile::tempdir().expect("a temporary directory");
        let _fixture = Fixture::without_card();
        // A directory is nameable but not readable as a card.
        env::set_var(RATECARD_PATH_ENV, directory.path());
        assert_eq!(quote(&parcel("domestic", 100)), Err(QuoteError::RateCardUnavailable));
    }

    #[test]
    fn a_malformed_line_is_reported_by_its_number_in_the_file() {
        let card = "# zone\tband_max_grams\tcents\n\
                    domestic\t500\t599\n\
                    \n\
                    domestic\ttwo thousand\t899\n";
        let _fixture = Fixture::with_card(card);
        assert_eq!(quote(&parcel("domestic", 100)), Err(QuoteError::MalformedRateCard { line: 4 }));
    }

    #[test]
    fn a_malformed_line_fails_a_quote_for_any_zone() {
        let card = "domestic\t500\t599\nbroken\n";
        let _fixture = Fixture::with_card(card);
        assert_eq!(
            quote(&parcel("international", 100)),
            Err(QuoteError::MalformedRateCard { line: 2 })
        );
    }

    #[test]
    fn every_call_is_observable() {
        let _fixture = Fixture::with_card(CARD);
        quote(&parcel("international", 400)).unwrap();
        assert_eq!(
            diagnostics::capture::drain(),
            vec![
                "ratecard quote zone=\"international\" weight_grams=400 \
                 base_cents=1499 surcharge_cents=300 total_cents=1799"
            ]
        );
    }

    #[test]
    fn a_call_that_cannot_be_priced_is_observable_too() {
        let _fixture = Fixture::with_card(CARD);
        quote(&parcel("lunar", 400)).unwrap_err();
        let emitted = diagnostics::capture::drain();
        assert_eq!(emitted.len(), 1);
        assert!(emitted[0].contains("zone=\"lunar\""), "{}", emitted[0]);
        assert!(emitted[0].contains("weight_grams=400"), "{}", emitted[0]);
        assert!(emitted[0].contains("total_cents=none"), "{}", emitted[0]);
    }

    #[test]
    fn errors_describe_themselves() {
        assert_eq!(
            QuoteError::MalformedRateCard { line: 7 }.to_string(),
            "malformed rate card at line 7"
        );
        assert_eq!(
            QuoteError::UnknownZone("lunar".to_string()).to_string(),
            "no rates for zone \"lunar\""
        );
        assert_eq!(
            QuoteError::Overweight {
                grams: 900,
                limit: 500
            }
            .to_string(),
            "parcel of 900 g exceeds the 500 g limit for this zone"
        );
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "no rate card: RATECARD_PATH is unset or unreadable"
        );
    }

    #[test]
    fn errors_are_errors() {
        fn assert_error<E: std::error::Error>(_: &E) {}
        assert_error(&QuoteError::RateCardUnavailable);
        let boxed: Box<dyn std::error::Error> = Box::new(QuoteError::RateCardUnavailable);
        assert_eq!(boxed.to_string(), QuoteError::RateCardUnavailable.to_string());
    }
}
