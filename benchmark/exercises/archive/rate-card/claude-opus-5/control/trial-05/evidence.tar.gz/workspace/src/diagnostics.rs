//! The operational record of every quote the crate serves.
//!
//! Operators redeploy rate cards without a code change, so a mispriced parcel
//! is diagnosed from the record, not from the card that happened to be live.

use crate::{Parcel, Quote, QuoteError};

/// One quote call, as it is reported to operators.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct QuoteRecord {
    zone: String,
    weight_grams: u32,
    outcome: Outcome,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum Outcome {
    Priced {
        base_cents: u64,
        surcharge_cents: u64,
        total_cents: u64,
    },
    Failed(String),
}

impl QuoteRecord {
    /// Describe a completed call, priced or not.
    pub fn of(parcel: &Parcel, outcome: &Result<Quote, QuoteError>) -> Self {
        Self {
            zone: parcel.zone.clone(),
            weight_grams: parcel.weight_grams,
            outcome: match outcome {
                Ok(quote) => Outcome::Priced {
                    base_cents: quote.base_cents,
                    surcharge_cents: quote.surcharge_cents,
                    total_cents: quote.total_cents,
                },
                Err(error) => Outcome::Failed(error.to_string()),
            },
        }
    }

    /// The record as a single key-value line.
    pub fn line(&self) -> String {
        // The zone is operator-supplied, so it is quoted and escaped to keep
        // the line parsable.
        let head =
            format!("ratecard quote zone={:?} weight_grams={}", self.zone, self.weight_grams);
        match &self.outcome {
            Outcome::Priced {
                base_cents,
                surcharge_cents,
                total_cents,
            } => format!(
                "{head} base_cents={base_cents} surcharge_cents={surcharge_cents} \
                 total_cents={total_cents}"
            ),
            Outcome::Failed(error) => format!("{head} total_cents=none error={error:?}"),
        }
    }

    /// Report the call to operators.
    pub fn emit(&self) {
        let line = self.line();
        eprintln!("{line}");
        #[cfg(test)]
        capture::push(line);
    }
}

/// Diagnostics emitted on the current thread, for tests that assert a call was
/// observable.
#[cfg(test)]
pub mod capture {
    use std::cell::RefCell;

    thread_local! {
        static EMITTED: RefCell<Vec<String>> = const { RefCell::new(Vec::new()) };
    }

    pub(super) fn push(line: String) {
        EMITTED.with(|emitted| emitted.borrow_mut().push(line));
    }

    /// Take everything emitted on this thread since the last drain.
    pub fn drain() -> Vec<String> {
        EMITTED.with(|emitted| emitted.borrow_mut().drain(..).collect())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn parcel() -> Parcel {
        Parcel {
            weight_grams: 750,
            zone: "domestic".to_string(),
        }
    }

    #[test]
    fn a_priced_call_reports_zone_weight_and_total() {
        let quote = Quote {
            base_cents: 899,
            surcharge_cents: 0,
            total_cents: 899,
            band_max_grams: 2000,
        };
        assert_eq!(
            QuoteRecord::of(&parcel(), &Ok(quote)).line(),
            "ratecard quote zone=\"domestic\" weight_grams=750 \
             base_cents=899 surcharge_cents=0 total_cents=899"
        );
    }

    #[test]
    fn a_failed_call_reports_why_instead_of_a_total() {
        let outcome = Err(QuoteError::Overweight {
            grams: 750,
            limit: 500,
        });
        assert_eq!(
            QuoteRecord::of(&parcel(), &outcome).line(),
            "ratecard quote zone=\"domestic\" weight_grams=750 total_cents=none \
             error=\"parcel of 750 g exceeds the 500 g limit for this zone\""
        );
    }

    #[test]
    fn an_awkward_zone_stays_on_one_parsable_line() {
        let parcel = Parcel {
            weight_grams: 1,
            zone: "off\tworld \"x\"".to_string(),
        };
        let outcome = Err(QuoteError::UnknownZone(parcel.zone.clone()));
        let line = QuoteRecord::of(&parcel, &outcome).line();
        assert!(line.starts_with(r#"ratecard quote zone="off\tworld \"x\"" weight_grams=1"#));
        assert_eq!(line.lines().count(), 1);
    }
}
