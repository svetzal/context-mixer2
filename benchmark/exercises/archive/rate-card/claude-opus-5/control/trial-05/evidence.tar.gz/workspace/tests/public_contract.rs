//! The contract an external caller depends on: the exported names, the field
//! reads, and the error matches.

use std::env;
use std::io::Write;
use std::sync::{Mutex, MutexGuard, OnceLock};

use ratecard::{quote, Parcel, Quote, QuoteError};

const CARD: &str = "# zone\tband_max_grams\tcents\n\
                    domestic\t500\t599\n\
                    domestic\t2000\t899\n\
                    domestic\t20000\t1799\n\
                    international\t500\t1499\n\
                    international\t20000\t4999\n";

/// `RATECARD_PATH` is process-wide, so tests that set it take turns.
fn env_lock() -> MutexGuard<'static, ()> {
    static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    LOCK.get_or_init(|| Mutex::new(()))
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
}

struct Fixture {
    _lock: MutexGuard<'static, ()>,
    _card: tempfile::NamedTempFile,
}

impl Fixture {
    fn with_card(text: &str) -> Self {
        let lock = env_lock();
        let mut card = tempfile::NamedTempFile::new().expect("a temporary card");
        card.write_all(text.as_bytes()).expect("the card is written");
        card.flush().expect("the card is flushed");
        env::set_var("RATECARD_PATH", card.path());
        Self {
            _lock: lock,
            _card: card,
        }
    }
}

impl Drop for Fixture {
    fn drop(&mut self) {
        env::remove_var("RATECARD_PATH");
    }
}

fn parcel(zone: &str, weight_grams: u32) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_string(),
    }
}

#[test]
fn quote_fields_are_read_directly() {
    let _fixture = Fixture::with_card(CARD);
    let quote: Quote = quote(&parcel("international", 12_000)).expect("a priced parcel");
    assert_eq!(quote.base_cents, 4999);
    assert_eq!(quote.surcharge_cents, 1500);
    assert_eq!(quote.total_cents, 6499);
    assert_eq!(quote.band_max_grams, 20000);
    assert_eq!(quote.total_cents, quote.base_cents + quote.surcharge_cents);
}

#[test]
fn error_variants_are_matched_directly() {
    let _fixture = Fixture::with_card(CARD);

    match quote(&parcel("lunar", 100)) {
        Err(QuoteError::UnknownZone(zone)) => assert_eq!(zone, "lunar"),
        other => panic!("expected UnknownZone, got {other:?}"),
    }

    match quote(&parcel("domestic", 25_000)) {
        Err(QuoteError::Overweight { grams, limit }) => {
            assert_eq!((grams, limit), (25_000, 20_000));
        }
        other => panic!("expected Overweight, got {other:?}"),
    }
}

#[test]
fn a_malformed_card_names_its_line() {
    let _fixture = Fixture::with_card("# header\ndomestic\t500\t599\ndomestic\t2000\n");
    match quote(&parcel("domestic", 100)) {
        Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
        other => panic!("expected MalformedRateCard, got {other:?}"),
    }
}

#[test]
fn an_absent_card_is_unavailable() {
    let _lock = env_lock();
    env::remove_var("RATECARD_PATH");
    assert!(matches!(quote(&parcel("domestic", 100)), Err(QuoteError::RateCardUnavailable)));
}

#[test]
fn errors_are_displayable_and_are_errors() {
    let error: Box<dyn std::error::Error> = Box::new(QuoteError::Overweight {
        grams: 900,
        limit: 500,
    });
    assert!(!error.to_string().is_empty());
}
