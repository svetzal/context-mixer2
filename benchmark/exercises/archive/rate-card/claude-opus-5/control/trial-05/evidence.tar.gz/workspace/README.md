# ratecard

Shipping quotes for the fulfilment service.

Warehouse operators price outbound parcels against a rate card that operations
maintains and redeploys without a code change. This crate owns reading that card
and turning a parcel into a quote.

## Operating

`RATECARD_PATH` names the tab-separated card to price against. It is read on
every quote, so operations can redeploy a card without a restart. A card that
is unset, unreadable, or malformed fails the quote rather than pricing against
a stale one.

Every call — priced or not — reports one line to stderr, so a disputed price
can be traced to the zone, weight, and total that were actually served:

```text
ratecard quote zone="international" weight_grams=400 base_cents=1499 surcharge_cents=300 total_cents=1799
ratecard quote zone="lunar" weight_grams=400 total_cents=none error="no rates for zone \"lunar\""
```

## Development

```bash
cargo test
```
