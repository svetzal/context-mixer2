//! Reading the operations-maintained rate card off disk.
//!
//! The card is redeployed without a code change, so parsing is strict and
//! reports the offending line rather than silently skipping it.

use std::collections::HashMap;
use std::env;
use std::fs;

use crate::{QuoteError, RATECARD_PATH_ENV};

/// One priced band: parcels up to `max_grams` cost `cents` before surcharges.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Band {
    pub max_grams: u32,
    pub cents: u64,
}

/// Every band for a single zone, ascending by `max_grams`. Never empty.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ZoneBands(Vec<Band>);

impl ZoneBands {
    /// The first band whose threshold reaches `grams`, or `None` if the parcel
    /// is heavier than every band in the zone.
    pub fn covering(&self, grams: u32) -> Option<Band> {
        self.0.iter().copied().find(|band| band.max_grams >= grams)
    }

    /// The heaviest parcel this zone will carry.
    pub fn limit(&self) -> u32 {
        self.0.last().map(|band| band.max_grams).unwrap_or(0)
    }
}

/// A parsed rate card, indexed by zone.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RateCard {
    zones: HashMap<String, ZoneBands>,
}

impl RateCard {
    /// Load the card named by `RATECARD_PATH`.
    pub fn from_env() -> Result<Self, QuoteError> {
        let path = env::var_os(RATECARD_PATH_ENV).ok_or(QuoteError::RateCardUnavailable)?;
        let text = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
        Self::parse(&text)
    }

    /// Parse the tab-separated card body.
    pub fn parse(text: &str) -> Result<Self, QuoteError> {
        let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

        for (index, raw) in text.lines().enumerate() {
            // Line numbers are 1-based and count comments and blanks.
            let number = index + 1;
            let line = raw.strip_suffix('\r').unwrap_or(raw);
            if is_ignorable(line) {
                continue;
            }
            let (zone, band) = parse_band(line, number)?;
            zones.entry(zone).or_default().push(band);
        }

        let zones = zones
            .into_iter()
            .map(|(zone, mut bands)| {
                // The file need not be sorted; the banding rule assumes it is.
                bands.sort_by_key(|band| band.max_grams);
                (zone, ZoneBands(bands))
            })
            .collect();

        Ok(Self { zones })
    }

    /// The bands priced for `zone`, or `None` if the card does not carry it.
    pub fn zone(&self, zone: &str) -> Option<&ZoneBands> {
        self.zones.get(zone)
    }
}

fn is_ignorable(line: &str) -> bool {
    let trimmed = line.trim_start();
    trimmed.is_empty() || trimmed.starts_with('#')
}

fn parse_band(line: &str, number: usize) -> Result<(String, Band), QuoteError> {
    let malformed = || QuoteError::MalformedRateCard { line: number };

    let mut fields = line.split('\t');
    let zone = fields.next().ok_or_else(malformed)?;
    let max_grams = fields.next().ok_or_else(malformed)?;
    let cents = fields.next().ok_or_else(malformed)?;
    if fields.next().is_some() || zone.is_empty() {
        return Err(malformed());
    }

    Ok((
        zone.to_string(),
        Band {
            max_grams: max_grams.parse().map_err(|_| malformed())?,
            cents: cents.parse().map_err(|_| malformed())?,
        },
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
                        domestic\t500\t599\n\
                        domestic\t2000\t899\n\
                        domestic\t20000\t1799\n\
                        international\t500\t1499\n\
                        international\t20000\t4999\n";

    fn card() -> RateCard {
        RateCard::parse(CARD).expect("the sample card parses")
    }

    #[test]
    fn reads_every_band_of_a_zone() {
        assert_eq!(
            card().zone("domestic"),
            Some(&ZoneBands(vec![
                Band {
                    max_grams: 500,
                    cents: 599
                },
                Band {
                    max_grams: 2000,
                    cents: 899
                },
                Band {
                    max_grams: 20000,
                    cents: 1799
                },
            ]))
        );
    }

    #[test]
    fn ignores_comments_and_blank_lines() {
        let text = "# a comment\n\n   \n\t\ndomestic\t500\t599\n";
        assert_eq!(RateCard::parse(text).unwrap().zone("domestic").unwrap().limit(), 500);
    }

    #[test]
    fn zone_absent_from_the_card_is_not_found() {
        assert!(card().zone("lunar").is_none());
    }

    #[test]
    fn covering_band_is_the_first_that_reaches_the_weight() {
        let zones = card();
        let bands = zones.zone("domestic").unwrap();
        assert_eq!(bands.covering(1).unwrap().max_grams, 500);
        assert_eq!(bands.covering(500).unwrap().max_grams, 500);
        assert_eq!(bands.covering(501).unwrap().max_grams, 2000);
        assert_eq!(bands.covering(20000).unwrap().max_grams, 20000);
        assert_eq!(bands.covering(20001), None);
    }

    #[test]
    fn limit_is_the_largest_band() {
        assert_eq!(card().zone("international").unwrap().limit(), 20000);
    }

    #[test]
    fn bands_are_ordered_however_the_file_lists_them() {
        let text = "domestic\t20000\t1799\ndomestic\t500\t599\ndomestic\t2000\t899\n";
        let bands = RateCard::parse(text).unwrap();
        let bands = bands.zone("domestic").unwrap();
        assert_eq!(
            bands.covering(600).unwrap(),
            Band {
                max_grams: 2000,
                cents: 899
            }
        );
    }

    #[test]
    fn too_few_fields_is_malformed_at_its_line() {
        let text = "# header\n\ndomestic\t500\n";
        assert_eq!(RateCard::parse(text), Err(QuoteError::MalformedRateCard { line: 3 }));
    }

    #[test]
    fn too_many_fields_is_malformed() {
        let text = "domestic\t500\t599\textra\n";
        assert_eq!(RateCard::parse(text), Err(QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn unparsable_numbers_are_malformed() {
        for text in [
            "domestic\theavy\t599\n",
            "domestic\t500\tcheap\n",
            "domestic\t-1\t599\n",
        ] {
            assert_eq!(RateCard::parse(text), Err(QuoteError::MalformedRateCard { line: 1 }));
        }
    }

    #[test]
    fn missing_zone_is_malformed() {
        assert_eq!(RateCard::parse("\t500\t599\n"), Err(QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn space_separated_lines_are_malformed() {
        assert_eq!(
            RateCard::parse("domestic 500 599\n"),
            Err(QuoteError::MalformedRateCard { line: 1 })
        );
    }

    #[test]
    fn carriage_returns_do_not_make_a_card_malformed() {
        let text = "# zone\tband_max_grams\tcents\r\ndomestic\t500\t599\r\n";
        assert_eq!(
            RateCard::parse(text).unwrap().zone("domestic").unwrap().covering(500),
            Some(Band {
                max_grams: 500,
                cents: 599
            })
        );
    }

    #[test]
    fn an_empty_card_carries_no_zones() {
        assert_eq!(RateCard::parse("").unwrap().zone("domestic"), None);
    }
}
