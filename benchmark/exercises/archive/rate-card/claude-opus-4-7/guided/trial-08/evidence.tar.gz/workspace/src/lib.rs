//! Shipping rate quotes from a zone rate card.
//!
//! The crate exposes a single fallible entry point, [`quote`], which reads a
//! tab-separated rate card from the path in the `RATECARD_PATH` environment
//! variable and prices a [`Parcel`] against it. The parsing and pricing
//! stages are pure and are unit-tested in isolation; only the top-level
//! [`quote`] function performs I/O and emits observability.

mod parse;
mod pricing;
mod source;
pub mod zones;

use std::fmt;

use crate::source::{EnvFileSource, RateCardSource};

/// A parcel awaiting a quote.
#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The priced result: the base band cents, any surcharges, the total, and
/// the band ceiling that matched.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Every reason a [`quote`] call may fail.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, or the file cannot be read.
    RateCardUnavailable,
    /// A rate-card line is malformed. `line` is 1-based and counts every
    /// line in the source file, including blanks and comments.
    MalformedRateCard { line: usize },
    /// The parcel's zone is not present in the rate card.
    UnknownZone(String),
    /// The parcel weighs more than the largest band for its zone. `limit`
    /// is that largest `band_max_grams`.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => f.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds the {limit}g limit for the zone")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Read the rate card configured through `RATECARD_PATH` and price `parcel`
/// against it. Emits a structured tracing span per call carrying the zone,
/// weight, and — on success — the total cents.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_from(&EnvFileSource, parcel)
}

/// Shared inner path used by [`quote`] and integration tests that supply an
/// in-memory rate-card source.
pub(crate) fn quote_from<S: RateCardSource>(
    source: &S,
    parcel: &Parcel,
) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "quote",
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
    );
    let _guard = span.enter();

    let outcome = load_and_price(source, parcel);
    match &outcome {
        Ok(q) => tracing::info!(
            total_cents = q.total_cents,
            base_cents = q.base_cents,
            surcharge_cents = q.surcharge_cents,
            band_max_grams = q.band_max_grams,
            "quote_priced",
        ),
        Err(err) => tracing::warn!(error = %err, "quote_failed"),
    }
    outcome
}

fn load_and_price<S: RateCardSource>(
    source: &S,
    parcel: &Parcel,
) -> Result<Quote, QuoteError> {
    let text = source.load()?;
    let card = parse::parse(&text)?;
    pricing::price(&card, parcel)
}

#[cfg(test)]
#[allow(clippy::unwrap_used)]
mod tests {
    use super::*;

    struct InMemory(&'static str);
    impl RateCardSource for InMemory {
        fn load(&self) -> Result<String, QuoteError> {
            Ok(self.0.to_string())
        }
    }

    struct Unavailable;
    impl RateCardSource for Unavailable {
        fn load(&self) -> Result<String, QuoteError> {
            Err(QuoteError::RateCardUnavailable)
        }
    }

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn end_to_end_domestic_light_parcel() {
        let source = InMemory(CARD);
        let q = quote_from(
            &source,
            &Parcel { weight_grams: 250, zone: "domestic".into() },
        )
        .unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn end_to_end_international_heavy_parcel() {
        let source = InMemory(CARD);
        let q = quote_from(
            &source,
            &Parcel { weight_grams: 15_000, zone: "international".into() },
        )
        .unwrap();
        assert_eq!(q.base_cents, 4_999);
        assert_eq!(q.surcharge_cents, 1_500);
        assert_eq!(q.total_cents, 6_499);
        assert_eq!(q.band_max_grams, 20_000);
    }

    #[test]
    fn missing_source_returns_unavailable() {
        let err = quote_from(
            &Unavailable,
            &Parcel { weight_grams: 100, zone: "domestic".into() },
        )
        .unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn unknown_zone_bubbles_up() {
        let err = quote_from(
            &InMemory(CARD),
            &Parcel { weight_grams: 100, zone: "lunar".into() },
        )
        .unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".into()));
    }

    #[test]
    fn overweight_bubbles_up() {
        let err = quote_from(
            &InMemory(CARD),
            &Parcel { weight_grams: 30_000, zone: "domestic".into() },
        )
        .unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight { grams: 30_000, limit: 20_000 }
        );
    }

    #[test]
    fn malformed_card_bubbles_up_with_line_number() {
        let bad = "\
# header
domestic\tbroken\t100
";
        let err = quote_from(
            &InMemory(Box::leak(bad.to_string().into_boxed_str())),
            &Parcel { weight_grams: 100, zone: "domestic".into() },
        )
        .unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn display_and_error_impls_are_wired() {
        let err: Box<dyn std::error::Error> =
            Box::new(QuoteError::Overweight { grams: 50_000, limit: 20_000 });
        assert!(err.to_string().contains("50000"));
        assert!(err.to_string().contains("20000"));

        let unknown = QuoteError::UnknownZone("mars".into());
        assert!(unknown.to_string().contains("mars"));
    }
}
