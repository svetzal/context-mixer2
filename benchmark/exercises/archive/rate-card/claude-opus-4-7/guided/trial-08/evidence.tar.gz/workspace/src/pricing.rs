//! Pure pricing: given a parsed rate card and a parcel, compute the quote.
//!
//! This module has no I/O and no dependencies on external services; it is
//! exercised directly by unit tests and by the crate's public entry point.

use std::collections::HashMap;

use crate::{Parcel, Quote, QuoteError};

/// A single pricing band within a zone. Represents the weight ceiling
/// (`max_grams`) below or equal to which parcels are charged `cents`.
#[derive(Debug, Clone)]
pub(crate) struct Band {
    pub(crate) max_grams: u32,
    pub(crate) cents: u64,
}

/// A parsed rate card keyed by zone. Bands within each zone are stored in
/// ascending `max_grams` order so band selection is a simple linear scan.
#[derive(Debug, Clone, Default)]
pub(crate) struct RateCard {
    pub(crate) zones: HashMap<String, Vec<Band>>,
}

impl RateCard {
    pub(crate) fn from_zones(zones: HashMap<String, Vec<Band>>) -> Self {
        let mut card = Self { zones };
        for bands in card.zones.values_mut() {
            bands.sort_by_key(|b| b.max_grams);
        }
        card
    }
}

const OVERWEIGHT_THRESHOLD_GRAMS: u32 = 10_000;
const OVERWEIGHT_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";
const INTERNATIONAL_SURCHARGE_NUMERATOR: u64 = 20;
const CENT_DIVISOR: u64 = 100;

pub(crate) fn price(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let Some(bands) = card.zones.get(&parcel.zone) else {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    };

    let Some(band) = bands.iter().find(|b| b.max_grams >= parcel.weight_grams) else {
        let limit = bands.last().map_or(0, |b| b.max_grams);
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        });
    };

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > OVERWEIGHT_THRESHOLD_GRAMS {
        surcharge_cents += OVERWEIGHT_SURCHARGE_CENTS;
    }

    if parcel.zone == INTERNATIONAL_ZONE {
        // Half-up rounding of (base_cents * 20 / 100).
        surcharge_cents +=
            (base_cents * INTERNATIONAL_SURCHARGE_NUMERATOR + CENT_DIVISOR / 2) / CENT_DIVISOR;
    }

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
#[allow(clippy::unwrap_used)]
mod tests {
    use super::*;

    fn sample_card() -> RateCard {
        let mut zones: HashMap<String, Vec<Band>> = HashMap::new();
        zones.insert(
            "domestic".into(),
            vec![
                Band { max_grams: 500, cents: 599 },
                Band { max_grams: 2_000, cents: 899 },
                Band { max_grams: 20_000, cents: 1_799 },
            ],
        );
        zones.insert(
            "international".into(),
            vec![
                Band { max_grams: 500, cents: 1_499 },
                Band { max_grams: 20_000, cents: 4_999 },
            ],
        );
        RateCard::from_zones(zones)
    }

    #[test]
    fn selects_first_band_covering_weight() {
        let card = sample_card();
        let quote = price(
            &card,
            &Parcel { weight_grams: 100, zone: "domestic".into() },
        )
        .unwrap();
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn band_edge_matches_ceiling() {
        let card = sample_card();
        let quote = price(
            &card,
            &Parcel { weight_grams: 500, zone: "domestic".into() },
        )
        .unwrap();
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.base_cents, 599);
    }

    #[test]
    fn crosses_band_boundary_by_one_gram() {
        let card = sample_card();
        let quote = price(
            &card,
            &Parcel { weight_grams: 501, zone: "domestic".into() },
        )
        .unwrap();
        assert_eq!(quote.band_max_grams, 2_000);
        assert_eq!(quote.base_cents, 899);
    }

    #[test]
    fn adds_overweight_surcharge_strictly_above_ten_kilos() {
        let card = sample_card();
        let heavy = price(
            &card,
            &Parcel { weight_grams: 10_001, zone: "domestic".into() },
        )
        .unwrap();
        assert_eq!(heavy.base_cents, 1_799);
        assert_eq!(heavy.surcharge_cents, 500);
        assert_eq!(heavy.total_cents, 2_299);

        let at_threshold = price(
            &card,
            &Parcel { weight_grams: 10_000, zone: "domestic".into() },
        )
        .unwrap();
        assert_eq!(at_threshold.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_twenty_percent_half_up() {
        let card = sample_card();
        // base 1499 * 0.20 = 299.8 -> 300 with half-up
        let quote = price(
            &card,
            &Parcel { weight_grams: 250, zone: "international".into() },
        )
        .unwrap();
        assert_eq!(quote.base_cents, 1_499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1_799);
    }

    #[test]
    fn international_stacks_overweight_and_percentage() {
        let card = sample_card();
        // 15kg intl: base=4999, +500 overweight, +1000 (4999*0.2 = 999.8 -> 1000)
        let quote = price(
            &card,
            &Parcel { weight_grams: 15_000, zone: "international".into() },
        )
        .unwrap();
        assert_eq!(quote.base_cents, 4_999);
        assert_eq!(quote.surcharge_cents, 1_500);
        assert_eq!(quote.total_cents, 6_499);
    }

    #[test]
    fn unknown_zone_returns_its_name() {
        let card = sample_card();
        let err = price(
            &card,
            &Parcel { weight_grams: 100, zone: "orbital".into() },
        )
        .unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("orbital".into()));
    }

    #[test]
    fn overweight_reports_largest_band_ceiling() {
        let card = sample_card();
        let err = price(
            &card,
            &Parcel { weight_grams: 25_000, zone: "domestic".into() },
        )
        .unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight { grams: 25_000, limit: 20_000 }
        );
    }

    #[test]
    fn half_up_rounding_boundary_cases() {
        // Build a card whose base is chosen so 20% lands exactly on x.5 cents.
        let mut zones = HashMap::new();
        zones.insert(
            "international".into(),
            vec![Band { max_grams: 100, cents: 5 }],
        );
        let card = RateCard::from_zones(zones);
        // 5 * 20 = 100 cent-percent, /100 = 1 exactly. surcharge = 1.
        let quote = price(
            &card,
            &Parcel { weight_grams: 50, zone: "international".into() },
        )
        .unwrap();
        assert_eq!(quote.surcharge_cents, 1);

        // Base=25: 25*20=500, /100 = 5 exactly.
        let mut zones2 = HashMap::new();
        zones2.insert(
            "international".into(),
            vec![Band { max_grams: 100, cents: 25 }],
        );
        let quote2 = price(
            &RateCard::from_zones(zones2),
            &Parcel { weight_grams: 50, zone: "international".into() },
        )
        .unwrap();
        assert_eq!(quote2.surcharge_cents, 5);

        // Base=125: 125*20=2500, /100=25 exact.
        // Base=128: 128*20=2560, half-up rounds .6 up: (2560+50)/100 = 26.
        let mut zones3 = HashMap::new();
        zones3.insert(
            "international".into(),
            vec![Band { max_grams: 100, cents: 128 }],
        );
        let quote3 = price(
            &RateCard::from_zones(zones3),
            &Parcel { weight_grams: 50, zone: "international".into() },
        )
        .unwrap();
        assert_eq!(quote3.surcharge_cents, 26);

        // Base=127: 127*20=2540, .4 rounds down: (2540+50)/100 = 25.
        let mut zones4 = HashMap::new();
        zones4.insert(
            "international".into(),
            vec![Band { max_grams: 100, cents: 127 }],
        );
        let quote4 = price(
            &RateCard::from_zones(zones4),
            &Parcel { weight_grams: 50, zone: "international".into() },
        )
        .unwrap();
        assert_eq!(quote4.surcharge_cents, 25);
    }
}
