//! Pure rate-card parsing: text in, [`RateCard`] out.
//!
//! Lines that are blank or begin with `#` (after leading whitespace) are
//! ignored for content but continue to count toward line numbering, so
//! [`QuoteError::MalformedRateCard`] line numbers match what an operator
//! sees in their editor.

use std::collections::HashMap;

use crate::QuoteError;
use crate::pricing::{Band, RateCard};

const EXPECTED_FIELDS: usize = 3;

pub(crate) fn parse(text: &str) -> Result<RateCard, QuoteError> {
    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

    for (index, raw_line) in text.lines().enumerate() {
        let line_no = index + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = raw_line.split('\t').collect();
        if parts.len() != EXPECTED_FIELDS {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }

        let zone = parts[0].to_string();
        let max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;

        zones
            .entry(zone)
            .or_default()
            .push(Band { max_grams, cents });
    }

    Ok(RateCard::from_zones(zones))
}

#[cfg(test)]
#[allow(clippy::unwrap_used)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn parses_the_reference_card() {
        let card = parse(SAMPLE).unwrap();
        assert_eq!(card.zones.len(), 2);
        let dom = card.zones.get("domestic").unwrap();
        assert_eq!(dom.len(), 3);
        assert_eq!(dom[0].max_grams, 500);
        assert_eq!(dom[0].cents, 599);
        assert_eq!(dom[2].max_grams, 20_000);
    }

    #[test]
    fn ignores_blank_and_comment_lines() {
        let text = "\
# header
\t
domestic\t500\t599

# another comment
domestic\t2000\t899
";
        let card = parse(text).unwrap();
        assert_eq!(card.zones.get("domestic").unwrap().len(), 2);
    }

    #[test]
    fn sorts_bands_ascending_after_parse() {
        let text = "\
domestic\t2000\t899
domestic\t500\t599
domestic\t20000\t1799
";
        let card = parse(text).unwrap();
        let bands = card.zones.get("domestic").unwrap();
        assert_eq!(bands[0].max_grams, 500);
        assert_eq!(bands[1].max_grams, 2_000);
        assert_eq!(bands[2].max_grams, 20_000);
    }

    #[test]
    fn wrong_field_count_reports_line_number() {
        let text = "\
# header
domestic\t500
";
        let err = parse(text).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn unparseable_weight_reports_line_number() {
        let text = "\
# header

domestic\theavy\t599
";
        let err = parse(text).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn unparseable_cents_reports_line_number() {
        let text = "\
domestic\t500\tfree
";
        let err = parse(text).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn line_numbering_counts_comments_and_blanks() {
        let text = "\
#a
#b

#c
domestic\tbroken\t100
";
        let err = parse(text).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 5 });
    }
}
