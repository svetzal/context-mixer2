//! Integration test for the crate's shell: `RATECARD_PATH` + filesystem.
//!
//! All env-touching cases live in one `#[test]` so that setting and
//! restoring `RATECARD_PATH` cannot race with a sibling test. `env::set_var`
//! is `unsafe` in current Rust; that is scoped to this file with a local
//! allow.

#![allow(unsafe_code)]
#![allow(clippy::unwrap_used)]

use std::io::Write;

use ratecard::{quote, Parcel, QuoteError};
use tempfile::NamedTempFile;

const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn write_card(text: &str) -> NamedTempFile {
    let mut file = NamedTempFile::new().unwrap();
    file.write_all(text.as_bytes()).unwrap();
    file.flush().unwrap();
    file
}

#[test]
fn end_to_end_shell_covers_success_and_failure_paths() {
    let saved = std::env::var("RATECARD_PATH").ok();

    // 1. Unset env → RateCardUnavailable.
    unsafe { std::env::remove_var("RATECARD_PATH"); }
    let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() })
        .unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);

    // 2. Env pointed at a missing file → RateCardUnavailable.
    unsafe { std::env::set_var("RATECARD_PATH", "/does/not/exist/ratecard.tsv"); }
    let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() })
        .unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);

    // 3. Env pointed at a valid file → success, domestic light parcel.
    let file = write_card(CARD);
    unsafe { std::env::set_var("RATECARD_PATH", file.path()); }
    let q = quote(&Parcel { weight_grams: 250, zone: "domestic".into() }).unwrap();
    assert_eq!(q.base_cents, 599);
    assert_eq!(q.surcharge_cents, 0);
    assert_eq!(q.total_cents, 599);
    assert_eq!(q.band_max_grams, 500);

    // 4. International heavy parcel: base + overweight + 20% (half-up).
    let q = quote(&Parcel {
        weight_grams: 15_000,
        zone: "international".into(),
    })
    .unwrap();
    assert_eq!(q.base_cents, 4_999);
    assert_eq!(q.surcharge_cents, 1_500);
    assert_eq!(q.total_cents, 6_499);
    assert_eq!(q.band_max_grams, 20_000);

    // 5. Unknown zone.
    let err = quote(&Parcel { weight_grams: 100, zone: "orbital".into() })
        .unwrap_err();
    assert_eq!(err, QuoteError::UnknownZone("orbital".into()));

    // 6. Overweight for the zone.
    let err = quote(&Parcel { weight_grams: 30_000, zone: "domestic".into() })
        .unwrap_err();
    assert_eq!(
        err,
        QuoteError::Overweight { grams: 30_000, limit: 20_000 }
    );

    // 7. Malformed card → line number counts comments and blanks.
    let bad = "\
# header
# another

domestic\tnot_a_number\t100
";
    let bad_file = write_card(bad);
    unsafe { std::env::set_var("RATECARD_PATH", bad_file.path()); }
    let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() })
        .unwrap_err();
    assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });

    // Restore the caller's environment.
    unsafe {
        match saved {
            Some(v) => std::env::set_var("RATECARD_PATH", v),
            None => std::env::remove_var("RATECARD_PATH"),
        }
    }
}
