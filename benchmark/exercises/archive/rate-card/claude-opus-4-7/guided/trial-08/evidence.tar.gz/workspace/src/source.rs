//! Gateway trait for loading a rate-card document.
//!
//! Wrapping the filesystem + environment lookup behind a trait keeps the
//! pricing pipeline testable with in-memory fakes and keeps the concrete
//! gateway thin — see [`EnvFileSource`].

use std::env;
use std::fs;

use crate::QuoteError;

pub(crate) trait RateCardSource {
    fn load(&self) -> Result<String, QuoteError>;
}

/// Production gateway: reads the file at `$RATECARD_PATH`.
pub(crate) struct EnvFileSource;

impl RateCardSource for EnvFileSource {
    fn load(&self) -> Result<String, QuoteError> {
        let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
        fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}
