//! Shipping rate quotes from a zone rate card.
//!
//! [`quote`] computes a [`Quote`] for a [`Parcel`], reading pricing bands
//! from the file named by the `RATECARD_PATH` environment variable.
//!
//! The pure calculation (parsing plus band selection and surcharge maths)
//! is kept independent from the I/O shell that fetches the rate card, so
//! the business rules can be exercised in tests without touching the
//! filesystem or the process environment.

#![warn(missing_docs)]

use std::collections::HashMap;
use std::fmt;

pub mod zones;

/// A shipping parcel described by weight and destination zone.
#[derive(Debug, Clone)]
pub struct Parcel {
    /// Parcel weight in grams.
    pub weight_grams: u32,
    /// Destination zone key that must appear in the rate card.
    pub zone: String,
}

/// A computed shipping quote for a [`Parcel`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Base carriage price in cents, taken from the matching band.
    pub base_cents: u64,
    /// Sum of applicable surcharges in cents.
    pub surcharge_cents: u64,
    /// Total price in cents (`base_cents + surcharge_cents`).
    pub total_cents: u64,
    /// The `band_max_grams` threshold of the matching band.
    pub band_max_grams: u32,
}

/// Failure modes returned by [`quote`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card could not be read, or `RATECARD_PATH` was not set.
    RateCardUnavailable,
    /// A line in the rate card did not parse. Carries the 1-based line
    /// number, counting every line in the file including comments and
    /// blanks.
    MalformedRateCard {
        /// 1-based line number of the offending line.
        line: usize,
    },
    /// The parcel's zone is not present in the rate card.
    UnknownZone(String),
    /// The parcel's weight exceeds the largest band for its zone.
    Overweight {
        /// The parcel weight that could not be quoted, in grams.
        grams: u32,
        /// The largest `band_max_grams` the zone offers.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => f.write_str("rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Edge contract for supplying rate-card content to the pure core. A test
/// double can implement this to return canned strings without touching
/// the filesystem.
trait RateCardSource {
    fn load(&self) -> Result<String, QuoteError>;
}

/// Production adapter that resolves `RATECARD_PATH` and reads the file.
struct EnvFileSource;

impl RateCardSource for EnvFileSource {
    fn load(&self) -> Result<String, QuoteError> {
        let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
        std::fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}

#[derive(Debug, Clone)]
struct Band {
    max_grams: u32,
    cents: u64,
}

type Zones = HashMap<String, Vec<Band>>;

fn parse_rate_card(content: &str) -> Result<Zones, QuoteError> {
    let mut zones: Zones = HashMap::new();
    for (idx, line) in content.lines().enumerate() {
        let line_no = idx + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }
        let zone = parts[0].to_owned();
        let max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        zones
            .entry(zone)
            .or_default()
            .push(Band { max_grams, cents });
    }
    for bands in zones.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }
    Ok(zones)
}

// Integer implementation of "20% of `base_cents`, rounded half-up to the
// cent". Adding 50 before dividing by 100 rounds half-up for non-negative
// values, matching the spec.
fn international_surcharge(base_cents: u64) -> u64 {
    (base_cents.saturating_mul(20).saturating_add(50)) / 100
}

fn compute_quote(parcel: &Parcel, zones: &Zones) -> Result<Quote, QuoteError> {
    let bands = zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let Some(limit) = bands.last().map(|b| b.max_grams) else {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    };
    let Some(band) = bands.iter().find(|b| b.max_grams >= parcel.weight_grams) else {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        });
    };
    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents = surcharge_cents.saturating_add(500);
    }
    if parcel.zone == "international" {
        surcharge_cents = surcharge_cents.saturating_add(international_surcharge(base_cents));
    }
    let total_cents = base_cents.saturating_add(surcharge_cents);
    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

fn quote_with_source<S: RateCardSource>(
    parcel: &Parcel,
    source: &S,
) -> Result<Quote, QuoteError> {
    let content = source.load()?;
    let zones = parse_rate_card(&content)?;
    compute_quote(parcel, &zones)
}

/// Compute a shipping [`Quote`] for `parcel` using the rate card at the
/// path in `RATECARD_PATH`.
///
/// See the crate-level documentation for the file format and the
/// surcharge rules.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let source = EnvFileSource;
    let span = tracing::info_span!(
        "ratecard.quote",
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
    );
    let _entered = span.enter();
    let result = quote_with_source(parcel, &source);
    match &result {
        Ok(q) => tracing::info!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            total_cents = q.total_cents,
            "quote computed",
        ),
        Err(e) => tracing::warn!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            error = %e,
            "quote failed",
        ),
    }
    result
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]
mod tests {
    use super::{
        compute_quote, international_surcharge, parse_rate_card, quote_with_source, Parcel,
        QuoteError, RateCardSource, Zones,
    };

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn sample_zones() -> Zones {
        parse_rate_card(SAMPLE).expect("sample rate card parses")
    }

    #[test]
    fn matches_first_band_at_or_above_weight() {
        let zones = sample_zones();
        let q = compute_quote(
            &Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            },
            &zones,
        )
        .unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn one_gram_over_a_threshold_falls_into_the_next_band() {
        let zones = sample_zones();
        let q = compute_quote(
            &Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            },
            &zones,
        )
        .unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn ten_thousand_grams_is_the_no_surcharge_boundary() {
        let zones = sample_zones();
        let q = compute_quote(
            &Parcel {
                weight_grams: 10_000,
                zone: "domestic".into(),
            },
            &zones,
        )
        .unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn weight_strictly_over_ten_thousand_adds_five_hundred_cents() {
        let zones = sample_zones();
        let q = compute_quote(
            &Parcel {
                weight_grams: 10_001,
                zone: "domestic".into(),
            },
            &zones,
        )
        .unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20_000);
    }

    #[test]
    fn international_adds_twenty_percent_rounded_half_up() {
        let zones = sample_zones();
        // base 1499 → 20% = 299.8 → 300
        let q = compute_quote(
            &Parcel {
                weight_grams: 250,
                zone: "international".into(),
            },
            &zones,
        )
        .unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn heavy_international_stacks_both_surcharges() {
        let zones = sample_zones();
        // base 4999 → 20% = 999.8 → 1000, plus 500 for weight > 10000
        let q = compute_quote(
            &Parcel {
                weight_grams: 15_000,
                zone: "international".into(),
            },
            &zones,
        )
        .unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
        assert_eq!(q.band_max_grams, 20_000);
    }

    #[test]
    fn international_surcharge_rounds_half_up() {
        // 20% of 1 = 0.2 → 0
        assert_eq!(international_surcharge(1), 0);
        // 20% of 3 = 0.6 → 1
        assert_eq!(international_surcharge(3), 1);
        // 20% of 100 = 20 exactly
        assert_eq!(international_surcharge(100), 20);
        // 20% of 1499 = 299.8 → 300
        assert_eq!(international_surcharge(1499), 300);
        // 20% of 4999 = 999.8 → 1000
        assert_eq!(international_surcharge(4999), 1000);
    }

    #[test]
    fn unknown_zone_carries_the_requested_zone_string() {
        let zones = sample_zones();
        let err = compute_quote(
            &Parcel {
                weight_grams: 100,
                zone: "lunar".into(),
            },
            &zones,
        )
        .unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".into()));
    }

    #[test]
    fn overweight_reports_the_zones_largest_band_as_limit() {
        let zones = sample_zones();
        let err = compute_quote(
            &Parcel {
                weight_grams: 25_000,
                zone: "domestic".into(),
            },
            &zones,
        )
        .unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000,
            }
        );
    }

    #[test]
    fn blank_lines_and_comments_are_skipped() {
        let zones = parse_rate_card("# hdr\n\n   \ndomestic\t500\t100\n").unwrap();
        assert_eq!(zones.get("domestic").unwrap().len(), 1);
    }

    #[test]
    fn malformed_line_reports_the_one_based_number_counting_every_line() {
        // 1: header comment, 2: blank, 3: valid, 4: bad (wrong field count)
        let err = parse_rate_card("# h\n\ndomestic\t500\t100\nnot-tabbed\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn malformed_number_reports_the_line_number() {
        let err = parse_rate_card("# h\ndomestic\tnope\t100\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn malformed_negative_number_is_rejected() {
        let err = parse_rate_card("domestic\t-1\t100\n").unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn bands_out_of_order_in_the_file_still_sort_ascending() {
        let card = "\
domestic\t20000\t1799
domestic\t500\t599
domestic\t2000\t899
";
        let zones = parse_rate_card(card).unwrap();
        let q = compute_quote(
            &Parcel {
                weight_grams: 1500,
                zone: "domestic".into(),
            },
            &zones,
        )
        .unwrap();
        assert_eq!(q.band_max_grams, 2000);
        assert_eq!(q.base_cents, 899);
    }

    #[test]
    fn quote_error_implements_display_and_error() {
        let err: QuoteError = QuoteError::RateCardUnavailable;
        let as_error: &dyn std::error::Error = &err;
        assert_eq!(as_error.to_string(), "rate card unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 7 }.to_string(),
            "malformed rate card at line 7"
        );
        assert_eq!(
            QuoteError::UnknownZone("lunar".into()).to_string(),
            "unknown zone: lunar"
        );
        assert_eq!(
            QuoteError::Overweight {
                grams: 30_000,
                limit: 20_000,
            }
            .to_string(),
            "parcel weight 30000g exceeds zone limit 20000g"
        );
    }

    // ---- Wiring through the source gateway (no filesystem, no env) ----

    struct FakeSource<'a>(&'a str);
    impl RateCardSource for FakeSource<'_> {
        fn load(&self) -> Result<String, QuoteError> {
            Ok(self.0.to_owned())
        }
    }

    struct FailingSource;
    impl RateCardSource for FailingSource {
        fn load(&self) -> Result<String, QuoteError> {
            Err(QuoteError::RateCardUnavailable)
        }
    }

    #[test]
    fn quote_with_source_reads_content_from_the_gateway() {
        let q = quote_with_source(
            &Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            },
            &FakeSource(SAMPLE),
        )
        .unwrap();
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn quote_with_source_surfaces_gateway_failure() {
        let err = quote_with_source(
            &Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            },
            &FailingSource,
        )
        .unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }
}
