//! Human-readable labels for the zone keys used in rate cards.

/// Return a human-readable label for a zone key, falling back to the key
/// itself when no label is known.
#[must_use]
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}

#[cfg(test)]
mod tests {
    use super::zone_label;

    #[test]
    fn known_zones_get_friendly_labels() {
        assert_eq!(zone_label("domestic"), "Domestic ground");
        assert_eq!(zone_label("international"), "International air");
    }

    #[test]
    fn unknown_zone_falls_back_to_the_input_key() {
        assert_eq!(zone_label("lunar"), "lunar");
    }
}
