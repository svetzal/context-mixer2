//! End-to-end wiring tests that exercise the real filesystem plus the
//! `RATECARD_PATH` environment variable through the public `quote` entry
//! point. Because process-wide env access must be serialized, every test
//! here acquires the same mutex before touching `RATECARD_PATH`.

#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]
// std::env::{set_var, remove_var} are `unsafe` on current Rust because they
// mutate process-wide state. The ENV_LOCK below serializes every access
// from this test binary, which is the invariant the unsafe API requires.
#![allow(unsafe_code)]

use std::io::Write;
use std::sync::Mutex;

use ratecard::{quote, Parcel, QuoteError};
use tempfile::NamedTempFile;

static ENV_LOCK: Mutex<()> = Mutex::new(());

const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn with_ratecard<R>(contents: &str, f: impl FnOnce() -> R) -> R {
    let _guard = ENV_LOCK.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
    let mut file = NamedTempFile::new().expect("create temp file");
    file.write_all(contents.as_bytes()).expect("write rate card");
    file.flush().expect("flush rate card");
    let path = file.path().to_string_lossy().into_owned();
    // SAFETY: ENV_LOCK serializes concurrent env access in this test binary.
    unsafe { std::env::set_var("RATECARD_PATH", &path) };
    let result = f();
    // SAFETY: as above.
    unsafe { std::env::remove_var("RATECARD_PATH") };
    result
}

fn with_env_unset<R>(f: impl FnOnce() -> R) -> R {
    let _guard = ENV_LOCK.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
    // SAFETY: ENV_LOCK serializes concurrent env access in this test binary.
    unsafe { std::env::remove_var("RATECARD_PATH") };
    f()
}

fn with_env_pointing_at<R>(path: &str, f: impl FnOnce() -> R) -> R {
    let _guard = ENV_LOCK.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
    // SAFETY: ENV_LOCK serializes concurrent env access in this test binary.
    unsafe { std::env::set_var("RATECARD_PATH", path) };
    let result = f();
    // SAFETY: as above.
    unsafe { std::env::remove_var("RATECARD_PATH") };
    result
}

#[test]
fn quote_reads_the_rate_card_from_the_env_path() {
    with_ratecard(SAMPLE, || {
        let q = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    });
}

#[test]
fn quote_reports_rate_card_unavailable_when_env_is_unset() {
    with_env_unset(|| {
        let err = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    });
}

#[test]
fn quote_reports_rate_card_unavailable_when_file_missing() {
    with_env_pointing_at("/definitely/not/a/real/ratecard.tsv", || {
        let err = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    });
}

#[test]
fn quote_reports_the_line_number_of_a_malformed_line() {
    // 1: header, 2: valid, 3: bad
    let bad = "# hdr\ndomestic\t500\t599\nbroken line here\n";
    with_ratecard(bad, || {
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    });
}

#[test]
fn quote_reports_unknown_zone_end_to_end() {
    with_ratecard(SAMPLE, || {
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "lunar".into(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".into()));
    });
}

#[test]
fn quote_reports_overweight_end_to_end() {
    with_ratecard(SAMPLE, || {
        let err = quote(&Parcel {
            weight_grams: 25_000,
            zone: "international".into(),
        })
        .unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000,
            }
        );
    });
}

#[test]
fn quote_applies_stacked_surcharges_end_to_end() {
    with_ratecard(SAMPLE, || {
        let q = quote(&Parcel {
            weight_grams: 15_000,
            zone: "international".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
        assert_eq!(q.band_max_grams, 20_000);
    });
}
