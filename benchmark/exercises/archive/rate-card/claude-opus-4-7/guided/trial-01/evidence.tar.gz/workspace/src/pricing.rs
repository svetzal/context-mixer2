//! Pure quote calculation from a parsed rate card.

use crate::model::{Parcel, Quote, QuoteError};
use crate::parse::RateCard;

const INTERNATIONAL_ZONE: &str = "international";
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

pub(crate) fn compute_quote(parcel: &Parcel, card: &RateCard) -> Result<Quote, QuoteError> {
    let bands = card
        .bands_for(&parcel.zone)
        .filter(|b| !b.is_empty())
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let Some(band) = bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
    else {
        let limit = bands
            .iter()
            .map(|b| b.band_max_grams)
            .max()
            .unwrap_or(0);
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        });
    };

    let base_cents = band.cents;
    let heavy = if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    };
    let intl = if parcel.zone == INTERNATIONAL_ZONE {
        half_up_percent(base_cents, INTERNATIONAL_SURCHARGE_PERCENT)
    } else {
        0
    };
    let surcharge_cents = heavy + intl;
    let total_cents = base_cents + surcharge_cents;
    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

fn half_up_percent(value: u64, percent: u64) -> u64 {
    (value * percent + 50) / 100
}

#[cfg(test)]
#[allow(clippy::unwrap_used)]
mod tests {
    use super::*;
    use crate::parse::parse_rate_card;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn sample_card() -> RateCard {
        parse_rate_card(SAMPLE).unwrap()
    }

    #[test]
    fn picks_the_first_band_that_covers_the_weight() {
        let card = sample_card();
        let q = compute_quote(
            &Parcel { weight_grams: 750, zone: "domestic".into() },
            &card,
        )
        .unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 899);
    }

    #[test]
    fn a_weight_at_the_band_boundary_falls_in_that_band() {
        let card = sample_card();
        let q = compute_quote(
            &Parcel { weight_grams: 500, zone: "domestic".into() },
            &card,
        )
        .unwrap();
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn zero_weight_is_priced_at_the_smallest_band() {
        let card = sample_card();
        let q = compute_quote(
            &Parcel { weight_grams: 0, zone: "domestic".into() },
            &card,
        )
        .unwrap();
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.total_cents, 599);
    }

    #[test]
    fn heavy_parcels_pay_a_flat_surcharge() {
        let card = sample_card();
        let q = compute_quote(
            &Parcel { weight_grams: 15_000, zone: "domestic".into() },
            &card,
        )
        .unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20_000);
    }

    #[test]
    fn ten_thousand_grams_exactly_is_not_heavy() {
        let card = sample_card();
        let q = compute_quote(
            &Parcel { weight_grams: 10_000, zone: "domestic".into() },
            &card,
        )
        .unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn international_zone_pays_twenty_percent_of_base() {
        let card = sample_card();
        let q = compute_quote(
            &Parcel { weight_grams: 250, zone: "international".into() },
            &card,
        )
        .unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_surcharge_rounds_half_up_to_the_cent() {
        let card = parse_rate_card("z\t500\t123\n").unwrap();
        let q = compute_quote(
            &Parcel { weight_grams: 100, zone: "z".into() },
            &card,
        )
        .unwrap();
        assert_eq!(q.base_cents, 123);
        assert_eq!(q.surcharge_cents, 0);

        let card = parse_rate_card("international\t500\t123\n").unwrap();
        let q = compute_quote(
            &Parcel { weight_grams: 100, zone: "international".into() },
            &card,
        )
        .unwrap();
        assert_eq!(q.surcharge_cents, 25);
    }

    #[test]
    fn heavy_and_international_surcharges_stack() {
        let card = sample_card();
        let q = compute_quote(
            &Parcel { weight_grams: 15_000, zone: "international".into() },
            &card,
        )
        .unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 500 + 1000);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn absent_zone_becomes_unknown_zone_carrying_the_request() {
        let card = sample_card();
        let err = compute_quote(
            &Parcel { weight_grams: 100, zone: "outer-space".into() },
            &card,
        )
        .unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("outer-space".into()));
    }

    #[test]
    fn weight_above_largest_band_becomes_overweight_at_the_ceiling() {
        let card = sample_card();
        let err = compute_quote(
            &Parcel { weight_grams: 25_000, zone: "domestic".into() },
            &card,
        )
        .unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight { grams: 25_000, limit: 20_000 }
        );
    }
}
