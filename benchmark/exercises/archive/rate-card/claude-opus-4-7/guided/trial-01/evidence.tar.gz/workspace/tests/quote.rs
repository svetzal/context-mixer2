//! End-to-end tests of `quote`, exercising the real env + filesystem shell.
//!
//! Tests here mutate `RATECARD_PATH` and so must run under a shared mutex.

#![allow(clippy::unwrap_used)]

use std::io::Write;
use std::sync::{Mutex, MutexGuard, OnceLock};

use ratecard::{quote, Parcel, QuoteError};
use tempfile::NamedTempFile;

const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn env_lock() -> MutexGuard<'static, ()> {
    static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    LOCK.get_or_init(|| Mutex::new(()))
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner)
}

fn card_file(text: &str) -> NamedTempFile {
    let mut file = NamedTempFile::new().unwrap();
    file.write_all(text.as_bytes()).unwrap();
    file.flush().unwrap();
    file
}

fn with_card<F, T>(text: &str, f: F) -> T
where
    F: FnOnce() -> T,
{
    let _guard = env_lock();
    let file = card_file(text);
    std::env::set_var("RATECARD_PATH", file.path());
    let out = f();
    std::env::remove_var("RATECARD_PATH");
    out
}

fn with_env<F, T>(f: F) -> T
where
    F: FnOnce() -> T,
{
    let _guard = env_lock();
    std::env::remove_var("RATECARD_PATH");
    f()
}

#[test]
fn quote_reads_the_env_pointed_card_and_prices_domestic() {
    with_card(SAMPLE_CARD, || {
        let q = quote(&Parcel { weight_grams: 250, zone: "domestic".into() }).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    });
}

#[test]
fn quote_prices_international_with_stacked_surcharges() {
    with_card(SAMPLE_CARD, || {
        let q = quote(&Parcel {
            weight_grams: 15_000,
            zone: "international".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 500 + 1000);
        assert_eq!(q.total_cents, 6499);
        assert_eq!(q.band_max_grams, 20_000);
    });
}

#[test]
fn unknown_zone_carries_the_requested_zone() {
    with_card(SAMPLE_CARD, || {
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "lunar".into(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".into()));
    });
}

#[test]
fn overweight_reports_the_zone_ceiling() {
    with_card(SAMPLE_CARD, || {
        let err = quote(&Parcel {
            weight_grams: 25_000,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight { grams: 25_000, limit: 20_000 }
        );
    });
}

#[test]
fn missing_env_var_is_unavailable() {
    let err = with_env(|| {
        quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err()
    });
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn unreadable_path_is_unavailable() {
    let _guard = env_lock();
    std::env::set_var("RATECARD_PATH", "/nonexistent/path/definitely/not/here.tsv");
    let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
    std::env::remove_var("RATECARD_PATH");
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn malformed_rate_card_surfaces_line_number() {
    with_card("# header\n\ndomestic\t500\n", || {
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    });
}

#[test]
fn quote_error_is_a_boxed_std_error() {
    let e = QuoteError::UnknownZone("moon".into());
    let boxed: Box<dyn std::error::Error> = Box::new(e);
    assert_eq!(boxed.to_string(), "unknown zone: moon");
}
