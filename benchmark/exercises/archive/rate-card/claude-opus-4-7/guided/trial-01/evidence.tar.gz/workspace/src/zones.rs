//! Human-facing labels for shipping zones.

/// Return a display label for a zone key, falling back to the key itself.
#[must_use]
pub fn zone_label(zone: &str) -> &str {
    match zone {
        "domestic" => "Domestic ground",
        "international" => "International air",
        other => other,
    }
}
