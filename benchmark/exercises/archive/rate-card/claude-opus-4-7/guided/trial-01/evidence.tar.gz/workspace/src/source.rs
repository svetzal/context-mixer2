//! Sources of rate card text.
//!
//! The [`RateCardSource`] gateway wraps the environment and filesystem so the
//! pricing pipeline can be exercised without real I/O.

use crate::model::QuoteError;

pub(crate) const RATECARD_PATH_ENV: &str = "RATECARD_PATH";

pub(crate) trait RateCardSource {
    fn read(&self) -> Result<String, QuoteError>;
}

pub(crate) struct EnvRateCardSource;

impl RateCardSource for EnvRateCardSource {
    fn read(&self) -> Result<String, QuoteError> {
        let path =
            std::env::var(RATECARD_PATH_ENV).map_err(|_| QuoteError::RateCardUnavailable)?;
        std::fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}
