//! Data types exchanged with callers of the crate.

use std::fmt;

/// A parcel awaiting a shipping quote.
#[derive(Debug, Clone)]
pub struct Parcel {
    /// Weight of the parcel in grams.
    pub weight_grams: u32,
    /// Shipping zone key matched against the rate card.
    pub zone: String,
}

/// The priced result for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Base cents drawn from the matched rate band.
    pub base_cents: u64,
    /// Total surcharges added on top of the base.
    pub surcharge_cents: u64,
    /// The amount the customer pays: `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// Upper weight bound in grams of the matched band.
    pub band_max_grams: u32,
}

/// Errors surfaced by [`crate::quote`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card file could not be located or read.
    RateCardUnavailable,
    /// A line in the rate card was malformed.
    ///
    /// `line` is the 1-based offset in the source file, counting blanks and
    /// comments.
    MalformedRateCard {
        /// 1-based line number of the offending line.
        line: usize,
    },
    /// The parcel's zone was not represented in the rate card.
    UnknownZone(String),
    /// The parcel exceeded the largest band available for its zone.
    Overweight {
        /// The parcel's weight in grams.
        grams: u32,
        /// The largest `band_max_grams` in the zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => f.write_str("rate card unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}
