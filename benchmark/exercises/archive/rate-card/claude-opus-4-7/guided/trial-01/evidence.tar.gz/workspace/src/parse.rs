//! Parse rate card text into an in-memory structure.

use std::collections::HashMap;

use crate::model::QuoteError;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct Band {
    pub(crate) band_max_grams: u32,
    pub(crate) cents: u64,
}

#[derive(Debug, Clone, Default)]
pub(crate) struct RateCard {
    zones: HashMap<String, Vec<Band>>,
}

impl RateCard {
    pub(crate) fn bands_for(&self, zone: &str) -> Option<&[Band]> {
        self.zones.get(zone).map(Vec::as_slice)
    }
}

pub(crate) fn parse_rate_card(text: &str) -> Result<RateCard, QuoteError> {
    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();
    for (idx, line) in text.lines().enumerate() {
        let line_no = idx + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let mut parts = line.split('\t');
        let (Some(zone), Some(grams), Some(cents), None) =
            (parts.next(), parts.next(), parts.next(), parts.next())
        else {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        };
        let band_max_grams: u32 = grams
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents: u64 = cents
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        zones
            .entry(zone.to_owned())
            .or_default()
            .push(Band { band_max_grams, cents });
    }
    for bands in zones.values_mut() {
        bands.sort_by_key(|b| b.band_max_grams);
    }
    Ok(RateCard { zones })
}

#[cfg(test)]
#[allow(clippy::unwrap_used)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn parses_sample_card_and_sorts_bands_ascending() {
        let card = parse_rate_card(SAMPLE).unwrap();
        let dom = card.bands_for("domestic").unwrap();
        assert_eq!(
            dom,
            &[
                Band { band_max_grams: 500, cents: 599 },
                Band { band_max_grams: 2000, cents: 899 },
                Band { band_max_grams: 20000, cents: 1799 },
            ]
        );
        let intl = card.bands_for("international").unwrap();
        assert_eq!(
            intl,
            &[
                Band { band_max_grams: 500, cents: 1499 },
                Band { band_max_grams: 20000, cents: 4999 },
            ]
        );
    }

    #[test]
    fn skips_blanks_and_comments_but_counts_them_in_line_numbers() {
        let card = "# header line\n\ndomestic\t500\t599\n";
        let parsed = parse_rate_card(card).unwrap();
        assert_eq!(parsed.bands_for("domestic").unwrap().len(), 1);
    }

    #[test]
    fn wrong_field_count_reports_the_offending_line() {
        let card = "# header\ndomestic\t500\n";
        let err = parse_rate_card(card).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn extra_fields_are_malformed() {
        let card = "domestic\t500\t599\textra\n";
        let err = parse_rate_card(card).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn nonnumeric_grams_are_malformed_with_line_number() {
        let card = "\n\ndomestic\tabc\t599\n";
        let err = parse_rate_card(card).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn nonnumeric_cents_are_malformed_with_line_number() {
        let card = "domestic\t500\tnope\n";
        let err = parse_rate_card(card).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn bands_arrive_out_of_order_and_are_sorted() {
        let card = "z\t2000\t2\nz\t500\t1\nz\t1000\t9\n";
        let parsed = parse_rate_card(card).unwrap();
        let bands = parsed.bands_for("z").unwrap();
        let grams: Vec<u32> = bands.iter().map(|b| b.band_max_grams).collect();
        assert_eq!(grams, vec![500, 1000, 2000]);
    }
}
