//! Shipping quotes from a zone rate card.
//!
//! [`quote`] reads a tab-separated rate card from the path in `RATECARD_PATH`
//! and prices a [`Parcel`] into a [`Quote`]. The public data types and error
//! variants are the crate's stable contract.
//!
//! # Example
//!
//! ```no_run
//! use ratecard::{quote, Parcel};
//!
//! let parcel = Parcel { weight_grams: 750, zone: "domestic".into() };
//! match quote(&parcel) {
//!     Ok(q) => println!("total cents: {}", q.total_cents),
//!     Err(e) => eprintln!("could not quote: {e}"),
//! }
//! ```

pub mod zones;

mod model;
mod parse;
mod pricing;
mod source;

pub use model::{Parcel, Quote, QuoteError};

use source::{EnvRateCardSource, RateCardSource};

/// Price a parcel against the deployed rate card.
///
/// The rate card is read from the path in the `RATECARD_PATH` environment
/// variable. See the crate documentation for the file format and the pricing
/// rules that govern the returned [`Quote`].
///
/// # Errors
///
/// Returns [`QuoteError::RateCardUnavailable`] if the environment variable is
/// unset or the file cannot be read; [`QuoteError::MalformedRateCard`] if a
/// line does not parse; [`QuoteError::UnknownZone`] if the parcel's zone has
/// no bands; [`QuoteError::Overweight`] if the parcel exceeds the largest
/// band for its zone.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_with(parcel, &EnvRateCardSource)
}

fn quote_with(parcel: &Parcel, source: &dyn RateCardSource) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "ratecard.quote",
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
    );
    let _guard = span.enter();

    let result = (|| {
        let text = source.read()?;
        let card = parse::parse_rate_card(&text)?;
        pricing::compute_quote(parcel, &card)
    })();

    match &result {
        Ok(q) => tracing::info!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            total_cents = q.total_cents,
            "quoted"
        ),
        Err(e) => tracing::warn!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            error = %e,
            "quote failed"
        ),
    }

    result
}

#[cfg(test)]
#[allow(clippy::unwrap_used)]
mod tests {
    use super::*;

    struct StaticSource(&'static str);

    impl RateCardSource for StaticSource {
        fn read(&self) -> Result<String, QuoteError> {
            Ok(self.0.to_owned())
        }
    }

    struct BrokenSource;

    impl RateCardSource for BrokenSource {
        fn read(&self) -> Result<String, QuoteError> {
            Err(QuoteError::RateCardUnavailable)
        }
    }

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn wires_source_parse_and_pricing_together() {
        let q = quote_with(
            &Parcel { weight_grams: 250, zone: "domestic".into() },
            &StaticSource(SAMPLE),
        )
        .unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn propagates_source_unavailability() {
        let err = quote_with(
            &Parcel { weight_grams: 250, zone: "domestic".into() },
            &BrokenSource,
        )
        .unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn propagates_parse_errors() {
        let err = quote_with(
            &Parcel { weight_grams: 250, zone: "domestic".into() },
            &StaticSource("garbage without tabs\n"),
        )
        .unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn display_and_error_impl_are_exposed() {
        let e: Box<dyn std::error::Error> = Box::new(QuoteError::UnknownZone("moon".into()));
        assert_eq!(format!("{e}"), "unknown zone: moon");
    }
}
