use crate::QuoteError;
use crate::pricing::RateCard;

/// Parse the textual representation of a rate card into a [`RateCard`].
///
/// The format is tab-separated with exactly three fields per row
/// (`zone`, `band_max_grams`, `cents`). Blank lines and lines beginning
/// with `#` are ignored, but they still count toward the 1-based line
/// number reported by [`QuoteError::MalformedRateCard`].
pub(crate) fn parse(input: &str) -> Result<RateCard, QuoteError> {
    let mut card = RateCard::new();
    for (idx, line) in input.lines().enumerate() {
        let line_no = idx + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }
        let max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        card.insert(parts[0].to_owned(), max_grams, cents);
    }
    Ok(card.finalize())
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn parses_the_documented_sample() {
        let card = parse(SAMPLE).expect("sample should parse");
        assert_eq!(card.zone_count(), 2);
        assert!(card.has_zone("domestic"));
        assert!(card.has_zone("international"));
    }

    #[test]
    fn skips_blank_and_comment_lines() {
        let text = "\n# comment\n\ndomestic\t100\t50\n";
        let card = parse(text).expect("should parse");
        assert!(card.has_zone("domestic"));
    }

    #[test]
    fn reports_wrong_field_count_with_line_number() {
        // Line 1: comment; line 2: blank; line 3: malformed (two fields).
        let text = "# hi\n\ndomestic\t100\n";
        let err = parse(text).expect_err("should fail");
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn reports_unparseable_grams_with_line_number() {
        let text = "# header\ndomestic\tabc\t50\n";
        let err = parse(text).expect_err("should fail");
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn reports_unparseable_cents_with_line_number() {
        let text = "domestic\t500\tnope\n";
        let err = parse(text).expect_err("should fail");
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn negative_grams_are_malformed() {
        let text = "domestic\t-1\t50\n";
        let err = parse(text).expect_err("should fail");
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn line_counting_includes_every_prior_line() {
        // Lines: 1 blank, 2 comment, 3 valid, 4 comment, 5 malformed.
        let text = "\n# a\ndomestic\t100\t10\n# b\ndomestic\tX\t20\n";
        let err = parse(text).expect_err("should fail");
        assert_eq!(err, QuoteError::MalformedRateCard { line: 5 });
    }

    #[test]
    fn empty_input_yields_empty_card() {
        let card = parse("").expect("empty parses");
        assert_eq!(card.zone_count(), 0);
    }
}
