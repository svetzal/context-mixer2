//! Shipping rate quotes computed from an operator-maintained rate card.
//!
//! Operations edits a tab-separated card on disk and redeploys it without a
//! code change. The [`quote`] entry point reads that card and turns a
//! [`Parcel`] into a [`Quote`], returning a [`QuoteError`] for the recoverable
//! failure modes that callers must handle.
//!
//! ```
//! use ratecard::{Parcel, Quote, QuoteError};
//!
//! let parcel = Parcel { weight_grams: 100, zone: "domestic".into() };
//! // A `Quote` value carries the numbers a caller needs to price a shipment.
//! let example = Quote {
//!     base_cents: 599,
//!     surcharge_cents: 0,
//!     total_cents: 599,
//!     band_max_grams: 500,
//! };
//! assert_eq!(example.base_cents + example.surcharge_cents, example.total_cents);
//! // `QuoteError` implements the standard error traits.
//! let err: Box<dyn std::error::Error> = Box::new(QuoteError::UnknownZone("mars".into()));
//! assert!(!err.to_string().is_empty());
//! # let _ = parcel;
//! ```

use std::fmt;

pub mod zones;

pub(crate) mod parse;
pub(crate) mod pricing;
mod shell;

pub use shell::quote;

/// A parcel to be quoted.
#[derive(Debug, Clone)]
pub struct Parcel {
    /// Parcel weight in whole grams.
    pub weight_grams: u32,
    /// Zone identifier as it appears in the rate card.
    pub zone: String,
}

/// A quotation produced from a rate card and parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// The base rate for the matching band, in cents.
    pub base_cents: u64,
    /// Surcharges added on top of the base rate, in cents.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// The `band_max_grams` of the band that matched.
    pub band_max_grams: u32,
}

/// Reasons a quote could not be produced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The `RATECARD_PATH` environment variable is unset, or the file it
    /// points to is missing or unreadable.
    RateCardUnavailable,
    /// A line in the rate card is not three tab-separated fields, or its
    /// numeric fields did not parse. `line` is 1-based and counts every line
    /// in the file, including comments and blank lines.
    MalformedRateCard {
        /// 1-based line number of the offending line.
        line: usize,
    },
    /// The requested zone is not present in the rate card.
    UnknownZone(String),
    /// The parcel weight exceeds the largest band available for its zone.
    Overweight {
        /// The requested parcel weight in grams.
        grams: u32,
        /// The largest `band_max_grams` value defined for the zone.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => f.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone '{zone}'"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds zone limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}
