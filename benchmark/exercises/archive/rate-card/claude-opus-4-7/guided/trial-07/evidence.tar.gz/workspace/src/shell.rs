use std::path::PathBuf;

use crate::{Parcel, Quote, QuoteError, parse};

const ENV_VAR: &str = "RATECARD_PATH";

/// Produce a quote for `parcel` by consulting the rate card at
/// `RATECARD_PATH`.
///
/// Every call emits a `tracing` event named `quote` with fields `zone`,
/// `weight_grams`, and (on success) `total_cents`, so operators can correlate
/// individual quotations with the wider request they belong to.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "quote",
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
    );
    let _enter = span.enter();

    let result = load_and_price(parcel);
    if let Ok(ref q) = result {
        tracing::info!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            total_cents = q.total_cents,
            "quote",
        );
    }
    result
}

fn load_and_price(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = std::env::var_os(ENV_VAR).ok_or(QuoteError::RateCardUnavailable)?;
    let path = PathBuf::from(path);
    let contents = std::fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = parse::parse(&contents)?;
    card.price(parcel)
}
