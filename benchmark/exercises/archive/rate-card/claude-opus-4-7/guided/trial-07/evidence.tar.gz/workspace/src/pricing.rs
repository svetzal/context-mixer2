use std::collections::BTreeMap;

use crate::{Parcel, Quote, QuoteError};

const INTERNATIONAL: &str = "international";
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_PERCENT: u64 = 20;

#[derive(Debug, Clone)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// An in-memory rate card: for each zone, the ordered list of price bands.
#[derive(Debug, Clone, Default)]
pub(crate) struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

impl RateCard {
    pub(crate) fn new() -> Self {
        Self::default()
    }

    pub(crate) fn insert(&mut self, zone: String, max_grams: u32, cents: u64) {
        self.zones
            .entry(zone)
            .or_default()
            .push(Band { max_grams, cents });
    }

    /// Sort each zone's bands into ascending order so `price` can walk them
    /// deterministically regardless of the file's row order.
    pub(crate) fn finalize(mut self) -> Self {
        for bands in self.zones.values_mut() {
            bands.sort_by_key(|b| b.max_grams);
        }
        self
    }

    pub(crate) fn price(&self, parcel: &Parcel) -> Result<Quote, QuoteError> {
        let bands = self
            .zones
            .get(&parcel.zone)
            .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

        // `bands` is sorted ascending by `max_grams` and non-empty (we only
        // insert entries alongside a band).
        let Some(band) = bands.iter().find(|b| b.max_grams >= parcel.weight_grams) else {
            let limit = bands.last().map_or(0, |b| b.max_grams);
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        };

        let base_cents = band.cents;
        let surcharge_cents = weight_surcharge(parcel.weight_grams)
            + zone_surcharge(&parcel.zone, base_cents);
        let total_cents = base_cents + surcharge_cents;

        Ok(Quote {
            base_cents,
            surcharge_cents,
            total_cents,
            band_max_grams: band.max_grams,
        })
    }

    #[cfg(test)]
    pub(crate) fn zone_count(&self) -> usize {
        self.zones.len()
    }

    #[cfg(test)]
    pub(crate) fn has_zone(&self, zone: &str) -> bool {
        self.zones.contains_key(zone)
    }
}

fn weight_surcharge(grams: u32) -> u64 {
    if grams > HEAVY_THRESHOLD_GRAMS {
        HEAVY_SURCHARGE_CENTS
    } else {
        0
    }
}

fn zone_surcharge(zone: &str, base_cents: u64) -> u64 {
    if zone == INTERNATIONAL {
        // 20% of base_cents, rounded half up to the nearest cent.
        (base_cents * INTERNATIONAL_PERCENT + 50) / 100
    } else {
        0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample_card() -> RateCard {
        let mut card = RateCard::new();
        card.insert("domestic".into(), 500, 599);
        card.insert("domestic".into(), 2000, 899);
        card.insert("domestic".into(), 20_000, 1799);
        card.insert("international".into(), 500, 1499);
        card.insert("international".into(), 20_000, 4999);
        card.finalize()
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_owned(),
        }
    }

    #[test]
    fn first_band_matches_at_boundary() {
        let quote = sample_card().price(&parcel(500, "domestic")).unwrap();
        assert_eq!(
            quote,
            Quote {
                base_cents: 599,
                surcharge_cents: 0,
                total_cents: 599,
                band_max_grams: 500,
            }
        );
    }

    #[test]
    fn middle_band_selected_by_weight() {
        let quote = sample_card().price(&parcel(501, "domestic")).unwrap();
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
    }

    #[test]
    fn heavy_parcel_pays_weight_surcharge() {
        // 10001g domestic: base 1799 + 500 weight surcharge = 2299
        let quote = sample_card()
            .price(&parcel(10_001, "domestic"))
            .unwrap();
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
        assert_eq!(quote.band_max_grams, 20_000);
    }

    #[test]
    fn ten_thousand_grams_exactly_has_no_weight_surcharge() {
        let quote = sample_card()
            .price(&parcel(10_000, "domestic"))
            .unwrap();
        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn international_pays_twenty_percent_surcharge() {
        // base 1499 -> 20% = 299.8 -> half up = 300
        let quote = sample_card().price(&parcel(400, "international")).unwrap();
        assert_eq!(quote.base_cents, 1499);
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn international_surcharge_rounds_half_up() {
        // base 4999 -> 20% = 999.8 -> 1000
        let quote = sample_card()
            .price(&parcel(15_000, "international"))
            .unwrap();
        assert_eq!(quote.base_cents, 4999);
        // heavy: +500, international: +1000 (rounded)
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn combined_surcharges_stack() {
        // 15000g international: base 4999 + 500 heavy + 1000 international = 6499
        let quote = sample_card()
            .price(&parcel(15_000, "international"))
            .unwrap();
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_carries_requested_name() {
        let err = sample_card().price(&parcel(100, "mars")).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("mars".into()));
    }

    #[test]
    fn overweight_reports_zone_limit() {
        let err = sample_card()
            .price(&parcel(20_001, "domestic"))
            .unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            }
        );
    }

    #[test]
    fn overweight_uses_that_zone_not_global() {
        // A zone with a smaller top band must report its own limit.
        let mut card = RateCard::new();
        card.insert("dom".into(), 100, 10);
        card.insert("intl".into(), 20_000, 500);
        let card = card.finalize();
        let err = card.price(&parcel(500, "dom")).unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 500,
                limit: 100
            }
        );
    }

    #[test]
    fn bands_out_of_order_still_price_correctly() {
        let mut card = RateCard::new();
        card.insert("domestic".into(), 20_000, 1799);
        card.insert("domestic".into(), 500, 599);
        card.insert("domestic".into(), 2000, 899);
        let card = card.finalize();
        let quote = card.price(&parcel(600, "domestic")).unwrap();
        assert_eq!(quote.band_max_grams, 2000);
        assert_eq!(quote.base_cents, 899);
    }

    #[test]
    fn zero_grams_matches_first_band() {
        let quote = sample_card().price(&parcel(0, "domestic")).unwrap();
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.base_cents, 599);
    }
}
