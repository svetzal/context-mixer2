//! Verifies that `quote` emits a tracing event carrying zone, weight, and
//! total per successful call. We install a temporary subscriber whose writer
//! captures into memory, then inspect the rendered line.

use std::io::{self, Write};
use std::sync::{Arc, Mutex};

use ratecard::{Parcel, quote};
use tempfile::NamedTempFile;
use tracing_subscriber::fmt::MakeWriter;

const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

#[derive(Clone, Default)]
struct SharedBuf {
    inner: Arc<Mutex<Vec<u8>>>,
}

impl SharedBuf {
    fn new() -> Self {
        Self::default()
    }

    fn snapshot(&self) -> String {
        let guard = self
            .inner
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        String::from_utf8_lossy(&guard).into_owned()
    }
}

impl Write for SharedBuf {
    fn write(&mut self, buf: &[u8]) -> io::Result<usize> {
        let mut guard = self
            .inner
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        guard.extend_from_slice(buf);
        Ok(buf.len())
    }
    fn flush(&mut self) -> io::Result<()> {
        Ok(())
    }
}

impl<'a> MakeWriter<'a> for SharedBuf {
    type Writer = SharedBuf;
    fn make_writer(&'a self) -> Self::Writer {
        self.clone()
    }
}

// `RATECARD_PATH` is process-wide. This file only has one test, so no lock
// beyond ordering with any other integration test file is needed — cargo
// runs different test binaries in separate processes.

#[test]
fn quote_emits_diagnostic_with_zone_weight_and_total() {
    let card = NamedTempFile::new().expect("temp");
    std::fs::write(card.path(), SAMPLE_CARD).expect("write card");
    std::env::set_var("RATECARD_PATH", card.path());

    let buf = SharedBuf::new();
    let subscriber = tracing_subscriber::fmt()
        .with_writer(buf.clone())
        .with_ansi(false)
        .with_target(false)
        .with_max_level(tracing::Level::INFO)
        .finish();

    let q = tracing::subscriber::with_default(subscriber, || {
        quote(&Parcel {
            weight_grams: 15_000,
            zone: "international".into(),
        })
    })
    .expect("should quote");

    std::env::remove_var("RATECARD_PATH");

    assert_eq!(q.total_cents, 6499);

    let rendered = buf.snapshot();
    assert!(
        rendered.contains("international"),
        "expected zone in trace, got: {rendered}"
    );
    assert!(
        rendered.contains("15000"),
        "expected weight_grams in trace, got: {rendered}"
    );
    assert!(
        rendered.contains("6499"),
        "expected total_cents in trace, got: {rendered}"
    );
}
