use std::io::Write;
use std::path::Path;
use std::sync::Mutex;

use ratecard::{Parcel, QuoteError, quote};
use tempfile::NamedTempFile;

const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

// `RATECARD_PATH` is process-wide; serialize every test that touches it.
static ENV_LOCK: Mutex<()> = Mutex::new(());

fn with_ratecard<R>(contents: &str, run: impl FnOnce() -> R) -> R {
    let guard = ENV_LOCK.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
    let mut file = NamedTempFile::new().expect("temp file");
    file.write_all(contents.as_bytes()).expect("write card");
    file.flush().expect("flush card");
    std::env::set_var("RATECARD_PATH", file.path());
    let out = run();
    std::env::remove_var("RATECARD_PATH");
    drop(guard);
    out
}

fn without_ratecard<R>(run: impl FnOnce() -> R) -> R {
    let guard = ENV_LOCK.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
    std::env::remove_var("RATECARD_PATH");
    let out = run();
    drop(guard);
    out
}

fn with_ratecard_at<R>(path: &Path, run: impl FnOnce() -> R) -> R {
    let guard = ENV_LOCK.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
    std::env::set_var("RATECARD_PATH", path);
    let out = run();
    std::env::remove_var("RATECARD_PATH");
    drop(guard);
    out
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel {
        weight_grams,
        zone: zone.to_owned(),
    }
}

#[test]
fn quote_reads_ratecard_from_env_var() {
    let q = with_ratecard(SAMPLE_CARD, || quote(&parcel(100, "domestic"))).unwrap();
    assert_eq!(q.base_cents, 599);
    assert_eq!(q.surcharge_cents, 0);
    assert_eq!(q.total_cents, 599);
    assert_eq!(q.band_max_grams, 500);
}

#[test]
fn quote_applies_heavy_surcharge() {
    let q = with_ratecard(SAMPLE_CARD, || quote(&parcel(15_000, "domestic"))).unwrap();
    assert_eq!(q.base_cents, 1799);
    assert_eq!(q.surcharge_cents, 500);
    assert_eq!(q.total_cents, 2299);
}

#[test]
fn quote_applies_international_surcharge() {
    let q = with_ratecard(SAMPLE_CARD, || quote(&parcel(400, "international"))).unwrap();
    assert_eq!(q.base_cents, 1499);
    // 20% of 1499 = 299.8 -> 300 half up.
    assert_eq!(q.surcharge_cents, 300);
    assert_eq!(q.total_cents, 1799);
}

#[test]
fn quote_stacks_surcharges_for_heavy_international() {
    let q = with_ratecard(SAMPLE_CARD, || quote(&parcel(15_000, "international"))).unwrap();
    assert_eq!(q.base_cents, 4999);
    // 20% of 4999 = 999.8 -> 1000; + 500 heavy = 1500
    assert_eq!(q.surcharge_cents, 1500);
    assert_eq!(q.total_cents, 6499);
}

#[test]
fn quote_reports_unknown_zone() {
    let err = with_ratecard(SAMPLE_CARD, || quote(&parcel(100, "mars"))).unwrap_err();
    assert_eq!(err, QuoteError::UnknownZone("mars".into()));
}

#[test]
fn quote_reports_overweight_with_zone_limit() {
    let err = with_ratecard(SAMPLE_CARD, || quote(&parcel(30_000, "international"))).unwrap_err();
    assert_eq!(
        err,
        QuoteError::Overweight {
            grams: 30_000,
            limit: 20_000,
        }
    );
}

#[test]
fn quote_reports_malformed_line_number_counting_comments_and_blanks() {
    // Line 1: comment; line 2: blank; line 3: valid; line 4: malformed.
    let card = "# header\n\ndomestic\t100\t50\ndomestic\tabc\t50\n";
    let err = with_ratecard(card, || quote(&parcel(50, "domestic"))).unwrap_err();
    assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
}

#[test]
fn quote_reports_unavailable_when_env_var_unset() {
    let err = without_ratecard(|| quote(&parcel(100, "domestic"))).unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn quote_reports_unavailable_when_file_missing() {
    // Point at a path that certainly doesn't exist.
    let missing = std::env::temp_dir().join("ratecard-does-not-exist-xyzzy.tsv");
    let _ = std::fs::remove_file(&missing);
    let err = with_ratecard_at(&missing, || quote(&parcel(100, "domestic"))).unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn quote_error_implements_display_and_error() {
    let e: Box<dyn std::error::Error> = Box::new(QuoteError::UnknownZone("mars".into()));
    assert!(e.to_string().contains("mars"));
    let e = QuoteError::Overweight { grams: 5, limit: 4 };
    assert!(format!("{e}").contains('5'));
    let e = QuoteError::MalformedRateCard { line: 42 };
    assert!(format!("{e}").contains("42"));
    let e = QuoteError::RateCardUnavailable;
    assert!(!format!("{e}").is_empty());
}
