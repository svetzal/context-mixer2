//! End-to-end wiring: exercise the public `quote` through the real
//! `RATECARD_PATH` env var + filesystem path. Env vars are process-global,
//! so tests here take a shared mutex before touching `RATECARD_PATH`.

use std::env;
use std::fs;
use std::sync::Mutex;

use ratecard::{quote, Parcel, QuoteError};

static ENV_LOCK: Mutex<()> = Mutex::new(());

const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

struct EnvGuard {
    previous: Option<String>,
    _lock: std::sync::MutexGuard<'static, ()>,
}

impl EnvGuard {
    fn set(path: &std::path::Path) -> Self {
        let lock = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let previous = env::var("RATECARD_PATH").ok();
        env::set_var("RATECARD_PATH", path);
        Self { previous, _lock: lock }
    }

    fn unset() -> Self {
        let lock = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let previous = env::var("RATECARD_PATH").ok();
        env::remove_var("RATECARD_PATH");
        Self { previous, _lock: lock }
    }
}

impl Drop for EnvGuard {
    fn drop(&mut self) {
        match &self.previous {
            Some(v) => env::set_var("RATECARD_PATH", v),
            None => env::remove_var("RATECARD_PATH"),
        }
    }
}

#[test]
fn quotes_a_domestic_parcel_end_to_end() {
    let dir = tempfile::tempdir().expect("tempdir");
    let path = dir.path().join("rates.tsv");
    fs::write(&path, SAMPLE).expect("write");
    let _guard = EnvGuard::set(&path);

    let q = quote(&Parcel { weight_grams: 1200, zone: "domestic".into() }).expect("ok");
    assert_eq!(q.base_cents, 899);
    assert_eq!(q.surcharge_cents, 0);
    assert_eq!(q.total_cents, 899);
    assert_eq!(q.band_max_grams, 2000);
}

#[test]
fn international_and_heavy_surcharge_stack_end_to_end() {
    let dir = tempfile::tempdir().expect("tempdir");
    let path = dir.path().join("rates.tsv");
    fs::write(&path, SAMPLE).expect("write");
    let _guard = EnvGuard::set(&path);

    let q = quote(&Parcel { weight_grams: 15_000, zone: "international".into() }).expect("ok");
    assert_eq!(q.base_cents, 4999);
    assert_eq!(q.surcharge_cents, 500 + 1000);
    assert_eq!(q.total_cents, 4999 + 500 + 1000);
    assert_eq!(q.band_max_grams, 20_000);
}

#[test]
fn missing_env_var_is_rate_card_unavailable() {
    let _guard = EnvGuard::unset();
    let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).expect_err("fail");
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn unreadable_path_is_rate_card_unavailable() {
    let dir = tempfile::tempdir().expect("tempdir");
    let path = dir.path().join("does-not-exist.tsv");
    let _guard = EnvGuard::set(&path);

    let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).expect_err("fail");
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn unknown_zone_reports_the_requested_zone() {
    let dir = tempfile::tempdir().expect("tempdir");
    let path = dir.path().join("rates.tsv");
    fs::write(&path, SAMPLE).expect("write");
    let _guard = EnvGuard::set(&path);

    let err = quote(&Parcel { weight_grams: 100, zone: "lunar".into() }).expect_err("fail");
    assert_eq!(err, QuoteError::UnknownZone("lunar".into()));
}

#[test]
fn overweight_reports_largest_band_as_limit() {
    let dir = tempfile::tempdir().expect("tempdir");
    let path = dir.path().join("rates.tsv");
    fs::write(&path, SAMPLE).expect("write");
    let _guard = EnvGuard::set(&path);

    let err = quote(&Parcel { weight_grams: 999_999, zone: "domestic".into() })
        .expect_err("fail");
    assert_eq!(
        err,
        QuoteError::Overweight { grams: 999_999, limit: 20_000 }
    );
}

#[test]
fn malformed_line_number_counts_blanks_and_comments() {
    let dir = tempfile::tempdir().expect("tempdir");
    let path = dir.path().join("rates.tsv");
    // line 1: comment, line 2: blank, line 3: valid, line 4: malformed
    let text = "# header\n\ndomestic\t500\t599\nbroken\n";
    fs::write(&path, text).expect("write");
    let _guard = EnvGuard::set(&path);

    let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).expect_err("fail");
    assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
}

#[test]
fn quote_error_implements_std_error() {
    fn assert_error<E: std::error::Error>() {}
    assert_error::<QuoteError>();
    let e: Box<dyn std::error::Error> = Box::new(QuoteError::RateCardUnavailable);
    assert!(e.to_string().contains("unavailable"));
}
