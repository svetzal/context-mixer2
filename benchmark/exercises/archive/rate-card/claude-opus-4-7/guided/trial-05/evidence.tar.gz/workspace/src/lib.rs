//! Shipping quotes computed from a tab-separated zone rate card.
//!
//! `quote` is the crate's single public function: pass a [`Parcel`] and it
//! reads the rate card at the `RATECARD_PATH` environment variable,
//! selects the matching band for the parcel's zone and weight, applies
//! surcharges, and returns a [`Quote`]. Failure modes are enumerated in
//! [`QuoteError`].

mod pricing;
mod source;
pub mod zones;

pub use pricing::{Parcel, Quote, QuoteError};

use source::{EnvFileSource, RateCardSource};

/// Compute a shipping quote for `parcel` using the rate card at
/// `RATECARD_PATH`.
///
/// See [`QuoteError`] for the enumerated failure modes.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_with_source(&EnvFileSource, parcel)
}

fn quote_with_source<S: RateCardSource>(
    source: &S,
    parcel: &Parcel,
) -> Result<Quote, QuoteError> {
    let raw = source.read()?;
    let card = pricing::parse_rate_card(&raw)?;
    let result = pricing::compute_quote(&card, parcel)?;
    tracing::info!(
        target: "ratecard::quote",
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = result.total_cents,
        "quote computed"
    );
    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::source::RateCardSource;

    struct FixedSource(&'static str);

    impl RateCardSource for FixedSource {
        fn read(&self) -> Result<String, QuoteError> {
            Ok(self.0.to_string())
        }
    }

    struct FailingSource;

    impl RateCardSource for FailingSource {
        fn read(&self) -> Result<String, QuoteError> {
            Err(QuoteError::RateCardUnavailable)
        }
    }

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn wires_source_through_parse_and_compute() {
        let src = FixedSource(SAMPLE);
        let q = quote_with_source(
            &src,
            &Parcel { weight_grams: 750, zone: "domestic".into() },
        )
        .expect("ok");
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn propagates_source_failure() {
        let err = quote_with_source(
            &FailingSource,
            &Parcel { weight_grams: 1, zone: "domestic".into() },
        )
        .expect_err("should fail");
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn propagates_parse_failure() {
        let src = FixedSource("broken line without tabs\n");
        let err = quote_with_source(
            &src,
            &Parcel { weight_grams: 1, zone: "domestic".into() },
        )
        .expect_err("should fail");
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }
}
