//! Rate-card source gateway.
//!
//! Wraps the process environment and filesystem behind a small trait so
//! core pricing can be exercised against in-memory fakes.

use std::env;
use std::fs;

use crate::pricing::QuoteError;

/// Source of raw rate-card text.
pub(crate) trait RateCardSource {
    fn read(&self) -> Result<String, QuoteError>;
}

/// Reads the file at the `RATECARD_PATH` environment variable.
pub(crate) struct EnvFileSource;

impl RateCardSource for EnvFileSource {
    fn read(&self) -> Result<String, QuoteError> {
        let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
        if path.is_empty() {
            return Err(QuoteError::RateCardUnavailable);
        }
        fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    struct FixedSource(&'static str);

    impl RateCardSource for FixedSource {
        fn read(&self) -> Result<String, QuoteError> {
            Ok(self.0.to_string())
        }
    }

    #[test]
    fn fake_source_returns_configured_text() {
        let src = FixedSource("domestic\t500\t599\n");
        assert_eq!(src.read().expect("ok"), "domestic\t500\t599\n");
    }
}
