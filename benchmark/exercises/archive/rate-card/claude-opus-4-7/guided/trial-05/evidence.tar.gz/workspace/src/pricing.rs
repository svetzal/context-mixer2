//! Pure quote calculation: rate-card parsing and band-based pricing.
//!
//! This module is deliberately I/O-free. Callers hand it a `&str` that
//! already contains the rate card and receive a `RateCard` value; from
//! there `compute_quote` produces a `Quote` (or a `QuoteError`) without
//! touching the filesystem, the clock, or any environment state.

use std::error::Error;
use std::fmt;

/// A parcel waiting to be quoted.
#[derive(Debug, Clone)]
pub struct Parcel {
    /// Weight in grams.
    pub weight_grams: u32,
    /// Zone identifier, matched against zones declared in the rate card.
    pub zone: String,
}

/// A priced quote for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Rate-card cents for the matching band, before surcharges.
    pub base_cents: u64,
    /// Sum of all applicable surcharges in cents.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// Upper weight bound of the matching band, in grams.
    pub band_max_grams: u32,
}

/// Every way `quote` can decline to produce a `Quote`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` was unset or the file could not be read.
    RateCardUnavailable,
    /// A rate-card line failed to parse; `line` is 1-based, counting every
    /// physical line including blanks and comments.
    MalformedRateCard { line: usize },
    /// The requested zone is not present in the rate card.
    UnknownZone(String),
    /// Parcel weight is above the zone's largest band.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => f.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => write!(
                f,
                "parcel weight {grams}g exceeds the largest band {limit}g"
            ),
        }
    }
}

impl Error for QuoteError {}

const INTERNATIONAL_ZONE: &str = "international";
const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_PERCENT: u64 = 20;

#[derive(Debug, Clone)]
pub(crate) struct Band {
    pub max_grams: u32,
    pub cents: u64,
}

/// Parsed rate card: an ordered list of (zone, ascending-bands) pairs.
#[derive(Debug, Clone, Default)]
pub(crate) struct RateCard {
    zones: Vec<(String, Vec<Band>)>,
}

impl RateCard {
    fn bands_for(&self, zone: &str) -> Option<&[Band]> {
        self.zones
            .iter()
            .find(|(z, _)| z == zone)
            .map(|(_, bands)| bands.as_slice())
    }
}

/// Parse a rate card from the tab-separated text.
///
/// Empty lines and lines whose first non-whitespace character is `#` are
/// ignored. Every other line must be exactly three tab-separated fields:
/// zone name, band upper bound in grams, and cents.
pub(crate) fn parse_rate_card(text: &str) -> Result<RateCard, QuoteError> {
    let mut card = RateCard::default();
    for (idx, line) in text.lines().enumerate() {
        let line_no = idx + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }
        let zone = parts[0];
        let max_grams = parts[1]
            .parse::<u32>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents = parts[2]
            .parse::<u64>()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let band = Band { max_grams, cents };
        if let Some((_, bands)) = card.zones.iter_mut().find(|(z, _)| z == zone) {
            bands.push(band);
        } else {
            card.zones.push((zone.to_string(), vec![band]));
        }
    }
    for (_, bands) in &mut card.zones {
        bands.sort_by_key(|b| b.max_grams);
    }
    Ok(card)
}

/// Compute the quote for `parcel` against a parsed `card`.
pub(crate) fn compute_quote(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = card
        .bands_for(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let limit = match bands.last() {
        Some(b) => b.max_grams,
        None => return Err(QuoteError::UnknownZone(parcel.zone.clone())),
    };
    let band = match bands.iter().find(|b| b.max_grams >= parcel.weight_grams) {
        Some(b) => b,
        None => {
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };
    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        surcharge_cents += HEAVY_SURCHARGE_CENTS;
    }
    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge_cents += round_half_up_percent(base_cents, INTERNATIONAL_PERCENT);
    }
    let total_cents = base_cents + surcharge_cents;
    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

/// `amount * percent / 100` with half-up rounding at the cent.
fn round_half_up_percent(amount: u64, percent: u64) -> u64 {
    (amount * percent + 50) / 100
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn card() -> RateCard {
        parse_rate_card(SAMPLE).expect("sample parses")
    }

    #[test]
    fn parses_sample_rate_card() {
        let c = card();
        let dom = c.bands_for("domestic").expect("domestic present");
        assert_eq!(dom.len(), 3);
        assert_eq!(dom[0].max_grams, 500);
        assert_eq!(dom[0].cents, 599);
        assert_eq!(dom[2].max_grams, 20000);
        let intl = c.bands_for("international").expect("intl present");
        assert_eq!(intl.len(), 2);
    }

    #[test]
    fn skips_blank_and_comment_lines() {
        let text = "\n# header\n\ndomestic\t500\t599\n";
        let c = parse_rate_card(text).expect("parses");
        assert_eq!(c.bands_for("domestic").expect("present").len(), 1);
    }

    #[test]
    fn sorts_bands_regardless_of_input_order() {
        let text = "domestic\t20000\t1799\ndomestic\t500\t599\ndomestic\t2000\t899\n";
        let c = parse_rate_card(text).expect("parses");
        let dom = c.bands_for("domestic").expect("present");
        assert_eq!(dom[0].max_grams, 500);
        assert_eq!(dom[1].max_grams, 2000);
        assert_eq!(dom[2].max_grams, 20000);
    }

    #[test]
    fn malformed_line_carries_1_based_line_number() {
        let text = "# header\n\ndomestic\t500\t599\nbroken line here\n";
        let err = parse_rate_card(text).expect_err("should fail");
        assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn malformed_when_number_does_not_parse() {
        let text = "domestic\tabc\t599\n";
        let err = parse_rate_card(text).expect_err("should fail");
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn malformed_when_wrong_column_count() {
        let text = "domestic\t500\n";
        let err = parse_rate_card(text).expect_err("should fail");
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn small_parcel_uses_first_band() {
        let q = compute_quote(&card(), &Parcel { weight_grams: 100, zone: "domestic".into() })
            .expect("quotes");
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn exact_band_boundary_uses_that_band() {
        let q = compute_quote(&card(), &Parcel { weight_grams: 500, zone: "domestic".into() })
            .expect("quotes");
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn one_over_boundary_uses_next_band() {
        let q = compute_quote(&card(), &Parcel { weight_grams: 501, zone: "domestic".into() })
            .expect("quotes");
        assert_eq!(q.band_max_grams, 2000);
        assert_eq!(q.base_cents, 899);
    }

    #[test]
    fn heavy_surcharge_added_above_10kg() {
        let q = compute_quote(&card(), &Parcel { weight_grams: 15000, zone: "domestic".into() })
            .expect("quotes");
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn heavy_surcharge_not_applied_at_exactly_10kg() {
        let q = compute_quote(&card(), &Parcel { weight_grams: 10_000, zone: "domestic".into() })
            .expect("quotes");
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn international_surcharge_is_twenty_percent_half_up() {
        // 1499 * 0.20 = 299.8 -> 300
        let q = compute_quote(&card(), &Parcel { weight_grams: 100, zone: "international".into() })
            .expect("quotes");
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_and_heavy_stack() {
        // 4999 base, +500 heavy, +1000 intl (4999*.2=999.8->1000)
        let q = compute_quote(
            &card(),
            &Parcel { weight_grams: 15_000, zone: "international".into() },
        )
        .expect("quotes");
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 500 + 1000);
        assert_eq!(q.total_cents, 4999 + 500 + 1000);
    }

    #[test]
    fn unknown_zone_carries_requested_zone() {
        let err = compute_quote(&card(), &Parcel { weight_grams: 100, zone: "mars".into() })
            .expect_err("should fail");
        assert_eq!(err, QuoteError::UnknownZone("mars".into()));
    }

    #[test]
    fn overweight_carries_largest_band_as_limit() {
        let err = compute_quote(
            &card(),
            &Parcel { weight_grams: 50_000, zone: "domestic".into() },
        )
        .expect_err("should fail");
        assert_eq!(
            err,
            QuoteError::Overweight { grams: 50_000, limit: 20_000 }
        );
    }

    #[test]
    fn half_up_rounds_up_at_exactly_half() {
        // 25 * 0.20 = 5.0 -> 5 ; 27 * 0.20 = 5.4 -> 5 ; 28 * 0.20 = 5.6 -> 6
        assert_eq!(round_half_up_percent(25, 20), 5);
        assert_eq!(round_half_up_percent(27, 20), 5);
        assert_eq!(round_half_up_percent(28, 20), 6);
        // exact half: value * .20 = X.5 when value*20 % 100 == 50
        // 15 * 20 = 300, mod 100 == 0 -> 3
        // 2525 * 20 = 50500, mod 100 == 0 -> 505
        // 2527 * 20 = 50540, mod 100 == 40 -> 505 (0.4)
        // pick 5 * 20 = 100 -> 1 (no half). Try 5 * 30 = 150, half up -> 2:
        assert_eq!(round_half_up_percent(5, 30), 2);
    }

    #[test]
    fn quote_error_display_is_informative() {
        assert!(QuoteError::RateCardUnavailable.to_string().contains("unavailable"));
        assert!(QuoteError::MalformedRateCard { line: 7 }.to_string().contains("7"));
        assert!(QuoteError::UnknownZone("mars".into()).to_string().contains("mars"));
        let msg = QuoteError::Overweight { grams: 50_000, limit: 20_000 }.to_string();
        assert!(msg.contains("50000"));
        assert!(msg.contains("20000"));
    }
}
