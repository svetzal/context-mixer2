//! Pure quoting logic: parsing a rate card and computing a quote from one.
//!
//! Nothing in this module touches the filesystem, environment, or clock.
//! All shell concerns live in [`crate::gateway`] and [`crate::quote`].

use std::collections::HashMap;

use crate::QuoteError;

/// A parcel presented for quoting.
#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// The result of pricing a parcel against the current rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// One priced weight band within a zone.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Band {
    max_grams: u32,
    cents: u64,
}

/// A parsed rate card, indexed by zone and sorted ascending by band ceiling.
#[derive(Debug, Clone, Default)]
pub struct RateCard {
    zones: HashMap<String, Vec<Band>>,
}

const INTERNATIONAL_ZONE: &str = "international";
const HEAVY_WEIGHT_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_WEIGHT_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

/// Parse the tab-separated rate card text into an in-memory [`RateCard`].
///
/// Blank lines and lines beginning with `#` are ignored. Line numbers reported
/// in [`QuoteError::MalformedRateCard`] are 1-based and count every line
/// including comments and blanks.
pub fn parse_rate_card(text: &str) -> Result<RateCard, QuoteError> {
    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();
    for (idx, raw_line) in text.lines().enumerate() {
        let line_number = idx + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = raw_line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let zone = fields[0];
        if zone.is_empty() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        zones
            .entry(zone.to_owned())
            .or_default()
            .push(Band { max_grams, cents });
    }
    for bands in zones.values_mut() {
        bands.sort_by_key(|band| band.max_grams);
    }
    Ok(RateCard { zones })
}

/// Compute the quote for `parcel` against `card`, applying surcharges.
pub fn compute_quote(parcel: &Parcel, card: &RateCard) -> Result<Quote, QuoteError> {
    let bands = card
        .zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    let Some(largest) = bands.last() else {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    };
    if parcel.weight_grams > largest.max_grams {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest.max_grams,
        });
    }
    let band = bands
        .iter()
        .find(|band| band.max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest.max_grams,
        })?;
    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > HEAVY_WEIGHT_THRESHOLD_GRAMS {
        surcharge_cents = surcharge_cents.saturating_add(HEAVY_WEIGHT_SURCHARGE_CENTS);
    }
    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge_cents = surcharge_cents.saturating_add(international_surcharge(base_cents));
    }
    let total_cents = base_cents.saturating_add(surcharge_cents);
    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

/// 20% of `base_cents`, rounded half-up to the nearest cent.
fn international_surcharge(base_cents: u64) -> u64 {
    (base_cents.saturating_mul(INTERNATIONAL_SURCHARGE_PERCENT) + 50) / 100
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]
mod tests {
    use super::*;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn card() -> RateCard {
        parse_rate_card(SAMPLE).expect("sample card parses")
    }

    #[test]
    fn skips_blank_and_comment_lines() {
        let text = "\n# comment\n\ndomestic\t500\t599\n";
        let parsed = parse_rate_card(text).expect("parses");
        assert_eq!(parsed.zones["domestic"].len(), 1);
    }

    #[test]
    fn line_numbers_count_blanks_and_comments() {
        let text = "\n# comment\n\nbroken line\n";
        match parse_rate_card(text) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 4),
            other => panic!("expected malformed error, got {other:?}"),
        }
    }

    #[test]
    fn rejects_non_numeric_max_grams() {
        let text = "domestic\tfive\t599\n";
        assert!(matches!(
            parse_rate_card(text),
            Err(QuoteError::MalformedRateCard { line: 1 })
        ));
    }

    #[test]
    fn rejects_non_numeric_cents() {
        let text = "domestic\t500\tcheap\n";
        assert!(matches!(
            parse_rate_card(text),
            Err(QuoteError::MalformedRateCard { line: 1 })
        ));
    }

    #[test]
    fn rejects_wrong_field_count() {
        let text = "domestic 500 599\n";
        assert!(matches!(
            parse_rate_card(text),
            Err(QuoteError::MalformedRateCard { line: 1 })
        ));
    }

    #[test]
    fn rejects_empty_zone() {
        let text = "\t500\t599\n";
        assert!(matches!(
            parse_rate_card(text),
            Err(QuoteError::MalformedRateCard { line: 1 })
        ));
    }

    #[test]
    fn matches_first_band_at_or_above_weight() {
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        let q = compute_quote(&parcel, &card()).expect("quotes");
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn boundary_weight_matches_its_band() {
        let parcel = Parcel {
            weight_grams: 500,
            zone: "domestic".into(),
        };
        let q = compute_quote(&parcel, &card()).expect("quotes");
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn just_above_a_band_falls_into_the_next() {
        let parcel = Parcel {
            weight_grams: 501,
            zone: "domestic".into(),
        };
        let q = compute_quote(&parcel, &card()).expect("quotes");
        assert_eq!(q.band_max_grams, 2000);
        assert_eq!(q.base_cents, 899);
    }

    #[test]
    fn heavy_domestic_gets_flat_surcharge() {
        let parcel = Parcel {
            weight_grams: 10_001,
            zone: "domestic".into(),
        };
        let q = compute_quote(&parcel, &card()).expect("quotes");
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20_000);
    }

    #[test]
    fn ten_kilo_domestic_gets_no_heavy_surcharge() {
        let parcel = Parcel {
            weight_grams: 10_000,
            zone: "domestic".into(),
        };
        let q = compute_quote(&parcel, &card()).expect("quotes");
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn international_gets_percentage_surcharge_half_up() {
        // 20% of 1499 = 299.8 → 300 (round half-up)
        let parcel = Parcel {
            weight_grams: 500,
            zone: "international".into(),
        };
        let q = compute_quote(&parcel, &card()).expect("quotes");
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn heavy_international_combines_surcharges() {
        // 20% of 4999 = 999.8 → 1000; plus 500 flat = 1500
        let parcel = Parcel {
            weight_grams: 15_000,
            zone: "international".into(),
        };
        let q = compute_quote(&parcel, &card()).expect("quotes");
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_carries_requested_zone() {
        let parcel = Parcel {
            weight_grams: 100,
            zone: "orbital".into(),
        };
        match compute_quote(&parcel, &card()) {
            Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "orbital"),
            other => panic!("expected UnknownZone, got {other:?}"),
        }
    }

    #[test]
    fn overweight_reports_largest_band_as_limit() {
        let parcel = Parcel {
            weight_grams: 20_001,
            zone: "domestic".into(),
        };
        match compute_quote(&parcel, &card()) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 20_001);
                assert_eq!(limit, 20_000);
            }
            other => panic!("expected Overweight, got {other:?}"),
        }
    }

    #[test]
    fn out_of_order_bands_are_sorted() {
        let text = "\
domestic\t20000\t1799
domestic\t500\t599
domestic\t2000\t899
";
        let parsed = parse_rate_card(text).expect("parses");
        let parcel = Parcel {
            weight_grams: 501,
            zone: "domestic".into(),
        };
        let q = compute_quote(&parcel, &parsed).expect("quotes");
        assert_eq!(q.band_max_grams, 2000);
        assert_eq!(q.base_cents, 899);
    }

    #[test]
    fn international_rounding_when_exact() {
        // 20% of 100 = 20 exact.
        assert_eq!(international_surcharge(100), 20);
        // 20% of 599 = 119.8 → 120.
        assert_eq!(international_surcharge(599), 120);
        // 20% of 1 = 0.2 → 0.
        assert_eq!(international_surcharge(1), 0);
        // 20% of 3 = 0.6 → 1.
        assert_eq!(international_surcharge(3), 1);
    }
}
