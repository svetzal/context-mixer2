//! Boundary between quoting logic and the outside world.
//!
//! Reading the `RATECARD_PATH` file is the only side-effect the crate has;
//! wrapping it in a trait keeps the core logic in [`crate::core`] pure and
//! substitutable in tests.

use std::fs;

use crate::QuoteError;

/// Loads the raw text of the rate card. Any failure to obtain it is reported
/// as [`QuoteError::RateCardUnavailable`], per the task contract.
pub trait RateCardSource {
    fn load(&self) -> Result<String, QuoteError>;
}

/// Reads the rate card from the filesystem path in `RATECARD_PATH`.
#[derive(Debug, Default, Clone, Copy)]
pub struct EnvFileRateCardSource;

impl RateCardSource for EnvFileRateCardSource {
    fn load(&self) -> Result<String, QuoteError> {
        let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
        if path.is_empty() {
            return Err(QuoteError::RateCardUnavailable);
        }
        fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}
