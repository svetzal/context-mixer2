//! Integration test that exercises the real filesystem/env shell of `quote`.
//!
//! `RATECARD_PATH` is process-wide state, so this test runs single-threaded
//! against a serialising mutex to avoid racing with itself when cargo runs
//! multiple integration binaries in parallel.

#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]

use std::io::Write;
use std::sync::Mutex;

use ratecard::{quote, Parcel, QuoteError};

static ENV_LOCK: Mutex<()> = Mutex::new(());

const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn with_ratecard<T>(contents: &str, body: impl FnOnce() -> T) -> T {
    let guard = ENV_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    let mut file = tempfile::NamedTempFile::new().expect("tempfile");
    file.write_all(contents.as_bytes()).expect("write tempfile");
    std::env::set_var("RATECARD_PATH", file.path());
    let result = body();
    std::env::remove_var("RATECARD_PATH");
    drop(guard);
    result
}

fn without_ratecard<T>(body: impl FnOnce() -> T) -> T {
    let guard = ENV_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    std::env::remove_var("RATECARD_PATH");
    let result = body();
    drop(guard);
    result
}

#[test]
fn quotes_a_domestic_parcel_from_file() {
    with_ratecard(CARD, || {
        let parcel = Parcel {
            weight_grams: 400,
            zone: "domestic".into(),
        };
        let q = quote(&parcel).expect("quotes");
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    });
}

#[test]
fn missing_env_var_is_rate_card_unavailable() {
    without_ratecard(|| {
        let parcel = Parcel {
            weight_grams: 400,
            zone: "domestic".into(),
        };
        assert_eq!(quote(&parcel), Err(QuoteError::RateCardUnavailable));
    });
}

#[test]
fn unreadable_path_is_rate_card_unavailable() {
    let guard = ENV_LOCK.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    std::env::set_var("RATECARD_PATH", "/definitely/not/a/real/path/ratecard.tsv");
    let parcel = Parcel {
        weight_grams: 400,
        zone: "domestic".into(),
    };
    let result = quote(&parcel);
    std::env::remove_var("RATECARD_PATH");
    drop(guard);
    assert_eq!(result, Err(QuoteError::RateCardUnavailable));
}

#[test]
fn malformed_card_reports_line_number() {
    let bad = "\n# comment\n\ngarbage line here\n";
    with_ratecard(bad, || {
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        assert_eq!(
            quote(&parcel),
            Err(QuoteError::MalformedRateCard { line: 4 })
        );
    });
}

#[test]
fn overweight_reports_zone_limit() {
    with_ratecard(CARD, || {
        let parcel = Parcel {
            weight_grams: 25_000,
            zone: "domestic".into(),
        };
        assert_eq!(
            quote(&parcel),
            Err(QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000
            })
        );
    });
}

#[test]
fn unknown_zone_carries_requested_zone() {
    with_ratecard(CARD, || {
        let parcel = Parcel {
            weight_grams: 400,
            zone: "orbital".into(),
        };
        match quote(&parcel) {
            Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "orbital"),
            other => panic!("expected UnknownZone, got {other:?}"),
        }
    });
}
