//! Shipping quote calculation from a tab-separated rate card.
//!
//! The public entry point is [`quote`], which reads the rate card path from
//! the `RATECARD_PATH` environment variable and prices a [`Parcel`] against it.
//!
//! Business logic (parsing, band selection, surcharges) is pure; the thin
//! I/O shell reads the file. Each successful call emits a `tracing` event
//! carrying the zone, weight, and total so operators can correlate quotes
//! with downstream work.

pub mod zones;

mod core;
mod gateway;

use std::error::Error;
use std::fmt;

pub use crate::core::{Parcel, Quote};

use crate::gateway::{EnvFileRateCardSource, RateCardSource};

/// The ways a quote can fail: infrastructure, data, or the parcel itself.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` was unset, empty, or referred to a file we could not read.
    RateCardUnavailable,
    /// A rate card line was not three tab-separated numeric fields.
    MalformedRateCard { line: usize },
    /// The parcel's zone is not present in the rate card.
    UnknownZone(String),
    /// The parcel exceeds the largest band configured for its zone.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => write!(f, "rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone `{zone}`"),
            Self::Overweight { grams, limit } => write!(
                f,
                "parcel weight {grams} g exceeds zone limit of {limit} g"
            ),
        }
    }
}

impl Error for QuoteError {}

/// Price a parcel against the rate card at `RATECARD_PATH`.
///
/// Emits a `tracing` event carrying the zone, weight, and total cents on
/// success so quoting can be observed and correlated in operation.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_with_source(parcel, &EnvFileRateCardSource)
}

/// The pipeline the public `quote` wraps: load, parse, compute, observe.
///
/// Kept `pub(crate)` so integration tests can drive it with an in-memory
/// source instead of racing on the process-wide `RATECARD_PATH` env var.
pub(crate) fn quote_with_source<S: RateCardSource>(
    parcel: &Parcel,
    source: &S,
) -> Result<Quote, QuoteError> {
    let text = source.load()?;
    let card = crate::core::parse_rate_card(&text)?;
    let quote = crate::core::compute_quote(parcel, &card)?;
    tracing::info!(
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = quote.total_cents,
        "ratecard.quote"
    );
    Ok(quote)
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]
mod tests {
    use super::*;

    struct StaticSource(&'static str);

    impl RateCardSource for StaticSource {
        fn load(&self) -> Result<String, QuoteError> {
            Ok(self.0.to_owned())
        }
    }

    struct FailingSource;

    impl RateCardSource for FailingSource {
        fn load(&self) -> Result<String, QuoteError> {
            Err(QuoteError::RateCardUnavailable)
        }
    }

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn end_to_end_domestic() {
        let source = StaticSource(CARD);
        let parcel = Parcel {
            weight_grams: 400,
            zone: "domestic".into(),
        };
        let quote = quote_with_source(&parcel, &source).expect("quotes");
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
        assert_eq!(quote.band_max_grams, 500);
    }

    #[test]
    fn end_to_end_international_heavy() {
        let source = StaticSource(CARD);
        let parcel = Parcel {
            weight_grams: 15_000,
            zone: "international".into(),
        };
        let quote = quote_with_source(&parcel, &source).expect("quotes");
        assert_eq!(quote.base_cents, 4999);
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
        assert_eq!(quote.band_max_grams, 20_000);
    }

    #[test]
    fn propagates_source_failure() {
        let parcel = Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        };
        assert_eq!(
            quote_with_source(&parcel, &FailingSource),
            Err(QuoteError::RateCardUnavailable)
        );
    }

    #[test]
    fn display_and_error_trait() {
        fn assert_error<E: Error>(_: &E) {}
        let err = QuoteError::UnknownZone("orbital".into());
        assert_error(&err);
        assert!(format!("{err}").contains("orbital"));

        let err = QuoteError::Overweight {
            grams: 30_000,
            limit: 20_000,
        };
        let msg = format!("{err}");
        assert!(msg.contains("30000"));
        assert!(msg.contains("20000"));

        assert_eq!(
            format!("{}", QuoteError::MalformedRateCard { line: 7 }),
            "malformed rate card at line 7"
        );
        assert_eq!(
            format!("{}", QuoteError::RateCardUnavailable),
            "rate card is unavailable"
        );
    }
}
