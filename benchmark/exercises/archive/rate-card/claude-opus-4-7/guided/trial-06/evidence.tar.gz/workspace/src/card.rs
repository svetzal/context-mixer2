use crate::QuoteError;

/// One row of the rate card: a per-zone weight ceiling and its price.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct Band {
    pub zone: String,
    pub band_max_grams: u32,
    pub cents: u64,
}

/// Parsed rate card, held as an ordered collection of bands.
#[derive(Debug, Default, Clone)]
pub(crate) struct RateCard {
    pub bands: Vec<Band>,
}

impl RateCard {
    /// Parse rate-card text. Empty lines and lines beginning with `#` are
    /// skipped; every other line must be exactly three tab-separated fields.
    pub fn parse(content: &str) -> Result<Self, QuoteError> {
        let mut bands = Vec::new();
        for (idx, raw) in content.lines().enumerate() {
            let line_no = idx + 1;
            if raw.is_empty() || raw.starts_with('#') {
                continue;
            }
            let parts: Vec<&str> = raw.split('\t').collect();
            if parts.len() != 3 {
                return Err(QuoteError::MalformedRateCard { line: line_no });
            }
            let zone = parts[0].to_owned();
            if zone.is_empty() {
                return Err(QuoteError::MalformedRateCard { line: line_no });
            }
            let Ok(band_max_grams) = parts[1].parse::<u32>() else {
                return Err(QuoteError::MalformedRateCard { line: line_no });
            };
            let Ok(cents) = parts[2].parse::<u64>() else {
                return Err(QuoteError::MalformedRateCard { line: line_no });
            };
            bands.push(Band {
                zone,
                band_max_grams,
                cents,
            });
        }
        Ok(Self { bands })
    }

    /// Look up the applicable band for a zone and weight.
    ///
    /// Returns `(base_cents, band_max_grams)` on a match.
    pub fn lookup(&self, zone: &str, weight_grams: u32) -> Result<(u64, u32), QuoteError> {
        let mut zone_bands: Vec<&Band> = self.bands.iter().filter(|b| b.zone == zone).collect();
        if zone_bands.is_empty() {
            return Err(QuoteError::UnknownZone(zone.to_owned()));
        }
        zone_bands.sort_by_key(|b| b.band_max_grams);
        for band in &zone_bands {
            if band.band_max_grams >= weight_grams {
                return Ok((band.cents, band.band_max_grams));
            }
        }
        let limit = zone_bands
            .last()
            .map(|b| b.band_max_grams)
            .unwrap_or_default();
        Err(QuoteError::Overweight {
            grams: weight_grams,
            limit,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::RateCard;
    use crate::QuoteError;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn parse_skips_comments_and_blanks() {
        let card = RateCard::parse(SAMPLE).expect("parse");
        assert_eq!(card.bands.len(), 5);
        assert_eq!(card.bands[0].zone, "domestic");
        assert_eq!(card.bands[0].band_max_grams, 500);
        assert_eq!(card.bands[0].cents, 599);
    }

    #[test]
    fn blank_lines_are_ignored_and_do_not_shift_line_numbers() {
        let card = "\
domestic\t500\t599

domestic\tbogus\t899
";
        match RateCard::parse(card) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
            other => panic!("expected malformed line 3, got {other:?}"),
        }
    }

    #[test]
    fn wrong_field_count_is_malformed() {
        let card = "\
# header
domestic\t500
";
        match RateCard::parse(card) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 2),
            other => panic!("expected malformed line 2, got {other:?}"),
        }
    }

    #[test]
    fn non_numeric_grams_is_malformed() {
        let card = "domestic\tsmall\t599\n";
        match RateCard::parse(card) {
            Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
            other => panic!("expected malformed line 1, got {other:?}"),
        }
    }

    #[test]
    fn empty_zone_is_malformed() {
        let card = "\t500\t599\n";
        assert!(matches!(
            RateCard::parse(card),
            Err(QuoteError::MalformedRateCard { line: 1 })
        ));
    }

    #[test]
    fn lookup_returns_first_matching_band() {
        let card = RateCard::parse(SAMPLE).expect("parse");
        assert_eq!(card.lookup("domestic", 1).expect("lookup"), (599, 500));
        assert_eq!(card.lookup("domestic", 500).expect("lookup"), (599, 500));
        assert_eq!(card.lookup("domestic", 501).expect("lookup"), (899, 2000));
        assert_eq!(
            card.lookup("international", 500).expect("lookup"),
            (1499, 500)
        );
    }

    #[test]
    fn lookup_sorts_bands_before_matching() {
        let unsorted = "\
domestic\t20000\t1799
domestic\t500\t599
domestic\t2000\t899
";
        let card = RateCard::parse(unsorted).expect("parse");
        assert_eq!(card.lookup("domestic", 100).expect("lookup"), (599, 500));
        assert_eq!(card.lookup("domestic", 1500).expect("lookup"), (899, 2000));
    }

    #[test]
    fn unknown_zone_is_reported() {
        let card = RateCard::parse(SAMPLE).expect("parse");
        match card.lookup("moon", 100) {
            Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "moon"),
            other => panic!("expected unknown zone, got {other:?}"),
        }
    }

    #[test]
    fn overweight_reports_largest_band() {
        let card = RateCard::parse(SAMPLE).expect("parse");
        match card.lookup("domestic", 25_000) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 25_000);
                assert_eq!(limit, 20_000);
            }
            other => panic!("expected overweight, got {other:?}"),
        }
    }
}
