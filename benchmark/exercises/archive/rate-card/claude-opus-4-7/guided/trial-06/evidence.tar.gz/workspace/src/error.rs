use std::fmt;

/// Reasons a shipping quote may not be produced.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// The rate card could not be located or read from disk.
    RateCardUnavailable,
    /// A rate-card line did not match the expected `zone\tband_max_grams\tcents`.
    MalformedRateCard { line: usize },
    /// The requested zone did not appear in the rate card.
    UnknownZone(String),
    /// The parcel weight exceeded the zone's largest band.
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => f.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams}g exceeds limit {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[cfg(test)]
mod tests {
    use super::QuoteError;

    #[test]
    fn display_covers_every_variant() {
        assert_eq!(
            QuoteError::RateCardUnavailable.to_string(),
            "rate card is unavailable"
        );
        assert_eq!(
            QuoteError::MalformedRateCard { line: 7 }.to_string(),
            "malformed rate card at line 7"
        );
        assert_eq!(
            QuoteError::UnknownZone("moon".into()).to_string(),
            "unknown zone: moon"
        );
        assert_eq!(
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000
            }
            .to_string(),
            "parcel weight 25000g exceeds limit 20000g"
        );
    }

    #[test]
    fn error_trait_is_implemented() {
        fn assert_error<E: std::error::Error>(_e: &E) {}
        assert_error(&QuoteError::RateCardUnavailable);
    }
}
