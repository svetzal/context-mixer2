const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";

/// Sum the surcharges that apply to a quote.
///
/// * Weight strictly above 10 kg adds 500 cents.
/// * International parcels add 20% of `base_cents`, rounded half-up.
pub(crate) fn compute_surcharge(base_cents: u64, weight_grams: u32, zone: &str) -> u64 {
    let mut surcharge = 0_u64;
    if weight_grams > HEAVY_THRESHOLD_GRAMS {
        surcharge = surcharge.saturating_add(HEAVY_SURCHARGE_CENTS);
    }
    if zone == INTERNATIONAL_ZONE {
        surcharge = surcharge.saturating_add(international_surcharge(base_cents));
    }
    surcharge
}

fn international_surcharge(base_cents: u64) -> u64 {
    // Half-up rounding of base_cents * 0.20: (base * 20 + 50) / 100.
    // For non-negative integers, `base * 20 mod 100` is always in {0,20,40,60,80},
    // so ties never occur and this formula matches half-up exactly.
    (base_cents.saturating_mul(20).saturating_add(50)) / 100
}

#[cfg(test)]
mod tests {
    use super::compute_surcharge;

    #[test]
    fn no_surcharge_for_light_domestic() {
        assert_eq!(compute_surcharge(599, 500, "domestic"), 0);
    }

    #[test]
    fn heavy_surcharge_applies_strictly_above_threshold() {
        assert_eq!(compute_surcharge(1799, 10_000, "domestic"), 0);
        assert_eq!(compute_surcharge(1799, 10_001, "domestic"), 500);
    }

    #[test]
    fn international_adds_twenty_percent_half_up() {
        // 20% of 1499 = 299.8 -> half-up -> 300
        assert_eq!(compute_surcharge(1499, 500, "international"), 300);
        // 20% of 4999 = 999.8 -> half-up -> 1000 (weight kept light to isolate the percentage)
        assert_eq!(compute_surcharge(4999, 500, "international"), 1000);
        // Exact: 20% of 500 = 100
        assert_eq!(compute_surcharge(500, 500, "international"), 100);
    }

    #[test]
    fn international_and_heavy_stack() {
        // 20% of 4999 = 1000 (rounded), plus 500 for weight > 10kg.
        assert_eq!(compute_surcharge(4999, 15_000, "international"), 1500);
    }
}
