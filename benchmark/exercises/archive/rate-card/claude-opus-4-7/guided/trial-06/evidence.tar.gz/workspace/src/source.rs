use crate::QuoteError;

/// Boundary trait: hand the pure quote code the raw rate-card text without
/// coupling it to the filesystem or environment.
pub(crate) trait RateCardSource {
    fn read(&self) -> Result<String, QuoteError>;
}

/// Production source: read the rate card from the path in `RATECARD_PATH`.
#[derive(Debug, Default)]
pub(crate) struct EnvFileSource;

impl RateCardSource for EnvFileSource {
    fn read(&self) -> Result<String, QuoteError> {
        let Ok(path) = std::env::var("RATECARD_PATH") else {
            return Err(QuoteError::RateCardUnavailable);
        };
        if path.is_empty() {
            return Err(QuoteError::RateCardUnavailable);
        }
        std::fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}

#[cfg(test)]
pub(crate) struct InMemorySource {
    pub content: Result<String, QuoteError>,
}

#[cfg(test)]
impl InMemorySource {
    pub fn ok(text: impl Into<String>) -> Self {
        Self {
            content: Ok(text.into()),
        }
    }

    pub fn unavailable() -> Self {
        Self {
            content: Err(QuoteError::RateCardUnavailable),
        }
    }
}

#[cfg(test)]
impl RateCardSource for InMemorySource {
    fn read(&self) -> Result<String, QuoteError> {
        self.content.clone()
    }
}
