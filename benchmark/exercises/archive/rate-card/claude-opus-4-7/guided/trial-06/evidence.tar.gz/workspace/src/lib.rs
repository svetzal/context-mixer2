//! Shipping rate quotes from a zone rate card.
//!
//! The public entry point is [`quote`]. It reads a tab-separated rate card from
//! the path in the `RATECARD_PATH` environment variable and returns a
//! structured [`Quote`] for a given [`Parcel`].

mod card;
mod error;
mod pricing;
mod source;
pub mod zones;

pub use error::QuoteError;

use source::RateCardSource;

/// A parcel awaiting a shipping quote.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A priced quote for a parcel.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Quote a parcel against the rate card at `RATECARD_PATH`.
///
/// # Errors
///
/// - [`QuoteError::RateCardUnavailable`] when `RATECARD_PATH` is unset, empty,
///   or points at an unreadable file.
/// - [`QuoteError::MalformedRateCard`] when a rate-card line is not three
///   tab-separated fields or its numbers do not parse.
/// - [`QuoteError::UnknownZone`] when the parcel's zone is absent from the
///   rate card.
/// - [`QuoteError::Overweight`] when the parcel weight exceeds the largest
///   band for the zone.
///
/// # Examples
///
/// With no rate card configured, the call fails with `RateCardUnavailable`:
///
/// ```
/// use ratecard::{Parcel, QuoteError, quote};
///
/// std::env::remove_var("RATECARD_PATH");
/// let parcel = Parcel { weight_grams: 250, zone: "domestic".into() };
/// assert!(matches!(quote(&parcel), Err(QuoteError::RateCardUnavailable)));
/// ```
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_with(&source::EnvFileSource, parcel)
}

fn quote_with<S: RateCardSource>(src: &S, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let outcome = compute(src, parcel);
    emit_diagnostic(parcel, &outcome);
    outcome
}

fn compute<S: RateCardSource>(src: &S, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let content = src.read()?;
    let card = card::RateCard::parse(&content)?;
    let (base_cents, band_max_grams) = card.lookup(&parcel.zone, parcel.weight_grams)?;
    let surcharge_cents = pricing::compute_surcharge(base_cents, parcel.weight_grams, &parcel.zone);
    let total_cents = base_cents.saturating_add(surcharge_cents);
    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

fn emit_diagnostic(parcel: &Parcel, outcome: &Result<Quote, QuoteError>) {
    match outcome {
        Ok(q) => tracing::info!(
            target: "ratecard.quote",
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            total_cents = q.total_cents,
            "quote priced"
        ),
        Err(e) => tracing::warn!(
            target: "ratecard.quote",
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            error = %e,
            "quote rejected"
        ),
    }
}

#[cfg(test)]
mod tests {
    use super::{quote_with, Parcel, QuoteError};
    use crate::source::InMemorySource;

    const CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn domestic_light_parcel_has_no_surcharge() {
        let src = InMemorySource::ok(CARD);
        let q = quote_with(
            &src,
            &Parcel {
                weight_grams: 250,
                zone: "domestic".into(),
            },
        )
        .expect("quote");
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn heavy_domestic_parcel_adds_flat_surcharge() {
        let src = InMemorySource::ok(CARD);
        let q = quote_with(
            &src,
            &Parcel {
                weight_grams: 15_000,
                zone: "domestic".into(),
            },
        )
        .expect("quote");
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20_000);
    }

    #[test]
    fn international_light_parcel_adds_percentage_surcharge() {
        let src = InMemorySource::ok(CARD);
        let q = quote_with(
            &src,
            &Parcel {
                weight_grams: 250,
                zone: "international".into(),
            },
        )
        .expect("quote");
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn heavy_international_stacks_surcharges() {
        let src = InMemorySource::ok(CARD);
        let q = quote_with(
            &src,
            &Parcel {
                weight_grams: 15_000,
                zone: "international".into(),
            },
        )
        .expect("quote");
        assert_eq!(q.base_cents, 4999);
        // 20% of 4999 = 999.8 -> 1000; plus 500 heavy = 1500.
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
        assert_eq!(q.band_max_grams, 20_000);
    }

    #[test]
    fn unavailable_card_propagates() {
        let src = InMemorySource::unavailable();
        let err = quote_with(
            &src,
            &Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            },
        )
        .expect_err("should fail");
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn unknown_zone_carries_requested_zone() {
        let src = InMemorySource::ok(CARD);
        let err = quote_with(
            &src,
            &Parcel {
                weight_grams: 100,
                zone: "orbital".into(),
            },
        )
        .expect_err("should fail");
        assert_eq!(err, QuoteError::UnknownZone("orbital".into()));
    }

    #[test]
    fn overweight_reports_zone_ceiling() {
        let src = InMemorySource::ok(CARD);
        let err = quote_with(
            &src,
            &Parcel {
                weight_grams: 25_000,
                zone: "domestic".into(),
            },
        )
        .expect_err("should fail");
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000
            }
        );
    }

    #[test]
    fn malformed_card_bubbles_line_number() {
        let broken = "\
# header
domestic\t500\t599
domestic\ttwothousand\t899
";
        let src = InMemorySource::ok(broken);
        let err = quote_with(
            &src,
            &Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            },
        )
        .expect_err("should fail");
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }
}
