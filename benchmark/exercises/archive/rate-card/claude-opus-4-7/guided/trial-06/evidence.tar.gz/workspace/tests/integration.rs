use std::io::Write;
use std::sync::Mutex;

use ratecard::{quote, Parcel, QuoteError};
use tempfile::NamedTempFile;

/// The `RATECARD_PATH` env variable is process-global; serialize any test that
/// touches it so parallel test threads do not clobber each other.
static ENV_LOCK: Mutex<()> = Mutex::new(());

const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn with_ratecard<F: FnOnce()>(content: &str, f: F) {
    let guard = ENV_LOCK.lock().unwrap_or_else(|poison| poison.into_inner());
    let mut file = NamedTempFile::new().expect("tempfile");
    file.write_all(content.as_bytes()).expect("write card");
    let previous = std::env::var("RATECARD_PATH").ok();
    std::env::set_var("RATECARD_PATH", file.path());
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(f));
    match previous {
        Some(v) => std::env::set_var("RATECARD_PATH", v),
        None => std::env::remove_var("RATECARD_PATH"),
    }
    drop(guard);
    if let Err(payload) = result {
        std::panic::resume_unwind(payload);
    }
}

fn without_ratecard<F: FnOnce()>(f: F) {
    let guard = ENV_LOCK.lock().unwrap_or_else(|poison| poison.into_inner());
    let previous = std::env::var("RATECARD_PATH").ok();
    std::env::remove_var("RATECARD_PATH");
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(f));
    if let Some(v) = previous {
        std::env::set_var("RATECARD_PATH", v);
    }
    drop(guard);
    if let Err(payload) = result {
        std::panic::resume_unwind(payload);
    }
}

#[test]
fn quote_reads_rate_card_from_disk() {
    with_ratecard(SAMPLE_CARD, || {
        let q = quote(&Parcel {
            weight_grams: 1_500,
            zone: "domestic".into(),
        })
        .expect("quote");
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 899);
        assert_eq!(q.band_max_grams, 2_000);
    });
}

#[test]
fn quote_stacks_international_and_heavy_surcharges() {
    with_ratecard(SAMPLE_CARD, || {
        let q = quote(&Parcel {
            weight_grams: 15_000,
            zone: "international".into(),
        })
        .expect("quote");
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
        assert_eq!(q.band_max_grams, 20_000);
    });
}

#[test]
fn quote_reports_unknown_zone() {
    with_ratecard(SAMPLE_CARD, || {
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "lunar".into(),
        })
        .expect_err("should fail");
        assert_eq!(err, QuoteError::UnknownZone("lunar".into()));
    });
}

#[test]
fn quote_reports_overweight() {
    with_ratecard(SAMPLE_CARD, || {
        let err = quote(&Parcel {
            weight_grams: 25_000,
            zone: "international".into(),
        })
        .expect_err("should fail");
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000
            }
        );
    });
}

#[test]
fn quote_reports_malformed_line_including_comments_and_blanks() {
    let card = "\
# header comment
\ndomestic\t500\t599
domestic\tbogus\t899
";
    with_ratecard(card, || {
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .expect_err("should fail");
        // Lines: 1=comment, 2=blank, 3=domestic\t500\t599, 4=malformed.
        assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
    });
}

#[test]
fn missing_env_var_is_unavailable() {
    without_ratecard(|| {
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .expect_err("should fail");
        assert_eq!(err, QuoteError::RateCardUnavailable);
    });
}

#[test]
fn missing_file_is_unavailable() {
    let guard = ENV_LOCK.lock().unwrap_or_else(|poison| poison.into_inner());
    let previous = std::env::var("RATECARD_PATH").ok();
    std::env::set_var(
        "RATECARD_PATH",
        "/nonexistent/path/that/should/not/exist/ratecard.tsv",
    );
    let err = quote(&Parcel {
        weight_grams: 100,
        zone: "domestic".into(),
    })
    .expect_err("should fail");
    match previous {
        Some(v) => std::env::set_var("RATECARD_PATH", v),
        None => std::env::remove_var("RATECARD_PATH"),
    }
    drop(guard);
    assert_eq!(err, QuoteError::RateCardUnavailable);
}
