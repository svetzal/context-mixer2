//! `ratecard`: turn a parcel and a redeployable rate card into a shipping quote.
//!
//! The public contract is [`Parcel`], [`Quote`], [`QuoteError`], and [`quote`].
//! Rate-card I/O and pricing logic are kept apart so pricing can be tested
//! without touching the filesystem.

mod model;
mod parse;
mod pricing;
mod source;
pub mod zones;

pub use model::{Parcel, Quote, QuoteError};

use source::{EnvFileSource, RateCardSource};

/// Price a parcel against the rate card at `RATECARD_PATH`.
///
/// Emits a `tracing` info-level event carrying the zone, weight in grams, and
/// resulting total in cents for every successful call, and a warn-level event
/// carrying the zone, weight, and error kind for every failure.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_with(parcel, &EnvFileSource)
}

fn quote_with<S: RateCardSource>(parcel: &Parcel, source: &S) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "ratecard.quote",
        zone = parcel.zone.as_str(),
        weight_grams = parcel.weight_grams,
    );
    let _enter = span.enter();

    let result = source.read().and_then(|text| {
        let card = parse::parse(&text)?;
        pricing::compute(parcel, &card)
    });

    match &result {
        Ok(q) => tracing::info!(total_cents = q.total_cents, "quoted"),
        Err(err) => tracing::warn!(error = %err, "quote_failed"),
    }

    result
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::QuoteError;
    use crate::source::RateCardSource;

    struct StaticSource(Result<String, QuoteError>);

    impl RateCardSource for StaticSource {
        fn read(&self) -> Result<String, QuoteError> {
            self.0.clone()
        }
    }

    fn card_text() -> String {
        [
            "# zone\tband_max_grams\tcents",
            "domestic\t500\t599",
            "domestic\t2000\t899",
            "domestic\t20000\t1799",
            "international\t500\t1499",
            "international\t20000\t4999",
            "",
        ]
        .join("\n")
    }

    #[test]
    fn quote_with_source_prices_domestic_middle_band() {
        let source = StaticSource(Ok(card_text()));
        let parcel = Parcel { weight_grams: 1500, zone: "domestic".into() };
        let quote = quote_with(&parcel, &source).expect("quote");
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
    }

    #[test]
    fn quote_with_source_reports_unknown_zone() {
        let source = StaticSource(Ok(card_text()));
        let parcel = Parcel { weight_grams: 100, zone: "lunar".into() };
        assert_eq!(
            quote_with(&parcel, &source).unwrap_err(),
            QuoteError::UnknownZone("lunar".into()),
        );
    }

    #[test]
    fn quote_with_source_reports_overweight() {
        let source = StaticSource(Ok(card_text()));
        let parcel = Parcel { weight_grams: 25_000, zone: "international".into() };
        assert_eq!(
            quote_with(&parcel, &source).unwrap_err(),
            QuoteError::Overweight { grams: 25_000, limit: 20_000 },
        );
    }

    #[test]
    fn quote_with_source_bubbles_unavailable() {
        let source = StaticSource(Err(QuoteError::RateCardUnavailable));
        let parcel = Parcel { weight_grams: 100, zone: "domestic".into() };
        assert_eq!(
            quote_with(&parcel, &source).unwrap_err(),
            QuoteError::RateCardUnavailable,
        );
    }

    #[test]
    fn quote_error_displays_line_number() {
        let err = QuoteError::MalformedRateCard { line: 4 };
        assert_eq!(err.to_string(), "malformed rate card at line 4");
    }

    #[test]
    fn quote_error_is_std_error() {
        fn assert_error<E: std::error::Error>(_: &E) {}
        let err = QuoteError::RateCardUnavailable;
        assert_error(&err);
    }
}
