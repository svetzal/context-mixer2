//! End-to-end tests that drive the public `quote()` function against a real
//! rate card on disk. Because `RATECARD_PATH` is process-global, every test
//! that touches it must hold the same mutex; otherwise parallel tests would
//! trample each other's env state.

use std::io::Write;
use std::sync::Mutex;

use ratecard::{quote, Parcel, QuoteError};
use tempfile::NamedTempFile;

static ENV_LOCK: Mutex<()> = Mutex::new(());

const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn write_card(text: &str) -> NamedTempFile {
    let mut file = NamedTempFile::new().expect("tempfile");
    file.write_all(text.as_bytes()).expect("write card");
    file.flush().expect("flush");
    file
}

fn with_ratecard<F, R>(text: &str, f: F) -> R
where
    F: FnOnce() -> R,
{
    let guard = ENV_LOCK.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
    let file = write_card(text);
    let prior = std::env::var("RATECARD_PATH").ok();
    std::env::set_var("RATECARD_PATH", file.path());
    let outcome = f();
    match prior {
        Some(v) => std::env::set_var("RATECARD_PATH", v),
        None => std::env::remove_var("RATECARD_PATH"),
    }
    drop(guard);
    outcome
}

#[test]
fn domestic_light_parcel_returns_first_band() {
    let quote = with_ratecard(SAMPLE_CARD, || {
        quote(&Parcel { weight_grams: 250, zone: "domestic".into() }).expect("quote")
    });
    assert_eq!(quote.base_cents, 599);
    assert_eq!(quote.surcharge_cents, 0);
    assert_eq!(quote.total_cents, 599);
    assert_eq!(quote.band_max_grams, 500);
}

#[test]
fn international_heavy_parcel_stacks_surcharges() {
    let quote = with_ratecard(SAMPLE_CARD, || {
        quote(&Parcel { weight_grams: 15_000, zone: "international".into() }).expect("quote")
    });
    assert_eq!(quote.base_cents, 4999);
    // 20% of 4999 = 999.8 → 1000, plus 500 heavy surcharge
    assert_eq!(quote.surcharge_cents, 1500);
    assert_eq!(quote.total_cents, 6499);
    assert_eq!(quote.band_max_grams, 20_000);
}

#[test]
fn unknown_zone_reports_the_requested_zone() {
    let err = with_ratecard(SAMPLE_CARD, || {
        quote(&Parcel { weight_grams: 100, zone: "lunar".into() }).unwrap_err()
    });
    assert_eq!(err, QuoteError::UnknownZone("lunar".into()));
}

#[test]
fn weight_past_largest_band_is_overweight() {
    let err = with_ratecard(SAMPLE_CARD, || {
        quote(&Parcel { weight_grams: 25_000, zone: "domestic".into() }).unwrap_err()
    });
    assert_eq!(err, QuoteError::Overweight { grams: 25_000, limit: 20_000 });
}

#[test]
fn malformed_line_carries_one_based_line_number() {
    let text = "# header\n\ndomestic\t500\t599\nnot-a-valid-line\n";
    let err = with_ratecard(text, || {
        quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err()
    });
    assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
}

#[test]
fn missing_env_var_is_rate_card_unavailable() {
    let guard = ENV_LOCK.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
    let prior = std::env::var("RATECARD_PATH").ok();
    std::env::remove_var("RATECARD_PATH");
    let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);
    if let Some(v) = prior {
        std::env::set_var("RATECARD_PATH", v);
    }
    drop(guard);
}

#[test]
fn path_pointing_at_nothing_is_rate_card_unavailable() {
    let guard = ENV_LOCK.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
    let prior = std::env::var("RATECARD_PATH").ok();
    std::env::set_var(
        "RATECARD_PATH",
        "/definitely/not/a/real/path/for-ratecard-testing.tsv",
    );
    let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);
    match prior {
        Some(v) => std::env::set_var("RATECARD_PATH", v),
        None => std::env::remove_var("RATECARD_PATH"),
    }
    drop(guard);
}
