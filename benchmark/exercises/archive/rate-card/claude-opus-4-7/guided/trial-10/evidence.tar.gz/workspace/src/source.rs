//! Gateway trait for obtaining the rate card text, plus the production adapter
//! that reads it from the path in `RATECARD_PATH`.

use crate::model::QuoteError;

pub(crate) trait RateCardSource {
    fn read(&self) -> Result<String, QuoteError>;
}

pub(crate) struct EnvFileSource;

impl RateCardSource for EnvFileSource {
    fn read(&self) -> Result<String, QuoteError> {
        let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
        if path.is_empty() {
            return Err(QuoteError::RateCardUnavailable);
        }
        std::fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)
    }
}
