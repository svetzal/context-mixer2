//! Pure rate-card parser. No I/O; input is the file's contents.

use crate::model::{Band, QuoteError, RateCard};

pub(crate) fn parse(text: &str) -> Result<RateCard, QuoteError> {
    let mut card = RateCard::default();

    for (idx, raw) in text.lines().enumerate() {
        let line_number = idx + 1;
        if raw.is_empty() || raw.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = raw.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let zone = fields[0];
        if zone.is_empty() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        card.zones
            .entry(zone.to_owned())
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in card.zones.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(card)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ignores_comments_and_blank_lines() {
        let text = "# header\n\ndomestic\t500\t599\n";
        let card = parse(text).expect("parse");
        assert_eq!(card.zones["domestic"], vec![Band { max_grams: 500, cents: 599 }]);
    }

    #[test]
    fn sorts_bands_ascending() {
        let text = "domestic\t2000\t899\ndomestic\t500\t599\n";
        let card = parse(text).expect("parse");
        assert_eq!(
            card.zones["domestic"],
            vec![
                Band { max_grams: 500, cents: 599 },
                Band { max_grams: 2000, cents: 899 },
            ]
        );
    }

    #[test]
    fn wrong_field_count_is_malformed_with_line_number() {
        // header + blank + bad = line 3
        let text = "# header\n\ndomestic,500,599\n";
        assert_eq!(
            parse(text).unwrap_err(),
            QuoteError::MalformedRateCard { line: 3 }
        );
    }

    #[test]
    fn extra_trailing_tab_is_malformed() {
        let text = "domestic\t500\t599\t\n";
        assert_eq!(
            parse(text).unwrap_err(),
            QuoteError::MalformedRateCard { line: 1 }
        );
    }

    #[test]
    fn unparseable_weight_is_malformed() {
        let text = "domestic\tnope\t599\n";
        assert_eq!(
            parse(text).unwrap_err(),
            QuoteError::MalformedRateCard { line: 1 }
        );
    }

    #[test]
    fn unparseable_cents_is_malformed() {
        let text = "domestic\t500\t-1\n";
        assert_eq!(
            parse(text).unwrap_err(),
            QuoteError::MalformedRateCard { line: 1 }
        );
    }

    #[test]
    fn empty_zone_is_malformed() {
        let text = "\t500\t599\n";
        assert_eq!(
            parse(text).unwrap_err(),
            QuoteError::MalformedRateCard { line: 1 }
        );
    }

    #[test]
    fn line_numbers_count_every_line() {
        // Lines 1..=4 are legal; line 5 is bad; line number must be 5.
        let text = "# comment\n\ndomestic\t500\t599\ndomestic\t2000\t899\nbad line here\n";
        assert_eq!(
            parse(text).unwrap_err(),
            QuoteError::MalformedRateCard { line: 5 }
        );
    }
}
