//! Pure pricing engine. Given a parsed rate card and a parcel, produce a Quote.

use crate::model::{Parcel, Quote, QuoteError, RateCard};

const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

pub(crate) fn compute(parcel: &Parcel, card: &RateCard) -> Result<Quote, QuoteError> {
    let bands = card
        .zones
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let Some(limit) = bands.last().map(|b| b.max_grams) else {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    };

    let band = bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        })?;

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;

    if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        surcharge_cents += HEAVY_SURCHARGE_CENTS;
    }
    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge_cents += international_uplift(base_cents);
    }

    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

/// 20% of `base_cents`, rounded half-up to the cent.
fn international_uplift(base_cents: u64) -> u64 {
    (base_cents * INTERNATIONAL_SURCHARGE_PERCENT + 50) / 100
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::Band;

    fn sample_card() -> RateCard {
        let mut card = RateCard::default();
        card.zones.insert(
            "domestic".to_owned(),
            vec![
                Band { max_grams: 500, cents: 599 },
                Band { max_grams: 2000, cents: 899 },
                Band { max_grams: 20_000, cents: 1799 },
            ],
        );
        card.zones.insert(
            "international".to_owned(),
            vec![
                Band { max_grams: 500, cents: 1499 },
                Band { max_grams: 20_000, cents: 4999 },
            ],
        );
        card
    }

    #[test]
    fn picks_first_band_that_meets_weight() {
        let card = sample_card();
        let parcel = Parcel { weight_grams: 501, zone: "domestic".into() };
        let quote = compute(&parcel, &card).expect("quote");
        assert_eq!(quote.base_cents, 899);
        assert_eq!(quote.band_max_grams, 2000);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 899);
    }

    #[test]
    fn exact_boundary_weight_matches_that_band() {
        let card = sample_card();
        let parcel = Parcel { weight_grams: 500, zone: "domestic".into() };
        let quote = compute(&parcel, &card).expect("quote");
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.base_cents, 599);
    }

    #[test]
    fn heavy_surcharge_kicks_in_above_ten_kilos() {
        let card = sample_card();
        let parcel = Parcel { weight_grams: 10_001, zone: "domestic".into() };
        let quote = compute(&parcel, &card).expect("quote");
        assert_eq!(quote.base_cents, 1799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2299);
    }

    #[test]
    fn heavy_surcharge_does_not_apply_at_boundary() {
        let card = sample_card();
        let parcel = Parcel { weight_grams: 10_000, zone: "domestic".into() };
        let quote = compute(&parcel, &card).expect("quote");
        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn international_zone_adds_twenty_percent_uplift() {
        let card = sample_card();
        let parcel = Parcel { weight_grams: 300, zone: "international".into() };
        let quote = compute(&parcel, &card).expect("quote");
        assert_eq!(quote.base_cents, 1499);
        // 20% of 1499 = 299.8 → 300 half-up
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1799);
    }

    #[test]
    fn international_and_heavy_stack() {
        let card = sample_card();
        let parcel = Parcel { weight_grams: 15_000, zone: "international".into() };
        let quote = compute(&parcel, &card).expect("quote");
        assert_eq!(quote.base_cents, 4999);
        // 20% of 4999 = 999.8 → 1000 half-up, plus 500 heavy = 1500
        assert_eq!(quote.surcharge_cents, 1500);
        assert_eq!(quote.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_carries_requested_zone() {
        let card = sample_card();
        let parcel = Parcel { weight_grams: 100, zone: "lunar".into() };
        assert_eq!(
            compute(&parcel, &card).unwrap_err(),
            QuoteError::UnknownZone("lunar".into())
        );
    }

    #[test]
    fn overweight_reports_largest_band_as_limit() {
        let card = sample_card();
        let parcel = Parcel { weight_grams: 20_001, zone: "domestic".into() };
        assert_eq!(
            compute(&parcel, &card).unwrap_err(),
            QuoteError::Overweight { grams: 20_001, limit: 20_000 }
        );
    }

    #[test]
    fn uplift_rounds_half_up_to_the_cent() {
        assert_eq!(international_uplift(2), 0);      // 0.4 → 0
        assert_eq!(international_uplift(3), 1);      // 0.6 → 1
        assert_eq!(international_uplift(1499), 300); // 299.8 → 300
        assert_eq!(international_uplift(4999), 1000);// 999.8 → 1000
    }
}
