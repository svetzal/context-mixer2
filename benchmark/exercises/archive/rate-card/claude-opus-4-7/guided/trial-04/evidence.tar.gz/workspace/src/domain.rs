//! Public types for shipping quote calculation.
//!
//! These form the crate's stable contract: parcels come in, quotes go out,
//! and every failure mode is enumerated in [`QuoteError`].

use std::error::Error;
use std::fmt;

/// A parcel to be priced: its billable weight in grams and the destination
/// zone whose rate band it falls into.
#[derive(Debug, Clone)]
pub struct Parcel {
    /// Billable parcel weight in grams.
    pub weight_grams: u32,
    /// Destination zone name; must exist in the rate card.
    pub zone: String,
}

/// The priced outcome of a [`Parcel`] against the rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    /// Band price in cents before surcharges.
    pub base_cents: u64,
    /// Sum of applicable surcharges in cents.
    pub surcharge_cents: u64,
    /// `base_cents + surcharge_cents`.
    pub total_cents: u64,
    /// Upper weight threshold of the matched band, in grams.
    pub band_max_grams: u32,
}

/// Every recoverable failure that [`crate::quote`] can produce.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, missing on disk, or unreadable.
    RateCardUnavailable,
    /// A rate card line was not three tab-separated fields or its numbers
    /// failed to parse. `line` is 1-based and counts every line in the file.
    MalformedRateCard {
        /// 1-based line number of the offending line.
        line: usize,
    },
    /// The requested zone is not present in the rate card.
    UnknownZone(String),
    /// The parcel is heavier than the zone's largest band.
    Overweight {
        /// The parcel's weight in grams.
        grams: u32,
        /// The zone's largest `band_max_grams`.
        limit: u32,
    },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RateCardUnavailable => f.write_str("rate card is unavailable"),
            Self::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => write!(
                f,
                "parcel weight {grams}g exceeds zone limit of {limit}g"
            ),
        }
    }
}

impl Error for QuoteError {}
