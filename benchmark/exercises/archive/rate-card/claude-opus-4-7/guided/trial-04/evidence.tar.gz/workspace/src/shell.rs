//! Imperative shell that composes environment lookup, file I/O, and the pure
//! parser/calculator, and emits a tracing span with structured fields for
//! each call.

use std::env;
use std::fs;

use crate::calc::calculate_quote;
use crate::domain::{Parcel, Quote, QuoteError};
use crate::parser::parse_rate_card;

const RATE_CARD_ENV: &str = "RATECARD_PATH";

/// Price `parcel` using the rate card located at the path in the
/// `RATECARD_PATH` environment variable.
///
/// # Errors
///
/// Returns [`QuoteError::RateCardUnavailable`] when the environment variable
/// is unset or the file cannot be read; [`QuoteError::MalformedRateCard`] for
/// syntactically invalid lines; [`QuoteError::UnknownZone`] if the parcel's
/// zone is absent; [`QuoteError::Overweight`] if the parcel exceeds every
/// band in its zone.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "quote",
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
        total_cents = tracing::field::Empty,
    );
    let _enter = span.enter();

    let path = env::var(RATE_CARD_ENV).map_err(|_| QuoteError::RateCardUnavailable)?;
    let text = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let card = parse_rate_card(&text)?;
    let quoted = calculate_quote(parcel, &card)?;

    span.record("total_cents", quoted.total_cents);
    Ok(quoted)
}
