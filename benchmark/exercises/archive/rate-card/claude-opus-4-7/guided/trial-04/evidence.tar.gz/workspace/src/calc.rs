//! Pure quote calculation over a parsed rate card.
//!
//! Contains no I/O, no environment access, and no logging. The shell layer
//! composes this with the parser.

use crate::domain::{Parcel, Quote, QuoteError};
use crate::parser::RateCard;

const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";
const INTERNATIONAL_SURCHARGE_PERCENT: u64 = 20;

/// Price `parcel` against `card`.
pub(crate) fn calculate_quote(parcel: &Parcel, card: &RateCard) -> Result<Quote, QuoteError> {
    let bands = card
        .zone(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let Some(band) = bands.iter().find(|b| b.max_grams >= parcel.weight_grams) else {
        let limit = bands.last().map_or(0, |b| b.max_grams);
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit,
        });
    };

    let base_cents = band.cents;

    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        surcharge_cents += HEAVY_SURCHARGE_CENTS;
    }
    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge_cents += percent_of_cents_half_up(base_cents, INTERNATIONAL_SURCHARGE_PERCENT);
    }

    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

/// Compute `percent`% of `cents`, rounding half-up to the nearest whole cent.
fn percent_of_cents_half_up(cents: u64, percent: u64) -> u64 {
    (cents * percent + 50) / 100
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::parser::parse_rate_card;

    fn sample_card() -> RateCard {
        let text = "\
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";
        parse_rate_card(text).expect("valid")
    }

    #[test]
    fn matches_the_first_band_whose_ceiling_meets_or_exceeds_the_weight() {
        let card = sample_card();
        let quote = calculate_quote(
            &Parcel {
                weight_grams: 400,
                zone: "domestic".into(),
            },
            &card,
        )
        .expect("priced");
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.base_cents, 599);
        assert_eq!(quote.surcharge_cents, 0);
        assert_eq!(quote.total_cents, 599);
    }

    #[test]
    fn weight_equal_to_band_ceiling_uses_that_band() {
        let card = sample_card();
        let quote = calculate_quote(
            &Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            },
            &card,
        )
        .expect("priced");
        assert_eq!(quote.band_max_grams, 500);
        assert_eq!(quote.base_cents, 599);
    }

    #[test]
    fn weight_above_ten_kilos_adds_the_heavy_surcharge() {
        let card = sample_card();
        let quote = calculate_quote(
            &Parcel {
                weight_grams: 15_000,
                zone: "domestic".into(),
            },
            &card,
        )
        .expect("priced");
        assert_eq!(quote.band_max_grams, 20_000);
        assert_eq!(quote.base_cents, 1_799);
        assert_eq!(quote.surcharge_cents, 500);
        assert_eq!(quote.total_cents, 2_299);
    }

    #[test]
    fn weight_exactly_ten_kilos_does_not_add_the_heavy_surcharge() {
        let card = sample_card();
        let quote = calculate_quote(
            &Parcel {
                weight_grams: 10_000,
                zone: "domestic".into(),
            },
            &card,
        )
        .expect("priced");
        assert_eq!(quote.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_twenty_percent_of_base() {
        let card = sample_card();
        let quote = calculate_quote(
            &Parcel {
                weight_grams: 300,
                zone: "international".into(),
            },
            &card,
        )
        .expect("priced");
        assert_eq!(quote.base_cents, 1_499);
        // 20% of 1499 = 299.8 → 300
        assert_eq!(quote.surcharge_cents, 300);
        assert_eq!(quote.total_cents, 1_799);
    }

    #[test]
    fn heavy_international_stacks_both_surcharges() {
        let card = sample_card();
        let quote = calculate_quote(
            &Parcel {
                weight_grams: 15_000,
                zone: "international".into(),
            },
            &card,
        )
        .expect("priced");
        assert_eq!(quote.base_cents, 4_999);
        // 500 (heavy) + 1000 (20% of 4999 = 999.8 → 1000)
        assert_eq!(quote.surcharge_cents, 1_500);
        assert_eq!(quote.total_cents, 6_499);
    }

    #[test]
    fn unknown_zone_carries_the_requested_name() {
        let card = sample_card();
        let err = calculate_quote(
            &Parcel {
                weight_grams: 100,
                zone: "lunar".into(),
            },
            &card,
        )
        .expect_err("unknown");
        assert_eq!(err, QuoteError::UnknownZone("lunar".into()));
    }

    #[test]
    fn overweight_reports_the_largest_band_in_the_zone() {
        let card = sample_card();
        let err = calculate_quote(
            &Parcel {
                weight_grams: 25_000,
                zone: "domestic".into(),
            },
            &card,
        )
        .expect_err("overweight");
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000,
            }
        );
    }

    #[test]
    fn half_up_rounding_matches_the_specification() {
        assert_eq!(percent_of_cents_half_up(1_499, 20), 300);
        assert_eq!(percent_of_cents_half_up(4_999, 20), 1_000);
        assert_eq!(percent_of_cents_half_up(0, 20), 0);
        assert_eq!(percent_of_cents_half_up(1, 20), 0);
        // 20% of 3 = 0.6 → 1
        assert_eq!(percent_of_cents_half_up(3, 20), 1);
        // exact .5 case: 5% of 10 = 0.5 → 1
        assert_eq!(percent_of_cents_half_up(10, 5), 1);
    }
}
