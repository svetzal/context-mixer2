//! Pure parsing of the tab-separated rate card text into a [`RateCard`].
//!
//! No filesystem or environment access; the caller supplies the raw text.

use std::collections::HashMap;

use crate::domain::QuoteError;

/// A single band within a zone's schedule.
#[derive(Debug)]
pub(crate) struct Band {
    pub(crate) max_grams: u32,
    pub(crate) cents: u64,
}

/// A parsed rate card: zones map to their bands, sorted ascending by
/// `max_grams`.
#[derive(Debug)]
pub(crate) struct RateCard {
    zones: HashMap<String, Vec<Band>>,
}

impl RateCard {
    /// Return this zone's ascending bands, or `None` if absent.
    pub(crate) fn zone(&self, name: &str) -> Option<&[Band]> {
        self.zones.get(name).map(Vec::as_slice)
    }
}

/// Parse the raw rate card text.
///
/// Empty lines and lines beginning with `#` are ignored. Every other line
/// must be exactly three tab-separated fields: `zone`, `band_max_grams`,
/// `cents`. Line numbers in [`QuoteError::MalformedRateCard`] are 1-based
/// and count every line — including comments and blanks.
pub(crate) fn parse_rate_card(text: &str) -> Result<RateCard, QuoteError> {
    let mut zones: HashMap<String, Vec<Band>> = HashMap::new();

    for (idx, raw) in text.lines().enumerate() {
        let line = idx + 1;
        if raw.trim().is_empty() || raw.starts_with('#') {
            continue;
        }

        let parts: Vec<&str> = raw.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line });
        }

        let zone = parts[0].to_string();
        let max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line })?;

        zones.entry(zone).or_default().push(Band { max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(RateCard { zones })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_a_valid_card() {
        let text = "\
# comment
domestic\t500\t599
domestic\t2000\t899
international\t500\t1499
";
        let card = parse_rate_card(text).expect("valid");
        let domestic = card.zone("domestic").expect("domestic present");
        assert_eq!(domestic.len(), 2);
        assert_eq!(domestic[0].max_grams, 500);
        assert_eq!(domestic[0].cents, 599);
        assert_eq!(domestic[1].max_grams, 2000);
        assert_eq!(card.zone("international").expect("intl present").len(), 1);
        assert!(card.zone("unknown").is_none());
    }

    #[test]
    fn ignores_blank_and_comment_lines() {
        let text = "\
# header

domestic\t500\t599

# another
";
        let card = parse_rate_card(text).expect("valid");
        assert_eq!(card.zone("domestic").expect("present").len(), 1);
    }

    #[test]
    fn sorts_bands_ascending_regardless_of_file_order() {
        let text = "\
domestic\t2000\t899
domestic\t500\t599
domestic\t20000\t1799
";
        let card = parse_rate_card(text).expect("valid");
        let bands = card.zone("domestic").expect("present");
        assert_eq!(bands[0].max_grams, 500);
        assert_eq!(bands[1].max_grams, 2000);
        assert_eq!(bands[2].max_grams, 20000);
    }

    #[test]
    fn reports_the_offending_line_when_fields_are_missing() {
        let text = "\
# header
domestic\t500\t599
broken row
";
        let err = parse_rate_card(text).expect_err("malformed");
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn counts_comments_and_blanks_in_line_numbers() {
        let text = "\
# c1

# c3
domestic\tnope\t599
";
        let err = parse_rate_card(text).expect_err("malformed");
        assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn rejects_lines_whose_cents_do_not_parse() {
        let text = "domestic\t500\tabc\n";
        let err = parse_rate_card(text).expect_err("malformed");
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }
}
