//! Cross-module wiring tests for `ratecard::quote`.
//!
//! These exercise the shell layer end to end: environment variable, file
//! read, parser, calculator. Env access is serialized with a mutex because
//! the process-wide `RATECARD_PATH` variable is shared across tests.

use std::io::Write;
use std::sync::{Mutex, OnceLock};

use ratecard::{quote, Parcel, Quote, QuoteError};
use tempfile::NamedTempFile;

const RATE_CARD_ENV: &str = "RATECARD_PATH";

const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn env_lock() -> &'static Mutex<()> {
    static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    LOCK.get_or_init(|| Mutex::new(()))
}

/// Run `body` with `RATECARD_PATH` set to a temp file containing `contents`.
/// The env lock is held for the whole closure, so concurrent tests do not
/// race on the shared variable.
fn with_rate_card<R>(contents: &str, body: impl FnOnce() -> R) -> R {
    let guard = env_lock().lock().unwrap_or_else(std::sync::PoisonError::into_inner);
    let mut file = NamedTempFile::new().expect("tempfile");
    file.write_all(contents.as_bytes()).expect("write");
    let path = file.path().to_owned();
    // SAFETY: env access is serialized by `env_lock`.
    std::env::set_var(RATE_CARD_ENV, &path);
    let result = body();
    std::env::remove_var(RATE_CARD_ENV);
    drop(guard);
    drop(file);
    result
}

fn without_rate_card<R>(body: impl FnOnce() -> R) -> R {
    let guard = env_lock().lock().unwrap_or_else(std::sync::PoisonError::into_inner);
    std::env::remove_var(RATE_CARD_ENV);
    let result = body();
    drop(guard);
    result
}

#[test]
fn prices_a_domestic_parcel_end_to_end() {
    with_rate_card(SAMPLE_CARD, || {
        let quoted = quote(&Parcel {
            weight_grams: 600,
            zone: "domestic".into(),
        })
        .expect("priced");
        assert_eq!(
            quoted,
            Quote {
                base_cents: 899,
                surcharge_cents: 0,
                total_cents: 899,
                band_max_grams: 2_000,
            }
        );
    });
}

#[test]
fn prices_a_heavy_international_parcel_with_both_surcharges() {
    with_rate_card(SAMPLE_CARD, || {
        let quoted = quote(&Parcel {
            weight_grams: 15_000,
            zone: "international".into(),
        })
        .expect("priced");
        assert_eq!(quoted.base_cents, 4_999);
        assert_eq!(quoted.surcharge_cents, 1_500);
        assert_eq!(quoted.total_cents, 6_499);
        assert_eq!(quoted.band_max_grams, 20_000);
    });
}

#[test]
fn missing_env_var_yields_rate_card_unavailable() {
    without_rate_card(|| {
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .expect_err("unavailable");
        assert_eq!(err, QuoteError::RateCardUnavailable);
    });
}

#[test]
fn missing_file_yields_rate_card_unavailable() {
    let guard = env_lock().lock().unwrap_or_else(std::sync::PoisonError::into_inner);
    std::env::set_var(RATE_CARD_ENV, "/nonexistent/definitely/not/here.tsv");
    let err = quote(&Parcel {
        weight_grams: 100,
        zone: "domestic".into(),
    })
    .expect_err("unavailable");
    std::env::remove_var(RATE_CARD_ENV);
    drop(guard);
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn malformed_line_surfaces_the_line_number() {
    let bad = "\
# header
domestic\t500\t599
totally-broken
";
    with_rate_card(bad, || {
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .expect_err("malformed");
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    });
}

#[test]
fn unknown_zone_reports_the_requested_zone() {
    with_rate_card(SAMPLE_CARD, || {
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "lunar".into(),
        })
        .expect_err("unknown");
        assert_eq!(err, QuoteError::UnknownZone("lunar".into()));
    });
}

#[test]
fn overweight_reports_the_zone_limit() {
    with_rate_card(SAMPLE_CARD, || {
        let err = quote(&Parcel {
            weight_grams: 30_000,
            zone: "domestic".into(),
        })
        .expect_err("overweight");
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 30_000,
                limit: 20_000,
            }
        );
    });
}

#[test]
fn quote_error_displays_and_is_a_std_error() {
    fn assert_is_error<E: std::error::Error>(_: &E) {}
    let err = QuoteError::UnknownZone("mars".into());
    assert_is_error(&err);
    assert_eq!(err.to_string(), "unknown zone: mars");
    assert_eq!(
        QuoteError::MalformedRateCard { line: 7 }.to_string(),
        "malformed rate card at line 7"
    );
    assert_eq!(
        QuoteError::Overweight {
            grams: 30_000,
            limit: 20_000,
        }
        .to_string(),
        "parcel weight 30000g exceeds zone limit of 20000g"
    );
    assert_eq!(
        QuoteError::RateCardUnavailable.to_string(),
        "rate card is unavailable"
    );
}
