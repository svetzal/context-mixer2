//! Shipping rate quote calculation from a tab-separated rate card.
//!
//! The crate exposes [`quote`], which reads a rate card from the path in the
//! `RATECARD_PATH` environment variable and prices a [`Parcel`] against it.

mod calc;
mod domain;
mod parser;
mod shell;
pub mod zones;

pub use domain::{Parcel, Quote, QuoteError};
pub use shell::quote;
