//! Pure quote logic: parses a rate card and computes a quote against a parcel.
//!
//! No I/O, no clocks, no globals. The imperative shell in `lib.rs` loads bytes
//! and hands them here.

use std::collections::BTreeMap;

use crate::{Parcel, Quote, QuoteError};

const OVERWEIGHT_THRESHOLD_GRAMS: u32 = 10_000;
const OVERWEIGHT_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct Band {
    pub(crate) band_max_grams: u32,
    pub(crate) cents: u64,
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub(crate) struct RateCard {
    zones: BTreeMap<String, Vec<Band>>,
}

impl RateCard {
    fn bands_for(&self, zone: &str) -> Option<&[Band]> {
        self.zones.get(zone).map(Vec::as_slice)
    }
}

#[derive(Debug, PartialEq, Eq)]
pub(crate) enum ParseError {
    Malformed { line: usize },
}

pub(crate) fn parse_rate_card(contents: &str) -> Result<RateCard, ParseError> {
    let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();
    for (index, raw) in contents.lines().enumerate() {
        let line_no = index + 1;
        let trimmed = raw.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = raw.split('\t').collect();
        if parts.len() != 3 {
            return Err(ParseError::Malformed { line: line_no });
        }
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| ParseError::Malformed { line: line_no })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| ParseError::Malformed { line: line_no })?;
        zones
            .entry(parts[0].to_owned())
            .or_default()
            .push(Band { band_max_grams, cents });
    }
    for bands in zones.values_mut() {
        bands.sort_by_key(|b| b.band_max_grams);
    }
    Ok(RateCard { zones })
}

pub(crate) fn compute_quote(card: &RateCard, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = card
        .bands_for(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;
    // parse_rate_card never inserts an empty band vector, but guard anyway rather than panic.
    let Some(limit) = bands.last().map(|b| b.band_max_grams) else {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    };
    let Some(band) = bands.iter().find(|b| b.band_max_grams >= parcel.weight_grams) else {
        return Err(QuoteError::Overweight { grams: parcel.weight_grams, limit });
    };
    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > OVERWEIGHT_THRESHOLD_GRAMS {
        surcharge_cents += OVERWEIGHT_SURCHARGE_CENTS;
    }
    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge_cents += international_surcharge_cents(base_cents);
    }
    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents: base_cents + surcharge_cents,
        band_max_grams: band.band_max_grams,
    })
}

fn international_surcharge_cents(base_cents: u64) -> u64 {
    // 20% of base, rounded half-up to the cent. `+ 50` before the divide-by-100 realises the
    // half-up rule for non-negative integer inputs (which cents always are).
    (base_cents * 20 + 50) / 100
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn card() -> RateCard {
        parse_rate_card(SAMPLE_CARD).expect("sample card parses")
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel { weight_grams, zone: zone.to_owned() }
    }

    #[test]
    fn parses_bands_grouped_by_zone_in_ascending_order() {
        let c = card();
        let dom = c.bands_for("domestic").expect("domestic exists");
        assert_eq!(dom.iter().map(|b| b.band_max_grams).collect::<Vec<_>>(), vec![500, 2000, 20_000]);
        let intl = c.bands_for("international").expect("international exists");
        assert_eq!(intl.iter().map(|b| b.cents).collect::<Vec<_>>(), vec![1499, 4999]);
    }

    #[test]
    fn sorts_bands_even_when_file_order_is_scrambled() {
        let scrambled = "domestic\t2000\t899\ndomestic\t500\t599\n";
        let c = parse_rate_card(scrambled).expect("parses");
        let dom = c.bands_for("domestic").expect("domestic exists");
        assert_eq!(dom[0].band_max_grams, 500);
        assert_eq!(dom[1].band_max_grams, 2000);
    }

    #[test]
    fn ignores_comment_and_blank_lines() {
        let c = parse_rate_card("\n  \n# comment\ndomestic\t500\t599\n").expect("parses");
        assert!(c.bands_for("domestic").is_some());
    }

    #[test]
    fn wrong_field_count_reports_line_number() {
        let contents = "# hi\n\ndomestic\t500\n";
        assert_eq!(parse_rate_card(contents), Err(ParseError::Malformed { line: 3 }));
    }

    #[test]
    fn non_numeric_grams_reports_line_number() {
        let contents = "domestic\tlots\t599\n";
        assert_eq!(parse_rate_card(contents), Err(ParseError::Malformed { line: 1 }));
    }

    #[test]
    fn non_numeric_cents_reports_line_number() {
        let contents = "# preface\ndomestic\t500\tfree\n";
        assert_eq!(parse_rate_card(contents), Err(ParseError::Malformed { line: 2 }));
    }

    #[test]
    fn quote_selects_smallest_band_that_fits() {
        let q = compute_quote(&card(), &parcel(250, "domestic")).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
    }

    #[test]
    fn band_boundary_is_inclusive() {
        let q = compute_quote(&card(), &parcel(500, "domestic")).unwrap();
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn one_gram_past_boundary_takes_the_next_band() {
        let q = compute_quote(&card(), &parcel(501, "domestic")).unwrap();
        assert_eq!(q.band_max_grams, 2000);
        assert_eq!(q.base_cents, 899);
    }

    #[test]
    fn overweight_surcharge_applies_strictly_above_ten_kilos() {
        let ten = compute_quote(&card(), &parcel(10_000, "domestic")).unwrap();
        assert_eq!(ten.surcharge_cents, 0);
        let over = compute_quote(&card(), &parcel(10_001, "domestic")).unwrap();
        assert_eq!(over.surcharge_cents, 500);
    }

    #[test]
    fn international_adds_twenty_percent_half_up() {
        // 1499 * 0.20 = 299.8 → 300
        let q = compute_quote(&card(), &parcel(300, "international")).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_and_overweight_surcharges_stack() {
        // 4999 * 0.20 = 999.8 → 1000, plus 500 for overweight
        let q = compute_quote(&card(), &parcel(15_000, "international")).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_carries_requested_zone() {
        match compute_quote(&card(), &parcel(100, "moonbase")) {
            Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "moonbase"),
            other => panic!("expected UnknownZone, got {other:?}"),
        }
    }

    #[test]
    fn overweight_carries_zone_limit() {
        match compute_quote(&card(), &parcel(30_000, "domestic")) {
            Err(QuoteError::Overweight { grams, limit }) => {
                assert_eq!(grams, 30_000);
                assert_eq!(limit, 20_000);
            }
            other => panic!("expected Overweight, got {other:?}"),
        }
    }

    #[test]
    fn international_half_up_rounds_exact_half_upward() {
        // 25 * 0.20 = 5.0 exactly — no rounding.
        assert_eq!(international_surcharge_cents(25), 5);
        // 3 * 0.20 = 0.6 → 1
        assert_eq!(international_surcharge_cents(3), 1);
        // 5 * 0.20 = 1.0 exactly
        assert_eq!(international_surcharge_cents(5), 1);
        // Exact half: choose a base whose 20% ends in .5. 25 * 0.20 * 10 needs an odd cent-tenth.
        // 15 * 20 = 300; 300 + 50 = 350 / 100 = 3. Represents 3.0 (no rounding case).
        // Trickier: 8 * 20 = 160 → 210 / 100 = 2 → 1.6 rounded to 2. Half-up works.
        assert_eq!(international_surcharge_cents(8), 2);
    }
}
