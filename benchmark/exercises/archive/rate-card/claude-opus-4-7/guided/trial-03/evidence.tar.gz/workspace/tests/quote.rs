//! Cross-module wiring test: exercises the public `quote()` end-to-end, including the
//! `RATECARD_PATH`-driven file source. Tests share process-wide env state, so they're
//! serialised through a mutex.

use std::io::Write;
use std::sync::{Mutex, MutexGuard, PoisonError};

use ratecard::{quote, Parcel, QuoteError};
use tempfile::NamedTempFile;

static ENV_LOCK: Mutex<()> = Mutex::new(());

const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

fn env_lock() -> MutexGuard<'static, ()> {
    ENV_LOCK.lock().unwrap_or_else(PoisonError::into_inner)
}

fn with_card<T>(contents: &str, f: impl FnOnce() -> T) -> T {
    let guard = env_lock();
    let mut file = NamedTempFile::new().expect("temp file");
    file.write_all(contents.as_bytes()).expect("write");
    std::env::set_var("RATECARD_PATH", file.path());
    let out = f();
    std::env::remove_var("RATECARD_PATH");
    drop(guard);
    out
}

fn parcel(weight_grams: u32, zone: &str) -> Parcel {
    Parcel { weight_grams, zone: zone.to_owned() }
}

#[test]
fn domestic_first_band() {
    with_card(SAMPLE, || {
        let q = quote(&parcel(250, "domestic")).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    });
}

#[test]
fn boundary_is_inclusive() {
    with_card(SAMPLE, || {
        let q = quote(&parcel(500, "domestic")).unwrap();
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.base_cents, 599);
    });
}

#[test]
fn one_gram_over_boundary_falls_into_next_band() {
    with_card(SAMPLE, || {
        let q = quote(&parcel(501, "domestic")).unwrap();
        assert_eq!(q.band_max_grams, 2000);
        assert_eq!(q.base_cents, 899);
    });
}

#[test]
fn overweight_surcharge_kicks_in_above_ten_kilos() {
    with_card(SAMPLE, || {
        let at_limit = quote(&parcel(10_000, "domestic")).unwrap();
        assert_eq!(at_limit.surcharge_cents, 0);
        let over = quote(&parcel(15_000, "domestic")).unwrap();
        assert_eq!(over.base_cents, 1799);
        assert_eq!(over.surcharge_cents, 500);
        assert_eq!(over.total_cents, 2299);
        assert_eq!(over.band_max_grams, 20_000);
    });
}

#[test]
fn international_adds_twenty_percent_half_up() {
    with_card(SAMPLE, || {
        // 1499 * 0.20 = 299.8 → 300
        let q = quote(&parcel(300, "international")).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    });
}

#[test]
fn international_and_overweight_stack() {
    with_card(SAMPLE, || {
        let q = quote(&parcel(15_000, "international")).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
        assert_eq!(q.band_max_grams, 20_000);
    });
}

#[test]
fn unknown_zone_is_reported_with_requested_name() {
    with_card(SAMPLE, || {
        let err = quote(&parcel(100, "moonbase")).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("moonbase".to_owned()));
    });
}

#[test]
fn overweight_reports_zone_limit() {
    with_card(SAMPLE, || {
        let err = quote(&parcel(30_000, "domestic")).unwrap_err();
        assert_eq!(err, QuoteError::Overweight { grams: 30_000, limit: 20_000 });
    });
}

#[test]
fn unset_env_var_is_unavailable() {
    let _guard = env_lock();
    std::env::remove_var("RATECARD_PATH");
    let err = quote(&parcel(100, "domestic")).unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);
}

#[test]
fn unreadable_path_is_unavailable() {
    let _guard = env_lock();
    std::env::set_var("RATECARD_PATH", "/nonexistent/definitely-not-there/ratecard.tsv");
    let err = quote(&parcel(100, "domestic")).unwrap_err();
    assert_eq!(err, QuoteError::RateCardUnavailable);
    std::env::remove_var("RATECARD_PATH");
}

#[test]
fn malformed_line_reports_one_based_number_including_comments_and_blanks() {
    // Line 1: comment, line 2: blank, line 3: malformed, line 4: valid
    let contents = "# heading\n\nbroken_line\ndomestic\t500\t599\n";
    with_card(contents, || {
        let err = quote(&parcel(100, "domestic")).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    });
}

#[test]
fn non_numeric_grams_is_malformed() {
    let contents = "domestic\tabc\t599\n";
    with_card(contents, || {
        let err = quote(&parcel(100, "domestic")).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    });
}

#[test]
fn quote_error_implements_display_and_error() {
    let e: &dyn std::error::Error = &QuoteError::RateCardUnavailable;
    assert_eq!(e.to_string(), "rate card unavailable");
}
