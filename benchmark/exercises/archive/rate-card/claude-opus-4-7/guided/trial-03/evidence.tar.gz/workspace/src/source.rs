//! Gateway trait for loading rate-card bytes, plus the production adapter that reads a file
//! whose path lives in `RATECARD_PATH`.
//!
//! The trait exists so `quote` can be exercised against in-memory fakes without touching the
//! filesystem or process environment.

use std::{env, fs};

#[derive(Debug)]
pub(crate) enum SourceError {
    Unavailable,
}

pub(crate) trait RateCardSource {
    fn load(&self) -> Result<String, SourceError>;
}

pub(crate) struct EnvFileSource;

impl RateCardSource for EnvFileSource {
    fn load(&self) -> Result<String, SourceError> {
        let path = env::var("RATECARD_PATH").map_err(|_| SourceError::Unavailable)?;
        fs::read_to_string(path).map_err(|_| SourceError::Unavailable)
    }
}

#[cfg(test)]
pub(crate) struct StringSource(pub String);

#[cfg(test)]
impl RateCardSource for StringSource {
    fn load(&self) -> Result<String, SourceError> {
        Ok(self.0.clone())
    }
}
