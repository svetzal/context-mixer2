//! Shipping quotes for a fulfilment operator's rate card.
//!
//! The public surface is fixed by an external test suite: [`Parcel`], [`Quote`],
//! [`QuoteError`], and the [`quote`] function.
//!
//! # Example
//!
//! ```no_run
//! use ratecard::{Parcel, quote};
//!
//! // With RATECARD_PATH pointing at a tab-separated rate card:
//! let q = quote(&Parcel { weight_grams: 300, zone: "domestic".into() }).unwrap();
//! println!("total = {} cents", q.total_cents);
//! ```

mod pricing;
mod source;

use pricing::{compute_quote, parse_rate_card, ParseError};
use source::{EnvFileSource, RateCardSource, SourceError};

/// A parcel to be priced against the rate card.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

/// A priced quote broken down into base, surcharge, and the band that was matched.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

/// Errors [`quote`] can return.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    /// `RATECARD_PATH` is unset, or the file cannot be read.
    RateCardUnavailable,
    /// A line was not three tab-separated numeric fields; 1-based, counting all lines.
    MalformedRateCard { line: usize },
    /// The requested zone has no bands in the card.
    UnknownZone(String),
    /// The parcel weight exceeds the largest band for its zone.
    Overweight { grams: u32, limit: u32 },
}

impl std::fmt::Display for QuoteError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::RateCardUnavailable => f.write_str("rate card unavailable"),
            Self::MalformedRateCard { line } => write!(f, "malformed rate card at line {line}"),
            Self::UnknownZone(zone) => write!(f, "unknown zone: {zone}"),
            Self::Overweight { grams, limit } => {
                write!(f, "parcel weight {grams} g exceeds zone limit {limit} g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

/// Price `parcel` against the rate card at `RATECARD_PATH`.
///
/// See the crate-level docs for the file format and quoting rules.
///
/// # Errors
///
/// Returns [`QuoteError`] when the card cannot be loaded or parsed, or when no band applies
/// to the parcel.
pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    quote_with(&EnvFileSource, parcel)
}

fn quote_with<S: RateCardSource>(source: &S, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let span = tracing::info_span!(
        "ratecard.quote",
        zone = %parcel.zone,
        weight_grams = parcel.weight_grams,
    );
    let _entered = span.enter();

    let outcome = load_and_price(source, parcel);
    match &outcome {
        Ok(q) => tracing::info!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            total_cents = q.total_cents,
            outcome = "priced",
            "quote completed",
        ),
        Err(err) => tracing::warn!(
            zone = %parcel.zone,
            weight_grams = parcel.weight_grams,
            outcome = "failed",
            error = %err,
            "quote failed",
        ),
    }
    outcome
}

fn load_and_price<S: RateCardSource>(source: &S, parcel: &Parcel) -> Result<Quote, QuoteError> {
    let contents = source.load().map_err(|e| match e {
        SourceError::Unavailable => QuoteError::RateCardUnavailable,
    })?;
    let card = parse_rate_card(&contents).map_err(|e| match e {
        ParseError::Malformed { line } => QuoteError::MalformedRateCard { line },
    })?;
    compute_quote(&card, parcel)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::source::StringSource;

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    #[test]
    fn quote_with_fake_source_prices_a_parcel() {
        let src = StringSource(SAMPLE.to_owned());
        let q = quote_with(&src, &Parcel { weight_grams: 250, zone: "domestic".into() }).unwrap();
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn quote_with_fake_source_reports_unavailable() {
        struct DeadSource;
        impl RateCardSource for DeadSource {
            fn load(&self) -> Result<String, SourceError> {
                Err(SourceError::Unavailable)
            }
        }
        let err = quote_with(&DeadSource, &Parcel { weight_grams: 100, zone: "domestic".into() })
            .unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn quote_with_fake_source_reports_malformed_line() {
        let src = StringSource("# ok\n\nbroken\ndomestic\t500\t599\n".to_owned());
        let err = quote_with(&src, &Parcel { weight_grams: 100, zone: "domestic".into() })
            .unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn display_covers_every_variant() {
        assert_eq!(QuoteError::RateCardUnavailable.to_string(), "rate card unavailable");
        assert_eq!(
            QuoteError::MalformedRateCard { line: 7 }.to_string(),
            "malformed rate card at line 7"
        );
        assert_eq!(
            QuoteError::UnknownZone("moonbase".into()).to_string(),
            "unknown zone: moonbase"
        );
        assert_eq!(
            QuoteError::Overweight { grams: 42, limit: 20 }.to_string(),
            "parcel weight 42 g exceeds zone limit 20 g"
        );
    }

    #[test]
    fn quote_error_is_a_std_error() {
        fn assert_is_error<E: std::error::Error>(_: &E) {}
        assert_is_error(&QuoteError::RateCardUnavailable);
    }
}
