pub mod zones;

use std::env;
use std::fmt;
use std::fs;

#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card is unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "rate card is malformed at line {}", line)
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {}", zone)
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {} grams exceeds limit {} grams", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug, Clone)]
struct Band {
    max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<Vec<(String, Band)>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    if path.is_empty() {
        return Err(QuoteError::RateCardUnavailable);
    }
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut entries: Vec<(String, Band)> = Vec::new();
    for (idx, raw) in contents.lines().enumerate() {
        let line_no = idx + 1;
        let trimmed = raw.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = raw.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }
        let zone = parts[0].to_string();
        let max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        entries.push((zone, Band { max_grams, cents }));
    }
    Ok(entries)
}

fn international_surcharge(base_cents: u64) -> u64 {
    (base_cents * 20 + 50) / 100
}

fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!(
        "ratecard.quote zone={} weight_grams={} total_cents={}",
        zone, weight_grams, total_cents
    );
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let entries = load_rate_card()?;

    let mut zone_bands: Vec<Band> = entries
        .into_iter()
        .filter_map(|(z, b)| if z == parcel.zone { Some(b) } else { None })
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.max_grams);

    let matched = zone_bands.iter().find(|b| b.max_grams >= parcel.weight_grams);
    let band = match matched {
        Some(b) => b,
        None => {
            let limit = zone_bands.last().map(|b| b.max_grams).unwrap_or(0);
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += international_surcharge(base_cents);
    }
    let total_cents = base_cents + surcharge_cents;

    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn write_card(contents: &str) -> NamedTempFile {
        let mut f = NamedTempFile::new().expect("temp file");
        f.write_all(contents.as_bytes()).expect("write");
        f
    }

    fn with_card<R>(contents: &str, body: impl FnOnce() -> R) -> R {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let file = write_card(contents);
        env::set_var("RATECARD_PATH", file.path());
        let result = body();
        env::remove_var("RATECARD_PATH");
        result
    }

    #[test]
    fn matches_first_band_by_weight() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn exact_band_boundary_uses_that_band() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn matches_middle_band() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&Parcel {
                weight_grams: 1500,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
            assert_eq!(q.surcharge_cents, 0);
        });
    }

    #[test]
    fn heavy_domestic_adds_weight_surcharge() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&Parcel {
                weight_grams: 15_000,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
            assert_eq!(q.band_max_grams, 20000);
        });
    }

    #[test]
    fn weight_exactly_ten_thousand_no_weight_surcharge() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&Parcel {
                weight_grams: 10_000,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.base_cents, 1799);
        });
    }

    #[test]
    fn international_surcharge_is_twenty_percent_half_up() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&Parcel {
                weight_grams: 300,
                zone: "international".into(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 1499);
            // 20% of 1499 = 299.8 → 300 half-up
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn heavy_international_stacks_both_surcharges() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&Parcel {
                weight_grams: 15_000,
                zone: "international".into(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 4999);
            // 20% of 4999 = 999.8 → 1000, plus 500 weight surcharge
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
        });
    }

    #[test]
    fn unknown_zone_returned() {
        with_card(SAMPLE_CARD, || {
            let err = quote(&Parcel {
                weight_grams: 100,
                zone: "lunar".into(),
            })
            .unwrap_err();
            assert_eq!(err, QuoteError::UnknownZone("lunar".into()));
        });
    }

    #[test]
    fn overweight_reports_largest_band() {
        with_card(SAMPLE_CARD, || {
            let err = quote(&Parcel {
                weight_grams: 25_000,
                zone: "domestic".into(),
            })
            .unwrap_err();
            assert_eq!(
                err,
                QuoteError::Overweight {
                    grams: 25_000,
                    limit: 20_000
                }
            );
        });
    }

    #[test]
    fn missing_env_var_is_rate_card_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        env::remove_var("RATECARD_PATH");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn unreadable_path_is_rate_card_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        env::set_var("RATECARD_PATH", "/nonexistent/path/to/nowhere.tsv");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        env::remove_var("RATECARD_PATH");
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn malformed_line_reports_one_based_line_number_including_comments_and_blanks() {
        let card = "\
# header comment
domestic\t500\t599

domestic\t2000\tNaN
";
        with_card(card, || {
            let err = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            })
            .unwrap_err();
            assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
        });
    }

    #[test]
    fn malformed_wrong_field_count() {
        let card = "domestic\t500\n";
        with_card(card, || {
            let err = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            })
            .unwrap_err();
            assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
        });
    }

    #[test]
    fn display_and_error_implemented() {
        let e: Box<dyn std::error::Error> = Box::new(QuoteError::RateCardUnavailable);
        assert!(!format!("{}", e).is_empty());
    }
}
