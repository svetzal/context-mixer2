pub mod zones;

use std::collections::BTreeMap;
use std::fmt;
use std::fs;
use std::path::PathBuf;

#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card is unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(
                    f,
                    "parcel weighs {grams} grams, exceeding the {limit} gram limit"
                )
            }
        }
    }
}

impl std::error::Error for QuoteError {}

#[derive(Debug, Clone)]
struct Band {
    max_grams: u32,
    cents: u64,
}

const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";
const INTERNATIONAL_SURCHARGE_NUMERATOR: u64 = 20;
const INTERNATIONAL_SURCHARGE_DENOMINATOR: u64 = 100;

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = load_rate_card()?;

    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = select_band(bands, parcel.weight_grams)?;

    let base_cents = band.cents;
    let surcharge_cents = compute_surcharge(base_cents, parcel);
    let total_cents = base_cents + surcharge_cents;

    let quote = Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    };

    emit_diagnostic(parcel, &quote);

    Ok(quote)
}

fn load_rate_card() -> Result<BTreeMap<String, Vec<Band>>, QuoteError> {
    let path = std::env::var_os("RATECARD_PATH")
        .map(PathBuf::from)
        .ok_or(QuoteError::RateCardUnavailable)?;

    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    parse_rate_card(&contents)
}

fn parse_rate_card(contents: &str) -> Result<BTreeMap<String, Vec<Band>>, QuoteError> {
    let mut card: BTreeMap<String, Vec<Band>> = BTreeMap::new();

    for (index, raw_line) in contents.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = raw_line.trim();

        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = raw_line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let zone = fields[0].trim();
        if zone.is_empty() {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }

        let max_grams: u32 = fields[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        let cents: u64 = fields[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;

        card.entry(zone.to_string())
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in card.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(card)
}

fn select_band(bands: &[Band], weight_grams: u32) -> Result<&Band, QuoteError> {
    let limit = bands.last().map(|b| b.max_grams).unwrap_or(0);

    bands
        .iter()
        .find(|b| b.max_grams >= weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: weight_grams,
            limit,
        })
}

fn compute_surcharge(base_cents: u64, parcel: &Parcel) -> u64 {
    let mut surcharge = 0u64;

    if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        surcharge += HEAVY_SURCHARGE_CENTS;
    }

    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge += round_half_up(base_cents * INTERNATIONAL_SURCHARGE_NUMERATOR, INTERNATIONAL_SURCHARGE_DENOMINATOR);
    }

    surcharge
}

fn round_half_up(numerator: u64, denominator: u64) -> u64 {
    (numerator + denominator / 2) / denominator
}

fn emit_diagnostic(parcel: &Parcel, quote: &Quote) {
    eprintln!(
        "ratecard quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, quote.total_cents
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    // cargo test runs tests in parallel by default, and we mutate process
    // environment here. Serialize with a mutex.
    static ENV_LOCK: Mutex<()> = Mutex::new(());

    const CARD: &str = "# zone\tband_max_grams\tcents\n\
domestic\t500\t599\n\
domestic\t2000\t899\n\
domestic\t20000\t1799\n\
international\t500\t1499\n\
international\t20000\t4999\n";

    struct EnvGuard<'a> {
        _lock: std::sync::MutexGuard<'a, ()>,
        _file: Option<NamedTempFile>,
    }

    impl<'a> Drop for EnvGuard<'a> {
        fn drop(&mut self) {
            // SAFETY: single-threaded across tests via ENV_LOCK.
            unsafe {
                std::env::remove_var("RATECARD_PATH");
            }
        }
    }

    fn with_card(contents: &str) -> EnvGuard<'static> {
        let lock = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let file = NamedTempFile::new().expect("temp file");
        std::fs::write(file.path(), contents).expect("write card");
        // SAFETY: single-threaded across tests via ENV_LOCK.
        unsafe {
            std::env::set_var("RATECARD_PATH", file.path());
        }
        EnvGuard {
            _lock: lock,
            _file: Some(file),
        }
    }

    fn without_card() -> EnvGuard<'static> {
        let lock = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        // SAFETY: single-threaded across tests via ENV_LOCK.
        unsafe {
            std::env::remove_var("RATECARD_PATH");
        }
        EnvGuard {
            _lock: lock,
            _file: None,
        }
    }

    fn parcel(weight_grams: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn light_domestic_uses_first_band() {
        let _g = with_card(CARD);
        let q = quote(&parcel(100, "domestic")).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn band_boundary_is_inclusive() {
        let _g = with_card(CARD);
        let q = quote(&parcel(500, "domestic")).unwrap();
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn weight_selects_first_covering_band() {
        let _g = with_card(CARD);
        let q = quote(&parcel(1500, "domestic")).unwrap();
        assert_eq!(q.band_max_grams, 2000);
        assert_eq!(q.total_cents, 899);
    }

    #[test]
    fn heavy_surcharge_kicks_in_strictly_above_ten_kilos() {
        let _g = with_card(CARD);
        let just_at = quote(&parcel(10_000, "domestic")).unwrap();
        assert_eq!(just_at.surcharge_cents, 0);

        let over = quote(&parcel(10_001, "domestic")).unwrap();
        assert_eq!(over.surcharge_cents, 500);
    }

    #[test]
    fn international_adds_twenty_percent_half_up() {
        let _g = with_card(CARD);
        let q = quote(&parcel(400, "international")).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn surcharges_accumulate() {
        let _g = with_card(CARD);
        let q = quote(&parcel(15_000, "international")).unwrap();
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_carries_zone_name() {
        let _g = with_card(CARD);
        let err = quote(&parcel(400, "moon")).unwrap_err();
        match err {
            QuoteError::UnknownZone(z) => assert_eq!(z, "moon"),
            other => panic!("wrong variant: {other:?}"),
        }
    }

    #[test]
    fn overweight_reports_grams_and_limit() {
        let _g = with_card(CARD);
        let err = quote(&parcel(25_000, "domestic")).unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 25_000);
                assert_eq!(limit, 20_000);
            }
            other => panic!("wrong variant: {other:?}"),
        }
    }

    #[test]
    fn missing_env_var_is_unavailable() {
        let _g = without_card();
        let err = quote(&parcel(400, "domestic")).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn missing_file_is_unavailable() {
        let lock = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        // SAFETY: serialized via ENV_LOCK.
        unsafe {
            std::env::set_var("RATECARD_PATH", "/nonexistent/path/to/ratecard.tsv");
        }
        let err = quote(&parcel(400, "domestic")).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
        unsafe {
            std::env::remove_var("RATECARD_PATH");
        }
        drop(lock);
    }

    #[test]
    fn malformed_number_reports_one_based_line() {
        let _g = with_card(
            "# zone\tband_max_grams\tcents\ndomestic\t500\t599\n\ndomestic\tnotanumber\t899\n",
        );
        let err = quote(&parcel(400, "domestic")).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 4),
            other => panic!("wrong variant: {other:?}"),
        }
    }

    #[test]
    fn wrong_field_count_is_malformed() {
        let _g = with_card("domestic\t500\n");
        let err = quote(&parcel(400, "domestic")).unwrap_err();
        assert!(matches!(err, QuoteError::MalformedRateCard { line: 1 }));
    }

    #[test]
    fn display_impl_covers_every_variant() {
        assert!(!format!("{}", QuoteError::RateCardUnavailable).is_empty());
        assert!(!format!("{}", QuoteError::MalformedRateCard { line: 3 }).is_empty());
        assert!(!format!("{}", QuoteError::UnknownZone("mars".into())).is_empty());
        assert!(
            !format!("{}", QuoteError::Overweight { grams: 30_000, limit: 20_000 }).is_empty()
        );
    }

    #[test]
    fn error_trait_is_implemented() {
        fn assert_error<E: std::error::Error>() {}
        assert_error::<QuoteError>();
    }
}
