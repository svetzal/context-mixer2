pub mod zones;

use std::env;
use std::fmt;
use std::fs;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(
                    f,
                    "overweight parcel: {grams} grams exceeds zone limit of {limit} grams"
                )
            }
        }
    }
}

impl std::error::Error for QuoteError {}

const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_ZONE: &str = "international";

#[derive(Debug)]
struct Band {
    zone: String,
    band_max_grams: u32,
    cents: u64,
}

fn parse_rate_card(text: &str) -> Result<Vec<Band>, QuoteError> {
    let mut bands = Vec::new();
    for (index, raw_line) in text.lines().enumerate() {
        let line_number = index + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = raw_line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let zone = fields[0].trim().to_string();
        let band_max_grams: u32 = fields[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = fields[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        bands.push(Band {
            zone,
            band_max_grams,
            cents,
        });
    }
    Ok(bands)
}

fn load_rate_card() -> Result<Vec<Band>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    if path.is_empty() {
        return Err(QuoteError::RateCardUnavailable);
    }
    let text = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    parse_rate_card(&text)
}

fn international_surcharge(base_cents: u64) -> u64 {
    // 20% of base_cents, half-up rounding to the nearest whole cent.
    let numerator = base_cents.saturating_mul(20);
    (numerator + 50) / 100
}

fn compute_quote(parcel: &Parcel, bands: &[Band]) -> Result<Quote, QuoteError> {
    let mut zone_bands: Vec<&Band> = bands.iter().filter(|b| b.zone == parcel.zone).collect();
    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }
    zone_bands.sort_by_key(|b| b.band_max_grams);

    let largest = zone_bands.last().unwrap().band_max_grams;

    let band = match zone_bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
    {
        Some(b) => *b,
        None => {
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: largest,
            });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        surcharge_cents += HEAVY_SURCHARGE_CENTS;
    }
    if parcel.zone == INTERNATIONAL_ZONE {
        surcharge_cents += international_surcharge(base_cents);
    }
    let total_cents = base_cents + surcharge_cents;

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

fn emit_diagnostic(parcel: &Parcel, quote: &Quote) {
    eprintln!(
        "ratecard.quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, quote.total_cents
    );
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_rate_card()?;
    let q = compute_quote(parcel, &bands)?;
    emit_diagnostic(parcel, &q);
    Ok(q)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    // Serialize any test that touches the RATECARD_PATH env var, since env
    // vars are process-global and cargo runs tests in parallel.
    static ENV_LOCK: Mutex<()> = Mutex::new(());

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn sample_bands() -> Vec<Band> {
        parse_rate_card(SAMPLE_CARD).expect("sample rate card parses")
    }

    fn parcel(weight: u32, zone: &str) -> Parcel {
        Parcel {
            weight_grams: weight,
            zone: zone.to_string(),
        }
    }

    #[test]
    fn domestic_first_band_matches_at_boundary() {
        let bands = sample_bands();
        let q = compute_quote(&parcel(500, "domestic"), &bands).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_below_first_band_matches_it() {
        let bands = sample_bands();
        let q = compute_quote(&parcel(1, "domestic"), &bands).unwrap();
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.total_cents, 599);
    }

    #[test]
    fn domestic_second_band_selected_above_first_boundary() {
        let bands = sample_bands();
        let q = compute_quote(&parcel(501, "domestic"), &bands).unwrap();
        assert_eq!(q.band_max_grams, 2000);
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 899);
    }

    #[test]
    fn heavy_surcharge_kicks_in_strictly_above_10000() {
        let bands = sample_bands();
        let q_at = compute_quote(&parcel(10_000, "domestic"), &bands).unwrap();
        assert_eq!(q_at.surcharge_cents, 0);
        assert_eq!(q_at.total_cents, 1799);
        assert_eq!(q_at.band_max_grams, 20_000);

        let q_above = compute_quote(&parcel(10_001, "domestic"), &bands).unwrap();
        assert_eq!(q_above.surcharge_cents, 500);
        assert_eq!(q_above.total_cents, 1799 + 500);
        assert_eq!(q_above.band_max_grams, 20_000);
    }

    #[test]
    fn international_surcharge_is_20_percent_half_up() {
        let bands = sample_bands();
        let q = compute_quote(&parcel(200, "international"), &bands).unwrap();
        assert_eq!(q.base_cents, 1499);
        // 20% of 1499 = 299.8, rounds half-up to 300
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1499 + 300);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn international_heavy_stacks_surcharges() {
        let bands = sample_bands();
        let q = compute_quote(&parcel(15_000, "international"), &bands).unwrap();
        assert_eq!(q.base_cents, 4999);
        // 20% of 4999 = 999.8, rounds to 1000. Plus 500 heavy surcharge.
        assert_eq!(q.surcharge_cents, 1000 + 500);
        assert_eq!(q.total_cents, 4999 + 1000 + 500);
        assert_eq!(q.band_max_grams, 20_000);
    }

    #[test]
    fn unknown_zone_returns_error_with_zone() {
        let bands = sample_bands();
        let err = compute_quote(&parcel(100, "moon"), &bands).unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("moon".to_string()));
    }

    #[test]
    fn overweight_reports_largest_band_as_limit() {
        let bands = sample_bands();
        let err = compute_quote(&parcel(20_001, "domestic"), &bands).unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 20_001,
                limit: 20_000,
            }
        );
    }

    #[test]
    fn parse_rejects_wrong_field_count_with_1_based_line() {
        let text = "# header\n\ndomestic\t500\n";
        let err = parse_rate_card(text).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn parse_rejects_bad_number_with_1_based_line() {
        let text = "# header\ndomestic\tabc\t599\n";
        let err = parse_rate_card(text).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn parse_counts_blank_and_comment_lines() {
        // Line 1: comment, line 2: blank, line 3: valid, line 4: blank,
        // line 5: malformed (only 2 fields).
        let text = "# header\n\ndomestic\t500\t599\n\ndomestic\t2000\n";
        let err = parse_rate_card(text).unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 5 });
    }

    #[test]
    fn parse_ignores_blank_and_comment_lines() {
        let bands = parse_rate_card(SAMPLE_CARD).unwrap();
        assert_eq!(bands.len(), 5);
    }

    #[test]
    fn out_of_order_bands_still_pick_smallest_matching() {
        // Bands intentionally listed out of order in the file.
        let text = "\
domestic\t20000\t1799
domestic\t500\t599
domestic\t2000\t899
";
        let bands = parse_rate_card(text).unwrap();
        let q = compute_quote(&parcel(300, "domestic"), &bands).unwrap();
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn quote_reads_from_env_var_path() {
        let _guard = ENV_LOCK.lock().unwrap();
        let file = NamedTempFile::new().unwrap();
        std::fs::write(file.path(), SAMPLE_CARD).unwrap();
        std::env::set_var("RATECARD_PATH", file.path());

        let q = quote(&parcel(1500, "domestic")).unwrap();
        assert_eq!(q.band_max_grams, 2000);
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.total_cents, 899);

        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn quote_unavailable_when_env_missing() {
        let _guard = ENV_LOCK.lock().unwrap();
        std::env::remove_var("RATECARD_PATH");
        let err = quote(&parcel(100, "domestic")).unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn quote_unavailable_when_path_does_not_exist() {
        let _guard = ENV_LOCK.lock().unwrap();
        std::env::set_var("RATECARD_PATH", "/nonexistent/path/should-not-exist.tsv");
        let err = quote(&parcel(100, "domestic")).unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
        std::env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn display_formats_are_readable() {
        assert_eq!(
            format!("{}", QuoteError::RateCardUnavailable),
            "rate card unavailable"
        );
        assert_eq!(
            format!("{}", QuoteError::MalformedRateCard { line: 7 }),
            "malformed rate card at line 7"
        );
        assert_eq!(
            format!("{}", QuoteError::UnknownZone("mars".to_string())),
            "unknown zone: mars"
        );
        assert_eq!(
            format!(
                "{}",
                QuoteError::Overweight {
                    grams: 25_000,
                    limit: 20_000,
                }
            ),
            "overweight parcel: 25000 grams exceeds zone limit of 20000 grams"
        );
    }

    #[test]
    fn error_trait_is_implemented() {
        fn assert_error<E: std::error::Error>(_: &E) {}
        assert_error(&QuoteError::RateCardUnavailable);
    }
}
