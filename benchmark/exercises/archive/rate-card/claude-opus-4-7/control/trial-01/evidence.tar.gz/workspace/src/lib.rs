use std::collections::BTreeMap;
use std::env;
use std::fmt;
use std::fs;

pub mod zones;

#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {line}")
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {zone}")
            }
            QuoteError::Overweight { grams, limit } => {
                write!(f, "overweight: {grams}g exceeds zone limit of {limit}g")
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<BTreeMap<String, Vec<Band>>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    if path.is_empty() {
        return Err(QuoteError::RateCardUnavailable);
    }
    let content = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut map: BTreeMap<String, Vec<Band>> = BTreeMap::new();
    for (idx, raw_line) in content.lines().enumerate() {
        let line_no = idx + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = raw_line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }
        let zone = fields[0].trim().to_string();
        let max_grams: u32 = fields[1]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents: u64 = fields[2]
            .trim()
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        if zone.is_empty() {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }
        map.entry(zone).or_default().push(Band { max_grams, cents });
    }

    for bands in map.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(map)
}

fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!(
        "ratecard.quote zone={zone} weight_grams={weight_grams} total_cents={total_cents}"
    );
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = load_rate_card()?;

    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    // Zone entries always have at least one band because entries are only
    // inserted when a line is pushed.
    let largest = bands.last().expect("zone entry has at least one band");

    let band = bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .ok_or(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest.max_grams,
        })?;

    let base_cents = band.cents;

    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        // 20% of base_cents, rounded half-up to the cent.
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }

    let total_cents = base_cents + surcharge_cents;

    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    // Env vars are process-global; serialize tests that touch RATECARD_PATH.
    static ENV_LOCK: Mutex<()> = Mutex::new(());

    const SAMPLE_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn write_card(contents: &str) -> NamedTempFile {
        let mut f = NamedTempFile::new().expect("tempfile");
        f.write_all(contents.as_bytes()).expect("write");
        f
    }

    fn with_card<T>(contents: &str, body: impl FnOnce() -> T) -> T {
        let guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let file = write_card(contents);
        env::set_var("RATECARD_PATH", file.path());
        let out = body();
        env::remove_var("RATECARD_PATH");
        drop(guard);
        out
    }

    fn without_card<T>(body: impl FnOnce() -> T) -> T {
        let guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        env::remove_var("RATECARD_PATH");
        let out = body();
        drop(guard);
        out
    }

    #[test]
    fn domestic_small_parcel_uses_first_band() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&Parcel {
                weight_grams: 250,
                zone: "domestic".into(),
            })
            .expect("quote");
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn boundary_weight_selects_that_band() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            })
            .expect("quote");
            assert_eq!(q.band_max_grams, 500);
            assert_eq!(q.base_cents, 599);
        });
    }

    #[test]
    fn weight_one_over_boundary_selects_next_band() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            })
            .expect("quote");
            assert_eq!(q.band_max_grams, 2000);
            assert_eq!(q.base_cents, 899);
        });
    }

    #[test]
    fn overweight_domestic_adds_500_cents() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&Parcel {
                weight_grams: 15_000,
                zone: "domestic".into(),
            })
            .expect("quote");
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
            assert_eq!(q.band_max_grams, 20_000);
        });
    }

    #[test]
    fn ten_thousand_grams_exact_has_no_overweight_surcharge() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&Parcel {
                weight_grams: 10_000,
                zone: "domestic".into(),
            })
            .expect("quote");
            assert_eq!(q.surcharge_cents, 0);
        });
    }

    #[test]
    fn international_adds_twenty_percent_rounded_half_up() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&Parcel {
                weight_grams: 300,
                zone: "international".into(),
            })
            .expect("quote");
            assert_eq!(q.base_cents, 1499);
            // 1499 * 0.20 = 299.8 -> 300
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_overweight_stacks_both_surcharges() {
        with_card(SAMPLE_CARD, || {
            let q = quote(&Parcel {
                weight_grams: 15_000,
                zone: "international".into(),
            })
            .expect("quote");
            assert_eq!(q.base_cents, 4999);
            // 4999 * 0.20 = 999.8 -> 1000, plus 500 heavy = 1500
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
            assert_eq!(q.band_max_grams, 20_000);
        });
    }

    #[test]
    fn unknown_zone_returns_error_carrying_requested_zone() {
        with_card(SAMPLE_CARD, || {
            let err = quote(&Parcel {
                weight_grams: 100,
                zone: "lunar".into(),
            })
            .unwrap_err();
            assert_eq!(err, QuoteError::UnknownZone("lunar".to_string()));
        });
    }

    #[test]
    fn overweight_error_reports_zone_largest_band_as_limit() {
        with_card(SAMPLE_CARD, || {
            let err = quote(&Parcel {
                weight_grams: 25_000,
                zone: "domestic".into(),
            })
            .unwrap_err();
            assert_eq!(
                err,
                QuoteError::Overweight {
                    grams: 25_000,
                    limit: 20_000,
                }
            );
        });
    }

    #[test]
    fn unset_ratecard_path_is_unavailable() {
        without_card(|| {
            let err = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            })
            .unwrap_err();
            assert_eq!(err, QuoteError::RateCardUnavailable);
        });
    }

    #[test]
    fn missing_ratecard_file_is_unavailable() {
        let guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        env::set_var("RATECARD_PATH", "/definitely/does/not/exist/ratecard.tsv");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        env::remove_var("RATECARD_PATH");
        drop(guard);
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn malformed_wrong_field_count_reports_one_based_line_counting_comments() {
        // Line 1: comment, line 2: blank, line 3: valid, line 4: malformed (2 fields).
        let card = "# header\n\ndomestic\t500\t599\ndomestic\t2000\n";
        with_card(card, || {
            let err = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            })
            .unwrap_err();
            assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
        });
    }

    #[test]
    fn malformed_unparseable_number_reports_line() {
        let card = "domestic\tfive-hundred\t599\n";
        with_card(card, || {
            let err = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            })
            .unwrap_err();
            assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
        });
    }

    #[test]
    fn malformed_unparseable_cents_reports_line() {
        let card = "# comment\ndomestic\t500\tfree\n";
        with_card(card, || {
            let err = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            })
            .unwrap_err();
            assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
        });
    }

    #[test]
    fn comments_and_blank_lines_are_ignored() {
        let card = "\
# header line
\t
domestic\t500\t599

# another comment
domestic\t2000\t899
";
        with_card(card, || {
            let q = quote(&Parcel {
                weight_grams: 1_000,
                zone: "domestic".into(),
            })
            .expect("quote");
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
        });
    }

    #[test]
    fn bands_apply_in_ascending_order_regardless_of_file_order() {
        let card = "\
domestic\t20000\t1799
domestic\t500\t599
domestic\t2000\t899
";
        with_card(card, || {
            let q = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            })
            .expect("quote");
            assert_eq!(q.band_max_grams, 500);
            assert_eq!(q.base_cents, 599);
        });
    }

    #[test]
    fn error_types_implement_display_and_error() {
        fn assert_error<E: std::error::Error>(_: &E) {}
        let e = QuoteError::UnknownZone("mars".into());
        assert_error(&e);
        assert!(!format!("{e}").is_empty());
    }
}
