use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card is unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => write!(
                f,
                "parcel weight {} grams exceeds zone limit of {} grams",
                grams, limit
            ),
        }
    }
}

impl Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

fn load_rate_card(path: &str) -> Result<Vec<(String, Band)>, QuoteError> {
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let mut entries: Vec<(String, Band)> = Vec::new();
    for (idx, line) in contents.lines().enumerate() {
        let line_no = idx + 1;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }
        let zone = parts[0].to_string();
        let max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        entries.push((zone, Band { max_grams, cents }));
    }
    Ok(entries)
}

fn international_surcharge(base_cents: u64) -> u64 {
    (base_cents * 20 + 50) / 100
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    if path.is_empty() {
        return Err(QuoteError::RateCardUnavailable);
    }
    let entries = load_rate_card(&path)?;

    let mut zone_bands: Vec<&Band> = entries
        .iter()
        .filter(|(z, _)| z == &parcel.zone)
        .map(|(_, b)| b)
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.max_grams);

    let band = match zone_bands.iter().find(|b| b.max_grams >= parcel.weight_grams) {
        Some(b) => *b,
        None => {
            let limit = zone_bands.last().unwrap().max_grams;
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit,
            });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += international_surcharge(base_cents);
    }
    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "ratecard.quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn write_card(contents: &str) -> NamedTempFile {
        let mut f = NamedTempFile::new().expect("temp file");
        f.write_all(contents.as_bytes()).expect("write");
        f
    }

    fn with_card<F: FnOnce()>(contents: &str, f: F) {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let file = write_card(contents);
        env::set_var("RATECARD_PATH", file.path());
        f();
        env::remove_var("RATECARD_PATH");
    }

    fn with_env<F: FnOnce()>(f: F) {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        env::remove_var("RATECARD_PATH");
        f();
    }

    #[test]
    fn picks_first_matching_band() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
        });
    }

    #[test]
    fn boundary_weight_uses_that_band() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn moves_to_next_band_above_boundary() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
        });
    }

    #[test]
    fn heavy_parcel_gets_flat_surcharge() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 15_000,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
            assert_eq!(q.band_max_grams, 20_000);
        });
    }

    #[test]
    fn boundary_10000_no_surcharge() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 10_000,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(q.surcharge_cents, 0);
        });
    }

    #[test]
    fn international_surcharge_is_twenty_percent_rounded() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 100,
                zone: "international".into(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 1499);
            // 1499 * 0.20 = 299.8 → 300
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_heavy_gets_both_surcharges() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 15_000,
                zone: "international".into(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 4999);
            // 4999 * 0.20 = 999.8 → 1000, plus 500 heavy
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
        });
    }

    #[test]
    fn unknown_zone_carries_requested_name() {
        with_card(SAMPLE, || {
            match quote(&Parcel {
                weight_grams: 100,
                zone: "lunar".into(),
            }) {
                Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "lunar"),
                other => panic!("expected UnknownZone, got {:?}", other),
            }
        });
    }

    #[test]
    fn overweight_reports_zone_limit() {
        with_card(SAMPLE, || {
            match quote(&Parcel {
                weight_grams: 25_000,
                zone: "domestic".into(),
            }) {
                Err(QuoteError::Overweight { grams, limit }) => {
                    assert_eq!(grams, 25_000);
                    assert_eq!(limit, 20_000);
                }
                other => panic!("expected Overweight, got {:?}", other),
            }
        });
    }

    #[test]
    fn unset_env_is_unavailable() {
        with_env(|| {
            match quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            }) {
                Err(QuoteError::RateCardUnavailable) => {}
                other => panic!("expected RateCardUnavailable, got {:?}", other),
            }
        });
    }

    #[test]
    fn missing_file_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        env::set_var("RATECARD_PATH", "/nonexistent/path/to/ratecard-xyz.tsv");
        let r = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        });
        env::remove_var("RATECARD_PATH");
        match r {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected RateCardUnavailable, got {:?}", other),
        }
    }

    #[test]
    fn malformed_reports_1_based_line_counting_comments_and_blanks() {
        // Line 1: comment. Line 2: blank. Line 3: valid. Line 4: bad (2 fields).
        let bad = "# a comment\n\ndomestic\t500\t599\ndomestic\t2000\n";
        with_card(bad, || {
            match quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            }) {
                Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 4),
                other => panic!("expected MalformedRateCard, got {:?}", other),
            }
        });
    }

    #[test]
    fn malformed_on_unparseable_number() {
        let bad = "domestic\tfive-hundred\t599\n";
        with_card(bad, || {
            match quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            }) {
                Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 1),
                other => panic!("expected MalformedRateCard, got {:?}", other),
            }
        });
    }

    #[test]
    fn error_display_and_error_trait() {
        let e: Box<dyn Error> = Box::new(QuoteError::UnknownZone("lunar".into()));
        assert!(format!("{}", e).contains("lunar"));
        let e2 = QuoteError::MalformedRateCard { line: 7 };
        assert!(format!("{}", e2).contains("7"));
    }
}
