pub mod zones;

use std::collections::BTreeMap;
use std::fmt;
use std::fs;

#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card is unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {}", zone)
            }
            QuoteError::Overweight { grams, limit } => {
                write!(
                    f,
                    "parcel weight {} grams exceeds zone limit of {} grams",
                    grams, limit
                )
            }
        }
    }
}

impl std::error::Error for QuoteError {}

const HEAVY_THRESHOLD_GRAMS: u32 = 10_000;
const HEAVY_SURCHARGE_CENTS: u64 = 500;
const INTERNATIONAL_SURCHARGE_NUMERATOR: u64 = 20;

#[derive(Debug, Clone, Copy)]
struct Band {
    max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<BTreeMap<String, Vec<Band>>, QuoteError> {
    let path = std::env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    if path.is_empty() {
        return Err(QuoteError::RateCardUnavailable);
    }
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut zones: BTreeMap<String, Vec<Band>> = BTreeMap::new();

    for (idx, raw_line) in contents.lines().enumerate() {
        let line_no = idx + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        let fields: Vec<&str> = raw_line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }
        let zone = fields[0].trim();
        let max_grams_str = fields[1].trim();
        let cents_str = fields[2].trim();
        if zone.is_empty() || max_grams_str.is_empty() || cents_str.is_empty() {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }
        let max_grams: u32 = max_grams_str
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents: u64 = cents_str
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;

        zones
            .entry(zone.to_string())
            .or_default()
            .push(Band { max_grams, cents });
    }

    for bands in zones.values_mut() {
        bands.sort_by_key(|b| b.max_grams);
    }

    Ok(zones)
}

fn international_surcharge(base_cents: u64) -> u64 {
    (base_cents * INTERNATIONAL_SURCHARGE_NUMERATOR + 50) / 100
}

fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!(
        "ratecard.quote zone={} weight_grams={} total_cents={}",
        zone, weight_grams, total_cents
    );
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let card = load_rate_card()?;

    let bands = card
        .get(&parcel.zone)
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let largest = bands
        .last()
        .ok_or_else(|| QuoteError::UnknownZone(parcel.zone.clone()))?;

    let band = match bands.iter().find(|b| b.max_grams >= parcel.weight_grams) {
        Some(b) => *b,
        None => {
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: largest.max_grams,
            });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > HEAVY_THRESHOLD_GRAMS {
        surcharge_cents += HEAVY_SURCHARGE_CENTS;
    }
    if parcel.zone == "international" {
        surcharge_cents += international_surcharge(base_cents);
    }
    let total_cents = base_cents + surcharge_cents;

    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    struct EnvGuard {
        _lock: std::sync::MutexGuard<'static, ()>,
        _file: Option<NamedTempFile>,
    }

    fn set_ratecard(contents: &str) -> EnvGuard {
        let lock = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let mut file = NamedTempFile::new().expect("create temp file");
        file.write_all(contents.as_bytes()).expect("write temp");
        std::env::set_var("RATECARD_PATH", file.path());
        EnvGuard {
            _lock: lock,
            _file: Some(file),
        }
    }

    fn clear_ratecard() -> EnvGuard {
        let lock = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        std::env::remove_var("RATECARD_PATH");
        EnvGuard {
            _lock: lock,
            _file: None,
        }
    }

    fn set_ratecard_path(path: &str) -> EnvGuard {
        let lock = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        std::env::set_var("RATECARD_PATH", path);
        EnvGuard {
            _lock: lock,
            _file: None,
        }
    }

    const SAMPLE: &str = "# zone\tband_max_grams\tcents\n\
        domestic\t500\t599\n\
        domestic\t2000\t899\n\
        domestic\t20000\t1799\n\
        international\t500\t1499\n\
        international\t20000\t4999\n";

    #[test]
    fn picks_first_band_meeting_weight() {
        let _g = set_ratecard(SAMPLE);
        let q = quote(&Parcel {
            weight_grams: 250,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn weight_equal_to_band_ceiling_takes_that_band() {
        let _g = set_ratecard(SAMPLE);
        let q = quote(&Parcel {
            weight_grams: 500,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn weight_over_10000_adds_heavy_surcharge() {
        let _g = set_ratecard(SAMPLE);
        let q = quote(&Parcel {
            weight_grams: 15_000,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20_000);
    }

    #[test]
    fn weight_exactly_10000_does_not_add_heavy_surcharge() {
        let _g = set_ratecard(SAMPLE);
        let q = quote(&Parcel {
            weight_grams: 10_000,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_20_percent_surcharge() {
        let _g = set_ratecard(SAMPLE);
        let q = quote(&Parcel {
            weight_grams: 300,
            zone: "international".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 1499);
        // 20% of 1499 = 299.8 → 300 half-up
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_and_heavy_stack() {
        let _g = set_ratecard(SAMPLE);
        let q = quote(&Parcel {
            weight_grams: 15_000,
            zone: "international".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 4999);
        // 20% of 4999 = 999.8 → 1000 half-up; plus 500 heavy
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn half_up_rounding_at_exact_half_cent() {
        // Contrive a base where 20% ends in .5 exactly: base=5 → 20% = 1.0 (no half).
        // base = 25 → 5.0. base=7 → 1.4. base=15 → 3.0. Try base=125 → 25.0.
        // We need cents * 20 % 100 == 50, i.e. cents % 5 == ? cents=5 → 100 % 100 = 0.
        // Actually cents * 20 % 100 = (cents % 5) * 20; = 50 when cents % 5 == 2.5 impossible.
        // So exact half never occurs when cents is integer — half-up simplifies but is still correct.
        // Instead verify a rounding-up boundary: base=3 → 20% = 0.6 → 1.
        let card = "international\t100\t3\n";
        let _g = set_ratecard(card);
        let q = quote(&Parcel {
            weight_grams: 50,
            zone: "international".into(),
        })
        .unwrap();
        assert_eq!(q.surcharge_cents, 1);
    }

    #[test]
    fn overweight_reports_largest_band() {
        let _g = set_ratecard(SAMPLE);
        let err = quote(&Parcel {
            weight_grams: 25_000,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000
            }
        );
    }

    #[test]
    fn unknown_zone_carries_requested_zone() {
        let _g = set_ratecard(SAMPLE);
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "moon".into(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("moon".into()));
    }

    #[test]
    fn missing_env_var_is_unavailable() {
        let _g = clear_ratecard();
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn missing_file_is_unavailable() {
        let _g = set_ratecard_path("/nonexistent/path/ratecard.tsv");
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
    }

    #[test]
    fn malformed_two_fields_reports_1_based_line() {
        // Line 1 is a comment; line 2 blank; line 3 has two fields.
        let card = "# header\n\ndomestic\t500\n";
        let _g = set_ratecard(card);
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 3 });
    }

    #[test]
    fn malformed_bad_number_reports_line() {
        let card = "domestic\t500\t599\ndomestic\ttwenty\t899\n";
        let _g = set_ratecard(card);
        let err = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 2 });
    }

    #[test]
    fn comments_and_blank_lines_are_skipped() {
        let card = "# header line\n\
            \n\
            domestic\t500\t599\n\
            # another comment\n\
            domestic\t2000\t899\n";
        let _g = set_ratecard(card);
        let q = quote(&Parcel {
            weight_grams: 1500,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn bands_are_sorted_regardless_of_file_order() {
        let card = "domestic\t20000\t1799\ndomestic\t500\t599\ndomestic\t2000\t899\n";
        let _g = set_ratecard(card);
        let q = quote(&Parcel {
            weight_grams: 400,
            zone: "domestic".into(),
        })
        .unwrap();
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn display_and_error_traits() {
        let e: Box<dyn std::error::Error> = Box::new(QuoteError::UnknownZone("mars".into()));
        assert!(format!("{}", e).contains("mars"));
    }
}
