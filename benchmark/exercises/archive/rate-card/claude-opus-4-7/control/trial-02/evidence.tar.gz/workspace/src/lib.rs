use std::env;
use std::fmt;
use std::fs;

pub mod zones;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card is unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {}", zone)
            }
            QuoteError::Overweight { grams, limit } => {
                write!(
                    f,
                    "parcel weight {} grams exceeds zone limit of {} grams",
                    grams, limit
                )
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    band_max_grams: u32,
    cents: u64,
}

fn load_bands(zone: &str) -> Result<Vec<Band>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    if path.is_empty() {
        return Err(QuoteError::RateCardUnavailable);
    }
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut zone_seen = false;
    let mut bands: Vec<Band> = Vec::new();

    for (idx, raw_line) in contents.lines().enumerate() {
        let line_no = idx + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = raw_line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }
        let row_zone = parts[0];
        let band_max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;

        if row_zone == zone {
            zone_seen = true;
            bands.push(Band {
                band_max_grams,
                cents,
            });
        }
    }

    if !zone_seen {
        return Err(QuoteError::UnknownZone(zone.to_string()));
    }

    bands.sort_by_key(|b| b.band_max_grams);
    Ok(bands)
}

fn international_surcharge(base_cents: u64) -> u64 {
    // 20% of base_cents, rounded half-up to the cent.
    (base_cents * 20 + 50) / 100
}

fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!(
        "ratecard.quote zone={} weight_grams={} total_cents={}",
        zone, weight_grams, total_cents
    );
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_bands(&parcel.zone)?;

    let largest = bands
        .last()
        .expect("zone with no bands should have surfaced UnknownZone");
    if parcel.weight_grams > largest.band_max_grams {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest.band_max_grams,
        });
    }

    let band = bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .expect("overweight case already handled");

    let base_cents = band.cents;
    let band_max_grams = band.band_max_grams;

    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += international_surcharge(base_cents);
    }

    let total_cents = base_cents + surcharge_cents;

    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    // Serialise tests: RATECARD_PATH is process-global.
    static ENV_LOCK: Mutex<()> = Mutex::new(());

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn write_card(contents: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().expect("create temp file");
        file.write_all(contents.as_bytes()).expect("write card");
        file
    }

    fn with_card<F: FnOnce()>(contents: &str, body: F) {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let file = write_card(contents);
        env::set_var("RATECARD_PATH", file.path());
        body();
        env::remove_var("RATECARD_PATH");
    }

    #[test]
    fn domestic_small_parcel_uses_first_band() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 250,
                zone: "domestic".into(),
            })
            .expect("quote ok");
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_boundary_takes_that_band() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            })
            .expect("quote ok");
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn domestic_next_band_up() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            })
            .expect("quote ok");
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 899);
        });
    }

    #[test]
    fn heavy_domestic_adds_overweight_surcharge() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 10_001,
                zone: "domestic".into(),
            })
            .expect("quote ok");
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.band_max_grams, 20000);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
        });
    }

    #[test]
    fn exactly_10000_grams_does_not_add_surcharge() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 10_000,
                zone: "domestic".into(),
            })
            .expect("quote ok");
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_adds_twenty_percent() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 300,
                zone: "international".into(),
            })
            .expect("quote ok");
            assert_eq!(q.base_cents, 1499);
            // 20% of 1499 = 299.8 → 300 half-up
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn international_heavy_stacks_both_surcharges() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 15_000,
                zone: "international".into(),
            })
            .expect("quote ok");
            assert_eq!(q.base_cents, 4999);
            // 20% of 4999 = 999.8 → 1000; + 500 overweight
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
            assert_eq!(q.band_max_grams, 20000);
        });
    }

    #[test]
    fn unknown_zone_returns_error_carrying_zone() {
        with_card(SAMPLE, || {
            match quote(&Parcel {
                weight_grams: 100,
                zone: "lunar".into(),
            }) {
                Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "lunar"),
                other => panic!("expected UnknownZone, got {:?}", other),
            }
        });
    }

    #[test]
    fn overweight_returns_error_with_zone_limit() {
        with_card(SAMPLE, || {
            match quote(&Parcel {
                weight_grams: 25_000,
                zone: "domestic".into(),
            }) {
                Err(QuoteError::Overweight { grams, limit }) => {
                    assert_eq!(grams, 25_000);
                    assert_eq!(limit, 20_000);
                }
                other => panic!("expected Overweight, got {:?}", other),
            }
        });
    }

    #[test]
    fn missing_env_var_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        env::remove_var("RATECARD_PATH");
        match quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        }) {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected RateCardUnavailable, got {:?}", other),
        }
    }

    #[test]
    fn missing_file_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        env::set_var("RATECARD_PATH", "/nonexistent/path/does/not/exist.tsv");
        let result = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        });
        env::remove_var("RATECARD_PATH");
        match result {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected RateCardUnavailable, got {:?}", other),
        }
    }

    #[test]
    fn malformed_field_count_reports_line_number() {
        let bad = "# header\n\ndomestic\t500\n";
        with_card(bad, || {
            match quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            }) {
                Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
                other => panic!("expected MalformedRateCard, got {:?}", other),
            }
        });
    }

    #[test]
    fn malformed_number_reports_line_number_counting_all_lines() {
        let bad = "# header\n\n\ndomestic\tabc\t599\n";
        with_card(bad, || {
            match quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            }) {
                Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 4),
                other => panic!("expected MalformedRateCard, got {:?}", other),
            }
        });
    }

    #[test]
    fn comments_and_blank_lines_are_ignored() {
        let card = "\
#\tzone\tband_max_grams\tcents

domestic\t500\t599

# another comment
domestic\t2000\t899
";
        with_card(card, || {
            let q = quote(&Parcel {
                weight_grams: 800,
                zone: "domestic".into(),
            })
            .expect("quote ok");
            assert_eq!(q.base_cents, 899);
            assert_eq!(q.band_max_grams, 2000);
        });
    }

    #[test]
    fn display_and_error_traits_present() {
        fn assert_error<E: std::error::Error>(_: &E) {}
        let e = QuoteError::UnknownZone("lunar".into());
        assert_error(&e);
        let text = format!("{}", e);
        assert!(text.contains("lunar"));
    }
}
