use std::env;
use std::fmt;
use std::fs;

pub mod zones;

pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => write!(f, "rate card unavailable"),
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => write!(f, "unknown zone: {}", zone),
            QuoteError::Overweight { grams, limit } => {
                write!(f, "parcel weight {} g exceeds zone limit {} g", grams, limit)
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

fn load_rate_card() -> Result<Vec<(String, Band)>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    if path.is_empty() {
        return Err(QuoteError::RateCardUnavailable);
    }
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let mut bands = Vec::new();
    for (idx, line) in contents.lines().enumerate() {
        let line_no = idx + 1;
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }
        let zone = fields[0].to_string();
        let max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        bands.push((zone, Band { max_grams, cents }));
    }
    Ok(bands)
}

fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!(
        "ratecard.quote zone={} weight_grams={} total_cents={}",
        zone, weight_grams, total_cents
    );
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_rate_card()?;

    let mut zone_bands: Vec<&Band> = bands
        .iter()
        .filter(|(z, _)| z == &parcel.zone)
        .map(|(_, b)| b)
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.max_grams);

    let largest = zone_bands.last().unwrap().max_grams;
    if parcel.weight_grams > largest {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest,
        });
    }

    let band = zone_bands
        .iter()
        .find(|b| b.max_grams >= parcel.weight_grams)
        .unwrap();

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        // 20% of base_cents, half-up to the cent.
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }
    let total_cents = base_cents + surcharge_cents;

    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    // RATECARD_PATH is process-global; serialize env-var access across tests.
    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn lock() -> std::sync::MutexGuard<'static, ()> {
        ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner())
    }

    const STANDARD_CARD: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn write_card(contents: &str) -> NamedTempFile {
        let mut f = NamedTempFile::new().unwrap();
        f.write_all(contents.as_bytes()).unwrap();
        f.flush().unwrap();
        f
    }

    #[test]
    fn domestic_first_band() {
        let _g = lock();
        let card = write_card(STANDARD_CARD);
        env::set_var("RATECARD_PATH", card.path());
        let q = quote(&Parcel { weight_grams: 250, zone: "domestic".into() }).unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn domestic_exact_band_boundary_matches_that_band() {
        let _g = lock();
        let card = write_card(STANDARD_CARD);
        env::set_var("RATECARD_PATH", card.path());
        let q = quote(&Parcel { weight_grams: 500, zone: "domestic".into() }).unwrap();
        assert_eq!(q.band_max_grams, 500);
        assert_eq!(q.base_cents, 599);
    }

    #[test]
    fn domestic_promotes_to_next_band() {
        let _g = lock();
        let card = write_card(STANDARD_CARD);
        env::set_var("RATECARD_PATH", card.path());
        let q = quote(&Parcel { weight_grams: 501, zone: "domestic".into() }).unwrap();
        assert_eq!(q.band_max_grams, 2000);
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 899);
    }

    #[test]
    fn heavy_domestic_adds_overweight_surcharge() {
        let _g = lock();
        let card = write_card(STANDARD_CARD);
        env::set_var("RATECARD_PATH", card.path());
        let q = quote(&Parcel { weight_grams: 15_000, zone: "domestic".into() }).unwrap();
        assert_eq!(q.band_max_grams, 20_000);
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
    }

    #[test]
    fn overweight_threshold_is_strict() {
        let _g = lock();
        let card = write_card(STANDARD_CARD);
        env::set_var("RATECARD_PATH", card.path());
        // exactly 10000g must not attract the heavy surcharge.
        let q = quote(&Parcel { weight_grams: 10_000, zone: "domestic".into() }).unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn international_adds_twenty_percent_half_up() {
        let _g = lock();
        let card = write_card(STANDARD_CARD);
        env::set_var("RATECARD_PATH", card.path());
        // 1499 * 0.20 = 299.8 -> rounds to 300
        let q = quote(&Parcel { weight_grams: 400, zone: "international".into() }).unwrap();
        assert_eq!(q.base_cents, 1499);
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
    }

    #[test]
    fn international_heavy_stacks_both_surcharges() {
        let _g = lock();
        let card = write_card(STANDARD_CARD);
        env::set_var("RATECARD_PATH", card.path());
        // 4999 * 0.20 = 999.8 -> 1000; plus 500 overweight = 1500 surcharge
        let q = quote(&Parcel { weight_grams: 15_000, zone: "international".into() }).unwrap();
        assert_eq!(q.base_cents, 4999);
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
        assert_eq!(q.band_max_grams, 20_000);
    }

    #[test]
    fn unknown_zone_returns_error_with_requested_zone() {
        let _g = lock();
        let card = write_card(STANDARD_CARD);
        env::set_var("RATECARD_PATH", card.path());
        let err = quote(&Parcel { weight_grams: 100, zone: "lunar".into() }).unwrap_err();
        match err {
            QuoteError::UnknownZone(z) => assert_eq!(z, "lunar"),
            other => panic!("expected UnknownZone, got {:?}", other),
        }
    }

    #[test]
    fn overweight_reports_zone_limit() {
        let _g = lock();
        let card = write_card(STANDARD_CARD);
        env::set_var("RATECARD_PATH", card.path());
        let err = quote(&Parcel { weight_grams: 25_000, zone: "domestic".into() }).unwrap_err();
        match err {
            QuoteError::Overweight { grams, limit } => {
                assert_eq!(grams, 25_000);
                assert_eq!(limit, 20_000);
            }
            other => panic!("expected Overweight, got {:?}", other),
        }
    }

    #[test]
    fn unset_env_var_is_unavailable() {
        let _g = lock();
        env::remove_var("RATECARD_PATH");
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn missing_file_is_unavailable() {
        let _g = lock();
        env::set_var("RATECARD_PATH", "/nonexistent/path/should-not-exist.tsv");
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        assert!(matches!(err, QuoteError::RateCardUnavailable));
    }

    #[test]
    fn malformed_field_count_reports_1_based_line_including_comments() {
        let _g = lock();
        // line 1: comment; line 2: valid; line 3: blank; line 4: malformed (2 fields)
        let bad = "# header\ndomestic\t500\t599\n\ndomestic\tbroken\n";
        let card = write_card(bad);
        env::set_var("RATECARD_PATH", card.path());
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 4),
            other => panic!("expected MalformedRateCard, got {:?}", other),
        }
    }

    #[test]
    fn malformed_number_reports_line() {
        let _g = lock();
        // line 1: valid; line 2: bad max_grams
        let bad = "domestic\t500\t599\ndomestic\tNOT_A_NUMBER\t899\n";
        let card = write_card(bad);
        env::set_var("RATECARD_PATH", card.path());
        let err = quote(&Parcel { weight_grams: 100, zone: "domestic".into() }).unwrap_err();
        match err {
            QuoteError::MalformedRateCard { line } => assert_eq!(line, 2),
            other => panic!("expected MalformedRateCard, got {:?}", other),
        }
    }

    #[test]
    fn display_and_error_traits_wire_up() {
        let e: Box<dyn std::error::Error> = Box::new(QuoteError::UnknownZone("mars".into()));
        assert_eq!(format!("{}", e), "unknown zone: mars");
    }
}
