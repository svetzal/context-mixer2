use std::env;
use std::error::Error;
use std::fmt;
use std::fs;

pub mod zones;

#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {}", zone)
            }
            QuoteError::Overweight { grams, limit } => write!(
                f,
                "parcel weight {} grams exceeds zone limit of {} grams",
                grams, limit
            ),
        }
    }
}

impl Error for QuoteError {}

struct Band {
    max_grams: u32,
    cents: u64,
}

fn load_rate_card(path: &str) -> Result<Vec<(String, Band)>, QuoteError> {
    let contents = fs::read_to_string(path).map_err(|_| QuoteError::RateCardUnavailable)?;
    let mut bands: Vec<(String, Band)> = Vec::new();
    for (idx, line) in contents.lines().enumerate() {
        let line_number = idx + 1;
        if line.trim().is_empty() || line.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_number });
        }
        let zone = parts[0].to_string();
        let max_grams: u32 = parts[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        let cents: u64 = parts[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_number })?;
        bands.push((zone, Band { max_grams, cents }));
    }
    Ok(bands)
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    let bands = load_rate_card(&path)?;

    let mut zone_bands: Vec<&Band> = bands
        .iter()
        .filter(|(z, _)| z == &parcel.zone)
        .map(|(_, b)| b)
        .collect();

    if zone_bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    zone_bands.sort_by_key(|b| b.max_grams);

    let max_limit = zone_bands.last().unwrap().max_grams;

    let band = match zone_bands.iter().find(|b| b.max_grams >= parcel.weight_grams) {
        Some(b) => *b,
        None => {
            return Err(QuoteError::Overweight {
                grams: parcel.weight_grams,
                limit: max_limit,
            });
        }
    };

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += (base_cents * 20 + 50) / 100;
    }
    let total_cents = base_cents + surcharge_cents;

    eprintln!(
        "quote zone={} weight_grams={} total_cents={}",
        parcel.zone, parcel.weight_grams, total_cents
    );

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn write_ratecard(content: &str) -> NamedTempFile {
        let mut f = NamedTempFile::new().unwrap();
        f.write_all(content.as_bytes()).unwrap();
        f.flush().unwrap();
        f
    }

    fn with_ratecard<T>(content: &str, f: impl FnOnce() -> T) -> T {
        let guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let file = write_ratecard(content);
        env::set_var("RATECARD_PATH", file.path());
        let out = f();
        env::remove_var("RATECARD_PATH");
        drop(guard);
        out
    }

    #[test]
    fn small_domestic_parcel() {
        let q = with_ratecard(SAMPLE, || {
            quote(&Parcel {
                weight_grams: 300,
                zone: "domestic".into(),
            })
        })
        .unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.surcharge_cents, 0);
        assert_eq!(q.total_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn boundary_matches_band_at_exact_weight() {
        let q = with_ratecard(SAMPLE, || {
            quote(&Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            })
        })
        .unwrap();
        assert_eq!(q.base_cents, 599);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn spills_into_next_band() {
        let q = with_ratecard(SAMPLE, || {
            quote(&Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            })
        })
        .unwrap();
        assert_eq!(q.base_cents, 899);
        assert_eq!(q.band_max_grams, 2000);
    }

    #[test]
    fn heavy_domestic_adds_flat_surcharge() {
        let q = with_ratecard(SAMPLE, || {
            quote(&Parcel {
                weight_grams: 15_000,
                zone: "domestic".into(),
            })
        })
        .unwrap();
        assert_eq!(q.base_cents, 1799);
        assert_eq!(q.surcharge_cents, 500);
        assert_eq!(q.total_cents, 2299);
        assert_eq!(q.band_max_grams, 20_000);
    }

    #[test]
    fn no_flat_surcharge_at_exactly_10000() {
        let q = with_ratecard(SAMPLE, || {
            quote(&Parcel {
                weight_grams: 10_000,
                zone: "domestic".into(),
            })
        })
        .unwrap();
        assert_eq!(q.surcharge_cents, 0);
    }

    #[test]
    fn international_percentage_surcharge_rounds_half_up() {
        let q = with_ratecard(SAMPLE, || {
            quote(&Parcel {
                weight_grams: 300,
                zone: "international".into(),
            })
        })
        .unwrap();
        assert_eq!(q.base_cents, 1499);
        // 20% of 1499 = 299.8 -> 300
        assert_eq!(q.surcharge_cents, 300);
        assert_eq!(q.total_cents, 1799);
        assert_eq!(q.band_max_grams, 500);
    }

    #[test]
    fn international_heavy_stacks_both_surcharges() {
        let q = with_ratecard(SAMPLE, || {
            quote(&Parcel {
                weight_grams: 15_000,
                zone: "international".into(),
            })
        })
        .unwrap();
        assert_eq!(q.base_cents, 4999);
        // 20% of 4999 = 999.8 -> 1000; plus 500 flat = 1500
        assert_eq!(q.surcharge_cents, 1500);
        assert_eq!(q.total_cents, 6499);
    }

    #[test]
    fn unknown_zone_reports_requested_zone() {
        let err = with_ratecard(SAMPLE, || {
            quote(&Parcel {
                weight_grams: 300,
                zone: "lunar".into(),
            })
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::UnknownZone("lunar".into()));
    }

    #[test]
    fn overweight_reports_zone_limit() {
        let err = with_ratecard(SAMPLE, || {
            quote(&Parcel {
                weight_grams: 25_000,
                zone: "domestic".into(),
            })
        })
        .unwrap_err();
        assert_eq!(
            err,
            QuoteError::Overweight {
                grams: 25_000,
                limit: 20_000
            }
        );
    }

    #[test]
    fn missing_env_var_is_unavailable() {
        let guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        env::remove_var("RATECARD_PATH");
        let err = quote(&Parcel {
            weight_grams: 300,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
        drop(guard);
    }

    #[test]
    fn unreadable_path_is_unavailable() {
        let guard = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        env::set_var("RATECARD_PATH", "/definitely/not/a/real/path/for/tests");
        let err = quote(&Parcel {
            weight_grams: 300,
            zone: "domestic".into(),
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::RateCardUnavailable);
        env::remove_var("RATECARD_PATH");
        drop(guard);
    }

    #[test]
    fn malformed_line_number_counts_comments_and_blanks() {
        // 1: comment, 2: blank, 3: valid, 4: bad number of fields
        let content = "# header\n\ndomestic\t500\t599\nnotavalidline\n";
        let err = with_ratecard(content, || {
            quote(&Parcel {
                weight_grams: 300,
                zone: "domestic".into(),
            })
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 4 });
    }

    #[test]
    fn malformed_when_number_does_not_parse() {
        let content = "domestic\tabc\t599\n";
        let err = with_ratecard(content, || {
            quote(&Parcel {
                weight_grams: 300,
                zone: "domestic".into(),
            })
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn malformed_when_cents_does_not_parse() {
        let content = "domestic\t500\tnope\n";
        let err = with_ratecard(content, || {
            quote(&Parcel {
                weight_grams: 300,
                zone: "domestic".into(),
            })
        })
        .unwrap_err();
        assert_eq!(err, QuoteError::MalformedRateCard { line: 1 });
    }

    #[test]
    fn quote_error_is_a_std_error() {
        let boxed: Box<dyn Error> = Box::new(QuoteError::RateCardUnavailable);
        assert_eq!(boxed.to_string(), "rate card unavailable");
        let d = QuoteError::MalformedRateCard { line: 7 };
        assert_eq!(d.to_string(), "malformed rate card at line 7");
        let u = QuoteError::UnknownZone("lunar".into());
        assert_eq!(u.to_string(), "unknown zone: lunar");
        let o = QuoteError::Overweight {
            grams: 25_000,
            limit: 20_000,
        };
        assert_eq!(
            o.to_string(),
            "parcel weight 25000 grams exceeds zone limit of 20000 grams"
        );
    }
}
