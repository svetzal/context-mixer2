pub mod zones;

use std::env;
use std::fmt;
use std::fs;

#[derive(Debug, Clone)]
pub struct Parcel {
    pub weight_grams: u32,
    pub zone: String,
}

#[derive(Debug, Clone)]
pub struct Quote {
    pub base_cents: u64,
    pub surcharge_cents: u64,
    pub total_cents: u64,
    pub band_max_grams: u32,
}

#[derive(Debug)]
pub enum QuoteError {
    RateCardUnavailable,
    MalformedRateCard { line: usize },
    UnknownZone(String),
    Overweight { grams: u32, limit: u32 },
}

impl fmt::Display for QuoteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            QuoteError::RateCardUnavailable => {
                write!(f, "rate card is unavailable")
            }
            QuoteError::MalformedRateCard { line } => {
                write!(f, "malformed rate card at line {}", line)
            }
            QuoteError::UnknownZone(zone) => {
                write!(f, "unknown zone: {}", zone)
            }
            QuoteError::Overweight { grams, limit } => {
                write!(
                    f,
                    "parcel weight {} grams exceeds limit of {} grams",
                    grams, limit
                )
            }
        }
    }
}

impl std::error::Error for QuoteError {}

struct Band {
    band_max_grams: u32,
    cents: u64,
}

fn load_bands(zone: &str) -> Result<Vec<Band>, QuoteError> {
    let path = env::var("RATECARD_PATH").map_err(|_| QuoteError::RateCardUnavailable)?;
    if path.is_empty() {
        return Err(QuoteError::RateCardUnavailable);
    }
    let contents = fs::read_to_string(&path).map_err(|_| QuoteError::RateCardUnavailable)?;

    let mut bands: Vec<Band> = Vec::new();
    for (idx, raw_line) in contents.lines().enumerate() {
        let line_no = idx + 1;
        let trimmed = raw_line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let fields: Vec<&str> = raw_line.split('\t').collect();
        if fields.len() != 3 {
            return Err(QuoteError::MalformedRateCard { line: line_no });
        }
        let row_zone = fields[0];
        let band_max_grams: u32 = fields[1]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        let cents: u64 = fields[2]
            .parse()
            .map_err(|_| QuoteError::MalformedRateCard { line: line_no })?;
        if row_zone == zone {
            bands.push(Band {
                band_max_grams,
                cents,
            });
        }
    }

    bands.sort_by_key(|b| b.band_max_grams);
    Ok(bands)
}

fn international_surcharge(base_cents: u64) -> u64 {
    (base_cents * 20 + 50) / 100
}

fn emit_diagnostic(zone: &str, weight_grams: u32, total_cents: u64) {
    eprintln!(
        "ratecard.quote zone={} weight_grams={} total_cents={}",
        zone, weight_grams, total_cents
    );
}

pub fn quote(parcel: &Parcel) -> Result<Quote, QuoteError> {
    let bands = load_bands(&parcel.zone)?;
    if bands.is_empty() {
        return Err(QuoteError::UnknownZone(parcel.zone.clone()));
    }

    let largest = bands.last().expect("bands non-empty").band_max_grams;
    if parcel.weight_grams > largest {
        return Err(QuoteError::Overweight {
            grams: parcel.weight_grams,
            limit: largest,
        });
    }

    let band = bands
        .iter()
        .find(|b| b.band_max_grams >= parcel.weight_grams)
        .expect("band exists since weight <= largest");

    let base_cents = band.cents;
    let mut surcharge_cents: u64 = 0;
    if parcel.weight_grams > 10_000 {
        surcharge_cents += 500;
    }
    if parcel.zone == "international" {
        surcharge_cents += international_surcharge(base_cents);
    }
    let total_cents = base_cents + surcharge_cents;

    emit_diagnostic(&parcel.zone, parcel.weight_grams, total_cents);

    Ok(Quote {
        base_cents,
        surcharge_cents,
        total_cents,
        band_max_grams: band.band_max_grams,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::sync::Mutex;
    use tempfile::NamedTempFile;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    const SAMPLE: &str = "\
# zone\tband_max_grams\tcents
domestic\t500\t599
domestic\t2000\t899
domestic\t20000\t1799
international\t500\t1499
international\t20000\t4999
";

    fn write_card(contents: &str) -> NamedTempFile {
        let mut file = NamedTempFile::new().expect("tempfile");
        file.write_all(contents.as_bytes()).expect("write");
        file
    }

    fn with_card<F, R>(contents: &str, f: F) -> R
    where
        F: FnOnce() -> R,
    {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|p| p.into_inner());
        let file = write_card(contents);
        env::set_var("RATECARD_PATH", file.path());
        let result = f();
        env::remove_var("RATECARD_PATH");
        result
    }

    #[test]
    fn matches_first_band_by_weight() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 250,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 599);
            assert_eq!(q.surcharge_cents, 0);
            assert_eq!(q.total_cents, 599);
            assert_eq!(q.band_max_grams, 500);
        });
    }

    #[test]
    fn matches_exact_band_boundary() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 500,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(q.band_max_grams, 500);
            assert_eq!(q.base_cents, 599);
        });
    }

    #[test]
    fn steps_up_to_next_band() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 501,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(q.band_max_grams, 2000);
            assert_eq!(q.base_cents, 899);
        });
    }

    #[test]
    fn heavy_weight_adds_flat_surcharge() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 15_000,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 1799);
            assert_eq!(q.surcharge_cents, 500);
            assert_eq!(q.total_cents, 2299);
            assert_eq!(q.band_max_grams, 20_000);
        });
    }

    #[test]
    fn boundary_at_10000_does_not_add_surcharge() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 10_000,
                zone: "domestic".into(),
            })
            .unwrap();
            assert_eq!(q.surcharge_cents, 0);
        });
    }

    #[test]
    fn international_adds_20_percent_surcharge() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 400,
                zone: "international".into(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 1499);
            // 20% of 1499 = 299.8 -> half-up = 300
            assert_eq!(q.surcharge_cents, 300);
            assert_eq!(q.total_cents, 1799);
        });
    }

    #[test]
    fn international_heavy_stacks_both_surcharges() {
        with_card(SAMPLE, || {
            let q = quote(&Parcel {
                weight_grams: 15_000,
                zone: "international".into(),
            })
            .unwrap();
            assert_eq!(q.base_cents, 4999);
            // 20% of 4999 = 999.8 -> 1000, plus 500 flat = 1500
            assert_eq!(q.surcharge_cents, 1500);
            assert_eq!(q.total_cents, 6499);
        });
    }

    #[test]
    fn unknown_zone_reports_zone() {
        with_card(SAMPLE, || {
            match quote(&Parcel {
                weight_grams: 100,
                zone: "lunar".into(),
            }) {
                Err(QuoteError::UnknownZone(z)) => assert_eq!(z, "lunar"),
                other => panic!("expected UnknownZone, got {:?}", other),
            }
        });
    }

    #[test]
    fn overweight_reports_limit() {
        with_card(SAMPLE, || {
            match quote(&Parcel {
                weight_grams: 25_000,
                zone: "domestic".into(),
            }) {
                Err(QuoteError::Overweight { grams, limit }) => {
                    assert_eq!(grams, 25_000);
                    assert_eq!(limit, 20_000);
                }
                other => panic!("expected Overweight, got {:?}", other),
            }
        });
    }

    #[test]
    fn missing_env_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|p| p.into_inner());
        env::remove_var("RATECARD_PATH");
        match quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        }) {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected RateCardUnavailable, got {:?}", other),
        }
    }

    #[test]
    fn unreadable_path_is_unavailable() {
        let _guard = ENV_LOCK.lock().unwrap_or_else(|p| p.into_inner());
        env::set_var("RATECARD_PATH", "/nonexistent/path/to/nowhere.tsv");
        let result = quote(&Parcel {
            weight_grams: 100,
            zone: "domestic".into(),
        });
        env::remove_var("RATECARD_PATH");
        match result {
            Err(QuoteError::RateCardUnavailable) => {}
            other => panic!("expected RateCardUnavailable, got {:?}", other),
        }
    }

    #[test]
    fn malformed_line_reports_1_based_line_number() {
        let bad = "\
# header
domestic\t500\t599
domestic\ttwo-thousand\t899
";
        with_card(bad, || {
            match quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            }) {
                Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 3),
                other => panic!("expected MalformedRateCard, got {:?}", other),
            }
        });
    }

    #[test]
    fn malformed_field_count_reports_line() {
        let bad = "\
domestic\t500\t599
domestic\t2000
";
        with_card(bad, || {
            match quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            }) {
                Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 2),
                other => panic!("expected MalformedRateCard, got {:?}", other),
            }
        });
    }

    #[test]
    fn comments_and_blanks_count_toward_line_numbers() {
        let card = "\
# header comment

domestic\t500\t599
# another comment
domestic\tbad\t899
";
        with_card(card, || {
            match quote(&Parcel {
                weight_grams: 100,
                zone: "domestic".into(),
            }) {
                Err(QuoteError::MalformedRateCard { line }) => assert_eq!(line, 5),
                other => panic!("expected MalformedRateCard, got {:?}", other),
            }
        });
    }

    #[test]
    fn display_and_error_impls_present() {
        let e = QuoteError::UnknownZone("mars".into());
        let _s: String = format!("{}", e);
        fn assert_error<E: std::error::Error>(_: &E) {}
        assert_error(&e);
    }
}
