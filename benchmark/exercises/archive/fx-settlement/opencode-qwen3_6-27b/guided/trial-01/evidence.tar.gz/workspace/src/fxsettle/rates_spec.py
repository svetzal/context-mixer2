"""Specification for the rates gateway."""

import json
import os
from decimal import Decimal
from unittest.mock import MagicMock, patch

import httpx
import pytest

from .exceptions import RateUnavailable, UnknownCurrencyPair
from .rates import fetch_rate


def _mock_response(status_code, response_text):
    mock = MagicMock()
    mock.status_code = status_code
    mock.json.return_value = json.loads(response_text) if isinstance(response_text, str) and status_code == 200 else None
    return mock


class DescribeFetchRate:

    class when_env_var_not_set:

        def should_raise_rate_unavailable(self):
            env = os.environ.copy()
            env.pop("FXSETTLE_RATES_URL", None)
            with patch.dict(os.environ, env, clear=True):
                with pytest.raises(RateUnavailable):
                    fetch_rate("USD", "CAD")

    class when_transport_fails:

        def should_raise_rate_unavailable(self):
            with patch.dict(os.environ, {"FXSETTLE_RATES_URL": "https://rates.example.com"}):
                with patch("httpx.get", side_effect=httpx.TransportError("connection refused")):
                    with pytest.raises(RateUnavailable):
                        fetch_rate("USD", "CAD")

    class when_server_returns_404:

        def should_raise_unknown_currency_pair(self):
            with patch.dict(os.environ, {"FXSETTLE_RATES_URL": "https://rates.example.com"}):
                mock_resp = MagicMock()
                mock_resp.status_code = 404
                with patch("httpx.get", return_value=mock_resp):
                    with pytest.raises(UnknownCurrencyPair):
                        fetch_rate("USD", "XYZ")

    class when_server_returns_500:

        def should_raise_rate_unavailable(self):
            with patch.dict(os.environ, {"FXSETTLE_RATES_URL": "https://rates.example.com"}):
                mock_resp = MagicMock()
                mock_resp.status_code = 500
                with patch("httpx.get", return_value=mock_resp):
                    with pytest.raises(RateUnavailable):
                        fetch_rate("USD", "CAD")

    class when_response_is_not_json:

        def should_raise_rate_unavailable(self):
            with patch.dict(os.environ, {"FXSETTLE_RATES_URL": "https://rates.example.com"}):
                mock_resp = MagicMock()
                mock_resp.status_code = 200
                mock_resp.json.side_effect = json.JSONDecodeError("test", "doc", 0)
                with patch("httpx.get", return_value=mock_resp):
                    with pytest.raises(RateUnavailable):
                        fetch_rate("USD", "CAD")

    class when_response_missing_rate_field:

        def should_raise_rate_unavailable(self):
            with patch.dict(os.environ, {"FXSETTLE_RATES_URL": "https://rates.example.com"}):
                mock_resp = MagicMock()
                mock_resp.status_code = 200
                mock_resp.json.return_value = {"base": "USD", "quote": "CAD"}
                with patch("httpx.get", return_value=mock_resp):
                    with pytest.raises(RateUnavailable):
                        fetch_rate("USD", "CAD")

    class when_server_returns_valid_rate:

        def should_return_decimal_rate(self):
            with patch.dict(os.environ, {"FXSETTLE_RATES_URL": "https://rates.example.com"}):
                mock_resp = MagicMock()
                mock_resp.status_code = 200
                mock_resp.json.return_value = {
                    "base": "USD",
                    "quote": "CAD",
                    "rate": "1.3542",
                    "as_of": "2026-08-13",
                }
                with patch("httpx.get", return_value=mock_resp):
                    result = fetch_rate("USD", "CAD")

                    assert result == Decimal("1.3542")
