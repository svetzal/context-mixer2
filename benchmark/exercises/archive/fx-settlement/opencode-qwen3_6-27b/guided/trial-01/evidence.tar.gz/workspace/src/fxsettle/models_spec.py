"""Specification for settlement domain models."""

from decimal import Decimal

import pytest

from .exceptions import RateUnavailable, UnknownCurrencyPair
from .models import Invoice, Settlement


class DescribeInvoice:

    class when_constructed:

        def should_store_all_fields(self):
            invoice = Invoice(
                amount=Decimal("1000"),
                currency="USD",
                counterparty="Acme",
            )

            assert invoice.amount == Decimal("1000")
            assert invoice.currency == "USD"
            assert invoice.counterparty == "Acme"

        def should_reject_field_reassignment(self):
            invoice = Invoice(
                amount=Decimal("100"),
                currency="EUR",
                counterparty="Beta",
            )

            with pytest.raises(Exception):
                invoice.amount = Decimal("200")


class DescribeSettlement:

    class when_constructed:

        def should_store_all_fields(self):
            settlement = Settlement(
                gross=Decimal("1354.20"),
                fee=Decimal("20.31"),
                net=Decimal("1333.89"),
                rate=Decimal("1.3542"),
                base_currency="USD",
                quote_currency="CAD",
            )

            assert settlement.gross == Decimal("1354.20")
            assert settlement.fee == Decimal("20.31")
            assert settlement.net == Decimal("1333.89")
            assert settlement.rate == Decimal("1.3542")
            assert settlement.base_currency == "USD"
            assert settlement.quote_currency == "CAD"

        def should_reject_field_reassignment(self):
            settlement = Settlement(
                gross=Decimal("100"),
                fee=Decimal("5"),
                net=Decimal("95"),
                rate=Decimal("1"),
                base_currency="USD",
                quote_currency="USD",
            )

            with pytest.raises(Exception):
                settlement.gross = Decimal("200")


class DescribeExceptions:

    class when_raising_unknown_currency_pair:

        def should_be_a_catchable_exception(self):
            exc = UnknownCurrencyPair("no rate")
            assert isinstance(exc, Exception)

    class when_raising_rate_unavailable:

        def should_be_a_catchable_exception(self):
            exc = RateUnavailable("service down")
            assert isinstance(exc, Exception)

    class when_catching:

        def should_allow_independent_catching(self):
            try:
                raise UnknownCurrencyPair("test")
            except UnknownCurrencyPair:
                pass

            try:
                raise RateUnavailable("test")
            except RateUnavailable:
                pass

            assert True
