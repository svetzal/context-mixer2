"""Domain models for invoice settlement."""

from decimal import Decimal

from pydantic import BaseModel, ConfigDict


class Invoice(BaseModel):
    amount: Decimal
    currency: str
    counterparty: str

    model_config = ConfigDict(frozen=True)


class Settlement(BaseModel):
    gross: Decimal
    fee: Decimal
    net: Decimal
    rate: Decimal
    base_currency: str
    quote_currency: str

    model_config = ConfigDict(frozen=True)
