"""Specification for the settle function."""

from decimal import Decimal
from unittest.mock import patch

import pytest

from .exceptions import RateUnavailable, UnknownCurrencyPair
from .models import Invoice, Settlement
from .settlement import settle


class DescribeSettle:

    class when_currencies_match:

        class arrange:

            invoice = Invoice(
                amount=Decimal("500"),
                currency="USD",
                counterparty="Alpha",
            )

        def should_use_rate_of_1(self):
            result = settle(self.arrange.invoice, "USD")

            assert result.rate == Decimal("1")

        def should_not_call_rates_service(self):
            with patch("httpx.get") as mock_get:
                settle(self.arrange.invoice, "USD")

                mock_get.assert_not_called()

        def should_return_correct_settlement(self):
            result = settle(self.arrange.invoice, "USD")

            assert result.gross == Decimal("500.00")
            assert result.base_currency == "USD"
            assert result.quote_currency == "USD"

        def should_apply_fee_tier(self):
            result = settle(self.arrange.invoice, "USD")

            assert result.fee == (Decimal("500") * Decimal("0.025"))

    class when_gross_under_1000:

        invoice = Invoice(
            amount=Decimal("100"),
            currency="EUR",
            counterparty="Beta",
        )

        def should_use_2_5_percent_fee(self):
            with patch.dict("os.environ", {"FXSETTLE_RATES_URL": "https://rates.example.com"}):
                mock_resp = _make_rate_response("1.1000")
                with patch("httpx.get", return_value=mock_resp):
                    result = settle(self.invoice, "USD")

                    gross = Decimal("110.00")
                    expected_fee = gross * Decimal("0.025")
                    assert result.fee == expected_fee.quantize(Decimal("0.01"))

    class when_gross_between_1000_and_10000:

        invoice = Invoice(
            amount=Decimal("2000"),
            currency="EUR",
            counterparty="Gamma",
        )

        def should_use_1_5_percent_fee(self):
            with patch.dict("os.environ", {"FXSETTLE_RATES_URL": "https://rates.example.com"}):
                mock_resp = _make_rate_response("1.1000")
                with patch("httpx.get", return_value=mock_resp):
                    result = settle(self.invoice, "USD")

                    gross = Decimal("2200.00")
                    expected_fee = gross * Decimal("0.015")
                    assert result.fee == expected_fee.quantize(Decimal("0.01"))

    class when_gross_over_10000:

        invoice = Invoice(
            amount=Decimal("20000"),
            currency="EUR",
            counterparty="Delta",
        )

        def should_use_0_8_percent_fee(self):
            with patch.dict("os.environ", {"FXSETTLE_RATES_URL": "https://rates.example.com"}):
                mock_resp = _make_rate_response("1.1000")
                with patch("httpx.get", return_value=mock_resp):
                    result = settle(self.invoice, "USD")

                    gross = Decimal("22000.00")
                    expected_fee = gross * Decimal("0.008")
                    assert result.fee == expected_fee.quantize(Decimal("0.01"))

    class when_minimum_fee_applies:

        invoice = Invoice(
            amount=Decimal("1"),
            currency="EUR",
            counterparty="Epsilon",
        )

        def should_apply_minimum_fee_of_5(self):
            with patch.dict("os.environ", {"FXSETTLE_RATES_URL": "https://rates.example.com"}):
                mock_resp = _make_rate_response("1.1000")
                with patch("httpx.get", return_value=mock_resp):
                    result = settle(self.invoice, "USD")

                    assert result.fee == Decimal("5.00")

    class when_targeting_jpy:

        invoice = Invoice(
            amount=Decimal("100"),
            currency="USD",
            counterparty="Zeta",
        )

        def should_round_to_whole_units(self):
            with patch.dict("os.environ", {"FXSETTLE_RATES_URL": "https://rates.example.com"}):
                mock_resp = _make_rate_response("149.555")
                with patch("httpx.get", return_value=mock_resp):
                    result = settle(self.invoice, "JPY")

                    assert result.gross == Decimal("150")

    class when_unauthorized_currency_pair:

        invoice = Invoice(
            amount=Decimal("500"),
            currency="USD",
            counterparty="Eta",
        )

        def should_raise_unknown_currency_pair(self):
            with patch.dict("os.environ", {"FXSETTLE_RATES_URL": "https://rates.example.com"}):
                mock_resp = MagicMock()
                mock_resp.status_code = 404
                with patch("httpx.get", return_value=mock_resp):
                    with pytest.raises(UnknownCurrencyPair):
                        settle(self.invoice, "XYZ")

    class when_rates_service_is_down:

        invoice = Invoice(
            amount=Decimal("500"),
            currency="USD",
            counterparty="Theta",
        )

        def should_raise_rate_unavailable(self):
            with patch.dict("os.environ", {"FXSETTLE_RATES_URL": "https://rates.example.com"}):
                with patch("httpx.get", side_effect=Exception("connection error")):
                    with pytest.raises(RateUnavailable):
                        settle(self.invoice, "CAD")

    class when_calculating_net:

        invoice = Invoice(
            amount=Decimal("1500"),
            currency="EUR",
            counterparty="Iota",
        )

        def should_be_gross_minus_fee(self):
            with patch.dict("os.environ", {"FXSETTLE_RATES_URL": "https://rates.example.com"}):
                mock_resp = _make_rate_response("1.2000")
                with patch("httpx.get", return_value=mock_resp):
                    result = settle(self.invoice, "USD")

                    assert result.net == result.gross - result.fee


# ---------------------------------------------------------------------------

from unittest.mock import MagicMock


def _make_rate_response(rate_str: str):
    mock = MagicMock()
    mock.status_code = 200
    mock.json.return_value = {
        "base": "EUR",
        "quote": "USD",
        "rate": rate_str,
        "as_of": "2026-08-13",
    }
    return mock
