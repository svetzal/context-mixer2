"""Gateway that retrieves FX rates from the external service."""

from __future__ import annotations

import json
import os
from decimal import Decimal

import httpx

from .exceptions import RateUnavailable, UnknownCurrencyPair


def _get_base_url() -> str:
    url = os.environ.get("FXSETTLE_RATES_URL")
    if not url:
        raise RateUnavailable("FXSETTLE_RATES_URL is not set")
    return url.rstrip("/")


def fetch_rate(base: str, quote: str) -> Decimal:
    """Return the exchange rate for base -> quote, or fail with a domain error."""

    base_url = _get_base_url()

    try:
        response = httpx.get(
            f"{base_url}/v1/rates",
            params={"base": base, "quote": quote},
        )
    except httpx.TransportError as exc:
        raise RateUnavailable(f"Transport error: {exc}") from exc

    if response.status_code == 404:
        raise UnknownCurrencyPair(f"No rate for {base}/{quote}")

    if response.status_code != 200:
        raise RateUnavailable(
            f"Unexpected status {response.status_code} from rates service"
        )

    try:
        body = response.json()
    except json.JSONDecodeError as exc:
        raise RateUnavailable("Response is not valid JSON") from exc

    rate_raw = body.get("rate")
    if rate_raw is None:
        raise RateUnavailable("Response missing 'rate' field")

    return Decimal(str(rate_raw))
