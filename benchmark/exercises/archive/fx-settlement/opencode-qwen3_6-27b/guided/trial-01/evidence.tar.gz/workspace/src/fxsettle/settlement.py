"""Settlement calculation: conversion, fees, and net amount."""

from __future__ import annotations

from decimal import ROUND_HALF_UP, Decimal

from .exceptions import UnknownCurrencyPair, RateUnavailable
from .models import Invoice, Settlement
from .rates import fetch_rate

# Currencies whose minor unit is zero.
_NO_MINOR = frozenset(("JPY", "KRW"))

_FEE_TIERS = [
     (Decimal("10000"), Decimal("0.008")),
     (Decimal("1000"), Decimal("0.015")),
     (Decimal("0"), Decimal("0.025")),
]

_MIN_FEE = Decimal("5")


def _minor_units(currency: str) -> int:
    return 0 if currency in _NO_MINOR else 2


def _round_money(value: Decimal, currency: str) -> Decimal:
    places = _minor_units(currency)
    if places == 0:
        return value.quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    exp = Decimal("0." + "0" * (places - 1) + "1")
    return value.quantize(exp, rounding=ROUND_HALF_UP)


def _fee_percentage(gross: Decimal) -> Decimal:
    for threshold, pct in _FEE_TIERS:
        if gross > threshold:
            return pct
    raise ValueError(f"Unreachable: gross {gross}")


def settle(invoice: Invoice, quote_currency: str) -> Settlement:
    """Settle an invoice by converting to *quote_currency*.

    Raises
    ------
    UnknownCurrencyPair
        When the rates service does not quote the requested pair.
    RateUnavailable
        When the rates service is unreachable or returns an invalid response.
    """
    if invoice.currency == quote_currency:
        rate = Decimal("1")
    else:
        rate = fetch_rate(invoice.currency, quote_currency)

    gross = _round_money(invoice.amount * rate, quote_currency)
    fee_pct = _fee_percentage(gross)
    fee_calc = gross * fee_pct
    fee = _round_money(max(fee_calc, _MIN_FEE), quote_currency)
    net = gross - fee

    return Settlement(
        gross=gross,
        fee=fee,
        net=net,
        rate=rate,
        base_currency=invoice.currency,
        quote_currency=quote_currency,
    )
