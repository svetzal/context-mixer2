"""Domain errors raised by the settlement package."""


class UnknownCurrencyPair(Exception):
    """The requested currency pair has no published rate."""


class RateUnavailable(Exception):
    """The rates service could not provide a rate."""
