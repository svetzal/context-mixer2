"""Imperative shell: orchestrates rate lookup and settlement calculation."""

from decimal import Decimal

from .domain import build_settlement
from .models import Invoice, Settlement
from .rates_gateway import RatesGateway

_IDENTITY_RATE = Decimal(1)


def settle(invoice: Invoice, quote_currency: str) -> Settlement:
    """Settle an invoice into ``quote_currency``.

    Raises:
        UnknownCurrencyPair: the rates service has no quote for this pair.
        RateUnavailable: the rate could not be obtained or trusted.
    """
    if invoice.currency == quote_currency:
        rate = _IDENTITY_RATE
    else:
        rate = RatesGateway().get_rate(invoice.currency, quote_currency)

    return build_settlement(invoice.amount, rate, invoice.currency, quote_currency)
