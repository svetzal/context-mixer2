"""Domain exceptions raised while settling a cross-currency invoice."""


class UnknownCurrencyPair(Exception):
    """Raised when the rates service has no quote for a currency pair."""


class RateUnavailable(Exception):
    """Raised when a rate cannot be obtained or trusted.

    Covers transport failures, non-success statuses other than a pair being
    unknown, unparsable bodies, missing rate data, and a missing
    ``FXSETTLE_RATES_URL`` configuration.
    """
