"""Pure settlement calculations.

No filesystem, network, database, git, clock, or process I/O. Every function
here is deterministic: equal inputs return equal outputs.
"""

from decimal import Decimal, ROUND_HALF_UP

from .models import Settlement

_ZERO_DECIMAL_CURRENCIES = {"JPY", "KRW"}

_FEE_FLOOR = Decimal(5)

_LOW_TIER_CEILING = Decimal(1000)
_MID_TIER_CEILING = Decimal(10000)
_LOW_TIER_RATE = Decimal("0.025")
_MID_TIER_RATE = Decimal("0.015")
_HIGH_TIER_RATE = Decimal("0.008")


def minor_units(currency: str) -> int:
    """Return the number of decimal places used by a currency's minor unit."""
    return 0 if currency in _ZERO_DECIMAL_CURRENCIES else 2


def round_to_minor_units(value: Decimal, currency: str) -> Decimal:
    """Round a value half-up to the given currency's minor unit precision."""
    exponent = Decimal(1) if minor_units(currency) == 0 else Decimal("0.01")
    return value.quantize(exponent, rounding=ROUND_HALF_UP)


def fee_percentage(gross: Decimal) -> Decimal:
    """Return the tiered fee percentage applicable to a gross amount."""
    if gross <= _LOW_TIER_CEILING:
        return _LOW_TIER_RATE
    if gross <= _MID_TIER_CEILING:
        return _MID_TIER_RATE
    return _HIGH_TIER_RATE


def build_settlement(
    amount: Decimal,
    rate: Decimal,
    base_currency: str,
    quote_currency: str,
) -> Settlement:
    """Compute a settlement for an amount converted at a given rate."""
    gross = round_to_minor_units(amount * rate, quote_currency)
    fee = round_to_minor_units(
        max(gross * fee_percentage(gross), _FEE_FLOOR), quote_currency
    )
    net = gross - fee

    return Settlement(
        gross=gross,
        fee=fee,
        net=net,
        rate=rate,
        base_currency=base_currency,
        quote_currency=quote_currency,
    )
