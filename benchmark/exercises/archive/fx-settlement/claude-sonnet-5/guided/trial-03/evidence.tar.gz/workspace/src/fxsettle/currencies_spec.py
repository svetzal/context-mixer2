"""Behaviour specifications for currency reference data."""

from fxsettle.currencies import currency_name


class DescribeCurrencyName:
    def should_return_the_display_name_for_a_known_code(self):
        assert currency_name("USD") == "United States dollar"
        assert currency_name("JPY") == "Japanese yen"

    def should_return_the_code_itself_for_an_unknown_code(self):
        assert currency_name("XXX") == "XXX"
