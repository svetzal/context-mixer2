"""Behaviour specifications for pure settlement calculations."""

from decimal import Decimal

from fxsettle.domain import (
    build_settlement,
    fee_percentage,
    minor_units,
    round_to_minor_units,
)


class DescribeMinorUnits:
    def should_be_zero_for_japanese_yen(self):
        assert minor_units("JPY") == 0

    def should_be_zero_for_south_korean_won(self):
        assert minor_units("KRW") == 0

    def should_be_two_for_other_currencies(self):
        assert minor_units("USD") == 2
        assert minor_units("EUR") == 2
        assert minor_units("GBP") == 2
        assert minor_units("CAD") == 2


class DescribeRoundToMinorUnits:
    def should_round_half_up_to_two_decimal_places(self):
        assert round_to_minor_units(Decimal("1.005"), "USD") == Decimal("1.01")
        assert round_to_minor_units(Decimal("1.004"), "USD") == Decimal("1.00")

    def should_round_half_up_to_a_whole_number_for_zero_decimal_currencies(self):
        assert round_to_minor_units(Decimal("100.5"), "JPY") == Decimal("101")
        assert round_to_minor_units(Decimal("100.4"), "JPY") == Decimal("100")


class DescribeFeePercentage:
    def should_charge_two_point_five_percent_at_and_below_one_thousand(self):
        assert fee_percentage(Decimal("1000")) == Decimal("0.025")
        assert fee_percentage(Decimal("1")) == Decimal("0.025")

    def should_charge_one_point_five_percent_between_one_thousand_and_ten_thousand(self):
        assert fee_percentage(Decimal("1000.01")) == Decimal("0.015")
        assert fee_percentage(Decimal("10000")) == Decimal("0.015")

    def should_charge_zero_point_eight_percent_above_ten_thousand(self):
        assert fee_percentage(Decimal("10000.01")) == Decimal("0.008")


class DescribeBuildSettlement:
    def should_convert_amount_by_rate_to_produce_gross(self):
        settlement = build_settlement(Decimal("500.00"), Decimal("1.3542"), "USD", "CAD")

        assert settlement.gross == Decimal("677.10")

    def should_apply_the_tiered_fee_percentage_to_gross(self):
        settlement = build_settlement(Decimal("500.00"), Decimal("1.3542"), "USD", "CAD")

        assert settlement.fee == Decimal("16.93")
        assert settlement.net == Decimal("660.17")

    def should_floor_the_fee_at_five_whole_units_of_the_quote_currency(self):
        settlement = build_settlement(Decimal("10.00"), Decimal("1"), "USD", "USD")

        assert settlement.fee == Decimal("5.00")
        assert settlement.net == Decimal("5.00")

    def should_round_gross_and_fee_to_the_quote_currencys_minor_units(self):
        settlement = build_settlement(Decimal("10000"), Decimal("1"), "USD", "JPY")

        assert settlement.gross == Decimal("10000")
        assert settlement.fee == Decimal("150")
        assert settlement.net == Decimal("9850")

    def should_carry_the_rate_and_currencies_through_unchanged(self):
        settlement = build_settlement(Decimal("100.00"), Decimal("2"), "USD", "CAD")

        assert settlement.rate == Decimal("2")
        assert settlement.base_currency == "USD"
        assert settlement.quote_currency == "CAD"
