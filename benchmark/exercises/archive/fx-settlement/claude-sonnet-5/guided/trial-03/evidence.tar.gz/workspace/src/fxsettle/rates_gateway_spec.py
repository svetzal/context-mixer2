"""Behaviour specifications for the rates service HTTP gateway.

Exercises real socket I/O against the local `rates_server` fixture rather
than mocking httpx internals.
"""

from decimal import Decimal

import pytest

from fxsettle.exceptions import RateUnavailable, UnknownCurrencyPair
from fxsettle.rates_gateway import RatesGateway


class DescribeRatesGateway:
    def should_return_the_quoted_rate_for_a_known_pair(self, rates_server):
        rates_server.set_response(
            "USD", "CAD", 200,
            {"base": "USD", "quote": "CAD", "rate": "1.3542", "as_of": "2026-08-13"},
        )
        gateway = RatesGateway(base_url=rates_server.base_url)

        rate = gateway.get_rate("USD", "CAD")

        assert rate == Decimal("1.3542")

    def should_raise_unknown_currency_pair_when_the_service_returns_404(self, rates_server):
        gateway = RatesGateway(base_url=rates_server.base_url)

        with pytest.raises(UnknownCurrencyPair):
            gateway.get_rate("USD", "XXX")

    def should_raise_rate_unavailable_on_a_server_error_status(self, rates_server):
        rates_server.set_response("USD", "CAD", 500, "internal error")
        gateway = RatesGateway(base_url=rates_server.base_url)

        with pytest.raises(RateUnavailable):
            gateway.get_rate("USD", "CAD")

    def should_raise_rate_unavailable_on_a_non_json_body(self, rates_server):
        rates_server.set_response("USD", "CAD", 200, "not json")
        gateway = RatesGateway(base_url=rates_server.base_url)

        with pytest.raises(RateUnavailable):
            gateway.get_rate("USD", "CAD")

    def should_raise_rate_unavailable_when_the_rate_field_is_missing(self, rates_server):
        rates_server.set_response("USD", "CAD", 200, {"base": "USD", "quote": "CAD"})
        gateway = RatesGateway(base_url=rates_server.base_url)

        with pytest.raises(RateUnavailable):
            gateway.get_rate("USD", "CAD")

    def should_raise_rate_unavailable_when_the_base_url_is_unset(self):
        gateway = RatesGateway(base_url=None)

        with pytest.raises(RateUnavailable):
            gateway.get_rate("USD", "CAD")

    def should_raise_rate_unavailable_on_a_transport_failure(self):
        gateway = RatesGateway(base_url="http://127.0.0.1:1")

        with pytest.raises(RateUnavailable):
            gateway.get_rate("USD", "CAD")
