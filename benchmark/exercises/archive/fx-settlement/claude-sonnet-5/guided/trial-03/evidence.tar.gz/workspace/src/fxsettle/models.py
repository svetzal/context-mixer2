"""Immutable domain models for cross-currency settlement."""

from decimal import Decimal

from pydantic import BaseModel, ConfigDict


class Invoice(BaseModel):
    """An amount owed by a counterparty in its local currency."""

    model_config = ConfigDict(frozen=True)

    amount: Decimal
    currency: str
    counterparty: str


class Settlement(BaseModel):
    """The result of converting and settling an invoice into a quote currency."""

    model_config = ConfigDict(frozen=True)

    gross: Decimal
    fee: Decimal
    net: Decimal
    rate: Decimal
    base_currency: str
    quote_currency: str
