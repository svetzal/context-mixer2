"""Imperative shell: thin gateway to the FX rates HTTP service."""

import os
from decimal import Decimal, InvalidOperation

import httpx

from .exceptions import RateUnavailable, UnknownCurrencyPair

_RATES_PATH = "/v1/rates"


class RatesGateway:
    """Fetches a single conversion rate from the configured rates service."""

    def __init__(self, base_url: str | None = None):
        self._base_url = (
            base_url if base_url is not None else os.environ.get("FXSETTLE_RATES_URL")
        )

    def get_rate(self, base: str, quote: str) -> Decimal:
        """Return the quoted rate for ``base`` -> ``quote``.

        Raises:
            UnknownCurrencyPair: the service has no quote for this pair.
            RateUnavailable: the rate could not be obtained or trusted.
        """
        if not self._base_url:
            raise RateUnavailable("FXSETTLE_RATES_URL is not set")

        try:
            response = httpx.get(
                f"{self._base_url}{_RATES_PATH}",
                params={"base": base, "quote": quote},
            )
        except httpx.HTTPError as exc:
            raise RateUnavailable(f"rates service request failed: {exc}") from exc

        if response.status_code == 404:
            raise UnknownCurrencyPair(f"no rate quoted for {base}/{quote}")

        if response.status_code != 200:
            raise RateUnavailable(
                f"rates service returned status {response.status_code}"
            )

        try:
            payload = response.json()
        except ValueError as exc:
            raise RateUnavailable("rates service returned a non-JSON body") from exc

        try:
            return Decimal(str(payload["rate"]))
        except (KeyError, TypeError, InvalidOperation) as exc:
            raise RateUnavailable(
                "rates service response is missing a usable rate"
            ) from exc
