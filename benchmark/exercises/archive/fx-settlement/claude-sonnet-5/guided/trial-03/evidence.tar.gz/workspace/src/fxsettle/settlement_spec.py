"""Behaviour specifications for settlement orchestration."""

from decimal import Decimal

import pytest

import fxsettle.settlement as settlement_module
from fxsettle import Invoice, RateUnavailable, UnknownCurrencyPair, settle


class _StubGateway:
    def __init__(self, rate=None, error=None):
        self._rate = rate
        self._error = error
        self.calls = []

    def get_rate(self, base, quote):
        self.calls.append((base, quote))
        if self._error is not None:
            raise self._error
        return self._rate


class DescribeSettle:
    def should_use_a_rate_of_one_and_skip_the_gateway_when_currencies_match(self, monkeypatch):
        stub = _StubGateway(rate=Decimal("999"))
        monkeypatch.setattr(settlement_module, "RatesGateway", lambda: stub)
        invoice = Invoice(amount=Decimal("100.00"), currency="USD", counterparty="Acme")

        result = settle(invoice, "USD")

        assert result.rate == Decimal("1")
        assert stub.calls == []

    def should_convert_using_the_gateway_rate_for_different_currencies(self, monkeypatch):
        stub = _StubGateway(rate=Decimal("1.3542"))
        monkeypatch.setattr(settlement_module, "RatesGateway", lambda: stub)
        invoice = Invoice(amount=Decimal("500.00"), currency="USD", counterparty="Acme")

        result = settle(invoice, "CAD")

        assert stub.calls == [("USD", "CAD")]
        assert result.gross == Decimal("677.10")

    def should_propagate_unknown_currency_pair_from_the_gateway(self, monkeypatch):
        stub = _StubGateway(error=UnknownCurrencyPair("no quote"))
        monkeypatch.setattr(settlement_module, "RatesGateway", lambda: stub)
        invoice = Invoice(amount=Decimal("100.00"), currency="USD", counterparty="Acme")

        with pytest.raises(UnknownCurrencyPair):
            settle(invoice, "XXX")

    def should_propagate_rate_unavailable_from_the_gateway(self, monkeypatch):
        stub = _StubGateway(error=RateUnavailable("down"))
        monkeypatch.setattr(settlement_module, "RatesGateway", lambda: stub)
        invoice = Invoice(amount=Decimal("100.00"), currency="USD", counterparty="Acme")

        with pytest.raises(RateUnavailable):
            settle(invoice, "CAD")


class DescribeSettleEndToEnd:
    def should_settle_against_a_live_rates_service(self, rates_server, monkeypatch):
        rates_server.set_response(
            "USD", "CAD", 200,
            {"base": "USD", "quote": "CAD", "rate": "1.3542", "as_of": "2026-08-13"},
        )
        monkeypatch.setenv("FXSETTLE_RATES_URL", rates_server.base_url)
        invoice = Invoice(amount=Decimal("500.00"), currency="USD", counterparty="Acme")

        result = settle(invoice, "CAD")

        assert result.base_currency == "USD"
        assert result.quote_currency == "CAD"
        assert result.rate == Decimal("1.3542")
        assert result.gross == Decimal("677.10")
        assert result.fee == Decimal("16.93")
        assert result.net == Decimal("660.17")

    def should_raise_unknown_currency_pair_for_an_unquoted_pair_on_a_live_service(
        self, rates_server, monkeypatch
    ):
        monkeypatch.setenv("FXSETTLE_RATES_URL", rates_server.base_url)
        invoice = Invoice(amount=Decimal("100.00"), currency="USD", counterparty="Acme")

        with pytest.raises(UnknownCurrencyPair):
            settle(invoice, "XXX")

    def should_raise_rate_unavailable_when_the_url_is_unset(self, monkeypatch):
        monkeypatch.delenv("FXSETTLE_RATES_URL", raising=False)
        invoice = Invoice(amount=Decimal("100.00"), currency="USD", counterparty="Acme")

        with pytest.raises(RateUnavailable):
            settle(invoice, "CAD")
