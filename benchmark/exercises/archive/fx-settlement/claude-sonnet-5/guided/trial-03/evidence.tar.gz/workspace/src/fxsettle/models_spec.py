"""Behaviour specifications for domain models."""

from decimal import Decimal

import pytest
from pydantic import ValidationError

from fxsettle import Invoice, Settlement


class DescribeInvoice:
    def should_hold_amount_currency_and_counterparty(self):
        invoice = Invoice(amount=Decimal("100.00"), currency="USD", counterparty="Acme")

        assert invoice.amount == Decimal("100.00")
        assert invoice.currency == "USD"
        assert invoice.counterparty == "Acme"

    def should_reject_field_assignment_after_construction(self):
        invoice = Invoice(amount=Decimal("100.00"), currency="USD", counterparty="Acme")

        with pytest.raises(ValidationError):
            invoice.amount = Decimal("200.00")


class DescribeSettlement:
    def should_hold_all_settlement_fields(self):
        settlement = Settlement(
            gross=Decimal("100.00"),
            fee=Decimal("5.00"),
            net=Decimal("95.00"),
            rate=Decimal("1.25"),
            base_currency="USD",
            quote_currency="CAD",
        )

        assert settlement.gross == Decimal("100.00")
        assert settlement.fee == Decimal("5.00")
        assert settlement.net == Decimal("95.00")
        assert settlement.rate == Decimal("1.25")
        assert settlement.base_currency == "USD"
        assert settlement.quote_currency == "CAD"

    def should_reject_field_assignment_after_construction(self):
        settlement = Settlement(
            gross=Decimal("100.00"),
            fee=Decimal("5.00"),
            net=Decimal("95.00"),
            rate=Decimal("1.25"),
            base_currency="USD",
            quote_currency="CAD",
        )

        with pytest.raises(ValidationError):
            settlement.gross = Decimal("200.00")
