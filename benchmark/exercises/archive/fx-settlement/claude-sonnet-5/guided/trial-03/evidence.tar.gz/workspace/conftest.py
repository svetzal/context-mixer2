"""Shared pytest fixtures: a real local HTTP double for the rates service.

Runs an actual socket server rather than mocking httpx internals, so specs
that use it exercise a genuine end-to-end HTTP round trip.
"""

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import pytest


class _RatesRequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        base = query.get("base", [None])[0]
        quote = query.get("quote", [None])[0]

        if parsed.path != "/v1/rates" or (base, quote) not in self.server.responses:
            self.send_response(404)
            self.end_headers()
            return

        status, body = self.server.responses[(base, quote)]
        self.send_response(status)
        if isinstance(body, (dict, list)):
            payload = json.dumps(body).encode()
            self.send_header("Content-Type", "application/json")
        else:
            payload = body.encode()
            self.send_header("Content-Type", "text/plain")
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, format, *args):
        pass


class FakeRatesServer:
    """A real, locally bound HTTP server standing in for the rates service."""

    def __init__(self):
        self._server = ThreadingHTTPServer(("127.0.0.1", 0), _RatesRequestHandler)
        self._server.responses = {}
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()

    @property
    def base_url(self) -> str:
        host, port = self._server.server_address
        return f"http://{host}:{port}"

    def set_response(self, base: str, quote: str, status: int, body) -> None:
        self._server.responses[(base, quote)] = (status, body)

    def shutdown(self) -> None:
        self._server.shutdown()
        self._server.server_close()
        self._thread.join(timeout=1)


@pytest.fixture
def rates_server():
    server = FakeRatesServer()
    yield server
    server.shutdown()
