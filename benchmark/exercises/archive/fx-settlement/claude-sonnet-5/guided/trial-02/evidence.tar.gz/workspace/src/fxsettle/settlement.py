"""Settlement orchestration: the imperative shell."""

from decimal import Decimal

from fxsettle.core import compute_settlement
from fxsettle.models import Invoice, Settlement
from fxsettle.rates_gateway import RatesGateway

_UNIT_RATE = Decimal(1)


def settle(invoice: Invoice, quote_currency: str, gateway: RatesGateway | None = None) -> Settlement:
    """Settle an invoice into quote_currency, converting via the rates gateway when needed."""
    if invoice.currency == quote_currency:
        rate = _UNIT_RATE
    else:
        gateway = gateway or RatesGateway()
        rate = gateway.get_rate(invoice.currency, quote_currency)

    return compute_settlement(invoice.amount, invoice.currency, quote_currency, rate)
