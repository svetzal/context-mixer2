"""Specification for settle(), the settlement orchestration shell."""

import http.server
import json
import threading
import urllib.parse
from decimal import Decimal

import pytest

from fxsettle.errors import RateUnavailable, UnknownCurrencyPair
from fxsettle.models import Invoice
from fxsettle.rates_gateway import RatesGateway
from fxsettle.settlement import settle


class _FakeGateway:
    def __init__(self, rate=None, error=None):
        self._rate = rate
        self._error = error
        self.calls = []

    def get_rate(self, base, quote):
        self.calls.append((base, quote))
        if self._error is not None:
            raise self._error
        return self._rate


class DescribeSettle:
    def should_settle_without_a_gateway_call_when_currencies_match(self):
        invoice = Invoice(amount=Decimal("100.00"), currency="USD", counterparty="Acme Corp")
        gateway = _FakeGateway(rate=Decimal("999"))

        settlement = settle(invoice, "USD", gateway=gateway)

        assert settlement.rate == Decimal(1)
        assert gateway.calls == []

    def should_convert_via_the_gateway_when_currencies_differ(self):
        invoice = Invoice(amount=Decimal("100.00"), currency="USD", counterparty="Acme Corp")
        gateway = _FakeGateway(rate=Decimal("1.35"))

        settlement = settle(invoice, "CAD", gateway=gateway)

        assert settlement.base_currency == "USD"
        assert settlement.quote_currency == "CAD"
        assert settlement.gross == Decimal("135.00")
        assert gateway.calls == [("USD", "CAD")]

    def should_propagate_unknown_currency_pair_from_the_gateway(self):
        invoice = Invoice(amount=Decimal("100.00"), currency="USD", counterparty="Acme Corp")
        gateway = _FakeGateway(error=UnknownCurrencyPair("no quote"))

        with pytest.raises(UnknownCurrencyPair):
            settle(invoice, "ZZZ", gateway=gateway)

    def should_propagate_rate_unavailable_from_the_gateway(self):
        invoice = Invoice(amount=Decimal("100.00"), currency="USD", counterparty="Acme Corp")
        gateway = _FakeGateway(error=RateUnavailable("down"))

        with pytest.raises(RateUnavailable):
            settle(invoice, "CAD", gateway=gateway)


class _RatesHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        query = urllib.parse.parse_qs(parsed.query)
        base = query.get("base", [None])[0]
        quote = query.get("quote", [None])[0]

        if parsed.path == "/v1/rates" and base == "USD" and quote == "CAD":
            self._respond(200, {"base": base, "quote": quote, "rate": "1.5000", "as_of": "2026-08-13"})
        else:
            self._respond(404, None)

    def _respond(self, status, payload):
        body = json.dumps(payload).encode() if payload is not None else b""
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        pass


@pytest.fixture
def live_rates_server():
    server = http.server.HTTPServer(("127.0.0.1", 0), _RatesHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    try:
        yield f"http://127.0.0.1:{server.server_port}"
    finally:
        server.shutdown()
        thread.join()


class DescribeSettleAgainstALiveRatesService:
    def should_settle_an_invoice_using_a_real_http_rates_service(self, live_rates_server):
        invoice = Invoice(amount=Decimal("200.00"), currency="USD", counterparty="Acme Corp")
        gateway = RatesGateway(base_url=live_rates_server)

        settlement = settle(invoice, "CAD", gateway=gateway)

        assert settlement.rate == Decimal("1.5000")
        assert settlement.gross == Decimal("300.00")

    def should_raise_unknown_currency_pair_when_the_live_service_has_no_quote(self, live_rates_server):
        invoice = Invoice(amount=Decimal("200.00"), currency="USD", counterparty="Acme Corp")
        gateway = RatesGateway(base_url=live_rates_server)

        with pytest.raises(UnknownCurrencyPair):
            settle(invoice, "ZZZ", gateway=gateway)

    def should_settle_using_the_rates_url_from_the_environment_variable(self, live_rates_server, monkeypatch):
        monkeypatch.setenv("FXSETTLE_RATES_URL", live_rates_server)
        invoice = Invoice(amount=Decimal("200.00"), currency="USD", counterparty="Acme Corp")

        settlement = settle(invoice, "CAD")

        assert settlement.rate == Decimal("1.5000")
