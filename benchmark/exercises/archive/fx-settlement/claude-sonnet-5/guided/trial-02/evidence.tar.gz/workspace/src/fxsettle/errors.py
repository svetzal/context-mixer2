"""Domain exceptions for settlement failures."""


class UnknownCurrencyPair(Exception):
    """Raised when the rates service has no quote for a currency pair."""


class RateUnavailable(Exception):
    """Raised when a rate cannot be obtained for any reason other than an unknown pair."""
