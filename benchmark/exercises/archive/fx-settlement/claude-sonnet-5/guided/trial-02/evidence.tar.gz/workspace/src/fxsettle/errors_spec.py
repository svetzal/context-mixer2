"""Specification for domain exceptions."""

from fxsettle.errors import RateUnavailable, UnknownCurrencyPair


class DescribeUnknownCurrencyPair:
    def should_be_catchable_as_its_own_type(self):
        try:
            raise UnknownCurrencyPair("no quote for XXX/YYY")
        except UnknownCurrencyPair as error:
            assert str(error) == "no quote for XXX/YYY"

    def should_not_be_caught_as_rate_unavailable(self):
        assert not issubclass(UnknownCurrencyPair, RateUnavailable)


class DescribeRateUnavailable:
    def should_be_catchable_as_its_own_type(self):
        try:
            raise RateUnavailable("transport failure")
        except RateUnavailable as error:
            assert str(error) == "transport failure"

    def should_not_be_caught_as_unknown_currency_pair(self):
        assert not issubclass(RateUnavailable, UnknownCurrencyPair)
