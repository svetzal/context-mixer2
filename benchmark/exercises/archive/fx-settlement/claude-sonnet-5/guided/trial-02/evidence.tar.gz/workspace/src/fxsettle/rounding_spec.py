"""Specification for currency rounding rules."""

from decimal import Decimal

from fxsettle.rounding import minor_units, round_half_up


class DescribeMinorUnits:
    def should_return_zero_for_jpy(self):
        assert minor_units("JPY") == 0

    def should_return_zero_for_krw(self):
        assert minor_units("KRW") == 0

    def should_return_two_for_other_currencies(self):
        assert minor_units("USD") == 2
        assert minor_units("EUR") == 2


class DescribeRoundHalfUp:
    def should_round_half_up_to_two_decimal_places(self):
        result = round_half_up(Decimal("10.125"), "USD")

        assert result == Decimal("10.13")

    def should_round_half_up_to_whole_units_for_zero_decimal_currencies(self):
        result = round_half_up(Decimal("1050.5"), "JPY")

        assert result == Decimal("1051")

    def should_leave_already_exact_values_unchanged(self):
        result = round_half_up(Decimal("42.00"), "USD")

        assert result == Decimal("42.00")
