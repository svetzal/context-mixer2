"""Thin gateway around the external FX rates service."""

import os
from decimal import Decimal, InvalidOperation

import httpx

from fxsettle.errors import RateUnavailable, UnknownCurrencyPair

_RATES_URL_ENV_VAR = "FXSETTLE_RATES_URL"


class RatesGateway:
    """Fetches conversion rates from the configured rates service over HTTP."""

    def __init__(self, base_url: str | None = None, client: httpx.Client | None = None):
        self._base_url = base_url
        self._client = client or httpx.Client()

    def get_rate(self, base: str, quote: str) -> Decimal:
        """Return the conversion rate for base -> quote.

        Raises UnknownCurrencyPair if the pair is not quoted, or RateUnavailable
        for any other failure to obtain a usable rate.
        """
        base_url = self._base_url or os.environ.get(_RATES_URL_ENV_VAR)
        if not base_url:
            raise RateUnavailable(f"{_RATES_URL_ENV_VAR} is not set")

        try:
            response = self._client.get(
                f"{base_url}/v1/rates", params={"base": base, "quote": quote}
            )
        except httpx.HTTPError as error:
            raise RateUnavailable(f"transport failure fetching {base}/{quote} rate") from error

        if response.status_code == 404:
            raise UnknownCurrencyPair(f"no rate quoted for {base}/{quote}")

        if response.is_error:
            raise RateUnavailable(
                f"rates service returned {response.status_code} for {base}/{quote}"
            )

        try:
            payload = response.json()
        except ValueError as error:
            raise RateUnavailable(
                f"rates service returned a non-JSON body for {base}/{quote}"
            ) from error

        try:
            rate_value = payload["rate"]
        except (KeyError, TypeError) as error:
            raise RateUnavailable(
                f"rates service response missing 'rate' for {base}/{quote}"
            ) from error

        try:
            return Decimal(str(rate_value))
        except InvalidOperation as error:
            raise RateUnavailable(
                f"rates service returned a non-numeric rate for {base}/{quote}"
            ) from error
