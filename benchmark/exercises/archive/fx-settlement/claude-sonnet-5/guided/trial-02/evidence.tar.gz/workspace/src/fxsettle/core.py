"""Pure settlement computation: the functional core."""

from decimal import Decimal

from fxsettle.fees import raw_fee
from fxsettle.models import Settlement
from fxsettle.rounding import round_half_up


def compute_settlement(
    amount: Decimal,
    base_currency: str,
    quote_currency: str,
    rate: Decimal,
) -> Settlement:
    """Compute a full settlement from an invoice amount and a known conversion rate."""
    gross = round_half_up(amount * rate, quote_currency)
    fee = round_half_up(raw_fee(gross), quote_currency)
    net = gross - fee
    return Settlement(
        gross=gross,
        fee=fee,
        net=net,
        rate=rate,
        base_currency=base_currency,
        quote_currency=quote_currency,
    )
