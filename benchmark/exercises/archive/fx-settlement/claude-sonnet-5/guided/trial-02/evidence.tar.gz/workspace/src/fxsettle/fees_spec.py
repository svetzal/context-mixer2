"""Specification for the tiered settlement fee."""

from decimal import Decimal

from fxsettle.fees import fee_percentage, raw_fee


class DescribeFeePercentage:
    def should_charge_two_point_five_percent_at_or_below_one_thousand(self):
        assert fee_percentage(Decimal(1000)) == Decimal("0.025")
        assert fee_percentage(Decimal(500)) == Decimal("0.025")

    def should_charge_one_point_five_percent_between_one_thousand_and_ten_thousand(self):
        assert fee_percentage(Decimal("1000.01")) == Decimal("0.015")
        assert fee_percentage(Decimal(10000)) == Decimal("0.015")

    def should_charge_zero_point_eight_percent_above_ten_thousand(self):
        assert fee_percentage(Decimal("10000.01")) == Decimal("0.008")


class DescribeRawFee:
    def should_apply_the_tiered_percentage_when_it_exceeds_the_floor(self):
        result = raw_fee(Decimal(2000))

        assert result == Decimal(30)

    def should_apply_the_five_unit_floor_for_small_amounts(self):
        result = raw_fee(Decimal(10))

        assert result == Decimal(5)
