"""Specification for the frozen domain models."""

from decimal import Decimal

import pytest
from pydantic import ValidationError

from fxsettle.models import Invoice, Settlement


class DescribeInvoice:
    def should_hold_the_fields_it_was_constructed_with(self):
        invoice = Invoice(amount=Decimal("100.00"), currency="USD", counterparty="Acme Corp")

        assert invoice.amount == Decimal("100.00")
        assert invoice.currency == "USD"
        assert invoice.counterparty == "Acme Corp"

    def should_reject_field_assignment_after_construction(self):
        invoice = Invoice(amount=Decimal("100.00"), currency="USD", counterparty="Acme Corp")

        with pytest.raises(ValidationError):
            invoice.amount = Decimal("200.00")


class DescribeSettlement:
    def should_hold_the_fields_it_was_constructed_with(self):
        settlement = Settlement(
            gross=Decimal("135.00"),
            fee=Decimal("5.00"),
            net=Decimal("130.00"),
            rate=Decimal("1.35"),
            base_currency="USD",
            quote_currency="CAD",
        )

        assert settlement.gross == Decimal("135.00")
        assert settlement.fee == Decimal("5.00")
        assert settlement.net == Decimal("130.00")
        assert settlement.rate == Decimal("1.35")
        assert settlement.base_currency == "USD"
        assert settlement.quote_currency == "CAD"

    def should_reject_field_assignment_after_construction(self):
        settlement = Settlement(
            gross=Decimal("135.00"),
            fee=Decimal("5.00"),
            net=Decimal("130.00"),
            rate=Decimal("1.35"),
            base_currency="USD",
            quote_currency="CAD",
        )

        with pytest.raises(ValidationError):
            settlement.gross = Decimal("999.00")
