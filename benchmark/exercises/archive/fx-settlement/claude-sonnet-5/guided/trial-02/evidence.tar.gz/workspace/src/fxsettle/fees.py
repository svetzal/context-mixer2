"""Tiered settlement fee calculation."""

from decimal import Decimal

_TIER_ONE_CEILING = Decimal(1000)
_TIER_TWO_CEILING = Decimal(10000)
_TIER_ONE_RATE = Decimal("0.025")
_TIER_TWO_RATE = Decimal("0.015")
_TIER_THREE_RATE = Decimal("0.008")
_FEE_FLOOR = Decimal(5)


def fee_percentage(gross: Decimal) -> Decimal:
    """Return the tiered fee percentage that applies to a gross amount."""
    if gross <= _TIER_ONE_CEILING:
        return _TIER_ONE_RATE
    if gross <= _TIER_TWO_CEILING:
        return _TIER_TWO_RATE
    return _TIER_THREE_RATE


def raw_fee(gross: Decimal) -> Decimal:
    """Return the un-rounded fee for a gross amount, before currency rounding."""
    return max(gross * fee_percentage(gross), _FEE_FLOOR)
