"""Specification for the RatesGateway HTTP boundary."""

from decimal import Decimal

import httpx
import pytest

from fxsettle.errors import RateUnavailable, UnknownCurrencyPair
from fxsettle.rates_gateway import RatesGateway


def _gateway_with_response(handler):
    client = httpx.Client(transport=httpx.MockTransport(handler))
    return RatesGateway(base_url="https://rates.example.test", client=client)


class DescribeGetRate:
    def should_return_the_quoted_rate_on_success(self):
        def handler(request):
            assert request.url.params["base"] == "USD"
            assert request.url.params["quote"] == "CAD"
            return httpx.Response(
                200,
                json={"base": "USD", "quote": "CAD", "rate": "1.3542", "as_of": "2026-08-13"},
            )

        gateway = _gateway_with_response(handler)

        rate = gateway.get_rate("USD", "CAD")

        assert rate == Decimal("1.3542")

    def should_raise_unknown_currency_pair_on_404(self):
        gateway = _gateway_with_response(lambda request: httpx.Response(404))

        with pytest.raises(UnknownCurrencyPair):
            gateway.get_rate("USD", "ZZZ")

    def should_raise_rate_unavailable_on_a_server_error(self):
        gateway = _gateway_with_response(lambda request: httpx.Response(500))

        with pytest.raises(RateUnavailable):
            gateway.get_rate("USD", "CAD")

    def should_raise_rate_unavailable_on_a_transport_failure(self):
        def handler(request):
            raise httpx.ConnectError("connection refused", request=request)

        gateway = _gateway_with_response(handler)

        with pytest.raises(RateUnavailable):
            gateway.get_rate("USD", "CAD")

    def should_raise_rate_unavailable_on_a_non_json_body(self):
        gateway = _gateway_with_response(lambda request: httpx.Response(200, text="not json"))

        with pytest.raises(RateUnavailable):
            gateway.get_rate("USD", "CAD")

    def should_raise_rate_unavailable_when_the_rate_field_is_missing(self):
        gateway = _gateway_with_response(
            lambda request: httpx.Response(200, json={"base": "USD", "quote": "CAD"})
        )

        with pytest.raises(RateUnavailable):
            gateway.get_rate("USD", "CAD")

    def should_raise_rate_unavailable_when_the_base_url_is_not_configured(self, monkeypatch):
        monkeypatch.delenv("FXSETTLE_RATES_URL", raising=False)
        gateway = RatesGateway(base_url=None, client=httpx.Client())

        with pytest.raises(RateUnavailable):
            gateway.get_rate("USD", "CAD")
