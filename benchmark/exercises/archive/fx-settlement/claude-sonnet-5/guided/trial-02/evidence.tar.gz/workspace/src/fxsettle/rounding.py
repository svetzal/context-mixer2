"""Currency rounding rules for the functional core."""

from decimal import ROUND_HALF_UP, Decimal

_ZERO_DECIMAL_CURRENCIES = {"JPY", "KRW"}


def minor_units(currency: str) -> int:
    """Return the number of minor-unit decimal places for a currency."""
    return 0 if currency in _ZERO_DECIMAL_CURRENCIES else 2


def round_half_up(value: Decimal, currency: str) -> Decimal:
    """Round a monetary value half-up to the currency's minor units."""
    exponent = Decimal(1).scaleb(-minor_units(currency))
    return value.quantize(exponent, rounding=ROUND_HALF_UP)
