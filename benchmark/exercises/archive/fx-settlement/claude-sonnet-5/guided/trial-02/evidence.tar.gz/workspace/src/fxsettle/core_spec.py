"""Specification for the pure settlement computation core."""

from decimal import Decimal

from fxsettle.core import compute_settlement


class DescribeComputeSettlement:
    def should_convert_the_amount_using_the_given_rate(self):
        settlement = compute_settlement(Decimal(100), "USD", "CAD", Decimal("1.35"))

        assert settlement.gross == Decimal("135.00")

    def should_apply_the_tiered_fee_to_the_gross_amount(self):
        settlement = compute_settlement(Decimal(1000), "USD", "CAD", Decimal(1))

        assert settlement.fee == Decimal("25.00")

    def should_compute_net_as_gross_minus_fee(self):
        settlement = compute_settlement(Decimal(1000), "USD", "CAD", Decimal(1))

        assert settlement.net == Decimal("975.00")

    def should_round_gross_to_the_quote_currencys_minor_units(self):
        settlement = compute_settlement(Decimal(100), "USD", "JPY", Decimal("150.555"))

        assert settlement.gross == Decimal("15056")

    def should_carry_the_rate_and_currencies_through(self):
        settlement = compute_settlement(Decimal(100), "USD", "CAD", Decimal("1.35"))

        assert settlement.rate == Decimal("1.35")
        assert settlement.base_currency == "USD"
        assert settlement.quote_currency == "CAD"
