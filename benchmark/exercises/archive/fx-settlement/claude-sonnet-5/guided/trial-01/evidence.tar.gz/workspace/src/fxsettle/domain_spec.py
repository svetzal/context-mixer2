from decimal import Decimal

from fxsettle.domain import compute_settlement, fee_percentage_for, round_to_minor_units
from fxsettle.models import Invoice


class DescribeRoundToMinorUnits:
    def should_round_half_up_to_two_decimal_places_by_default(self):
        result = round_to_minor_units(Decimal("100.005"), "USD")

        assert result == Decimal("100.01")

    def should_round_half_up_to_zero_decimal_places_for_jpy(self):
        result = round_to_minor_units(Decimal("1000.5"), "JPY")

        assert result == Decimal("1001")

    def should_round_half_up_to_zero_decimal_places_for_krw(self):
        result = round_to_minor_units(Decimal("1000.5"), "KRW")

        assert result == Decimal("1001")


class DescribeFeePercentageFor:
    def should_be_two_point_five_percent_at_or_below_one_thousand(self):
        assert fee_percentage_for(Decimal(1000)) == Decimal("0.025")
        assert fee_percentage_for(Decimal(1)) == Decimal("0.025")

    def should_be_one_point_five_percent_above_one_thousand_up_to_ten_thousand(self):
        assert fee_percentage_for(Decimal("1000.01")) == Decimal("0.015")
        assert fee_percentage_for(Decimal(10000)) == Decimal("0.015")

    def should_be_zero_point_eight_percent_above_ten_thousand(self):
        assert fee_percentage_for(Decimal("10000.01")) == Decimal("0.008")


class DescribeComputeSettlement:
    def should_convert_gross_using_the_supplied_rate(self):
        invoice = Invoice(amount=Decimal("100.00"), currency="USD", counterparty="acme")

        settlement = compute_settlement(invoice, "CAD", Decimal("1.3542"))

        assert settlement.gross == Decimal("135.42")
        assert settlement.rate == Decimal("1.3542")
        assert settlement.base_currency == "USD"
        assert settlement.quote_currency == "CAD"

    def should_apply_the_lowest_fee_tier_below_the_first_threshold(self):
        invoice = Invoice(amount=Decimal("400.00"), currency="USD", counterparty="acme")

        settlement = compute_settlement(invoice, "USD", Decimal(1))

        assert settlement.gross == Decimal("400.00")
        assert settlement.fee == Decimal("10.00")
        assert settlement.net == Decimal("390.00")

    def should_apply_the_middle_fee_tier_between_the_thresholds(self):
        invoice = Invoice(amount=Decimal("5000.00"), currency="USD", counterparty="acme")

        settlement = compute_settlement(invoice, "USD", Decimal(1))

        assert settlement.gross == Decimal("5000.00")
        assert settlement.fee == Decimal("75.00")
        assert settlement.net == Decimal("4925.00")

    def should_apply_the_highest_fee_tier_above_the_second_threshold(self):
        invoice = Invoice(amount=Decimal("20000.00"), currency="USD", counterparty="acme")

        settlement = compute_settlement(invoice, "USD", Decimal(1))

        assert settlement.gross == Decimal("20000.00")
        assert settlement.fee == Decimal("160.00")
        assert settlement.net == Decimal("19840.00")

    def should_floor_the_fee_at_five_whole_units_of_the_quote_currency(self):
        invoice = Invoice(amount=Decimal("50.00"), currency="USD", counterparty="acme")

        settlement = compute_settlement(invoice, "USD", Decimal(1))

        assert settlement.gross == Decimal("50.00")
        assert settlement.fee == Decimal("5.00")
        assert settlement.net == Decimal("45.00")

    def should_round_gross_and_fee_to_zero_decimal_places_for_jpy(self):
        invoice = Invoice(amount=Decimal("100.00"), currency="USD", counterparty="acme")

        settlement = compute_settlement(invoice, "JPY", Decimal("150.005"))

        assert settlement.gross == Decimal("15001")
        assert settlement.fee == Decimal("120")
        assert settlement.net == Decimal("14881")
