from fxsettle.currencies import currency_name, minor_units


class DescribeCurrencyName:
    def should_return_the_display_name_for_a_known_code(self):
        assert currency_name("USD") == "United States dollar"

    def should_return_the_code_itself_for_an_unknown_code(self):
        assert currency_name("XYZ") == "XYZ"


class DescribeMinorUnits:
    def should_be_zero_for_jpy(self):
        assert minor_units("JPY") == 0

    def should_be_zero_for_krw(self):
        assert minor_units("KRW") == 0

    def should_be_two_for_any_other_currency(self):
        assert minor_units("USD") == 2
        assert minor_units("EUR") == 2
