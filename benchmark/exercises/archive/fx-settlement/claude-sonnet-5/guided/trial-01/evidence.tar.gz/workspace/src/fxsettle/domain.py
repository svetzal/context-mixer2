"""Pure settlement calculations. No I/O; deterministic for equal inputs."""

from decimal import ROUND_HALF_UP, Decimal

from fxsettle.currencies import minor_units
from fxsettle.models import Invoice, Settlement

FEE_FLOOR = Decimal(5)


def round_to_minor_units(value, currency):
    """Round a decimal amount half-up to the minor units of a currency."""
    places = minor_units(currency)
    quantum = Decimal(1).scaleb(-places)
    return value.quantize(quantum, rounding=ROUND_HALF_UP)


def fee_percentage_for(gross):
    """Return the tiered fee percentage that applies to a gross amount."""
    if gross <= Decimal(1000):
        return Decimal("0.025")
    if gross <= Decimal(10000):
        return Decimal("0.015")
    return Decimal("0.008")


def compute_settlement(invoice: Invoice, quote_currency: str, rate: Decimal) -> Settlement:
    """Convert an invoice into a quote currency settlement at a known rate."""
    gross = round_to_minor_units(invoice.amount * rate, quote_currency)

    fee_percentage = fee_percentage_for(gross)
    fee = round_to_minor_units(max(gross * fee_percentage, FEE_FLOOR), quote_currency)

    net = gross - fee

    return Settlement(
        gross=gross,
        fee=fee,
        net=net,
        rate=rate,
        base_currency=invoice.currency,
        quote_currency=quote_currency,
    )
