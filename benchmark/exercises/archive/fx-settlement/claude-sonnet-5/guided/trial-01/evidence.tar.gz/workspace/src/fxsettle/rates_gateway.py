"""Thin gateway over the external FX rates service.

Owns the only network call in this package. Callers depend on
`fetch_rate` and the exceptions it raises, not on `httpx`.
"""

import os
from decimal import Decimal, InvalidOperation

import httpx

from fxsettle.errors import RateUnavailable, UnknownCurrencyPair

RATES_URL_ENV_VAR = "FXSETTLE_RATES_URL"


def fetch_rate(
    base_currency: str,
    quote_currency: str,
    client: httpx.Client | None = None,
) -> Decimal:
    """Fetch the conversion rate for a base/quote currency pair.

    `client` is injectable so tests can supply an `httpx.Client` built on a
    fake transport instead of touching the network; production callers omit
    it and a real client is used.

    Raises:
        UnknownCurrencyPair: the rates service does not quote this pair.
        RateUnavailable: the rate could not be obtained for any other
            reason, including an unset base URL, a transport failure, a
            non-success status, a non-JSON body, or a missing `rate` field.
    """
    base_url = os.environ.get(RATES_URL_ENV_VAR)
    if not base_url:
        raise RateUnavailable(f"{RATES_URL_ENV_VAR} is not set")

    owns_client = client is None
    http_client = client if client is not None else httpx.Client()

    try:
        return _request_rate(http_client, base_url, base_currency, quote_currency)
    finally:
        if owns_client:
            http_client.close()


def _request_rate(http_client, base_url, base_currency, quote_currency):
    try:
        response = http_client.get(
            f"{base_url}/v1/rates",
            params={"base": base_currency, "quote": quote_currency},
        )
    except httpx.HTTPError as error:
        raise RateUnavailable(f"transport failure fetching rate: {error}") from error

    if response.status_code == 404:
        raise UnknownCurrencyPair(f"no quote for {base_currency}/{quote_currency}")

    if response.is_error:
        raise RateUnavailable(f"rates service returned status {response.status_code}")

    try:
        body = response.json()
    except ValueError as error:
        raise RateUnavailable("rates service returned a non-JSON body") from error

    try:
        return Decimal(str(body["rate"]))
    except (KeyError, InvalidOperation, TypeError) as error:
        raise RateUnavailable("rates service response is missing a valid rate") from error
