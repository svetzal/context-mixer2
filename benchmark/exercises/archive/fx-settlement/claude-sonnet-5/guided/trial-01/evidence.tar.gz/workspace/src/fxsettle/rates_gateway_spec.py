from decimal import Decimal

import httpx
import pytest

from fxsettle.errors import RateUnavailable, UnknownCurrencyPair
from fxsettle.rates_gateway import RATES_URL_ENV_VAR, fetch_rate


def _client_returning(handler):
    return httpx.Client(transport=httpx.MockTransport(handler))


def _json_response(status_code, body):
    def handler(request):
        return httpx.Response(status_code, json=body)

    return handler


def _raw_response(status_code, text):
    def handler(request):
        return httpx.Response(status_code, text=text)

    return handler


class DescribeFetchRate:
    def should_return_the_rate_from_a_successful_response(self, monkeypatch):
        monkeypatch.setenv(RATES_URL_ENV_VAR, "https://rates.example")
        client = _client_returning(
            _json_response(200, {"base": "USD", "quote": "CAD", "rate": "1.3542", "as_of": "2026-08-13"})
        )

        rate = fetch_rate("USD", "CAD", client=client)

        assert rate == Decimal("1.3542")

    def should_send_the_base_and_quote_as_query_parameters(self, monkeypatch):
        monkeypatch.setenv(RATES_URL_ENV_VAR, "https://rates.example")
        seen_requests = []

        def handler(request):
            seen_requests.append(request)
            return httpx.Response(200, json={"base": "USD", "quote": "CAD", "rate": "1.5"})

        client = _client_returning(handler)

        fetch_rate("USD", "CAD", client=client)

        assert seen_requests[0].url.params["base"] == "USD"
        assert seen_requests[0].url.params["quote"] == "CAD"
        assert seen_requests[0].url.path == "/v1/rates"

    def should_raise_unknown_currency_pair_on_a_404(self, monkeypatch):
        monkeypatch.setenv(RATES_URL_ENV_VAR, "https://rates.example")
        client = _client_returning(_raw_response(404, "not found"))

        with pytest.raises(UnknownCurrencyPair):
            fetch_rate("USD", "ZZZ", client=client)

    def should_raise_rate_unavailable_on_a_non_success_status(self, monkeypatch):
        monkeypatch.setenv(RATES_URL_ENV_VAR, "https://rates.example")
        client = _client_returning(_raw_response(500, "server error"))

        with pytest.raises(RateUnavailable):
            fetch_rate("USD", "CAD", client=client)

    def should_raise_rate_unavailable_on_a_non_json_body(self, monkeypatch):
        monkeypatch.setenv(RATES_URL_ENV_VAR, "https://rates.example")
        client = _client_returning(_raw_response(200, "not json"))

        with pytest.raises(RateUnavailable):
            fetch_rate("USD", "CAD", client=client)

    def should_raise_rate_unavailable_on_a_missing_rate_field(self, monkeypatch):
        monkeypatch.setenv(RATES_URL_ENV_VAR, "https://rates.example")
        client = _client_returning(_json_response(200, {"base": "USD", "quote": "CAD"}))

        with pytest.raises(RateUnavailable):
            fetch_rate("USD", "CAD", client=client)

    def should_raise_rate_unavailable_on_a_transport_failure(self, monkeypatch):
        monkeypatch.setenv(RATES_URL_ENV_VAR, "https://rates.example")

        def handler(request):
            raise httpx.ConnectError("connection refused", request=request)

        client = _client_returning(handler)

        with pytest.raises(RateUnavailable):
            fetch_rate("USD", "CAD", client=client)

    def should_raise_rate_unavailable_when_the_base_url_is_unset(self, monkeypatch):
        monkeypatch.delenv(RATES_URL_ENV_VAR, raising=False)

        with pytest.raises(RateUnavailable):
            fetch_rate("USD", "CAD")
