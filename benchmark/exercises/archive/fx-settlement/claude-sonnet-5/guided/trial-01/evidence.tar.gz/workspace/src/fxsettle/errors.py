"""Domain exceptions raised by settlement rate lookups."""


class UnknownCurrencyPair(Exception):
    """Raised when the rates service has no quote for a base/quote pair."""


class RateUnavailable(Exception):
    """Raised when a rate cannot be obtained for any reason other than an
    unknown pair: transport failure, bad status, malformed body, missing
    `rate` field, or missing `FXSETTLE_RATES_URL` configuration.
    """
