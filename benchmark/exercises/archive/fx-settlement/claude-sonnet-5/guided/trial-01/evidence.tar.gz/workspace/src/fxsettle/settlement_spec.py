from decimal import Decimal

import pytest

import fxsettle.settlement as settlement_module
from fxsettle.errors import RateUnavailable, UnknownCurrencyPair
from fxsettle.models import Invoice
from fxsettle.settlement import settle


class DescribeSettle:
    def should_use_a_rate_of_one_and_skip_the_gateway_when_currencies_match(self, monkeypatch):
        def fail_if_called(base_currency, quote_currency):
            raise AssertionError("the rates gateway should not be called")

        monkeypatch.setattr(settlement_module, "fetch_rate", fail_if_called)
        invoice = Invoice(amount=Decimal("100.00"), currency="USD", counterparty="acme")

        result = settle(invoice, "USD")

        assert result.rate == Decimal(1)
        assert result.gross == Decimal("100.00")

    def should_fetch_and_apply_the_rate_from_the_gateway_when_currencies_differ(self, monkeypatch):
        monkeypatch.setattr(settlement_module, "fetch_rate", lambda base, quote: Decimal("1.3542"))
        invoice = Invoice(amount=Decimal("100.00"), currency="USD", counterparty="acme")

        result = settle(invoice, "CAD")

        assert result.rate == Decimal("1.3542")
        assert result.gross == Decimal("135.42")
        assert result.base_currency == "USD"
        assert result.quote_currency == "CAD"

    def should_propagate_unknown_currency_pair_from_the_gateway(self, monkeypatch):
        def raise_unknown_pair(base_currency, quote_currency):
            raise UnknownCurrencyPair("no quote")

        monkeypatch.setattr(settlement_module, "fetch_rate", raise_unknown_pair)
        invoice = Invoice(amount=Decimal("100.00"), currency="USD", counterparty="acme")

        with pytest.raises(UnknownCurrencyPair):
            settle(invoice, "ZZZ")

    def should_propagate_rate_unavailable_from_the_gateway(self, monkeypatch):
        def raise_unavailable(base_currency, quote_currency):
            raise RateUnavailable("no rate")

        monkeypatch.setattr(settlement_module, "fetch_rate", raise_unavailable)
        invoice = Invoice(amount=Decimal("100.00"), currency="USD", counterparty="acme")

        with pytest.raises(RateUnavailable):
            settle(invoice, "CAD")
