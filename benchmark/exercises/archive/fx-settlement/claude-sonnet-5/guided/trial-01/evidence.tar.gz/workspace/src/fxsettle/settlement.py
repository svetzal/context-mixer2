"""Orchestrates settlement: fetches a rate, then applies the pure domain math."""

from decimal import Decimal

from fxsettle.domain import compute_settlement
from fxsettle.models import Invoice, Settlement
from fxsettle.rates_gateway import fetch_rate


def settle(invoice: Invoice, quote_currency: str) -> Settlement:
    """Settle an invoice into `quote_currency`.

    Raises:
        UnknownCurrencyPair: the rates service does not quote this pair.
        RateUnavailable: the rate could not be obtained for any other reason.
    """
    if invoice.currency == quote_currency:
        rate = Decimal(1)
    else:
        rate = fetch_rate(invoice.currency, quote_currency)

    return compute_settlement(invoice, quote_currency, rate)
